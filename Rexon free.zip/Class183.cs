using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Insane Auto Run [RIGHT GRIP]", "Rig", "Fast automatic running forward.", false, 10, ModType.const_0, false)]
internal class Class183 : MonoBehaviour
{
	private static bool bool_0;

	private static int int_0;

	private static double double_0;

	private static int int_1;

	private static bool bool_1;

	private static IntPtr[] ReleaseVarDescGetIUnknownForObjectInContext;

	private static IntPtr[] setInvocationListDefineLPArray;

	private static IntPtr[] TabTypeAttributes;

	private static IntPtr[] NetworkServiceSidResetColor;

	private static float getElementCountSetCursorPosition()
	{
		return Time.time;
	}

	private static Transform setEncoderFallbackgetCompany(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.leftHandTransform;
	}

	private static Vector3 PreLoadEnvoySinks()
	{
		return global::_003CModule_003E.vector3_132;
	}

	private static Vector3 PrepareConstrainedRegionsNoOPIetfLanguageTag(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static Vector3 getMDStreamVersionRound()
	{
		return global::_003CModule_003E.vector3_130;
	}

	private static LayerMask PreAllocatedOverlappedSetAt(int int_2)
	{
		return int_2;
	}

	private static double EscapedgetValidOn(double double_1)
	{
		return Math.Floor(double_1);
	}

	private static bool LdnullSetReturnType(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private unsafe static int smethod_0()
	{
		int num = 29;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 124;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnsuresStackBehaviourPop.GetTypeFromCLSIDContinuationTaskFromTask);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 74;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_038e:
															byte b = *ptr2;
															while (true)
															{
																IL_037e:
																ptr2++;
																while (true)
																{
																	IL_036e:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0351:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_0341:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_0331:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_0324:
																										if (10 < b)
																										{
																											while (11 >= b)
																											{
																												while (11 <= b)
																												{
																													num = 73;
																													while (true)
																													{
																														IL_02bb:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																														while (true)
																														{
																															IL_029c:
																															array[num5 - 2] = 0;
																															num = 155;
																															while (true)
																															{
																																if (num != 155)
																																{
																																	if (num != 1136)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 128:
																																		goto IL_029c;
																																	case 73:
																																	case 75:
																																		goto IL_02bb;
																																	case 35:
																																		goto IL_0301;
																																	case 34:
																																	case 37:
																																		goto IL_0314;
																																	case 40:
																																		goto IL_0324;
																																	case 121:
																																		goto IL_0331;
																																	case 58:
																																		goto IL_0341;
																																	case 136:
																																		goto IL_0351;
																																	case 57:
																																		goto IL_035e;
																																	case 108:
																																		goto IL_036e;
																																	case 2:
																																		goto IL_037e;
																																	case 89:
																																	case 104:
																																		goto IL_038e;
																																	case 36:
																																		goto IL_0399;
																																	case 9:
																																	case 21:
																																		goto IL_03a4;
																																	case 38:
																																		goto IL_03b2;
																																	case 41:
																																		goto IL_03d7;
																																	case 26:
																																	case 84:
																																		goto IL_03e4;
																																	case 117:
																																	case 120:
																																		goto IL_03f4;
																																	case 132:
																																		goto IL_040c;
																																	case 145:
																																		goto IL_041f;
																																	case 94:
																																		goto IL_0429;
																																	case 146:
																																		goto IL_0437;
																																	case 82:
																																	case 147:
																																		goto IL_044a;
																																	case 54:
																																	case 91:
																																		goto IL_0458;
																																	case 85:
																																	case 125:
																																		goto IL_0463;
																																	case 83:
																																		goto IL_046e;
																																	case 92:
																																	case 126:
																																		goto IL_047c;
																																	case 18:
																																		goto IL_04a5;
																																	case 100:
																																		goto IL_04b3;
																																	case 15:
																																		goto IL_04d4;
																																	case 11:
																																	case 122:
																																		goto IL_04df;
																																	case 68:
																																		goto IL_051e;
																																	case 22:
																																		goto IL_0531;
																																	case 14:
																																		goto IL_053f;
																																	case 95:
																																	case 110:
																																		goto IL_054d;
																																	case 23:
																																		goto IL_055b;
																																	case 48:
																																		goto IL_0573;
																																	case 138:
																																		goto IL_0581;
																																	case 3:
																																		goto IL_0594;
																																	case 4:
																																	case 62:
																																		goto IL_059f;
																																	case 24:
																																		goto IL_05bd;
																																	case 5:
																																		goto IL_05cb;
																																	case 80:
																																	case 97:
																																		goto IL_05de;
																																	case 6:
																																		goto IL_05ec;
																																	case 17:
																																	case 30:
																																		goto IL_05f7;
																																	case 115:
																																		goto IL_0637;
																																	case 47:
																																		goto IL_064b;
																																	case 27:
																																	case 60:
																																		goto IL_065e;
																																	case 111:
																																		goto IL_066c;
																																	case 56:
																																	case 112:
																																		goto IL_0685;
																																	case 45:
																																		goto IL_0693;
																																	case 70:
																																	case 119:
																																		goto IL_06a1;
																																	case 134:
																																		goto IL_06ca;
																																	case 79:
																																	case 148:
																																		goto IL_06e3;
																																	case 116:
																																		goto IL_06fc;
																																	case 66:
																																		goto IL_070a;
																																	case 20:
																																		goto IL_0718;
																																	case 64:
																																	case 88:
																																		goto IL_0747;
																																	case 140:
																																		goto IL_0787;
																																	case 81:
																																		goto IL_079b;
																																	case 55:
																																		goto IL_07ae;
																																	case 16:
																																		goto IL_07bc;
																																	case 10:
																																		goto IL_07ca;
																																	case 105:
																																		goto IL_07d8;
																																	case 42:
																																	case 133:
																																		goto IL_07e6;
																																	case 109:
																																		goto IL_0848;
																																	case 1:
																																	case 101:
																																		goto IL_0861;
																																	case 46:
																																	case 71:
																																		goto IL_087a;
																																	case 49:
																																		goto IL_0885;
																																	case 0:
																																	case 7:
																																	case 8:
																																	case 13:
																																	case 19:
																																	case 32:
																																	case 33:
																																	case 51:
																																	case 53:
																																	case 59:
																																	case 61:
																																	case 65:
																																	case 69:
																																	case 76:
																																	case 77:
																																	case 86:
																																	case 90:
																																	case 96:
																																	case 99:
																																	case 103:
																																	case 129:
																																	case 137:
																																	case 139:
																																	case 141:
																																	case 142:
																																	case 143:
																																		goto end_IL_0301;
																																	case 25:
																																	case 31:
																																	case 43:
																																	case 52:
																																	case 63:
																																	case 67:
																																	case 74:
																																	case 78:
																																	case 87:
																																	case 98:
																																	case 102:
																																	case 107:
																																	case 113:
																																	case 114:
																																	case 118:
																																	case 123:
																																	case 127:
																																		goto end_IL_0289;
																																	case 72:
																																		goto end_IL_08a3;
																																	case 93:
																																		goto end_IL_08b6;
																																	case 144:
																																		goto end_IL_08c1;
																																	case 124:
																																		goto end_IL_08cb;
																																	case 39:
																																		goto end_IL_08d6;
																																	case 12:
																																	case 106:
																																		goto end_IL_08e6;
																																	case 50:
																																		goto end_IL_08ff;
																																	case 131:
																																	case 135:
																																		goto end_IL_090f;
																																	case 28:
																																		goto end_IL_091f;
																																	case 29:
																																		goto end_IL_092f;
																																	case 44:
																																	case 130:
																																		goto IL_094a;
																																	}
																																	continue;
																																}
																																num5--;
																																break;
																																continue;
																																end_IL_0289:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_036e;
																													continue;
																													end_IL_0301:
																													break;
																													IL_0301:;
																												}
																												break;
																												IL_0314:;
																											}
																											break;
																										}
																										goto IL_0399;
																										IL_040c:
																										if (9 > b)
																										{
																											break;
																										}
																										goto end_IL_036e;
																										IL_0399:
																										if (10 <= b)
																										{
																											goto IL_03a4;
																										}
																										goto IL_03e4;
																										IL_03a4:
																										array[num5] = 0;
																										goto IL_03b2;
																										IL_03b2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_041f;
																										IL_041f:
																										array2[num5] = null;
																										goto IL_0429;
																										IL_0429:
																										num5++;
																										goto IL_0437;
																										IL_0437:
																										ptr2 += 8;
																										goto end_IL_036e;
																										IL_03e4:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_040c;
																									}
																									break;
																								}
																								num = 64;
																								goto IL_0747;
																								IL_0787:
																								array[num5 - 2] = 0;
																								goto IL_079b;
																								IL_079b:
																								num5--;
																								goto end_IL_036e;
																								IL_0747:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0787;
																							}
																							break;
																						}
																						goto IL_07ae;
																						IL_087a:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0885;
																						IL_07ae:
																						if (14 >= b)
																						{
																							goto IL_07bc;
																						}
																						goto IL_087a;
																						IL_07bc:
																						if (14 > b)
																						{
																							goto IL_07ca;
																						}
																						num = 101;
																						goto IL_0861;
																						IL_07ca:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_07d8;
																						IL_07d8:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_07e6;
																						IL_07e6:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0848;
																						IL_0848:
																						num5 -= 2;
																						goto end_IL_036e;
																						IL_0885:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_0861:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_036e;
																					}
																					break;
																				}
																				goto IL_03d7;
																				IL_06a1:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_06ca;
																				IL_03d7:
																				if (8 <= b)
																				{
																					goto IL_03f4;
																				}
																				goto IL_044a;
																				IL_044a:
																				if (4 < b)
																				{
																					goto IL_0458;
																				}
																				goto IL_0594;
																				IL_0458:
																				if (6 < b)
																				{
																					goto IL_0463;
																				}
																				goto IL_04d4;
																				IL_0463:
																				if (7 < b)
																				{
																					num = 142;
																					break;
																				}
																				goto IL_046e;
																				IL_046e:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_047c;
																				IL_047c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04a5;
																				IL_04a5:
																				ptr2 += 8;
																				goto IL_04b3;
																				IL_04b3:
																				num5--;
																				goto end_IL_036e;
																				IL_06ca:
																				array[num5 - 1] = 5;
																				goto end_IL_036e;
																				IL_04d4:
																				if (6 <= b)
																				{
																					goto IL_04df;
																				}
																				goto IL_0531;
																				IL_04df:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_051e;
																				IL_051e:
																				num5 -= 3;
																				goto end_IL_036e;
																				IL_0531:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_053f;
																				IL_053f:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_054d;
																				IL_054d:
																				array[num5] = 5;
																				goto IL_055b;
																				IL_055b:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0573;
																				IL_0573:
																				num5++;
																				goto IL_0581;
																				IL_0581:
																				ptr2 += 8;
																				goto end_IL_036e;
																				IL_0594:
																				if (4 <= b)
																				{
																					goto IL_059f;
																				}
																				goto IL_05de;
																				IL_059f:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_05bd;
																				IL_05bd:
																				ptr2 += 8;
																				goto IL_05cb;
																				IL_05cb:
																				num5--;
																				goto end_IL_036e;
																				IL_05de:
																				if (2 >= b)
																				{
																					goto IL_05ec;
																				}
																				num = 56;
																				goto IL_0685;
																				IL_05ec:
																				if (2 <= b)
																				{
																					goto IL_05f7;
																				}
																				goto IL_065e;
																				IL_05f7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0637;
																				IL_0637:
																				array[num5 - 2] = 0;
																				goto IL_064b;
																				IL_064b:
																				num5--;
																				goto end_IL_036e;
																				IL_065e:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_066c;
																				IL_066c:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_06e3;
																				IL_06e3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_06fc;
																				IL_06fc:
																				array[num5] = 0;
																				goto IL_070a;
																				IL_070a:
																				num5++;
																				goto IL_0718;
																				IL_0718:
																				ptr2 += 8;
																				goto end_IL_036e;
																				IL_03f4:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_036e;
																				IL_0685:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0693;
																				IL_0693:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_06a1;
																			}
																			break;
																			IL_035e:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_036e:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_094a;
													IL_094a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a3:
													break;
												}
												continue;
												end_IL_08b6:
												break;
											}
											continue;
											end_IL_08c1:
											break;
										}
										continue;
										end_IL_08cb:
										break;
									}
									continue;
									end_IL_08d6:
									break;
								}
								continue;
								end_IL_08e6:
								break;
							}
							continue;
							end_IL_08ff:
							break;
						}
						continue;
						end_IL_090f:
						break;
					}
					continue;
					end_IL_091f:
					break;
				}
				continue;
				end_IL_092f:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getExtraInfoInsufficientMemoryException.ConstructorBuildergetHostFile);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_030a:
															byte b = *ptr2;
															while (true)
															{
																IL_02fa:
																ptr2++;
																while (true)
																{
																	IL_02ea:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02ca:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02bd:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_02ad:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_02a0:
																										if (4 >= b)
																										{
																											while (4 <= b)
																											{
																												num = 88;
																												while (true)
																												{
																													IL_0259:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 19;
																													while (true)
																													{
																														IL_0249:
																														ptr2 += 8;
																														while (true)
																														{
																															IL_0230:
																															num5--;
																															num = 128;
																															while (num != 128)
																															{
																																if (num != 1109)
																																{
																																	goto end_IL_028d;
																																}
																																switch (num)
																																{
																																case 98:
																																	goto IL_0230;
																																case 19:
																																	goto IL_0249;
																																case 88:
																																case 105:
																																	goto IL_0259;
																																case 33:
																																	goto IL_028d;
																																case 10:
																																case 85:
																																	goto IL_02a0;
																																case 67:
																																	goto IL_02ad;
																																case 1:
																																	goto IL_02bd;
																																case 59:
																																	goto IL_02ca;
																																case 116:
																																	goto IL_02da;
																																case 75:
																																	goto IL_02ea;
																																case 21:
																																	goto IL_02fa;
																																case 31:
																																case 61:
																																	goto IL_030a;
																																case 50:
																																	goto IL_0323;
																																case 72:
																																	goto IL_0331;
																																case 48:
																																case 104:
																																	goto IL_0348;
																																case 0:
																																	goto IL_0360;
																																case 90:
																																case 103:
																																	goto IL_036e;
																																case 49:
																																	goto IL_0379;
																																case 84:
																																	goto IL_038c;
																																case 66:
																																	goto IL_03a3;
																																case 36:
																																case 56:
																																	goto IL_03b1;
																																case 112:
																																	goto IL_041f;
																																case 42:
																																case 106:
																																	goto IL_0432;
																																case 29:
																																	goto IL_0472;
																																case 12:
																																	goto IL_0486;
																																case 117:
																																	goto IL_0499;
																																case 101:
																																case 114:
																																	goto IL_04a7;
																																case 32:
																																	goto IL_04b5;
																																case 81:
																																	goto IL_04c3;
																																case 39:
																																	goto IL_04d1;
																																case 79:
																																case 108:
																																	goto IL_04df;
																																case 28:
																																	goto IL_04f3;
																																case 111:
																																	goto IL_0547;
																																case 26:
																																	goto IL_0555;
																																case 30:
																																case 41:
																																	goto IL_0571;
																																case 74:
																																case 95:
																																	goto IL_058d;
																																case 65:
																																	goto IL_059b;
																																case 13:
																																case 62:
																																	goto IL_05a9;
																																case 73:
																																	goto IL_05c5;
																																case 14:
																																case 96:
																																	goto IL_05dc;
																																case 97:
																																	goto IL_05e7;
																																case 16:
																																case 20:
																																	goto IL_05f5;
																																case 63:
																																	goto IL_0603;
																																case 70:
																																	goto IL_0626;
																																case 22:
																																	goto IL_0639;
																																case 71:
																																	goto IL_0647;
																																case 4:
																																	goto IL_065a;
																																case 78:
																																	goto IL_0668;
																																case 40:
																																case 100:
																																	goto IL_0676;
																																case 109:
																																	goto IL_068f;
																																case 113:
																																	goto IL_069d;
																																case 83:
																																	goto IL_06ab;
																																case 11:
																																case 86:
																																	goto IL_06be;
																																case 60:
																																	goto IL_06fe;
																																case 7:
																																	goto IL_0712;
																																case 3:
																																case 9:
																																case 15:
																																case 23:
																																case 25:
																																case 37:
																																case 43:
																																case 44:
																																case 45:
																																case 47:
																																case 51:
																																case 52:
																																case 53:
																																case 55:
																																case 58:
																																case 80:
																																case 82:
																																case 93:
																																case 99:
																																case 115:
																																	goto end_IL_028d;
																																case 64:
																																	goto IL_074e;
																																case 8:
																																	goto IL_075c;
																																case 17:
																																	goto IL_076a;
																																case 2:
																																case 18:
																																case 24:
																																case 27:
																																case 35:
																																case 38:
																																case 54:
																																case 57:
																																case 68:
																																case 69:
																																case 91:
																																case 102:
																																case 107:
																																case 121:
																																	goto end_IL_021d;
																																case 94:
																																	goto end_IL_0778;
																																case 118:
																																	goto end_IL_078b;
																																case 6:
																																	goto end_IL_0795;
																																case 87:
																																	goto end_IL_07a0;
																																case 120:
																																	goto end_IL_07b5;
																																case 34:
																																case 46:
																																	goto end_IL_07ca;
																																case 110:
																																	goto end_IL_07da;
																																case 5:
																																case 89:
																																	goto end_IL_07ea;
																																case 76:
																																	goto end_IL_07fa;
																																case 77:
																																	goto end_IL_080a;
																																case 92:
																																case 119:
																																	goto IL_082e;
																																}
																																continue;
																																end_IL_021d:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02bd;
																												continue;
																												end_IL_028d:
																												break;
																												IL_028d:;
																											}
																											break;
																										}
																										goto IL_0323;
																										IL_0348:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02bd;
																										IL_0323:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_0331;
																										IL_0331:
																										if (5 > b)
																										{
																											break;
																										}
																										num = 48;
																										goto IL_0348;
																									}
																									break;
																								}
																								goto IL_0360;
																								IL_0472:
																								array[num5 - 2] = 0;
																								goto IL_0486;
																								IL_0360:
																								if (3 > b)
																								{
																									goto IL_036e;
																								}
																								goto IL_0432;
																								IL_036e:
																								if (1 >= b)
																								{
																									goto IL_0379;
																								}
																								goto IL_038c;
																								IL_0379:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_038c:
																								if (2 < b)
																								{
																									break;
																								}
																								num = 66;
																								goto IL_03a3;
																								IL_0486:
																								num5--;
																								goto end_IL_02bd;
																								IL_03a3:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_03b1;
																								IL_03b1:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_041f;
																								IL_041f:
																								num5 -= 2;
																								goto end_IL_02bd;
																								IL_0432:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0472;
																							}
																							goto end_IL_02da;
																						}
																						num = 69;
																						break;
																						continue;
																						end_IL_02bd:
																						break;
																					}
																					break;
																				}
																				goto IL_0499;
																				IL_06ab:
																				ptr2 += 8;
																				break;
																				IL_0499:
																				if (9 < b)
																				{
																					goto IL_04a7;
																				}
																				goto IL_05c5;
																				IL_04a7:
																				if (11 >= b)
																				{
																					goto IL_04b5;
																				}
																				num = 74;
																				goto IL_058d;
																				IL_04b5:
																				if (11 > b)
																				{
																					goto IL_04c3;
																				}
																				num = 41;
																				goto IL_0571;
																				IL_04c3:
																				if (10 < b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_04d1;
																				IL_04d1:
																				if (10 > b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_04df;
																				IL_04df:
																				array[num5 - 2] = 0;
																				goto IL_04f3;
																				IL_04f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)TabTypeAttributes[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0547;
																				IL_0547:
																				num5--;
																				goto IL_0555;
																				IL_0555:
																				ptr2 += 8;
																				break;
																				IL_06fe:
																				array[num5 - 2] = 0;
																				goto IL_0712;
																				IL_0571:
																				num5--;
																				break;
																				IL_06be:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06fe;
																				IL_058d:
																				if (12 < b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_059b;
																				IL_059b:
																				if (12 > b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_05a9;
																				IL_05a9:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_05c5:
																				if (9 > b)
																				{
																					num = 96;
																					goto IL_05dc;
																				}
																				goto IL_06be;
																				IL_0712:
																				num5--;
																				num = 18;
																				break;
																				IL_05dc:
																				if (7 >= b)
																				{
																					goto IL_05e7;
																				}
																				goto IL_065a;
																				IL_05e7:
																				if (7 > b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_05f5;
																				IL_05f5:
																				array[num5] = 0;
																				goto IL_0603;
																				IL_0603:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0626;
																				IL_0626:
																				array2[num5] = null;
																				num = 22;
																				goto IL_0639;
																				IL_0639:
																				num5++;
																				goto IL_0647;
																				IL_0647:
																				ptr2 += 8;
																				break;
																				IL_065a:
																				if (8 < b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_0668;
																				IL_0668:
																				if (8 > b)
																				{
																					goto end_IL_02da;
																				}
																				goto IL_0676;
																				IL_0676:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_068f;
																				IL_068f:
																				array[num5] = 0;
																				goto IL_069d;
																				IL_069d:
																				num5++;
																				goto IL_06ab;
																			}
																			goto end_IL_02ea;
																			continue;
																			end_IL_02da:
																			break;
																			IL_02da:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_074e;
																	IL_076a:
																	ptr2 += 8;
																	break;
																	IL_075c:
																	num5++;
																	goto IL_076a;
																	IL_074e:
																	array[num5] = 0;
																	goto IL_075c;
																	continue;
																	end_IL_02ea:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 92;
													goto IL_082e;
													IL_082e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0778:
													break;
												}
												continue;
												end_IL_078b:
												break;
											}
											continue;
											end_IL_0795:
											break;
										}
										continue;
										end_IL_07a0:
										break;
									}
									continue;
									end_IL_07b5:
									break;
								}
								continue;
								end_IL_07ca:
								break;
							}
							continue;
							end_IL_07da:
							break;
						}
						continue;
						end_IL_07ea:
						break;
					}
					continue;
					end_IL_07fa:
					break;
				}
				continue;
				end_IL_080a:
				break;
			}
		}
	}

	private static double SafeThreadHandleBlockSize(double double_1)
	{
		return Math.Round(double_1);
	}

	private static Vector3 RIPEMDDuplicate()
	{
		return global::_003CModule_003E.vector3_135;
	}

	private static bool InterruptCOREFILELOAD(Vector3 vector3_0, Vector3 vector3_1, ref RaycastHit raycastHit_0, float float_0, int int_2)
	{
		return Physics.Raycast(vector3_0, vector3_1, out raycastHit_0, float_0, int_2);
	}

	private static ControllerInputPoller TupleElementNamesAttributeCATEGORYINSTANCE()
	{
		return ControllerInputPoller.instance;
	}

	private static Vector3 EnhancedKeyGetInstance(Transform transform_0)
	{
		return transform_0.right;
	}

	private static Quaternion BuiltInPermissionSetsRightAltPressed(Vector3 vector3_0)
	{
		return Quaternion.LookRotation(vector3_0);
	}

	private static Vector3 UnauthenticatedPrincipalEmptyReadOnlyDictionaryInternal()
	{
		return global::_003CModule_003E.vector3_138;
	}

	private static CapsuleCollider CursorTopAddKeyword(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.bodyCollider;
	}

	private static string BuiltinReplicatorSidTimer(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private unsafe void Update()
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num == 995)
						{
							switch (num)
							{
							case 3:
								goto end_IL_0044;
							case 4:
								goto end_IL_0051;
							case 0:
								goto IL_0069;
							case 2:
							case 7:
								goto IL_009c;
							case 1:
								goto IL_00a2;
							case 5:
							case 6:
								return;
							}
							continue;
						}
					}
					else
					{
						num3 = 0;
					}
					goto IL_009c;
					IL_009c:
					if (num3 != 62)
					{
						goto IL_0069;
					}
					goto IL_00a2;
					IL_0069:
					((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, void>)ReleaseVarDescGetIUnknownForObjectInContext[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref num11);
					goto IL_009c;
					IL_00a2:
					num3 = 0;
					return;
					continue;
					end_IL_0044:
					break;
				}
				continue;
				end_IL_0051:
				break;
			}
		}
	}

	private static double MulticastDelegateCheckValueWritePermission(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static double NotHandledCrossAppDomainString(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static double FieldInfoCollect(double double_1)
	{
		return Math.Cos(double_1);
	}

	private static Vector3 getANSICodePagegetDays()
	{
		return Vector3.up;
	}

	private static double GenericPrincipalJulianCenturies(double double_1)
	{
		return Math.Log(double_1);
	}

	private static float ObjectWithMapAssemIdMonitoringTotalProcessorTime()
	{
		return global::_003CModule_003E.float_113;
	}

	private static Vector3 PrivateBinPathProbeValuegetCompatibleFrameworksData(Vector3 vector3_0, float float_0)
	{
		return vector3_0 * float_0;
	}

	private static Vector3 smethod_2()
	{
		return global::_003CModule_003E.vector3_140;
	}

	private static Vector3 COMServerThreadingModelSetReturnType()
	{
		return global::_003CModule_003E.vector3_139;
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDayOfMonthGetDeserializedTimeZoneInfo.HexBinaryAssumeLocal);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0412:
														byte b = *ptr2;
														while (true)
														{
															IL_0402:
															ptr2++;
															while (true)
															{
																IL_03f2:
																if (b >= 1)
																{
																	goto IL_0242;
																}
																goto IL_03d1;
																IL_03d1:
																while (true)
																{
																	IL_03d1_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 136;
																	while (num != 136 && num == 1117)
																	{
																		switch (num)
																		{
																		case 74:
																			goto IL_0242;
																		case 82:
																			goto IL_0250;
																		case 35:
																		case 38:
																			goto IL_0264;
																		case 115:
																			goto IL_0274;
																		case 61:
																			goto IL_0282;
																		case 49:
																			goto IL_0290;
																		case 34:
																			goto IL_029e;
																		case 102:
																			goto IL_02a9;
																		case 60:
																		case 116:
																			goto IL_02bc;
																		case 86:
																			goto IL_02c7;
																		case 119:
																			goto IL_02e8;
																		case 57:
																		case 107:
																			goto IL_02f6;
																		case 56:
																			goto IL_0301;
																		case 22:
																			goto IL_0314;
																		case 25:
																			goto IL_0322;
																		case 7:
																		case 128:
																			goto IL_0335;
																		case 23:
																		case 46:
																			goto IL_0340;
																		case 89:
																			goto IL_034e;
																		case 36:
																			goto IL_035b;
																		case 125:
																			goto IL_0369;
																		case 103:
																			goto IL_0374;
																		case 127:
																		case 129:
																			goto IL_0384;
																		case 13:
																			goto IL_038f;
																		case 31:
																		case 51:
																			goto IL_039d;
																		case 121:
																			goto IL_03a8;
																		case 20:
																			goto IL_03b8;
																		case 62:
																			goto IL_03c3;
																		case 0:
																		case 1:
																		case 3:
																		case 4:
																		case 12:
																		case 14:
																		case 15:
																		case 16:
																		case 30:
																		case 39:
																		case 40:
																		case 42:
																		case 48:
																		case 65:
																		case 73:
																		case 76:
																		case 80:
																		case 85:
																		case 87:
																		case 90:
																		case 96:
																		case 113:
																		case 114:
																			goto IL_03d1_2;
																		case 32:
																			goto IL_03f2;
																		case 123:
																			goto IL_0402;
																		case 6:
																		case 17:
																			goto IL_0412;
																		case 55:
																		case 79:
																			goto IL_041d;
																		case 37:
																			goto IL_0440;
																		case 108:
																			goto IL_044e;
																		case 21:
																		case 66:
																			goto IL_0461;
																		case 77:
																		case 78:
																			goto IL_0479;
																		case 101:
																			goto IL_0492;
																		case 92:
																			goto IL_04a0;
																		case 105:
																			goto IL_04b7;
																		case 111:
																		case 118:
																			goto IL_04ca;
																		case 84:
																			goto IL_04f3;
																		case 99:
																			goto IL_0501;
																		case 70:
																		case 93:
																			goto IL_0514;
																		case 43:
																			goto IL_0576;
																		case 26:
																		case 28:
																			goto IL_0589;
																		case 2:
																			goto IL_05c9;
																		case 117:
																			goto IL_05dd;
																		case 54:
																		case 59:
																			goto IL_05f0;
																		case 53:
																			goto IL_0604;
																		case 100:
																			goto IL_0643;
																		case 124:
																			goto IL_0656;
																		case 58:
																		case 63:
																			goto IL_0669;
																		case 83:
																		case 122:
																			goto IL_0685;
																		case 64:
																		case 75:
																			goto IL_06a1;
																		case 110:
																			goto IL_06af;
																		case 18:
																			goto IL_06d2;
																		case 10:
																			goto IL_06dc;
																		case 112:
																			goto IL_06f3;
																		case 27:
																		case 69:
																			goto IL_070c;
																		case 8:
																			goto IL_0755;
																		case 88:
																			goto IL_0769;
																		case 9:
																		case 19:
																		case 33:
																		case 45:
																		case 47:
																		case 50:
																		case 71:
																		case 72:
																		case 81:
																		case 91:
																		case 94:
																		case 95:
																		case 109:
																		case 120:
																		case 126:
																			goto end_IL_022f;
																		case 11:
																			goto end_IL_0777;
																		case 29:
																			goto end_IL_078a;
																		case 24:
																			goto end_IL_0794;
																		case 44:
																			goto end_IL_079f;
																		case 52:
																		case 97:
																			goto end_IL_07b4;
																		case 98:
																			goto end_IL_07c4;
																		case 41:
																		case 104:
																			goto end_IL_07d4;
																		case 67:
																			goto end_IL_07e4;
																		case 68:
																			goto end_IL_07f4;
																		case 5:
																		case 106:
																			goto IL_080f;
																		}
																		continue;
																		end_IL_022f:
																		break;
																	}
																	break;
																}
																break;
																IL_0242:
																if (b <= 13)
																{
																	goto IL_0250;
																}
																goto IL_03d1;
																IL_0250:
																if (7 < b)
																{
																	num = 35;
																	goto IL_0264;
																}
																goto IL_0274;
																IL_0440:
																array[num5] = 0;
																goto IL_044e;
																IL_0264:
																if (10 >= b)
																{
																	goto IL_02e8;
																}
																goto IL_0335;
																IL_0335:
																if (12 < b)
																{
																	goto IL_0340;
																}
																goto IL_035b;
																IL_0340:
																if (13 >= b)
																{
																	goto IL_034e;
																}
																goto IL_03d1;
																IL_034e:
																if (13 <= b)
																{
																}
																goto IL_03d1;
																IL_035b:
																if (12 > b)
																{
																	goto IL_0369;
																}
																goto IL_0669;
																IL_0369:
																if (11 >= b)
																{
																	goto IL_0374;
																}
																goto IL_03d1;
																IL_0374:
																if (11 > b)
																{
																	goto IL_03d1;
																}
																goto IL_0685;
																IL_0685:
																num5--;
																num = 71;
																break;
																IL_0669:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																break;
																IL_02e8:
																if (10 > b)
																{
																	goto IL_02f6;
																}
																goto IL_05f0;
																IL_02f6:
																if (8 >= b)
																{
																	goto IL_0301;
																}
																goto IL_0314;
																IL_0301:
																if (8 > b)
																{
																	goto IL_03d1;
																}
																goto IL_0514;
																IL_0514:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0576;
																IL_0576:
																num5 -= 2;
																break;
																IL_0314:
																if (9 >= b)
																{
																	goto IL_0322;
																}
																goto IL_03d1;
																IL_0322:
																if (9 > b)
																{
																	goto IL_03d1;
																}
																goto IL_0589;
																IL_0589:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05c9;
																IL_05c9:
																array[num5 - 2] = 0;
																goto IL_05dd;
																IL_05dd:
																num5--;
																break;
																IL_05f0:
																array[num5 - 1] = 0;
																goto IL_0604;
																IL_0604:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)NetworkServiceSidResetColor[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_0643;
																IL_0643:
																ptr2 += 8;
																break;
																IL_0274:
																if (7 > b)
																{
																	goto IL_0282;
																}
																goto IL_041d;
																IL_0282:
																if (3 >= b)
																{
																	goto IL_0290;
																}
																goto IL_0384;
																IL_0290:
																if (3 > b)
																{
																	goto IL_029e;
																}
																goto IL_0461;
																IL_029e:
																if (1 >= b)
																{
																	goto IL_02a9;
																}
																goto IL_02bc;
																IL_02a9:
																if (1 > b)
																{
																	goto IL_03d1;
																}
																goto IL_0479;
																IL_0479:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0492;
																IL_0492:
																array[num5] = 0;
																goto IL_04a0;
																IL_04a0:
																num5++;
																num = 105;
																goto IL_04b7;
																IL_04b7:
																ptr2 += 8;
																break;
																IL_02bc:
																if (2 >= b)
																{
																	goto IL_02c7;
																}
																num = 87;
																goto IL_03d1;
																IL_02c7:
																if (2 > b)
																{
																	goto IL_03d1;
																}
																goto IL_04ca;
																IL_04ca:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04f3;
																IL_04f3:
																ptr2 += 8;
																goto IL_0501;
																IL_0501:
																num5--;
																break;
																IL_044e:
																num5++;
																goto IL_0656;
																IL_0461:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0384:
																if (5 >= b)
																{
																	goto IL_038f;
																}
																goto IL_03b8;
																IL_038f:
																if (5 > b)
																{
																	goto IL_039d;
																}
																goto IL_06a1;
																IL_039d:
																if (4 >= b)
																{
																	goto IL_03a8;
																}
																goto IL_03d1;
																IL_03a8:
																if (4 <= b)
																{
																	break;
																}
																goto IL_03d1;
																IL_06a1:
																array[num5] = 0;
																goto IL_06af;
																IL_06af:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_06d2;
																IL_06d2:
																array2[num5] = null;
																goto IL_06dc;
																IL_06dc:
																num5++;
																num = 112;
																goto IL_06f3;
																IL_06f3:
																ptr2 += 8;
																break;
																IL_03b8:
																if (6 >= b)
																{
																	goto IL_03c3;
																}
																goto IL_03d1;
																IL_03c3:
																if (6 > b)
																{
																	goto IL_03d1;
																}
																num = 27;
																goto IL_070c;
																IL_0656:
																ptr2 += 8;
																break;
																IL_070c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 8;
																goto IL_0755;
																IL_0755:
																array[num5 - 2] = 0;
																goto IL_0769;
																IL_0769:
																num5--;
																break;
																IL_041d:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0440;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_080f;
												IL_080f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0777:
												break;
											}
											continue;
											end_IL_078a:
											break;
										}
										continue;
										end_IL_0794:
										break;
									}
									continue;
									end_IL_079f:
									break;
								}
								continue;
								end_IL_07b4:
								break;
							}
							continue;
							end_IL_07c4:
							break;
						}
						continue;
						end_IL_07d4:
						break;
					}
					continue;
					end_IL_07e4:
					break;
				}
				continue;
				end_IL_07f4:
				break;
			}
		}
	}

	private static float OptionalParamBindingAddPermission(Vector3 vector3_0)
	{
		return vector3_0.z;
	}

	private static object rootChineseLunisolarCalendar(float float_0, float float_1, float float_2)
	{
		return new Vector3(float_0, float_1, float_2);
	}

	private static double StoreOperationInstallDeploymentAssemblyBuilderAccess(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static void getReflectionOnlygetKeys(Transform transform_0, Quaternion quaternion_0)
	{
		transform_0.rotation = quaternion_0;
	}

	private static int smethod_4(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		num += num2;
		int num3 = num;
		num = int_2;
		num2 = int_3;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 957;
		num2 = 87;
		return num + 87;
	}

	private static Vector3 smethod_5(Vector3 vector3_0, Vector3 vector3_1, float float_0)
	{
		return Vector3.Lerp(vector3_0, vector3_1, float_0);
	}

	private static Transform LaunchMediaSelectsetAutoFlush(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static LayerMask ResourceWriterCompatibleFrameworksMetadataSupportUrl()
	{
		return global::_003CModule_003E.layerMask_1;
	}

	private static object WindowsCodePageTCEAdapterGenerator(float float_0, float float_1, float float_2)
	{
		return new Vector3(float_0, float_1, float_2);
	}

	private static double DispatchChannelSinkProviderRC(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static int OutTypeChainFlagsetUrl(LayerMask layerMask_0)
	{
		return layerMask_0;
	}

	private static Vector3 ZoneMembershipConditionHandleToInfo()
	{
		return global::_003CModule_003E.vector3_134;
	}

	private static Vector3 FavoritesCheckSubKeyReadPermission()
	{
		return global::_003CModule_003E.vector3_131;
	}

	private static float getElementIndexFileAssociationSection(Vector3 vector3_0)
	{
		return vector3_0.x;
	}

	private static int BaseAddressFilePathOrdinalIgnoreCase(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static SphereCollider BestFitUseAssemParamName(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.headCollider;
	}

	private static Vector3 GetHashFromHandleHashMembershipCondition()
	{
		return global::_003CModule_003E.vector3_137;
	}

	private static float RedirectedGuidISymbolScope(float float_0)
	{
		return Mathf.Sin(float_0);
	}

	private static float getPersistgetResolver(float float_0)
	{
		return Mathf.Cos(float_0);
	}

	private static double DeleteLocalDataStoreIIDIEnumSTOREASSEMBLY(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static Vector3 HeaderPreserveEventListnerObjectIdentity(Transform transform_0)
	{
		return transform_0.forward;
	}

	private static float SuppressFlowgetUserClaimsd(Vector3 vector3_0)
	{
		return vector3_0.y;
	}

	private static Vector3 setUseStdAsciiRulesLastEvent(Vector3 vector3_0, Vector3 vector3_1)
	{
		return vector3_0 + vector3_1;
	}

	private static Vector3 getIsNestedFamANDAssemgetUniversalSortableDateTimePattern(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.point;
	}

	private unsafe static int smethod_7()
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 64;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OrderFullTrustAssemblies.ArrayListR);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_037d:
														byte b = *ptr2;
														while (true)
														{
															IL_036d:
															ptr2++;
															while (true)
															{
																IL_035d:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		num = 21;
																		while (true)
																		{
																			IL_033a:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_032a:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_031d:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_030d:
																									if (6 < b)
																									{
																										while (true)
																										{
																											IL_02fd:
																											if (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_02b9:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 138;
																														while (true)
																														{
																															IL_02a0:
																															ptr2 += 8;
																															num = 156;
																															while (true)
																															{
																																if (num != 156)
																																{
																																	if (num != 1137)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 138:
																																		goto IL_02a0;
																																	case 9:
																																	case 92:
																																		goto IL_02b9;
																																	case 117:
																																		goto IL_02ed;
																																	case 103:
																																		goto IL_02fd;
																																	case 95:
																																		goto IL_030d;
																																	case 110:
																																	case 147:
																																		goto IL_031d;
																																	case 44:
																																		goto IL_032a;
																																	case 21:
																																		goto IL_033a;
																																	case 19:
																																		goto IL_034a;
																																	case 98:
																																		goto IL_035d;
																																	case 102:
																																		goto IL_036d;
																																	case 3:
																																	case 68:
																																		goto IL_037d;
																																	case 13:
																																		goto IL_0388;
																																	case 28:
																																	case 53:
																																		goto IL_0393;
																																	case 22:
																																		goto IL_03b1;
																																	case 71:
																																	case 75:
																																		goto IL_03c1;
																																	case 94:
																																		goto IL_03d1;
																																	case 97:
																																		goto IL_03e1;
																																	case 10:
																																	case 113:
																																		goto IL_03f4;
																																	case 33:
																																		goto IL_0433;
																																	case 137:
																																		goto IL_0446;
																																	case 116:
																																		goto IL_0451;
																																	case 77:
																																		goto IL_045f;
																																	case 24:
																																	case 62:
																																		goto IL_046d;
																																	case 91:
																																		goto IL_0486;
																																	case 112:
																																		goto IL_0494;
																																	case 30:
																																		goto IL_04a2;
																																	case 27:
																																	case 136:
																																		goto IL_04be;
																																	case 52:
																																		goto IL_04fe;
																																	case 69:
																																		goto IL_0512;
																																	case 140:
																																		goto IL_0525;
																																	case 48:
																																		goto IL_0533;
																																	case 45:
																																	case 111:
																																		goto IL_0541;
																																	case 63:
																																		goto IL_056a;
																																	case 123:
																																	case 148:
																																		goto IL_0583;
																																	case 35:
																																		goto IL_0591;
																																	case 23:
																																	case 36:
																																		goto IL_059c;
																																	case 18:
																																		goto IL_05aa;
																																	case 57:
																																		goto IL_05c2;
																																	case 76:
																																		goto IL_05d9;
																																	case 59:
																																	case 120:
																																		goto IL_0624;
																																	case 82:
																																		goto IL_063c;
																																	case 43:
																																		goto IL_064a;
																																	case 15:
																																	case 39:
																																		goto IL_0655;
																																	case 85:
																																		goto IL_0695;
																																	case 143:
																																		goto IL_06a9;
																																	case 26:
																																		goto IL_06c5;
																																	case 61:
																																		goto IL_06d3;
																																	case 49:
																																	case 96:
																																		goto IL_06de;
																																	case 65:
																																		goto IL_06ec;
																																	case 106:
																																	case 132:
																																		goto IL_06ff;
																																	case 146:
																																		goto IL_070d;
																																	case 8:
																																		goto IL_0730;
																																	case 135:
																																		goto IL_073a;
																																	case 119:
																																		goto IL_0748;
																																	case 80:
																																	case 149:
																																		goto IL_075b;
																																	case 129:
																																		goto IL_0769;
																																	case 40:
																																	case 89:
																																		goto IL_0777;
																																	case 70:
																																		goto IL_07bb;
																																	case 42:
																																		goto IL_07cf;
																																	case 38:
																																	case 74:
																																		goto IL_07eb;
																																	case 37:
																																		goto IL_07f9;
																																	case 25:
																																	case 99:
																																		goto IL_0804;
																																	case 7:
																																		goto IL_0820;
																																	case 88:
																																		goto IL_082e;
																																	case 56:
																																	case 124:
																																		goto IL_083c;
																																	case 16:
																																		goto IL_089e;
																																	case 108:
																																		goto IL_08ae;
																																	case 81:
																																		goto IL_08b9;
																																	case 0:
																																	case 4:
																																	case 14:
																																	case 20:
																																	case 29:
																																	case 31:
																																	case 32:
																																	case 47:
																																	case 54:
																																	case 55:
																																	case 67:
																																	case 78:
																																	case 79:
																																	case 87:
																																	case 90:
																																	case 100:
																																	case 101:
																																	case 104:
																																	case 109:
																																	case 121:
																																	case 122:
																																	case 126:
																																	case 130:
																																	case 131:
																																	case 133:
																																	case 134:
																																	case 139:
																																	case 142:
																																	case 144:
																																	case 145:
																																		goto end_IL_02ed;
																																	case 11:
																																	case 17:
																																	case 34:
																																	case 41:
																																	case 46:
																																	case 50:
																																	case 60:
																																	case 66:
																																	case 72:
																																	case 73:
																																	case 83:
																																	case 84:
																																	case 86:
																																	case 93:
																																	case 114:
																																	case 118:
																																	case 128:
																																	case 141:
																																		goto end_IL_028d;
																																	case 1:
																																		goto end_IL_08d7;
																																	case 127:
																																		goto end_IL_08ea;
																																	case 64:
																																		goto end_IL_08f4;
																																	case 12:
																																		goto end_IL_08ff;
																																	case 58:
																																	case 107:
																																		goto end_IL_090f;
																																	case 115:
																																		goto end_IL_0928;
																																	case 51:
																																	case 125:
																																		goto end_IL_0938;
																																	case 5:
																																		goto end_IL_0948;
																																	case 6:
																																		goto end_IL_0958;
																																	case 2:
																																	case 105:
																																		goto IL_097c;
																																	}
																																	continue;
																																}
																																num5--;
																																num = 118;
																																break;
																																continue;
																																end_IL_028d:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_035d;
																													continue;
																													end_IL_02ed:
																													break;
																													IL_02ed:;
																												}
																											}
																											else
																											{
																												num = 104;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03d1;
																									IL_05d9:
																									ptr2 += 8;
																									goto end_IL_035d;
																									IL_03d1:
																									if (6 <= b)
																									{
																										goto IL_03f4;
																									}
																									goto IL_0583;
																									IL_03f4:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0433;
																									IL_0433:
																									num5 -= 3;
																									goto end_IL_035d;
																									IL_0583:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0591;
																									IL_0591:
																									if (5 > b)
																									{
																										num = 78;
																										break;
																									}
																									goto IL_059c;
																									IL_059c:
																									array[num5] = 5;
																									goto IL_05aa;
																									IL_05aa:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_05c2;
																									IL_05c2:
																									num5++;
																									num = 76;
																									goto IL_05d9;
																								}
																								break;
																							}
																							goto IL_0388;
																							IL_0541:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_056a;
																							IL_0388:
																							if (4 <= b)
																							{
																								goto IL_0393;
																							}
																							goto IL_03c1;
																							IL_0393:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_03b1;
																							IL_03b1:
																							ptr2 += 8;
																							goto IL_03e1;
																							IL_03e1:
																							num5--;
																							goto end_IL_035d;
																							IL_03c1:
																							if (2 >= b)
																							{
																								goto IL_0446;
																							}
																							goto IL_0525;
																							IL_0446:
																							if (2 > b)
																							{
																								goto IL_0451;
																							}
																							num = 27;
																							goto IL_04be;
																							IL_0451:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_045f;
																							IL_045f:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_046d;
																							IL_046d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0486;
																							IL_0486:
																							array[num5] = 0;
																							goto IL_0494;
																							IL_0494:
																							num5++;
																							goto IL_04a2;
																							IL_04a2:
																							ptr2 += 8;
																							goto end_IL_035d;
																							IL_056a:
																							array[num5 - 1] = 5;
																							goto end_IL_035d;
																							IL_04be:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fe;
																							IL_04fe:
																							array[num5 - 2] = 0;
																							goto IL_0512;
																							IL_0512:
																							num5--;
																							goto end_IL_035d;
																							IL_0525:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0533;
																							IL_0533:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0541;
																						}
																						break;
																					}
																					goto IL_0624;
																					IL_0624:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_035d;
																				}
																				break;
																			}
																			goto IL_063c;
																			IL_08ae:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_08b9;
																			IL_063c:
																			if (12 >= b)
																			{
																				goto IL_064a;
																			}
																			num = 74;
																			goto IL_07eb;
																			IL_064a:
																			if (12 <= b)
																			{
																				goto IL_0655;
																			}
																			goto IL_06c5;
																			IL_0655:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0695;
																			IL_0695:
																			array[num5 - 2] = 0;
																			goto IL_06a9;
																			IL_06a9:
																			num5--;
																			num = 60;
																			goto end_IL_035d;
																			IL_06c5:
																			if (10 >= b)
																			{
																				goto IL_06d3;
																			}
																			goto IL_075b;
																			IL_06d3:
																			if (10 > b)
																			{
																				goto IL_06de;
																			}
																			goto IL_06ff;
																			IL_06de:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06ec;
																			IL_06ec:
																			if (9 <= b)
																			{
																				goto end_IL_035d;
																			}
																			break;
																			IL_06ff:
																			array[num5] = 0;
																			goto IL_070d;
																			IL_070d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0730;
																			IL_0730:
																			array2[num5] = null;
																			goto IL_073a;
																			IL_073a:
																			num5++;
																			goto IL_0748;
																			IL_0748:
																			ptr2 += 8;
																			goto end_IL_035d;
																			IL_075b:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0769;
																			IL_0769:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0777;
																			IL_0777:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07bb;
																			IL_07bb:
																			array[num5 - 2] = 0;
																			goto IL_07cf;
																			IL_07cf:
																			num5--;
																			goto end_IL_035d;
																			IL_08b9:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_07eb:
																			if (14 >= b)
																			{
																				goto IL_07f9;
																			}
																			goto IL_08ae;
																			IL_07f9:
																			if (14 <= b)
																			{
																				goto IL_0804;
																			}
																			goto IL_0820;
																			IL_0804:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_035d;
																			IL_0820:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_082e;
																			IL_082e:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_083c;
																			IL_083c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_089e;
																			IL_089e:
																			num5 -= 2;
																			goto end_IL_035d;
																		}
																		break;
																		IL_034a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_035d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 2;
												goto IL_097c;
												IL_097c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d7:
												break;
											}
											continue;
											end_IL_08ea:
											break;
										}
										continue;
										end_IL_08f4:
										break;
									}
									continue;
									end_IL_08ff:
									break;
								}
								continue;
								end_IL_090f:
								break;
							}
							continue;
							end_IL_0928:
							break;
						}
						continue;
						end_IL_0938:
						break;
					}
					continue;
					end_IL_0948:
					break;
				}
				continue;
				end_IL_0958:
				break;
			}
		}
	}

	private static double IllogicalCallContextMiddayAtPersianObservationSite(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static Vector3 setFilterLevelEvidenceObject(Vector3 vector3_0, float float_0)
	{
		return vector3_0 * float_0;
	}

	public Class183()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static GorillaTagger EventResetModegetConstructionException()
	{
		return GorillaTagger.Instance;
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setSecurityInfrastructureRemoveRange.EventPayloadAssemblyReferenceDependentAssemblyDescription);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 48;
															while (true)
															{
																IL_0285:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0268:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_025b:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (8 <= b)
																							{
																								while (true)
																								{
																									IL_01de:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 111;
																									while (true)
																									{
																										if (num != 111)
																										{
																											if (num != 1092)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 31:
																											case 56:
																												goto IL_01de;
																											case 104:
																												goto IL_024b;
																											case 20:
																												goto IL_025b;
																											case 84:
																												goto IL_0268;
																											case 50:
																												goto IL_0275;
																											case 48:
																												goto IL_0285;
																											case 82:
																												goto end_IL_0285;
																											case 12:
																											case 44:
																												goto end_IL_0295;
																											case 17:
																												goto IL_02b9;
																											case 36:
																												goto IL_02c6;
																											case 27:
																												goto IL_02d1;
																											case 14:
																											case 49:
																												goto IL_02f2;
																											case 58:
																											case 64:
																												goto IL_0305;
																											case 47:
																											case 57:
																												goto IL_0310;
																											case 38:
																												goto IL_0323;
																											case 11:
																											case 35:
																												goto IL_032e;
																											case 59:
																												goto IL_0357;
																											case 28:
																												goto IL_0367;
																											case 30:
																												goto IL_0375;
																											case 32:
																											case 45:
																												goto IL_0383;
																											case 3:
																												goto IL_039c;
																											case 39:
																												goto IL_03aa;
																											case 6:
																												goto IL_03b8;
																											case 69:
																												goto IL_03cb;
																											case 9:
																											case 73:
																												goto IL_03de;
																											case 76:
																												goto IL_03fa;
																											case 1:
																											case 2:
																												goto IL_0408;
																											case 85:
																												goto IL_0420;
																											case 68:
																												goto IL_0443;
																											case 5:
																												goto IL_044d;
																											case 60:
																											case 88:
																												goto IL_045d;
																											case 89:
																												goto IL_046b;
																											case 90:
																												goto IL_047e;
																											case 77:
																											case 95:
																												goto IL_0491;
																											case 92:
																												goto IL_049c;
																											case 26:
																												goto IL_04d0;
																											case 96:
																											case 98:
																												goto IL_04db;
																											case 19:
																												goto IL_04f2;
																											case 22:
																											case 66:
																												goto IL_0500;
																											case 87:
																												goto IL_0523;
																											case 79:
																												goto IL_0531;
																											case 8:
																												goto IL_053f;
																											case 101:
																												goto IL_0552;
																											case 21:
																											case 97:
																												goto IL_055d;
																											case 93:
																												goto IL_05a6;
																											case 29:
																												goto IL_05ba;
																											case 0:
																											case 7:
																											case 15:
																											case 16:
																											case 23:
																											case 24:
																											case 25:
																											case 34:
																											case 37:
																											case 43:
																											case 46:
																											case 51:
																											case 52:
																											case 67:
																											case 71:
																											case 74:
																											case 80:
																											case 81:
																											case 94:
																												goto end_IL_01cb;
																											case 13:
																											case 18:
																											case 33:
																											case 41:
																											case 42:
																											case 55:
																											case 65:
																											case 70:
																											case 75:
																											case 78:
																											case 86:
																											case 100:
																											case 102:
																												goto end_IL_02ae;
																											case 63:
																												goto end_IL_05dd;
																											case 99:
																												goto end_IL_05f0;
																											case 72:
																												goto end_IL_05fa;
																											case 91:
																												goto end_IL_0605;
																											case 10:
																											case 83:
																												goto end_IL_061a;
																											case 53:
																												goto end_IL_062a;
																											case 40:
																											case 103:
																												goto end_IL_063a;
																											case 61:
																												goto end_IL_064a;
																											case 62:
																												goto end_IL_065a;
																											case 4:
																											case 54:
																												goto IL_0675;
																											}
																											continue;
																										}
																										num5 -= 2;
																										goto end_IL_02ae;
																										continue;
																										end_IL_01cb:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_04d0;
																							IL_05a6:
																							array[num5 - 2] = 0;
																							goto IL_05ba;
																							IL_04d0:
																							if (6 < b)
																							{
																								goto IL_04db;
																							}
																							goto IL_0552;
																							IL_04db:
																							if (7 < b)
																							{
																								break;
																							}
																							num = 19;
																							goto IL_04f2;
																							IL_05ba:
																							num5--;
																							goto end_IL_02ae;
																							IL_04f2:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0500;
																							IL_0500:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0523;
																							IL_0523:
																							array[num5] = 0;
																							goto IL_0531;
																							IL_0531:
																							num5++;
																							goto IL_053f;
																							IL_053f:
																							ptr2 += 8;
																							goto end_IL_02ae;
																							IL_0552:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_055d;
																							IL_055d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 93;
																							goto IL_05a6;
																						}
																						break;
																					}
																					goto IL_02c6;
																					IL_0491:
																					if (10 < b)
																					{
																						num = 37;
																						break;
																					}
																					goto IL_049c;
																					IL_02c6:
																					if (9 >= b)
																					{
																						goto IL_02d1;
																					}
																					num = 95;
																					goto IL_0491;
																					IL_02d1:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_03de;
																					IL_03de:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02ae;
																					IL_049c:
																					if (10 > b)
																					{
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_02b9;
																			IL_047e:
																			ptr2 += 8;
																			goto end_IL_02ae;
																			IL_02b9:
																			if (5 <= b)
																			{
																				goto IL_02f2;
																			}
																			goto IL_0305;
																			IL_0305:
																			if (2 < b)
																			{
																				goto IL_0310;
																			}
																			goto IL_0323;
																			IL_0310:
																			if (3 >= b)
																			{
																				goto IL_03fa;
																			}
																			goto IL_045d;
																			IL_045d:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_046b;
																			IL_046b:
																			if (4 <= b)
																			{
																				goto end_IL_02ae;
																			}
																			break;
																			IL_03fa:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0408;
																			IL_0408:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02ae;
																			IL_0323:
																			if (2 <= b)
																			{
																				goto IL_032e;
																			}
																			goto IL_0367;
																			IL_032e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0357;
																			IL_0357:
																			ptr2 += 8;
																			goto IL_03cb;
																			IL_03cb:
																			num5--;
																			goto end_IL_02ae;
																			IL_0367:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0375;
																			IL_0375:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0383;
																			IL_0383:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_039c;
																			IL_039c:
																			array[num5] = 0;
																			goto IL_03aa;
																			IL_03aa:
																			num5++;
																			goto IL_03b8;
																			IL_03b8:
																			ptr2 += 8;
																			goto end_IL_02ae;
																			IL_02f2:
																			array[num5] = 0;
																			goto IL_0420;
																			IL_0420:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0443;
																			IL_0443:
																			array2[num5] = null;
																			goto IL_044d;
																			IL_044d:
																			num5++;
																			goto IL_047e;
																		}
																		break;
																		IL_0275:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ae;
																continue;
																end_IL_0285:
																break;
															}
															continue;
															end_IL_0295:
															break;
														}
														continue;
														end_IL_02ae:
														break;
													}
													continue;
												}
												goto IL_0675;
												IL_0675:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05dd:
												break;
											}
											continue;
											end_IL_05f0:
											break;
										}
										continue;
										end_IL_05fa:
										break;
									}
									continue;
									end_IL_0605:
									break;
								}
								continue;
								end_IL_061a:
								break;
							}
							continue;
							end_IL_062a:
							break;
						}
						continue;
						end_IL_063a:
						break;
					}
					continue;
					end_IL_064a:
					break;
				}
				continue;
				end_IL_065a:
				break;
			}
		}
	}

	private static Vector3 EvidenceUpgradeLockHolderEVENTINFOCLASS()
	{
		return global::_003CModule_003E.vector3_133;
	}

	private static Vector3 getDeclaredPropertiesASMNAME()
	{
		return Vector3.down;
	}

	private static int DeserializationEventHandlerFindTokenByIndex(string[] string_0)
	{
		return LayerMask.GetMask(string_0);
	}

	private static void GuestIncrement(Transform transform_0, Vector3 vector3_0)
	{
		transform_0.position = vector3_0;
	}

	private unsafe static int smethod_9(int int_2)
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 12;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										num = 76;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getObjectAceTypeCommonPrograms.STORECATEGORYGetBaseException);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 77;
															while (true)
															{
																ptr2++;
																num = 2;
																while (true)
																{
																	IL_0274:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0254:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0247:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0237:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0227:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												num = 121;
																												while (true)
																												{
																													if (num != 121)
																													{
																														if (num != 1102)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 9:
																														case 101:
																															goto IL_0214;
																														case 6:
																														case 45:
																															goto IL_0227;
																														case 84:
																															goto IL_0237;
																														case 51:
																														case 81:
																															goto IL_0247;
																														case 42:
																															goto IL_0254;
																														case 34:
																															goto IL_0264;
																														case 2:
																															goto IL_0274;
																														case 77:
																															goto end_IL_0274;
																														case 43:
																														case 105:
																															goto end_IL_0284;
																														case 80:
																															goto IL_02b1;
																														case 49:
																															goto IL_02bc;
																														case 21:
																														case 85:
																															goto IL_02ca;
																														case 106:
																															goto IL_02e6;
																														case 52:
																															goto IL_02f4;
																														case 7:
																														case 33:
																															goto IL_0315;
																														case 67:
																															goto IL_0341;
																														case 71:
																															goto IL_034f;
																														case 103:
																															goto IL_0366;
																														case 36:
																															goto IL_0379;
																														case 18:
																														case 73:
																															goto IL_0387;
																														case 72:
																															goto IL_03c7;
																														case 20:
																															goto IL_03db;
																														case 88:
																														case 91:
																															goto IL_03ee;
																														case 111:
																															goto IL_0450;
																														case 1:
																															goto IL_0463;
																														case 3:
																														case 93:
																															goto IL_046e;
																														case 5:
																															goto IL_04b7;
																														case 24:
																															goto IL_04cb;
																														case 114:
																															goto IL_04de;
																														case 19:
																															goto IL_04ec;
																														case 8:
																														case 57:
																															goto IL_04fa;
																														case 54:
																														case 64:
																															goto IL_0505;
																														case 83:
																															goto IL_0513;
																														case 17:
																														case 86:
																															goto IL_0521;
																														case 11:
																															goto IL_054a;
																														case 47:
																															goto end_IL_0201;
																														case 55:
																															goto IL_056b;
																														case 13:
																														case 58:
																															goto IL_0579;
																														case 35:
																															goto IL_0592;
																														case 28:
																															goto IL_05a0;
																														case 63:
																															goto IL_05ae;
																														case 25:
																														case 31:
																															goto IL_05c1;
																														case 87:
																															goto IL_05e2;
																														case 102:
																															goto IL_05ed;
																														case 16:
																														case 104:
																															goto IL_05fd;
																														case 15:
																															goto IL_0608;
																														case 22:
																														case 30:
																														case 37:
																														case 39:
																														case 40:
																														case 46:
																														case 48:
																														case 53:
																														case 56:
																														case 66:
																														case 70:
																														case 74:
																														case 75:
																														case 89:
																														case 90:
																														case 94:
																														case 95:
																														case 96:
																														case 97:
																														case 112:
																														case 113:
																															goto end_IL_0214;
																														case 0:
																														case 78:
																															goto IL_0628;
																														case 27:
																															goto IL_0636;
																														case 61:
																															goto IL_0659;
																														case 110:
																															goto IL_0663;
																														case 107:
																															goto IL_0671;
																														case 10:
																														case 14:
																														case 41:
																														case 50:
																														case 59:
																														case 62:
																														case 65:
																														case 68:
																														case 69:
																														case 79:
																														case 82:
																														case 92:
																														case 100:
																														case 108:
																															goto end_IL_029d;
																														case 4:
																															goto end_IL_067f;
																														case 76:
																															goto end_IL_0692;
																														case 60:
																															goto end_IL_069c;
																														case 32:
																															goto end_IL_06a7;
																														case 38:
																														case 109:
																															goto end_IL_06c5;
																														case 29:
																															goto end_IL_06d5;
																														case 12:
																															goto end_IL_06e5;
																														case 44:
																															goto end_IL_06f5;
																														case 98:
																															goto end_IL_0705;
																														case 99:
																															goto end_IL_0710;
																														case 23:
																														case 26:
																															goto IL_072b;
																														}
																														continue;
																													}
																													if (8 > b)
																													{
																														goto end_IL_0214;
																													}
																													goto IL_0315;
																													IL_0341:
																													array[num5] = 0;
																													goto IL_034f;
																													IL_0366:
																													ptr2 += 8;
																													goto end_IL_029d;
																													IL_034f:
																													num5++;
																													num = 103;
																													goto IL_0366;
																													IL_0315:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 67;
																													goto IL_0341;
																													continue;
																													end_IL_0201:
																													break;
																												}
																												goto IL_0558;
																												continue;
																												end_IL_0214:
																												break;
																												IL_0214:;
																											}
																											break;
																										}
																										goto IL_0379;
																										IL_03db:
																										num5--;
																										goto end_IL_029d;
																										IL_0379:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0387;
																										IL_0387:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03c7;
																										IL_03c7:
																										array[num5 - 2] = 0;
																										goto IL_03db;
																									}
																									break;
																								}
																								goto IL_03ee;
																								IL_0450:
																								num5 -= 2;
																								goto end_IL_029d;
																								IL_03ee:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0450;
																							}
																							break;
																						}
																						goto IL_02b1;
																						IL_02f4:
																						if (11 > b)
																						{
																						}
																						break;
																						IL_02b1:
																						if (10 >= b)
																						{
																							goto IL_02bc;
																						}
																						goto IL_02e6;
																						IL_02bc:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_02ca;
																						IL_02ca:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_029d;
																						IL_02e6:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_02f4;
																					}
																					break;
																				}
																				goto IL_0463;
																				IL_0671:
																				ptr2 += 8;
																				goto end_IL_029d;
																				IL_0463:
																				if (6 <= b)
																				{
																					goto IL_046e;
																				}
																				goto IL_04de;
																				IL_046e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 5;
																				goto IL_04b7;
																				IL_04b7:
																				array[num5 - 2] = 0;
																				goto IL_04cb;
																				IL_04cb:
																				num5--;
																				goto end_IL_029d;
																				IL_04de:
																				if (3 >= b)
																				{
																					goto IL_04ec;
																				}
																				goto IL_05e2;
																				IL_04ec:
																				if (3 > b)
																				{
																					goto IL_04fa;
																				}
																				goto IL_05c1;
																				IL_04fa:
																				if (1 < b)
																				{
																					goto IL_0505;
																				}
																				goto IL_056b;
																				IL_0505:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0513;
																				IL_0513:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0521;
																				IL_0521:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_054a;
																				IL_054a:
																				ptr2 += 8;
																				goto IL_0558;
																				IL_0558:
																				num5--;
																				goto end_IL_029d;
																				IL_056b:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0579;
																				IL_0579:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0592;
																				IL_0592:
																				array[num5] = 0;
																				goto IL_05a0;
																				IL_05a0:
																				num5++;
																				goto IL_05ae;
																				IL_05ae:
																				ptr2 += 8;
																				goto end_IL_029d;
																				IL_05c1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 65;
																				goto end_IL_029d;
																				IL_05e2:
																				if (4 >= b)
																				{
																					goto IL_05ed;
																				}
																				goto IL_05fd;
																				IL_05ed:
																				if (4 <= b)
																				{
																					goto end_IL_029d;
																				}
																				break;
																				IL_05fd:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0608;
																				IL_0608:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0628;
																				IL_0628:
																				array[num5] = 0;
																				goto IL_0636;
																				IL_0636:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0659;
																				IL_0659:
																				array2[num5] = null;
																				goto IL_0663;
																				IL_0663:
																				num5++;
																				goto IL_0671;
																			}
																			break;
																			IL_0264:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_029d;
																	continue;
																	end_IL_0274:
																	break;
																}
																continue;
																end_IL_0284:
																break;
															}
															continue;
															end_IL_029d:
															break;
														}
														continue;
													}
													goto IL_072b;
													IL_072b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_067f:
													break;
												}
												continue;
												end_IL_0692:
												break;
											}
											continue;
											end_IL_069c:
											break;
										}
										continue;
										end_IL_06a7:
										break;
									}
									continue;
									end_IL_06c5:
									break;
								}
								continue;
								end_IL_06d5:
								break;
							}
							continue;
							end_IL_06e5:
							break;
						}
						continue;
						end_IL_06f5:
						break;
					}
					continue;
					end_IL_0705:
					break;
				}
				continue;
				end_IL_0710:
				break;
			}
		}
	}

	private static Transform SecurityControlEvidencesetTreatControlCAsInput(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 FavoritesFormatException(ref Vector3 vector3_0)
	{
		return vector3_0.normalized;
	}

	private unsafe static int smethod_10()
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BodyNameIDENTITYATTRIBUTE.OemPlusTristate);
										num = 152;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_039b:
														byte b = *ptr2;
														while (true)
														{
															IL_038b:
															ptr2++;
															while (true)
															{
																IL_037b:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_035b:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_033b:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_032e:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_031e:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_02e3:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_02ca:
																														ptr2 += 8;
																														num = 170;
																														while (true)
																														{
																															if (num != 170)
																															{
																																if (num != 1151)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 153:
																																	goto IL_02ca;
																																case 145:
																																case 146:
																																	goto IL_02e3;
																																case 68:
																																	goto IL_030e;
																																case 160:
																																	goto IL_031e;
																																case 92:
																																	goto IL_032e;
																																case 55:
																																case 133:
																																	goto IL_033b;
																																case 136:
																																	goto IL_034b;
																																case 65:
																																	goto IL_035b;
																																case 110:
																																	goto IL_036b;
																																case 48:
																																	goto IL_037b;
																																case 53:
																																	goto IL_038b;
																																case 119:
																																case 151:
																																	goto IL_039b;
																																case 67:
																																	goto IL_03af;
																																case 72:
																																	goto IL_03bd;
																																case 83:
																																	goto IL_03d0;
																																case 19:
																																case 39:
																																	goto IL_03e6;
																																case 18:
																																case 124:
																																	goto IL_0409;
																																case 85:
																																case 101:
																																	goto IL_0414;
																																case 47:
																																	goto IL_042b;
																																case 41:
																																case 60:
																																	goto IL_0439;
																																case 112:
																																	goto IL_046b;
																																case 111:
																																	goto IL_0484;
																																case 63:
																																case 78:
																																	goto IL_0492;
																																case 50:
																																	goto IL_04db;
																																case 26:
																																case 132:
																																	goto IL_04f4;
																																case 126:
																																	goto IL_050b;
																																case 52:
																																case 80:
																																	goto IL_0522;
																																case 76:
																																case 141:
																																	goto IL_053a;
																																case 11:
																																	goto IL_0548;
																																case 142:
																																	goto IL_055b;
																																case 107:
																																	goto IL_0572;
																																case 148:
																																	goto IL_058e;
																																case 155:
																																	goto IL_05a1;
																																case 56:
																																case 103:
																																	goto IL_05af;
																																case 137:
																																	goto IL_05bd;
																																case 28:
																																	goto IL_05d5;
																																case 130:
																																	goto IL_05e3;
																																case 21:
																																case 157:
																																	goto IL_05f6;
																																case 94:
																																	goto IL_0635;
																																case 150:
																																case 159:
																																	goto IL_0648;
																																case 87:
																																	goto IL_0661;
																																case 16:
																																	goto IL_066f;
																																case 49:
																																	goto IL_0686;
																																case 113:
																																case 161:
																																	goto IL_0699;
																																case 57:
																																case 95:
																																	goto IL_06a7;
																																case 36:
																																	goto IL_06be;
																																case 97:
																																case 100:
																																	goto IL_06c9;
																																case 45:
																																	goto IL_06dc;
																																case 99:
																																	goto IL_06ea;
																																case 31:
																																case 96:
																																	goto IL_06f8;
																																case 82:
																																	goto IL_070c;
																																case 115:
																																	goto IL_0760;
																																case 135:
																																	goto IL_076e;
																																case 138:
																																	goto IL_0781;
																																case 89:
																																	goto end_IL_02b7;
																																case 59:
																																case 84:
																																	goto IL_07a5;
																																case 61:
																																	goto IL_07ca;
																																case 102:
																																	goto IL_07d8;
																																case 58:
																																	goto IL_07eb;
																																case 77:
																																case 147:
																																	goto IL_07f9;
																																case 104:
																																	goto IL_0807;
																																case 30:
																																case 43:
																																	goto IL_0812;
																																case 4:
																																	goto IL_0820;
																																case 35:
																																case 123:
																																	goto IL_082e;
																																case 131:
																																	goto IL_083c;
																																case 40:
																																	goto IL_085f;
																																case 106:
																																	goto IL_0869;
																																case 108:
																																	goto IL_0877;
																																case 13:
																																case 32:
																																	goto IL_088a;
																																case 9:
																																	goto IL_08ce;
																																case 93:
																																	goto IL_08e2;
																																case 122:
																																	goto IL_08f5;
																																case 69:
																																	goto IL_0903;
																																case 20:
																																case 27:
																																	goto IL_0911;
																																case 3:
																																	goto IL_0951;
																																case 90:
																																	goto IL_0965;
																																case 2:
																																case 70:
																																	goto IL_0978;
																																case 6:
																																	goto IL_09da;
																																case 5:
																																case 10:
																																case 12:
																																case 22:
																																case 24:
																																case 25:
																																case 33:
																																case 42:
																																case 51:
																																case 54:
																																case 64:
																																case 71:
																																case 73:
																																case 79:
																																case 88:
																																case 91:
																																case 105:
																																case 109:
																																case 118:
																																case 120:
																																case 121:
																																case 125:
																																case 139:
																																case 143:
																																case 154:
																																case 156:
																																case 158:
																																case 163:
																																	goto end_IL_030e;
																																case 0:
																																case 14:
																																case 15:
																																case 17:
																																case 23:
																																case 29:
																																case 34:
																																case 44:
																																case 46:
																																case 66:
																																case 81:
																																case 98:
																																case 114:
																																case 117:
																																case 127:
																																case 129:
																																case 134:
																																case 144:
																																case 149:
																																case 162:
																																	goto end_IL_034b;
																																case 152:
																																	goto end_IL_0a0d;
																																case 62:
																																	goto end_IL_0a20;
																																case 128:
																																	goto end_IL_0a2a;
																																case 116:
																																	goto end_IL_0a3e;
																																case 1:
																																case 37:
																																	goto end_IL_0a4e;
																																case 140:
																																	goto end_IL_0a5e;
																																case 38:
																																case 74:
																																	goto end_IL_0a6e;
																																case 7:
																																	goto end_IL_0a7e;
																																case 8:
																																	goto end_IL_0a8e;
																																case 75:
																																case 86:
																																	goto IL_0aa9;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_034b;
																															continue;
																															end_IL_02b7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_078c;
																												continue;
																												end_IL_030e:
																												break;
																												IL_030e:;
																											}
																											break;
																										}
																										goto IL_04f4;
																										IL_050b:
																										if (8 > b)
																										{
																											break;
																										}
																										num = 52;
																										goto IL_0522;
																										IL_04f4:
																										if (8 < b)
																										{
																											break;
																										}
																										num = 126;
																										goto IL_050b;
																										IL_0522:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_034b;
																									}
																									break;
																								}
																								num = 67;
																								goto IL_03af;
																								IL_05f6:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0635;
																								IL_0635:
																								num5 -= 3;
																								goto end_IL_034b;
																								IL_03af:
																								if (6 > b)
																								{
																									goto IL_03bd;
																								}
																								goto IL_05f6;
																								IL_03bd:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_05a1;
																								IL_05a1:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_05af;
																								IL_05af:
																								array[num5] = 5;
																								goto IL_05bd;
																								IL_05bd:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_05d5;
																								IL_05d5:
																								num5++;
																								goto IL_05e3;
																								IL_05e3:
																								ptr2 += 8;
																								goto end_IL_034b;
																							}
																							break;
																						}
																						goto IL_03d0;
																						IL_03e6:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_055b;
																						IL_03d0:
																						if (4 <= b)
																						{
																							goto IL_03e6;
																						}
																						num = 18;
																						goto IL_0409;
																						IL_055b:
																						ptr2 += 8;
																						num = 107;
																						goto IL_0572;
																						IL_0409:
																						if (2 < b)
																						{
																							goto IL_0414;
																						}
																						goto IL_0484;
																						IL_0414:
																						if (3 < b)
																						{
																							break;
																						}
																						num = 47;
																						goto IL_042b;
																						IL_0572:
																						num5--;
																						num = 14;
																						goto end_IL_034b;
																						IL_042b:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0439;
																						IL_0439:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						num = 112;
																						goto IL_046b;
																						IL_046b:
																						array[num5 - 1] = 5;
																						goto end_IL_034b;
																						IL_0484:
																						if (2 <= b)
																						{
																							goto IL_0492;
																						}
																						goto IL_053a;
																						IL_0492:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 50;
																						goto IL_04db;
																						IL_04db:
																						array[num5 - 2] = 0;
																						goto IL_058e;
																						IL_058e:
																						num5--;
																						goto end_IL_034b;
																						IL_053a:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0548;
																						IL_0548:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0648;
																						IL_0648:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0661;
																						IL_0661:
																						array[num5] = 0;
																						goto IL_066f;
																						IL_066f:
																						num5++;
																						num = 49;
																						goto IL_0686;
																						IL_0686:
																						ptr2 += 8;
																						goto end_IL_034b;
																					}
																					goto end_IL_036b;
																					continue;
																					end_IL_034b:
																					break;
																					IL_034b:;
																				}
																				break;
																			}
																			goto IL_0699;
																			IL_0965:
																			num5--;
																			break;
																			IL_0699:
																			if (13 < b)
																			{
																				goto IL_06a7;
																			}
																			goto IL_07eb;
																			IL_06a7:
																			if (15 >= b)
																			{
																				num = 36;
																				goto IL_06be;
																			}
																			goto IL_0781;
																			IL_0978:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_09da;
																			IL_06be:
																			if (15 <= b)
																			{
																				goto IL_06c9;
																			}
																			goto IL_06dc;
																			IL_06c9:
																			num5--;
																			break;
																			IL_06dc:
																			if (14 < b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_06ea;
																			IL_06ea:
																			if (14 > b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_06f8;
																			IL_06f8:
																			array[num5 - 2] = 0;
																			goto IL_070c;
																			IL_070c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)setInvocationListDefineLPArray[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0760;
																			IL_0760:
																			num5--;
																			goto IL_076e;
																			IL_076e:
																			ptr2 += 8;
																			break;
																			IL_0781:
																			if (16 >= b)
																			{
																				goto IL_078c;
																			}
																			goto IL_07ca;
																			IL_078c:
																			if (16 > b)
																			{
																				num = 25;
																				goto end_IL_036b;
																			}
																			goto IL_07a5;
																			IL_09da:
																			num5 -= 2;
																			break;
																			IL_07a5:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 29;
																			break;
																			IL_07ca:
																			if (17 < b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_07d8;
																			IL_07d8:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_036b;
																			IL_07eb:
																			if (13 > b)
																			{
																				goto IL_07f9;
																			}
																			goto IL_0978;
																			IL_07f9:
																			if (11 >= b)
																			{
																				goto IL_0807;
																			}
																			goto IL_08f5;
																			IL_0807:
																			if (11 > b)
																			{
																				goto IL_0812;
																			}
																			goto IL_088a;
																			IL_0812:
																			if (10 < b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_0820;
																			IL_0820:
																			if (10 > b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_082e;
																			IL_082e:
																			array[num5] = 0;
																			goto IL_083c;
																			IL_083c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_085f;
																			IL_085f:
																			array2[num5] = null;
																			goto IL_0869;
																			IL_0869:
																			num5++;
																			goto IL_0877;
																			IL_0877:
																			ptr2 += 8;
																			break;
																			IL_088a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_08ce;
																			IL_08ce:
																			array[num5 - 2] = 0;
																			goto IL_08e2;
																			IL_08e2:
																			num5--;
																			break;
																			IL_08f5:
																			if (12 < b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_0903;
																			IL_0903:
																			if (12 > b)
																			{
																				goto end_IL_036b;
																			}
																			goto IL_0911;
																			IL_0911:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0951;
																			IL_0951:
																			array[num5 - 2] = 0;
																			goto IL_0965;
																		}
																		goto end_IL_037b;
																		continue;
																		end_IL_036b:
																		break;
																		IL_036b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_037b:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0aa9;
												IL_0aa9:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0a0d:
												break;
											}
											continue;
											end_IL_0a20:
											break;
										}
										continue;
										end_IL_0a2a:
										break;
									}
									continue;
									end_IL_0a3e:
									break;
								}
								continue;
								end_IL_0a4e:
								break;
							}
							continue;
							end_IL_0a5e:
							break;
						}
						continue;
						end_IL_0a6e:
						break;
					}
					continue;
					end_IL_0a7e:
					break;
				}
				continue;
				end_IL_0a8e:
				break;
			}
		}
	}

	private static Transform VARFLAGFHIDDENArrayTypeInfo(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 CMSSECTIONIDCLRSURROGATESECTIONHashValueSize(Transform transform_0)
	{
		return transform_0.position;
	}

	static Class183()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 2:
							case 5:
							case 6:
								goto end_IL_003d;
							case 3:
								goto end_IL_004a;
							case 4:
								goto end_IL_005f;
							case 1:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}
}
