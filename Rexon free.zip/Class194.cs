using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("PSA Simulator", "Rig", "Play Space Abuse Simulator.", false, 7, ModType.const_0, false)]
internal class Class194 : MonoBehaviour
{
	private static float float_0;

	private static int int_0;

	private static bool bool_0;

	private static float float_1;

	private static bool bool_1;

	private static double double_0;

	private static IntPtr[] BaseBinaryObserved;

	private static IntPtr[] EnumSubcategoriesXmlAttribute;

	private static IntPtr[] DictionaryEnumeratorFreeNamedDataSlot;

	private unsafe static int smethod_0()
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 142;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRefTypeInfoDispIdAttribute.UseDigitPrefixInTokensgetHostSecurityManager);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 76;
															while (true)
															{
																if (b >= 1)
																{
																	num = 25;
																	while (true)
																	{
																		if (b <= 15)
																		{
																			while (true)
																			{
																				if (8 >= b)
																				{
																					while (true)
																					{
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02dd:
																								if (4 < b)
																								{
																									goto IL_076c;
																								}
																								while (true)
																								{
																									IL_02cd:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_02a4:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											num = 157;
																											while (true)
																											{
																												if (num != 157)
																												{
																													if (num != 1138)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 53:
																													case 105:
																														goto IL_02a4;
																													case 148:
																														goto IL_02cd;
																													case 54:
																													case 116:
																														goto IL_02dd;
																													case 66:
																														goto end_IL_02dd;
																													case 125:
																														goto end_IL_02ed;
																													case 25:
																														goto end_IL_02fd;
																													case 76:
																														goto end_IL_030a;
																													case 50:
																														goto end_IL_031a;
																													case 83:
																													case 138:
																														goto end_IL_032d;
																													case 91:
																													case 131:
																														goto IL_0351;
																													case 45:
																														goto IL_035f;
																													case 123:
																														goto IL_036d;
																													case 7:
																														goto IL_037b;
																													case 13:
																														goto IL_0389;
																													case 6:
																													case 49:
																														goto IL_03a0;
																													case 38:
																													case 104:
																														goto IL_0407;
																													case 129:
																														goto IL_0415;
																													case 92:
																														goto IL_0428;
																													case 16:
																													case 120:
																														goto IL_0436;
																													case 94:
																														goto IL_0441;
																													case 97:
																														goto IL_044f;
																													case 24:
																													case 79:
																														goto IL_045d;
																													case 15:
																														goto IL_04a1;
																													case 61:
																														goto IL_04c3;
																													case 34:
																													case 118:
																														goto IL_04d1;
																													case 96:
																														goto IL_04df;
																													case 111:
																														goto IL_0502;
																													case 2:
																														goto IL_050c;
																													case 93:
																														goto IL_051a;
																													case 12:
																													case 17:
																														goto IL_0536;
																													case 78:
																														goto IL_0576;
																													case 57:
																													case 133:
																														goto IL_058f;
																													case 29:
																														goto IL_059d;
																													case 42:
																													case 135:
																														goto IL_05b0;
																													case 112:
																													case 134:
																														goto IL_05bb;
																													case 68:
																														goto IL_05c9;
																													case 31:
																													case 65:
																														goto IL_05d7;
																													case 87:
																														goto IL_0600;
																													case 86:
																														goto IL_0619;
																													case 82:
																													case 89:
																														goto IL_0624;
																													case 20:
																														goto IL_0664;
																													case 4:
																														goto IL_067d;
																													case 136:
																														goto IL_068d;
																													case 140:
																														goto IL_06a0;
																													case 141:
																														goto IL_06b3;
																													case 81:
																													case 143:
																														goto IL_06c6;
																													case 144:
																														goto IL_06e2;
																													case 77:
																													case 98:
																														goto IL_06f0;
																													case 130:
																														goto IL_0709;
																													case 55:
																														goto IL_0717;
																													case 5:
																														goto IL_0725;
																													case 150:
																														goto IL_0738;
																													case 80:
																														goto IL_0759;
																													case 114:
																														goto IL_076c;
																													case 36:
																													case 109:
																														goto IL_0777;
																													case 27:
																														goto IL_0785;
																													case 8:
																													case 59:
																														goto IL_0793;
																													case 40:
																														goto end_IL_0291;
																													case 28:
																														goto IL_07ca;
																													case 73:
																														goto IL_07dd;
																													case 33:
																													case 70:
																														goto IL_07e8;
																													case 95:
																														goto IL_0827;
																													case 88:
																													case 126:
																														goto IL_083a;
																													case 72:
																														goto IL_0845;
																													case 75:
																													case 115:
																														goto IL_0859;
																													case 110:
																														goto IL_0870;
																													case 132:
																														goto IL_0888;
																													case 124:
																														goto IL_0896;
																													case 0:
																													case 74:
																														goto IL_08a6;
																													case 1:
																													case 9:
																													case 10:
																													case 21:
																													case 22:
																													case 23:
																													case 26:
																													case 35:
																													case 39:
																													case 41:
																													case 44:
																													case 48:
																													case 56:
																													case 58:
																													case 62:
																													case 63:
																													case 69:
																													case 84:
																													case 85:
																													case 99:
																													case 100:
																													case 106:
																													case 113:
																													case 117:
																													case 127:
																													case 139:
																													case 146:
																													case 147:
																														goto IL_08c4;
																													case 3:
																													case 11:
																													case 14:
																													case 19:
																													case 30:
																													case 37:
																													case 47:
																													case 60:
																													case 64:
																													case 67:
																													case 71:
																													case 103:
																													case 107:
																													case 119:
																													case 121:
																													case 122:
																													case 128:
																													case 137:
																														goto end_IL_0346;
																													case 90:
																														goto end_IL_08d7;
																													case 142:
																														goto end_IL_08ea;
																													case 32:
																														goto end_IL_08f4;
																													case 149:
																														goto end_IL_08ff;
																													case 18:
																													case 43:
																														goto end_IL_0918;
																													case 108:
																														goto end_IL_0928;
																													case 101:
																													case 145:
																														goto end_IL_0938;
																													case 51:
																														goto end_IL_0948;
																													case 52:
																														goto end_IL_0958;
																													case 46:
																													case 102:
																														goto IL_0973;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto IL_0759;
																												IL_0759:
																												num5--;
																												goto end_IL_0346;
																												continue;
																												end_IL_0291:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_05b0;
																									IL_0725:
																									ptr2 += 8;
																									goto end_IL_0346;
																									IL_05b0:
																									if (2 < b)
																									{
																										goto IL_05bb;
																									}
																									goto IL_0619;
																									IL_05bb:
																									if (3 >= b)
																									{
																										goto IL_05c9;
																									}
																									goto IL_08c4;
																									IL_05c9:
																									if (3 <= b)
																									{
																										goto IL_05d7;
																									}
																									goto IL_08c4;
																									IL_05d7:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0600;
																									IL_0600:
																									array[num5 - 1] = 5;
																									goto end_IL_0346;
																									IL_0619:
																									if (2 <= b)
																									{
																										goto IL_0624;
																									}
																									goto IL_067d;
																									IL_0624:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0664;
																									IL_0664:
																									array[num5 - 2] = 0;
																									goto IL_0738;
																									IL_0738:
																									num5--;
																									goto end_IL_0346;
																									IL_067d:
																									if (1 >= b)
																									{
																										goto IL_06e2;
																									}
																									goto IL_08c4;
																									IL_06e2:
																									if (1 <= b)
																									{
																										goto IL_06f0;
																									}
																									goto IL_08c4;
																									IL_06f0:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0709;
																									IL_0709:
																									array[num5] = 0;
																									goto IL_0717;
																									IL_0717:
																									num5++;
																									goto IL_0725;
																								}
																								goto IL_07bc;
																								IL_0888:
																								num5++;
																								goto IL_0896;
																								IL_076c:
																								if (6 < b)
																								{
																									goto IL_0777;
																								}
																								goto IL_07dd;
																								IL_0777:
																								if (7 >= b)
																								{
																									goto IL_0785;
																								}
																								goto IL_08c4;
																								IL_0785:
																								if (7 <= b)
																								{
																									goto IL_0793;
																								}
																								goto IL_08c4;
																								IL_0793:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07bc;
																								IL_07bc:
																								ptr2 += 8;
																								goto IL_07ca;
																								IL_07ca:
																								num5--;
																								goto end_IL_0346;
																								IL_07dd:
																								if (6 <= b)
																								{
																									goto IL_07e8;
																								}
																								goto IL_083a;
																								IL_07e8:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0827;
																								IL_0827:
																								num5 -= 3;
																								goto end_IL_0346;
																								IL_083a:
																								if (5 >= b)
																								{
																									goto IL_0845;
																								}
																								goto IL_08c4;
																								IL_0845:
																								if (5 <= b)
																								{
																									num = 75;
																									goto IL_0859;
																								}
																								goto IL_08c4;
																								IL_0896:
																								ptr2 += 8;
																								goto end_IL_0346;
																								IL_0859:
																								array[num5] = 5;
																								num = 110;
																								goto IL_0870;
																								IL_0870:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0888;
																								continue;
																								end_IL_02dd:
																								break;
																							}
																							continue;
																						}
																						goto IL_08a6;
																						IL_08a6:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0346;
																						continue;
																						end_IL_02ed:
																						break;
																					}
																					continue;
																				}
																				goto IL_0351;
																				IL_0536:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0576;
																				IL_0351:
																				if (12 < b)
																				{
																					goto IL_035f;
																				}
																				goto IL_0428;
																				IL_035f:
																				if (14 >= b)
																				{
																					goto IL_036d;
																				}
																				goto IL_0407;
																				IL_036d:
																				if (14 > b)
																				{
																					goto IL_037b;
																				}
																				goto IL_06c6;
																				IL_037b:
																				if (13 >= b)
																				{
																					goto IL_0389;
																				}
																				goto IL_08c4;
																				IL_0389:
																				if (13 <= b)
																				{
																					num = 6;
																					goto IL_03a0;
																				}
																				goto IL_08c4;
																				IL_0576:
																				array[num5 - 2] = 0;
																				goto IL_06a0;
																				IL_03a0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_068d;
																				IL_068d:
																				num5 -= 2;
																				goto end_IL_0346;
																				IL_06c6:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0346;
																				IL_0407:
																				if (15 >= b)
																				{
																					goto IL_0415;
																				}
																				goto IL_08c4;
																				IL_0415:
																				if (15 <= b)
																				{
																				}
																				goto IL_08c4;
																				IL_0428:
																				if (12 > b)
																				{
																					goto IL_0436;
																				}
																				goto IL_0536;
																				IL_0436:
																				if (10 < b)
																				{
																					goto IL_0441;
																				}
																				num = 61;
																				goto IL_04c3;
																				IL_0441:
																				if (11 >= b)
																				{
																					goto IL_044f;
																				}
																				goto IL_08c4;
																				IL_044f:
																				if (11 <= b)
																				{
																					goto IL_045d;
																				}
																				goto IL_08c4;
																				IL_045d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_04a1;
																				IL_04a1:
																				array[num5 - 2] = 0;
																				goto IL_06b3;
																				IL_06b3:
																				num5--;
																				goto end_IL_0346;
																				IL_06a0:
																				num5--;
																				goto end_IL_0346;
																				IL_04c3:
																				if (10 <= b)
																				{
																					goto IL_04d1;
																				}
																				goto IL_058f;
																				IL_04d1:
																				array[num5] = 0;
																				goto IL_04df;
																				IL_04df:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0502;
																				IL_0502:
																				array2[num5] = null;
																				goto IL_050c;
																				IL_050c:
																				num5++;
																				goto IL_051a;
																				IL_051a:
																				ptr2 += 8;
																				num = 30;
																				goto end_IL_0346;
																				IL_058f:
																				if (9 >= b)
																				{
																					goto IL_059d;
																				}
																				goto IL_08c4;
																				IL_059d:
																				if (9 <= b)
																				{
																					goto end_IL_0346;
																				}
																				goto IL_08c4;
																				continue;
																				end_IL_02fd:
																				break;
																			}
																			continue;
																		}
																		num = 139;
																		goto IL_08c4;
																		continue;
																		end_IL_030a:
																		break;
																	}
																	continue;
																}
																goto IL_08c4;
																IL_08c4:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0346;
																continue;
																end_IL_031a:
																break;
															}
															continue;
															end_IL_032d:
															break;
														}
														continue;
														end_IL_0346:
														break;
													}
													continue;
												}
												goto IL_0973;
												IL_0973:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d7:
												break;
											}
											continue;
											end_IL_08ea:
											break;
										}
										continue;
										end_IL_08f4:
										break;
									}
									continue;
									end_IL_08ff:
									break;
								}
								continue;
								end_IL_0918:
								break;
							}
							continue;
							end_IL_0928:
							break;
						}
						continue;
						end_IL_0938:
						break;
					}
					continue;
					end_IL_0948:
					break;
				}
				continue;
				end_IL_0958:
				break;
			}
		}
	}

	private static double ActivatorXml(double double_1)
	{
		return Math.Round(double_1);
	}

	private static int smethod_1(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		int num3;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_1;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		num = num3;
		int num4 = smethod_4();
		num2 = num4;
		return num;
	}

	private static Vector3 SecurityUnmngdCodeAccessgetFullName(Rigidbody rigidbody_0)
	{
		return rigidbody_0.velocity;
	}

	private static bool BinaryCrossAppDomainStringConsoleApplication(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerSecondaryButton;
	}

	private static ControllerInputPoller FileSourcePathCOMServerHostFile()
	{
		return ControllerInputPoller.instance;
	}

	private static void getLCIDdwHighDateTime(ref Vector3 vector3_0, float float_2, float float_3, float float_4)
	{
		vector3_0 = new Vector3(float_2, float_3, float_4);
	}

	private static Vector3 DiscretionaryAclAutoInheritedPreserveSigAttribute(Rigidbody rigidbody_0)
	{
		return rigidbody_0.velocity;
	}

	private static double IReportMatchMembershipConditionClassInterfaceAttribute(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private void OnDisable()
	{
		UsersgetDeploymentFlags(this);
	}

	private unsafe void Update()
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					while (true)
					{
						IL_008d:
						if (num3 == 34)
						{
							num = 4;
							while (true)
							{
								IL_007f:
								num3 = 0;
								num = 14;
								while (true)
								{
									if (num != 14)
									{
										if (num != 995)
										{
											break;
										}
										switch (num)
										{
										case 7:
											break;
										default:
											continue;
										case 4:
											goto IL_007f;
										case 3:
										case 5:
											goto IL_008d;
										case 6:
											goto end_IL_0072;
										case 1:
											goto end_IL_0098;
										case 2:
											goto end_IL_009d;
										case 0:
											return;
										}
										goto IL_000e;
									}
									return;
									continue;
									end_IL_0072:
									break;
								}
								break;
							}
							break;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, void>)BaseBinaryObserved[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11);
					}
					continue;
					end_IL_0098:
					break;
				}
				continue;
				end_IL_009d:
				break;
			}
		}
	}

	private static Vector3 ActivateInstanceASCIIEncoding()
	{
		return global::_003CModule_003E.vector3_154;
	}

	private static Transform Firsttype(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 DateTimeFormatFlagsDequeue()
	{
		return global::_003CModule_003E.vector3_153;
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 58;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 67;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 70;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									num = 98;
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPositionPointergetMaxCharCount.ReliabilityContractAttributeDoubleToIntBits);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 20;
																while (true)
																{
																	IL_0288:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_026b:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_025b:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_024b:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0238:
																										if (2 > b)
																										{
																											num = 83;
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_01f4:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														num = 113;
																														while (true)
																														{
																															if (num != 113)
																															{
																																if (num != 1094)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 23:
																																case 105:
																																	goto IL_01f4;
																																case 11:
																																	goto IL_0218;
																																case 54:
																																case 83:
																																	goto IL_0228;
																																case 41:
																																	goto IL_0238;
																																case 42:
																																case 78:
																																	goto IL_024b;
																																case 106:
																																	goto IL_025b;
																																case 10:
																																	goto IL_026b;
																																case 96:
																																	goto IL_0278;
																																case 20:
																																	goto IL_0288;
																																case 87:
																																	goto end_IL_0288;
																																case 21:
																																case 80:
																																	goto end_IL_0298;
																																case 9:
																																case 48:
																																	goto IL_02bc;
																																case 18:
																																	goto IL_02ca;
																																case 32:
																																	goto IL_02d5;
																																case 4:
																																case 45:
																																	goto IL_02e3;
																																case 33:
																																case 59:
																																	goto IL_02f6;
																																case 12:
																																	goto IL_0358;
																																case 27:
																																case 66:
																																	goto IL_036b;
																																case 60:
																																	goto IL_0376;
																																case 65:
																																	goto IL_0384;
																																case 19:
																																case 73:
																																	goto IL_0397;
																																case 15:
																																	goto IL_03c0;
																																case 51:
																																	goto IL_03ce;
																																case 74:
																																	goto IL_03e1;
																																case 81:
																																	goto IL_03f1;
																																case 82:
																																	goto IL_0404;
																																case 28:
																																case 86:
																																	goto IL_0417;
																																case 76:
																																	goto IL_0425;
																																case 7:
																																case 88:
																																	goto IL_0438;
																																case 61:
																																	goto IL_0478;
																																case 75:
																																	goto IL_048c;
																																case 16:
																																case 91:
																																	goto IL_049f;
																																case 93:
																																	goto IL_04c2;
																																case 14:
																																case 94:
																																	goto end_IL_01e1;
																																case 97:
																																	goto IL_04ea;
																																case 100:
																																	goto IL_04f8;
																																case 40:
																																case 101:
																																	goto IL_050b;
																																case 102:
																																	goto IL_0527;
																																case 29:
																																	goto IL_0535;
																																case 17:
																																	goto IL_0556;
																																case 64:
																																	goto IL_0564;
																																case 56:
																																case 104:
																																	goto IL_0577;
																																case 72:
																																	goto IL_0585;
																																case 53:
																																	goto IL_05a8;
																																case 77:
																																	goto IL_05b2;
																																case 30:
																																	goto IL_05c9;
																																case 2:
																																case 5:
																																case 22:
																																case 24:
																																case 25:
																																case 31:
																																case 34:
																																case 36:
																																case 39:
																																case 43:
																																case 49:
																																case 50:
																																case 55:
																																case 63:
																																case 69:
																																case 84:
																																case 85:
																																case 92:
																																case 95:
																																case 99:
																																	goto end_IL_0218;
																																case 1:
																																case 6:
																																case 8:
																																case 37:
																																case 44:
																																case 46:
																																case 47:
																																case 52:
																																case 62:
																																case 71:
																																case 79:
																																case 89:
																																case 90:
																																	goto end_IL_02b1;
																																case 0:
																																	goto end_IL_05fe;
																																case 13:
																																	goto end_IL_0611;
																																case 98:
																																	goto end_IL_061b;
																																case 26:
																																	goto end_IL_0626;
																																case 70:
																																	goto end_IL_063b;
																																case 68:
																																	goto end_IL_0654;
																																case 67:
																																	goto end_IL_0664;
																																case 3:
																																case 103:
																																	goto end_IL_066f;
																																case 57:
																																	goto end_IL_067f;
																																case 58:
																																	goto end_IL_0698;
																																case 35:
																																case 38:
																																	goto IL_06b3;
																																}
																																continue;
																															}
																															array[num5] = 0;
																															goto IL_0556;
																															IL_0556:
																															num5++;
																															goto IL_0564;
																															IL_0564:
																															ptr2 += 8;
																															goto end_IL_02b1;
																															continue;
																															end_IL_01e1:
																															break;
																														}
																														break;
																													}
																													goto IL_04d2;
																													continue;
																													end_IL_0218:
																													break;
																													IL_0218:;
																												}
																												break;
																												IL_0228:;
																											}
																											break;
																										}
																										goto IL_0397;
																										IL_03c0:
																										ptr2 += 8;
																										goto IL_03ce;
																										IL_03ce:
																										num5--;
																										goto end_IL_02b1;
																										IL_0397:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03c0;
																									}
																									break;
																								}
																								goto IL_036b;
																								IL_04d2:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02b1;
																								IL_036b:
																								if (3 < b)
																								{
																									goto IL_0376;
																								}
																								goto IL_03f1;
																								IL_0376:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0384;
																								IL_0384:
																								if (4 <= b)
																								{
																									goto end_IL_02b1;
																								}
																								break;
																								IL_03f1:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_04d2;
																							}
																							break;
																						}
																						goto IL_0577;
																						IL_05c9:
																						ptr2 += 8;
																						num = 44;
																						goto end_IL_02b1;
																						IL_0577:
																						array[num5] = 0;
																						goto IL_0585;
																						IL_0585:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05a8;
																						IL_05a8:
																						array2[num5] = null;
																						goto IL_05b2;
																						IL_05b2:
																						num5++;
																						num = 30;
																						goto IL_05c9;
																					}
																					break;
																				}
																				goto IL_02bc;
																				IL_04f8:
																				if (10 <= b)
																				{
																				}
																				break;
																				IL_02bc:
																				if (8 >= b)
																				{
																					goto IL_02ca;
																				}
																				goto IL_0417;
																				IL_02ca:
																				if (8 > b)
																				{
																					goto IL_02d5;
																				}
																				goto IL_02f6;
																				IL_02d5:
																				if (6 < b)
																				{
																					goto IL_02e3;
																				}
																				goto IL_03e1;
																				IL_02e3:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0404;
																				IL_0404:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_049f;
																				IL_049f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04c2;
																				IL_04c2:
																				array[num5] = 0;
																				goto IL_0527;
																				IL_0527:
																				num5++;
																				goto IL_0535;
																				IL_0535:
																				ptr2 += 8;
																				goto end_IL_02b1;
																				IL_03e1:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0438;
																				IL_0438:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0478;
																				IL_0478:
																				array[num5 - 2] = 0;
																				goto IL_048c;
																				IL_048c:
																				num5--;
																				goto end_IL_02b1;
																				IL_02f6:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0358;
																				IL_0358:
																				num5 -= 2;
																				goto end_IL_02b1;
																				IL_0417:
																				if (9 >= b)
																				{
																					goto IL_0425;
																				}
																				goto IL_04ea;
																				IL_0425:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_050b;
																				IL_050b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b1;
																				IL_04ea:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_04f8;
																			}
																			break;
																			IL_0278:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 37;
																	goto end_IL_02b1;
																	continue;
																	end_IL_0288:
																	break;
																}
																continue;
																end_IL_0298:
																break;
															}
															continue;
															end_IL_02b1:
															break;
														}
														continue;
													}
													goto IL_06b3;
													IL_06b3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05fe:
													break;
												}
												continue;
												end_IL_0611:
												break;
											}
											continue;
											end_IL_061b:
											break;
										}
										continue;
										end_IL_0626:
										break;
									}
									continue;
									end_IL_063b:
									break;
								}
								continue;
								end_IL_0654:
								break;
							}
							continue;
							end_IL_0664:
							break;
						}
						continue;
						end_IL_066f:
						break;
					}
					continue;
					end_IL_067f:
					break;
				}
				continue;
				end_IL_0698:
				break;
			}
		}
	}

	private static float DispatchWrappergetActivator(Vector3 vector3_0)
	{
		return vector3_0.z;
	}

	private static double addCancelKeyPressRemoteShutdown(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static float SetApartmentStateCCPASCAL(Vector3 vector3_0)
	{
		return vector3_0.x;
	}

	private static GTPlayer ConfigEventsM()
	{
		return GTPlayer.Instance;
	}

	private unsafe static int smethod_4()
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 81;
						while (true)
						{
							int[] array3 = new int[2];
							num = 7;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SEPLocalTimeMarkgetMonitoringSurvivedMemorySize.PageUpGetActivationContextData);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 92;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 156;
															while (true)
															{
																if (num != 156)
																{
																	if (num != 1137)
																	{
																		goto IL_05ae;
																	}
																	switch (num)
																	{
																	case 77:
																		goto end_IL_027f;
																	case 4:
																	case 148:
																		goto end_IL_028f;
																	case 40:
																		goto IL_02c1;
																	case 69:
																		goto IL_02cf;
																	case 108:
																		goto IL_02dd;
																	case 11:
																	case 64:
																		goto IL_02eb;
																	case 123:
																		goto IL_02f9;
																	case 86:
																		goto IL_0307;
																	case 56:
																		goto IL_0315;
																	case 74:
																	case 87:
																		goto IL_0323;
																	case 88:
																		goto IL_0385;
																	case 16:
																	case 120:
																		goto IL_0398;
																	case 105:
																	case 109:
																		goto IL_03b4;
																	case 68:
																		goto IL_03c2;
																	case 29:
																		goto IL_03d5;
																	case 0:
																	case 52:
																		goto IL_03e0;
																	case 127:
																		goto IL_0420;
																	case 50:
																		goto IL_0434;
																	case 130:
																		goto IL_0447;
																	case 32:
																		goto IL_0455;
																	case 30:
																	case 83:
																		goto IL_0460;
																	case 119:
																		goto IL_046e;
																	case 44:
																	case 55:
																		goto IL_0481;
																	case 72:
																		goto IL_048f;
																	case 128:
																		goto IL_04b2;
																	case 82:
																		goto IL_04bc;
																	case 117:
																		goto IL_04ca;
																	case 135:
																		goto IL_04dd;
																	case 8:
																		goto IL_04eb;
																	case 98:
																	case 132:
																		goto IL_04f9;
																	case 12:
																		goto IL_053d;
																	case 13:
																		goto IL_0551;
																	case 118:
																		goto IL_0564;
																	case 53:
																	case 129:
																		goto IL_056f;
																	case 141:
																		goto IL_0587;
																	case 9:
																	case 39:
																		goto IL_0595;
																	case 84:
																		goto IL_05a3;
																	case 1:
																	case 51:
																		goto IL_05ae;
																	case 65:
																		goto IL_05bc;
																	case 41:
																	case 126:
																		goto IL_05ca;
																	case 93:
																		goto IL_05d8;
																	case 136:
																		goto IL_05f0;
																	case 2:
																		goto IL_0607;
																	case 14:
																	case 42:
																		goto IL_061a;
																	case 139:
																		goto IL_0659;
																	case 28:
																		goto IL_066c;
																	case 107:
																		goto IL_067a;
																	case 33:
																	case 89:
																		goto IL_0688;
																	case 35:
																		goto IL_06ba;
																	case 10:
																		goto IL_06d1;
																	case 49:
																		goto IL_06e4;
																	case 24:
																	case 137:
																		goto IL_06ef;
																	case 71:
																		goto IL_070d;
																	case 95:
																		goto IL_071b;
																	case 149:
																		goto IL_072e;
																	case 3:
																	case 36:
																		goto IL_0739;
																	case 66:
																		goto IL_0747;
																	case 75:
																	case 144:
																		goto IL_0755;
																	case 26:
																		goto IL_077e;
																	case 143:
																		goto IL_0797;
																	case 58:
																	case 94:
																		goto IL_07a2;
																	case 142:
																		goto IL_07e2;
																	case 57:
																		goto IL_07f6;
																	case 46:
																	case 134:
																		goto IL_0809;
																	case 59:
																		goto IL_0814;
																	case 112:
																	case 121:
																		goto IL_081f;
																	case 45:
																		goto IL_0841;
																	case 54:
																		goto IL_084f;
																	case 85:
																		goto IL_085d;
																	case 15:
																	case 23:
																	case 25:
																	case 27:
																	case 34:
																	case 38:
																	case 47:
																	case 48:
																	case 61:
																	case 63:
																	case 70:
																	case 76:
																	case 79:
																	case 97:
																	case 99:
																	case 100:
																	case 101:
																	case 102:
																	case 106:
																	case 111:
																	case 115:
																	case 116:
																	case 122:
																	case 124:
																	case 133:
																	case 138:
																	case 140:
																	case 145:
																	case 146:
																		goto IL_086d;
																	case 18:
																	case 20:
																	case 21:
																	case 22:
																	case 31:
																	case 62:
																	case 67:
																	case 73:
																	case 78:
																	case 90:
																	case 91:
																	case 92:
																	case 103:
																	case 110:
																	case 113:
																	case 114:
																	case 125:
																	case 131:
																		goto end_IL_02a8;
																	case 19:
																		goto end_IL_0889;
																	case 17:
																		goto end_IL_089c;
																	case 96:
																		goto end_IL_08af;
																	case 7:
																		goto end_IL_08ba;
																	case 80:
																	case 81:
																		goto end_IL_08ca;
																	case 104:
																		goto end_IL_08da;
																	case 43:
																	case 147:
																		goto end_IL_08f3;
																	case 5:
																		goto end_IL_090c;
																	case 6:
																		goto end_IL_091c;
																	case 37:
																	case 60:
																		goto IL_0937;
																	}
																	continue;
																}
																if (b >= 1)
																{
																	goto IL_02c1;
																}
																goto IL_086d;
																IL_084f:
																num5++;
																goto IL_085d;
																IL_086d:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 62;
																goto end_IL_02a8;
																IL_085d:
																ptr2 += 8;
																goto end_IL_02a8;
																IL_02c1:
																if (b <= 15)
																{
																	goto IL_02cf;
																}
																goto IL_086d;
																IL_02cf:
																if (8 < b)
																{
																	goto IL_02dd;
																}
																goto IL_0564;
																IL_02dd:
																if (12 < b)
																{
																	goto IL_02eb;
																}
																goto IL_03d5;
																IL_02eb:
																if (14 >= b)
																{
																	goto IL_02f9;
																}
																goto IL_03b4;
																IL_02f9:
																if (14 > b)
																{
																	goto IL_0307;
																}
																goto IL_0398;
																IL_0307:
																if (13 >= b)
																{
																	goto IL_0315;
																}
																goto IL_086d;
																IL_0315:
																if (13 <= b)
																{
																	goto IL_0323;
																}
																goto IL_086d;
																IL_0323:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0385;
																IL_0385:
																num5 -= 2;
																goto end_IL_02a8;
																IL_0398:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_02a8;
																IL_03b4:
																if (15 >= b)
																{
																	goto IL_03c2;
																}
																goto IL_086d;
																IL_03c2:
																if (15 <= b)
																{
																}
																goto IL_086d;
																IL_03d5:
																if (12 <= b)
																{
																	goto IL_03e0;
																}
																goto IL_0447;
																IL_03e0:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0420;
																IL_0420:
																array[num5 - 2] = 0;
																goto IL_0434;
																IL_0434:
																num5--;
																goto end_IL_02a8;
																IL_0447:
																if (10 >= b)
																{
																	goto IL_0455;
																}
																goto IL_04dd;
																IL_0455:
																if (10 > b)
																{
																	goto IL_0460;
																}
																goto IL_0481;
																IL_0460:
																if (9 >= b)
																{
																	goto IL_046e;
																}
																goto IL_086d;
																IL_046e:
																if (9 <= b)
																{
																	goto end_IL_02a8;
																}
																goto IL_086d;
																IL_0481:
																array[num5] = 0;
																goto IL_048f;
																IL_048f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04b2;
																IL_04b2:
																array2[num5] = null;
																goto IL_04bc;
																IL_04bc:
																num5++;
																goto IL_04ca;
																IL_04ca:
																ptr2 += 8;
																goto end_IL_02a8;
																IL_04dd:
																if (11 >= b)
																{
																	goto IL_04eb;
																}
																goto IL_086d;
																IL_04eb:
																if (11 <= b)
																{
																	goto IL_04f9;
																}
																goto IL_086d;
																IL_04f9:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_053d;
																IL_053d:
																array[num5 - 2] = 0;
																goto IL_0551;
																IL_0551:
																num5--;
																goto end_IL_02a8;
																IL_0564:
																if (8 <= b)
																{
																	goto IL_056f;
																}
																goto IL_0587;
																IL_056f:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a8;
																IL_0587:
																if (4 < b)
																{
																	goto IL_0595;
																}
																goto IL_06e4;
																IL_0595:
																if (6 >= b)
																{
																	goto IL_05a3;
																}
																goto IL_066c;
																IL_05a3:
																if (6 > b)
																{
																	goto IL_05ae;
																}
																goto IL_061a;
																IL_05ae:
																if (5 >= b)
																{
																	goto IL_05bc;
																}
																goto IL_086d;
																IL_05bc:
																if (5 <= b)
																{
																	goto IL_05ca;
																}
																goto IL_086d;
																IL_05ca:
																array[num5] = 5;
																goto IL_05d8;
																IL_05d8:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_05f0;
																IL_05f0:
																num5++;
																num = 2;
																goto IL_0607;
																IL_0607:
																ptr2 += 8;
																goto end_IL_02a8;
																IL_061a:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0659;
																IL_0659:
																num5 -= 3;
																goto end_IL_02a8;
																IL_066c:
																if (7 >= b)
																{
																	goto IL_067a;
																}
																goto IL_086d;
																IL_067a:
																if (7 <= b)
																{
																	goto IL_0688;
																}
																goto IL_086d;
																IL_0688:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 35;
																goto IL_06ba;
																IL_06ba:
																ptr2 += 8;
																num = 10;
																goto IL_06d1;
																IL_06d1:
																num5--;
																goto end_IL_02a8;
																IL_06e4:
																if (4 <= b)
																{
																	goto IL_06ef;
																}
																goto IL_072e;
																IL_06ef:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_070d;
																IL_070d:
																ptr2 += 8;
																goto IL_071b;
																IL_071b:
																num5--;
																goto end_IL_02a8;
																IL_072e:
																if (2 < b)
																{
																	goto IL_0739;
																}
																goto IL_0797;
																IL_0739:
																if (3 >= b)
																{
																	goto IL_0747;
																}
																goto IL_086d;
																IL_0747:
																if (3 <= b)
																{
																	goto IL_0755;
																}
																goto IL_086d;
																IL_0755:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_077e;
																IL_077e:
																array[num5 - 1] = 5;
																goto end_IL_02a8;
																IL_0797:
																if (2 <= b)
																{
																	goto IL_07a2;
																}
																goto IL_0809;
																IL_07a2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_07e2;
																IL_07e2:
																array[num5 - 2] = 0;
																goto IL_07f6;
																IL_07f6:
																num5--;
																goto end_IL_02a8;
																IL_0809:
																if (1 >= b)
																{
																	goto IL_0814;
																}
																goto IL_086d;
																IL_0814:
																if (1 <= b)
																{
																	goto IL_081f;
																}
																goto IL_086d;
																IL_081f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																num = 45;
																goto IL_0841;
																IL_0841:
																array[num5] = 0;
																goto IL_084f;
																continue;
																end_IL_027f:
																break;
															}
															continue;
															end_IL_028f:
															break;
														}
														continue;
														end_IL_02a8:
														break;
													}
													continue;
												}
												goto IL_0937;
												IL_0937:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0889:
												break;
											}
											continue;
											end_IL_089c:
											break;
										}
										continue;
										end_IL_08af:
										break;
									}
									continue;
									end_IL_08ba:
									break;
								}
								continue;
								end_IL_08ca:
								break;
							}
							continue;
							end_IL_08da:
							break;
						}
						continue;
						end_IL_08f3:
						break;
					}
					continue;
					end_IL_090c:
					break;
				}
				continue;
				end_IL_091c:
				break;
			}
		}
	}

	private static int PARAMFLAGFHASCUSTDATAISymbolVariable(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private unsafe static int smethod_5()
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setParamNamesEventSourceOptions.EnumerableToIterableAdapterToSerializedString);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02c3:
														num = 33;
														while (true)
														{
															IL_02b8:
															byte b = *ptr2;
															while (true)
															{
																IL_02a8:
																ptr2++;
																while (true)
																{
																	IL_0298:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			num = 150;
																			while (true)
																			{
																				if (num != 150)
																				{
																					if (num != 1131)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 138:
																						goto IL_0285;
																					case 73:
																						goto IL_0298;
																					case 110:
																						goto IL_02a8;
																					case 33:
																						goto IL_02b8;
																					case 59:
																						goto IL_02c3;
																					case 112:
																						goto IL_02dc;
																					case 31:
																					case 37:
																						goto IL_02ea;
																					case 32:
																					case 108:
																						goto IL_0301;
																					case 98:
																					case 113:
																						goto IL_030c;
																					case 69:
																						goto IL_031a;
																					case 7:
																					case 131:
																						goto IL_0328;
																					case 39:
																						goto IL_0351;
																					case 21:
																						goto IL_0368;
																					case 17:
																						goto IL_0384;
																					case 15:
																					case 64:
																						goto IL_038f;
																					case 82:
																						goto IL_03ce;
																					case 45:
																						goto IL_03e1;
																					case 43:
																						goto IL_03f8;
																					case 36:
																					case 119:
																						goto IL_0411;
																					case 80:
																						goto IL_041f;
																					case 100:
																						goto IL_0437;
																					case 38:
																						goto IL_0445;
																					case 134:
																						goto IL_0458;
																					case 62:
																					case 106:
																						goto IL_0466;
																					case 83:
																						goto IL_0474;
																					case 1:
																					case 85:
																						goto IL_047f;
																					case 128:
																						goto IL_04bf;
																					case 76:
																						goto IL_04d3;
																					case 79:
																						goto IL_04e6;
																					case 61:
																						goto IL_04f4;
																					case 72:
																					case 114:
																						goto IL_0502;
																					case 47:
																						goto IL_051b;
																					case 140:
																						goto IL_0529;
																					case 25:
																						goto IL_0537;
																					case 48:
																						goto IL_054a;
																					case 50:
																						goto IL_0558;
																					case 14:
																					case 125:
																						goto IL_0566;
																					case 115:
																						goto IL_058f;
																					case 58:
																					case 109:
																						goto IL_05a8;
																					case 136:
																						goto IL_05c6;
																					case 34:
																						goto IL_05d4;
																					case 116:
																					case 122:
																						goto IL_05e7;
																					case 77:
																						goto IL_05ff;
																					case 6:
																						goto IL_060d;
																					case 11:
																						goto IL_061b;
																					case 60:
																						goto IL_0629;
																					case 127:
																					case 142:
																						goto IL_0634;
																					case 9:
																						goto IL_0642;
																					case 29:
																					case 118:
																						goto IL_0655;
																					case 22:
																						goto IL_0663;
																					case 96:
																						goto IL_0686;
																					case 13:
																						goto IL_0699;
																					case 121:
																						goto IL_06a7;
																					case 68:
																						goto IL_06ba;
																					case 75:
																						goto IL_06c8;
																					case 90:
																					case 101:
																						goto IL_06d6;
																					case 0:
																						goto IL_071a;
																					case 3:
																						goto IL_072e;
																					case 92:
																					case 99:
																						goto IL_0741;
																					case 8:
																						goto IL_0781;
																					case 49:
																						goto IL_0795;
																					case 124:
																					case 137:
																						goto IL_07a8;
																					case 26:
																						goto IL_07b6;
																					case 126:
																					case 132:
																						goto IL_07c4;
																					case 35:
																						goto IL_07d2;
																					case 5:
																					case 27:
																						goto IL_07e0;
																					case 30:
																						goto IL_0842;
																					case 28:
																					case 89:
																						goto IL_0852;
																					case 54:
																						goto IL_086b;
																					case 95:
																						goto IL_0876;
																					case 2:
																					case 12:
																					case 18:
																					case 23:
																					case 46:
																					case 52:
																					case 55:
																					case 66:
																					case 74:
																					case 78:
																					case 86:
																					case 87:
																					case 91:
																					case 93:
																					case 103:
																					case 104:
																					case 107:
																					case 111:
																					case 117:
																					case 129:
																					case 133:
																					case 135:
																					case 141:
																						goto end_IL_0285;
																					case 4:
																					case 10:
																					case 16:
																					case 19:
																					case 44:
																					case 51:
																					case 53:
																					case 56:
																					case 57:
																					case 63:
																					case 65:
																					case 67:
																					case 70:
																					case 71:
																					case 81:
																					case 105:
																					case 130:
																					case 143:
																						goto end_IL_0275;
																					case 88:
																						goto end_IL_0894;
																					case 139:
																						goto end_IL_08a7;
																					case 24:
																						goto end_IL_08b1;
																					case 94:
																						goto end_IL_08bc;
																					case 20:
																					case 102:
																						goto end_IL_08cc;
																					case 42:
																						goto end_IL_08dc;
																					case 84:
																					case 123:
																						goto end_IL_08ec;
																					case 40:
																						goto end_IL_08fc;
																					case 41:
																						goto end_IL_090c;
																					case 97:
																					case 120:
																						goto IL_0927;
																					}
																					continue;
																				}
																				if (8 >= b)
																				{
																					goto IL_02dc;
																				}
																				goto IL_05ff;
																				IL_07d2:
																				if (13 > b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_07e0;
																				IL_0842:
																				num5 -= 2;
																				break;
																				IL_07e0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0842;
																				IL_02dc:
																				if (8 > b)
																				{
																					goto IL_02ea;
																				}
																				goto IL_05e7;
																				IL_02ea:
																				if (4 < b)
																				{
																					num = 108;
																					goto IL_0301;
																				}
																				goto IL_0458;
																				IL_0852:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0301:
																				if (6 < b)
																				{
																					goto IL_030c;
																				}
																				goto IL_0384;
																				IL_030c:
																				if (7 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_031a;
																				IL_031a:
																				if (7 > b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0328;
																				IL_0328:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0351;
																				IL_0351:
																				ptr2 += 8;
																				num = 21;
																				goto IL_0368;
																				IL_0368:
																				num5--;
																				num = 10;
																				break;
																				IL_0384:
																				if (6 <= b)
																				{
																					goto IL_038f;
																				}
																				goto IL_03e1;
																				IL_038f:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03ce;
																				IL_03ce:
																				num5 -= 3;
																				break;
																				IL_03e1:
																				if (5 < b)
																				{
																					goto end_IL_0285;
																				}
																				num = 43;
																				goto IL_03f8;
																				IL_086b:
																				if (15 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0876;
																				IL_03f8:
																				if (5 > b)
																				{
																					num = 93;
																					goto end_IL_0285;
																				}
																				goto IL_0411;
																				IL_0876:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_0285;
																				IL_0411:
																				array[num5] = 5;
																				goto IL_041f;
																				IL_041f:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0437;
																				IL_0437:
																				num5++;
																				goto IL_0445;
																				IL_0445:
																				ptr2 += 8;
																				break;
																				IL_0458:
																				if (4 > b)
																				{
																					goto IL_0466;
																				}
																				goto IL_05a8;
																				IL_0466:
																				if (2 >= b)
																				{
																					goto IL_0474;
																				}
																				goto IL_054a;
																				IL_0474:
																				if (2 <= b)
																				{
																					goto IL_047f;
																				}
																				goto IL_04e6;
																				IL_047f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04bf;
																				IL_04bf:
																				array[num5 - 2] = 0;
																				goto IL_04d3;
																				IL_04d3:
																				num5--;
																				break;
																				IL_04e6:
																				if (1 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_04f4;
																				IL_04f4:
																				if (1 > b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0502;
																				IL_0502:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_051b;
																				IL_051b:
																				array[num5] = 0;
																				goto IL_0529;
																				IL_0529:
																				num5++;
																				goto IL_0537;
																				IL_0537:
																				ptr2 += 8;
																				break;
																				IL_054a:
																				if (3 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0558;
																				IL_0558:
																				if (3 > b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0566;
																				IL_0566:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_058f;
																				IL_058f:
																				array[num5 - 1] = 5;
																				break;
																				IL_05a8:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_05c6;
																				IL_05c6:
																				ptr2 += 8;
																				goto IL_05d4;
																				IL_05d4:
																				num5--;
																				break;
																				IL_05e7:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_05ff:
																				if (12 >= b)
																				{
																					goto IL_060d;
																				}
																				goto IL_07a8;
																				IL_060d:
																				if (12 > b)
																				{
																					goto IL_061b;
																				}
																				goto IL_0741;
																				IL_061b:
																				if (10 >= b)
																				{
																					goto IL_0629;
																				}
																				goto IL_06ba;
																				IL_0629:
																				if (10 > b)
																				{
																					goto IL_0634;
																				}
																				goto IL_0655;
																				IL_0634:
																				if (9 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_0642;
																				IL_0642:
																				if (9 <= b)
																				{
																					break;
																				}
																				goto end_IL_0285;
																				IL_0655:
																				array[num5] = 0;
																				goto IL_0663;
																				IL_0663:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0686;
																				IL_0686:
																				array2[num5] = null;
																				num = 13;
																				goto IL_0699;
																				IL_0699:
																				num5++;
																				goto IL_06a7;
																				IL_06a7:
																				ptr2 += 8;
																				break;
																				IL_06ba:
																				if (11 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_06c8;
																				IL_06c8:
																				if (11 > b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_06d6;
																				IL_06d6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_071a;
																				IL_071a:
																				array[num5 - 2] = 0;
																				goto IL_072e;
																				IL_072e:
																				num5--;
																				break;
																				IL_0741:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0781;
																				IL_0781:
																				array[num5 - 2] = 0;
																				goto IL_0795;
																				IL_0795:
																				num5--;
																				break;
																				IL_07a8:
																				if (14 >= b)
																				{
																					goto IL_07b6;
																				}
																				goto IL_086b;
																				IL_07b6:
																				if (14 > b)
																				{
																					goto IL_07c4;
																				}
																				goto IL_0852;
																				IL_07c4:
																				if (13 < b)
																				{
																					goto end_IL_0285;
																				}
																				goto IL_07d2;
																				continue;
																				end_IL_0275:
																				break;
																			}
																			goto end_IL_0298;
																			continue;
																			end_IL_0285:
																			break;
																			IL_0285:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0298:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0927;
												IL_0927:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0894:
												break;
											}
											continue;
											end_IL_08a7:
											break;
										}
										continue;
										end_IL_08b1:
										break;
									}
									continue;
									end_IL_08bc:
									break;
								}
								continue;
								end_IL_08cc:
								break;
							}
							continue;
							end_IL_08dc:
							break;
						}
						continue;
						end_IL_08ec:
						break;
					}
					continue;
					end_IL_08fc:
					break;
				}
				continue;
				end_IL_090c:
				break;
			}
		}
	}

	private static void CacheTypeAllocateDataSlot(Rigidbody rigidbody_0, Vector3 vector3_0, ForceMode forceMode_0)
	{
		rigidbody_0.AddForce(vector3_0, forceMode_0);
	}

	private static int smethod_6(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			return num - num2;
		}
		num = int_1;
		num2 = int_2;
		return num - num2;
	}

	private static Rigidbody ForegroundIntensityStfld()
	{
		return global::_003CModule_003E.rigidbody_3;
	}

	private static int smethod_8(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 400;
		num2 = 80;
		num += 80;
		int num6 = smethod_4();
		num2 = num6;
		return num;
	}

	private static Rigidbody getAbbreviatedDayNamesBSTRMarshaler(Component component_0)
	{
		return component_0.GetComponent<Rigidbody>();
	}

	private static Vector3 AssemblyReferenceDependentAssemblySupportUrlDebuggableAttribute(Transform transform_0)
	{
		return transform_0.forward;
	}

	private unsafe void method_0()
	{
		int num = 197;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									num = 111;
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LastCalledTypeRemoveEventHandler.BindToMonikerEnvironment);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03f1:
																	if (b >= 1)
																	{
																		while (b <= 24)
																		{
																			while (true)
																			{
																				IL_03d1:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_03c4:
																						if (18 < b)
																						{
																							while (true)
																							{
																								IL_03b4:
																								if (21 >= b)
																								{
																									while (true)
																									{
																										IL_03a7:
																										if (21 > b)
																										{
																											while (true)
																											{
																												IL_0397:
																												if (19 < b)
																												{
																													while (20 >= b)
																													{
																														num = 213;
																														while (true)
																														{
																															if (num != 213)
																															{
																																if (num != 1194)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 176:
																																	goto IL_0384;
																																case 81:
																																	goto IL_0397;
																																case 18:
																																	goto IL_03a7;
																																case 200:
																																	goto IL_03b4;
																																case 183:
																																	goto IL_03c4;
																																case 1:
																																	goto IL_03d1;
																																case 31:
																																	goto IL_03e1;
																																case 122:
																																	goto IL_03f1;
																																case 13:
																																	goto end_IL_03f1;
																																case 101:
																																case 110:
																																	goto end_IL_0401;
																																case 56:
																																	goto IL_041c;
																																case 38:
																																case 75:
																																	goto IL_042c;
																																case 78:
																																	goto IL_0471;
																																case 4:
																																	goto IL_047c;
																																case 71:
																																	goto IL_0487;
																																case 57:
																																	goto IL_049a;
																																case 96:
																																	goto IL_04b6;
																																case 125:
																																	goto IL_04c4;
																																case 65:
																																	goto IL_04d2;
																																case 144:
																																	goto IL_04e5;
																																case 42:
																																case 63:
																																	goto IL_04f0;
																																case 83:
																																	goto IL_0531;
																																case 142:
																																	goto IL_054a;
																																case 29:
																																	goto IL_055e;
																																case 90:
																																case 132:
																																	goto IL_056c;
																																case 138:
																																	goto IL_0585;
																																case 109:
																																	goto end_IL_0371;
																																case 131:
																																	goto IL_05a6;
																																case 22:
																																case 103:
																																	goto IL_05b4;
																																case 160:
																																	goto IL_05cc;
																																case 106:
																																case 148:
																																	goto IL_05da;
																																case 20:
																																	goto IL_05f3;
																																case 108:
																																case 169:
																																	goto IL_0606;
																																case 72:
																																	goto IL_0646;
																																case 73:
																																	goto IL_065a;
																																case 174:
																																	goto IL_0676;
																																case 120:
																																	goto IL_0693;
																																case 136:
																																case 175:
																																	goto IL_06a6;
																																case 6:
																																	goto IL_06cf;
																																case 92:
																																	goto IL_06e6;
																																case 178:
																																	goto IL_06f9;
																																case 134:
																																case 164:
																																	goto IL_0710;
																																case 159:
																																	goto IL_0728;
																																case 28:
																																	goto IL_0736;
																																case 88:
																																	goto IL_0744;
																																case 179:
																																	goto IL_0757;
																																case 185:
																																	goto IL_076a;
																																case 53:
																																	goto IL_0778;
																																case 163:
																																case 186:
																																	goto IL_078b;
																																case 64:
																																	goto IL_07dd;
																																case 189:
																																	goto IL_07f0;
																																case 45:
																																	goto IL_07fe;
																																case 55:
																																case 115:
																																	goto IL_0809;
																																case 188:
																																	goto IL_0832;
																																case 10:
																																	goto IL_0849;
																																case 133:
																																	goto IL_085c;
																																case 7:
																																	goto IL_086a;
																																case 51:
																																	goto IL_0878;
																																case 16:
																																case 99:
																																	goto IL_0886;
																																case 93:
																																	goto IL_08c6;
																																case 165:
																																	goto IL_08da;
																																case 139:
																																	goto IL_08f6;
																																case 40:
																																case 97:
																																	goto IL_0904;
																																case 86:
																																	goto IL_0926;
																																case 48:
																																	goto IL_0934;
																																case 47:
																																	goto IL_0942;
																																case 117:
																																	goto IL_0955;
																																case 46:
																																	goto IL_0960;
																																case 127:
																																	goto IL_0973;
																																case 124:
																																	goto IL_0981;
																																case 50:
																																case 168:
																																	goto IL_098f;
																																case 129:
																																	goto IL_09cf;
																																case 190:
																																	goto IL_09e3;
																																case 191:
																																	goto IL_09f6;
																																case 11:
																																	goto IL_0a04;
																																case 167:
																																case 177:
																																	goto IL_0a0f;
																																case 3:
																																	goto IL_0a4f;
																																case 170:
																																	goto IL_0a63;
																																case 184:
																																	goto IL_0a76;
																																case 24:
																																	goto IL_0a81;
																																case 59:
																																case 153:
																																	goto IL_0a8f;
																																case 95:
																																	goto IL_0acf;
																																case 128:
																																	goto IL_0ae3;
																																case 123:
																																	goto IL_0af6;
																																case 61:
																																	goto IL_0b04;
																																case 23:
																																	goto IL_0b17;
																																case 76:
																																	goto IL_0b25;
																																case 25:
																																case 135:
																																	goto IL_0b33;
																																case 137:
																																	goto IL_0b95;
																																case 66:
																																	goto IL_0ba8;
																																case 116:
																																	goto IL_0bb6;
																																case 145:
																																case 157:
																																	goto IL_0bc4;
																																case 171:
																																	goto IL_0bd8;
																																case 181:
																																	goto IL_0c2c;
																																case 151:
																																	goto IL_0c3a;
																																case 193:
																																	goto IL_0c56;
																																case 49:
																																	goto IL_0c64;
																																case 68:
																																case 204:
																																	goto IL_0c77;
																																case 126:
																																case 205:
																																	goto IL_0c8a;
																																case 119:
																																	goto IL_0c98;
																																case 15:
																																	goto IL_0cbb;
																																case 118:
																																	goto IL_0cc5;
																																case 113:
																																	goto IL_0cdc;
																																case 182:
																																case 192:
																																	goto IL_0cfd;
																																case 155:
																																	goto IL_0d11;
																																case 27:
																																	goto IL_0d59;
																																case 203:
																																	goto IL_0d6c;
																																case 82:
																																	goto IL_0d7a;
																																case 9:
																																case 26:
																																	goto IL_0d85;
																																case 52:
																																	goto IL_0da1;
																																case 150:
																																	goto IL_0daf;
																																case 161:
																																case 202:
																																	goto IL_0dbd;
																																case 8:
																																	goto IL_0dd1;
																																case 87:
																																	goto IL_0e10;
																																case 79:
																																	goto IL_0e29;
																																case 33:
																																	goto IL_0e34;
																																case 30:
																																case 32:
																																case 34:
																																case 35:
																																case 36:
																																case 39:
																																case 62:
																																case 67:
																																case 69:
																																case 77:
																																case 84:
																																case 85:
																																case 91:
																																case 94:
																																case 98:
																																case 102:
																																case 112:
																																case 114:
																																case 121:
																																case 140:
																																case 143:
																																case 146:
																																case 147:
																																case 152:
																																case 172:
																																case 187:
																																case 194:
																																	goto end_IL_0384;
																																case 0:
																																case 2:
																																case 5:
																																case 12:
																																case 14:
																																case 17:
																																case 19:
																																case 21:
																																case 37:
																																case 41:
																																case 44:
																																case 54:
																																case 60:
																																case 70:
																																case 74:
																																case 89:
																																case 100:
																																case 107:
																																case 141:
																																case 154:
																																case 156:
																																case 162:
																																case 166:
																																case 173:
																																case 198:
																																case 201:
																																case 206:
																																	goto end_IL_0411;
																																case 43:
																																	goto end_IL_0e52;
																																case 195:
																																	goto end_IL_0e65;
																																case 58:
																																	goto end_IL_0e6f;
																																case 111:
																																	goto end_IL_0e7a;
																																case 149:
																																	goto end_IL_0e8a;
																																case 104:
																																case 130:
																																	goto end_IL_0e9a;
																																case 180:
																																	goto end_IL_0eb3;
																																case 158:
																																	goto end_IL_0ec3;
																																case 80:
																																	goto end_IL_0ed3;
																																case 196:
																																	goto end_IL_0ee3;
																																case 197:
																																	goto end_IL_0ef3;
																																case 105:
																																case 199:
																																	return;
																																}
																																continue;
																															}
																															if (20 > b)
																															{
																																goto end_IL_0384;
																															}
																															goto IL_0cfd;
																															IL_0cfd:
																															array[num6 - 1] = 3;
																															goto IL_0d11;
																															IL_0d59:
																															ptr2 += 8;
																															goto end_IL_0411;
																															IL_0d11:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)EnumSubcategoriesXmlAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																															num = 27;
																															goto IL_0d59;
																															continue;
																															end_IL_0371:
																															break;
																														}
																														goto IL_0598;
																														continue;
																														end_IL_0384:
																														break;
																														IL_0384:;
																													}
																													break;
																												}
																												goto IL_05cc;
																												IL_0c64:
																												ptr2 += 16;
																												goto end_IL_0411;
																												IL_05cc:
																												if (19 > b)
																												{
																													break;
																												}
																												goto IL_05da;
																												IL_05da:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																												goto IL_05f3;
																												IL_05f3:
																												array[num6] = 3;
																												goto IL_0c56;
																												IL_0c56:
																												num6++;
																												goto IL_0c64;
																											}
																											break;
																										}
																										goto IL_042c;
																										IL_0693:
																										num6--;
																										goto end_IL_0411;
																										IL_042c:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0676;
																										IL_0676:
																										array[num6 - 2] = 3;
																										num = 120;
																										goto IL_0693;
																									}
																									break;
																								}
																								goto IL_0d6c;
																								IL_0e34:
																								if (24 <= b)
																								{
																								}
																								break;
																								IL_0d6c:
																								if (23 >= b)
																								{
																									goto IL_0d7a;
																								}
																								goto IL_0e29;
																								IL_0d7a:
																								if (23 <= b)
																								{
																									goto IL_0d85;
																								}
																								goto IL_0da1;
																								IL_0d85:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								goto end_IL_0411;
																								IL_0da1:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_0daf;
																								IL_0daf:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_0dbd;
																								IL_0dbd:
																								array[num6 - 1] = 0;
																								goto IL_0dd1;
																								IL_0dd1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)EnumSubcategoriesXmlAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_0e10;
																								IL_0e10:
																								ptr2 += 8;
																								num = 70;
																								goto end_IL_0411;
																								IL_0e29:
																								if (24 < b)
																								{
																									break;
																								}
																								goto IL_0e34;
																							}
																							break;
																						}
																						goto IL_041c;
																						IL_0778:
																						ptr2 += 16;
																						goto end_IL_0411;
																						IL_041c:
																						if (18 > b)
																						{
																							goto IL_0471;
																						}
																						goto IL_06a6;
																						IL_06a6:
																						((delegate*<Class194, void>)EnumSubcategoriesXmlAttribute[*(int*)(ptr2 + num3)])((Class194)array2[num6 - 1]);
																						goto IL_06cf;
																						IL_06cf:
																						num6--;
																						num = 92;
																						goto IL_06e6;
																						IL_06e6:
																						ptr2 += 8;
																						goto end_IL_0411;
																						IL_0471:
																						if (15 < b)
																						{
																							goto IL_047c;
																						}
																						goto IL_04e5;
																						IL_047c:
																						if (16 >= b)
																						{
																							goto IL_0487;
																						}
																						goto IL_049a;
																						IL_0487:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_078b;
																						IL_078b:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_07dd;
																						IL_07dd:
																						num6--;
																						goto end_IL_0411;
																						IL_049a:
																						if (17 < b)
																						{
																							break;
																						}
																						num = 178;
																						goto IL_06f9;
																						IL_0598:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_05a6;
																						IL_06f9:
																						if (17 > b)
																						{
																							break;
																						}
																						num = 134;
																						goto IL_0710;
																						IL_05a6:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_05b4;
																						IL_0710:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0728;
																						IL_0728:
																						array[num6] = 5;
																						goto IL_0736;
																						IL_0736:
																						num6++;
																						goto IL_0744;
																						IL_0744:
																						ptr2 += 8;
																						goto end_IL_0411;
																						IL_04e5:
																						if (15 <= b)
																						{
																							goto IL_04f0;
																						}
																						goto IL_054a;
																						IL_04f0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0531;
																						IL_0531:
																						array[num6 - 2] = 0;
																						goto IL_0757;
																						IL_0757:
																						num6--;
																						goto end_IL_0411;
																						IL_054a:
																						if (13 >= b)
																						{
																							num = 29;
																							goto IL_055e;
																						}
																						goto IL_0598;
																						IL_05b4:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0411;
																						IL_055e:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_056c;
																						IL_056c:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0585;
																						IL_0585:
																						array[num6] = 1;
																						goto IL_076a;
																						IL_076a:
																						num6++;
																						goto IL_0778;
																					}
																					break;
																				}
																				goto IL_04b6;
																				IL_0c2c:
																				num6--;
																				goto IL_0c3a;
																				IL_04b6:
																				if (12 <= b)
																				{
																					goto end_IL_0411;
																				}
																				goto IL_04c4;
																				IL_04c4:
																				if (6 >= b)
																				{
																					goto IL_04d2;
																				}
																				goto IL_09f6;
																				IL_04d2:
																				if (6 <= b)
																				{
																					goto IL_0606;
																				}
																				goto IL_07f0;
																				IL_0606:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0646;
																				IL_0646:
																				array[num6 - 2] = 0;
																				goto IL_065a;
																				IL_065a:
																				num6--;
																				num = 198;
																				goto end_IL_0411;
																				IL_07f0:
																				if (3 >= b)
																				{
																					goto IL_07fe;
																				}
																				goto IL_0955;
																				IL_07fe:
																				if (3 <= b)
																				{
																					goto IL_0809;
																				}
																				goto IL_085c;
																				IL_0809:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0832;
																				IL_0832:
																				ptr2 += 8;
																				num = 10;
																				goto IL_0849;
																				IL_0849:
																				num6--;
																				goto end_IL_0411;
																				IL_085c:
																				if (1 < b)
																				{
																					goto IL_086a;
																				}
																				num = 139;
																				goto IL_08f6;
																				IL_086a:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0878;
																				IL_0878:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0886;
																				IL_0886:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_08c6;
																				IL_08c6:
																				array[num6 - 2] = 0;
																				goto IL_08da;
																				IL_08da:
																				num6--;
																				goto end_IL_0411;
																				IL_0c3a:
																				ptr2 += 8;
																				num = 14;
																				goto end_IL_0411;
																				IL_08f6:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0904;
																				IL_0904:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				num = 86;
																				goto IL_0926;
																				IL_0926:
																				array[num6] = 0;
																				goto IL_0934;
																				IL_0934:
																				num6++;
																				goto IL_0942;
																				IL_0942:
																				ptr2 += 8;
																				goto end_IL_0411;
																				IL_0955:
																				if (4 >= b)
																				{
																					goto IL_0960;
																				}
																				goto IL_0973;
																				IL_0960:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0c8a;
																				IL_0c8a:
																				array[num6] = 0;
																				goto IL_0c98;
																				IL_0c98:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0cbb;
																				IL_0cbb:
																				array2[num6] = null;
																				goto IL_0cc5;
																				IL_0cc5:
																				num6++;
																				num = 113;
																				goto IL_0cdc;
																				IL_0cdc:
																				ptr2 += 8;
																				goto end_IL_0411;
																				IL_0973:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0981;
																				IL_0981:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_098f;
																				IL_098f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_09cf;
																				IL_09cf:
																				array[num6 - 2] = 0;
																				goto IL_09e3;
																				IL_09e3:
																				num6--;
																				goto end_IL_0411;
																				IL_09f6:
																				if (9 >= b)
																				{
																					goto IL_0a04;
																				}
																				goto IL_0b17;
																				IL_0a04:
																				if (9 <= b)
																				{
																					goto IL_0a0f;
																				}
																				goto IL_0a76;
																				IL_0a0f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0a4f;
																				IL_0a4f:
																				array[num6 - 2] = 0;
																				goto IL_0a63;
																				IL_0a63:
																				num6--;
																				goto end_IL_0411;
																				IL_0a76:
																				if (7 >= b)
																				{
																					goto IL_0a81;
																				}
																				goto IL_0af6;
																				IL_0a81:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0a8f;
																				IL_0a8f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0acf;
																				IL_0acf:
																				array[num6 - 2] = 0;
																				goto IL_0ae3;
																				IL_0ae3:
																				num6--;
																				goto end_IL_0411;
																				IL_0af6:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0b04;
																				IL_0b04:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0c77;
																				IL_0c77:
																				num6--;
																				goto end_IL_0411;
																				IL_0b17:
																				if (10 >= b)
																				{
																					goto IL_0b25;
																				}
																				goto IL_0ba8;
																				IL_0b25:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0b33;
																				IL_0b33:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0b95;
																				IL_0b95:
																				num6 -= 2;
																				goto end_IL_0411;
																				IL_0ba8:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0bb6;
																				IL_0bb6:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0bc4;
																				IL_0bc4:
																				array[num6 - 2] = 0;
																				goto IL_0bd8;
																				IL_0bd8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)EnumSubcategoriesXmlAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0c2c;
																			}
																			break;
																			IL_03e1:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0411;
																	continue;
																	end_IL_03f1:
																	break;
																}
																continue;
																end_IL_0401:
																break;
															}
															continue;
															end_IL_0411:
															break;
														}
														continue;
														end_IL_0e52:
														break;
													}
													continue;
													end_IL_0e65:
													break;
												}
												continue;
												end_IL_0e6f:
												break;
											}
											continue;
											end_IL_0e7a:
											break;
										}
										continue;
										end_IL_0e8a:
										break;
									}
									continue;
									end_IL_0e9a:
									break;
								}
								continue;
								end_IL_0eb3:
								break;
							}
							continue;
							end_IL_0ec3:
							break;
						}
						continue;
						end_IL_0ed3:
						break;
					}
					continue;
					end_IL_0ee3:
					break;
				}
				continue;
				end_IL_0ef3:
				break;
			}
		}
	}

	private static Vector3 EmitWriteLineEventWaitHandleRights(Vector3 vector3_0, float float_2)
	{
		return vector3_0 * float_2;
	}

	private static double EventAttributesHostDll(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private unsafe void method_1()
	{
		int num = 148;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 147;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						num = 34;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetResourceStringUserDataCOMRedirectionSection.RemoteLogonIdSidLogRemotingStage);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_046d:
															if (b >= 1)
															{
																while (b <= 27)
																{
																	num = 119;
																	while (true)
																	{
																		IL_044a:
																		if (14 >= b)
																		{
																			while (true)
																			{
																				IL_043a:
																				if (14 > b)
																				{
																					while (true)
																					{
																						IL_042a:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_041d:
																								if (10 < b)
																								{
																									while (true)
																									{
																										IL_040d:
																										if (12 < b)
																										{
																											while (13 >= b)
																											{
																												while (13 <= b)
																												{
																													num = 235;
																													while (true)
																													{
																														if (num != 235)
																														{
																															if (num != 1216)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 160:
																																goto IL_03ea;
																															case 142:
																																goto IL_03fd;
																															case 165:
																																goto IL_040d;
																															case 183:
																																goto IL_041d;
																															case 68:
																																goto IL_042a;
																															case 206:
																																goto IL_043a;
																															case 119:
																																goto IL_044a;
																															case 133:
																																goto IL_045a;
																															case 61:
																																goto IL_046d;
																															case 171:
																																goto end_IL_046d;
																															case 137:
																															case 202:
																																goto end_IL_047d;
																															case 90:
																																goto IL_0498;
																															case 131:
																																goto IL_04ab;
																															case 43:
																															case 108:
																																goto IL_04b6;
																															case 127:
																																goto IL_04d4;
																															case 60:
																																goto end_IL_03d7;
																															case 64:
																															case 140:
																																goto IL_04f5;
																															case 15:
																																goto IL_0536;
																															case 56:
																																goto IL_054a;
																															case 149:
																																goto IL_055d;
																															case 128:
																																goto IL_056b;
																															case 22:
																																goto IL_0579;
																															case 112:
																															case 184:
																																goto IL_0589;
																															case 159:
																																goto IL_05eb;
																															case 105:
																															case 188:
																																goto IL_0607;
																															case 191:
																																goto IL_0652;
																															case 35:
																															case 168:
																																goto IL_0660;
																															case 197:
																																goto IL_0673;
																															case 207:
																																goto IL_0681;
																															case 5:
																																goto IL_068f;
																															case 226:
																																goto IL_06a2;
																															case 194:
																																goto IL_06b6;
																															case 158:
																																goto IL_06c9;
																															case 19:
																																goto IL_06ea;
																															case 85:
																															case 124:
																																goto IL_06f5;
																															case 228:
																																goto IL_073e;
																															case 86:
																																goto IL_0752;
																															case 45:
																																goto IL_076e;
																															case 24:
																																goto IL_077c;
																															case 195:
																															case 222:
																																goto IL_0787;
																															case 96:
																																goto IL_07b0;
																															case 200:
																																goto IL_07be;
																															case 106:
																																goto IL_07d1;
																															case 98:
																																goto IL_07dc;
																															case 26:
																															case 120:
																																goto IL_07ea;
																															case 187:
																																goto IL_0803;
																															case 189:
																																goto IL_0811;
																															case 52:
																																goto IL_081f;
																															case 218:
																																goto IL_0832;
																															case 154:
																																goto IL_0840;
																															case 42:
																															case 110:
																																goto IL_084e;
																															case 208:
																																goto IL_088e;
																															case 3:
																																goto IL_08a2;
																															case 7:
																																goto IL_08b5;
																															case 25:
																																goto IL_08c3;
																															case 95:
																															case 213:
																																goto IL_08ce;
																															case 198:
																																goto IL_090e;
																															case 0:
																																goto IL_0922;
																															case 216:
																																goto IL_0935;
																															case 70:
																																goto IL_0943;
																															case 29:
																															case 81:
																																goto IL_0951;
																															case 16:
																																goto IL_095f;
																															case 37:
																																goto IL_098b;
																															case 76:
																																goto IL_0995;
																															case 122:
																																goto IL_09a3;
																															case 88:
																																goto IL_09b6;
																															case 211:
																																goto IL_09c4;
																															case 63:
																															case 178:
																																goto IL_09d2;
																															case 66:
																																goto IL_0a12;
																															case 181:
																																goto IL_0a26;
																															case 169:
																																goto IL_0a39;
																															case 51:
																																goto IL_0a47;
																															case 132:
																																goto IL_0a55;
																															case 126:
																																goto IL_0a63;
																															case 74:
																															case 166:
																																goto IL_0a6e;
																															case 111:
																																goto IL_0a8a;
																															case 103:
																																goto IL_0a98;
																															case 36:
																															case 163:
																																goto IL_0aa6;
																															case 18:
																																goto IL_0ae6;
																															case 223:
																																goto IL_0afa;
																															case 80:
																																goto IL_0b0d;
																															case 144:
																																goto IL_0b1b;
																															case 152:
																																goto IL_0b37;
																															case 212:
																																goto IL_0b45;
																															case 77:
																																goto IL_0b50;
																															case 65:
																															case 136:
																																goto IL_0b5e;
																															case 54:
																																goto IL_0b72;
																															case 115:
																																goto IL_0bb1;
																															case 196:
																																goto IL_0bc4;
																															case 190:
																																goto IL_0bd2;
																															case 87:
																															case 130:
																																goto IL_0be0;
																															case 20:
																																goto IL_0bf4;
																															case 167:
																																goto IL_0c2c;
																															case 2:
																															case 201:
																																goto IL_0c3f;
																															case 104:
																																goto IL_0c7d;
																															case 30:
																																goto IL_0c94;
																															case 50:
																																goto IL_0ca7;
																															case 113:
																															case 138:
																																goto IL_0cb2;
																															case 170:
																																goto IL_0cf2;
																															case 199:
																																goto IL_0d06;
																															case 59:
																																goto IL_0d19;
																															case 91:
																																goto IL_0d27;
																															case 78:
																															case 100:
																																goto IL_0d32;
																															case 220:
																																goto IL_0d3c;
																															case 125:
																																goto IL_0d4a;
																															case 28:
																																goto IL_0d5d;
																															case 121:
																																goto IL_0d68;
																															case 93:
																															case 102:
																																goto IL_0d76;
																															case 180:
																																goto IL_0dc8;
																															case 83:
																																goto IL_0ddb;
																															case 57:
																																goto IL_0de9;
																															case 17:
																															case 84:
																																goto IL_0df7;
																															case 141:
																																goto IL_0e05;
																															case 82:
																																goto IL_0e23;
																															case 153:
																																goto IL_0e31;
																															case 53:
																																goto IL_0e44;
																															case 114:
																																goto IL_0e52;
																															case 32:
																																goto IL_0e60;
																															case 107:
																																goto IL_0e6e;
																															case 204:
																															case 225:
																																goto IL_0e7c;
																															case 175:
																																goto IL_0e90;
																															case 73:
																																goto IL_0edd;
																															case 14:
																																goto IL_0eeb;
																															case 10:
																															case 214:
																																goto IL_0efe;
																															case 31:
																																goto IL_0f17;
																															case 224:
																																goto IL_0f2e;
																															case 205:
																																goto IL_0f3c;
																															case 139:
																																goto IL_0f4f;
																															case 155:
																																goto IL_0f5a;
																															case 38:
																															case 193:
																																goto IL_0f65;
																															case 174:
																																goto IL_0f79;
																															case 13:
																																goto IL_0fb8;
																															case 4:
																															case 11:
																															case 12:
																															case 21:
																															case 27:
																															case 41:
																															case 46:
																															case 48:
																															case 62:
																															case 71:
																															case 72:
																															case 89:
																															case 97:
																															case 101:
																															case 109:
																															case 116:
																															case 123:
																															case 129:
																															case 143:
																															case 173:
																															case 177:
																															case 179:
																															case 182:
																															case 185:
																															case 186:
																															case 203:
																															case 209:
																															case 210:
																															case 217:
																															case 219:
																																goto end_IL_03ea;
																															case 1:
																															case 6:
																															case 8:
																															case 9:
																															case 23:
																															case 33:
																															case 39:
																															case 47:
																															case 49:
																															case 58:
																															case 67:
																															case 69:
																															case 79:
																															case 92:
																															case 94:
																															case 99:
																															case 117:
																															case 118:
																															case 134:
																															case 135:
																															case 151:
																															case 156:
																															case 157:
																															case 162:
																															case 164:
																															case 172:
																															case 192:
																															case 215:
																															case 221:
																															case 227:
																																goto end_IL_048d;
																															case 145:
																																goto end_IL_0fdb;
																															case 161:
																																goto end_IL_0fee;
																															case 55:
																																goto end_IL_0ff8;
																															case 150:
																															case 176:
																																goto end_IL_1003;
																															case 34:
																																goto end_IL_1013;
																															case 40:
																																goto end_IL_1023;
																															case 146:
																																goto end_IL_1033;
																															case 147:
																																goto end_IL_104c;
																															case 148:
																																goto end_IL_105c;
																															case 44:
																															case 75:
																																return;
																															}
																															continue;
																														}
																														goto IL_06c9;
																														IL_06c9:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														goto end_IL_048d;
																														continue;
																														end_IL_03d7:
																														break;
																													}
																													goto IL_04e2;
																													continue;
																													end_IL_03ea:
																													break;
																													IL_03ea:;
																												}
																												break;
																												IL_03fd:;
																											}
																											break;
																										}
																										goto IL_04ab;
																										IL_04e2:
																										if (11 > b)
																										{
																											break;
																										}
																										goto end_IL_048d;
																										IL_04ab:
																										if (12 <= b)
																										{
																											goto IL_04b6;
																										}
																										goto IL_04d4;
																										IL_04b6:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0673;
																										IL_0673:
																										array[num6] = 1;
																										goto IL_0681;
																										IL_0681:
																										num6++;
																										goto IL_068f;
																										IL_068f:
																										ptr2 += 16;
																										goto end_IL_048d;
																										IL_04d4:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_04e2;
																									}
																									break;
																								}
																								goto IL_0498;
																								IL_05eb:
																								num6 -= 2;
																								num = 117;
																								goto end_IL_048d;
																								IL_0498:
																								if (10 > b)
																								{
																									goto IL_055d;
																								}
																								goto IL_0589;
																								IL_055d:
																								if (8 < b)
																								{
																									goto IL_056b;
																								}
																								goto IL_0652;
																								IL_056b:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0579;
																								IL_0579:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0607;
																								IL_0607:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								num = 226;
																								goto IL_06a2;
																								IL_06a2:
																								array[num6 - 2] = 0;
																								goto IL_06b6;
																								IL_06b6:
																								num6--;
																								goto end_IL_048d;
																								IL_0652:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0660;
																								IL_0660:
																								num6--;
																								goto end_IL_048d;
																								IL_0589:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_05eb;
																							}
																							break;
																						}
																						num = 19;
																						goto IL_06ea;
																						IL_0a12:
																						array[num6 - 2] = 0;
																						goto IL_0a26;
																						IL_0a26:
																						num6--;
																						goto end_IL_048d;
																						IL_06ea:
																						if (7 <= b)
																						{
																							goto IL_06f5;
																						}
																						goto IL_076e;
																						IL_06f5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 228;
																						goto IL_073e;
																						IL_073e:
																						array[num6 - 2] = 0;
																						goto IL_0752;
																						IL_0752:
																						num6--;
																						num = 118;
																						goto end_IL_048d;
																						IL_076e:
																						if (3 >= b)
																						{
																							goto IL_077c;
																						}
																						goto IL_08b5;
																						IL_077c:
																						if (3 <= b)
																						{
																							goto IL_0787;
																						}
																						goto IL_07d1;
																						IL_0787:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_07b0;
																						IL_07b0:
																						ptr2 += 8;
																						goto IL_07be;
																						IL_07be:
																						num6--;
																						goto end_IL_048d;
																						IL_07d1:
																						if (1 >= b)
																						{
																							goto IL_07dc;
																						}
																						goto IL_0832;
																						IL_07dc:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_07ea;
																						IL_07ea:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0803;
																						IL_0803:
																						array[num6] = 0;
																						goto IL_0811;
																						IL_0811:
																						num6++;
																						goto IL_081f;
																						IL_081f:
																						ptr2 += 8;
																						goto end_IL_048d;
																						IL_0832:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_0840;
																						IL_0840:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_084e;
																						IL_084e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_088e;
																						IL_088e:
																						array[num6 - 2] = 0;
																						goto IL_08a2;
																						IL_08a2:
																						num6--;
																						goto end_IL_048d;
																						IL_08b5:
																						if (5 >= b)
																						{
																							goto IL_08c3;
																						}
																						goto IL_09b6;
																						IL_08c3:
																						if (5 <= b)
																						{
																							goto IL_08ce;
																						}
																						goto IL_0935;
																						IL_08ce:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_090e;
																						IL_090e:
																						array[num6 - 2] = 0;
																						goto IL_0922;
																						IL_0922:
																						num6--;
																						goto end_IL_048d;
																						IL_0935:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0943;
																						IL_0943:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0951;
																						IL_0951:
																						array[num6] = 0;
																						goto IL_095f;
																						IL_095f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						num = 37;
																						goto IL_098b;
																						IL_098b:
																						array2[num6] = null;
																						goto IL_0995;
																						IL_0995:
																						num6++;
																						goto IL_09a3;
																						IL_09a3:
																						ptr2 += 8;
																						goto end_IL_048d;
																						IL_09b6:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_09c4;
																						IL_09c4:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_09d2;
																						IL_09d2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0a12;
																					}
																					break;
																				}
																				goto IL_04f5;
																				IL_054a:
																				num6--;
																				goto end_IL_048d;
																				IL_04f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_0536;
																				IL_0536:
																				array[num6 - 2] = 0;
																				goto IL_054a;
																			}
																			break;
																		}
																		goto IL_0a39;
																		IL_0f79:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0fb8;
																		IL_0a39:
																		if (21 < b)
																		{
																			goto IL_0a47;
																		}
																		goto IL_0ca7;
																		IL_0a47:
																		if (24 < b)
																		{
																			goto IL_0a55;
																		}
																		goto IL_0b37;
																		IL_0a55:
																		if (26 >= b)
																		{
																			goto IL_0a63;
																		}
																		goto IL_0b0d;
																		IL_0a63:
																		if (26 <= b)
																		{
																			goto IL_0a6e;
																		}
																		goto IL_0a8a;
																		IL_0a6e:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		goto end_IL_048d;
																		IL_0a8a:
																		if (25 < b)
																		{
																			break;
																		}
																		goto IL_0a98;
																		IL_0a98:
																		if (25 > b)
																		{
																			break;
																		}
																		goto IL_0aa6;
																		IL_0aa6:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0ae6;
																		IL_0ae6:
																		array[num6 - 2] = 3;
																		goto IL_0afa;
																		IL_0afa:
																		num6--;
																		goto end_IL_048d;
																		IL_0b0d:
																		if (27 < b)
																		{
																			break;
																		}
																		goto IL_0b1b;
																		IL_0b1b:
																		if (27 <= b)
																		{
																			num = 116;
																		}
																		break;
																		IL_0fb8:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0b37:
																		if (24 > b)
																		{
																			goto IL_0b45;
																		}
																		goto IL_0c3f;
																		IL_0b45:
																		if (22 >= b)
																		{
																			goto IL_0b50;
																		}
																		goto IL_0bc4;
																		IL_0b50:
																		if (22 > b)
																		{
																			break;
																		}
																		goto IL_0b5e;
																		IL_0b5e:
																		array[num6 - 1] = 0;
																		goto IL_0b72;
																		IL_0b72:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0bb1;
																		IL_0bb1:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0bc4:
																		if (23 < b)
																		{
																			break;
																		}
																		goto IL_0bd2;
																		IL_0bd2:
																		if (23 > b)
																		{
																			break;
																		}
																		goto IL_0be0;
																		IL_0be0:
																		array[num6 - 1] = 5;
																		goto IL_0bf4;
																		IL_0bf4:
																		array2[num6 - 1] = ((delegate*<Component, Rigidbody>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 1]);
																		goto IL_0c2c;
																		IL_0c2c:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0c3f:
																		((delegate*<Rigidbody, bool, void>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																		goto IL_0c7d;
																		IL_0c7d:
																		num6 -= 2;
																		num = 30;
																		goto IL_0c94;
																		IL_0c94:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0ca7:
																		if (21 <= b)
																		{
																			goto IL_0cb2;
																		}
																		goto IL_0d19;
																		IL_0cb2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0cf2;
																		IL_0cf2:
																		array[num6 - 2] = 3;
																		goto IL_0d06;
																		IL_0d06:
																		num6--;
																		goto end_IL_048d;
																		IL_0d19:
																		if (17 >= b)
																		{
																			goto IL_0d27;
																		}
																		goto IL_0e44;
																		IL_0d27:
																		if (17 <= b)
																		{
																			goto IL_0d32;
																		}
																		goto IL_0d5d;
																		IL_0d32:
																		array2[num6] = null;
																		goto IL_0d3c;
																		IL_0d3c:
																		array[num6] = 5;
																		goto IL_0d4a;
																		IL_0d4a:
																		num6++;
																		goto end_IL_048d;
																		IL_0d5d:
																		if (15 >= b)
																		{
																			goto IL_0d68;
																		}
																		goto IL_0ddb;
																		IL_0d68:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_0d76;
																		IL_0d76:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0dc8;
																		IL_0dc8:
																		num6--;
																		goto end_IL_048d;
																		IL_0ddb:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_0de9;
																		IL_0de9:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_0df7;
																		IL_0df7:
																		array[num6] = 5;
																		goto IL_0e05;
																		IL_0e05:
																		array2[num6] = ((delegate*<GTPlayer>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])();
																		goto IL_0e23;
																		IL_0e23:
																		num6++;
																		goto IL_0e31;
																		IL_0e31:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0e44:
																		if (19 >= b)
																		{
																			goto IL_0e52;
																		}
																		goto IL_0f4f;
																		IL_0e52:
																		if (19 > b)
																		{
																			goto IL_0e60;
																		}
																		goto IL_0efe;
																		IL_0e60:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_0e6e;
																		IL_0e6e:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0e7c;
																		IL_0e7c:
																		array[num6 - 2] = 0;
																		goto IL_0e90;
																		IL_0e90:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DictionaryEnumeratorFreeNamedDataSlot[*(int*)(ptr2 + num3)])((GTPlayer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																		goto IL_0edd;
																		IL_0edd:
																		num6--;
																		goto IL_0eeb;
																		IL_0eeb:
																		ptr2 += 8;
																		goto end_IL_048d;
																		IL_0efe:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0f17;
																		IL_0f17:
																		array[num6] = 3;
																		num = 224;
																		goto IL_0f2e;
																		IL_0f2e:
																		num6++;
																		goto IL_0f3c;
																		IL_0f3c:
																		ptr2 += 16;
																		goto end_IL_048d;
																		IL_0f4f:
																		if (20 < b)
																		{
																			break;
																		}
																		goto IL_0f5a;
																		IL_0f5a:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_0f65;
																		IL_0f65:
																		array[num6 - 1] = 3;
																		goto IL_0f79;
																	}
																	break;
																	IL_045a:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_048d;
															continue;
															end_IL_046d:
															break;
														}
														continue;
														end_IL_047d:
														break;
													}
													continue;
													end_IL_048d:
													break;
												}
												continue;
												end_IL_0fdb:
												break;
											}
											continue;
											end_IL_0fee:
											break;
										}
										continue;
										end_IL_0ff8:
										break;
									}
									continue;
									end_IL_1003:
									break;
								}
								continue;
								end_IL_1013:
								break;
							}
							continue;
							end_IL_1023:
							break;
						}
						continue;
						end_IL_1033:
						break;
					}
					continue;
					end_IL_104c:
					break;
				}
				continue;
				end_IL_105c:
				break;
			}
		}
	}

	public Class194()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int LookForMyCallersCallerObjectCloneHelper(int int_1, int int_2)
	{
		return smethod_8(int_1, int_2);
	}

	private static int DESCryptoServiceProvidergetDefaultRequestSet(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static float getRestrictedMemberAccessStartNew(ref Vector3 vector3_0)
	{
		return vector3_0.magnitude;
	}

	private static void BuiltInPermissionFlagNoContext(Rigidbody rigidbody_0, bool bool_2)
	{
		rigidbody_0.useGravity = bool_2;
	}

	private unsafe static int smethod_12(int int_1)
	{
		int num = 106;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DebuggerTypeProxyAttributeLoaderInformation.FoundDatePatternGetMany);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 20;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02a1:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0281:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0274:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0264:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0254:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0224:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_01f6:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 117;
																														while (true)
																														{
																															if (num != 117)
																															{
																																if (num != 1098)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 72:
																																	goto IL_01f6;
																																case 19:
																																case 61:
																																	goto IL_0224;
																																case 26:
																																	goto IL_0234;
																																case 9:
																																	goto IL_0244;
																																case 24:
																																	goto IL_0254;
																																case 15:
																																	goto IL_0264;
																																case 4:
																																	goto IL_0274;
																																case 74:
																																	goto IL_0281;
																																case 31:
																																	goto IL_0291;
																																case 38:
																																	goto IL_02a1;
																																case 20:
																																	goto end_IL_02a1;
																																case 73:
																																case 99:
																																	goto end_IL_02b1;
																																case 45:
																																case 56:
																																	goto IL_02d5;
																																case 48:
																																	goto IL_031e;
																																case 37:
																																	goto IL_0332;
																																case 28:
																																	goto IL_0358;
																																case 95:
																																	goto IL_0366;
																																case 89:
																																	goto IL_0379;
																																case 75:
																																	goto IL_038c;
																																case 11:
																																case 52:
																																	goto IL_0397;
																																case 90:
																																	goto IL_03b8;
																																case 3:
																																	goto IL_03cc;
																																case 68:
																																case 71:
																																	goto IL_03da;
																																case 79:
																																	goto IL_03f3;
																																case 94:
																																	goto IL_0401;
																																case 96:
																																	goto IL_040f;
																																case 107:
																																	goto IL_0422;
																																case 54:
																																	goto IL_0430;
																																case 13:
																																case 88:
																																	goto IL_043b;
																																case 43:
																																	goto IL_0464;
																																case 5:
																																	goto IL_0472;
																																case 58:
																																case 82:
																																	goto IL_049c;
																																case 77:
																																	goto IL_04aa;
																																case 47:
																																	goto IL_04b8;
																																case 0:
																																case 103:
																																	goto IL_04c3;
																																case 27:
																																	goto IL_04d1;
																																case 39:
																																case 53:
																																	goto IL_04df;
																																case 102:
																																	goto IL_0502;
																																case 23:
																																	goto IL_0510;
																																case 108:
																																	goto IL_051e;
																																case 98:
																																	goto IL_0531;
																																case 16:
																																case 86:
																																	goto IL_053f;
																																case 25:
																																	goto IL_057f;
																																case 57:
																																	goto IL_0593;
																																case 64:
																																case 104:
																																	goto IL_05a6;
																																case 12:
																																	goto IL_0608;
																																case 70:
																																	goto IL_0618;
																																case 46:
																																	goto IL_0623;
																																case 65:
																																	goto IL_062e;
																																case 51:
																																	goto IL_0644;
																																case 6:
																																case 100:
																																	goto end_IL_01e3;
																																case 10:
																																case 14:
																																case 18:
																																case 21:
																																case 29:
																																case 30:
																																case 33:
																																case 34:
																																case 49:
																																case 55:
																																case 59:
																																case 60:
																																case 63:
																																case 66:
																																case 67:
																																case 78:
																																case 84:
																																case 92:
																																case 97:
																																case 101:
																																case 109:
																																	goto end_IL_0234;
																																case 2:
																																case 22:
																																case 32:
																																case 41:
																																case 44:
																																case 50:
																																case 80:
																																case 81:
																																case 83:
																																case 85:
																																case 87:
																																case 91:
																																case 93:
																																case 110:
																																	goto end_IL_02c1;
																																case 76:
																																	goto end_IL_0684;
																																case 62:
																																	goto end_IL_0697;
																																case 36:
																																	goto end_IL_06a1;
																																case 69:
																																	goto end_IL_06ac;
																																case 8:
																																case 40:
																																	goto end_IL_06c1;
																																case 17:
																																	goto end_IL_06d1;
																																case 35:
																																case 42:
																																	goto end_IL_06e1;
																																case 105:
																																	goto end_IL_06f1;
																																case 106:
																																	goto end_IL_0701;
																																case 1:
																																case 7:
																																	goto IL_071c;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_0358;
																															IL_0358:
																															num5++;
																															goto IL_0366;
																															IL_0366:
																															ptr2 += 8;
																															goto end_IL_02c1;
																															continue;
																															end_IL_01e3:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_064f;
																												continue;
																												end_IL_0234:
																												break;
																												IL_0234:;
																											}
																											break;
																											IL_0244:;
																										}
																										break;
																									}
																									goto IL_0379;
																									IL_0379:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02c1;
																								}
																								break;
																							}
																							goto IL_038c;
																							IL_0464:
																							ptr2 += 8;
																							goto IL_0472;
																							IL_038c:
																							if (3 <= b)
																							{
																								goto IL_0397;
																							}
																							goto IL_03b8;
																							IL_0397:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 93;
																							goto end_IL_02c1;
																							IL_03b8:
																							if (1 >= b)
																							{
																								num = 3;
																								goto IL_03cc;
																							}
																							goto IL_0422;
																							IL_0472:
																							num5--;
																							goto end_IL_02c1;
																							IL_03cc:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_03da;
																							IL_03da:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03f3;
																							IL_03f3:
																							array[num5] = 0;
																							goto IL_0401;
																							IL_0401:
																							num5++;
																							goto IL_040f;
																							IL_040f:
																							ptr2 += 8;
																							goto end_IL_02c1;
																							IL_0422:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0430;
																							IL_0430:
																							if (2 > b)
																							{
																								num = 21;
																								break;
																							}
																							goto IL_043b;
																							IL_043b:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0464;
																						}
																						break;
																					}
																					goto IL_02d5;
																					IL_0332:
																					num5--;
																					num = 81;
																					goto end_IL_02c1;
																					IL_02d5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 48;
																					goto IL_031e;
																					IL_031e:
																					array[num5 - 2] = 0;
																					goto IL_0332;
																				}
																				break;
																			}
																			num = 82;
																			goto IL_049c;
																			IL_064f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02c1;
																			IL_0644:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_064f;
																			IL_049c:
																			if (9 >= b)
																			{
																				goto IL_04aa;
																			}
																			goto IL_0618;
																			IL_04aa:
																			if (9 > b)
																			{
																				goto IL_04b8;
																			}
																			goto IL_05a6;
																			IL_04b8:
																			if (7 < b)
																			{
																				goto IL_04c3;
																			}
																			goto IL_0531;
																			IL_04c3:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_04d1;
																			IL_04d1:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04df;
																			IL_04df:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0502;
																			IL_0502:
																			array[num5] = 0;
																			goto IL_0510;
																			IL_0510:
																			num5++;
																			goto IL_051e;
																			IL_051e:
																			ptr2 += 8;
																			goto end_IL_02c1;
																			IL_0531:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_053f;
																			IL_053f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_057f;
																			IL_057f:
																			array[num5 - 2] = 0;
																			goto IL_0593;
																			IL_0593:
																			num5--;
																			goto end_IL_02c1;
																			IL_05a6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0608;
																			IL_0608:
																			num5 -= 2;
																			goto end_IL_02c1;
																			IL_0618:
																			if (10 < b)
																			{
																				goto IL_0623;
																			}
																			num = 51;
																			goto IL_0644;
																			IL_0623:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_062e;
																			IL_062e:
																			if (11 <= b)
																			{
																			}
																			break;
																		}
																		break;
																		IL_0291:;
																	}
																}
																else
																{
																	num = 66;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02c1;
																continue;
																end_IL_02a1:
																break;
															}
															continue;
															end_IL_02b1:
															break;
														}
														continue;
														end_IL_02c1:
														break;
													}
													continue;
												}
												goto IL_071c;
												IL_071c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0684:
												break;
											}
											continue;
											end_IL_0697:
											break;
										}
										continue;
										end_IL_06a1:
										break;
									}
									continue;
									end_IL_06ac:
									break;
								}
								continue;
								end_IL_06c1:
								break;
							}
							continue;
							end_IL_06d1:
							break;
						}
						continue;
						end_IL_06e1:
						break;
					}
					continue;
					end_IL_06f1:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private static SphereCollider AccessAllowedCallbackMuiResourceTypeIdStringEntry(GTPlayer gtplayer_0)
	{
		return gtplayer_0.headCollider;
	}

	private static void UsersgetDeploymentFlags(Class194 class194_1)
	{
		class194_1.method_1();
	}

	static Class194()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 15;
					while (true)
					{
						if (num == 15 || num != 996)
						{
							return;
						}
						switch (num)
						{
						case 2:
						case 3:
						case 6:
						case 8:
							goto end_IL_0045;
						case 0:
							goto end_IL_0052;
						case 1:
							goto end_IL_0067;
						case 4:
							return;
						case 5:
							return;
						case 7:
							return;
						}
						continue;
						end_IL_0045:
						break;
					}
					continue;
					end_IL_0052:
					break;
				}
				continue;
				end_IL_0067:
				break;
			}
		}
	}
}
