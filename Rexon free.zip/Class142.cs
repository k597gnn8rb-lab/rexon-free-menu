using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti Anticheat Report", "Safety", "Blocks anticheat from sending reports about you.", false, 14, ModType.const_0, false)]
internal class Class142 : MonoBehaviour
{
	public static bool bool_0;

	private static float float_0;

	private static double double_0;

	private static double double_1;

	private static bool bool_1;

	private static double double_2;

	private static bool bool_2;

	private static bool bool_3;

	private static IntPtr[] HostProtectionAttributeIdentityReferenceCollection;

	private static IntPtr[] EventWaitHandleResponseXmlNamespace;

	private unsafe void OnEnable()
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CommonNumberSeparatorOpenRemoteBaseKey.IsolatedStorageFilePermissionPropertyType);
									while (true)
									{
										byte* ptr2 = ptr;
										num = 41;
										while (true)
										{
											num = 99;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 140;
														while (true)
														{
															if (num != 140)
															{
																if (num != 1121)
																{
																	goto IL_04c7;
																}
																switch (num)
																{
																case 9:
																case 59:
																	goto end_IL_023f;
																case 115:
																	goto IL_0271;
																case 0:
																	goto IL_027f;
																case 79:
																	goto IL_028d;
																case 14:
																	goto IL_029b;
																case 26:
																case 31:
																	goto IL_02a6;
																case 124:
																	goto IL_02e6;
																case 88:
																	goto IL_02fa;
																case 50:
																	goto IL_030d;
																case 32:
																	goto IL_031b;
																case 8:
																	goto IL_0329;
																case 2:
																case 116:
																	goto IL_0337;
																case 92:
																	goto IL_0345;
																case 36:
																case 42:
																	goto IL_0353;
																case 98:
																	goto IL_0361;
																case 30:
																	goto IL_038d;
																case 96:
																	goto IL_0397;
																case 95:
																	goto IL_03a5;
																case 46:
																case 127:
																	goto IL_03b8;
																case 55:
																	goto IL_03f8;
																case 21:
																	goto IL_040c;
																case 12:
																case 81:
																	goto IL_041f;
																case 71:
																	goto IL_042d;
																case 113:
																case 131:
																	goto IL_043b;
																case 102:
																	goto IL_047b;
																case 20:
																	goto IL_048f;
																case 121:
																	goto IL_04ab;
																case 43:
																case 84:
																	goto IL_04b9;
																case 4:
																case 27:
																	goto IL_04c7;
																case 120:
																	goto IL_04d5;
																case 3:
																case 44:
																	goto IL_04e3;
																case 111:
																	goto IL_0523;
																case 62:
																	goto IL_0537;
																case 57:
																	goto IL_054a;
																case 60:
																case 77:
																	goto IL_055d;
																case 17:
																	goto IL_0586;
																case 29:
																	goto IL_0594;
																case 119:
																	goto IL_05a7;
																case 128:
																	goto IL_05b5;
																case 80:
																case 106:
																	goto IL_05c0;
																case 83:
																	goto IL_0622;
																case 33:
																	goto IL_0635;
																case 47:
																	goto IL_0640;
																case 35:
																case 61:
																	goto IL_064e;
																case 40:
																case 52:
																	goto IL_066a;
																case 100:
																	goto IL_0678;
																case 5:
																case 85:
																	goto IL_0686;
																case 112:
																	goto IL_06c6;
																case 16:
																	goto IL_06da;
																case 18:
																	goto IL_06ed;
																case 6:
																case 103:
																	goto IL_06f8;
																case 101:
																	goto IL_0703;
																case 72:
																case 133:
																	goto IL_070e;
																case 122:
																	goto IL_072a;
																case 89:
																case 129:
																	goto IL_0735;
																case 97:
																	goto IL_074f;
																case 130:
																	goto IL_075f;
																case 7:
																	goto IL_076a;
																case 1:
																case 11:
																case 13:
																case 19:
																case 23:
																case 24:
																case 28:
																case 34:
																case 37:
																case 45:
																case 48:
																case 49:
																case 51:
																case 56:
																case 58:
																case 63:
																case 68:
																case 69:
																case 73:
																case 76:
																case 78:
																case 82:
																case 86:
																case 87:
																case 108:
																case 123:
																case 125:
																	goto IL_0775;
																case 118:
																	goto IL_078e;
																case 54:
																	goto IL_079c;
																case 66:
																	goto IL_07b3;
																case 10:
																case 22:
																case 38:
																case 39:
																case 53:
																case 64:
																case 65:
																case 90:
																case 91:
																case 94:
																case 99:
																case 104:
																case 105:
																case 117:
																case 132:
																	goto end_IL_024f;
																case 41:
																	goto end_IL_07c1;
																case 70:
																	goto end_IL_07d4;
																case 126:
																	goto end_IL_07df;
																case 114:
																	goto end_IL_07f2;
																case 25:
																case 67:
																	goto end_IL_07fd;
																case 15:
																	goto end_IL_080d;
																case 107:
																case 110:
																	goto end_IL_081d;
																case 74:
																	goto end_IL_082d;
																case 75:
																	goto end_IL_083d;
																case 93:
																case 109:
																	return;
																}
																continue;
															}
															ptr2++;
															goto IL_0271;
															IL_0775:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_078e;
															IL_079c:
															num5++;
															num = 66;
															goto IL_07b3;
															IL_078e:
															array[num5] = 0;
															goto IL_079c;
															IL_0271:
															if (b >= 1)
															{
																goto IL_027f;
															}
															goto IL_0775;
															IL_027f:
															if (b <= 13)
															{
																goto IL_028d;
															}
															goto IL_0775;
															IL_028d:
															if (7 >= b)
															{
																goto IL_029b;
															}
															goto IL_05a7;
															IL_029b:
															if (7 <= b)
															{
																goto IL_02a6;
															}
															goto IL_030d;
															IL_02a6:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_02e6;
															IL_02e6:
															array[num5 - 2] = 0;
															goto IL_02fa;
															IL_02fa:
															num5--;
															goto end_IL_024f;
															IL_030d:
															if (3 < b)
															{
																goto IL_031b;
															}
															goto IL_04ab;
															IL_031b:
															if (5 >= b)
															{
																goto IL_0329;
															}
															goto IL_041f;
															IL_0329:
															if (5 > b)
															{
																goto IL_0337;
															}
															goto IL_03b8;
															IL_0337:
															if (4 >= b)
															{
																goto IL_0345;
															}
															goto IL_0775;
															IL_0345:
															if (4 <= b)
															{
																goto IL_0353;
															}
															goto IL_0775;
															IL_0353:
															array[num5] = 0;
															goto IL_0361;
															IL_0361:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															num = 30;
															goto IL_038d;
															IL_038d:
															array2[num5] = null;
															goto IL_0397;
															IL_0397:
															num5++;
															goto IL_03a5;
															IL_03a5:
															ptr2 += 8;
															goto end_IL_024f;
															IL_03b8:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_03f8;
															IL_03f8:
															array[num5 - 2] = 0;
															goto IL_040c;
															IL_040c:
															num5--;
															goto end_IL_024f;
															IL_041f:
															if (6 >= b)
															{
																goto IL_042d;
															}
															goto IL_0775;
															IL_042d:
															if (6 <= b)
															{
																goto IL_043b;
															}
															goto IL_0775;
															IL_043b:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_047b;
															IL_047b:
															array[num5 - 2] = 0;
															goto IL_048f;
															IL_048f:
															num5--;
															num = 65;
															goto end_IL_024f;
															IL_04ab:
															if (3 > b)
															{
																goto IL_04b9;
															}
															goto IL_055d;
															IL_04b9:
															if (1 < b)
															{
																goto IL_04c7;
															}
															goto IL_054a;
															IL_04c7:
															if (2 >= b)
															{
																goto IL_04d5;
															}
															goto IL_0775;
															IL_04d5:
															if (2 <= b)
															{
																goto IL_04e3;
															}
															goto IL_0775;
															IL_04e3:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0523;
															IL_0523:
															array[num5 - 2] = 0;
															goto IL_0537;
															IL_0537:
															num5--;
															goto end_IL_024f;
															IL_054a:
															if (1 <= b)
															{
															}
															goto IL_0775;
															IL_055d:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0586;
															IL_0586:
															ptr2 += 8;
															goto IL_0594;
															IL_0594:
															num5--;
															goto end_IL_024f;
															IL_05a7:
															if (10 >= b)
															{
																goto IL_05b5;
															}
															goto IL_06ed;
															IL_05b5:
															if (10 <= b)
															{
																goto IL_05c0;
															}
															goto IL_0635;
															IL_05c0:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0622;
															IL_0622:
															num5 -= 2;
															goto end_IL_024f;
															IL_0635:
															if (8 >= b)
															{
																goto IL_0640;
															}
															num = 52;
															goto IL_066a;
															IL_0640:
															if (8 <= b)
															{
																goto IL_064e;
															}
															goto IL_0775;
															IL_064e:
															num5--;
															goto end_IL_024f;
															IL_07b3:
															ptr2 += 8;
															goto end_IL_024f;
															IL_066a:
															if (9 >= b)
															{
																goto IL_0678;
															}
															goto IL_0775;
															IL_0678:
															if (9 <= b)
															{
																goto IL_0686;
															}
															goto IL_0775;
															IL_0686:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_06c6;
															IL_06c6:
															array[num5 - 2] = 0;
															goto IL_06da;
															IL_06da:
															num5--;
															goto end_IL_024f;
															IL_06ed:
															if (12 < b)
															{
																goto IL_06f8;
															}
															goto IL_072a;
															IL_06f8:
															if (13 >= b)
															{
																goto IL_0703;
															}
															goto IL_0775;
															IL_0703:
															if (13 <= b)
															{
																goto IL_070e;
															}
															goto IL_0775;
															IL_070e:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto end_IL_024f;
															IL_072a:
															if (12 <= b)
															{
																goto IL_0735;
															}
															goto IL_075f;
															IL_0735:
															bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
															goto IL_074f;
															IL_074f:
															num5--;
															goto end_IL_024f;
															IL_075f:
															if (11 >= b)
															{
																goto IL_076a;
															}
															goto IL_0775;
															IL_076a:
															if (11 <= b)
															{
																goto end_IL_024f;
															}
															goto IL_0775;
															continue;
															end_IL_023f:
															break;
														}
														continue;
														end_IL_024f:
														break;
													}
													continue;
												}
												num = 109;
												return;
												continue;
												end_IL_07c1:
												break;
											}
											continue;
											end_IL_07d4:
											break;
										}
										continue;
										end_IL_07df:
										break;
									}
									continue;
									end_IL_07f2:
									break;
								}
								continue;
								end_IL_07fd:
								break;
							}
							continue;
							end_IL_080d:
							break;
						}
						continue;
						end_IL_081d:
						break;
					}
					continue;
					end_IL_082d:
					break;
				}
				continue;
				end_IL_083d:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 94;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsStaticRegistrationClassContext.IgnoreReturnCreateOaep);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													num = 82;
													while (true)
													{
														IL_02d9:
														if (b >= 1)
														{
															while (b <= 14)
															{
																while (true)
																{
																	IL_02b9:
																	if (7 < b)
																	{
																		while (true)
																		{
																			IL_02a9:
																			if (11 >= b)
																			{
																				while (true)
																				{
																					IL_0299:
																					if (11 > b)
																					{
																						while (true)
																						{
																							IL_0289:
																							if (9 >= b)
																							{
																								num = 89;
																								while (true)
																								{
																									IL_0276:
																									if (9 <= b)
																									{
																										num = 142;
																										while (true)
																										{
																											if (num != 142)
																											{
																												if (num != 1123)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 89:
																													goto IL_0276;
																												case 70:
																													goto IL_0289;
																												case 3:
																													goto IL_0299;
																												case 134:
																													goto IL_02a9;
																												case 67:
																													goto IL_02b9;
																												case 76:
																													goto end_IL_02b9;
																												case 82:
																													goto IL_02d9;
																												case 114:
																													goto end_IL_02d9;
																												case 25:
																												case 125:
																													goto end_IL_02e9;
																												case 19:
																													goto IL_030d;
																												case 43:
																													goto IL_031d;
																												case 35:
																													goto IL_032b;
																												case 2:
																												case 77:
																													goto IL_0339;
																												case 79:
																													goto IL_0355;
																												case 64:
																													goto IL_0363;
																												case 98:
																													goto IL_0376;
																												case 86:
																												case 104:
																													goto IL_0384;
																												case 5:
																													goto IL_03e6;
																												case 105:
																													goto IL_0402;
																												case 8:
																												case 37:
																													goto IL_040d;
																												case 21:
																													goto IL_041b;
																												case 109:
																													goto IL_0437;
																												case 23:
																												case 30:
																													goto IL_0445;
																												case 13:
																													goto IL_0453;
																												case 65:
																												case 101:
																													goto IL_0461;
																												case 107:
																													goto IL_046f;
																												case 57:
																													goto IL_0492;
																												case 45:
																													goto IL_049c;
																												case 18:
																													goto IL_04aa;
																												case 26:
																												case 117:
																													goto IL_04bd;
																												case 74:
																													goto end_IL_0263;
																												case 118:
																													goto IL_051f;
																												case 9:
																												case 49:
																													goto IL_052d;
																												case 92:
																													goto IL_0538;
																												case 87:
																													goto IL_0554;
																												case 110:
																													goto IL_0562;
																												case 1:
																												case 60:
																													goto IL_0570;
																												case 71:
																													goto IL_05b0;
																												case 113:
																													goto IL_05c4;
																												case 91:
																												case 127:
																													goto IL_05d7;
																												case 115:
																													goto IL_0600;
																												case 56:
																													goto IL_060e;
																												case 20:
																												case 129:
																													goto IL_0621;
																												case 85:
																													goto IL_0638;
																												case 31:
																													goto IL_065c;
																												case 40:
																													goto IL_066a;
																												case 6:
																												case 130:
																													goto IL_067d;
																												case 90:
																													goto IL_06bd;
																												case 27:
																													goto IL_06d1;
																												case 131:
																													goto IL_06e4;
																												case 17:
																												case 132:
																													goto IL_06f7;
																												case 133:
																													goto IL_0737;
																												case 123:
																													goto IL_074b;
																												case 11:
																													goto IL_075e;
																												case 80:
																													goto IL_079e;
																												case 100:
																													goto IL_07b2;
																												case 0:
																													goto IL_07ce;
																												case 10:
																													goto IL_07d9;
																												case 66:
																												case 78:
																													goto IL_07e4;
																												case 135:
																													goto IL_07fa;
																												case 59:
																												case 99:
																													goto IL_080a;
																												case 73:
																													goto IL_0824;
																												case 38:
																													goto IL_0834;
																												case 22:
																													goto IL_083f;
																												case 116:
																												case 122:
																													goto IL_0853;
																												case 4:
																												case 29:
																												case 44:
																												case 46:
																												case 53:
																												case 54:
																												case 55:
																												case 61:
																												case 68:
																												case 69:
																												case 72:
																												case 81:
																												case 83:
																												case 95:
																												case 96:
																												case 102:
																												case 103:
																												case 106:
																												case 108:
																												case 112:
																												case 120:
																												case 121:
																												case 124:
																													goto end_IL_02c9;
																												case 34:
																													goto IL_0885;
																												case 84:
																													goto IL_0893;
																												case 28:
																													goto IL_08a1;
																												case 14:
																												case 15:
																												case 16:
																												case 24:
																												case 32:
																												case 36:
																												case 39:
																												case 41:
																												case 42:
																												case 48:
																												case 51:
																												case 52:
																												case 58:
																												case 62:
																												case 63:
																												case 88:
																												case 111:
																													goto end_IL_0302;
																												case 33:
																													goto end_IL_08af;
																												case 12:
																													goto end_IL_08bf;
																												case 97:
																													goto end_IL_08c9;
																												case 7:
																												case 126:
																													goto end_IL_08d4;
																												case 119:
																													goto end_IL_08e4;
																												case 47:
																												case 128:
																													goto end_IL_08f4;
																												case 93:
																													goto end_IL_0904;
																												case 94:
																													goto end_IL_0914;
																												case 50:
																												case 75:
																													return;
																												}
																												continue;
																											}
																											goto IL_075e;
																											IL_079e:
																											array[num5 - 2] = 0;
																											goto IL_07b2;
																											IL_07b2:
																											num5--;
																											num = 58;
																											goto end_IL_0302;
																											IL_075e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_079e;
																											continue;
																											end_IL_0263:
																											break;
																										}
																										break;
																									}
																									goto IL_031d;
																									IL_032b:
																									if (8 > b)
																									{
																										goto end_IL_02c9;
																									}
																									goto IL_0339;
																									IL_0339:
																									num5--;
																									num = 15;
																									goto end_IL_0302;
																									IL_031d:
																									if (8 < b)
																									{
																										goto end_IL_02c9;
																									}
																									goto IL_032b;
																								}
																								break;
																							}
																							goto IL_030d;
																							IL_0384:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03e6;
																							IL_03e6:
																							num5 -= 2;
																							num = 14;
																							goto end_IL_0302;
																							IL_030d:
																							if (10 < b)
																							{
																								goto end_IL_02c9;
																							}
																							goto IL_0376;
																							IL_0376:
																							if (10 > b)
																							{
																								goto end_IL_02c9;
																							}
																							goto IL_0384;
																						}
																						break;
																					}
																					goto IL_0621;
																					IL_066a:
																					ptr2 += 8;
																					goto end_IL_0302;
																					IL_0621:
																					array[num5] = 0;
																					num = 85;
																					goto IL_0638;
																					IL_0638:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)HostProtectionAttributeIdentityReferenceCollection[*(int*)(ptr2 + num3)])();
																					goto IL_065c;
																					IL_065c:
																					num5++;
																					goto IL_066a;
																				}
																				break;
																			}
																			goto IL_07ce;
																			IL_083f:
																			if (14 > b)
																			{
																				goto end_IL_02c9;
																			}
																			num = 122;
																			goto IL_0853;
																			IL_07ce:
																			if (13 >= b)
																			{
																				goto IL_07d9;
																			}
																			goto IL_0834;
																			IL_07d9:
																			if (13 > b)
																			{
																				goto IL_07e4;
																			}
																			goto IL_080a;
																			IL_07e4:
																			if (12 < b)
																			{
																				num = 46;
																				goto end_IL_02c9;
																			}
																			goto IL_07fa;
																			IL_0853:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0302;
																			IL_07fa:
																			if (12 > b)
																			{
																				goto end_IL_02c9;
																			}
																			goto end_IL_0302;
																			IL_080a:
																			bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0824;
																			IL_0824:
																			num5--;
																			goto end_IL_0302;
																			IL_0834:
																			if (14 < b)
																			{
																				goto end_IL_02c9;
																			}
																			goto IL_083f;
																		}
																		goto IL_04fd;
																	}
																	goto IL_0355;
																	IL_04bd:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04fd;
																	IL_0355:
																	if (7 > b)
																	{
																		goto IL_0363;
																	}
																	goto IL_04bd;
																	IL_0363:
																	if (3 < b)
																	{
																		goto IL_0402;
																	}
																	goto IL_051f;
																	IL_051f:
																	if (3 > b)
																	{
																		goto IL_052d;
																	}
																	goto IL_05d7;
																	IL_052d:
																	if (1 >= b)
																	{
																		goto IL_0538;
																	}
																	goto IL_0554;
																	IL_0538:
																	if (1 > b)
																	{
																		num = 81;
																	}
																	goto end_IL_02c9;
																	IL_04fd:
																	array[num5 - 2] = 0;
																	num = 131;
																	goto IL_06e4;
																	IL_0554:
																	if (2 < b)
																	{
																		goto end_IL_02c9;
																	}
																	goto IL_0562;
																	IL_0562:
																	if (2 > b)
																	{
																		goto end_IL_02c9;
																	}
																	goto IL_0570;
																	IL_0570:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05b0;
																	IL_05b0:
																	array[num5 - 2] = 0;
																	goto IL_05c4;
																	IL_05c4:
																	num5--;
																	goto end_IL_0302;
																	IL_05d7:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0600;
																	IL_0600:
																	ptr2 += 8;
																	goto IL_060e;
																	IL_060e:
																	num5--;
																	goto end_IL_0302;
																	IL_0402:
																	if (5 < b)
																	{
																		goto IL_040d;
																	}
																	goto IL_0437;
																	IL_040d:
																	if (6 < b)
																	{
																		goto end_IL_02c9;
																	}
																	goto IL_041b;
																	IL_041b:
																	if (6 > b)
																	{
																		num = 72;
																		goto end_IL_02c9;
																	}
																	goto IL_06f7;
																	IL_06e4:
																	num5--;
																	goto end_IL_0302;
																	IL_06f7:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0737;
																	IL_0737:
																	array[num5 - 2] = 0;
																	goto IL_074b;
																	IL_074b:
																	num5--;
																	goto end_IL_0302;
																	IL_0437:
																	if (5 > b)
																	{
																		goto IL_0445;
																	}
																	goto IL_067d;
																	IL_0445:
																	if (4 < b)
																	{
																		goto end_IL_02c9;
																	}
																	goto IL_0453;
																	IL_0453:
																	if (4 > b)
																	{
																		goto end_IL_02c9;
																	}
																	goto IL_0461;
																	IL_0461:
																	array[num5] = 0;
																	goto IL_046f;
																	IL_046f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0492;
																	IL_0492:
																	array2[num5] = null;
																	goto IL_049c;
																	IL_049c:
																	num5++;
																	goto IL_04aa;
																	IL_04aa:
																	ptr2 += 8;
																	goto end_IL_0302;
																	IL_067d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_06bd;
																	IL_06bd:
																	array[num5 - 2] = 0;
																	goto IL_06d1;
																	IL_06d1:
																	num5--;
																	goto end_IL_0302;
																	continue;
																	end_IL_02b9:
																	break;
																}
																continue;
																end_IL_02c9:
																break;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_0885;
														IL_08a1:
														ptr2 += 8;
														goto end_IL_0302;
														IL_0893:
														num5++;
														goto IL_08a1;
														IL_0885:
														array[num5] = 0;
														goto IL_0893;
														continue;
														end_IL_02d9:
														break;
													}
													continue;
													end_IL_02e9:
													break;
												}
												continue;
												end_IL_0302:
												break;
											}
											continue;
											end_IL_08af:
											break;
										}
										continue;
										end_IL_08bf:
										break;
									}
									continue;
									end_IL_08c9:
									break;
								}
								continue;
								end_IL_08d4:
								break;
							}
							continue;
							end_IL_08e4:
							break;
						}
						continue;
						end_IL_08f4:
						break;
					}
					continue;
					end_IL_0904:
					break;
				}
				continue;
				end_IL_0914:
				break;
			}
		}
	}

	public Class142()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		num += num2;
		int num3 = num;
		num = int_0;
		num2 = int_1;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 180;
		num2 = 36;
		return num + 36;
	}

	private static int smethod_1(int int_0)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_0;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 29;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									num = 52;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref COMExceptionopLessThan.VolatileWriteDivide);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_026d:
														byte b = *ptr2;
														while (true)
														{
															IL_025d:
															ptr2++;
															while (true)
															{
																IL_024d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_022d:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0220:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0210:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_01eb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_01d6:
																									array2[num5] = null;
																									num = 109;
																									while (true)
																									{
																										if (num != 109)
																										{
																											if (num != 1090)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 33:
																												goto IL_01d6;
																											case 72:
																												goto IL_01eb;
																											case 17:
																											case 68:
																												goto IL_0210;
																											case 41:
																												goto IL_0220;
																											case 78:
																												goto IL_022d;
																											case 0:
																												goto IL_023d;
																											case 2:
																												goto IL_024d;
																											case 101:
																												goto IL_025d;
																											case 79:
																											case 85:
																												goto IL_026d;
																											case 56:
																												goto IL_0286;
																											case 76:
																												goto IL_0299;
																											case 71:
																												goto IL_02a7;
																											case 1:
																											case 69:
																												goto IL_02b2;
																											case 26:
																												goto IL_02db;
																											case 14:
																												goto IL_02e9;
																											case 35:
																												goto IL_02fc;
																											case 100:
																												goto IL_030a;
																											case 16:
																											case 44:
																												goto IL_0323;
																											case 23:
																												goto IL_033c;
																											case 91:
																												goto IL_034a;
																											case 32:
																												goto IL_0358;
																											case 102:
																												goto IL_0374;
																											case 92:
																												goto IL_037f;
																											case 5:
																											case 63:
																												goto IL_038d;
																											case 82:
																												goto IL_03a5;
																											case 10:
																												goto IL_03b3;
																											case 21:
																												goto IL_03c6;
																											case 58:
																												goto IL_03d4;
																											case 37:
																												goto IL_03e2;
																											case 7:
																												goto IL_03ed;
																											case 83:
																											case 87:
																												goto IL_03fb;
																											case 84:
																												goto IL_043b;
																											case 20:
																												goto IL_044f;
																											case 22:
																											case 49:
																												goto IL_0462;
																											case 40:
																												goto IL_0479;
																											case 6:
																											case 27:
																												goto IL_0487;
																											case 60:
																												goto IL_04aa;
																											case 93:
																												goto IL_04b8;
																											case 48:
																												goto IL_04c6;
																											case 38:
																											case 89:
																												goto IL_04d9;
																											case 64:
																												goto IL_053b;
																											case 18:
																												goto IL_0554;
																											case 47:
																												goto IL_055f;
																											case 88:
																												goto IL_056a;
																											case 42:
																												goto IL_0580;
																											case 54:
																											case 96:
																												goto IL_058b;
																											case 3:
																											case 4:
																											case 11:
																											case 24:
																											case 39:
																											case 45:
																											case 46:
																											case 50:
																											case 53:
																											case 55:
																											case 59:
																											case 61:
																											case 65:
																											case 70:
																											case 77:
																											case 81:
																											case 86:
																											case 90:
																											case 94:
																											case 95:
																											case 97:
																												goto end_IL_023d;
																											case 9:
																											case 12:
																											case 25:
																											case 30:
																											case 31:
																											case 34:
																											case 36:
																											case 43:
																											case 66:
																											case 67:
																											case 74:
																											case 75:
																											case 98:
																												goto end_IL_01c3;
																											case 19:
																												goto end_IL_05b7;
																											case 52:
																												goto end_IL_05ca;
																											case 51:
																												goto end_IL_05d4;
																											case 13:
																												goto end_IL_05df;
																											case 15:
																											case 99:
																												goto end_IL_05fd;
																											case 73:
																												goto end_IL_060d;
																											case 62:
																											case 80:
																												goto end_IL_061d;
																											case 28:
																												goto end_IL_062d;
																											case 29:
																												goto end_IL_063d;
																											case 8:
																											case 57:
																												goto IL_0658;
																											}
																											continue;
																										}
																										num5++;
																										goto IL_0286;
																										IL_0286:
																										ptr2 += 8;
																										break;
																										continue;
																										end_IL_01c3:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0299;
																					IL_03a5:
																					if (4 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_03b3;
																					IL_0299:
																					if (2 >= b)
																					{
																						goto IL_02a7;
																					}
																					goto IL_0374;
																					IL_02a7:
																					if (2 <= b)
																					{
																						goto IL_02b2;
																					}
																					goto IL_02fc;
																					IL_02b2:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02db;
																					IL_02db:
																					ptr2 += 8;
																					goto IL_02e9;
																					IL_02e9:
																					num5--;
																					break;
																					IL_02fc:
																					if (1 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_030a;
																					IL_030a:
																					if (1 > b)
																					{
																						num = 53;
																						goto end_IL_023d;
																					}
																					goto IL_0323;
																					IL_03b3:
																					if (4 > b)
																					{
																						goto end_IL_023d;
																					}
																					break;
																					IL_0323:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_033c;
																					IL_033c:
																					array[num5] = 0;
																					goto IL_034a;
																					IL_034a:
																					num5++;
																					goto IL_0358;
																					IL_0358:
																					ptr2 += 8;
																					num = 36;
																					break;
																					IL_0374:
																					if (3 >= b)
																					{
																						goto IL_037f;
																					}
																					goto IL_03a5;
																					IL_037f:
																					if (3 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_038d;
																					IL_038d:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																				}
																				break;
																			}
																			goto IL_03c6;
																			IL_058b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_03c6:
																			if (8 >= b)
																			{
																				goto IL_03d4;
																			}
																			goto IL_0554;
																			IL_03d4:
																			if (8 > b)
																			{
																				goto IL_03e2;
																			}
																			goto IL_04d9;
																			IL_03e2:
																			if (6 >= b)
																			{
																				goto IL_03ed;
																			}
																			goto IL_0462;
																			IL_03ed:
																			if (6 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_03fb;
																			IL_03fb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_043b;
																			IL_043b:
																			array[num5 - 2] = 0;
																			goto IL_044f;
																			IL_044f:
																			num5--;
																			break;
																			IL_0462:
																			if (7 < b)
																			{
																				goto end_IL_023d;
																			}
																			num = 40;
																			goto IL_0479;
																			IL_0580:
																			if (9 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_058b;
																			IL_0479:
																			if (7 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_0487;
																			IL_0487:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04aa;
																			IL_04aa:
																			array[num5] = 0;
																			goto IL_04b8;
																			IL_04b8:
																			num5++;
																			goto IL_04c6;
																			IL_04c6:
																			ptr2 += 8;
																			break;
																			IL_04d9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_053b;
																			IL_053b:
																			num5 -= 2;
																			num = 25;
																			break;
																			IL_0554:
																			if (9 < b)
																			{
																				goto IL_055f;
																			}
																			num = 42;
																			goto IL_0580;
																			IL_055f:
																			if (10 < b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_056a;
																			IL_056a:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_023d;
																		}
																		goto end_IL_024d;
																		continue;
																		end_IL_023d:
																		break;
																		IL_023d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_024d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0658;
												IL_0658:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b7:
												break;
											}
											continue;
											end_IL_05ca:
											break;
										}
										continue;
										end_IL_05d4:
										break;
									}
									continue;
									end_IL_05df:
									break;
								}
								continue;
								end_IL_05fd:
								break;
							}
							continue;
							end_IL_060d:
							break;
						}
						continue;
						end_IL_061d:
						break;
					}
					continue;
					end_IL_062d:
					break;
				}
				continue;
				end_IL_063d:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_0, int int_1)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 90;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getProviderNameOutputBlockSize.GetMethodsEnumRunning);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 100;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_032f:
																	if (b >= 1)
																	{
																		goto IL_01f3;
																	}
																	goto IL_0307;
																	IL_0307:
																	while (true)
																	{
																		IL_0307_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01da:
																			array[num5] = 0;
																			num = 110;
																			while (true)
																			{
																				if (num != 110)
																				{
																					if (num != 1091)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 92:
																						goto IL_01da;
																					case 65:
																						goto IL_01f3;
																					case 84:
																						goto IL_0201;
																					case 50:
																						goto IL_020c;
																					case 43:
																					case 47:
																						goto IL_021a;
																					case 17:
																					case 68:
																						goto IL_0225;
																					case 15:
																						goto IL_0233;
																					case 26:
																						goto IL_0246;
																					case 5:
																						goto IL_0262;
																					case 88:
																						goto IL_0270;
																					case 32:
																						goto IL_027b;
																					case 73:
																					case 83:
																						goto IL_0286;
																					case 24:
																						goto IL_0291;
																					case 10:
																						goto IL_02a1;
																					case 16:
																						goto IL_02b1;
																					case 30:
																					case 98:
																						goto IL_02c8;
																					case 18:
																						goto IL_02d3;
																					case 101:
																						goto IL_02e0;
																					case 7:
																						goto IL_02ee;
																					case 40:
																						goto IL_02f9;
																					case 1:
																					case 11:
																					case 14:
																					case 19:
																					case 25:
																					case 29:
																					case 31:
																					case 33:
																					case 34:
																					case 48:
																					case 49:
																					case 54:
																					case 61:
																					case 67:
																					case 71:
																					case 77:
																					case 87:
																						goto IL_0307_2;
																					case 99:
																						goto IL_032f;
																					case 100:
																						goto end_IL_032f;
																					case 8:
																					case 81:
																						goto end_IL_033f;
																					case 2:
																					case 78:
																						goto IL_0363;
																					case 37:
																					case 76:
																						goto end_IL_01c7;
																					case 53:
																					case 62:
																						goto IL_03a0;
																					case 51:
																						goto IL_03e9;
																					case 38:
																						goto IL_03fd;
																					case 23:
																					case 89:
																						goto IL_0410;
																					case 55:
																						goto IL_0439;
																					case 45:
																						goto IL_0447;
																					case 91:
																						goto IL_045a;
																					case 60:
																						goto IL_047d;
																					case 85:
																						goto IL_0487;
																					case 57:
																						goto IL_0495;
																					case 58:
																					case 96:
																						goto IL_04a8;
																					case 75:
																						goto IL_04e8;
																					case 79:
																						goto IL_04fc;
																					case 70:
																					case 97:
																						goto IL_050f;
																					case 42:
																						goto IL_054f;
																					case 59:
																						goto IL_0563;
																					case 0:
																					case 9:
																						goto IL_0576;
																					case 44:
																						goto IL_05b6;
																					case 64:
																						goto IL_05ca;
																					case 35:
																					case 103:
																						goto IL_05da;
																					case 94:
																						goto IL_05fc;
																					case 27:
																						goto IL_060a;
																					case 93:
																						goto IL_0618;
																					case 22:
																						goto IL_0636;
																					case 4:
																					case 28:
																					case 41:
																					case 56:
																					case 63:
																					case 66:
																					case 69:
																					case 72:
																					case 74:
																					case 80:
																					case 95:
																						goto end_IL_034f;
																					case 39:
																						goto end_IL_0644;
																					case 52:
																						goto end_IL_0657;
																					case 3:
																						goto end_IL_0661;
																					case 36:
																						goto end_IL_066c;
																					case 86:
																						goto end_IL_0681;
																					case 12:
																					case 90:
																						goto end_IL_0696;
																					case 13:
																						goto end_IL_06a6;
																					case 6:
																					case 102:
																						goto end_IL_06b6;
																					case 20:
																						goto end_IL_06cf;
																					case 21:
																						goto end_IL_06df;
																					case 46:
																					case 82:
																						goto IL_06fa;
																					}
																					continue;
																				}
																				num5++;
																				goto IL_0636;
																				IL_0636:
																				ptr2 += 8;
																				goto end_IL_034f;
																				continue;
																				end_IL_01c7:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_038d;
																	IL_01f3:
																	if (b <= 9)
																	{
																		goto IL_0201;
																	}
																	goto IL_0307;
																	IL_0201:
																	if (5 < b)
																	{
																		goto IL_020c;
																	}
																	num = 5;
																	goto IL_0262;
																	IL_020c:
																	if (7 < b)
																	{
																		goto IL_021a;
																	}
																	goto IL_02e0;
																	IL_021a:
																	if (8 < b)
																	{
																		goto IL_0225;
																	}
																	goto IL_0246;
																	IL_0225:
																	if (9 >= b)
																	{
																		goto IL_0233;
																	}
																	goto IL_0307;
																	IL_0233:
																	if (9 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0363;
																	IL_0363:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_034f;
																	IL_0246:
																	if (8 > b)
																	{
																		goto IL_0307;
																	}
																	num = 97;
																	goto IL_050f;
																	IL_0487:
																	num5++;
																	goto IL_0495;
																	IL_050f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_054f;
																	IL_054f:
																	array[num5 - 2] = 0;
																	goto IL_0563;
																	IL_0563:
																	num5--;
																	goto end_IL_034f;
																	IL_02e0:
																	if (7 > b)
																	{
																		goto IL_02ee;
																	}
																	goto IL_05da;
																	IL_02ee:
																	if (6 >= b)
																	{
																		goto IL_02f9;
																	}
																	goto IL_0307;
																	IL_02f9:
																	if (6 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0576;
																	IL_0576:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05b6;
																	IL_05b6:
																	array[num5 - 2] = 0;
																	goto IL_05ca;
																	IL_05ca:
																	num5--;
																	goto end_IL_034f;
																	IL_05da:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	num = 94;
																	goto IL_05fc;
																	IL_05fc:
																	array[num5] = 0;
																	goto IL_060a;
																	IL_060a:
																	num5++;
																	goto IL_0618;
																	IL_0618:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_047d:
																	array2[num5] = null;
																	goto IL_0487;
																	IL_0262:
																	if (5 > b)
																	{
																		goto IL_0270;
																	}
																	goto IL_038d;
																	IL_0270:
																	if (2 < b)
																	{
																		goto IL_027b;
																	}
																	goto IL_02b1;
																	IL_027b:
																	if (3 < b)
																	{
																		goto IL_0286;
																	}
																	goto IL_02a1;
																	IL_0286:
																	if (4 >= b)
																	{
																		goto IL_0291;
																	}
																	goto IL_0307;
																	IL_0291:
																	if (4 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_04a8;
																	IL_04a8:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04e8;
																	IL_04e8:
																	array[num5 - 2] = 0;
																	goto IL_04fc;
																	IL_04fc:
																	num5--;
																	goto end_IL_034f;
																	IL_02a1:
																	if (3 > b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0410;
																	IL_0410:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0439;
																	IL_0439:
																	ptr2 += 8;
																	goto IL_0447;
																	IL_0447:
																	num5--;
																	goto end_IL_034f;
																	IL_02b1:
																	if (2 > b)
																	{
																		num = 98;
																		goto IL_02c8;
																	}
																	goto IL_03a0;
																	IL_0495:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_02c8:
																	if (1 >= b)
																	{
																		goto IL_02d3;
																	}
																	goto IL_0307;
																	IL_02d3:
																	if (1 > b)
																	{
																	}
																	goto IL_0307;
																	IL_03a0:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 51;
																	goto IL_03e9;
																	IL_03e9:
																	array[num5 - 2] = 0;
																	goto IL_03fd;
																	IL_03fd:
																	num5--;
																	goto end_IL_034f;
																	IL_038d:
																	array[num5] = 0;
																	goto IL_045a;
																	IL_045a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_047d;
																	continue;
																	end_IL_032f:
																	break;
																}
																continue;
																end_IL_033f:
																break;
															}
															continue;
															end_IL_034f:
															break;
														}
														continue;
													}
													goto IL_06fa;
													IL_06fa:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0644:
													break;
												}
												continue;
												end_IL_0657:
												break;
											}
											continue;
											end_IL_0661:
											break;
										}
										continue;
										end_IL_066c:
										break;
									}
									continue;
									end_IL_0681:
									break;
								}
								continue;
								end_IL_0696:
								break;
							}
							continue;
							end_IL_06a6:
							break;
						}
						continue;
						end_IL_06b6:
						break;
					}
					continue;
					end_IL_06cf:
					break;
				}
				continue;
				end_IL_06df:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									num = 92;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VtableLayoutMaskMethodBody.SetCreationTimeGetConnectionInterface);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 25;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	if (b >= 1)
																	{
																		while (true)
																		{
																			if (b <= 9)
																			{
																				while (true)
																				{
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0239:
																							if (5 <= b)
																							{
																								while (true)
																								{
																									IL_0229:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_01fb:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										num = 86;
																										while (true)
																										{
																											IL_01ef:
																											array2[num5] = null;
																											while (true)
																											{
																												IL_01d6:
																												num5++;
																												num = 109;
																												while (true)
																												{
																													if (num != 109)
																													{
																														if (num != 1090)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 14:
																															goto IL_01d6;
																														case 86:
																															goto IL_01ef;
																														case 73:
																															goto IL_01fb;
																														case 16:
																														case 48:
																															goto IL_0229;
																														case 70:
																															goto IL_0239;
																														case 17:
																															goto end_IL_0239;
																														case 35:
																															goto end_IL_0246;
																														case 56:
																															goto end_IL_0256;
																														case 93:
																															goto end_IL_0266;
																														case 10:
																														case 39:
																															goto end_IL_0276;
																														case 0:
																														case 89:
																															goto IL_0291;
																														case 1:
																															goto IL_029c;
																														case 6:
																															goto end_IL_01c3;
																														case 20:
																															goto IL_02b8;
																														case 42:
																															goto IL_02cb;
																														case 22:
																															goto IL_02d6;
																														case 40:
																															goto IL_02e9;
																														case 52:
																															goto IL_02f7;
																														case 24:
																														case 67:
																															goto IL_0305;
																														case 58:
																															goto IL_0345;
																														case 78:
																															goto IL_0359;
																														case 53:
																														case 90:
																															goto IL_036c;
																														case 59:
																															goto IL_0395;
																														case 87:
																															goto IL_03a3;
																														case 71:
																														case 101:
																															goto IL_03b6;
																														case 26:
																															goto IL_03f6;
																														case 64:
																															goto IL_040a;
																														case 75:
																															goto IL_0430;
																														case 29:
																															goto IL_043e;
																														case 47:
																														case 65:
																															goto IL_044c;
																														case 82:
																															goto IL_045a;
																														case 79:
																														case 83:
																															goto IL_0468;
																														case 2:
																															goto IL_04a8;
																														case 36:
																															goto IL_04bc;
																														case 21:
																														case 38:
																															goto IL_04d8;
																														case 9:
																															goto IL_04f1;
																														case 50:
																															goto IL_04ff;
																														case 11:
																															goto IL_050d;
																														case 69:
																															goto IL_0520;
																														case 8:
																															goto IL_052b;
																														case 23:
																														case 34:
																															goto IL_0539;
																														case 44:
																															goto IL_0579;
																														case 74:
																															goto IL_058d;
																														case 77:
																															goto IL_05a0;
																														case 81:
																															goto IL_05b4;
																														case 76:
																														case 95:
																															goto IL_05bf;
																														case 5:
																														case 18:
																														case 27:
																														case 32:
																														case 33:
																														case 37:
																														case 46:
																														case 49:
																														case 51:
																														case 55:
																														case 57:
																														case 66:
																														case 80:
																														case 84:
																														case 88:
																														case 91:
																														case 97:
																														case 102:
																															goto IL_05e1;
																														case 45:
																															goto IL_0604;
																														case 19:
																															goto IL_0612;
																														case 85:
																															goto IL_0620;
																														case 25:
																														case 31:
																														case 41:
																														case 43:
																														case 60:
																														case 62:
																														case 63:
																														case 72:
																														case 94:
																														case 96:
																														case 98:
																															goto end_IL_0286;
																														case 68:
																															goto end_IL_062e;
																														case 15:
																															goto end_IL_0641;
																														case 92:
																															goto end_IL_0654;
																														case 12:
																															goto end_IL_065f;
																														case 100:
																															goto end_IL_0674;
																														case 28:
																														case 99:
																															goto end_IL_0692;
																														case 30:
																															goto end_IL_06a2;
																														case 13:
																														case 61:
																															goto end_IL_06b2;
																														case 3:
																															goto end_IL_06c2;
																														case 4:
																															goto end_IL_06d2;
																														case 7:
																														case 54:
																															goto IL_06ed;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto end_IL_0286;
																													continue;
																													end_IL_01c3:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02aa;
																							}
																							goto IL_0291;
																							IL_0359:
																							num5--;
																							goto end_IL_0286;
																							IL_0291:
																							if (2 >= b)
																							{
																								goto IL_029c;
																							}
																							goto IL_02cb;
																							IL_029c:
																							if (2 > b)
																							{
																								goto IL_02aa;
																							}
																							goto IL_03b6;
																							IL_02aa:
																							if (1 >= b)
																							{
																								goto IL_02b8;
																							}
																							goto IL_05e1;
																							IL_02b8:
																							if (1 > b)
																							{
																							}
																							goto IL_05e1;
																							IL_03b6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03f6;
																							IL_03f6:
																							array[num5 - 2] = 0;
																							goto IL_040a;
																							IL_040a:
																							num5--;
																							goto end_IL_0286;
																							IL_02cb:
																							if (3 >= b)
																							{
																								goto IL_02d6;
																							}
																							goto IL_02e9;
																							IL_02d6:
																							if (3 <= b)
																							{
																								goto IL_036c;
																							}
																							goto IL_05e1;
																							IL_036c:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0395;
																							IL_0395:
																							ptr2 += 8;
																							goto IL_03a3;
																							IL_03a3:
																							num5--;
																							goto end_IL_0286;
																							IL_02e9:
																							if (4 >= b)
																							{
																								goto IL_02f7;
																							}
																							goto IL_05e1;
																							IL_02f7:
																							if (4 <= b)
																							{
																								goto IL_0305;
																							}
																							goto IL_05e1;
																							IL_0305:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0345;
																							IL_0345:
																							array[num5 - 2] = 0;
																							goto IL_0359;
																							continue;
																							end_IL_0239:
																							break;
																						}
																						continue;
																					}
																					goto IL_0430;
																					IL_05b4:
																					if (9 <= b)
																					{
																						goto IL_05bf;
																					}
																					goto IL_05e1;
																					IL_0430:
																					if (7 >= b)
																					{
																						goto IL_043e;
																					}
																					goto IL_0520;
																					IL_043e:
																					if (7 > b)
																					{
																						goto IL_044c;
																					}
																					goto IL_04d8;
																					IL_044c:
																					if (6 >= b)
																					{
																						goto IL_045a;
																					}
																					goto IL_05e1;
																					IL_045a:
																					if (6 <= b)
																					{
																						goto IL_0468;
																					}
																					goto IL_05e1;
																					IL_0468:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04a8;
																					IL_04a8:
																					array[num5 - 2] = 0;
																					goto IL_04bc;
																					IL_04bc:
																					num5--;
																					num = 43;
																					goto end_IL_0286;
																					IL_04d8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04f1;
																					IL_04f1:
																					array[num5] = 0;
																					goto IL_04ff;
																					IL_04ff:
																					num5++;
																					goto IL_050d;
																					IL_050d:
																					ptr2 += 8;
																					goto end_IL_0286;
																					IL_0520:
																					if (8 >= b)
																					{
																						goto IL_052b;
																					}
																					goto IL_05a0;
																					IL_052b:
																					if (8 <= b)
																					{
																						goto IL_0539;
																					}
																					goto IL_05e1;
																					IL_0539:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0579;
																					IL_0579:
																					array[num5 - 2] = 0;
																					goto IL_058d;
																					IL_058d:
																					num5--;
																					goto end_IL_0286;
																					IL_05a0:
																					if (9 >= b)
																					{
																						num = 81;
																						goto IL_05b4;
																					}
																					goto IL_05e1;
																					IL_05bf:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0286;
																					continue;
																					end_IL_0246:
																					break;
																				}
																				continue;
																			}
																			num = 84;
																			goto IL_05e1;
																			continue;
																			end_IL_0256:
																			break;
																		}
																		continue;
																	}
																	goto IL_05e1;
																	IL_0620:
																	ptr2 += 8;
																	goto end_IL_0286;
																	IL_05e1:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0604;
																	IL_0604:
																	array[num5] = 0;
																	goto IL_0612;
																	IL_0612:
																	num5++;
																	goto IL_0620;
																	continue;
																	end_IL_0266:
																	break;
																}
																continue;
																end_IL_0276:
																break;
															}
															continue;
															end_IL_0286:
															break;
														}
														continue;
													}
													goto IL_06ed;
													IL_06ed:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_0654:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									continue;
									end_IL_0674:
									break;
								}
								continue;
								end_IL_0692:
								break;
							}
							continue;
							end_IL_06a2:
							break;
						}
						continue;
						end_IL_06b2:
						break;
					}
					continue;
					end_IL_06c2:
					break;
				}
				continue;
				end_IL_06d2:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NativeOverlappedRecordFixup.FileModeAsR);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0268:
														byte b = *ptr2;
														while (true)
														{
															IL_0258:
															ptr2++;
															while (true)
															{
																IL_0248:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0228:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0218:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_020b:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01fb:
																									if (3 < b)
																									{
																										while (4 >= b)
																										{
																											num = 110;
																											while (true)
																											{
																												if (num != 110)
																												{
																													if (num != 1091)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 35:
																														goto IL_01e8;
																													case 3:
																														goto IL_01fb;
																													case 36:
																													case 81:
																														goto IL_020b;
																													case 1:
																														goto IL_0218;
																													case 47:
																														goto IL_0228;
																													case 85:
																														goto IL_0238;
																													case 93:
																														goto IL_0248;
																													case 98:
																														goto IL_0258;
																													case 14:
																													case 94:
																														goto IL_0268;
																													case 91:
																														goto IL_0273;
																													case 73:
																														goto IL_027e;
																													case 71:
																													case 86:
																														goto IL_0297;
																													case 42:
																														goto IL_02c9;
																													case 46:
																														goto IL_02d7;
																													case 102:
																														goto IL_02ea;
																													case 4:
																													case 88:
																														goto IL_02f8;
																													case 70:
																														goto IL_0311;
																													case 25:
																														goto IL_0328;
																													case 7:
																														goto IL_033f;
																													case 59:
																														goto IL_036e;
																													case 56:
																													case 62:
																														goto IL_037c;
																													case 28:
																													case 30:
																														goto IL_0394;
																													case 64:
																														goto IL_03a2;
																													case 44:
																														goto IL_03c5;
																													case 87:
																														goto IL_03cf;
																													case 22:
																														goto IL_03dd;
																													case 15:
																														goto IL_03f0;
																													case 77:
																														goto IL_03fe;
																													case 27:
																													case 33:
																														goto IL_0409;
																													case 48:
																														goto IL_046b;
																													case 65:
																													case 100:
																														goto IL_0487;
																													case 19:
																														goto IL_0492;
																													case 66:
																													case 103:
																														goto IL_04a0;
																													case 45:
																														goto IL_04e9;
																													case 53:
																														goto IL_04fd;
																													case 16:
																														goto IL_0510;
																													case 0:
																														goto IL_051e;
																													case 32:
																													case 51:
																														goto IL_0529;
																													case 13:
																														goto IL_054c;
																													case 68:
																														goto IL_0563;
																													case 18:
																														goto IL_0571;
																													case 69:
																														goto IL_058c;
																													case 37:
																														goto IL_0597;
																													case 23:
																													case 67:
																														goto IL_05a2;
																													case 75:
																														goto IL_05bb;
																													case 41:
																														goto IL_05c6;
																													case 2:
																													case 5:
																													case 12:
																													case 24:
																													case 29:
																													case 31:
																													case 38:
																													case 39:
																													case 40:
																													case 49:
																													case 54:
																													case 55:
																													case 57:
																													case 58:
																													case 60:
																													case 61:
																													case 74:
																													case 92:
																													case 96:
																													case 97:
																													case 99:
																														goto end_IL_01e8;
																													case 6:
																													case 10:
																													case 11:
																													case 34:
																													case 50:
																													case 63:
																													case 76:
																													case 78:
																													case 80:
																													case 82:
																													case 83:
																													case 95:
																													case 101:
																														goto end_IL_01d5;
																													case 26:
																														goto end_IL_05ed;
																													case 79:
																														goto end_IL_0600;
																													case 84:
																														goto end_IL_060a;
																													case 20:
																														goto end_IL_0615;
																													case 21:
																													case 43:
																														goto end_IL_062a;
																													case 52:
																														goto end_IL_063a;
																													case 8:
																													case 17:
																														goto end_IL_064a;
																													case 89:
																														goto end_IL_065a;
																													case 90:
																														goto end_IL_066a;
																													case 9:
																													case 72:
																														goto IL_0685;
																													}
																													continue;
																												}
																												if (4 <= b)
																												{
																													break;
																												}
																												goto end_IL_01e8;
																												continue;
																												end_IL_01d5:
																												break;
																											}
																											goto end_IL_0248;
																											continue;
																											end_IL_01e8:
																											break;
																											IL_01e8:;
																										}
																										break;
																									}
																									num = 59;
																									goto IL_036e;
																									IL_036e:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_037c;
																									IL_037c:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0248;
																								}
																								break;
																							}
																							goto IL_0273;
																							IL_02c9:
																							ptr2 += 8;
																							goto IL_02d7;
																							IL_0273:
																							if (2 > b)
																							{
																								goto IL_027e;
																							}
																							num = 86;
																							goto IL_0297;
																							IL_027e:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_02ea;
																							IL_02ea:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_02f8;
																							IL_02f8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0311;
																							IL_0311:
																							array[num5] = 0;
																							num = 25;
																							goto IL_0328;
																							IL_0328:
																							num5++;
																							num = 7;
																							goto IL_033f;
																							IL_033f:
																							ptr2 += 8;
																							goto end_IL_0248;
																							IL_02d7:
																							num5--;
																							goto end_IL_0248;
																							IL_0297:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 42;
																							goto IL_02c9;
																						}
																						break;
																					}
																					goto IL_0394;
																					IL_03dd:
																					ptr2 += 8;
																					goto end_IL_0248;
																					IL_0394:
																					array[num5] = 0;
																					goto IL_03a2;
																					IL_03a2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03c5;
																					IL_03c5:
																					array2[num5] = null;
																					goto IL_03cf;
																					IL_03cf:
																					num5++;
																					goto IL_03dd;
																				}
																				break;
																			}
																			goto IL_03f0;
																			IL_05bb:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_05c6;
																			IL_03f0:
																			if (8 >= b)
																			{
																				goto IL_03fe;
																			}
																			goto IL_058c;
																			IL_03fe:
																			if (8 <= b)
																			{
																				goto IL_0409;
																			}
																			goto IL_0487;
																			IL_0409:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_046b;
																			IL_046b:
																			num5 -= 2;
																			num = 101;
																			goto end_IL_0248;
																			IL_0487:
																			if (6 >= b)
																			{
																				goto IL_0492;
																			}
																			goto IL_0510;
																			IL_0492:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_04a0;
																			IL_04a0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 45;
																			goto IL_04e9;
																			IL_04e9:
																			array[num5 - 2] = 0;
																			goto IL_04fd;
																			IL_04fd:
																			num5--;
																			goto end_IL_0248;
																			IL_0510:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_051e;
																			IL_051e:
																			if (7 > b)
																			{
																				num = 54;
																				break;
																			}
																			goto IL_0529;
																			IL_0529:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_054c;
																			IL_054c:
																			array[num5] = 0;
																			num = 68;
																			goto IL_0563;
																			IL_0563:
																			num5++;
																			goto IL_0571;
																			IL_0571:
																			ptr2 += 8;
																			goto end_IL_0248;
																			IL_05c6:
																			if (10 <= b)
																			{
																				num = 92;
																			}
																			break;
																			IL_058c:
																			if (9 >= b)
																			{
																				goto IL_0597;
																			}
																			goto IL_05bb;
																			IL_0597:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_05a2;
																			IL_05a2:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0248;
																		}
																		break;
																		IL_0238:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0248:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0685;
												IL_0685:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ed:
												break;
											}
											continue;
											end_IL_0600:
											break;
										}
										continue;
										end_IL_060a:
										break;
									}
									continue;
									end_IL_0615:
									break;
								}
								continue;
								end_IL_062a:
								break;
							}
							continue;
							end_IL_063a:
							break;
						}
						continue;
						end_IL_064a:
						break;
					}
					continue;
					end_IL_065a:
					break;
				}
				continue;
				end_IL_066a:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 146;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 137;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OPTILMetadataSectionRequestedExecutionLevelUIAccess.RemotingSurrogateSelectorArgRegSubKeyAbsent);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0307:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02e7:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02d7:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02c7:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_02b7:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (true)
																											{
																												IL_0294:
																												if (13 > b)
																												{
																													num = 153;
																													while (num != 153)
																													{
																														if (num != 1134)
																														{
																															goto IL_0522;
																														}
																														switch (num)
																														{
																														case 27:
																															goto IL_0294;
																														case 103:
																															goto IL_02a7;
																														case 67:
																															goto IL_02b7;
																														case 114:
																															goto IL_02c7;
																														case 9:
																														case 80:
																															goto IL_02d7;
																														case 33:
																															goto IL_02e7;
																														case 43:
																															goto IL_02f7;
																														case 122:
																															goto IL_0307;
																														case 52:
																															goto end_IL_0307;
																														case 36:
																														case 58:
																															goto end_IL_0317;
																														case 26:
																														case 35:
																															goto IL_0332;
																														case 32:
																															goto IL_0394;
																														case 20:
																														case 85:
																															goto IL_03b0;
																														case 139:
																															goto IL_03cc;
																														case 140:
																															goto IL_03da;
																														case 64:
																															goto IL_03f6;
																														case 11:
																														case 135:
																															goto IL_0404;
																														case 24:
																														case 94:
																															goto IL_0412;
																														case 22:
																															goto IL_0420;
																														case 48:
																														case 112:
																															goto IL_0439;
																														case 65:
																															goto IL_047d;
																														case 88:
																															goto IL_0491;
																														case 62:
																															goto IL_04a4;
																														case 84:
																														case 115:
																															goto IL_04af;
																														case 116:
																															goto IL_04bd;
																														case 2:
																															goto IL_04e0;
																														case 92:
																															goto IL_04ea;
																														case 109:
																															goto IL_04f8;
																														case 63:
																															goto IL_0514;
																														case 130:
																															goto IL_0522;
																														case 17:
																														case 131:
																															goto IL_0535;
																														case 25:
																															goto IL_0575;
																														case 117:
																															goto IL_0589;
																														case 100:
																															goto IL_059c;
																														case 60:
																														case 127:
																															goto IL_05a7;
																														case 104:
																															goto IL_05bf;
																														case 106:
																															goto IL_05cd;
																														case 12:
																														case 29:
																															goto IL_05d8;
																														case 38:
																															goto IL_05f6;
																														case 66:
																															goto IL_0604;
																														case 81:
																															goto IL_0617;
																														case 87:
																														case 93:
																															goto IL_0622;
																														case 71:
																															goto IL_0630;
																														case 51:
																														case 53:
																															goto IL_063e;
																														case 125:
																															goto IL_0667;
																														case 97:
																															goto IL_0680;
																														case 16:
																														case 37:
																															goto IL_068b;
																														case 56:
																															goto IL_0699;
																														case 90:
																														case 144:
																															goto IL_06a7;
																														case 142:
																															goto IL_06c0;
																														case 59:
																															goto IL_06ce;
																														case 101:
																															goto IL_06dc;
																														case 50:
																														case 134:
																															goto IL_06f8;
																														case 23:
																															goto IL_0738;
																														case 82:
																															goto IL_074c;
																														case 128:
																															goto IL_075f;
																														case 95:
																															goto IL_076d;
																														case 39:
																														case 126:
																															goto IL_0778;
																														case 123:
																															goto IL_07b7;
																														case 83:
																														case 143:
																															goto IL_07ca;
																														case 70:
																															goto IL_07d5;
																														case 76:
																														case 133:
																															goto IL_07e3;
																														case 4:
																															goto IL_07f1;
																														case 40:
																															goto IL_0809;
																														case 41:
																															goto IL_0817;
																														case 91:
																															goto IL_0832;
																														case 34:
																															goto IL_083d;
																														case 105:
																														case 118:
																															goto IL_0848;
																														case 72:
																															goto IL_0871;
																														case 7:
																															goto IL_087f;
																														case 0:
																														case 3:
																														case 5:
																														case 6:
																														case 8:
																														case 10:
																														case 18:
																														case 28:
																														case 30:
																														case 31:
																														case 47:
																														case 49:
																														case 57:
																														case 61:
																														case 68:
																														case 73:
																														case 75:
																														case 77:
																														case 78:
																														case 79:
																														case 107:
																														case 113:
																														case 124:
																														case 132:
																														case 136:
																														case 141:
																															goto end_IL_0281;
																														case 13:
																														case 15:
																														case 19:
																														case 42:
																														case 45:
																														case 46:
																														case 54:
																														case 74:
																														case 86:
																														case 89:
																														case 96:
																														case 98:
																														case 99:
																														case 102:
																														case 108:
																														case 120:
																														case 129:
																														case 138:
																															goto end_IL_0327;
																														case 55:
																															goto end_IL_08a2;
																														case 14:
																															goto end_IL_08b5;
																														case 44:
																															goto end_IL_08bf;
																														case 110:
																															goto end_IL_08ca;
																														case 21:
																														case 121:
																															goto end_IL_08da;
																														case 137:
																															goto end_IL_08ea;
																														case 69:
																														case 119:
																															goto end_IL_08fa;
																														case 145:
																															goto end_IL_090a;
																														case 146:
																															goto end_IL_0923;
																														case 1:
																														case 111:
																															goto IL_093e;
																														}
																														continue;
																														end_IL_0281:
																														break;
																													}
																													break;
																												}
																												goto IL_0332;
																												IL_0332:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0394;
																												IL_0394:
																												num5 -= 2;
																												goto end_IL_0327;
																											}
																											break;
																											IL_02a7:;
																										}
																										break;
																									}
																									num = 85;
																									goto IL_03b0;
																									IL_03b0:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0327;
																								}
																								break;
																							}
																							goto IL_03cc;
																							IL_03da:
																							if (15 > b)
																							{
																							}
																							break;
																							IL_03cc:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_03da;
																						}
																						break;
																					}
																					num = 64;
																					goto IL_03f6;
																					IL_0535:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0575;
																					IL_0575:
																					array[num5 - 2] = 0;
																					goto IL_0589;
																					IL_03f6:
																					if (12 > b)
																					{
																						goto IL_0404;
																					}
																					goto IL_0535;
																					IL_0404:
																					if (10 < b)
																					{
																						goto IL_0412;
																					}
																					goto IL_04a4;
																					IL_0412:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0420;
																					IL_0420:
																					if (11 > b)
																					{
																						num = 77;
																						break;
																					}
																					goto IL_0439;
																					IL_0589:
																					num5--;
																					goto end_IL_0327;
																					IL_0439:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_047d;
																					IL_047d:
																					array[num5 - 2] = 0;
																					goto IL_0491;
																					IL_0491:
																					num5--;
																					goto end_IL_0327;
																					IL_04a4:
																					if (10 <= b)
																					{
																						goto IL_04af;
																					}
																					goto IL_0514;
																					IL_04af:
																					array[num5] = 0;
																					goto IL_04bd;
																					IL_04bd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04e0;
																					IL_04e0:
																					array2[num5] = null;
																					goto IL_04ea;
																					IL_04ea:
																					num5++;
																					goto IL_04f8;
																					IL_04f8:
																					ptr2 += 8;
																					num = 89;
																					goto end_IL_0327;
																					IL_0514:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0522;
																					IL_0522:
																					if (9 <= b)
																					{
																						goto end_IL_0327;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_059c;
																			IL_0871:
																			ptr2 += 8;
																			goto IL_087f;
																			IL_059c:
																			if (8 <= b)
																			{
																				goto IL_05a7;
																			}
																			goto IL_05bf;
																			IL_05a7:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0327;
																			IL_05bf:
																			if (4 >= b)
																			{
																				goto IL_05cd;
																			}
																			goto IL_075f;
																			IL_05cd:
																			if (4 <= b)
																			{
																				goto IL_05d8;
																			}
																			goto IL_0617;
																			IL_05d8:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_05f6;
																			IL_05f6:
																			ptr2 += 8;
																			goto IL_0604;
																			IL_0604:
																			num5--;
																			goto end_IL_0327;
																			IL_0617:
																			if (2 < b)
																			{
																				goto IL_0622;
																			}
																			goto IL_0680;
																			IL_0622:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0630;
																			IL_0630:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_063e;
																			IL_063e:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0667;
																			IL_0667:
																			array[num5 - 1] = 5;
																			goto end_IL_0327;
																			IL_0680:
																			if (2 > b)
																			{
																				goto IL_068b;
																			}
																			goto IL_06f8;
																			IL_068b:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0699;
																			IL_0699:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_06a7;
																			IL_06a7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06c0;
																			IL_06c0:
																			array[num5] = 0;
																			goto IL_06ce;
																			IL_06ce:
																			num5++;
																			goto IL_06dc;
																			IL_06dc:
																			ptr2 += 8;
																			num = 46;
																			goto end_IL_0327;
																			IL_06f8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0738;
																			IL_0738:
																			array[num5 - 2] = 0;
																			goto IL_074c;
																			IL_074c:
																			num5--;
																			goto end_IL_0327;
																			IL_075f:
																			if (6 >= b)
																			{
																				goto IL_076d;
																			}
																			goto IL_0832;
																			IL_076d:
																			if (6 <= b)
																			{
																				goto IL_0778;
																			}
																			goto IL_07ca;
																			IL_0778:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07b7;
																			IL_07b7:
																			num5 -= 3;
																			goto end_IL_0327;
																			IL_07ca:
																			if (5 < b)
																			{
																				num = 107;
																				break;
																			}
																			goto IL_07d5;
																			IL_07d5:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_07e3;
																			IL_07e3:
																			array[num5] = 5;
																			goto IL_07f1;
																			IL_07f1:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0809;
																			IL_0809:
																			num5++;
																			goto IL_0817;
																			IL_0817:
																			ptr2 += 8;
																			goto end_IL_0327;
																			IL_087f:
																			num5--;
																			goto end_IL_0327;
																			IL_0832:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_083d;
																			IL_083d:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0848;
																			IL_0848:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0871;
																		}
																		break;
																		IL_02f7:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0327;
																continue;
																end_IL_0307:
																break;
															}
															continue;
															end_IL_0317:
															break;
														}
														continue;
														end_IL_0327:
														break;
													}
													continue;
												}
												goto IL_093e;
												IL_093e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a2:
												break;
											}
											continue;
											end_IL_08b5:
											break;
										}
										continue;
										end_IL_08bf:
										break;
									}
									continue;
									end_IL_08ca:
									break;
								}
								continue;
								end_IL_08da:
								break;
							}
							continue;
							end_IL_08ea:
							break;
						}
						continue;
						end_IL_08fa:
						break;
					}
					continue;
					end_IL_090a:
					break;
				}
				continue;
				end_IL_0923:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSFILEHASHALGORITHMFileHashValue.setKeyStoreAllowLeadingSign);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03cb:
														byte b = *ptr2;
														while (true)
														{
															IL_03bb:
															ptr2++;
															while (true)
															{
																IL_03ab:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_038b:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_036b:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_035e:
																								if (6 >= b)
																								{
																									while (true)
																									{
																										IL_034e:
																										if (6 > b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_031e:
																														array[num5] = 5;
																														while (true)
																														{
																															IL_0304:
																															array2[num5] = array5[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_02eb:
																																num5++;
																																num = 125;
																																while (true)
																																{
																																	IL_02d2:
																																	ptr2 += 8;
																																	num = 172;
																																	while (num != 172)
																																	{
																																		if (num != 1153)
																																		{
																																			goto IL_079f;
																																		}
																																		switch (num)
																																		{
																																		case 125:
																																			goto IL_02d2;
																																		case 73:
																																			goto IL_02eb;
																																		case 10:
																																			goto IL_0304;
																																		case 15:
																																		case 75:
																																			goto IL_031e;
																																		case 111:
																																			goto IL_032e;
																																		case 160:
																																			goto IL_033e;
																																		case 131:
																																			goto IL_034e;
																																		case 80:
																																			goto IL_035e;
																																		case 40:
																																		case 43:
																																			goto IL_036b;
																																		case 162:
																																			goto IL_037b;
																																		case 24:
																																			goto IL_038b;
																																		case 92:
																																			goto IL_039b;
																																		case 61:
																																			goto IL_03ab;
																																		case 94:
																																			goto IL_03bb;
																																		case 13:
																																		case 110:
																																			goto IL_03cb;
																																		case 4:
																																		case 54:
																																			goto IL_03d6;
																																		case 53:
																																			goto IL_03e1;
																																		case 25:
																																			goto IL_03f1;
																																		case 33:
																																			goto IL_03ff;
																																		case 57:
																																		case 66:
																																			goto IL_040f;
																																		case 48:
																																			goto IL_0438;
																																		case 31:
																																			goto IL_0446;
																																		case 106:
																																		case 118:
																																			goto IL_0459;
																																		case 119:
																																		case 133:
																																			goto IL_0471;
																																		case 51:
																																			goto IL_04b0;
																																		case 0:
																																			goto IL_04c3;
																																		case 1:
																																		case 3:
																																			goto IL_04d1;
																																		case 35:
																																			goto IL_04df;
																																		case 7:
																																		case 32:
																																			goto IL_04ea;
																																		case 68:
																																			goto IL_052a;
																																		case 102:
																																			goto IL_053e;
																																		case 164:
																																			goto IL_0551;
																																		case 70:
																																			goto IL_055f;
																																		case 144:
																																		case 156:
																																			goto IL_056d;
																																		case 72:
																																			goto IL_0586;
																																		case 71:
																																			goto IL_0594;
																																		case 103:
																																			goto IL_05ab;
																																		case 5:
																																		case 127:
																																			goto IL_05be;
																																		case 36:
																																			goto IL_05cc;
																																		case 86:
																																		case 124:
																																			goto IL_05da;
																																		case 100:
																																			goto IL_0603;
																																		case 12:
																																		case 123:
																																			goto IL_0625;
																																		case 150:
																																			goto IL_0643;
																																		case 21:
																																			goto IL_0651;
																																		case 8:
																																		case 20:
																																			goto IL_0664;
																																		case 121:
																																			goto IL_0672;
																																		case 17:
																																		case 113:
																																			goto IL_0680;
																																		case 138:
																																			goto IL_068e;
																																		case 96:
																																			goto IL_069c;
																																		case 49:
																																			goto IL_06aa;
																																		case 149:
																																		case 151:
																																			goto IL_06b8;
																																		case 158:
																																			goto IL_06c6;
																																		case 97:
																																			goto IL_06e9;
																																		case 104:
																																			goto IL_06f3;
																																		case 65:
																																			goto IL_070a;
																																		case 29:
																																		case 129:
																																			goto IL_071d;
																																		case 64:
																																			goto IL_076a;
																																		case 135:
																																			goto IL_077e;
																																		case 122:
																																		case 140:
																																			goto IL_0791;
																																		case 52:
																																			goto IL_079f;
																																		case 23:
																																		case 148:
																																			goto IL_07ad;
																																		case 143:
																																			goto IL_07ed;
																																		case 55:
																																			goto IL_080a;
																																		case 44:
																																		case 87:
																																			goto IL_081d;
																																		case 83:
																																			goto IL_087f;
																																		case 58:
																																			goto IL_0892;
																																		case 69:
																																			goto IL_08a0;
																																		case 26:
																																		case 91:
																																			goto IL_08ab;
																																		case 16:
																																			goto IL_08b9;
																																		case 95:
																																		case 161:
																																			goto IL_08c7;
																																		case 163:
																																			goto IL_08db;
																																		case 88:
																																			goto IL_091a;
																																		case 37:
																																		case 76:
																																			goto IL_092a;
																																		case 14:
																																			goto IL_093a;
																																		case 147:
																																			goto IL_0945;
																																		case 115:
																																		case 128:
																																			goto IL_0950;
																																		case 47:
																																		case 137:
																																			goto IL_0969;
																																		case 22:
																																			goto IL_097d;
																																		case 2:
																																		case 18:
																																		case 28:
																																		case 30:
																																		case 39:
																																		case 41:
																																		case 42:
																																		case 45:
																																		case 50:
																																		case 59:
																																		case 60:
																																		case 62:
																																		case 67:
																																		case 78:
																																		case 82:
																																		case 89:
																																		case 101:
																																		case 107:
																																		case 108:
																																		case 109:
																																		case 112:
																																		case 126:
																																		case 141:
																																		case 146:
																																		case 152:
																																		case 153:
																																		case 154:
																																		case 155:
																																		case 157:
																																		case 159:
																																		case 165:
																																			goto end_IL_032e;
																																		case 6:
																																		case 9:
																																		case 19:
																																		case 27:
																																		case 34:
																																		case 38:
																																		case 46:
																																		case 63:
																																		case 79:
																																		case 90:
																																		case 93:
																																		case 99:
																																		case 105:
																																		case 116:
																																		case 117:
																																		case 132:
																																		case 134:
																																		case 136:
																																		case 142:
																																			goto end_IL_02bf;
																																		case 11:
																																			goto end_IL_099b;
																																		case 120:
																																			goto end_IL_09ae;
																																		case 77:
																																			goto end_IL_09b8;
																																		case 114:
																																			goto end_IL_09c3;
																																		case 81:
																																		case 145:
																																			goto end_IL_09d3;
																																		case 130:
																																			goto end_IL_09e3;
																																		case 56:
																																		case 74:
																																			goto end_IL_09f3;
																																		case 84:
																																			goto end_IL_0a03;
																																		case 85:
																																			goto end_IL_0a13;
																																		case 98:
																																		case 139:
																																			goto IL_0a2e;
																																		}
																																		continue;
																																		end_IL_02bf:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_037b;
																													continue;
																													end_IL_032e:
																													break;
																													IL_032e:;
																												}
																												break;
																												IL_033e:;
																											}
																											break;
																										}
																										goto IL_0471;
																										IL_04b0:
																										num5 -= 3;
																										goto end_IL_037b;
																										IL_0471:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04b0;
																									}
																									break;
																								}
																								goto IL_03d6;
																								IL_0459:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_037b;
																								IL_03d6:
																								if (7 >= b)
																								{
																									goto IL_03e1;
																								}
																								goto IL_03f1;
																								IL_03e1:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_040f;
																								IL_040f:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0438;
																								IL_0438:
																								ptr2 += 8;
																								goto IL_0446;
																								IL_0446:
																								num5--;
																								goto end_IL_037b;
																								IL_03f1:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_03ff;
																								IL_03ff:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0459;
																							}
																							break;
																						}
																						goto IL_04c3;
																						IL_0651:
																						num5--;
																						goto end_IL_037b;
																						IL_04c3:
																						if (4 > b)
																						{
																							goto IL_04d1;
																						}
																						goto IL_0625;
																						IL_04d1:
																						if (2 >= b)
																						{
																							goto IL_04df;
																						}
																						goto IL_05be;
																						IL_04df:
																						if (2 <= b)
																						{
																							goto IL_04ea;
																						}
																						goto IL_0551;
																						IL_04ea:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_052a;
																						IL_052a:
																						array[num5 - 2] = 0;
																						goto IL_053e;
																						IL_053e:
																						num5--;
																						goto end_IL_037b;
																						IL_0551:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_055f;
																						IL_055f:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_056d;
																						IL_056d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0586;
																						IL_0586:
																						array[num5] = 0;
																						goto IL_0594;
																						IL_0594:
																						num5++;
																						num = 103;
																						goto IL_05ab;
																						IL_05ab:
																						ptr2 += 8;
																						goto end_IL_037b;
																						IL_05be:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_05cc;
																						IL_05cc:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_05da;
																						IL_05da:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0603;
																						IL_0603:
																						array[num5 - 1] = 5;
																						num = 105;
																						goto end_IL_037b;
																						IL_0625:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_0643;
																						IL_0643:
																						ptr2 += 8;
																						goto IL_0651;
																					}
																					goto end_IL_039b;
																					continue;
																					end_IL_037b:
																					break;
																					IL_037b:;
																				}
																				break;
																			}
																			goto IL_0664;
																			IL_097d:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_039b;
																			IL_0664:
																			if (13 >= b)
																			{
																				goto IL_0672;
																			}
																			goto IL_0892;
																			IL_0672:
																			if (13 > b)
																			{
																				goto IL_0680;
																			}
																			goto IL_081d;
																			IL_0680:
																			if (11 >= b)
																			{
																				goto IL_068e;
																			}
																			goto IL_0791;
																			IL_068e:
																			if (11 > b)
																			{
																				goto IL_069c;
																			}
																			goto IL_071d;
																			IL_069c:
																			if (10 < b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_06aa;
																			IL_06aa:
																			if (10 > b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_06b8;
																			IL_06b8:
																			array[num5] = 0;
																			goto IL_06c6;
																			IL_06c6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06e9;
																			IL_06e9:
																			array2[num5] = null;
																			goto IL_06f3;
																			IL_06f3:
																			num5++;
																			num = 65;
																			goto IL_070a;
																			IL_070a:
																			ptr2 += 8;
																			break;
																			IL_071d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 64;
																			goto IL_076a;
																			IL_076a:
																			array[num5 - 2] = 0;
																			goto IL_077e;
																			IL_077e:
																			num5--;
																			break;
																			IL_0791:
																			if (12 < b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_079f;
																			IL_079f:
																			if (12 > b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_07ad;
																			IL_07ad:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07ed;
																			IL_07ed:
																			array[num5 - 2] = 0;
																			num = 55;
																			goto IL_080a;
																			IL_080a:
																			num5--;
																			break;
																			IL_081d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_087f;
																			IL_087f:
																			num5 -= 2;
																			break;
																			IL_0892:
																			if (15 >= b)
																			{
																				goto IL_08a0;
																			}
																			goto IL_093a;
																			IL_08a0:
																			if (15 > b)
																			{
																				goto IL_08ab;
																			}
																			goto IL_092a;
																			IL_08ab:
																			if (14 < b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_08b9;
																			IL_08b9:
																			if (14 > b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_08c7;
																			IL_08c7:
																			array[num5 - 1] = 0;
																			goto IL_08db;
																			IL_08db:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)EventWaitHandleResponseXmlNamespace[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_091a;
																			IL_091a:
																			ptr2 += 8;
																			break;
																			IL_092a:
																			num5--;
																			break;
																			IL_093a:
																			if (16 >= b)
																			{
																				goto IL_0945;
																			}
																			goto IL_0969;
																			IL_0945:
																			if (16 > b)
																			{
																				goto end_IL_039b;
																			}
																			goto IL_0950;
																			IL_0950:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0969:
																			if (17 < b)
																			{
																				goto end_IL_039b;
																			}
																			num = 22;
																			goto IL_097d;
																		}
																		goto end_IL_03ab;
																		continue;
																		end_IL_039b:
																		break;
																		IL_039b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03ab:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a2e;
												IL_0a2e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_099b:
												break;
											}
											continue;
											end_IL_09ae:
											break;
										}
										continue;
										end_IL_09b8:
										break;
									}
									continue;
									end_IL_09c3:
									break;
								}
								continue;
								end_IL_09d3:
								break;
							}
							continue;
							end_IL_09e3:
							break;
						}
						continue;
						end_IL_09f3:
						break;
					}
					continue;
					end_IL_0a03:
					break;
				}
				continue;
				end_IL_0a13:
				break;
			}
		}
	}

	static Class142()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 11;
					while (true)
					{
						if (num != 11)
						{
							if (num != 992)
							{
								break;
							}
							switch (num)
							{
							case 1:
							case 2:
								goto end_IL_0035;
							case 3:
								goto end_IL_0042;
							case 4:
								goto end_IL_0051;
							case 0:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0035:
						break;
					}
					continue;
					end_IL_0042:
					break;
				}
				continue;
				end_IL_0051:
				break;
			}
		}
	}
}
