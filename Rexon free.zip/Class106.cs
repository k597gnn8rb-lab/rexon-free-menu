using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Stilt Long Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns long stilts.", false, 4, ModType.const_0, false)]
internal class Class106 : Class93
{
	private static double double_1;

	private static float float_0;

	private static int int_3;

	private static double double_2;

	private static double double_3;

	private static bool bool_0;

	private static IntPtr[] IContextPropertyGetArrayMethod;

	private static IntPtr[] setForegroundColorDiscretionaryAclAutoInheritRequired;

	private static IntPtr[] CalendricalCalculationsHelperSecureString;

	private static IntPtr[] RIPEMDGetPrimary;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_03b3, IL_03c6, IL_03d6, IL_03e6, IL_03f6, IL_0403, IL_0413, IL_0423, IL_0436, IL_0446, IL_0451, IL_0461, IL_047a, IL_048d, IL_04cd, IL_04ea, IL_04fd, IL_053d, IL_0551, IL_0564, IL_05a3, IL_05b6, IL_05c9, IL_05d4, IL_05e2, IL_05f0, IL_05fe, IL_0621, IL_062b, IL_0639, IL_064c, IL_065a, IL_0683, IL_0691, IL_06a4, IL_06b2, IL_06c0, IL_06ce, IL_06dc, IL_06ea, IL_072a, IL_073e, IL_0751, IL_075f, IL_079f, IL_07b3, IL_07c6, IL_07d9, IL_07e4, IL_07f2, IL_0832, IL_0846, IL_0859, IL_0867, IL_0875, IL_08d7, IL_08ea, IL_08f8, IL_0906, IL_0914, IL_091f, IL_092d, IL_0956, IL_096f, IL_097d, IL_098b, IL_09a3, IL_09c1, IL_09e5, IL_09fd, IL_0a10, IL_0a1e, IL_0a2c, IL_0a3a, IL_0a48, IL_0a65, IL_0ab4, IL_0abe, IL_0aeb, IL_0aff, IL_0b0d, IL_0b20, IL_0b33, IL_0b5a, IL_0b68, IL_0b7b, IL_0b89, IL_0ba1, IL_0baf, IL_0bc2, IL_0bcd, IL_0bd8, IL_0be6, IL_0bf1, IL_0c0d, IL_0c1b, IL_0c29, IL_0c4a, IL_0c58, IL_0c63, IL_0c71, IL_0caf, IL_0cc2, IL_0cd0, IL_0cde, IL_0cf2, IL_0d2a, IL_0d46, IL_0d5f, IL_0d6d, IL_0d7b, IL_0d8b, IL_0da4, IL_0db2, IL_0dc0, IL_0dce, IL_0de1, IL_0deb, IL_0df6, IL_0e06, IL_0e16, IL_0e26, IL_0e3f, IL_0e4f, IL_0e5f, IL_0e6f, IL_0e7f, IL_0ea3, IL_0eac are reachable both inside and outside the pinned region starting at IL_0e94. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 85;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef14 = default(int);
				ref int reference = ref __rxRef14;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					num = 84;
					while (true)
					{
						IL_0e7f:
						num2 = 1;
						while (true)
						{
							IL_0e6f:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e5f:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e4f:
									array2 = new byte[4];
									while (true)
									{
										IL_0e3f:
										array3 = new object[4];
										while (true)
										{
											IL_0e26:
											array4 = new int[4];
											num = 152;
											while (true)
											{
												IL_0e16:
												array5 = new int[6];
												while (true)
												{
													IL_0e06:
													array6 = new long[4];
													while (true)
													{
														IL_0df6:
														array7 = new object[11];
														while (true)
														{
															IL_0deb:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeLibExporterFlagsActivatorCache.IsCanceledlcid);
															while (true)
															{
																IL_0de1:
																ptr2 = ptr;
																while (true)
																{
																	IL_0dce:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0446:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0436:
																				ptr2++;
																				while (true)
																				{
																					IL_0423:
																					if (b >= 1)
																					{
																						num = 118;
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0403:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_03f6:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_03e6:
																												if (5 >= b)
																												{
																													while (true)
																													{
																														IL_03d6:
																														if (5 > b)
																														{
																															while (true)
																															{
																																IL_03c6:
																																if (2 < b)
																																{
																																	num = 226;
																																	while (true)
																																	{
																																		if (num != 226)
																																		{
																																			if (num != 1207)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 85:
																																				break;
																																			default:
																																				continue;
																																			case 141:
																																				goto IL_03c6;
																																			case 11:
																																				goto IL_03d6;
																																			case 86:
																																				goto IL_03e6;
																																			case 107:
																																				goto IL_03f6;
																																			case 116:
																																				goto IL_0403;
																																			case 118:
																																				goto IL_0413;
																																			case 8:
																																				goto IL_0423;
																																			case 48:
																																				goto IL_0436;
																																			case 69:
																																			case 186:
																																				goto IL_0446;
																																			case 37:
																																				goto IL_0451;
																																			case 30:
																																			case 56:
																																				goto IL_0461;
																																			case 54:
																																			case 68:
																																				goto IL_047a;
																																			case 58:
																																			case 123:
																																				goto IL_048d;
																																			case 24:
																																				goto IL_04cd;
																																			case 131:
																																				goto IL_04ea;
																																			case 115:
																																			case 146:
																																				goto IL_04fd;
																																			case 62:
																																				goto IL_053d;
																																			case 14:
																																				goto IL_0551;
																																			case 178:
																																				goto IL_0564;
																																			case 6:
																																				goto IL_05a3;
																																			case 200:
																																				goto IL_05b6;
																																			case 182:
																																				goto IL_05c9;
																																			case 12:
																																			case 179:
																																				goto IL_05d4;
																																			case 154:
																																				goto IL_05e2;
																																			case 100:
																																			case 202:
																																				goto IL_05f0;
																																			case 198:
																																				goto IL_05fe;
																																			case 176:
																																				goto IL_0621;
																																			case 124:
																																				goto IL_062b;
																																			case 183:
																																				goto IL_0639;
																																			case 81:
																																				goto IL_064c;
																																			case 120:
																																			case 214:
																																				goto IL_065a;
																																			case 7:
																																				goto IL_0683;
																																			case 167:
																																				goto IL_0691;
																																			case 32:
																																				goto IL_06a4;
																																			case 70:
																																				goto IL_06b2;
																																			case 33:
																																			case 156:
																																				goto IL_06c0;
																																			case 1:
																																			case 41:
																																				goto IL_06ce;
																																			case 208:
																																				goto IL_06dc;
																																			case 143:
																																			case 166:
																																				goto IL_06ea;
																																			case 63:
																																				goto IL_072a;
																																			case 39:
																																				goto IL_073e;
																																			case 215:
																																				goto IL_0751;
																																			case 13:
																																			case 213:
																																				goto IL_075f;
																																			case 29:
																																				goto IL_079f;
																																			case 133:
																																				goto IL_07b3;
																																			case 15:
																																			case 209:
																																				goto IL_07c6;
																																			case 72:
																																			case 160:
																																				goto IL_07d9;
																																			case 27:
																																				goto IL_07e4;
																																			case 99:
																																			case 157:
																																				goto IL_07f2;
																																			case 82:
																																				goto IL_0832;
																																			case 66:
																																				goto IL_0846;
																																			case 153:
																																				goto IL_0859;
																																			case 173:
																																				goto IL_0867;
																																			case 21:
																																			case 162:
																																				goto IL_0875;
																																			case 18:
																																				goto IL_08d7;
																																			case 108:
																																				goto IL_08ea;
																																			case 161:
																																				goto IL_08f8;
																																			case 105:
																																				goto IL_0906;
																																			case 16:
																																			case 79:
																																				goto IL_0914;
																																			case 121:
																																				goto IL_091f;
																																			case 75:
																																			case 211:
																																				goto IL_092d;
																																			case 175:
																																				goto IL_0956;
																																			case 45:
																																			case 204:
																																				goto IL_096f;
																																			case 83:
																																				goto IL_097d;
																																			case 114:
																																			case 193:
																																				goto IL_098b;
																																			case 17:
																																				goto IL_09a3;
																																			case 171:
																																				goto IL_09c1;
																																			case 31:
																																				goto IL_09e5;
																																			case 217:
																																				goto IL_09fd;
																																			case 158:
																																				goto IL_0a10;
																																			case 103:
																																				goto IL_0a1e;
																																			case 130:
																																			case 138:
																																				goto IL_0a2c;
																																			case 164:
																																				goto IL_0a3a;
																																			case 122:
																																			case 168:
																																				goto IL_0a48;
																																			case 53:
																																				goto IL_0aff;
																																			case 128:
																																				goto IL_0b0d;
																																			case 218:
																																				goto IL_0b20;
																																			case 77:
																																			case 104:
																																				goto IL_0b33;
																																			case 149:
																																				goto IL_0b5a;
																																			case 36:
																																				goto IL_0b68;
																																			case 9:
																																			case 177:
																																				goto IL_0b7b;
																																			case 163:
																																				goto IL_0b89;
																																			case 127:
																																				goto IL_0ba1;
																																			case 194:
																																				goto IL_0baf;
																																			case 150:
																																				goto IL_0bc2;
																																			case 110:
																																			case 201:
																																				goto IL_0bcd;
																																			case 134:
																																			case 203:
																																				goto IL_0bd8;
																																			case 0:
																																				goto IL_0be6;
																																			case 20:
																																			case 139:
																																				goto IL_0bf1;
																																			case 94:
																																				goto IL_0c1b;
																																			case 19:
																																			case 117:
																																				goto IL_0c29;
																																			case 155:
																																				goto IL_0c4a;
																																			case 74:
																																			case 119:
																																				goto IL_0c58;
																																			case 52:
																																				goto IL_0c63;
																																			case 76:
																																			case 181:
																																				goto IL_0c71;
																																			case 191:
																																				goto IL_0caf;
																																			case 51:
																																			case 132:
																																				goto IL_0cc2;
																																			case 169:
																																				goto IL_0cd0;
																																			case 35:
																																			case 106:
																																				goto IL_0cde;
																																			case 151:
																																				goto IL_0cf2;
																																			case 199:
																																				goto IL_0d2a;
																																			case 145:
																																			case 184:
																																				goto IL_0d46;
																																			case 135:
																																				goto IL_0d5f;
																																			case 136:
																																				goto IL_0d6d;
																																			case 102:
																																				goto IL_0d7b;
																																			case 2:
																																			case 3:
																																			case 5:
																																			case 10:
																																			case 23:
																																			case 25:
																																			case 26:
																																			case 28:
																																			case 34:
																																			case 40:
																																			case 42:
																																			case 43:
																																			case 44:
																																			case 46:
																																			case 49:
																																			case 57:
																																			case 71:
																																			case 73:
																																			case 87:
																																			case 89:
																																			case 91:
																																			case 92:
																																			case 96:
																																			case 98:
																																			case 101:
																																			case 109:
																																			case 111:
																																			case 137:
																																			case 140:
																																			case 142:
																																			case 147:
																																			case 165:
																																			case 174:
																																			case 187:
																																			case 188:
																																			case 189:
																																			case 190:
																																			case 196:
																																			case 197:
																																			case 206:
																																				goto end_IL_03b3;
																																			case 59:
																																				goto IL_0da4;
																																			case 205:
																																				goto IL_0db2;
																																			case 129:
																																				goto IL_0dc0;
																																			case 22:
																																			case 47:
																																			case 50:
																																			case 55:
																																			case 60:
																																			case 61:
																																			case 64:
																																			case 65:
																																			case 67:
																																			case 78:
																																			case 80:
																																			case 93:
																																			case 95:
																																			case 112:
																																			case 113:
																																			case 126:
																																			case 144:
																																			case 148:
																																			case 172:
																																			case 180:
																																			case 185:
																																			case 192:
																																			case 207:
																																			case 210:
																																			case 219:
																																				goto IL_0dce;
																																			case 216:
																																				goto IL_0de1;
																																			case 159:
																																				goto IL_0deb;
																																			case 4:
																																				goto IL_0df6;
																																			case 88:
																																				goto IL_0e06;
																																			case 152:
																																				goto IL_0e16;
																																			case 97:
																																				goto IL_0e26;
																																			case 170:
																																				goto IL_0e3f;
																																			case 90:
																																				goto IL_0e4f;
																																			case 212:
																																				goto IL_0e5f;
																																			case 195:
																																				goto IL_0e6f;
																																			case 84:
																																				goto IL_0e7f;
																																			case 38:
																																			case 125:
																																				goto IL_0eac;
																																			}
																																			goto end_IL_0423;
																																		}
																																		goto IL_05c9;
																																		IL_0683:
																																		ptr2 += 8;
																																		goto IL_0691;
																																		IL_0691:
																																		num6--;
																																		goto IL_0dce;
																																		IL_05c9:
																																		if (3 < b)
																																		{
																																			goto IL_05d4;
																																		}
																																		goto IL_064c;
																																		IL_05d4:
																																		if (4 < b)
																																		{
																																			break;
																																		}
																																		goto IL_05e2;
																																		IL_05e2:
																																		if (4 > b)
																																		{
																																			break;
																																		}
																																		goto IL_05f0;
																																		IL_05f0:
																																		array2[num6] = 0;
																																		goto IL_05fe;
																																		IL_05fe:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																		goto IL_0621;
																																		IL_0621:
																																		array3[num6] = null;
																																		goto IL_062b;
																																		IL_062b:
																																		num6++;
																																		goto IL_0639;
																																		IL_0639:
																																		ptr2 += 8;
																																		goto IL_0dce;
																																		IL_064c:
																																		if (3 > b)
																																		{
																																			break;
																																		}
																																		goto IL_065a;
																																		IL_065a:
																																		reference = ref array5[*(int*)(ptr2 + num3)];
																																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_0683;
																																		continue;
																																		end_IL_03b3:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0451;
																																IL_053d:
																																array2[num6 - 2] = 0;
																																goto IL_0551;
																																IL_0551:
																																num6--;
																																goto IL_0dce;
																																IL_0451:
																																if (2 > b)
																																{
																																	goto IL_047a;
																																}
																																goto IL_04fd;
																																IL_047a:
																																if (1 < b)
																																{
																																	break;
																																}
																																goto IL_05b6;
																																IL_05b6:
																																if (1 <= b)
																																{
																																}
																																break;
																																IL_04fd:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_053d;
																															}
																															break;
																														}
																														goto IL_048d;
																														IL_04ea:
																														num6--;
																														goto IL_0dce;
																														IL_048d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_04cd;
																														IL_04cd:
																														array2[num6 - 2] = 0;
																														num = 131;
																														goto IL_04ea;
																													}
																													break;
																												}
																												goto IL_06a4;
																												IL_08d7:
																												num6 -= 2;
																												goto IL_0dce;
																												IL_06a4:
																												if (8 >= b)
																												{
																													goto IL_06b2;
																												}
																												goto IL_07d9;
																												IL_06b2:
																												if (8 > b)
																												{
																													goto IL_06c0;
																												}
																												goto IL_07c6;
																												IL_06c0:
																												if (6 < b)
																												{
																													goto IL_06ce;
																												}
																												goto IL_0751;
																												IL_06ce:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_06dc;
																												IL_06dc:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_06ea;
																												IL_06ea:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_072a;
																												IL_072a:
																												array2[num6 - 2] = 0;
																												goto IL_073e;
																												IL_073e:
																												num6--;
																												goto IL_0dce;
																												IL_0751:
																												if (6 > b)
																												{
																													break;
																												}
																												goto IL_075f;
																												IL_075f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_079f;
																												IL_079f:
																												array2[num6 - 2] = 0;
																												goto IL_07b3;
																												IL_07b3:
																												num6--;
																												goto IL_0dce;
																												IL_07c6:
																												num6--;
																												goto IL_0dce;
																												IL_07d9:
																												if (9 >= b)
																												{
																													goto IL_07e4;
																												}
																												goto IL_0859;
																												IL_07e4:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_07f2;
																												IL_07f2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0832;
																												IL_0832:
																												array2[num6 - 2] = 0;
																												goto IL_0846;
																												IL_0846:
																												num6--;
																												goto IL_0dce;
																												IL_0859:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_0867;
																												IL_0867:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_0875;
																												IL_0875:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_08d7;
																											}
																											break;
																										}
																										goto IL_0461;
																										IL_05a3:
																										ptr2 += 8;
																										goto IL_0dce;
																										IL_0461:
																										array2[num6 - 1] = 0;
																										goto IL_0564;
																										IL_0564:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)IContextPropertyGetArrayMethod[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_05a3;
																									}
																									break;
																								}
																								goto IL_08ea;
																								IL_0d2a:
																								ptr2 += 8;
																								num = 64;
																								goto IL_0dce;
																								IL_08ea:
																								if (17 >= b)
																								{
																									goto IL_08f8;
																								}
																								goto IL_0bc2;
																								IL_08f8:
																								if (17 > b)
																								{
																									goto IL_0906;
																								}
																								goto IL_0b7b;
																								IL_0906:
																								if (14 < b)
																								{
																									goto IL_0914;
																								}
																								goto IL_0a10;
																								IL_0914:
																								if (15 >= b)
																								{
																									goto IL_091f;
																								}
																								goto IL_096f;
																								IL_091f:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_092d;
																								IL_092d:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_0956;
																								IL_0956:
																								array2[num6 - 1] = 5;
																								goto IL_0dce;
																								IL_096f:
																								if (16 < b)
																								{
																									break;
																								}
																								goto IL_097d;
																								IL_097d:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_098b;
																								IL_098b:
																								array2[num6] = array2[num6 - 1];
																								goto IL_09a3;
																								IL_09a3:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_09c1;
																								IL_09c1:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09e5;
																								IL_09e5:
																								array3[num6] = array3[num6 - 1];
																								goto IL_09fd;
																								IL_09fd:
																								num6++;
																								goto IL_0dce;
																								IL_0a10:
																								if (14 > b)
																								{
																									goto IL_0a1e;
																								}
																								goto IL_0b33;
																								IL_0a1e:
																								if (12 < b)
																								{
																									goto IL_0a2c;
																								}
																								goto IL_0b20;
																								IL_0a2c:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_0a3a;
																								IL_0a3a:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_0a48;
																								IL_0a48:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0a57;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0aff;
																								IL_0d46:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0d5f;
																								IL_0d5f:
																								array2[num6] = 1;
																								goto IL_0d6d;
																								IL_0d6d:
																								num6++;
																								goto IL_0d7b;
																								IL_0aff:
																								array2[num6] = 5;
																								goto IL_0b0d;
																								IL_0b0d:
																								num6++;
																								goto IL_0dce;
																								IL_0b20:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0dce;
																								IL_0b33:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								num = 149;
																								goto IL_0b5a;
																								IL_0b5a:
																								ptr2 += 8;
																								goto IL_0b68;
																								IL_0b68:
																								num6--;
																								goto IL_0dce;
																								IL_0b7b:
																								array2[num6] = 5;
																								goto IL_0b89;
																								IL_0b89:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0ba1;
																								IL_0ba1:
																								num6++;
																								goto IL_0baf;
																								IL_0baf:
																								ptr2 += 8;
																								goto IL_0dce;
																								IL_0bc2:
																								if (20 < b)
																								{
																									goto IL_0bcd;
																								}
																								goto IL_0c4a;
																								IL_0bcd:
																								if (21 < b)
																								{
																									goto IL_0bd8;
																								}
																								goto IL_0c1b;
																								IL_0bd8:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_0be6;
																								IL_0be6:
																								if (22 > b)
																								{
																									num = 142;
																									break;
																								}
																								goto IL_0bf1;
																								IL_0bf1:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_0dce;
																								IL_0d7b:
																								ptr2 += 16;
																								goto IL_0dce;
																								IL_0c1b:
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_0c29;
																								IL_0c29:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								num = 78;
																								goto IL_0dce;
																								IL_0c4a:
																								if (20 > b)
																								{
																									goto IL_0c58;
																								}
																								goto IL_0d46;
																								IL_0c58:
																								if (18 >= b)
																								{
																									goto IL_0c63;
																								}
																								goto IL_0cc2;
																								IL_0c63:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_0c71;
																								IL_0c71:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_0caf;
																								IL_0caf:
																								num6 -= 3;
																								goto IL_0dce;
																								IL_0cc2:
																								if (19 < b)
																								{
																									break;
																								}
																								goto IL_0cd0;
																								IL_0cd0:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_0cde;
																								IL_0cde:
																								array2[num6 - 1] = 5;
																								goto IL_0cf2;
																								IL_0cf2:
																								array3[num6 - 1] = ((delegate*<string[], string>)IContextPropertyGetArrayMethod[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0d2a;
																							}
																							break;
																							IL_0413:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0da4;
																					IL_0db2:
																					num6++;
																					goto IL_0dc0;
																					IL_0dc0:
																					ptr2 += 8;
																					goto IL_0dce;
																					IL_0da4:
																					array2[num6] = 0;
																					goto IL_0db2;
																					continue;
																					end_IL_0423:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	num = 125;
																	goto IL_0eac;
																	IL_0eac:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0a57:
				while (true)
				{
					IL_0a57_2:
					array = new byte[4];
					while (true)
					{
						IL_0a65:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0b0d_2:
								num6++;
								while (true)
								{
									IL_0dce_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0423_2:
													if (b >= 1)
													{
														num = 118;
														while (b <= 22)
														{
															while (true)
															{
																IL_0403_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_03f6_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_03e6_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_03d6_2:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_03c6_2:
																								if (2 < b)
																								{
																									num = 226;
																									while (true)
																									{
																										if (num != 226)
																										{
																											if (num != 1207)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 141:
																												goto IL_03c6_2;
																											case 11:
																												goto IL_03d6_2;
																											case 86:
																												goto IL_03e6_2;
																											case 107:
																												goto IL_03f6_2;
																											case 116:
																												goto IL_0403_2;
																											case 118:
																												goto IL_0413_2;
																											case 8:
																												goto IL_0423_2;
																											case 48:
																												goto end_IL_0423_2;
																											case 69:
																											case 186:
																												goto end_IL_0436;
																											case 37:
																												goto IL_0451_2;
																											case 30:
																											case 56:
																												goto IL_0461_2;
																											case 54:
																											case 68:
																												goto IL_047a_2;
																											case 58:
																											case 123:
																												goto IL_048d_2;
																											case 24:
																												goto IL_04cd_2;
																											case 131:
																												goto IL_04ea_2;
																											case 115:
																											case 146:
																												goto IL_04fd_2;
																											case 62:
																												goto IL_053d_2;
																											case 14:
																												goto IL_0551_2;
																											case 178:
																												goto IL_0564_2;
																											case 6:
																												goto IL_05a3_2;
																											case 200:
																												goto IL_05b6_2;
																											case 182:
																												goto IL_05c9_2;
																											case 12:
																											case 179:
																												goto IL_05d4_2;
																											case 154:
																												goto IL_05e2_2;
																											case 100:
																											case 202:
																												goto IL_05f0_2;
																											case 198:
																												goto IL_05fe_2;
																											case 176:
																												goto IL_0621_2;
																											case 124:
																												goto IL_062b_2;
																											case 183:
																												goto IL_0639_2;
																											case 81:
																												goto IL_064c_2;
																											case 120:
																											case 214:
																												goto IL_065a_2;
																											case 7:
																												goto IL_0683_2;
																											case 167:
																												goto IL_0691_2;
																											case 32:
																												goto IL_06a4_2;
																											case 70:
																												goto IL_06b2_2;
																											case 33:
																											case 156:
																												goto IL_06c0_2;
																											case 1:
																											case 41:
																												goto IL_06ce_2;
																											case 208:
																												goto IL_06dc_2;
																											case 143:
																											case 166:
																												goto IL_06ea_2;
																											case 63:
																												goto IL_072a_2;
																											case 39:
																												goto IL_073e_2;
																											case 215:
																												goto IL_0751_2;
																											case 13:
																											case 213:
																												goto IL_075f_2;
																											case 29:
																												goto IL_079f_2;
																											case 133:
																												goto IL_07b3_2;
																											case 15:
																											case 209:
																												goto IL_07c6_2;
																											case 72:
																											case 160:
																												goto IL_07d9_2;
																											case 27:
																												goto IL_07e4_2;
																											case 99:
																											case 157:
																												goto IL_07f2_2;
																											case 82:
																												goto IL_0832_2;
																											case 66:
																												goto IL_0846_2;
																											case 153:
																												goto IL_0859_2;
																											case 173:
																												goto IL_0867_2;
																											case 21:
																											case 162:
																												goto IL_0875_2;
																											case 18:
																												goto IL_08d7_2;
																											case 108:
																												goto IL_08ea_2;
																											case 161:
																												goto IL_08f8_2;
																											case 105:
																												goto IL_0906_2;
																											case 16:
																											case 79:
																												goto IL_0914_2;
																											case 121:
																												goto IL_091f_2;
																											case 75:
																											case 211:
																												goto IL_092d_2;
																											case 175:
																												goto IL_0956_2;
																											case 45:
																											case 204:
																												goto IL_096f_2;
																											case 83:
																												goto IL_097d_2;
																											case 114:
																											case 193:
																												goto IL_098b_2;
																											case 17:
																												goto IL_09a3_2;
																											case 171:
																												goto IL_09c1_2;
																											case 31:
																												goto IL_09e5_2;
																											case 217:
																												goto IL_09fd_2;
																											case 158:
																												goto IL_0a10_2;
																											case 103:
																												goto IL_0a1e_2;
																											case 130:
																											case 138:
																												goto IL_0a2c_2;
																											case 164:
																												goto IL_0a3a_2;
																											case 122:
																											case 168:
																												goto IL_0a48_2;
																											case 53:
																												goto end_IL_0446;
																											case 128:
																												goto IL_0b0d_2;
																											case 218:
																												goto IL_0b20_2;
																											case 77:
																											case 104:
																												goto IL_0b33_2;
																											case 149:
																												goto IL_0b5a_2;
																											case 36:
																												goto IL_0b68_2;
																											case 9:
																											case 177:
																												goto IL_0b7b_2;
																											case 163:
																												goto IL_0b89_2;
																											case 127:
																												goto IL_0ba1_2;
																											case 194:
																												goto IL_0baf_2;
																											case 150:
																												goto IL_0bc2_2;
																											case 110:
																											case 201:
																												goto IL_0bcd_2;
																											case 134:
																											case 203:
																												goto IL_0bd8_2;
																											case 0:
																												goto IL_0be6_2;
																											case 20:
																											case 139:
																												goto IL_0bf1_2;
																											case 94:
																												goto IL_0c1b_2;
																											case 19:
																											case 117:
																												goto IL_0c29_2;
																											case 155:
																												goto IL_0c4a_2;
																											case 74:
																											case 119:
																												goto IL_0c58_2;
																											case 52:
																												goto IL_0c63_2;
																											case 76:
																											case 181:
																												goto IL_0c71_2;
																											case 191:
																												goto IL_0caf_2;
																											case 51:
																											case 132:
																												goto IL_0cc2_2;
																											case 169:
																												goto IL_0cd0_2;
																											case 35:
																											case 106:
																												goto IL_0cde_2;
																											case 151:
																												goto IL_0cf2_2;
																											case 199:
																												goto IL_0d2a_2;
																											case 145:
																											case 184:
																												goto IL_0d46_2;
																											case 135:
																												goto IL_0d5f_2;
																											case 136:
																												goto IL_0d6d_2;
																											case 102:
																												goto IL_0d7b_2;
																											case 2:
																											case 3:
																											case 5:
																											case 10:
																											case 23:
																											case 25:
																											case 26:
																											case 28:
																											case 34:
																											case 40:
																											case 42:
																											case 43:
																											case 44:
																											case 46:
																											case 49:
																											case 57:
																											case 71:
																											case 73:
																											case 87:
																											case 89:
																											case 91:
																											case 92:
																											case 96:
																											case 98:
																											case 101:
																											case 109:
																											case 111:
																											case 137:
																											case 140:
																											case 142:
																											case 147:
																											case 165:
																											case 174:
																											case 187:
																											case 188:
																											case 189:
																											case 190:
																											case 196:
																											case 197:
																											case 206:
																												goto end_IL_03b3_2;
																											case 59:
																												goto IL_0da4_2;
																											case 205:
																												goto IL_0db2_2;
																											case 129:
																												goto IL_0dc0_2;
																											case 22:
																											case 47:
																											case 50:
																											case 55:
																											case 60:
																											case 61:
																											case 64:
																											case 65:
																											case 67:
																											case 78:
																											case 80:
																											case 93:
																											case 95:
																											case 112:
																											case 113:
																											case 126:
																											case 144:
																											case 148:
																											case 172:
																											case 180:
																											case 185:
																											case 192:
																											case 207:
																											case 210:
																											case 219:
																												goto IL_0dce_2;
																											case 216:
																												ptr2 = ptr;
																												goto IL_0dce_2;
																											case 159:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeLibExporterFlagsActivatorCache.IsCanceledlcid);
																												goto case 216;
																											case 4:
																												array7 = new object[11];
																												goto case 159;
																											case 88:
																												array6 = new long[4];
																												goto case 4;
																											case 152:
																												array5 = new int[6];
																												goto case 88;
																											case 97:
																												array4 = new int[4];
																												num = 152;
																												goto case 152;
																											case 170:
																												array3 = new object[4];
																												goto case 97;
																											case 90:
																												array2 = new byte[4];
																												goto case 170;
																											case 212:
																												num4 = num2 * 8;
																												goto case 90;
																											case 195:
																												num3 = num2 * 4;
																												goto case 212;
																											case 84:
																												num2 = 1;
																												goto case 195;
																											case 85:
																												goto end_IL_0aff;
																											case 38:
																											case 125:
																												goto IL_0eac_2;
																											}
																											continue;
																										}
																										goto IL_05c9_2;
																										IL_0683_2:
																										ptr2 += 8;
																										goto IL_0691_2;
																										IL_0691_2:
																										num6--;
																										goto IL_0dce_2;
																										IL_05c9_2:
																										if (3 < b)
																										{
																											goto IL_05d4_2;
																										}
																										goto IL_064c_2;
																										IL_05d4_2:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_05e2_2;
																										IL_05e2_2:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_05f0_2;
																										IL_05f0_2:
																										array2[num6] = 0;
																										goto IL_05fe_2;
																										IL_05fe_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_0621_2;
																										IL_0621_2:
																										array3[num6] = null;
																										goto IL_062b_2;
																										IL_062b_2:
																										num6++;
																										goto IL_0639_2;
																										IL_0639_2:
																										ptr2 += 8;
																										goto IL_0dce_2;
																										IL_064c_2:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_065a_2;
																										IL_065a_2:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0683_2;
																										continue;
																										end_IL_03b3_2:
																										break;
																									}
																									break;
																								}
																								goto IL_0451_2;
																								IL_053d_2:
																								array2[num6 - 2] = 0;
																								goto IL_0551_2;
																								IL_0551_2:
																								num6--;
																								goto IL_0dce_2;
																								IL_0451_2:
																								if (2 > b)
																								{
																									goto IL_047a_2;
																								}
																								goto IL_04fd_2;
																								IL_047a_2:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_05b6_2;
																								IL_05b6_2:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_04fd_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_053d_2;
																							}
																							break;
																						}
																						goto IL_048d_2;
																						IL_04ea_2:
																						num6--;
																						goto IL_0dce_2;
																						IL_048d_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_04cd_2;
																						IL_04cd_2:
																						array2[num6 - 2] = 0;
																						num = 131;
																						goto IL_04ea_2;
																					}
																					break;
																				}
																				goto IL_06a4_2;
																				IL_08d7_2:
																				num6 -= 2;
																				goto IL_0dce_2;
																				IL_06a4_2:
																				if (8 >= b)
																				{
																					goto IL_06b2_2;
																				}
																				goto IL_07d9_2;
																				IL_06b2_2:
																				if (8 > b)
																				{
																					goto IL_06c0_2;
																				}
																				goto IL_07c6_2;
																				IL_06c0_2:
																				if (6 < b)
																				{
																					goto IL_06ce_2;
																				}
																				goto IL_0751_2;
																				IL_06ce_2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_06dc_2;
																				IL_06dc_2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_06ea_2;
																				IL_06ea_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_072a_2;
																				IL_072a_2:
																				array2[num6 - 2] = 0;
																				goto IL_073e_2;
																				IL_073e_2:
																				num6--;
																				goto IL_0dce_2;
																				IL_0751_2:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_075f_2;
																				IL_075f_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_079f_2;
																				IL_079f_2:
																				array2[num6 - 2] = 0;
																				goto IL_07b3_2;
																				IL_07b3_2:
																				num6--;
																				goto IL_0dce_2;
																				IL_07c6_2:
																				num6--;
																				goto IL_0dce_2;
																				IL_07d9_2:
																				if (9 >= b)
																				{
																					goto IL_07e4_2;
																				}
																				goto IL_0859_2;
																				IL_07e4_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_07f2_2;
																				IL_07f2_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0832_2;
																				IL_0832_2:
																				array2[num6 - 2] = 0;
																				goto IL_0846_2;
																				IL_0846_2:
																				num6--;
																				goto IL_0dce_2;
																				IL_0859_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0867_2;
																				IL_0867_2:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0875_2;
																				IL_0875_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08d7_2;
																			}
																			break;
																		}
																		goto IL_0461_2;
																		IL_05a3_2:
																		ptr2 += 8;
																		goto IL_0dce_2;
																		IL_0461_2:
																		array2[num6 - 1] = 0;
																		goto IL_0564_2;
																		IL_0564_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)IContextPropertyGetArrayMethod[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_05a3_2;
																	}
																	break;
																}
																goto IL_08ea_2;
																IL_0d6d_2:
																num6++;
																goto IL_0d7b_2;
																IL_08ea_2:
																if (17 >= b)
																{
																	goto IL_08f8_2;
																}
																goto IL_0bc2_2;
																IL_08f8_2:
																if (17 > b)
																{
																	goto IL_0906_2;
																}
																goto IL_0b7b_2;
																IL_0906_2:
																if (14 < b)
																{
																	goto IL_0914_2;
																}
																goto IL_0a10_2;
																IL_0914_2:
																if (15 >= b)
																{
																	goto IL_091f_2;
																}
																goto IL_096f_2;
																IL_091f_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_092d_2;
																IL_092d_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_0956_2;
																IL_0956_2:
																array2[num6 - 1] = 5;
																goto IL_0dce_2;
																IL_096f_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_097d_2;
																IL_097d_2:
																if (16 > b)
																{
																	break;
																}
																goto IL_098b_2;
																IL_098b_2:
																array2[num6] = array2[num6 - 1];
																goto IL_09a3_2;
																IL_09a3_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_09c1_2;
																IL_09c1_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09e5_2;
																IL_09e5_2:
																array3[num6] = array3[num6 - 1];
																goto IL_09fd_2;
																IL_09fd_2:
																num6++;
																goto IL_0dce_2;
																IL_0a10_2:
																if (14 > b)
																{
																	goto IL_0a1e_2;
																}
																goto IL_0b33_2;
																IL_0a1e_2:
																if (12 < b)
																{
																	goto IL_0a2c_2;
																}
																goto IL_0b20_2;
																IL_0a2c_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_0a3a_2;
																IL_0a3a_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_0a48_2;
																IL_0a48_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0a57_2;
																}
																goto IL_0a65;
																IL_0b20_2:
																if (12 > b)
																{
																	break;
																}
																goto IL_0dce_2;
																IL_0b33_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																num = 149;
																goto IL_0b5a_2;
																IL_0b5a_2:
																ptr2 += 8;
																goto IL_0b68_2;
																IL_0b68_2:
																num6--;
																goto IL_0dce_2;
																IL_0b7b_2:
																array2[num6] = 5;
																goto IL_0b89_2;
																IL_0b89_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0ba1_2;
																IL_0ba1_2:
																num6++;
																goto IL_0baf_2;
																IL_0baf_2:
																ptr2 += 8;
																goto IL_0dce_2;
																IL_0bc2_2:
																if (20 < b)
																{
																	goto IL_0bcd_2;
																}
																goto IL_0c4a_2;
																IL_0bcd_2:
																if (21 < b)
																{
																	goto IL_0bd8_2;
																}
																goto IL_0c1b_2;
																IL_0bd8_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_0be6_2;
																IL_0be6_2:
																if (22 > b)
																{
																	num = 142;
																	break;
																}
																goto IL_0bf1_2;
																IL_0bf1_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																goto IL_0dce_2;
																IL_0d7b_2:
																ptr2 += 16;
																goto IL_0dce_2;
																IL_0c1b_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_0c29_2;
																IL_0c29_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 78;
																goto IL_0dce_2;
																IL_0c4a_2:
																if (20 > b)
																{
																	goto IL_0c58_2;
																}
																goto IL_0d46_2;
																IL_0c58_2:
																if (18 >= b)
																{
																	goto IL_0c63_2;
																}
																goto IL_0cc2_2;
																IL_0c63_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_0c71_2;
																IL_0c71_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0caf_2;
																IL_0caf_2:
																num6 -= 3;
																goto IL_0dce_2;
																IL_0cc2_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0cd0_2;
																IL_0cd0_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_0cde_2;
																IL_0cde_2:
																array2[num6 - 1] = 5;
																goto IL_0cf2_2;
																IL_0cf2_2:
																array3[num6 - 1] = ((delegate*<string[], string>)IContextPropertyGetArrayMethod[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0d2a_2;
																IL_0d2a_2:
																ptr2 += 8;
																num = 64;
																goto IL_0dce_2;
																IL_0d46_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0d5f_2;
																IL_0d5f_2:
																array2[num6] = 1;
																goto IL_0d6d_2;
															}
															break;
															IL_0413_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0da4_2;
													IL_0db2_2:
													num6++;
													goto IL_0dc0_2;
													IL_0dc0_2:
													ptr2 += 8;
													goto IL_0dce_2;
													IL_0da4_2:
													array2[num6] = 0;
													goto IL_0db2_2;
													continue;
													end_IL_0423_2:
													break;
												}
												continue;
												end_IL_0436:
												break;
											}
											continue;
											end_IL_0446:
											break;
										}
										break;
									}
									num = 125;
									goto IL_0eac_2;
									IL_0eac_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0aff:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_037b, IL_038e, IL_03ad, IL_03ef, IL_03ff, IL_040f, IL_041f, IL_042f, IL_043f, IL_044f, IL_045f, IL_046c, IL_047c, IL_048c, IL_049c, IL_04b0, IL_04c3, IL_04d3, IL_04e1, IL_04ef, IL_052f, IL_0548, IL_055c, IL_059b, IL_05ae, IL_05b9, IL_05cc, IL_05d7, IL_05e2, IL_0600, IL_0613, IL_0621, IL_062f, IL_063d, IL_0648, IL_0656, IL_067f, IL_06a1, IL_06b4, IL_06cc, IL_06da, IL_06ed, IL_0700, IL_070e, IL_0721, IL_073d, IL_074b, IL_0756, IL_076f, IL_077d, IL_0790, IL_079b, IL_07a9, IL_07e7, IL_07fa, IL_0808, IL_0816, IL_082a, IL_0862, IL_0875, IL_0880, IL_088e, IL_08a6, IL_08b4, IL_08c2, IL_08de, IL_08ec, IL_0904, IL_0922, IL_094f, IL_0967, IL_097a, IL_098d, IL_09aa, IL_09f9, IL_0a03, IL_0a30, IL_0a44, IL_0a52, IL_0a65, IL_0a78, IL_0a83, IL_0a91, IL_0ad1, IL_0ae5, IL_0af8, IL_0b06, IL_0b11, IL_0b73, IL_0b86, IL_0b94, IL_0ba2, IL_0bb0, IL_0bbb, IL_0bc9, IL_0bf2, IL_0c00, IL_0c13, IL_0c21, IL_0c2f, IL_0c3d, IL_0c69, IL_0c73, IL_0c81, IL_0c94, IL_0c9f, IL_0caa, IL_0cbd, IL_0ccb, IL_0d0b, IL_0d1f, IL_0d32, IL_0d72, IL_0d8f, IL_0d9f, IL_0db8, IL_0dc6, IL_0dd4, IL_0de2, IL_0df5, IL_0dff, IL_0e0a, IL_0e1a, IL_0e2a, IL_0e3a, IL_0e4a, IL_0e5a, IL_0e73, IL_0e83, IL_0e93, IL_0eae are reachable both inside and outside the pinned region starting at IL_0ea8. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 63;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef15 = default(int);
				ref int reference = ref __rxRef15;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e93:
						num2 = 1;
						while (true)
						{
							IL_0e83:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e73:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e5a:
									array2 = new byte[4];
									num = 129;
									while (true)
									{
										IL_0e4a:
										array3 = new object[4];
										while (true)
										{
											IL_0e3a:
											array4 = new int[4];
											while (true)
											{
												IL_0e2a:
												array5 = new int[6];
												while (true)
												{
													IL_0e1a:
													array6 = new long[4];
													while (true)
													{
														IL_0e0a:
														array7 = new object[17];
														while (true)
														{
															IL_0dff:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CModOptLIBFLAGS.ENDTryPopRange);
															while (true)
															{
																IL_0df5:
																ptr2 = ptr;
																while (true)
																{
																	IL_0de2:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_049c:
																			byte b = *ptr2;
																			num = 96;
																			while (true)
																			{
																				IL_048c:
																				ptr2++;
																				while (true)
																				{
																					IL_047c:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_045f:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_044f:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_043f:
																												if (5 < b)
																												{
																													while (true)
																													{
																														IL_042f:
																														if (8 >= b)
																														{
																															while (true)
																															{
																																IL_041f:
																																if (8 > b)
																																{
																																	while (true)
																																	{
																																		IL_040f:
																																		if (6 < b)
																																		{
																																			while (7 >= b)
																																			{
																																				while (7 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_03ad:
																																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																						while (true)
																																						{
																																							IL_038e:
																																							array2[num6 - 2] = 0;
																																							num = 219;
																																							while (true)
																																							{
																																								if (num != 219)
																																								{
																																									if (num != 1200)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 63:
																																										break;
																																									default:
																																										continue;
																																									case 128:
																																										goto IL_038e;
																																									case 98:
																																									case 212:
																																										goto IL_03ad;
																																									case 207:
																																										goto IL_03ef;
																																									case 106:
																																									case 135:
																																										goto IL_03ff;
																																									case 35:
																																									case 157:
																																										goto IL_040f;
																																									case 114:
																																										goto IL_041f;
																																									case 38:
																																									case 158:
																																										goto IL_042f;
																																									case 208:
																																										goto IL_043f;
																																									case 65:
																																										goto IL_044f;
																																									case 101:
																																										goto IL_045f;
																																									case 76:
																																										goto IL_046c;
																																									case 36:
																																										goto IL_047c;
																																									case 96:
																																										goto IL_048c;
																																									case 97:
																																									case 148:
																																										goto IL_049c;
																																									case 20:
																																									case 66:
																																										goto IL_04b0;
																																									case 123:
																																										goto IL_04c3;
																																									case 80:
																																									case 134:
																																										goto IL_04d3;
																																									case 5:
																																									case 163:
																																										goto IL_04ef;
																																									case 145:
																																										goto IL_052f;
																																									case 68:
																																									case 172:
																																										goto IL_0548;
																																									case 64:
																																										goto IL_055c;
																																									case 74:
																																										goto IL_059b;
																																									case 180:
																																										goto IL_05ae;
																																									case 83:
																																									case 166:
																																										goto IL_05b9;
																																									case 73:
																																										goto IL_05cc;
																																									case 57:
																																										goto IL_05d7;
																																									case 116:
																																									case 167:
																																										goto IL_05e2;
																																									case 67:
																																										goto IL_0600;
																																									case 160:
																																										goto IL_0613;
																																									case 93:
																																										goto IL_0621;
																																									case 58:
																																										goto IL_063d;
																																									case 55:
																																										goto IL_0648;
																																									case 21:
																																									case 165:
																																										goto end_IL_037b;
																																									case 13:
																																										goto IL_067f;
																																									case 52:
																																										goto IL_06a1;
																																									case 189:
																																										goto IL_06b4;
																																									case 4:
																																										goto IL_06cc;
																																									case 70:
																																										goto IL_06da;
																																									case 190:
																																										goto IL_06ed;
																																									case 37:
																																									case 200:
																																										goto IL_0700;
																																									case 121:
																																										goto IL_070e;
																																									case 201:
																																										goto IL_0721;
																																									case 204:
																																										goto IL_073d;
																																									case 71:
																																										goto IL_074b;
																																									case 12:
																																									case 111:
																																										goto IL_0756;
																																									case 34:
																																										goto IL_076f;
																																									case 95:
																																										goto IL_077d;
																																									case 127:
																																										goto IL_0790;
																																									case 6:
																																										goto IL_079b;
																																									case 69:
																																									case 100:
																																										goto IL_07a9;
																																									case 141:
																																										goto IL_07e7;
																																									case 47:
																																										goto IL_07fa;
																																									case 84:
																																										goto IL_0808;
																																									case 137:
																																									case 182:
																																										goto IL_0816;
																																									case 177:
																																										goto IL_082a;
																																									case 108:
																																										goto IL_0862;
																																									case 202:
																																										goto IL_0875;
																																									case 25:
																																										goto IL_0880;
																																									case 15:
																																									case 99:
																																										goto IL_088e;
																																									case 109:
																																										goto IL_08a6;
																																									case 1:
																																										goto IL_08b4;
																																									case 155:
																																									case 161:
																																										goto IL_08c2;
																																									case 206:
																																										goto IL_08de;
																																									case 125:
																																									case 133:
																																										goto IL_08ec;
																																									case 26:
																																										goto IL_0904;
																																									case 10:
																																										goto IL_0922;
																																									case 41:
																																										goto IL_094f;
																																									case 184:
																																										goto IL_0967;
																																									case 209:
																																										goto IL_097a;
																																									case 17:
																																									case 211:
																																										goto IL_098d;
																																									case 122:
																																										goto IL_0a44;
																																									case 32:
																																										goto IL_0a52;
																																									case 39:
																																										goto IL_0a78;
																																									case 194:
																																										goto IL_0a83;
																																									case 87:
																																									case 118:
																																										goto IL_0a91;
																																									case 152:
																																										goto IL_0ad1;
																																									case 132:
																																										goto IL_0ae5;
																																									case 48:
																																										goto IL_0af8;
																																									case 142:
																																										goto IL_0b06;
																																									case 140:
																																									case 143:
																																										goto IL_0b11;
																																									case 85:
																																										goto IL_0b73;
																																									case 151:
																																										goto IL_0b94;
																																									case 203:
																																										goto IL_0ba2;
																																									case 49:
																																									case 210:
																																										goto IL_0bb0;
																																									case 56:
																																										goto IL_0bbb;
																																									case 147:
																																									case 192:
																																										goto IL_0bc9;
																																									case 117:
																																										goto IL_0bf2;
																																									case 44:
																																										goto IL_0c00;
																																									case 86:
																																										goto IL_0c13;
																																									case 178:
																																										goto IL_0c21;
																																									case 27:
																																									case 164:
																																										goto IL_0c2f;
																																									case 46:
																																										goto IL_0c3d;
																																									case 144:
																																										goto IL_0c69;
																																									case 187:
																																										goto IL_0c73;
																																									case 205:
																																										goto IL_0c81;
																																									case 2:
																																										goto IL_0c94;
																																									case 23:
																																									case 126:
																																										goto IL_0c9f;
																																									case 102:
																																										goto IL_0caa;
																																									case 50:
																																									case 170:
																																										goto IL_0ccb;
																																									case 196:
																																										goto IL_0d0b;
																																									case 60:
																																										goto IL_0d1f;
																																									case 9:
																																									case 53:
																																										goto IL_0d32;
																																									case 107:
																																										goto IL_0d72;
																																									case 119:
																																										goto IL_0d8f;
																																									case 7:
																																									case 11:
																																									case 14:
																																									case 16:
																																									case 18:
																																									case 24:
																																									case 29:
																																									case 30:
																																									case 43:
																																									case 61:
																																									case 72:
																																									case 78:
																																									case 79:
																																									case 88:
																																									case 94:
																																									case 105:
																																									case 112:
																																									case 124:
																																									case 130:
																																									case 131:
																																									case 136:
																																									case 138:
																																									case 150:
																																									case 154:
																																									case 156:
																																									case 168:
																																									case 169:
																																									case 173:
																																									case 174:
																																									case 175:
																																									case 176:
																																									case 181:
																																									case 186:
																																									case 188:
																																									case 193:
																																									case 195:
																																									case 197:
																																									case 198:
																																									case 199:
																																										goto end_IL_03ef;
																																									case 54:
																																										goto IL_0db8;
																																									case 191:
																																										goto IL_0dc6;
																																									case 89:
																																										goto IL_0dd4;
																																									case 0:
																																									case 8:
																																									case 22:
																																									case 28:
																																									case 33:
																																									case 40:
																																									case 42:
																																									case 45:
																																									case 59:
																																									case 75:
																																									case 77:
																																									case 82:
																																									case 91:
																																									case 103:
																																									case 104:
																																									case 110:
																																									case 113:
																																									case 115:
																																									case 120:
																																									case 146:
																																									case 149:
																																									case 159:
																																									case 179:
																																									case 183:
																																									case 185:
																																										goto IL_0de2;
																																									case 81:
																																										goto IL_0df5;
																																									case 171:
																																										goto IL_0dff;
																																									case 51:
																																										goto IL_0e0a;
																																									case 31:
																																										goto IL_0e1a;
																																									case 19:
																																										goto IL_0e2a;
																																									case 92:
																																										goto IL_0e3a;
																																									case 129:
																																										goto IL_0e4a;
																																									case 90:
																																										goto IL_0e5a;
																																									case 139:
																																										goto IL_0e73;
																																									case 162:
																																										goto IL_0e83;
																																									case 62:
																																										goto IL_0e93;
																																									case 3:
																																									case 153:
																																										goto IL_0eae;
																																									}
																																									goto end_IL_047c;
																																								}
																																								num6--;
																																								goto IL_0de2;
																																								continue;
																																								end_IL_037b:
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_0656;
																																					continue;
																																					end_IL_03ef:
																																					break;
																																					IL_03ef:;
																																				}
																																				break;
																																				IL_03ff:;
																																			}
																																			break;
																																		}
																																		goto IL_04c3;
																																		IL_0721:
																																		num6--;
																																		num = 82;
																																		goto IL_0de2;
																																		IL_04c3:
																																		if (6 > b)
																																		{
																																			break;
																																		}
																																		goto IL_04ef;
																																		IL_04ef:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_052f;
																																		IL_052f:
																																		array2[num6 - 2] = 0;
																																		goto IL_0721;
																																	}
																																	break;
																																}
																																goto IL_04b0;
																																IL_04b0:
																																num6--;
																																goto IL_0de2;
																															}
																															break;
																														}
																														goto IL_0a78;
																														IL_0b73:
																														num6 -= 2;
																														goto IL_0de2;
																														IL_0a78:
																														if (9 >= b)
																														{
																															goto IL_0a83;
																														}
																														goto IL_0af8;
																														IL_0a83:
																														if (9 > b)
																														{
																															break;
																														}
																														goto IL_0a91;
																														IL_0a91:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_0ad1;
																														IL_0ad1:
																														array2[num6 - 2] = 0;
																														goto IL_0ae5;
																														IL_0ae5:
																														num6--;
																														goto IL_0de2;
																														IL_0af8:
																														if (10 < b)
																														{
																															break;
																														}
																														goto IL_0b06;
																														IL_0b06:
																														if (10 > b)
																														{
																															num = 169;
																															break;
																														}
																														goto IL_0b11;
																														IL_0b11:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_0b73;
																													}
																													break;
																												}
																												goto IL_0b94;
																												IL_0d72:
																												array2[num6 - 2] = 0;
																												num = 119;
																												goto IL_0d8f;
																												IL_0b94:
																												if (5 > b)
																												{
																													goto IL_0ba2;
																												}
																												goto IL_0d32;
																												IL_0ba2:
																												if (2 < b)
																												{
																													goto IL_0bb0;
																												}
																												goto IL_0c94;
																												IL_0bb0:
																												if (3 >= b)
																												{
																													goto IL_0bbb;
																												}
																												goto IL_0c13;
																												IL_0bbb:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_0bc9;
																												IL_0bc9:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0bf2;
																												IL_0bf2:
																												ptr2 += 8;
																												goto IL_0c00;
																												IL_0c00:
																												num6--;
																												goto IL_0de2;
																												IL_0c13:
																												if (4 < b)
																												{
																													break;
																												}
																												goto IL_0c21;
																												IL_0c21:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_0c2f;
																												IL_0c2f:
																												array2[num6] = 0;
																												goto IL_0c3d;
																												IL_0c3d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												num = 144;
																												goto IL_0c69;
																												IL_0c69:
																												array3[num6] = null;
																												goto IL_0c73;
																												IL_0c73:
																												num6++;
																												goto IL_0c81;
																												IL_0c81:
																												ptr2 += 8;
																												goto IL_0de2;
																												IL_0c94:
																												if (2 > b)
																												{
																													goto IL_0c9f;
																												}
																												goto IL_0ccb;
																												IL_0c9f:
																												if (1 < b)
																												{
																													num = 61;
																													break;
																												}
																												goto IL_0caa;
																												IL_0caa:
																												if (1 <= b)
																												{
																												}
																												break;
																												IL_0d8f:
																												num6--;
																												goto IL_0de2;
																												IL_0ccb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0d0b;
																												IL_0d0b:
																												array2[num6 - 2] = 0;
																												goto IL_0d1f;
																												IL_0d1f:
																												num6--;
																												goto IL_0de2;
																												IL_0d32:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0d72;
																											}
																											break;
																										}
																										goto IL_0548;
																										IL_059b:
																										ptr2 += 8;
																										goto IL_0de2;
																										IL_0548:
																										array2[num6 - 1] = 0;
																										goto IL_055c;
																										IL_055c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)setForegroundColorDiscretionaryAclAutoInheritRequired[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_059b;
																									}
																									break;
																								}
																								goto IL_04d3;
																								IL_0875:
																								if (21 >= b)
																								{
																									goto IL_0880;
																								}
																								goto IL_08a6;
																								IL_04d3:
																								if (17 >= b)
																								{
																									num = 180;
																									goto IL_05ae;
																								}
																								goto IL_073d;
																								IL_0880:
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_088e;
																								IL_05ae:
																								if (17 <= b)
																								{
																									goto IL_05b9;
																								}
																								goto IL_05cc;
																								IL_05b9:
																								array2[num6] = 5;
																								goto IL_06b4;
																								IL_06b4:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_06cc;
																								IL_06cc:
																								num6++;
																								goto IL_06da;
																								IL_06da:
																								ptr2 += 8;
																								goto IL_0de2;
																								IL_05cc:
																								if (14 >= b)
																								{
																									goto IL_05d7;
																								}
																								goto IL_063d;
																								IL_05d7:
																								if (14 <= b)
																								{
																									goto IL_05e2;
																								}
																								goto IL_0613;
																								IL_05e2:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0600;
																								IL_0600:
																								ptr2 += 8;
																								goto IL_06ed;
																								IL_06ed:
																								num6--;
																								goto IL_0de2;
																								IL_0613:
																								if (12 >= b)
																								{
																									goto IL_0621;
																								}
																								goto IL_0700;
																								IL_0621:
																								if (12 > b)
																								{
																									break;
																								}
																								num = 33;
																								goto IL_0de2;
																								IL_088e:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_0de2;
																								IL_0700:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_070e;
																								IL_070e:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_098d;
																								IL_098d:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_099c;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0a44;
																								IL_08a6:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_08b4;
																								IL_08b4:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_08c2;
																								IL_08c2:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_0de2;
																								IL_0a44:
																								array2[num6] = 5;
																								goto IL_0a52;
																								IL_0a52:
																								num6++;
																								goto IL_0de2;
																								IL_063d:
																								if (15 >= b)
																								{
																									goto IL_0648;
																								}
																								goto IL_06a1;
																								IL_0648:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0656;
																								IL_0656:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_067f;
																								IL_067f:
																								array2[num6 - 1] = 5;
																								num = 59;
																								goto IL_0de2;
																								IL_06a1:
																								if (16 < b)
																								{
																									break;
																								}
																								goto IL_08de;
																								IL_08de:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_08ec;
																								IL_08ec:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0904;
																								IL_0904:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0922;
																								IL_0922:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 41;
																								goto IL_094f;
																								IL_094f:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0967;
																								IL_0967:
																								num6++;
																								goto IL_0de2;
																								IL_073d:
																								if (20 >= b)
																								{
																									goto IL_074b;
																								}
																								goto IL_0875;
																								IL_074b:
																								if (20 <= b)
																								{
																									goto IL_0756;
																								}
																								goto IL_0790;
																								IL_0756:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_076f;
																								IL_076f:
																								array2[num6] = 1;
																								goto IL_077d;
																								IL_077d:
																								num6++;
																								goto IL_097a;
																								IL_097a:
																								ptr2 += 16;
																								goto IL_0de2;
																								IL_0790:
																								if (18 >= b)
																								{
																									goto IL_079b;
																								}
																								goto IL_07fa;
																								IL_079b:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_07a9;
																								IL_07a9:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_07e7;
																								IL_07e7:
																								num6 -= 3;
																								goto IL_0de2;
																								IL_07fa:
																								if (19 < b)
																								{
																									break;
																								}
																								goto IL_0808;
																								IL_0808:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_0816;
																								IL_0816:
																								array2[num6 - 1] = 5;
																								goto IL_082a;
																								IL_082a:
																								array3[num6 - 1] = ((delegate*<string[], string>)setForegroundColorDiscretionaryAclAutoInheritRequired[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0862;
																								IL_0862:
																								ptr2 += 8;
																								goto IL_0de2;
																							}
																							break;
																							IL_046c:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0db8;
																					IL_0dd4:
																					ptr2 += 8;
																					goto IL_0de2;
																					IL_0dc6:
																					num6++;
																					goto IL_0dd4;
																					IL_0db8:
																					array2[num6] = 0;
																					goto IL_0dc6;
																					continue;
																					end_IL_047c:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0eae;
																	IL_0eae:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_099c:
				while (true)
				{
					IL_099c_2:
					array = new byte[4];
					while (true)
					{
						IL_09aa:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0a52_2:
								num6++;
								while (true)
								{
									IL_0de2_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											num = 96;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_047c_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_045f_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_044f_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_043f_2:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_042f_2:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_041f_2:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_040f_2:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_03ad_2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														while (true)
																														{
																															IL_038e_2:
																															array2[num6 - 2] = 0;
																															num = 219;
																															while (true)
																															{
																																if (num != 219)
																																{
																																	if (num != 1200)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 128:
																																		goto IL_038e_2;
																																	case 98:
																																	case 212:
																																		goto IL_03ad_2;
																																	case 207:
																																		goto IL_03ef_2;
																																	case 106:
																																	case 135:
																																		goto IL_03ff_2;
																																	case 35:
																																	case 157:
																																		goto IL_040f_2;
																																	case 114:
																																		goto IL_041f_2;
																																	case 38:
																																	case 158:
																																		goto IL_042f_2;
																																	case 208:
																																		goto IL_043f_2;
																																	case 65:
																																		goto IL_044f_2;
																																	case 101:
																																		goto IL_045f_2;
																																	case 76:
																																		goto IL_046c_2;
																																	case 36:
																																		goto IL_047c_2;
																																	case 96:
																																		goto end_IL_047c_2;
																																	case 97:
																																	case 148:
																																		goto end_IL_048c;
																																	case 20:
																																	case 66:
																																		goto IL_04b0_2;
																																	case 123:
																																		goto IL_04c3_2;
																																	case 80:
																																	case 134:
																																		goto IL_04d3_2;
																																	case 5:
																																	case 163:
																																		goto IL_04ef_2;
																																	case 145:
																																		goto IL_052f_2;
																																	case 68:
																																	case 172:
																																		goto IL_0548_2;
																																	case 64:
																																		goto IL_055c_2;
																																	case 74:
																																		goto IL_059b_2;
																																	case 180:
																																		goto IL_05ae_2;
																																	case 83:
																																	case 166:
																																		goto IL_05b9_2;
																																	case 73:
																																		goto IL_05cc_2;
																																	case 57:
																																		goto IL_05d7_2;
																																	case 116:
																																	case 167:
																																		goto IL_05e2_2;
																																	case 67:
																																		goto IL_0600_2;
																																	case 160:
																																		goto IL_0613_2;
																																	case 93:
																																		goto IL_0621_2;
																																	case 58:
																																		goto IL_063d_2;
																																	case 55:
																																		goto IL_0648_2;
																																	case 21:
																																	case 165:
																																		goto end_IL_037b_2;
																																	case 13:
																																		goto IL_067f_2;
																																	case 52:
																																		goto IL_06a1_2;
																																	case 189:
																																		goto IL_06b4_2;
																																	case 4:
																																		goto IL_06cc_2;
																																	case 70:
																																		goto IL_06da_2;
																																	case 190:
																																		goto IL_06ed_2;
																																	case 37:
																																	case 200:
																																		goto IL_0700_2;
																																	case 121:
																																		goto IL_070e_2;
																																	case 201:
																																		goto IL_0721_2;
																																	case 204:
																																		goto IL_073d_2;
																																	case 71:
																																		goto IL_074b_2;
																																	case 12:
																																	case 111:
																																		goto IL_0756_2;
																																	case 34:
																																		goto IL_076f_2;
																																	case 95:
																																		goto IL_077d_2;
																																	case 127:
																																		goto IL_0790_2;
																																	case 6:
																																		goto IL_079b_2;
																																	case 69:
																																	case 100:
																																		goto IL_07a9_2;
																																	case 141:
																																		goto IL_07e7_2;
																																	case 47:
																																		goto IL_07fa_2;
																																	case 84:
																																		goto IL_0808_2;
																																	case 137:
																																	case 182:
																																		goto IL_0816_2;
																																	case 177:
																																		goto IL_082a_2;
																																	case 108:
																																		goto IL_0862_2;
																																	case 202:
																																		goto IL_0875_2;
																																	case 25:
																																		goto IL_0880_2;
																																	case 15:
																																	case 99:
																																		goto IL_088e_2;
																																	case 109:
																																		goto IL_08a6_2;
																																	case 1:
																																		goto IL_08b4_2;
																																	case 155:
																																	case 161:
																																		goto IL_08c2_2;
																																	case 206:
																																		goto IL_08de_2;
																																	case 125:
																																	case 133:
																																		goto IL_08ec_2;
																																	case 26:
																																		goto IL_0904_2;
																																	case 10:
																																		goto IL_0922_2;
																																	case 41:
																																		goto IL_094f_2;
																																	case 184:
																																		goto IL_0967_2;
																																	case 209:
																																		goto IL_097a_2;
																																	case 17:
																																	case 211:
																																		goto IL_098d_2;
																																	case 122:
																																		goto end_IL_049c;
																																	case 32:
																																		goto IL_0a52_2;
																																	case 39:
																																		goto IL_0a78_2;
																																	case 194:
																																		goto IL_0a83_2;
																																	case 87:
																																	case 118:
																																		goto IL_0a91_2;
																																	case 152:
																																		goto IL_0ad1_2;
																																	case 132:
																																		goto IL_0ae5_2;
																																	case 48:
																																		goto IL_0af8_2;
																																	case 142:
																																		goto IL_0b06_2;
																																	case 140:
																																	case 143:
																																		goto IL_0b11_2;
																																	case 85:
																																		goto IL_0b73_2;
																																	case 151:
																																		goto IL_0b94_2;
																																	case 203:
																																		goto IL_0ba2_2;
																																	case 49:
																																	case 210:
																																		goto IL_0bb0_2;
																																	case 56:
																																		goto IL_0bbb_2;
																																	case 147:
																																	case 192:
																																		goto IL_0bc9_2;
																																	case 117:
																																		goto IL_0bf2_2;
																																	case 44:
																																		goto IL_0c00_2;
																																	case 86:
																																		goto IL_0c13_2;
																																	case 178:
																																		goto IL_0c21_2;
																																	case 27:
																																	case 164:
																																		goto IL_0c2f_2;
																																	case 46:
																																		goto IL_0c3d_2;
																																	case 144:
																																		goto IL_0c69_2;
																																	case 187:
																																		goto IL_0c73_2;
																																	case 205:
																																		goto IL_0c81_2;
																																	case 2:
																																		goto IL_0c94_2;
																																	case 23:
																																	case 126:
																																		goto IL_0c9f_2;
																																	case 102:
																																		goto IL_0caa_2;
																																	case 50:
																																	case 170:
																																		goto IL_0ccb_2;
																																	case 196:
																																		goto IL_0d0b_2;
																																	case 60:
																																		goto IL_0d1f_2;
																																	case 9:
																																	case 53:
																																		goto IL_0d32_2;
																																	case 107:
																																		goto IL_0d72_2;
																																	case 119:
																																		goto IL_0d8f_2;
																																	case 7:
																																	case 11:
																																	case 14:
																																	case 16:
																																	case 18:
																																	case 24:
																																	case 29:
																																	case 30:
																																	case 43:
																																	case 61:
																																	case 72:
																																	case 78:
																																	case 79:
																																	case 88:
																																	case 94:
																																	case 105:
																																	case 112:
																																	case 124:
																																	case 130:
																																	case 131:
																																	case 136:
																																	case 138:
																																	case 150:
																																	case 154:
																																	case 156:
																																	case 168:
																																	case 169:
																																	case 173:
																																	case 174:
																																	case 175:
																																	case 176:
																																	case 181:
																																	case 186:
																																	case 188:
																																	case 193:
																																	case 195:
																																	case 197:
																																	case 198:
																																	case 199:
																																		goto end_IL_03ef_2;
																																	case 54:
																																		goto IL_0db8_2;
																																	case 191:
																																		goto IL_0dc6_2;
																																	case 89:
																																		goto IL_0dd4_2;
																																	case 0:
																																	case 8:
																																	case 22:
																																	case 28:
																																	case 33:
																																	case 40:
																																	case 42:
																																	case 45:
																																	case 59:
																																	case 75:
																																	case 77:
																																	case 82:
																																	case 91:
																																	case 103:
																																	case 104:
																																	case 110:
																																	case 113:
																																	case 115:
																																	case 120:
																																	case 146:
																																	case 149:
																																	case 159:
																																	case 179:
																																	case 183:
																																	case 185:
																																		goto IL_0de2_2;
																																	case 81:
																																		ptr2 = ptr;
																																		goto IL_0de2_2;
																																	case 171:
																																		ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CModOptLIBFLAGS.ENDTryPopRange);
																																		goto case 81;
																																	case 51:
																																		array7 = new object[17];
																																		goto case 171;
																																	case 31:
																																		array6 = new long[4];
																																		goto case 51;
																																	case 19:
																																		array5 = new int[6];
																																		goto case 31;
																																	case 92:
																																		array4 = new int[4];
																																		goto case 19;
																																	case 129:
																																		array3 = new object[4];
																																		goto case 92;
																																	case 90:
																																		array2 = new byte[4];
																																		num = 129;
																																		goto case 129;
																																	case 139:
																																		num4 = num2 * 8;
																																		goto case 90;
																																	case 162:
																																		num3 = num2 * 4;
																																		goto case 139;
																																	case 62:
																																		num2 = 1;
																																		goto case 162;
																																	case 63:
																																		goto end_IL_0a44;
																																	case 3:
																																	case 153:
																																		goto IL_0eae_2;
																																	}
																																	continue;
																																}
																																num6--;
																																goto IL_0de2_2;
																																continue;
																																end_IL_037b_2:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0656_2;
																													continue;
																													end_IL_03ef_2:
																													break;
																													IL_03ef_2:;
																												}
																												break;
																												IL_03ff_2:;
																											}
																											break;
																										}
																										goto IL_04c3_2;
																										IL_0721_2:
																										num6--;
																										num = 82;
																										goto IL_0de2_2;
																										IL_04c3_2:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_04ef_2;
																										IL_04ef_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_052f_2;
																										IL_052f_2:
																										array2[num6 - 2] = 0;
																										goto IL_0721_2;
																									}
																									break;
																								}
																								goto IL_04b0_2;
																								IL_04b0_2:
																								num6--;
																								goto IL_0de2_2;
																							}
																							break;
																						}
																						goto IL_0a78_2;
																						IL_0b73_2:
																						num6 -= 2;
																						goto IL_0de2_2;
																						IL_0a78_2:
																						if (9 >= b)
																						{
																							goto IL_0a83_2;
																						}
																						goto IL_0af8_2;
																						IL_0a83_2:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0a91_2;
																						IL_0a91_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0ad1_2;
																						IL_0ad1_2:
																						array2[num6 - 2] = 0;
																						goto IL_0ae5_2;
																						IL_0ae5_2:
																						num6--;
																						goto IL_0de2_2;
																						IL_0af8_2:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0b06_2;
																						IL_0b06_2:
																						if (10 > b)
																						{
																							num = 169;
																							break;
																						}
																						goto IL_0b11_2;
																						IL_0b11_2:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0b73_2;
																					}
																					break;
																				}
																				goto IL_0b94_2;
																				IL_0d72_2:
																				array2[num6 - 2] = 0;
																				num = 119;
																				goto IL_0d8f_2;
																				IL_0b94_2:
																				if (5 > b)
																				{
																					goto IL_0ba2_2;
																				}
																				goto IL_0d32_2;
																				IL_0ba2_2:
																				if (2 < b)
																				{
																					goto IL_0bb0_2;
																				}
																				goto IL_0c94_2;
																				IL_0bb0_2:
																				if (3 >= b)
																				{
																					goto IL_0bbb_2;
																				}
																				goto IL_0c13_2;
																				IL_0bbb_2:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0bc9_2;
																				IL_0bc9_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0bf2_2;
																				IL_0bf2_2:
																				ptr2 += 8;
																				goto IL_0c00_2;
																				IL_0c00_2:
																				num6--;
																				goto IL_0de2_2;
																				IL_0c13_2:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0c21_2;
																				IL_0c21_2:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0c2f_2;
																				IL_0c2f_2:
																				array2[num6] = 0;
																				goto IL_0c3d_2;
																				IL_0c3d_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				num = 144;
																				goto IL_0c69_2;
																				IL_0c69_2:
																				array3[num6] = null;
																				goto IL_0c73_2;
																				IL_0c73_2:
																				num6++;
																				goto IL_0c81_2;
																				IL_0c81_2:
																				ptr2 += 8;
																				goto IL_0de2_2;
																				IL_0c94_2:
																				if (2 > b)
																				{
																					goto IL_0c9f_2;
																				}
																				goto IL_0ccb_2;
																				IL_0c9f_2:
																				if (1 < b)
																				{
																					num = 61;
																					break;
																				}
																				goto IL_0caa_2;
																				IL_0caa_2:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0d8f_2:
																				num6--;
																				goto IL_0de2_2;
																				IL_0ccb_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0d0b_2;
																				IL_0d0b_2:
																				array2[num6 - 2] = 0;
																				goto IL_0d1f_2;
																				IL_0d1f_2:
																				num6--;
																				goto IL_0de2_2;
																				IL_0d32_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0d72_2;
																			}
																			break;
																		}
																		goto IL_0548_2;
																		IL_059b_2:
																		ptr2 += 8;
																		goto IL_0de2_2;
																		IL_0548_2:
																		array2[num6 - 1] = 0;
																		goto IL_055c_2;
																		IL_055c_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)setForegroundColorDiscretionaryAclAutoInheritRequired[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_059b_2;
																	}
																	break;
																}
																goto IL_04d3_2;
																IL_08a6_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_08b4_2;
																IL_04d3_2:
																if (17 >= b)
																{
																	num = 180;
																	goto IL_05ae_2;
																}
																goto IL_073d_2;
																IL_08b4_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_08c2_2;
																IL_05ae_2:
																if (17 <= b)
																{
																	goto IL_05b9_2;
																}
																goto IL_05cc_2;
																IL_05b9_2:
																array2[num6] = 5;
																goto IL_06b4_2;
																IL_06b4_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_06cc_2;
																IL_06cc_2:
																num6++;
																goto IL_06da_2;
																IL_06da_2:
																ptr2 += 8;
																goto IL_0de2_2;
																IL_05cc_2:
																if (14 >= b)
																{
																	goto IL_05d7_2;
																}
																goto IL_063d_2;
																IL_05d7_2:
																if (14 <= b)
																{
																	goto IL_05e2_2;
																}
																goto IL_0613_2;
																IL_05e2_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0600_2;
																IL_0600_2:
																ptr2 += 8;
																goto IL_06ed_2;
																IL_06ed_2:
																num6--;
																goto IL_0de2_2;
																IL_0613_2:
																if (12 >= b)
																{
																	goto IL_0621_2;
																}
																goto IL_0700_2;
																IL_0621_2:
																if (12 > b)
																{
																	break;
																}
																num = 33;
																goto IL_0de2_2;
																IL_08c2_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																goto IL_0de2_2;
																IL_0700_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_070e_2;
																IL_070e_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_098d_2;
																IL_098d_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_099c_2;
																}
																goto IL_09aa;
																IL_063d_2:
																if (15 >= b)
																{
																	goto IL_0648_2;
																}
																goto IL_06a1_2;
																IL_0648_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_0656_2;
																IL_0656_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_067f_2;
																IL_067f_2:
																array2[num6 - 1] = 5;
																num = 59;
																goto IL_0de2_2;
																IL_06a1_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_08de_2;
																IL_08de_2:
																if (16 > b)
																{
																	break;
																}
																goto IL_08ec_2;
																IL_08ec_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0904_2;
																IL_0904_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0922_2;
																IL_0922_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 41;
																goto IL_094f_2;
																IL_094f_2:
																array3[num6] = array3[num6 - 1];
																goto IL_0967_2;
																IL_0967_2:
																num6++;
																goto IL_0de2_2;
																IL_073d_2:
																if (20 >= b)
																{
																	goto IL_074b_2;
																}
																goto IL_0875_2;
																IL_074b_2:
																if (20 <= b)
																{
																	goto IL_0756_2;
																}
																goto IL_0790_2;
																IL_0756_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_076f_2;
																IL_076f_2:
																array2[num6] = 1;
																goto IL_077d_2;
																IL_077d_2:
																num6++;
																goto IL_097a_2;
																IL_097a_2:
																ptr2 += 16;
																goto IL_0de2_2;
																IL_0790_2:
																if (18 >= b)
																{
																	goto IL_079b_2;
																}
																goto IL_07fa_2;
																IL_079b_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_07a9_2;
																IL_07a9_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_07e7_2;
																IL_07e7_2:
																num6 -= 3;
																goto IL_0de2_2;
																IL_07fa_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0808_2;
																IL_0808_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_0816_2;
																IL_0816_2:
																array2[num6 - 1] = 5;
																goto IL_082a_2;
																IL_082a_2:
																array3[num6 - 1] = ((delegate*<string[], string>)setForegroundColorDiscretionaryAclAutoInheritRequired[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0862_2;
																IL_0862_2:
																ptr2 += 8;
																goto IL_0de2_2;
																IL_0875_2:
																if (21 >= b)
																{
																	goto IL_0880_2;
																}
																goto IL_08a6_2;
																IL_0880_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_088e_2;
																IL_088e_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0de2_2;
															}
															break;
															IL_046c_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0db8_2;
													IL_0dd4_2:
													ptr2 += 8;
													goto IL_0de2_2;
													IL_0dc6_2:
													num6++;
													goto IL_0dd4_2;
													IL_0db8_2:
													array2[num6] = 0;
													goto IL_0dc6_2;
													continue;
													end_IL_047c_2:
													break;
												}
												continue;
												end_IL_048c:
												break;
											}
											continue;
											end_IL_049c:
											break;
										}
										break;
									}
									goto IL_0eae_2;
									IL_0eae_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0a44:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class106()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_4)
	{
		int num = 20;
		int[] array3 = default(int[]);
		byte b = default(byte);
		byte* ptr = default(byte*);
		int num5 = default(int);
		int num6 = default(int);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 135;
							while (true)
							{
								if (num != 135)
								{
									if (num != 1116)
									{
										goto IL_02ca;
									}
									switch (num)
									{
									case 90:
										goto end_IL_022b;
									case 18:
										goto end_IL_023b;
									case 35:
									case 62:
										goto end_IL_0246;
									case 19:
										goto end_IL_0256;
									case 20:
										goto end_IL_0266;
									case 92:
										goto IL_028f;
									case 47:
										goto IL_029d;
									case 84:
										goto IL_02b0;
									case 22:
										goto IL_02b9;
									case 7:
									case 27:
									case 34:
									case 50:
									case 52:
									case 59:
									case 68:
									case 74:
									case 86:
									case 106:
									case 108:
									case 110:
									case 115:
									case 121:
									case 124:
									case 126:
										goto IL_02ca;
									case 15:
									case 25:
										goto IL_02da;
									case 17:
										goto IL_02ec;
									case 0:
										goto IL_02fa;
									case 127:
										goto IL_0311;
									case 2:
										goto IL_031f;
									case 42:
										goto IL_032d;
									case 9:
										goto IL_033b;
									case 53:
										goto IL_0349;
									case 4:
										goto IL_0357;
									case 12:
									case 91:
										goto IL_0362;
									case 94:
										goto IL_0370;
									case 58:
									case 85:
										goto IL_0383;
									case 64:
										goto IL_0391;
									case 44:
										goto IL_03b4;
									case 97:
										goto IL_03be;
									case 93:
										goto IL_03d5;
									case 29:
										goto IL_03f1;
									case 114:
										goto IL_03ff;
									case 55:
									case 66:
										goto IL_040d;
									case 65:
										goto IL_044d;
									case 6:
										goto IL_0461;
									case 80:
										goto IL_0474;
									case 54:
										goto IL_0482;
									case 31:
										goto IL_048d;
									case 5:
										goto IL_049b;
									case 45:
									case 99:
										goto IL_04a9;
									case 87:
										goto IL_04d2;
									case 8:
										goto IL_04e0;
									case 43:
										goto IL_04fc;
									case 98:
									case 118:
										goto IL_050a;
									case 104:
										goto IL_0523;
									case 28:
										goto IL_0531;
									case 14:
										goto IL_053f;
									case 56:
									case 70:
										goto IL_0552;
									case 23:
									case 49:
										goto IL_056a;
									case 41:
										goto IL_058d;
									case 10:
										goto IL_059b;
									case 38:
										goto IL_05a9;
									case 46:
									case 71:
										goto IL_05c5;
									case 30:
										goto IL_05d3;
									case 33:
									case 57:
										goto IL_05e1;
									case 116:
										goto IL_05f5;
									case 119:
										goto IL_0649;
									case 3:
										goto IL_0657;
									case 105:
										goto IL_066a;
									case 82:
										goto IL_0678;
									case 76:
									case 128:
										goto IL_0686;
									case 112:
										goto IL_06e8;
									case 11:
										goto IL_06fb;
									case 24:
										goto IL_0709;
									case 109:
									case 113:
										goto IL_0717;
									case 95:
										goto IL_0757;
									case 77:
										goto IL_076b;
									case 79:
										goto IL_077e;
									case 13:
										goto IL_0789;
									case 61:
									case 111:
										goto IL_0794;
									case 37:
										goto IL_079f;
									case 69:
									case 101:
										goto IL_07aa;
									case 39:
									case 100:
										goto IL_07bd;
									case 60:
										goto IL_07d9;
									case 75:
										goto IL_07e4;
									case 1:
									case 16:
									case 21:
									case 26:
									case 32:
									case 40:
									case 48:
									case 51:
									case 63:
									case 67:
									case 72:
									case 73:
									case 78:
									case 81:
									case 83:
									case 88:
									case 89:
									case 96:
									case 103:
									case 107:
									case 117:
									case 120:
									case 122:
									case 123:
									case 125:
										goto IL_07ef;
									case 36:
									case 102:
										goto IL_0807;
									}
									continue;
								}
								array3 = new int[3];
								goto IL_028f;
								IL_079f:
								if (11 <= b)
								{
									goto IL_07aa;
								}
								goto IL_07ef;
								IL_07bd:
								byte* num4 = ptr;
								num5 = 1;
								ptr = num4 + -200;
								goto IL_02ca;
								IL_07aa:
								num6--;
								goto IL_02ca;
								IL_028f:
								array4 = new long[4];
								goto IL_029d;
								IL_029d:
								array3[0] = int_4;
								goto IL_02b0;
								IL_02b0:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsAppEarlierThanWindowsPhoneGetSurrogateForCyclicalReference.ContractInvariantMethodAttributesetChannelUris);
								goto IL_02b9;
								IL_02b9:
								ptr = ptr2;
								num = 108;
								goto IL_02ca;
								IL_02ca:
								if (num5 != 1)
								{
									goto IL_02da;
								}
								goto IL_0807;
								IL_0807:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								IL_02da:
								b = *ptr;
								num = 17;
								goto IL_02ec;
								IL_02ec:
								ptr++;
								goto IL_02fa;
								IL_02fa:
								if (b >= 1)
								{
									num = 127;
									goto IL_0311;
								}
								goto IL_07ef;
								IL_07d9:
								if (13 >= b)
								{
									goto IL_07e4;
								}
								goto IL_07ef;
								IL_0311:
								if (b <= 13)
								{
									goto IL_031f;
								}
								goto IL_07ef;
								IL_031f:
								if (7 >= b)
								{
									goto IL_032d;
								}
								num = 71;
								goto IL_05c5;
								IL_032d:
								if (7 > b)
								{
									goto IL_033b;
								}
								goto IL_056a;
								IL_033b:
								if (3 < b)
								{
									goto IL_0349;
								}
								goto IL_0474;
								IL_0349:
								if (5 >= b)
								{
									goto IL_0357;
								}
								goto IL_03f1;
								IL_0357:
								if (5 > b)
								{
									goto IL_0362;
								}
								goto IL_0383;
								IL_0362:
								if (4 >= b)
								{
									goto IL_0370;
								}
								goto IL_07ef;
								IL_0370:
								if (4 <= b)
								{
									goto IL_02ca;
								}
								goto IL_07ef;
								IL_0383:
								array[num6] = 0;
								goto IL_0391;
								IL_0391:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
								goto IL_03b4;
								IL_03b4:
								array2[num6] = null;
								goto IL_03be;
								IL_03be:
								num6++;
								num = 93;
								goto IL_03d5;
								IL_03d5:
								ptr += 8;
								num = 27;
								goto IL_02ca;
								IL_03f1:
								if (6 >= b)
								{
									goto IL_03ff;
								}
								goto IL_07ef;
								IL_03ff:
								if (6 <= b)
								{
									goto IL_040d;
								}
								goto IL_07ef;
								IL_040d:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								goto IL_044d;
								IL_044d:
								array[num6 - 2] = 0;
								goto IL_0461;
								IL_0461:
								num6--;
								goto IL_02ca;
								IL_0474:
								if (3 > b)
								{
									goto IL_0482;
								}
								goto IL_0552;
								IL_0482:
								if (1 < b)
								{
									goto IL_048d;
								}
								num = 43;
								goto IL_04fc;
								IL_048d:
								if (2 >= b)
								{
									goto IL_049b;
								}
								goto IL_07ef;
								IL_049b:
								if (2 <= b)
								{
									goto IL_04a9;
								}
								goto IL_07ef;
								IL_04a9:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								goto IL_04d2;
								IL_04d2:
								ptr += 8;
								goto IL_04e0;
								IL_04e0:
								num6--;
								goto IL_02ca;
								IL_07ef:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_02ca;
								IL_04fc:
								if (1 <= b)
								{
									goto IL_050a;
								}
								goto IL_07ef;
								IL_050a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr + num3);
								goto IL_0523;
								IL_0523:
								array[num6] = 0;
								goto IL_0531;
								IL_0531:
								num6++;
								goto IL_053f;
								IL_053f:
								ptr += 8;
								goto IL_02ca;
								IL_0552:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_02ca;
								IL_056a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
								goto IL_058d;
								IL_058d:
								array[num6] = 0;
								goto IL_059b;
								IL_059b:
								num6++;
								goto IL_05a9;
								IL_05a9:
								ptr += 8;
								goto IL_02ca;
								IL_07e4:
								if (13 > b)
								{
								}
								goto IL_07ef;
								IL_05c5:
								if (10 >= b)
								{
									goto IL_05d3;
								}
								goto IL_077e;
								IL_05d3:
								if (10 <= b)
								{
									goto IL_05e1;
								}
								goto IL_066a;
								IL_05e1:
								array[num6 - 2] = 0;
								goto IL_05f5;
								IL_05f5:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)CalendricalCalculationsHelperSecureString[*(int*)(ptr + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
								goto IL_0649;
								IL_0649:
								num6--;
								goto IL_0657;
								IL_0657:
								ptr += 8;
								goto IL_02ca;
								IL_066a:
								if (8 >= b)
								{
									goto IL_0678;
								}
								goto IL_06fb;
								IL_0678:
								if (8 <= b)
								{
									goto IL_0686;
								}
								goto IL_07ef;
								IL_0686:
								ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_06e8;
								IL_06e8:
								num6 -= 2;
								goto IL_02ca;
								IL_06fb:
								if (9 >= b)
								{
									goto IL_0709;
								}
								goto IL_07ef;
								IL_0709:
								if (9 <= b)
								{
									goto IL_0717;
								}
								goto IL_07ef;
								IL_0717:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
								goto IL_0757;
								IL_0757:
								array[num6 - 2] = 0;
								goto IL_076b;
								IL_076b:
								num6--;
								goto IL_02ca;
								IL_077e:
								if (12 >= b)
								{
									goto IL_0789;
								}
								goto IL_07d9;
								IL_0789:
								if (12 > b)
								{
									goto IL_0794;
								}
								goto IL_07bd;
								IL_0794:
								if (11 >= b)
								{
									goto IL_079f;
								}
								goto IL_07ef;
								continue;
								end_IL_022b:
								break;
							}
							continue;
							end_IL_023b:
							break;
						}
						continue;
						end_IL_0246:
						break;
					}
					continue;
					end_IL_0256:
					break;
				}
				continue;
				end_IL_0266:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_4, int int_5)
	{
		int num = 27;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 26;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 15;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FixedSizeCompatibleComparer.ForegroundIntensityIInternalMessage);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_022d:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0200:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_01f0:
																								if (2 >= b)
																								{
																									num = 112;
																									while (true)
																									{
																										if (num != 112)
																										{
																											if (num != 1093)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 72:
																											case 89:
																												goto IL_01f0;
																											case 77:
																												goto IL_0200;
																											case 38:
																												goto end_IL_0200;
																											case 31:
																												goto end_IL_0210;
																											case 14:
																												goto IL_022d;
																											case 9:
																												goto end_IL_022d;
																											case 51:
																											case 94:
																												goto end_IL_023d;
																											case 5:
																												goto IL_0258;
																											case 23:
																											case 41:
																												goto IL_0268;
																											case 60:
																												goto IL_0276;
																											case 46:
																												goto IL_0281;
																											case 44:
																											case 61:
																												goto IL_0294;
																											case 48:
																												goto IL_02ad;
																											case 55:
																												goto IL_02bb;
																											case 39:
																												goto IL_02c9;
																											case 67:
																												goto IL_02dc;
																											case 12:
																											case 76:
																												goto IL_02ea;
																											case 81:
																												goto IL_0318;
																											case 49:
																											case 87:
																												goto IL_032b;
																											case 50:
																											case 85:
																												goto IL_0336;
																											case 54:
																												goto IL_0344;
																											case 10:
																											case 19:
																												goto IL_0352;
																											case 66:
																												goto IL_036e;
																											case 22:
																											case 79:
																												goto IL_037c;
																											case 91:
																												goto IL_03c1;
																											case 16:
																											case 78:
																												goto IL_03cf;
																											case 25:
																												goto IL_040f;
																											case 13:
																												goto IL_0423;
																											case 92:
																												goto IL_0436;
																											case 100:
																												goto IL_0446;
																											case 3:
																												goto IL_045a;
																											case 101:
																												goto IL_046d;
																											case 82:
																												goto IL_047b;
																											case 63:
																											case 104:
																												goto IL_048e;
																											case 103:
																												goto IL_04ce;
																											case 11:
																												goto IL_04e2;
																											case 0:
																											case 73:
																												goto IL_0500;
																											case 32:
																												goto IL_050e;
																											case 88:
																											case 93:
																												goto IL_0521;
																											case 102:
																												goto IL_0561;
																											case 42:
																												goto IL_0575;
																											case 28:
																											case 96:
																												goto end_IL_01dd;
																											case 65:
																												goto IL_0596;
																											case 18:
																												goto IL_05b9;
																											case 21:
																												goto IL_05c3;
																											case 69:
																												goto IL_05d1;
																											case 4:
																											case 6:
																											case 8:
																											case 17:
																											case 30:
																											case 33:
																											case 43:
																											case 45:
																											case 47:
																											case 52:
																											case 53:
																											case 57:
																											case 70:
																											case 74:
																											case 75:
																											case 83:
																											case 90:
																											case 98:
																												goto end_IL_021d;
																											case 86:
																												goto IL_0604;
																											case 62:
																												goto IL_0612;
																											case 29:
																												goto IL_0620;
																											case 1:
																											case 2:
																											case 7:
																											case 35:
																											case 37:
																											case 56:
																											case 59:
																											case 80:
																											case 84:
																											case 97:
																											case 105:
																												goto end_IL_024d;
																											case 99:
																												goto end_IL_062e;
																											case 68:
																												goto end_IL_0641;
																											case 58:
																												goto end_IL_064b;
																											case 71:
																												goto end_IL_0656;
																											case 24:
																												goto end_IL_066b;
																											case 36:
																											case 64:
																												goto end_IL_0680;
																											case 15:
																												goto end_IL_0690;
																											case 40:
																											case 95:
																												goto end_IL_06a0;
																											case 26:
																												goto end_IL_06b0;
																											case 27:
																												goto end_IL_06c9;
																											case 20:
																											case 34:
																												goto IL_06ed;
																											}
																											continue;
																										}
																										if (2 > b)
																										{
																											goto IL_0500;
																										}
																										goto IL_0521;
																										IL_0521:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0561;
																										IL_0575:
																										num5--;
																										goto end_IL_024d;
																										IL_0561:
																										array[num5 - 2] = 0;
																										goto IL_0575;
																										IL_0500:
																										if (1 < b)
																										{
																											goto end_IL_021d;
																										}
																										goto IL_050e;
																										IL_050e:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_021d;
																										continue;
																										end_IL_01dd:
																										break;
																									}
																									break;
																								}
																								goto IL_0258;
																								IL_040f:
																								array[num5 - 2] = 0;
																								goto IL_0423;
																								IL_0423:
																								num5--;
																								goto end_IL_024d;
																								IL_0258:
																								if (3 >= b)
																								{
																									goto IL_02dc;
																								}
																								goto IL_0318;
																								IL_02dc:
																								if (3 > b)
																								{
																									goto end_IL_021d;
																								}
																								goto IL_02ea;
																								IL_02ea:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_046d;
																								IL_046d:
																								ptr2 += 8;
																								goto IL_047b;
																								IL_047b:
																								num5--;
																								goto end_IL_024d;
																								IL_0318:
																								if (4 < b)
																								{
																									goto end_IL_021d;
																								}
																								goto IL_03c1;
																								IL_03c1:
																								if (4 > b)
																								{
																									goto end_IL_021d;
																								}
																								goto IL_03cf;
																								IL_03cf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_040f;
																							}
																						}
																						array[num5] = 0;
																						goto IL_0596;
																						IL_05d1:
																						ptr2 += 8;
																						goto end_IL_024d;
																						IL_05c3:
																						num5++;
																						goto IL_05d1;
																						IL_0596:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05b9;
																						IL_05b9:
																						array2[num5] = null;
																						goto IL_05c3;
																						continue;
																						end_IL_0200:
																						break;
																					}
																					continue;
																				}
																				goto IL_0268;
																				IL_045a:
																				num5--;
																				goto end_IL_024d;
																				IL_0268:
																				if (7 >= b)
																				{
																					goto IL_0276;
																				}
																				goto IL_032b;
																				IL_0276:
																				if (7 > b)
																				{
																					goto IL_0281;
																				}
																				goto IL_0294;
																				IL_0281:
																				if (6 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_0436;
																				IL_0436:
																				if (6 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_048e;
																				IL_048e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04ce;
																				IL_04ce:
																				array[num5 - 2] = 0;
																				goto IL_04e2;
																				IL_04e2:
																				num5--;
																				goto end_IL_024d;
																				IL_0294:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_02ad;
																				IL_02ad:
																				array[num5] = 0;
																				goto IL_02bb;
																				IL_02bb:
																				num5++;
																				goto IL_02c9;
																				IL_02c9:
																				ptr2 += 8;
																				goto end_IL_024d;
																				IL_032b:
																				if (8 < b)
																				{
																					goto IL_0336;
																				}
																				goto IL_036e;
																				IL_0336:
																				if (9 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_0344;
																				IL_0344:
																				if (9 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_0352;
																				IL_0352:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_024d;
																				IL_036e:
																				if (8 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_037c;
																				IL_037c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0446;
																				IL_0446:
																				array[num5 - 2] = 0;
																				goto IL_045a;
																				continue;
																				end_IL_0210:
																				break;
																			}
																			continue;
																			end_IL_021d:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0604;
																	IL_0620:
																	ptr2 += 8;
																	goto end_IL_024d;
																	IL_0612:
																	num5++;
																	goto IL_0620;
																	IL_0604:
																	array[num5] = 0;
																	goto IL_0612;
																	continue;
																	end_IL_022d:
																	break;
																}
																continue;
																end_IL_023d:
																break;
															}
															continue;
															end_IL_024d:
															break;
														}
														continue;
													}
													goto IL_06ed;
													IL_06ed:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_064b:
											break;
										}
										continue;
										end_IL_0656:
										break;
									}
									continue;
									end_IL_066b:
									break;
								}
								continue;
								end_IL_0680:
								break;
							}
							continue;
							end_IL_0690:
							break;
						}
						continue;
						end_IL_06a0:
						break;
					}
					continue;
					end_IL_06b0:
					break;
				}
				continue;
				end_IL_06c9:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_4, int int_5)
	{
		int num = 25;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 103;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										IL_075c:
										array3[1] = int_5;
										while (true)
										{
											IL_0751:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetResponseTrySteal.TypeKindInterfaceIsIInspectable);
											while (true)
											{
												IL_0747:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0734:
													if (num4 != 1)
													{
														while (true)
														{
															IL_02bd:
															byte b = *ptr2;
															while (true)
															{
																IL_02ad:
																ptr2++;
																while (true)
																{
																	IL_029d:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0280:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0270:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_0260:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_0253:
																										if (11 > b)
																										{
																											while (10 >= b)
																											{
																												num = 132;
																												while (true)
																												{
																													if (num != 132)
																													{
																														if (num != 1113)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 21:
																														case 74:
																															goto IL_0240;
																														case 7:
																															goto IL_0253;
																														case 87:
																															goto IL_0260;
																														case 105:
																															goto IL_0270;
																														case 19:
																															goto IL_0280;
																														case 116:
																															goto IL_028d;
																														case 117:
																															goto IL_029d;
																														case 110:
																															goto IL_02ad;
																														case 4:
																														case 37:
																															goto IL_02bd;
																														case 1:
																														case 73:
																															goto IL_02c8;
																														case 106:
																															goto IL_02db;
																														case 48:
																														case 100:
																															goto IL_02e9;
																														case 26:
																															goto IL_02f7;
																														case 41:
																														case 64:
																															goto IL_0302;
																														case 5:
																															goto IL_0342;
																														case 102:
																															goto IL_0356;
																														case 12:
																															goto IL_0372;
																														case 45:
																														case 94:
																															goto IL_0380;
																														case 51:
																															goto IL_038e;
																														case 3:
																														case 49:
																															goto IL_039c;
																														case 35:
																															goto IL_040a;
																														case 11:
																															goto IL_041d;
																														case 63:
																															goto IL_0430;
																														case 88:
																															goto IL_043b;
																														case 18:
																														case 20:
																															goto IL_0449;
																														case 96:
																														case 112:
																															goto IL_0474;
																														case 22:
																															goto IL_0482;
																														case 72:
																														case 118:
																															goto IL_0490;
																														case 123:
																															goto IL_04a8;
																														case 14:
																															goto IL_04b6;
																														case 31:
																														case 60:
																															goto IL_04d7;
																														case 56:
																															goto IL_04eb;
																														case 81:
																															goto IL_0533;
																														case 42:
																														case 121:
																															goto IL_0558;
																														case 80:
																															goto IL_0566;
																														case 6:
																														case 13:
																															goto IL_057d;
																														case 99:
																															goto IL_0599;
																														case 67:
																														case 113:
																															goto IL_05a4;
																														case 30:
																															goto IL_05e4;
																														case 62:
																															goto IL_05f8;
																														case 16:
																														case 125:
																															goto IL_060b;
																														case 15:
																														case 28:
																															goto IL_0616;
																														case 108:
																															goto IL_0624;
																														case 10:
																														case 38:
																															goto IL_0632;
																														case 70:
																															goto IL_064b;
																														case 91:
																															goto IL_0659;
																														case 43:
																															goto IL_0667;
																														case 109:
																															goto IL_067a;
																														case 17:
																														case 93:
																															goto IL_0685;
																														case 71:
																															goto IL_069c;
																														case 40:
																															goto IL_06bf;
																														case 107:
																															goto IL_06c9;
																														case 114:
																															goto IL_06d7;
																														case 8:
																														case 27:
																														case 34:
																														case 36:
																														case 47:
																														case 50:
																														case 52:
																														case 53:
																														case 55:
																														case 57:
																														case 68:
																														case 75:
																														case 76:
																														case 79:
																														case 82:
																														case 84:
																														case 86:
																														case 90:
																														case 95:
																														case 97:
																														case 101:
																														case 104:
																														case 120:
																															goto end_IL_0240;
																														case 122:
																															goto IL_070a;
																														case 98:
																															goto IL_0718;
																														case 58:
																															goto IL_0726;
																														case 9:
																														case 23:
																														case 29:
																														case 32:
																														case 33:
																														case 44:
																														case 46:
																														case 54:
																														case 59:
																														case 65:
																														case 66:
																														case 77:
																														case 83:
																														case 85:
																														case 89:
																															goto IL_0734;
																														case 119:
																															goto IL_0747;
																														case 0:
																															goto IL_0751;
																														case 61:
																															goto IL_075c;
																														case 39:
																															goto end_IL_022d;
																														case 115:
																															goto end_IL_0771;
																														case 92:
																														case 111:
																															goto end_IL_0786;
																														case 103:
																															goto end_IL_0796;
																														case 2:
																														case 124:
																															goto end_IL_07a6;
																														case 24:
																															goto end_IL_07b6;
																														case 25:
																															goto end_IL_07cf;
																														case 69:
																														case 78:
																															goto IL_07f3;
																														}
																														continue;
																													}
																													if (10 > b)
																													{
																														goto end_IL_0240;
																													}
																													goto IL_04d7;
																													IL_04d7:
																													array[num5 - 1] = 0;
																													goto IL_04eb;
																													IL_0533:
																													ptr2 += 8;
																													num = 83;
																													goto IL_0734;
																													IL_04eb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)RIPEMDGetPrimary[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																													num = 81;
																													goto IL_0533;
																													continue;
																													end_IL_022d:
																													break;
																												}
																												goto end_IL_029d;
																												continue;
																												end_IL_0240:
																												break;
																												IL_0240:;
																											}
																											break;
																										}
																										goto IL_02c8;
																										IL_02c8:
																										num5--;
																										goto IL_0734;
																									}
																									break;
																								}
																								num = 121;
																								goto IL_0558;
																								IL_0566:
																								if (12 > b)
																								{
																									break;
																								}
																								num = 6;
																								goto IL_057d;
																								IL_057d:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto IL_0734;
																								IL_0558:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_0566;
																							}
																							break;
																						}
																						goto IL_0599;
																						IL_06d7:
																						ptr2 += 8;
																						goto IL_0734;
																						IL_0599:
																						if (9 <= b)
																						{
																							goto IL_05a4;
																						}
																						goto IL_060b;
																						IL_05a4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05e4;
																						IL_05e4:
																						array[num5 - 2] = 0;
																						goto IL_05f8;
																						IL_05f8:
																						num5--;
																						goto IL_0734;
																						IL_060b:
																						if (7 < b)
																						{
																							goto IL_0616;
																						}
																						goto IL_067a;
																						IL_0616:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0624;
																						IL_0624:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0632;
																						IL_0632:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_064b;
																						IL_064b:
																						array[num5] = 0;
																						goto IL_0659;
																						IL_0659:
																						num5++;
																						goto IL_0667;
																						IL_0667:
																						ptr2 += 8;
																						goto IL_0734;
																						IL_067a:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0685;
																						IL_0685:
																						array[num5] = 0;
																						num = 71;
																						goto IL_069c;
																						IL_069c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_06bf;
																						IL_06bf:
																						array2[num5] = null;
																						goto IL_06c9;
																						IL_06c9:
																						num5++;
																						goto IL_06d7;
																					}
																					break;
																				}
																				goto IL_02db;
																				IL_0490:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0734;
																				IL_02db:
																				if (6 <= b)
																				{
																					goto IL_0734;
																				}
																				goto IL_02e9;
																				IL_02e9:
																				if (3 >= b)
																				{
																					goto IL_02f7;
																				}
																				goto IL_0430;
																				IL_02f7:
																				if (3 <= b)
																				{
																					goto IL_0302;
																				}
																				goto IL_0372;
																				IL_0302:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0342;
																				IL_0342:
																				array[num5 - 2] = 0;
																				goto IL_0356;
																				IL_0356:
																				num5--;
																				num = 29;
																				goto IL_0734;
																				IL_0372:
																				if (1 < b)
																				{
																					goto IL_0380;
																				}
																				goto IL_041d;
																				IL_0380:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_038e;
																				IL_038e:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_039c;
																				IL_039c:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_040a;
																				IL_040a:
																				num5 -= 2;
																				goto IL_0734;
																				IL_041d:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0430:
																				if (4 >= b)
																				{
																					goto IL_043b;
																				}
																				goto IL_0474;
																				IL_043b:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0449;
																				IL_0449:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04a8;
																				IL_04a8:
																				ptr2 += 8;
																				goto IL_04b6;
																				IL_04b6:
																				num5--;
																				goto IL_0734;
																				IL_0474:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0482;
																				IL_0482:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0490;
																			}
																			break;
																			IL_028d:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_070a;
																	IL_0726:
																	ptr2 += 8;
																	goto IL_0734;
																	IL_0718:
																	num5++;
																	goto IL_0726;
																	IL_070a:
																	array[num5] = 0;
																	goto IL_0718;
																	continue;
																	end_IL_029d:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													num = 69;
													goto IL_07f3;
													IL_07f3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0771:
									break;
								}
								continue;
								end_IL_0786:
								break;
							}
							continue;
							end_IL_0796:
							break;
						}
						continue;
						end_IL_07a6:
						break;
					}
					continue;
					end_IL_07b6:
					break;
				}
				continue;
				end_IL_07cf:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_4, int int_5)
	{
		int num = 34;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComInterfaceTypeFqbn.CursorTopDeclaredProperties);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0235:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0215:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0208:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_01f8:
																								if (8 < b)
																								{
																									while (true)
																									{
																										IL_01e8:
																										if (9 < b)
																										{
																											num = 110;
																											while (num != 110)
																											{
																												if (num != 1091)
																												{
																													goto IL_04b2;
																												}
																												switch (num)
																												{
																												case 35:
																												case 78:
																													goto IL_01e8;
																												case 103:
																													goto IL_01f8;
																												case 2:
																													goto IL_0208;
																												case 75:
																													goto IL_0215;
																												case 16:
																													goto IL_0225;
																												case 82:
																													goto IL_0235;
																												case 57:
																													goto end_IL_0235;
																												case 22:
																												case 90:
																													goto end_IL_0245;
																												case 45:
																													goto IL_0260;
																												case 62:
																													goto IL_0273;
																												case 11:
																												case 56:
																													goto IL_027e;
																												case 31:
																												case 68:
																													goto IL_029c;
																												case 52:
																													goto IL_02aa;
																												case 26:
																												case 77:
																													goto IL_02b8;
																												case 1:
																													goto IL_02f8;
																												case 79:
																												case 85:
																													goto IL_030e;
																												case 94:
																													goto IL_032a;
																												case 97:
																													goto IL_033d;
																												case 86:
																													goto IL_034b;
																												case 84:
																													goto IL_0359;
																												case 99:
																													goto IL_036c;
																												case 30:
																												case 71:
																													goto IL_037a;
																												case 19:
																													goto IL_03ba;
																												case 81:
																													goto IL_03ce;
																												case 102:
																													goto IL_03e1;
																												case 27:
																													goto IL_03ef;
																												case 55:
																													goto IL_03fd;
																												case 17:
																												case 76:
																													goto IL_0408;
																												case 73:
																													goto IL_0448;
																												case 5:
																													goto IL_045c;
																												case 89:
																													goto IL_046f;
																												case 23:
																													goto IL_047d;
																												case 15:
																													goto IL_0499;
																												case 72:
																													goto IL_04a4;
																												case 10:
																												case 53:
																													goto IL_04b2;
																												case 47:
																													goto IL_04db;
																												case 50:
																													goto IL_04e9;
																												case 14:
																													goto IL_04fc;
																												case 7:
																													goto IL_050a;
																												case 38:
																												case 70:
																													goto IL_0518;
																												case 61:
																													goto IL_0558;
																												case 49:
																													goto IL_0575;
																												case 24:
																												case 83:
																													goto IL_0591;
																												case 4:
																													goto IL_059f;
																												case 8:
																													goto IL_05c2;
																												case 20:
																													goto IL_05cc;
																												case 41:
																													goto IL_05da;
																												case 3:
																												case 6:
																												case 29:
																												case 40:
																												case 42:
																												case 43:
																												case 46:
																												case 59:
																												case 63:
																												case 65:
																												case 69:
																												case 74:
																												case 80:
																												case 88:
																												case 91:
																												case 92:
																												case 93:
																												case 101:
																													goto end_IL_01d5;
																												case 87:
																													goto IL_060d;
																												case 98:
																													goto IL_061b;
																												case 67:
																													goto IL_0629;
																												case 0:
																												case 9:
																												case 12:
																												case 13:
																												case 32:
																												case 37:
																												case 44:
																												case 51:
																												case 60:
																												case 64:
																												case 100:
																													goto end_IL_0255;
																												case 28:
																													goto end_IL_0637;
																												case 36:
																													goto end_IL_064a;
																												case 25:
																													goto end_IL_0654;
																												case 39:
																													goto end_IL_065f;
																												case 54:
																													goto end_IL_0674;
																												case 58:
																												case 96:
																													goto end_IL_0689;
																												case 95:
																													goto end_IL_0699;
																												case 18:
																												case 66:
																													goto end_IL_06a9;
																												case 33:
																													goto end_IL_06b9;
																												case 34:
																													goto end_IL_06c9;
																												case 21:
																												case 48:
																													goto IL_06e4;
																												}
																												continue;
																												end_IL_01d5:
																												break;
																											}
																											break;
																										}
																										goto IL_0260;
																										IL_0260:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_030e;
																										IL_030e:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0255;
																									}
																									break;
																								}
																								goto IL_036c;
																								IL_03ce:
																								num6--;
																								goto end_IL_0255;
																								IL_036c:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_037a;
																								IL_037a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_03ba;
																								IL_03ba:
																								array[num6 - 2] = 0;
																								goto IL_03ce;
																							}
																							break;
																						}
																						goto IL_0273;
																						IL_032a:
																						num6--;
																						goto end_IL_0255;
																						IL_0273:
																						if (7 <= b)
																						{
																							goto IL_027e;
																						}
																						goto IL_029c;
																						IL_027e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_033d;
																						IL_033d:
																						array[num6] = 0;
																						goto IL_034b;
																						IL_034b:
																						num6++;
																						goto IL_0359;
																						IL_0359:
																						ptr2 += 8;
																						goto end_IL_0255;
																						IL_029c:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_02aa;
																						IL_02aa:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_02b8;
																						IL_02b8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_02f8;
																						IL_02f8:
																						array[num6 - 2] = 0;
																						goto IL_032a;
																					}
																					break;
																				}
																				goto IL_03e1;
																				IL_05c2:
																				array2[num6] = null;
																				goto IL_05cc;
																				IL_03e1:
																				if (5 > b)
																				{
																					goto IL_03ef;
																				}
																				num = 83;
																				goto IL_0591;
																				IL_03ef:
																				if (2 >= b)
																				{
																					goto IL_03fd;
																				}
																				goto IL_0499;
																				IL_03fd:
																				if (2 <= b)
																				{
																					goto IL_0408;
																				}
																				goto IL_046f;
																				IL_0408:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0448;
																				IL_0448:
																				array[num6 - 2] = 0;
																				goto IL_045c;
																				IL_045c:
																				num6--;
																				goto end_IL_0255;
																				IL_046f:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_047d;
																				IL_047d:
																				if (1 <= b)
																				{
																					num = 59;
																				}
																				break;
																				IL_05da:
																				ptr2 += 8;
																				goto end_IL_0255;
																				IL_0499:
																				if (3 >= b)
																				{
																					goto IL_04a4;
																				}
																				goto IL_04fc;
																				IL_04a4:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_04b2;
																				IL_04b2:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04db;
																				IL_04db:
																				ptr2 += 8;
																				goto IL_04e9;
																				IL_04e9:
																				num6--;
																				goto end_IL_0255;
																				IL_04fc:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_050a;
																				IL_050a:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0518;
																				IL_0518:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0558;
																				IL_0558:
																				array[num6 - 2] = 0;
																				num = 49;
																				goto IL_0575;
																				IL_0575:
																				num6--;
																				goto end_IL_0255;
																				IL_05cc:
																				num6++;
																				goto IL_05da;
																				IL_0591:
																				array[num6] = 0;
																				goto IL_059f;
																				IL_059f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05c2;
																			}
																			break;
																			IL_0225:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060d;
																	IL_0629:
																	ptr2 += 8;
																	goto end_IL_0255;
																	IL_061b:
																	num6++;
																	goto IL_0629;
																	IL_060d:
																	array[num6] = 0;
																	goto IL_061b;
																	continue;
																	end_IL_0235:
																	break;
																}
																continue;
																end_IL_0245:
																break;
															}
															continue;
															end_IL_0255:
															break;
														}
														continue;
													}
													goto IL_06e4;
													IL_06e4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0637:
													break;
												}
												continue;
												end_IL_064a:
												break;
											}
											continue;
											end_IL_0654:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									continue;
									end_IL_0674:
									break;
								}
								continue;
								end_IL_0689:
								break;
							}
							continue;
							end_IL_0699:
							break;
						}
						continue;
						end_IL_06a9:
						break;
					}
					continue;
					end_IL_06b9:
					break;
				}
				continue;
				end_IL_06c9:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_4)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackBuilderSinkBind.stackBuilderSinkBind_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 77;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_022c:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_01ff:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_01e6:
																								array[num5] = 0;
																								num = 113;
																								while (true)
																								{
																									if (num != 113)
																									{
																										if (num != 1094)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 31:
																										case 37:
																											goto IL_01e6;
																										case 82:
																											goto IL_01ff;
																										case 70:
																											goto end_IL_01ff;
																										case 74:
																											goto end_IL_020c;
																										case 58:
																											goto IL_022c;
																										case 7:
																											goto end_IL_022c;
																										case 77:
																											goto end_IL_023c;
																										case 66:
																											goto end_IL_024c;
																										case 10:
																										case 48:
																											goto IL_0262;
																										case 3:
																										case 17:
																											goto end_IL_01d3;
																										case 9:
																										case 14:
																											goto IL_0281;
																										case 49:
																											goto IL_0291;
																										case 11:
																										case 41:
																											goto IL_02aa;
																										case 56:
																											goto IL_02c2;
																										case 100:
																											goto IL_02d5;
																										case 87:
																											goto IL_02e0;
																										case 64:
																											goto IL_02ee;
																										case 20:
																										case 53:
																											goto IL_02fc;
																										case 36:
																											goto IL_0315;
																										case 85:
																											goto IL_0323;
																										case 6:
																											goto IL_0331;
																										case 94:
																										case 95:
																											goto IL_034d;
																										case 69:
																											goto IL_0376;
																										case 81:
																											goto IL_0384;
																										case 29:
																											goto IL_03ba;
																										case 50:
																											goto IL_03c4;
																										case 47:
																											goto IL_03d2;
																										case 90:
																											goto IL_03e5;
																										case 46:
																										case 55:
																											goto IL_03f0;
																										case 1:
																											goto IL_03fb;
																										case 15:
																										case 45:
																											goto IL_0409;
																										case 24:
																										case 72:
																											goto IL_0425;
																										case 39:
																											goto IL_0433;
																										case 91:
																											goto IL_0446;
																										case 22:
																										case 51:
																											goto IL_0454;
																										case 5:
																										case 84:
																											goto IL_045f;
																										case 34:
																											goto IL_046d;
																										case 0:
																										case 65:
																											goto IL_047b;
																										case 86:
																											goto IL_049e;
																										case 4:
																											goto IL_04ac;
																										case 27:
																											goto IL_04ba;
																										case 13:
																											goto IL_04d6;
																										case 63:
																										case 67:
																											goto IL_04e4;
																										case 33:
																											goto IL_0524;
																										case 62:
																											goto IL_0538;
																										case 78:
																										case 89:
																											goto IL_054b;
																										case 26:
																											goto IL_05ad;
																										case 12:
																										case 16:
																										case 23:
																										case 30:
																										case 32:
																										case 52:
																										case 54:
																										case 73:
																										case 76:
																										case 79:
																										case 83:
																										case 88:
																										case 92:
																										case 93:
																										case 97:
																										case 102:
																										case 103:
																										case 104:
																										case 105:
																											goto end_IL_021c;
																										case 8:
																										case 21:
																										case 28:
																										case 38:
																										case 42:
																										case 44:
																										case 57:
																										case 59:
																										case 80:
																										case 96:
																										case 99:
																										case 101:
																										case 106:
																											goto end_IL_0257;
																										case 19:
																											goto end_IL_05d0;
																										case 43:
																											goto end_IL_05e3;
																										case 71:
																											goto end_IL_05ed;
																										case 35:
																											goto end_IL_05f8;
																										case 2:
																										case 40:
																											goto end_IL_060d;
																										case 25:
																											goto end_IL_061d;
																										case 18:
																										case 98:
																											goto end_IL_062d;
																										case 60:
																											goto end_IL_063d;
																										case 61:
																											goto end_IL_064d;
																										case 68:
																										case 75:
																											goto IL_0668;
																										}
																										continue;
																									}
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03ba;
																									IL_03ba:
																									array2[num5] = null;
																									goto IL_03c4;
																									IL_03d2:
																									ptr2 += 8;
																									goto end_IL_0257;
																									IL_03c4:
																									num5++;
																									goto IL_03d2;
																									continue;
																									end_IL_01d3:
																									break;
																								}
																								break;
																							}
																							goto IL_026d;
																						}
																						goto IL_0262;
																						IL_0384:
																						num5--;
																						goto end_IL_0257;
																						IL_0262:
																						if (2 < b)
																						{
																							goto IL_026d;
																						}
																						goto IL_02d5;
																						IL_026d:
																						if (3 < b)
																						{
																							num = 9;
																							goto IL_0281;
																						}
																						goto IL_0291;
																						IL_034d:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0376;
																						IL_0281:
																						if (4 < b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_02c2;
																						IL_02c2:
																						if (4 <= b)
																						{
																							goto end_IL_0257;
																						}
																						goto end_IL_021c;
																						IL_0291:
																						if (3 > b)
																						{
																							num = 32;
																							goto end_IL_021c;
																						}
																						goto IL_02aa;
																						IL_0376:
																						ptr2 += 8;
																						goto IL_0384;
																						IL_02aa:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0257;
																						IL_02d5:
																						if (2 > b)
																						{
																							goto IL_02e0;
																						}
																						num = 95;
																						goto IL_034d;
																						IL_02e0:
																						if (1 < b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_02ee;
																						IL_02ee:
																						if (1 > b)
																						{
																							goto end_IL_021c;
																						}
																						goto IL_02fc;
																						IL_02fc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0315;
																						IL_0315:
																						array[num5] = 0;
																						goto IL_0323;
																						IL_0323:
																						num5++;
																						goto IL_0331;
																						IL_0331:
																						ptr2 += 8;
																						goto end_IL_0257;
																						continue;
																						end_IL_01ff:
																						break;
																					}
																					continue;
																				}
																				goto IL_03e5;
																				IL_05ad:
																				num5 -= 2;
																				goto end_IL_0257;
																				IL_03e5:
																				if (8 < b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_0446;
																				IL_03f0:
																				if (9 >= b)
																				{
																					goto IL_03fb;
																				}
																				goto IL_0425;
																				IL_03fb:
																				if (9 > b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_0409;
																				IL_0409:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0257;
																				IL_0425:
																				if (10 < b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_0433;
																				IL_0433:
																				if (10 > b)
																				{
																				}
																				goto end_IL_021c;
																				IL_0446:
																				if (8 > b)
																				{
																					goto IL_0454;
																				}
																				goto IL_054b;
																				IL_0454:
																				if (6 < b)
																				{
																					goto IL_045f;
																				}
																				goto IL_04d6;
																				IL_045f:
																				if (7 < b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_046d;
																				IL_046d:
																				if (7 > b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_047b;
																				IL_047b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_049e;
																				IL_049e:
																				array[num5] = 0;
																				goto IL_04ac;
																				IL_04ac:
																				num5++;
																				goto IL_04ba;
																				IL_04ba:
																				ptr2 += 8;
																				num = 57;
																				goto end_IL_0257;
																				IL_04d6:
																				if (6 > b)
																				{
																					goto end_IL_021c;
																				}
																				goto IL_04e4;
																				IL_04e4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0524;
																				IL_0524:
																				array[num5 - 2] = 0;
																				goto IL_0538;
																				IL_0538:
																				num5--;
																				goto end_IL_0257;
																				IL_054b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05ad;
																				continue;
																				end_IL_020c:
																				break;
																			}
																			continue;
																			end_IL_021c:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0257;
																	continue;
																	end_IL_022c:
																	break;
																}
																continue;
																end_IL_023c:
																break;
															}
															continue;
															end_IL_024c:
															break;
														}
														continue;
														end_IL_0257:
														break;
													}
													continue;
												}
												goto IL_0668;
												IL_0668:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d0:
												break;
											}
											continue;
											end_IL_05e3:
											break;
										}
										continue;
										end_IL_05ed:
										break;
									}
									continue;
									end_IL_05f8:
									break;
								}
								continue;
								end_IL_060d:
								break;
							}
							continue;
							end_IL_061d:
							break;
						}
						continue;
						end_IL_062d:
						break;
					}
					continue;
					end_IL_063d:
					break;
				}
				continue;
				end_IL_064d:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_4, int int_5)
	{
		int num = 16;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 50;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_4;
										while (true)
										{
											array3[1] = int_5;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setXCertificateInnerExceptions.FormDDisallowUnassignedInternalImpl);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 61;
																while (true)
																{
																	byte b = *ptr2;
																	num = 89;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_021a:
																			if (b >= 1)
																			{
																				while (b <= 8)
																				{
																					while (true)
																					{
																						IL_01fd:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_01f0:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_01e0:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												num = 47;
																												while (true)
																												{
																													IL_01b4:
																													array[num5] = 0;
																													num = 97;
																													while (true)
																													{
																														if (num != 97)
																														{
																															if (num != 1078)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 34:
																															case 47:
																																goto IL_01b4;
																															case 27:
																																goto IL_01cd;
																															case 25:
																															case 57:
																																goto IL_01e0;
																															case 51:
																																goto IL_01f0;
																															case 77:
																																goto IL_01fd;
																															case 49:
																																goto IL_020a;
																															case 90:
																																goto IL_021a;
																															case 89:
																																goto end_IL_021a;
																															case 61:
																																goto end_IL_022a;
																															case 76:
																																goto end_IL_023a;
																															case 63:
																																goto IL_0259;
																															case 36:
																															case 42:
																																goto IL_0267;
																															case 35:
																																goto IL_0275;
																															case 64:
																																goto IL_0285;
																															case 44:
																															case 67:
																																goto IL_0292;
																															case 21:
																															case 69:
																																goto IL_02aa;
																															case 12:
																																goto IL_02d3;
																															case 70:
																																goto IL_02e1;
																															case 74:
																															case 80:
																																goto IL_02f4;
																															case 43:
																															case 55:
																																goto IL_0302;
																															case 72:
																																goto end_IL_01a1;
																															case 20:
																															case 71:
																																goto IL_031e;
																															case 45:
																																goto IL_0367;
																															case 81:
																																goto IL_037b;
																															case 9:
																															case 82:
																																goto IL_038e;
																															case 59:
																																goto IL_03a5;
																															case 38:
																															case 56:
																																goto IL_03b3;
																															case 83:
																																goto IL_03cf;
																															case 8:
																															case 41:
																																goto IL_03dd;
																															case 3:
																																goto IL_044b;
																															case 87:
																																goto IL_045e;
																															case 85:
																																goto IL_0469;
																															case 6:
																																goto IL_0499;
																															case 58:
																																goto IL_04a3;
																															case 5:
																																goto IL_04b1;
																															case 0:
																															case 7:
																															case 23:
																															case 26:
																															case 31:
																															case 32:
																															case 33:
																															case 37:
																															case 40:
																															case 53:
																															case 60:
																															case 62:
																															case 66:
																															case 75:
																															case 79:
																															case 86:
																															case 88:
																																goto end_IL_01cd;
																															case 29:
																																goto IL_04ed;
																															case 52:
																																goto IL_04fb;
																															case 78:
																																goto IL_0512;
																															case 1:
																															case 11:
																															case 13:
																															case 14:
																															case 18:
																															case 22:
																															case 24:
																															case 30:
																															case 48:
																															case 54:
																															case 73:
																																goto end_IL_024e;
																															case 4:
																																goto end_IL_0520;
																															case 65:
																																goto end_IL_0533;
																															case 39:
																																goto end_IL_053d;
																															case 68:
																																goto end_IL_0548;
																															case 17:
																																goto end_IL_055d;
																															case 50:
																																goto end_IL_0572;
																															case 19:
																																goto end_IL_0582;
																															case 10:
																																goto end_IL_0592;
																															case 28:
																															case 84:
																																goto end_IL_059d;
																															case 15:
																																goto end_IL_05ad;
																															case 16:
																																goto end_IL_05bd;
																															case 2:
																															case 46:
																																goto IL_05d8;
																															}
																															continue;
																														}
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														goto IL_0499;
																														IL_0499:
																														array2[num5] = null;
																														goto IL_04a3;
																														IL_04b1:
																														ptr2 += 8;
																														goto end_IL_024e;
																														IL_04a3:
																														num5++;
																														goto IL_04b1;
																														continue;
																														end_IL_01a1:
																														break;
																													}
																													break;
																												}
																												goto IL_0310;
																												continue;
																												end_IL_01cd:
																												break;
																												IL_01cd:;
																											}
																											break;
																										}
																										goto IL_038e;
																										IL_03a5:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_03b3;
																										IL_038e:
																										if (8 < b)
																										{
																											break;
																										}
																										num = 59;
																										goto IL_03a5;
																										IL_03b3:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										goto end_IL_024e;
																									}
																									break;
																								}
																								goto IL_0259;
																								IL_0292:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_024e;
																								IL_0259:
																								if (6 <= b)
																								{
																									goto end_IL_024e;
																								}
																								goto IL_0267;
																								IL_0267:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0275;
																								IL_0275:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0292;
																							}
																							break;
																						}
																						goto IL_0285;
																						IL_02e1:
																						num5--;
																						goto end_IL_024e;
																						IL_0285:
																						if (4 <= b)
																						{
																							goto IL_02aa;
																						}
																						goto IL_02f4;
																						IL_02f4:
																						if (2 < b)
																						{
																							goto IL_0302;
																						}
																						goto IL_03cf;
																						IL_0302:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_0310;
																						IL_0310:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_031e;
																						IL_031e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 45;
																						goto IL_0367;
																						IL_0367:
																						array[num5 - 2] = 0;
																						goto IL_037b;
																						IL_037b:
																						num5--;
																						goto end_IL_024e;
																						IL_03cf:
																						if (2 <= b)
																						{
																							goto IL_03dd;
																						}
																						goto IL_045e;
																						IL_03dd:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_044b;
																						IL_044b:
																						num5 -= 2;
																						goto end_IL_024e;
																						IL_045e:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0469;
																						IL_0469:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_02aa:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02d3;
																						IL_02d3:
																						ptr2 += 8;
																						goto IL_02e1;
																					}
																					break;
																					IL_020a:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 29;
																			goto IL_04ed;
																			IL_0512:
																			ptr2 += 8;
																			goto end_IL_024e;
																			IL_04fb:
																			num5++;
																			num = 78;
																			goto IL_0512;
																			IL_04ed:
																			array[num5] = 0;
																			goto IL_04fb;
																			continue;
																			end_IL_021a:
																			break;
																		}
																		continue;
																		end_IL_022a:
																		break;
																	}
																	continue;
																	end_IL_023a:
																	break;
																}
																continue;
																end_IL_024e:
																break;
															}
															continue;
														}
														goto IL_05d8;
														IL_05d8:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0520:
														break;
													}
													continue;
													end_IL_0533:
													break;
												}
												continue;
												end_IL_053d:
												break;
											}
											continue;
											end_IL_0548:
											break;
										}
										continue;
										end_IL_055d:
										break;
									}
									continue;
									end_IL_0572:
									break;
								}
								continue;
								end_IL_0582:
								break;
							}
							continue;
							end_IL_0592:
							break;
						}
						continue;
						end_IL_059d:
						break;
					}
					continue;
					end_IL_05ad:
					break;
				}
				continue;
				end_IL_05bd:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_4)
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						IL_065a:
						object[] array2 = new object[2];
						while (true)
						{
							IL_064f:
							num = 85;
							while (true)
							{
								IL_0636:
								int[] array3 = new int[3];
								num = 103;
								while (true)
								{
									IL_0626:
									long[] array4 = new long[2];
									while (true)
									{
										IL_0611:
										array3[0] = int_4;
										while (true)
										{
											IL_0606:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TracingStatusChangedEventArgsgetAsCy.TimeZoneNotFoundExceptionFindName);
											while (true)
											{
												IL_05fc:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_05e9:
													if (num4 != 1)
													{
														while (true)
														{
															IL_02aa:
															byte b = *ptr2;
															num = 93;
															while (true)
															{
																IL_029a:
																ptr2++;
																while (true)
																{
																	IL_028a:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_026a:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_025a:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_024d:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_023d:
																										if (6 >= b)
																										{
																											while (6 <= b)
																											{
																												while (true)
																												{
																													IL_01e2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 112;
																													while (true)
																													{
																														if (num != 112)
																														{
																															if (num != 1093)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 2:
																															case 79:
																																goto IL_01e2;
																															case 83:
																																goto IL_022d;
																															case 84:
																																goto IL_023d;
																															case 69:
																																goto IL_024d;
																															case 73:
																																goto IL_025a;
																															case 81:
																																goto IL_026a;
																															case 9:
																																goto IL_027a;
																															case 17:
																																goto IL_028a;
																															case 93:
																																goto IL_029a;
																															case 50:
																															case 88:
																																goto IL_02aa;
																															case 13:
																															case 42:
																																goto IL_02be;
																															case 51:
																																goto IL_0320;
																															case 77:
																																goto IL_0333;
																															case 21:
																																goto IL_0341;
																															case 1:
																															case 24:
																																goto IL_034c;
																															case 60:
																																goto IL_035f;
																															case 3:
																															case 8:
																																goto IL_036a;
																															case 5:
																																goto IL_0378;
																															case 6:
																															case 35:
																																goto IL_0386;
																															case 29:
																																goto IL_039f;
																															case 4:
																															case 86:
																																goto IL_03bb;
																															case 19:
																															case 58:
																																goto IL_03c6;
																															case 70:
																																goto IL_03d6;
																															case 34:
																															case 90:
																																goto IL_03e9;
																															case 45:
																																goto IL_0412;
																															case 89:
																																goto IL_0429;
																															case 91:
																																goto IL_043c;
																															case 92:
																																goto IL_044f;
																															case 15:
																															case 64:
																																goto IL_045d;
																															case 97:
																																goto IL_0475;
																															case 98:
																																goto IL_0483;
																															case 101:
																																goto IL_0496;
																															case 38:
																																goto IL_04a4;
																															case 11:
																															case 104:
																																goto IL_04b7;
																															case 57:
																																goto IL_04ce;
																															case 67:
																																goto IL_04f1;
																															case 87:
																																goto IL_04fb;
																															case 37:
																																goto IL_0509;
																															case 43:
																															case 105:
																																goto IL_051c;
																															case 62:
																																goto IL_0555;
																															case 99:
																																goto IL_0568;
																															case 20:
																																goto IL_0573;
																															case 49:
																															case 100:
																																goto IL_057e;
																															case 40:
																																goto IL_05aa;
																															case 72:
																																goto IL_05b8;
																															case 65:
																																goto IL_05c6;
																															case 7:
																															case 14:
																															case 22:
																															case 25:
																															case 27:
																															case 28:
																															case 36:
																															case 39:
																															case 44:
																															case 48:
																															case 54:
																															case 55:
																															case 59:
																															case 66:
																															case 68:
																															case 71:
																															case 74:
																															case 75:
																															case 76:
																															case 94:
																															case 96:
																																goto end_IL_022d;
																															case 0:
																															case 10:
																															case 18:
																															case 23:
																															case 41:
																															case 46:
																															case 47:
																															case 56:
																															case 61:
																															case 63:
																															case 82:
																															case 95:
																															case 102:
																																goto IL_05e9;
																															case 12:
																																goto IL_05fc;
																															case 80:
																																goto IL_0606;
																															case 52:
																																goto IL_0611;
																															case 103:
																																goto IL_0626;
																															case 85:
																																goto IL_0636;
																															case 16:
																																goto IL_064f;
																															case 33:
																																goto IL_065a;
																															case 26:
																															case 53:
																																goto end_IL_01cf;
																															case 31:
																																goto end_IL_066a;
																															case 32:
																																goto end_IL_067a;
																															case 30:
																															case 78:
																																goto IL_0695;
																															}
																															continue;
																														}
																														array[num5 - 2] = 0;
																														goto IL_0555;
																														IL_0555:
																														num5--;
																														goto IL_05e9;
																														continue;
																														end_IL_01cf:
																														break;
																													}
																													break;
																												}
																												goto end_IL_028a;
																												continue;
																												end_IL_022d:
																												break;
																												IL_022d:;
																											}
																											break;
																										}
																										goto IL_0568;
																										IL_05c6:
																										ptr2 += 8;
																										goto IL_05e9;
																										IL_0568:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0573;
																										IL_0573:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_057e;
																										IL_057e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										num = 40;
																										goto IL_05aa;
																										IL_05aa:
																										array[num5] = 0;
																										goto IL_05b8;
																										IL_05b8:
																										num5++;
																										goto IL_05c6;
																									}
																									break;
																								}
																								goto IL_02be;
																								IL_0320:
																								num5 -= 2;
																								goto IL_05e9;
																								IL_02be:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0320;
																							}
																							break;
																						}
																						goto IL_03bb;
																						IL_051c:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						num = 56;
																						goto IL_05e9;
																						IL_03bb:
																						if (9 < b)
																						{
																							goto IL_03c6;
																						}
																						goto IL_03d6;
																						IL_03c6:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_043c;
																						IL_043c:
																						if (10 <= b)
																						{
																						}
																						break;
																						IL_03d6:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_051c;
																					}
																					break;
																				}
																				goto IL_0333;
																				IL_0509:
																				ptr2 += 8;
																				goto IL_05e9;
																				IL_0333:
																				if (5 > b)
																				{
																					goto IL_0341;
																				}
																				goto IL_04b7;
																				IL_0341:
																				if (2 < b)
																				{
																					goto IL_034c;
																				}
																				goto IL_035f;
																				IL_034c:
																				if (3 >= b)
																				{
																					goto IL_044f;
																				}
																				goto IL_0475;
																				IL_044f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_045d;
																				IL_045d:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05e9;
																				IL_0475:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0483;
																				IL_0483:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05e9;
																				IL_035f:
																				if (2 > b)
																				{
																					goto IL_036a;
																				}
																				goto IL_03e9;
																				IL_036a:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0378;
																				IL_0378:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0386;
																				IL_0386:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_039f;
																				IL_039f:
																				array[num5] = 0;
																				num = 101;
																				goto IL_0496;
																				IL_0496:
																				num5++;
																				goto IL_04a4;
																				IL_04a4:
																				ptr2 += 8;
																				goto IL_05e9;
																				IL_03e9:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0412;
																				IL_0412:
																				ptr2 += 8;
																				num = 89;
																				goto IL_0429;
																				IL_0429:
																				num5--;
																				goto IL_05e9;
																				IL_04b7:
																				array[num5] = 0;
																				num = 57;
																				goto IL_04ce;
																				IL_04ce:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04f1;
																				IL_04f1:
																				array2[num5] = null;
																				goto IL_04fb;
																				IL_04fb:
																				num5++;
																				goto IL_0509;
																			}
																			break;
																			IL_027a:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05e9;
																	continue;
																	end_IL_028a:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_0695;
													IL_0695:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_066a:
					break;
				}
				continue;
				end_IL_067a:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_4)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 95;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NumberGroupSeparatorIgnorableSymbol.IsClosedExceptionArgument);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02e1:
														byte b = *ptr2;
														while (true)
														{
															IL_02d1:
															ptr2++;
															while (true)
															{
																IL_02c1:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_02a4:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0294:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0284:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0274:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_0222:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0203:
																													array[num5 - 2] = 0;
																													num = 43;
																													while (true)
																													{
																														IL_01ea:
																														num5--;
																														num = 114;
																														while (num != 114 && num == 1095)
																														{
																															switch (num)
																															{
																															case 43:
																																goto IL_01ea;
																															case 80:
																																goto IL_0203;
																															case 49:
																															case 103:
																																goto IL_0222;
																															case 21:
																																goto IL_0264;
																															case 37:
																																goto IL_0274;
																															case 84:
																																goto IL_0284;
																															case 67:
																																goto IL_0294;
																															case 86:
																																goto IL_02a4;
																															case 54:
																																goto IL_02b1;
																															case 73:
																																goto IL_02c1;
																															case 41:
																																goto IL_02d1;
																															case 5:
																															case 56:
																																goto IL_02e1;
																															case 77:
																																goto IL_02ec;
																															case 11:
																															case 35:
																																goto IL_02fa;
																															case 47:
																																goto IL_0308;
																															case 14:
																																goto IL_032b;
																															case 78:
																																goto IL_0335;
																															case 76:
																																goto IL_0343;
																															case 51:
																															case 81:
																																goto IL_035f;
																															case 45:
																																goto IL_036d;
																															case 83:
																															case 87:
																																goto IL_0389;
																															case 4:
																																goto IL_03eb;
																															case 40:
																															case 92:
																																goto IL_03fe;
																															case 1:
																																goto IL_0409;
																															case 42:
																															case 85:
																																goto IL_0417;
																															case 28:
																																goto IL_042a;
																															case 63:
																																goto IL_0435;
																															case 39:
																																goto IL_0443;
																															case 46:
																																goto IL_045f;
																															case 22:
																															case 27:
																																goto IL_046d;
																															case 23:
																															case 97:
																																goto IL_0485;
																															case 36:
																																goto IL_04a8;
																															case 98:
																																goto IL_04b8;
																															case 68:
																															case 100:
																																goto IL_04cb;
																															case 32:
																															case 82:
																																goto IL_04d6;
																															case 50:
																																goto IL_04e4;
																															case 74:
																																goto IL_04f7;
																															case 101:
																																goto IL_0507;
																															case 99:
																																goto IL_0515;
																															case 62:
																															case 102:
																																goto IL_0528;
																															case 24:
																															case 105:
																																goto IL_054d;
																															case 18:
																																goto IL_0566;
																															case 6:
																																goto IL_057d;
																															case 8:
																																goto IL_058b;
																															case 52:
																															case 106:
																																goto IL_059b;
																															case 3:
																																goto IL_05c4;
																															case 104:
																																goto IL_05d2;
																															case 10:
																															case 12:
																															case 13:
																															case 15:
																															case 20:
																															case 33:
																															case 34:
																															case 38:
																															case 44:
																															case 48:
																															case 55:
																															case 57:
																															case 64:
																															case 65:
																															case 69:
																															case 70:
																															case 71:
																															case 72:
																															case 75:
																															case 79:
																															case 90:
																															case 93:
																																goto end_IL_0264;
																															case 2:
																															case 7:
																															case 9:
																															case 17:
																															case 26:
																															case 29:
																															case 30:
																															case 31:
																															case 53:
																															case 60:
																															case 61:
																															case 66:
																																goto end_IL_01d7;
																															case 88:
																																goto end_IL_05f5;
																															case 91:
																																goto end_IL_0608;
																															case 89:
																																goto end_IL_0612;
																															case 0:
																																goto end_IL_061d;
																															case 25:
																															case 94:
																																goto end_IL_0632;
																															case 59:
																																goto end_IL_0642;
																															case 16:
																															case 58:
																																goto end_IL_0652;
																															case 95:
																																goto end_IL_0662;
																															case 96:
																																goto end_IL_0672;
																															case 19:
																															case 107:
																																goto IL_0696;
																															}
																															continue;
																															end_IL_01d7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_02c1;
																											continue;
																											end_IL_0264:
																											break;
																											IL_0264:;
																										}
																										break;
																									}
																									goto IL_035f;
																									IL_0507:
																									num5++;
																									goto IL_0515;
																									IL_035f:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_036d;
																									IL_036d:
																									if (7 > b)
																									{
																										break;
																									}
																									num = 97;
																									goto IL_0485;
																									IL_0515:
																									ptr2 += 8;
																									goto end_IL_02c1;
																									IL_0485:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_04a8;
																									IL_04a8:
																									array[num5] = 0;
																									goto IL_0507;
																								}
																								break;
																							}
																							goto IL_0389;
																							IL_03eb:
																							num5 -= 2;
																							goto end_IL_02c1;
																							IL_0389:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03eb;
																						}
																						break;
																					}
																					goto IL_04cb;
																					IL_0528:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 2;
																					goto end_IL_02c1;
																					IL_04cb:
																					if (9 < b)
																					{
																						goto IL_04d6;
																					}
																					goto IL_04f7;
																					IL_04d6:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_04e4;
																					IL_04e4:
																					if (10 <= b)
																					{
																					}
																					break;
																					IL_04f7:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0528;
																				}
																				break;
																			}
																			goto IL_02ec;
																			IL_045f:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_046d;
																			IL_02ec:
																			if (5 <= b)
																			{
																				goto IL_02fa;
																			}
																			goto IL_03fe;
																			IL_02fa:
																			array[num5] = 0;
																			goto IL_0308;
																			IL_0308:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_032b;
																			IL_032b:
																			array2[num5] = null;
																			goto IL_0335;
																			IL_0335:
																			num5++;
																			goto IL_0343;
																			IL_0343:
																			ptr2 += 8;
																			num = 29;
																			goto end_IL_02c1;
																			IL_03fe:
																			if (2 >= b)
																			{
																				goto IL_0409;
																			}
																			goto IL_042a;
																			IL_0409:
																			if (2 > b)
																			{
																				goto IL_0417;
																			}
																			goto IL_059b;
																			IL_0417:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04b8;
																			IL_04b8:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_054d;
																			IL_054d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0566;
																			IL_0566:
																			array[num5] = 0;
																			num = 6;
																			goto IL_057d;
																			IL_057d:
																			num5++;
																			goto IL_058b;
																			IL_058b:
																			ptr2 += 8;
																			goto end_IL_02c1;
																			IL_059b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05c4;
																			IL_05c4:
																			ptr2 += 8;
																			goto IL_05d2;
																			IL_05d2:
																			num5--;
																			goto end_IL_02c1;
																			IL_042a:
																			if (3 < b)
																			{
																				goto IL_0435;
																			}
																			num = 46;
																			goto IL_045f;
																			IL_0435:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0443;
																			IL_0443:
																			if (4 <= b)
																			{
																				goto end_IL_02c1;
																			}
																			break;
																			IL_046d:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02c1;
																		}
																		break;
																		IL_02b1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02c1:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0696;
												IL_0696:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f5:
												break;
											}
											continue;
											end_IL_0608:
											break;
										}
										continue;
										end_IL_0612:
										break;
									}
									continue;
									end_IL_061d:
									break;
								}
								continue;
								end_IL_0632:
								break;
							}
							continue;
							end_IL_0642:
							break;
						}
						continue;
						end_IL_0652:
						break;
					}
					continue;
					end_IL_0662:
					break;
				}
				continue;
				end_IL_0672:
				break;
			}
		}
	}

	static Class106()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 3;
					while (true)
					{
						IL_004a:
						num = 13;
						while (true)
						{
							if (num != 13)
							{
								if (num != 994)
								{
									break;
								}
								switch (num)
								{
								case 3:
									goto IL_004a;
								case 4:
								case 6:
									goto end_IL_003d;
								case 1:
									goto end_IL_0056;
								case 2:
									goto end_IL_0065;
								case 0:
									return;
								case 5:
									return;
								}
								continue;
							}
							return;
							continue;
							end_IL_003d:
							break;
						}
						break;
					}
					continue;
					end_IL_0056:
					break;
				}
				continue;
				end_IL_0065:
				break;
			}
		}
	}
}
