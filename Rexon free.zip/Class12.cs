using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Utilities;

[HarmonyPatch(typeof(MonkeAgent), "SendReport")]
internal class Class12
{
	private static float float_0;

	private static bool bool_0;

	private static double double_0;

	private static bool bool_1;

	private static bool bool_2;

	private static int int_0;

	private static int int_1;

	private static IntPtr[] WriteArraycharBuffer;

	public static bool Prefix(string susReason, string susId, string susNick)
	{
		int num = 180;
		num = 36;
		num = 325;
		num = 25;
		num = 36;
		num = 61;
		num = 61;
		num = 61;
		num = 550;
		num = 50;
		num = 228;
		num = 76;
		num = 50;
		num = 126;
		num = 3750;
		num = 3750;
		num = 3811;
		num = 2132;
		num = 164;
		object obj = "L";
		object obj2 = obj;
		obj = "B";
		object obj3 = obj;
		obj = "f";
		object obj4 = obj;
		obj = "=";
		object obj5 = obj;
		obj = "5";
		object obj6 = obj;
		obj = "e";
		object obj7 = obj;
		obj = "C";
		object obj8 = obj;
		obj = ">";
		object obj9 = obj;
		obj = "Y";
		object obj10 = obj;
		obj = " ";
		object obj11 = obj;
		obj = "O";
		object obj12 = obj;
		obj = "t";
		object obj13 = obj;
		obj = "<";
		object obj14 = obj;
		obj = "l";
		object obj15 = obj;
		obj = "r";
		object obj16 = obj;
		obj = "R";
		object obj17 = obj;
		obj = "p";
		object obj18 = obj;
		obj = "]";
		object obj19 = obj;
		obj = "K";
		object obj20 = obj;
		obj = ")";
		object obj21 = obj;
		obj = "(";
		object obj22 = obj;
		obj = "/";
		object obj23 = obj;
		obj = "c";
		object obj24 = obj;
		obj = "E";
		object obj25 = obj;
		obj = "A";
		object obj26 = obj;
		obj = "n";
		object obj27 = obj;
		obj = "T";
		object obj28 = obj;
		obj = "8";
		object obj29 = obj;
		obj = "o";
		object obj30 = obj;
		obj = "i";
		object obj31 = obj;
		obj = "P";
		object obj32 = obj;
		obj = "#";
		object obj33 = obj;
		obj = "D";
		object obj34 = obj;
		obj = "[";
		object obj35 = obj;
		obj = "g";
		object obj36 = obj;
		num = 45;
		num = 9;
		obj = new string[9];
		object obj37 = obj;
		object obj38 = obj21;
		((string[])obj37)[0] = (string)obj38;
		obj37 = obj;
		obj38 = obj14;
		((string[])obj37)[1] = (string)obj38;
		obj37 = obj;
		obj38 = obj23;
		((string[])obj37)[2] = (string)obj38;
		obj37 = obj;
		obj38 = obj24;
		((string[])obj37)[3] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[4] = (string)obj38;
		obj37 = obj;
		obj38 = obj15;
		((string[])obj37)[5] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[6] = (string)obj38;
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[7] = (string)obj38;
		obj37 = obj;
		obj38 = obj9;
		((string[])obj37)[8] = (string)obj38;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj39 = obj;
		num = 495;
		num = 45;
		obj = new string[45];
		obj37 = obj;
		obj38 = obj14;
		((string[])obj37)[0] = (string)obj38;
		obj37 = obj;
		obj38 = obj24;
		((string[])obj37)[1] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[2] = (string)obj38;
		obj37 = obj;
		obj38 = obj15;
		((string[])obj37)[3] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[4] = (string)obj38;
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[5] = (string)obj38;
		obj37 = obj;
		obj38 = obj5;
		((string[])obj37)[6] = (string)obj38;
		obj37 = obj;
		obj38 = obj33;
		((string[])obj37)[7] = (string)obj38;
		obj37 = obj;
		obj38 = obj4;
		((string[])obj37)[8] = (string)obj38;
		obj37 = obj;
		obj38 = obj6;
		((string[])obj37)[9] = (string)obj38;
		obj37 = obj;
		obj38 = obj6;
		((string[])obj37)[10] = (string)obj38;
		obj37 = obj;
		obj38 = obj9;
		((string[])obj37)[11] = (string)obj38;
		obj37 = obj;
		obj38 = obj35;
		((string[])obj37)[12] = (string)obj38;
		obj37 = obj;
		obj38 = obj3;
		((string[])obj37)[13] = (string)obj38;
		obj37 = obj;
		obj38 = obj2;
		((string[])obj37)[14] = (string)obj38;
		obj37 = obj;
		obj38 = obj12;
		((string[])obj37)[15] = (string)obj38;
		obj37 = obj;
		obj38 = obj8;
		((string[])obj37)[16] = (string)obj38;
		obj37 = obj;
		obj38 = obj20;
		((string[])obj37)[17] = (string)obj38;
		obj37 = obj;
		obj38 = obj25;
		((string[])obj37)[18] = (string)obj38;
		obj37 = obj;
		obj38 = obj34;
		((string[])obj37)[19] = (string)obj38;
		obj37 = obj;
		obj38 = obj11;
		((string[])obj37)[20] = (string)obj38;
		obj37 = obj;
		obj38 = obj17;
		((string[])obj37)[21] = (string)obj38;
		obj37 = obj;
		obj38 = obj25;
		((string[])obj37)[22] = (string)obj38;
		obj37 = obj;
		obj38 = obj32;
		((string[])obj37)[23] = (string)obj38;
		obj37 = obj;
		obj38 = obj12;
		((string[])obj37)[24] = (string)obj38;
		obj37 = obj;
		obj38 = obj17;
		((string[])obj37)[25] = (string)obj38;
		obj37 = obj;
		obj38 = obj28;
		((string[])obj37)[26] = (string)obj38;
		obj37 = obj;
		obj38 = obj11;
		((string[])obj37)[27] = (string)obj38;
		obj37 = obj;
		obj38 = obj2;
		((string[])obj37)[28] = (string)obj38;
		obj37 = obj;
		obj38 = obj12;
		((string[])obj37)[29] = (string)obj38;
		obj37 = obj;
		obj38 = obj8;
		((string[])obj37)[30] = (string)obj38;
		obj37 = obj;
		obj38 = obj26;
		((string[])obj37)[31] = (string)obj38;
		obj37 = obj;
		obj38 = obj2;
		((string[])obj37)[32] = (string)obj38;
		obj37 = obj;
		obj38 = obj2;
		((string[])obj37)[33] = (string)obj38;
		obj37 = obj;
		obj38 = obj10;
		((string[])obj37)[34] = (string)obj38;
		obj37 = obj;
		obj38 = obj19;
		((string[])obj37)[35] = (string)obj38;
		obj37 = obj;
		obj38 = obj14;
		((string[])obj37)[36] = (string)obj38;
		obj37 = obj;
		obj38 = obj23;
		((string[])obj37)[37] = (string)obj38;
		obj37 = obj;
		obj38 = obj24;
		((string[])obj37)[38] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[39] = (string)obj38;
		obj37 = obj;
		obj38 = obj15;
		((string[])obj37)[40] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[41] = (string)obj38;
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[42] = (string)obj38;
		obj37 = obj;
		obj38 = obj9;
		((string[])obj37)[43] = (string)obj38;
		obj37 = obj;
		obj38 = obj11;
		((string[])obj37)[44] = (string)obj38;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj40 = obj;
		num = 70;
		num = 10;
		obj = new string[10];
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[0] = (string)obj38;
		obj37 = obj;
		obj38 = obj7;
		((string[])obj37)[1] = (string)obj38;
		obj37 = obj;
		obj38 = obj18;
		((string[])obj37)[2] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[3] = (string)obj38;
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[4] = (string)obj38;
		obj37 = obj;
		obj38 = obj13;
		((string[])obj37)[5] = (string)obj38;
		obj37 = obj;
		obj38 = obj31;
		((string[])obj37)[6] = (string)obj38;
		obj37 = obj;
		obj38 = obj27;
		((string[])obj37)[7] = (string)obj38;
		obj37 = obj;
		obj38 = obj36;
		((string[])obj37)[8] = (string)obj38;
		obj37 = obj;
		obj38 = obj11;
		((string[])obj37)[9] = (string)obj38;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj41 = obj;
		num = 182;
		num = 14;
		obj = new string[14];
		obj37 = obj;
		obj38 = obj11;
		((string[])obj37)[0] = (string)obj38;
		obj37 = obj;
		obj38 = obj14;
		((string[])obj37)[1] = (string)obj38;
		obj37 = obj;
		obj38 = obj24;
		((string[])obj37)[2] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[3] = (string)obj38;
		obj37 = obj;
		obj38 = obj15;
		((string[])obj37)[4] = (string)obj38;
		obj37 = obj;
		obj38 = obj30;
		((string[])obj37)[5] = (string)obj38;
		obj37 = obj;
		obj38 = obj16;
		((string[])obj37)[6] = (string)obj38;
		obj37 = obj;
		obj38 = obj5;
		((string[])obj37)[7] = (string)obj38;
		obj37 = obj;
		obj38 = obj33;
		((string[])obj37)[8] = (string)obj38;
		obj37 = obj;
		obj38 = obj29;
		((string[])obj37)[9] = (string)obj38;
		obj37 = obj;
		obj38 = obj29;
		((string[])obj37)[10] = (string)obj38;
		obj37 = obj;
		obj38 = obj29;
		((string[])obj37)[11] = (string)obj38;
		obj37 = obj;
		obj38 = obj9;
		((string[])obj37)[12] = (string)obj38;
		obj37 = obj;
		obj38 = obj22;
		((string[])obj37)[13] = (string)obj38;
		string text4 = string.Concat((string[])obj);
		obj = text4;
		object obj42 = obj;
		try
		{
			if (PhotonNetwork.InRoom)
			{
				obj = susId;
				Player localPlayer = PhotonNetwork.LocalPlayer;
				obj37 = localPlayer;
				string userId = ((Player)obj37).UserId;
				obj37 = userId;
				if ((string)obj == (string)obj37)
				{
					num = 1;
				}
				else
				{
					obj = susId;
					obj37 = NetworkSystem.Instance;
					NetPlayer localPlayer2 = ((NetworkSystem)obj37).LocalPlayer;
					obj37 = localPlayer2;
					string userId2 = ((NetPlayer)obj37).UserId;
					obj37 = userId2;
					num = (((string)obj == (string)obj37) ? 1 : 0);
				}
			}
			else
			{
				num = 0;
			}
			if (num != 0)
			{
				if (Class156.bool_0)
				{
					num = 15;
					num = 5;
					obj = new string[5];
					obj37 = obj;
					obj38 = obj40;
					((string[])obj37)[0] = (string)obj38;
					obj37 = obj;
					obj38 = susReason;
					((string[])obj37)[1] = (string)obj38;
					obj37 = obj;
					obj38 = obj42;
					((string[])obj37)[2] = (string)obj38;
					obj37 = obj;
					obj38 = susNick;
					((string[])obj37)[3] = (string)obj38;
					obj37 = obj;
					obj38 = obj39;
					((string[])obj37)[4] = (string)obj38;
					string text5 = string.Concat((string[])obj);
					obj = text5;
					double num2 = 10.0;
					NotificationManager.smethod_0((string)obj, (float)num2);
				}
				num = 0;
				return false;
			}
			if (Class156.bool_0)
			{
				num = 20;
				num = 5;
				obj = new string[5];
				obj37 = obj;
				obj38 = obj41;
				((string[])obj37)[0] = (string)obj38;
				obj37 = obj;
				obj38 = susReason;
				((string[])obj37)[1] = (string)obj38;
				obj37 = obj;
				obj38 = obj42;
				((string[])obj37)[2] = (string)obj38;
				obj37 = obj;
				obj38 = susNick;
				((string[])obj37)[3] = (string)obj38;
				obj37 = obj;
				obj38 = obj39;
				((string[])obj37)[4] = (string)obj38;
				string text6 = string.Concat((string[])obj);
				obj = text6;
				double num2 = 5.0;
				NotificationManager.smethod_0((string)obj, (float)num2);
			}
		}
		catch
		{
			num = 0;
			return false;
		}
		num = 1;
		return true;
	}

	public Class12()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 115;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsInvalidNumberGetRuntimeProperty.GetContainingTypeLibEndOfLine);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d6:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 64;
																		while (true)
																		{
																			IL_02b3:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_02a3:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0296:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0286:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (true)
																											{
																												IL_0266:
																												if (8 <= b)
																												{
																													while (true)
																													{
																														IL_0241:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_0231:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_0218:
																																num5++;
																																num = 122;
																																while (true)
																																{
																																	if (num != 122)
																																	{
																																		if (num != 1103)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 16:
																																			goto IL_0218;
																																		case 48:
																																			goto IL_0231;
																																		case 8:
																																		case 10:
																																			goto IL_0241;
																																		case 81:
																																			goto IL_0266;
																																		case 55:
																																			goto IL_0276;
																																		case 98:
																																			goto IL_0286;
																																		case 95:
																																			goto IL_0296;
																																		case 47:
																																		case 87:
																																			goto IL_02a3;
																																		case 64:
																																			goto IL_02b3;
																																		case 77:
																																			goto IL_02c3;
																																		case 2:
																																			goto IL_02d6;
																																		case 93:
																																			goto end_IL_02d6;
																																		case 23:
																																		case 94:
																																			goto end_IL_02e6;
																																		case 42:
																																		case 46:
																																			goto IL_030f;
																																		case 26:
																																		case 86:
																																			goto IL_037c;
																																		case 83:
																																			goto IL_0387;
																																		case 78:
																																		case 90:
																																			goto IL_0395;
																																		case 97:
																																			goto IL_03b1;
																																		case 59:
																																			goto IL_03bf;
																																		case 107:
																																			goto IL_03d2;
																																		case 109:
																																			goto IL_03e5;
																																		case 20:
																																		case 80:
																																			goto IL_03f3;
																																		case 88:
																																			goto IL_0433;
																																		case 13:
																																			goto IL_0447;
																																		case 110:
																																			goto IL_0476;
																																		case 3:
																																		case 58:
																																			goto IL_0481;
																																		case 89:
																																			goto IL_04ca;
																																		case 34:
																																			goto IL_04de;
																																		case 112:
																																			goto IL_04f1;
																																		case 17:
																																		case 100:
																																			goto IL_04ff;
																																		case 67:
																																		case 91:
																																			goto end_IL_0205;
																																		case 54:
																																			goto IL_051b;
																																		case 105:
																																		case 108:
																																			goto IL_0529;
																																		case 76:
																																			goto IL_0540;
																																		case 49:
																																			goto IL_0563;
																																		case 31:
																																			goto IL_056d;
																																		case 5:
																																			goto IL_0584;
																																		case 0:
																																			goto IL_0597;
																																		case 50:
																																			goto IL_05aa;
																																		case 9:
																																		case 21:
																																			goto IL_05b8;
																																		case 75:
																																		case 111:
																																			goto IL_05c3;
																																		case 92:
																																			goto IL_05ce;
																																		case 35:
																																		case 63:
																																			goto IL_05e2;
																																		case 29:
																																			goto IL_060b;
																																		case 62:
																																			goto IL_0619;
																																		case 51:
																																			goto IL_062c;
																																		case 1:
																																		case 4:
																																		case 15:
																																		case 19:
																																		case 27:
																																		case 30:
																																		case 32:
																																		case 38:
																																		case 41:
																																		case 43:
																																		case 45:
																																		case 52:
																																		case 65:
																																		case 69:
																																		case 70:
																																		case 71:
																																		case 74:
																																		case 82:
																																		case 96:
																																		case 101:
																																		case 102:
																																		case 103:
																																			goto end_IL_0266;
																																		case 39:
																																		case 106:
																																			goto IL_0655;
																																		case 40:
																																			goto IL_066e;
																																		case 44:
																																			goto IL_067c;
																																		case 24:
																																			goto IL_068a;
																																		case 14:
																																		case 53:
																																			goto IL_069a;
																																		case 6:
																																		case 7:
																																		case 12:
																																		case 18:
																																		case 22:
																																		case 25:
																																		case 33:
																																		case 57:
																																		case 60:
																																		case 79:
																																		case 84:
																																		case 85:
																																		case 104:
																																		case 113:
																																			goto end_IL_02f6;
																																		case 37:
																																			goto end_IL_06ad;
																																		case 99:
																																			goto end_IL_06c0;
																																		case 28:
																																			goto end_IL_06ca;
																																		case 68:
																																			goto end_IL_06d5;
																																		case 36:
																																		case 72:
																																			goto end_IL_06ea;
																																		case 56:
																																			goto end_IL_06fa;
																																		case 66:
																																		case 73:
																																			goto end_IL_070a;
																																		case 114:
																																			goto end_IL_071a;
																																		case 115:
																																			goto end_IL_072a;
																																		case 11:
																																		case 61:
																																			goto IL_0745;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	num = 6;
																																	goto end_IL_02f6;
																																	continue;
																																	end_IL_0205:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_050d;
																												}
																												num = 38;
																												break;
																												continue;
																												end_IL_0266:
																												break;
																											}
																											break;
																											IL_0276:;
																										}
																										break;
																									}
																									goto IL_03e5;
																									IL_0447:
																									num5--;
																									goto end_IL_02f6;
																									IL_03e5:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_03f3;
																									IL_03f3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0433;
																									IL_0433:
																									array[num5 - 2] = 0;
																									goto IL_0447;
																								}
																								break;
																							}
																							goto IL_030f;
																							IL_03d2:
																							num5 -= 2;
																							goto end_IL_02f6;
																							IL_030f:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 107;
																							goto IL_03d2;
																						}
																						break;
																					}
																					goto IL_037c;
																					IL_03bf:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_037c:
																					if (10 >= b)
																					{
																						goto IL_0387;
																					}
																					goto IL_03b1;
																					IL_0387:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0395;
																					IL_0395:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02f6;
																					IL_03b1:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_03bf;
																				}
																				break;
																			}
																			goto IL_0476;
																			IL_067c:
																			num5++;
																			goto IL_068a;
																			IL_0476:
																			if (6 <= b)
																			{
																				goto IL_0481;
																			}
																			goto IL_04f1;
																			IL_0481:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 89;
																			goto IL_04ca;
																			IL_04ca:
																			array[num5 - 2] = 0;
																			goto IL_04de;
																			IL_04de:
																			num5--;
																			goto end_IL_02f6;
																			IL_04f1:
																			if (3 < b)
																			{
																				goto IL_04ff;
																			}
																			goto IL_05aa;
																			IL_04ff:
																			if (4 < b)
																			{
																				goto IL_050d;
																			}
																			goto IL_0597;
																			IL_050d:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_051b;
																			IL_051b:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0529;
																			IL_0529:
																			array[num5] = 0;
																			num = 76;
																			goto IL_0540;
																			IL_0540:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0563;
																			IL_0563:
																			array2[num5] = null;
																			goto IL_056d;
																			IL_056d:
																			num5++;
																			num = 5;
																			goto IL_0584;
																			IL_0584:
																			ptr2 += 8;
																			goto end_IL_02f6;
																			IL_0597:
																			if (4 <= b)
																			{
																				goto end_IL_02f6;
																			}
																			break;
																			IL_05aa:
																			if (3 > b)
																			{
																				goto IL_05b8;
																			}
																			goto IL_069a;
																			IL_05b8:
																			if (1 < b)
																			{
																				goto IL_05c3;
																			}
																			goto IL_062c;
																			IL_05c3:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_05ce;
																			IL_05ce:
																			if (2 > b)
																			{
																				break;
																			}
																			num = 35;
																			goto IL_05e2;
																			IL_068a:
																			ptr2 += 8;
																			goto end_IL_02f6;
																			IL_05e2:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_060b;
																			IL_060b:
																			ptr2 += 8;
																			goto IL_0619;
																			IL_0619:
																			num5--;
																			goto end_IL_02f6;
																			IL_062c:
																			if (1 > b)
																			{
																				num = 74;
																				break;
																			}
																			goto IL_0655;
																			IL_069a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02f6;
																			IL_0655:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_066e;
																			IL_066e:
																			array[num5] = 0;
																			goto IL_067c;
																		}
																		break;
																		IL_02c3:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f6;
																continue;
																end_IL_02d6:
																break;
															}
															continue;
															end_IL_02e6:
															break;
														}
														continue;
														end_IL_02f6:
														break;
													}
													continue;
												}
												goto IL_0745;
												IL_0745:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06ad:
												break;
											}
											continue;
											end_IL_06c0:
											break;
										}
										continue;
										end_IL_06ca:
										break;
									}
									continue;
									end_IL_06d5:
									break;
								}
								continue;
								end_IL_06ea:
								break;
							}
							continue;
							end_IL_06fa:
							break;
						}
						continue;
						end_IL_070a:
						break;
					}
					continue;
					end_IL_071a:
					break;
				}
				continue;
				end_IL_072a:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 5;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setChannelUrisNativeMethods.AltDirectorySeparatorCharPtrToStringUni);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 86;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0281:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0261:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0251:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0241:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0234:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01e6:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 113;
																													while (true)
																													{
																														if (num != 113)
																														{
																															if (num != 1094)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 36:
																															case 95:
																																goto IL_01e6;
																															case 77:
																																goto IL_0214;
																															case 48:
																															case 82:
																																goto IL_0224;
																															case 42:
																															case 73:
																																goto IL_0234;
																															case 20:
																																goto IL_0241;
																															case 29:
																															case 72:
																																goto IL_0251;
																															case 93:
																																goto IL_0261;
																															case 1:
																																goto IL_0271;
																															case 7:
																																goto IL_0281;
																															case 86:
																																goto end_IL_0281;
																															case 66:
																															case 84:
																																goto end_IL_0291;
																															case 85:
																																goto IL_02b5;
																															case 88:
																															case 90:
																																goto IL_02c3;
																															case 98:
																																goto IL_0303;
																															case 43:
																																goto IL_0317;
																															case 10:
																																goto IL_0338;
																															case 57:
																																goto IL_0346;
																															case 35:
																															case 61:
																																goto IL_0362;
																															case 8:
																																goto IL_03c4;
																															case 91:
																																goto IL_03d7;
																															case 52:
																															case 104:
																																goto IL_03e2;
																															case 47:
																																goto IL_03f0;
																															case 30:
																																goto IL_0403;
																															case 53:
																															case 92:
																																goto IL_0411;
																															case 44:
																																goto IL_042d;
																															case 4:
																															case 25:
																																goto IL_043b;
																															case 22:
																															case 27:
																																goto IL_0446;
																															case 39:
																																goto IL_0451;
																															case 96:
																															case 103:
																																goto IL_045f;
																															case 81:
																															case 94:
																																goto IL_0477;
																															case 56:
																																goto IL_048e;
																															case 76:
																																goto IL_049e;
																															case 26:
																															case 32:
																																goto IL_04a9;
																															case 101:
																																goto IL_04b4;
																															case 21:
																															case 24:
																																goto IL_04bf;
																															case 71:
																																goto IL_04d8;
																															case 11:
																																goto IL_04e6;
																															case 105:
																																goto IL_04f4;
																															case 0:
																															case 13:
																															case 28:
																															case 34:
																															case 51:
																															case 54:
																															case 60:
																															case 64:
																															case 65:
																															case 68:
																															case 74:
																															case 79:
																															case 80:
																															case 83:
																															case 89:
																															case 97:
																															case 99:
																															case 100:
																																goto end_IL_01d3;
																															case 23:
																															case 49:
																																goto IL_0528;
																															case 9:
																																goto IL_055a;
																															case 14:
																																goto IL_0568;
																															case 16:
																															case 33:
																																goto IL_0578;
																															case 58:
																																goto IL_058f;
																															case 19:
																																goto IL_05b2;
																															case 2:
																																goto IL_05bc;
																															case 75:
																																goto IL_05ca;
																															case 3:
																															case 18:
																															case 31:
																															case 55:
																															case 59:
																															case 62:
																															case 63:
																															case 67:
																															case 69:
																															case 70:
																															case 78:
																															case 87:
																															case 106:
																																goto end_IL_02a1;
																															case 102:
																																goto end_IL_05d8;
																															case 38:
																																goto end_IL_05eb;
																															case 45:
																																goto end_IL_05f5;
																															case 12:
																																goto end_IL_0600;
																															case 41:
																															case 46:
																																goto end_IL_0615;
																															case 17:
																																goto end_IL_0625;
																															case 15:
																															case 37:
																																goto end_IL_0635;
																															case 5:
																																goto end_IL_0645;
																															case 6:
																																goto end_IL_0655;
																															case 40:
																															case 50:
																																goto IL_0679;
																															}
																															continue;
																														}
																														array[num5] = 0;
																														goto IL_0338;
																														IL_0338:
																														num5++;
																														goto IL_0346;
																														IL_0346:
																														ptr2 += 8;
																														num = 78;
																														goto end_IL_02a1;
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												break;
																												IL_0214:;
																											}
																											break;
																											IL_0224:;
																										}
																										break;
																									}
																									goto IL_02b5;
																									IL_0317:
																									num5--;
																									goto end_IL_02a1;
																									IL_02b5:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_02c3;
																									IL_02c3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0303;
																									IL_0303:
																									array[num5 - 2] = 0;
																									goto IL_0317;
																								}
																								break;
																							}
																							goto IL_0362;
																							IL_03c4:
																							num5 -= 2;
																							goto end_IL_02a1;
																							IL_0362:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03c4;
																						}
																						break;
																					}
																					goto IL_03d7;
																					IL_0411:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a1;
																					IL_03d7:
																					if (9 < b)
																					{
																						goto IL_03e2;
																					}
																					goto IL_0403;
																					IL_03e2:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_03f0;
																					IL_03f0:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_0403:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0411;
																				}
																				break;
																			}
																			goto IL_042d;
																			IL_05bc:
																			num5++;
																			goto IL_05ca;
																			IL_042d:
																			if (5 > b)
																			{
																				goto IL_043b;
																			}
																			goto IL_0578;
																			IL_043b:
																			if (2 < b)
																			{
																				goto IL_0446;
																			}
																			goto IL_049e;
																			IL_0446:
																			if (3 >= b)
																			{
																				goto IL_0451;
																			}
																			goto IL_0477;
																			IL_0451:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_045f;
																			IL_045f:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02a1;
																			IL_0477:
																			if (4 < b)
																			{
																				break;
																			}
																			num = 56;
																			goto IL_048e;
																			IL_05ca:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_048e:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a1;
																			IL_049e:
																			if (2 > b)
																			{
																				goto IL_04a9;
																			}
																			goto IL_0528;
																			IL_04a9:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04b4;
																			IL_04b4:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04bf;
																			IL_04bf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04d8;
																			IL_04d8:
																			array[num5] = 0;
																			goto IL_04e6;
																			IL_04e6:
																			num5++;
																			goto IL_04f4;
																			IL_04f4:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_0528:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 9;
																			goto IL_055a;
																			IL_055a:
																			ptr2 += 8;
																			goto IL_0568;
																			IL_0568:
																			num5--;
																			goto end_IL_02a1;
																			IL_0578:
																			array[num5] = 0;
																			num = 58;
																			goto IL_058f;
																			IL_058f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05b2;
																			IL_05b2:
																			array2[num5] = null;
																			goto IL_05bc;
																		}
																		break;
																		IL_0271:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 63;
																goto end_IL_02a1;
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
														end_IL_02a1:
														break;
													}
													continue;
												}
												goto IL_0679;
												IL_0679:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d8:
												break;
											}
											continue;
											end_IL_05eb:
											break;
										}
										continue;
										end_IL_05f5:
										break;
									}
									continue;
									end_IL_0600:
									break;
								}
								continue;
								end_IL_0615:
								break;
							}
							continue;
							end_IL_0625:
							break;
						}
						continue;
						end_IL_0635:
						break;
					}
					continue;
					end_IL_0645:
					break;
				}
				continue;
				end_IL_0655:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 29;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 85;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PRIExceptionInfoMatchAnyKeyword.CompatibilitySwitchIsHighSurrogate);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02e3:
																if (b >= 1)
																{
																	num = 81;
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02c3:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02b6:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_02a6:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0296:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0266:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0241:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_0235:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_021c:
																																num5++;
																																num = 123;
																																while (true)
																																{
																																	if (num != 123)
																																	{
																																		if (num != 1104)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 5:
																																			goto IL_021c;
																																		case 52:
																																			goto IL_0235;
																																		case 38:
																																			goto IL_0241;
																																		case 8:
																																		case 111:
																																			goto IL_0266;
																																		case 99:
																																			goto IL_0276;
																																		case 24:
																																			goto IL_0286;
																																		case 17:
																																		case 97:
																																			goto IL_0296;
																																		case 43:
																																		case 112:
																																			goto IL_02a6;
																																		case 16:
																																			goto IL_02b6;
																																		case 61:
																																			goto IL_02c3;
																																		case 81:
																																			goto IL_02d3;
																																		case 45:
																																			goto IL_02e3;
																																		case 78:
																																			goto end_IL_02e3;
																																		case 54:
																																		case 93:
																																			goto end_IL_02f6;
																																		case 22:
																																		case 32:
																																			goto IL_0311;
																																		case 50:
																																			goto IL_0353;
																																		case 58:
																																			goto IL_0366;
																																		case 18:
																																			goto IL_037a;
																																		case 62:
																																			goto IL_03a0;
																																		case 66:
																																		case 74:
																																			goto IL_03ae;
																																		case 79:
																																			goto IL_03b9;
																																		case 9:
																																		case 33:
																																			goto IL_03c7;
																																		case 1:
																																			goto IL_03e0;
																																		case 101:
																																			goto IL_03ee;
																																		case 95:
																																			goto IL_03fc;
																																		case 37:
																																		case 41:
																																			goto IL_040f;
																																		case 83:
																																			goto IL_041d;
																																		case 84:
																																		case 89:
																																			goto IL_042b;
																																		case 98:
																																			goto IL_0454;
																																		case 115:
																																			goto IL_0462;
																																		case 55:
																																		case 63:
																																			goto IL_0475;
																																		case 2:
																																		case 34:
																																			goto IL_048d;
																																		case 7:
																																			goto IL_049b;
																																		case 60:
																																		case 100:
																																			goto IL_04a6;
																																		case 103:
																																			goto IL_0508;
																																		case 4:
																																		case 86:
																																			goto IL_0524;
																																		case 82:
																																			goto IL_052f;
																																		case 36:
																																		case 106:
																																			goto IL_053d;
																																		case 40:
																																			goto IL_057d;
																																		case 65:
																																			goto IL_059a;
																																		case 14:
																																			goto IL_05ad;
																																		case 30:
																																			goto IL_05bb;
																																		case 57:
																																		case 77:
																																			goto IL_05c9;
																																		case 68:
																																			goto IL_05ec;
																																		case 15:
																																			goto IL_05fa;
																																		case 72:
																																			goto IL_0608;
																																		case 91:
																																			goto IL_0618;
																																		case 64:
																																		case 92:
																																			goto IL_0623;
																																		case 13:
																																			goto IL_062e;
																																		case 67:
																																			goto IL_063b;
																																		case 3:
																																		case 107:
																																			goto IL_0646;
																																		case 0:
																																		case 6:
																																		case 25:
																																		case 39:
																																		case 42:
																																		case 44:
																																		case 47:
																																		case 48:
																																		case 51:
																																		case 53:
																																		case 56:
																																		case 59:
																																		case 69:
																																		case 70:
																																		case 71:
																																		case 87:
																																		case 90:
																																		case 96:
																																		case 104:
																																		case 108:
																																		case 110:
																																		case 114:
																																			goto end_IL_0209;
																																		case 10:
																																		case 11:
																																		case 12:
																																		case 20:
																																		case 23:
																																		case 26:
																																		case 27:
																																		case 31:
																																		case 35:
																																		case 46:
																																		case 49:
																																		case 80:
																																		case 88:
																																		case 105:
																																			goto end_IL_0306;
																																		case 109:
																																			goto end_IL_067b;
																																		case 75:
																																			goto end_IL_068e;
																																		case 73:
																																			goto end_IL_0698;
																																		case 76:
																																			goto end_IL_06a3;
																																		case 94:
																																		case 116:
																																			goto end_IL_06b8;
																																		case 85:
																																			goto end_IL_06c8;
																																		case 19:
																																		case 21:
																																			goto end_IL_06d8;
																																		case 28:
																																			goto end_IL_06e8;
																																		case 29:
																																			goto end_IL_0701;
																																		case 102:
																																		case 113:
																																			goto IL_071c;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_0306;
																																	continue;
																																	end_IL_0209:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																												IL_0276:;
																											}
																											break;
																											IL_0286:;
																										}
																										break;
																									}
																									goto IL_0353;
																									IL_0353:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_0306;
																								}
																								break;
																							}
																							goto IL_03a0;
																							IL_0475:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0306;
																							IL_03a0:
																							if (3 > b)
																							{
																								goto IL_03ae;
																							}
																							goto IL_0475;
																							IL_03ae:
																							if (1 >= b)
																							{
																								goto IL_03b9;
																							}
																							goto IL_040f;
																							IL_03b9:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_03c7;
																							IL_03c7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03e0;
																							IL_03e0:
																							array[num5] = 0;
																							goto IL_03ee;
																							IL_03ee:
																							num5++;
																							goto IL_03fc;
																							IL_03fc:
																							ptr2 += 8;
																							goto end_IL_0306;
																							IL_040f:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_041d;
																							IL_041d:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_042b;
																							IL_042b:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0454;
																							IL_0454:
																							ptr2 += 8;
																							goto IL_0462;
																							IL_0462:
																							num5--;
																							goto end_IL_0306;
																						}
																						break;
																					}
																					goto IL_0311;
																					IL_037a:
																					num5--;
																					goto end_IL_0306;
																					IL_0311:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0366;
																					IL_0366:
																					array[num5 - 2] = 0;
																					goto IL_037a;
																				}
																				break;
																			}
																			goto IL_048d;
																			IL_063b:
																			if (10 > b)
																			{
																				num = 69;
																				break;
																			}
																			goto IL_0646;
																			IL_048d:
																			if (9 >= b)
																			{
																				goto IL_049b;
																			}
																			goto IL_0618;
																			IL_049b:
																			if (9 <= b)
																			{
																				goto IL_04a6;
																			}
																			num = 4;
																			goto IL_0524;
																			IL_04a6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0508;
																			IL_0508:
																			num5 -= 2;
																			goto end_IL_0306;
																			IL_0646:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0306;
																			IL_0524:
																			if (7 >= b)
																			{
																				goto IL_052f;
																			}
																			goto IL_05ad;
																			IL_052f:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_053d;
																			IL_053d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_057d;
																			IL_057d:
																			array[num5 - 2] = 0;
																			num = 65;
																			goto IL_059a;
																			IL_059a:
																			num5--;
																			goto end_IL_0306;
																			IL_05ad:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_05bb;
																			IL_05bb:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05c9;
																			IL_05c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05ec;
																			IL_05ec:
																			array[num5] = 0;
																			goto IL_05fa;
																			IL_05fa:
																			num5++;
																			goto IL_0608;
																			IL_0608:
																			ptr2 += 8;
																			goto end_IL_0306;
																			IL_0618:
																			if (10 < b)
																			{
																				goto IL_0623;
																			}
																			goto IL_063b;
																			IL_0623:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_062e;
																			IL_062e:
																			if (11 <= b)
																			{
																			}
																			break;
																		}
																		break;
																		IL_02d3:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0306;
																continue;
																end_IL_02e3:
																break;
															}
															continue;
															end_IL_02f6:
															break;
														}
														continue;
														end_IL_0306:
														break;
													}
													continue;
												}
												goto IL_071c;
												IL_071c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067b:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_0698:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 77;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenRestrictedDeviceClaimAttributesQuerySource.ReadSubTreesetNoPrompt);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 10;
																while (true)
																{
																	IL_01a9:
																	if (b >= 1)
																	{
																		num = 95;
																		while (true)
																		{
																			if (num != 95)
																			{
																				if (num != 1076)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 10:
																					goto IL_01a9;
																				case 39:
																					goto end_IL_01a9;
																				case 15:
																				case 83:
																					goto end_IL_01bc;
																				case 65:
																					goto IL_01ee;
																				case 19:
																					goto IL_01fc;
																				case 11:
																				case 74:
																					goto IL_0207;
																				case 1:
																					goto IL_0230;
																				case 70:
																					goto IL_023e;
																				case 52:
																					goto IL_0251;
																				case 25:
																					goto IL_025f;
																				case 35:
																				case 82:
																					goto IL_026a;
																				case 72:
																					goto IL_0278;
																				case 62:
																				case 73:
																					goto IL_028b;
																				case 5:
																					goto IL_02f9;
																				case 3:
																					goto IL_030c;
																				case 36:
																					goto IL_031a;
																				case 37:
																				case 88:
																					goto IL_0328;
																				case 53:
																					goto IL_0368;
																				case 41:
																					goto IL_037c;
																				case 54:
																					goto IL_038f;
																				case 43:
																				case 51:
																					goto IL_039d;
																				case 57:
																				case 60:
																					goto IL_03a8;
																				case 47:
																					goto IL_03b6;
																				case 16:
																				case 27:
																					goto IL_03c4;
																				case 23:
																					goto IL_03e0;
																				case 12:
																				case 17:
																					goto IL_03ee;
																				case 68:
																					goto IL_03fc;
																				case 40:
																					goto IL_041f;
																				case 58:
																					goto IL_0429;
																				case 6:
																					goto IL_0437;
																				case 29:
																					goto IL_044a;
																				case 22:
																					goto IL_0458;
																				case 59:
																					goto IL_0463;
																				case 33:
																				case 71:
																					goto IL_046e;
																				case 7:
																				case 9:
																				case 21:
																				case 26:
																				case 31:
																				case 42:
																				case 44:
																				case 45:
																				case 46:
																				case 48:
																				case 61:
																				case 66:
																				case 67:
																				case 76:
																				case 81:
																				case 86:
																				case 87:
																					goto end_IL_0199;
																				case 38:
																					goto IL_04af;
																				case 79:
																					goto IL_04bd;
																				case 80:
																					goto IL_04cb;
																				case 0:
																				case 2:
																				case 8:
																				case 13:
																				case 18:
																				case 20:
																				case 24:
																				case 28:
																				case 69:
																				case 75:
																				case 78:
																					goto end_IL_01d5;
																				case 84:
																					goto end_IL_04d9;
																				case 63:
																					goto end_IL_04ec;
																				case 64:
																					goto end_IL_04f6;
																				case 14:
																					goto end_IL_0501;
																				case 77:
																					goto end_IL_0516;
																				case 34:
																				case 49:
																					goto end_IL_052b;
																				case 4:
																					goto end_IL_053b;
																				case 30:
																				case 32:
																					goto end_IL_0554;
																				case 55:
																					goto end_IL_0564;
																				case 56:
																					goto end_IL_0574;
																				case 50:
																				case 85:
																					goto IL_058f;
																				}
																				continue;
																			}
																			if (b > 8)
																			{
																				break;
																			}
																			goto IL_01ee;
																			IL_0458:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0463;
																			IL_046e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 28;
																			goto end_IL_01d5;
																			IL_0463:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_046e;
																			IL_01ee:
																			if (4 >= b)
																			{
																				goto IL_01fc;
																			}
																			goto IL_038f;
																			IL_01fc:
																			if (4 <= b)
																			{
																				goto IL_0207;
																			}
																			goto IL_0251;
																			IL_0207:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0230;
																			IL_0230:
																			ptr2 += 8;
																			goto IL_023e;
																			IL_023e:
																			num5--;
																			goto end_IL_01d5;
																			IL_0251:
																			if (2 >= b)
																			{
																				goto IL_025f;
																			}
																			goto IL_030c;
																			IL_025f:
																			if (2 > b)
																			{
																				goto IL_026a;
																			}
																			goto IL_028b;
																			IL_026a:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0278;
																			IL_0278:
																			if (1 <= b)
																			{
																			}
																			break;
																			IL_028b:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_02f9;
																			IL_02f9:
																			num5 -= 2;
																			goto end_IL_01d5;
																			IL_030c:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_031a;
																			IL_031a:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0328;
																			IL_0328:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0368;
																			IL_0368:
																			array[num5 - 2] = 0;
																			goto IL_037c;
																			IL_037c:
																			num5--;
																			goto end_IL_01d5;
																			IL_038f:
																			if (6 < b)
																			{
																				goto IL_039d;
																			}
																			goto IL_044a;
																			IL_039d:
																			if (7 < b)
																			{
																				goto IL_03a8;
																			}
																			goto IL_03e0;
																			IL_03a8:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03b6;
																			IL_03b6:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03c4;
																			IL_03c4:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_01d5;
																			IL_03e0:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_03ee;
																			IL_03ee:
																			array[num5] = 0;
																			goto IL_03fc;
																			IL_03fc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_041f;
																			IL_041f:
																			array2[num5] = null;
																			goto IL_0429;
																			IL_0429:
																			num5++;
																			goto IL_0437;
																			IL_0437:
																			ptr2 += 8;
																			goto end_IL_01d5;
																			IL_044a:
																			if (6 <= b)
																			{
																				goto end_IL_01d5;
																			}
																			goto IL_0458;
																			continue;
																			end_IL_0199:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04af;
																	IL_04bd:
																	num5++;
																	goto IL_04cb;
																	IL_04cb:
																	ptr2 += 8;
																	goto end_IL_01d5;
																	IL_04af:
																	array[num5] = 0;
																	goto IL_04bd;
																	continue;
																	end_IL_01a9:
																	break;
																}
																continue;
																end_IL_01bc:
																break;
															}
															continue;
															end_IL_01d5:
															break;
														}
														continue;
													}
													goto IL_058f;
													IL_058f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d9:
													break;
												}
												continue;
												end_IL_04ec:
												break;
											}
											continue;
											end_IL_04f6:
											break;
										}
										continue;
										end_IL_0501:
										break;
									}
									continue;
									end_IL_0516:
									break;
								}
								continue;
								end_IL_052b:
								break;
							}
							continue;
							end_IL_053b:
							break;
						}
						continue;
						end_IL_0554:
						break;
					}
					continue;
					end_IL_0564:
					break;
				}
				continue;
				end_IL_0574:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 48;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DoesDefinitionMatchReferenceIncludeMissing.EventInfoIOCompletionCallback);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 36;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 53;
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0270:
																			if (b >= 1)
																			{
																				while (b <= 11)
																				{
																					while (true)
																					{
																						IL_0250:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_0240:
																								if (9 >= b)
																								{
																									while (true)
																									{
																										IL_0230:
																										if (9 > b)
																										{
																											while (true)
																											{
																												IL_0223:
																												if (7 < b)
																												{
																													while (8 >= b)
																													{
																														num = 120;
																														while (true)
																														{
																															if (num != 120)
																															{
																																if (num != 1101)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 16:
																																	goto IL_0210;
																																case 79:
																																case 87:
																																	goto IL_0223;
																																case 66:
																																	goto IL_0230;
																																case 47:
																																case 92:
																																	goto IL_0240;
																																case 97:
																																	goto IL_0250;
																																case 29:
																																	goto IL_0260;
																																case 17:
																																	goto IL_0270;
																																case 65:
																																	goto end_IL_0270;
																																case 53:
																																	goto end_IL_0280;
																																case 44:
																																	goto end_IL_0290;
																																case 19:
																																	goto IL_02a6;
																																case 14:
																																case 43:
																																	goto IL_02b4;
																																case 32:
																																case 73:
																																	goto IL_02f6;
																																case 41:
																																	goto IL_0301;
																																case 0:
																																	goto IL_0311;
																																case 33:
																																	goto IL_031f;
																																case 72:
																																case 94:
																																	goto IL_0332;
																																case 106:
																																	goto IL_034e;
																																case 7:
																																	goto end_IL_01fd;
																																case 27:
																																case 57:
																																	goto IL_0383;
																																case 68:
																																	goto IL_03a6;
																																case 103:
																																	goto IL_03b4;
																																case 26:
																																	goto IL_03c2;
																																case 22:
																																case 40:
																																	goto IL_03d5;
																																case 64:
																																	goto IL_0437;
																																case 11:
																																	goto IL_0453;
																																case 50:
																																case 110:
																																	goto IL_045e;
																																case 107:
																																	goto IL_049e;
																																case 112:
																																	goto IL_04b2;
																																case 2:
																																	goto IL_04c5;
																																case 54:
																																	goto IL_04d3;
																																case 31:
																																case 111:
																																	goto IL_04de;
																																case 67:
																																	goto IL_04f6;
																																case 76:
																																case 78:
																																	goto IL_0501;
																																case 20:
																																	goto IL_050f;
																																case 34:
																																case 52:
																																	goto IL_051d;
																																case 10:
																																	goto IL_0546;
																																case 101:
																																	goto IL_0554;
																																case 100:
																																	goto IL_0570;
																																case 88:
																																case 89:
																																	goto IL_057e;
																																case 83:
																																	goto IL_0597;
																																case 15:
																																	goto IL_05a5;
																																case 84:
																																	goto IL_05b3;
																																case 95:
																																	goto IL_05cf;
																																case 21:
																																case 91:
																																	goto IL_05da;
																																case 74:
																																	goto IL_05e5;
																																case 51:
																																case 90:
																																	goto IL_05f0;
																																case 5:
																																	goto IL_05fe;
																																case 98:
																																	goto IL_0621;
																																case 77:
																																	goto IL_062b;
																																case 24:
																																	goto IL_0639;
																																case 82:
																																	goto IL_0649;
																																case 1:
																																case 3:
																																case 6:
																																case 8:
																																case 9:
																																case 12:
																																case 18:
																																case 28:
																																case 35:
																																case 37:
																																case 49:
																																case 55:
																																case 59:
																																case 60:
																																case 61:
																																case 62:
																																case 75:
																																case 80:
																																case 81:
																																case 86:
																																case 109:
																																	goto end_IL_0210;
																																case 23:
																																case 25:
																																case 30:
																																case 36:
																																case 42:
																																case 45:
																																case 58:
																																case 63:
																																case 69:
																																case 93:
																																case 96:
																																case 99:
																																case 104:
																																	goto end_IL_029b;
																																case 105:
																																	goto end_IL_0672;
																																case 85:
																																	goto end_IL_0685;
																																case 4:
																																	goto end_IL_0690;
																																case 102:
																																	goto end_IL_069a;
																																case 46:
																																	goto end_IL_06a5;
																																case 13:
																																case 113:
																																	goto end_IL_06ba;
																																case 70:
																																	goto end_IL_06ca;
																																case 48:
																																	goto end_IL_06da;
																																case 56:
																																	goto end_IL_06ea;
																																case 38:
																																	goto end_IL_06fa;
																																case 39:
																																	goto end_IL_0705;
																																case 71:
																																case 108:
																																	goto IL_0720;
																																}
																																continue;
																															}
																															if (8 > b)
																															{
																																goto end_IL_0210;
																															}
																															goto IL_0383;
																															IL_03a6:
																															array[num5] = 0;
																															goto IL_03b4;
																															IL_03c2:
																															ptr2 += 8;
																															goto end_IL_029b;
																															IL_03b4:
																															num5++;
																															goto IL_03c2;
																															IL_0383:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_03a6;
																															continue;
																															end_IL_01fd:
																															break;
																														}
																														goto IL_0362;
																														continue;
																														end_IL_0210:
																														break;
																														IL_0210:;
																													}
																													break;
																												}
																												goto IL_02a6;
																												IL_0362:
																												num5--;
																												goto end_IL_029b;
																												IL_02a6:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_02b4;
																												IL_02b4:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_034e;
																												IL_034e:
																												array[num5 - 2] = 0;
																												goto IL_0362;
																											}
																											break;
																										}
																										goto IL_03d5;
																										IL_0437:
																										num5 -= 2;
																										num = 23;
																										goto end_IL_029b;
																										IL_03d5:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0437;
																									}
																									break;
																								}
																								goto IL_02f6;
																								IL_031f:
																								if (11 > b)
																								{
																								}
																								break;
																								IL_02f6:
																								if (10 >= b)
																								{
																									goto IL_0301;
																								}
																								goto IL_0311;
																								IL_0301:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0332;
																								IL_0332:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_029b;
																								IL_0311:
																								if (11 < b)
																								{
																									break;
																								}
																								goto IL_031f;
																							}
																							break;
																						}
																						goto IL_0453;
																						IL_0649:
																						if (4 <= b)
																						{
																							goto end_IL_029b;
																						}
																						break;
																						IL_0453:
																						if (6 <= b)
																						{
																							goto IL_045e;
																						}
																						goto IL_04c5;
																						IL_045e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_049e;
																						IL_049e:
																						array[num5 - 2] = 0;
																						goto IL_04b2;
																						IL_04b2:
																						num5--;
																						goto end_IL_029b;
																						IL_04c5:
																						if (3 >= b)
																						{
																							goto IL_04d3;
																						}
																						goto IL_05cf;
																						IL_04d3:
																						if (3 <= b)
																						{
																							goto IL_04de;
																						}
																						goto IL_04f6;
																						IL_04de:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_029b;
																						IL_04f6:
																						if (1 < b)
																						{
																							goto IL_0501;
																						}
																						goto IL_0570;
																						IL_0501:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_050f;
																						IL_050f:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_051d;
																						IL_051d:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0546;
																						IL_0546:
																						ptr2 += 8;
																						goto IL_0554;
																						IL_0554:
																						num5--;
																						num = 69;
																						goto end_IL_029b;
																						IL_0570:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_057e;
																						IL_057e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0597;
																						IL_0597:
																						array[num5] = 0;
																						goto IL_05a5;
																						IL_05a5:
																						num5++;
																						goto IL_05b3;
																						IL_05b3:
																						ptr2 += 8;
																						num = 30;
																						goto end_IL_029b;
																						IL_05cf:
																						if (4 < b)
																						{
																							goto IL_05da;
																						}
																						goto IL_0649;
																						IL_05da:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_05e5;
																						IL_05e5:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_05f0;
																						IL_05f0:
																						array[num5] = 0;
																						goto IL_05fe;
																						IL_05fe:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0621;
																						IL_0621:
																						array2[num5] = null;
																						goto IL_062b;
																						IL_062b:
																						num5++;
																						goto IL_0639;
																						IL_0639:
																						ptr2 += 8;
																						goto end_IL_029b;
																					}
																					break;
																					IL_0260:;
																				}
																			}
																			else
																			{
																				num = 18;
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_029b;
																			continue;
																			end_IL_0270:
																			break;
																		}
																		continue;
																		end_IL_0280:
																		break;
																	}
																	continue;
																	end_IL_0290:
																	break;
																}
																continue;
																end_IL_029b:
																break;
															}
															continue;
														}
														goto IL_0720;
														IL_0720:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0672:
														break;
													}
													continue;
													end_IL_0685:
													break;
												}
												continue;
												end_IL_0690:
												break;
											}
											continue;
											end_IL_069a:
											break;
										}
										continue;
										end_IL_06a5:
										break;
									}
									continue;
									end_IL_06ba:
									break;
								}
								continue;
								end_IL_06ca:
								break;
							}
							continue;
							end_IL_06da:
							break;
						}
						continue;
						end_IL_06ea:
						break;
					}
					continue;
					end_IL_06fa:
					break;
				}
				continue;
				end_IL_0705:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 55;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetHashFromAssemblyFilegetHashName.TaskExceptionHolderStringSection);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_065a:
													if (num4 != 1)
													{
														goto IL_000e;
													}
													num = 112;
													while (true)
													{
														if (num != 112)
														{
															if (num != 1093)
															{
																break;
															}
															switch (num)
															{
															case 27:
															case 49:
																break;
															case 68:
																goto IL_0017;
															case 34:
																goto IL_0025;
															case 33:
																goto end_IL_0647;
															case 32:
																goto IL_0053;
															case 60:
																goto IL_0061;
															case 16:
															case 82:
																goto IL_006f;
															case 24:
																goto IL_007d;
															case 46:
															case 70:
																goto IL_0088;
															case 80:
																goto IL_0096;
															case 15:
															case 85:
																goto IL_00a9;
															case 47:
																goto IL_00e9;
															case 38:
																goto IL_0106;
															case 6:
															case 99:
																goto IL_0119;
															case 61:
																goto IL_0124;
															case 12:
															case 97:
																goto IL_0132;
															case 8:
																goto IL_015b;
															case 31:
																goto IL_0169;
															case 3:
																goto IL_017c;
															case 7:
																goto IL_018a;
															case 51:
															case 89:
																goto IL_0198;
															case 48:
																goto IL_01d8;
															case 77:
																goto IL_01f5;
															case 83:
															case 96:
																goto IL_0208;
															case 62:
																goto IL_0216;
															case 0:
																goto IL_0239;
															case 66:
																goto IL_024c;
															case 23:
																goto IL_025a;
															case 53:
																goto IL_026d;
															case 72:
															case 75:
																goto IL_027b;
															case 22:
																goto IL_0286;
															case 26:
															case 88:
																goto IL_0294;
															case 14:
																goto IL_02d4;
															case 92:
																goto IL_02e8;
															case 56:
																goto IL_02fb;
															case 21:
																goto IL_0309;
															case 29:
															case 41:
																goto IL_0317;
															case 11:
																goto IL_0333;
															case 20:
															case 65:
																goto IL_034a;
															case 2:
																goto IL_0355;
															case 19:
															case 45:
																goto IL_0363;
															case 57:
																goto IL_03a3;
															case 74:
																goto IL_03b7;
															case 4:
															case 18:
																goto IL_03d5;
															case 79:
																goto IL_03ee;
															case 43:
																goto IL_0405;
															case 101:
																goto IL_0413;
															case 1:
															case 13:
															case 30:
															case 35:
															case 36:
															case 37:
															case 40:
															case 44:
															case 50:
															case 64:
															case 69:
															case 73:
															case 86:
															case 91:
															case 98:
															case 100:
															case 102:
															case 105:
																goto IL_0426;
															case 63:
																goto IL_0449;
															case 103:
																goto IL_0457;
															case 17:
																goto IL_0465;
															default:
																continue;
															case 5:
															case 39:
															case 42:
															case 52:
															case 67:
															case 76:
															case 78:
															case 81:
															case 84:
															case 90:
															case 93:
																goto IL_065a;
															case 10:
																goto end_IL_065a;
															case 28:
																goto end_IL_066d;
															case 104:
																goto end_IL_0677;
															case 94:
																goto end_IL_0682;
															case 95:
																goto end_IL_0697;
															case 9:
															case 25:
																goto end_IL_06ac;
															case 71:
																goto end_IL_06bc;
															case 58:
															case 59:
																goto end_IL_06cc;
															case 54:
																goto end_IL_06dc;
															case 55:
																goto end_IL_06ec;
															case 87:
																goto IL_0707;
															}
															goto IL_000e;
														}
														goto IL_0707;
														IL_0707:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0647:
														break;
													}
													goto IL_003c;
													IL_0405:
													num5++;
													goto IL_0413;
													IL_0413:
													ptr2 += 8;
													continue;
													IL_000e:
													b = *ptr2;
													goto IL_0017;
													IL_0017:
													ptr2++;
													goto IL_0025;
													IL_0025:
													if (b >= 1)
													{
														num = 33;
														goto IL_003c;
													}
													goto IL_0426;
													IL_0426:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0449;
													IL_003c:
													if (b <= 9)
													{
														num = 32;
														goto IL_0053;
													}
													goto IL_0426;
													IL_0449:
													array[num5] = 0;
													goto IL_0457;
													IL_0053:
													if (5 >= b)
													{
														goto IL_0061;
													}
													goto IL_026d;
													IL_0061:
													if (5 > b)
													{
														goto IL_006f;
													}
													goto IL_0208;
													IL_006f:
													if (2 >= b)
													{
														goto IL_007d;
													}
													goto IL_0119;
													IL_007d:
													if (2 > b)
													{
														goto IL_0088;
													}
													goto IL_00a9;
													IL_0088:
													if (1 >= b)
													{
														goto IL_0096;
													}
													goto IL_0426;
													IL_0096:
													if (1 > b)
													{
													}
													goto IL_0426;
													IL_00a9:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_00e9;
													IL_00e9:
													array[num5 - 2] = 0;
													num = 38;
													goto IL_0106;
													IL_0106:
													num5--;
													continue;
													IL_0119:
													if (3 >= b)
													{
														goto IL_0124;
													}
													goto IL_017c;
													IL_0124:
													if (3 <= b)
													{
														goto IL_0132;
													}
													goto IL_0426;
													IL_0132:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_015b;
													IL_015b:
													ptr2 += 8;
													goto IL_0169;
													IL_0169:
													num5--;
													continue;
													IL_017c:
													if (4 >= b)
													{
														goto IL_018a;
													}
													goto IL_0426;
													IL_018a:
													if (4 <= b)
													{
														goto IL_0198;
													}
													goto IL_0426;
													IL_0198:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_01d8;
													IL_01d8:
													array[num5 - 2] = 0;
													num = 77;
													goto IL_01f5;
													IL_01f5:
													num5--;
													continue;
													IL_0208:
													array[num5] = 0;
													goto IL_0216;
													IL_0216:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0239;
													IL_0239:
													array2[num5] = null;
													num = 66;
													goto IL_024c;
													IL_024c:
													num5++;
													goto IL_025a;
													IL_025a:
													ptr2 += 8;
													continue;
													IL_026d:
													if (7 < b)
													{
														goto IL_027b;
													}
													goto IL_0333;
													IL_027b:
													if (8 >= b)
													{
														goto IL_0286;
													}
													goto IL_02fb;
													IL_0286:
													if (8 <= b)
													{
														goto IL_0294;
													}
													goto IL_0426;
													IL_0294:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_02d4;
													IL_02d4:
													array[num5 - 2] = 0;
													goto IL_02e8;
													IL_02e8:
													num5--;
													continue;
													IL_02fb:
													if (9 >= b)
													{
														goto IL_0309;
													}
													goto IL_0426;
													IL_0309:
													if (9 <= b)
													{
														goto IL_0317;
													}
													goto IL_0426;
													IL_0317:
													byte* num6 = ptr2;
													num4 = 1;
													ptr2 = num6 + -200;
													continue;
													IL_0333:
													if (7 > b)
													{
														num = 20;
														goto IL_034a;
													}
													goto IL_03d5;
													IL_0457:
													num5++;
													goto IL_0465;
													IL_034a:
													if (6 >= b)
													{
														goto IL_0355;
													}
													num = 91;
													goto IL_0426;
													IL_0355:
													if (6 <= b)
													{
														goto IL_0363;
													}
													goto IL_0426;
													IL_0363:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_03a3;
													IL_03a3:
													array[num5 - 2] = 0;
													goto IL_03b7;
													IL_03b7:
													num5--;
													continue;
													IL_0465:
													ptr2 += 8;
													continue;
													IL_03d5:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
													goto IL_03ee;
													IL_03ee:
													array[num5] = 0;
													num = 43;
													goto IL_0405;
													continue;
													end_IL_065a:
													break;
												}
												continue;
												end_IL_066d:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_0682:
										break;
									}
									continue;
									end_IL_0697:
									break;
								}
								continue;
								end_IL_06ac:
								break;
							}
							continue;
							end_IL_06bc:
							break;
						}
						continue;
						end_IL_06cc:
						break;
					}
					continue;
					end_IL_06dc:
					break;
				}
				continue;
				end_IL_06ec:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 55;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DoFixupsgetDynamicBase.ShortInlineRNonVersionableAttribute);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0204:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e4:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01d7:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01c7:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										while (true)
																										{
																											IL_019e:
																											array[num5] = 0;
																											num = 95;
																											while (true)
																											{
																												if (num != 95)
																												{
																													if (num != 1076)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 56:
																													case 62:
																														goto IL_019e;
																													case 66:
																														goto IL_01b7;
																													case 53:
																														goto IL_01c7;
																													case 15:
																													case 23:
																														goto IL_01d7;
																													case 14:
																														goto IL_01e4;
																													case 8:
																														goto IL_01f4;
																													case 13:
																														goto IL_0204;
																													case 37:
																														goto end_IL_0204;
																													case 17:
																													case 24:
																														goto end_IL_0214;
																													case 63:
																														goto IL_022f;
																													case 57:
																													case 77:
																														goto IL_023d;
																													case 64:
																														goto IL_024b;
																													case 9:
																													case 38:
																														goto IL_0259;
																													case 39:
																														goto IL_0294;
																													case 75:
																														goto IL_02a7;
																													case 2:
																														goto IL_02be;
																													case 73:
																													case 82:
																														goto IL_02da;
																													case 22:
																														goto IL_02e8;
																													case 67:
																													case 80:
																														goto IL_02f6;
																													case 44:
																														goto IL_0312;
																													case 3:
																													case 19:
																														goto IL_0320;
																													case 32:
																													case 50:
																														goto IL_032e;
																													case 27:
																														goto IL_0345;
																													case 42:
																													case 71:
																														goto IL_0353;
																													case 60:
																														goto IL_0393;
																													case 47:
																														goto IL_03a7;
																													case 1:
																														goto IL_03ba;
																													case 34:
																													case 49:
																														goto IL_03c5;
																													case 76:
																														goto IL_03d3;
																													case 21:
																													case 65:
																														goto IL_03e6;
																													case 51:
																														goto IL_0454;
																													case 69:
																													case 81:
																														goto IL_0467;
																													case 43:
																														goto IL_0490;
																													case 83:
																														goto IL_049e;
																													case 4:
																													case 10:
																													case 11:
																													case 18:
																													case 29:
																													case 31:
																													case 36:
																													case 41:
																													case 48:
																													case 59:
																													case 68:
																													case 78:
																													case 79:
																													case 85:
																														goto end_IL_018b;
																													case 74:
																														goto IL_04d1;
																													case 7:
																														goto IL_04df;
																													case 35:
																														goto IL_04ed;
																													case 0:
																													case 5:
																													case 25:
																													case 30:
																													case 33:
																													case 40:
																													case 45:
																													case 52:
																													case 72:
																													case 84:
																													case 88:
																														goto end_IL_0224;
																													case 26:
																														goto end_IL_04fb;
																													case 87:
																														goto end_IL_050e;
																													case 61:
																														goto end_IL_0518;
																													case 86:
																														goto end_IL_0523;
																													case 58:
																														goto end_IL_0538;
																													case 12:
																													case 46:
																														goto end_IL_054d;
																													case 70:
																														goto end_IL_055d;
																													case 16:
																													case 20:
																														goto end_IL_056d;
																													case 54:
																														goto end_IL_057d;
																													case 55:
																														goto end_IL_058d;
																													case 6:
																													case 28:
																														goto IL_05b1;
																													}
																													continue;
																												}
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0294;
																												IL_0294:
																												array2[num5] = null;
																												num = 75;
																												goto IL_02a7;
																												IL_02be:
																												ptr2 += 8;
																												goto end_IL_0224;
																												IL_02a7:
																												num5++;
																												num = 2;
																												goto IL_02be;
																												continue;
																												end_IL_018b:
																												break;
																											}
																											break;
																										}
																										break;
																										IL_01b7:;
																									}
																									break;
																								}
																								num = 82;
																								goto IL_02da;
																								IL_02e8:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02f6;
																								IL_02f6:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0224;
																								IL_02da:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_02e8;
																							}
																							break;
																						}
																						goto IL_022f;
																						IL_0259:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0224;
																						IL_022f:
																						if (6 <= b)
																						{
																							goto end_IL_0224;
																						}
																						goto IL_023d;
																						IL_023d:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_024b;
																						IL_024b:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0259;
																					}
																					break;
																				}
																				goto IL_0312;
																				IL_0490:
																				ptr2 += 8;
																				goto IL_049e;
																				IL_0312:
																				if (4 > b)
																				{
																					goto IL_0320;
																				}
																				goto IL_0467;
																				IL_0320:
																				if (2 < b)
																				{
																					goto IL_032e;
																				}
																				goto IL_03ba;
																				IL_032e:
																				if (3 < b)
																				{
																					break;
																				}
																				num = 27;
																				goto IL_0345;
																				IL_049e:
																				num5--;
																				goto end_IL_0224;
																				IL_0345:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0353;
																				IL_0353:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0393;
																				IL_0393:
																				array[num5 - 2] = 0;
																				goto IL_03a7;
																				IL_03a7:
																				num5--;
																				goto end_IL_0224;
																				IL_03ba:
																				if (2 > b)
																				{
																					goto IL_03c5;
																				}
																				goto IL_03e6;
																				IL_03c5:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03d3;
																				IL_03d3:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_03e6:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0454;
																				IL_0454:
																				num5 -= 2;
																				goto end_IL_0224;
																				IL_0467:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0490;
																			}
																			break;
																			IL_01f4:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d1;
																	IL_04ed:
																	ptr2 += 8;
																	goto end_IL_0224;
																	IL_04df:
																	num5++;
																	goto IL_04ed;
																	IL_04d1:
																	array[num5] = 0;
																	goto IL_04df;
																	continue;
																	end_IL_0204:
																	break;
																}
																continue;
																end_IL_0214:
																break;
															}
															continue;
															end_IL_0224:
															break;
														}
														continue;
													}
													num = 6;
													goto IL_05b1;
													IL_05b1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04fb:
													break;
												}
												continue;
												end_IL_050e:
												break;
											}
											continue;
											end_IL_0518:
											break;
										}
										continue;
										end_IL_0523:
										break;
									}
									continue;
									end_IL_0538:
									break;
								}
								continue;
								end_IL_054d:
								break;
							}
							continue;
							end_IL_055d:
							break;
						}
						continue;
						end_IL_056d:
						break;
					}
					continue;
					end_IL_057d:
					break;
				}
				continue;
				end_IL_058d:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									IL_09d0:
									object[] array5 = new object[1];
									num = 41;
									while (true)
									{
										IL_09c5:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UCOMIExpandoNetworkShortcuts.BuiltinPerformanceLoggingUsersSidstate);
										while (true)
										{
											IL_09bb:
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03bc:
														byte b = *ptr2;
														while (true)
														{
															IL_03ac:
															ptr2++;
															while (true)
															{
																IL_039c:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_037f:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_035f:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_034f:
																								if (4 > b)
																								{
																									while (true)
																									{
																										IL_033f:
																										if (2 >= b)
																										{
																											while (true)
																											{
																												IL_032f:
																												if (2 <= b)
																												{
																													while (true)
																													{
																														IL_02ed:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														while (true)
																														{
																															IL_02ce:
																															array[num5 - 2] = 0;
																															num = 171;
																															while (true)
																															{
																																if (num != 171)
																																{
																																	if (num != 1152)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 0:
																																		goto IL_02ce;
																																	case 85:
																																	case 100:
																																		goto IL_02ed;
																																	case 67:
																																		goto IL_032f;
																																	case 62:
																																	case 150:
																																		goto IL_033f;
																																	case 57:
																																		goto IL_034f;
																																	case 38:
																																	case 53:
																																		goto IL_035f;
																																	case 122:
																																		goto IL_036f;
																																	case 71:
																																		goto IL_037f;
																																	case 96:
																																		goto IL_038c;
																																	case 149:
																																		goto IL_039c;
																																	case 93:
																																		goto IL_03ac;
																																	case 14:
																																	case 30:
																																		goto IL_03bc;
																																	case 21:
																																	case 107:
																																		goto IL_03c7;
																																	case 81:
																																		goto IL_03d5;
																																	case 34:
																																	case 84:
																																		goto IL_03e0;
																																	case 13:
																																		goto IL_03ee;
																																	case 5:
																																	case 80:
																																		goto IL_03fc;
																																	case 7:
																																		goto IL_0440;
																																	case 108:
																																	case 110:
																																		goto IL_0459;
																																	case 28:
																																		goto IL_04bb;
																																	case 120:
																																		goto IL_04ce;
																																	case 4:
																																	case 51:
																																		goto IL_04d9;
																																	case 87:
																																		goto IL_04e4;
																																	case 19:
																																		goto IL_04f7;
																																	case 66:
																																		goto IL_0505;
																																	case 8:
																																		goto IL_0518;
																																	case 17:
																																	case 27:
																																		goto IL_0526;
																																	case 56:
																																	case 123:
																																		goto IL_0539;
																																	case 125:
																																		goto IL_0552;
																																	case 101:
																																	case 117:
																																		goto IL_0560;
																																	case 23:
																																		goto IL_05a0;
																																	case 72:
																																		goto IL_05b4;
																																	case 12:
																																	case 131:
																																		goto IL_05c7;
																																	case 135:
																																		goto IL_05e3;
																																	case 127:
																																	case 148:
																																		goto IL_05f6;
																																	case 76:
																																		goto IL_0604;
																																	case 61:
																																	case 151:
																																		goto IL_0612;
																																	case 154:
																																		goto IL_0628;
																																	case 115:
																																		goto IL_0636;
																																	case 37:
																																	case 156:
																																		goto IL_0644;
																																	case 157:
																																		goto IL_0652;
																																	case 2:
																																		goto IL_0675;
																																	case 60:
																																		goto IL_067f;
																																	case 138:
																																		goto IL_068d;
																																	case 158:
																																		goto IL_06a0;
																																	case 48:
																																		goto IL_06df;
																																	case 44:
																																	case 104:
																																		goto IL_0717;
																																	case 50:
																																		goto IL_0725;
																																	case 86:
																																	case 136:
																																		goto IL_0733;
																																	case 105:
																																		goto IL_074c;
																																	case 16:
																																		goto IL_075a;
																																	case 29:
																																		goto IL_0768;
																																	case 40:
																																	case 126:
																																		goto IL_0784;
																																	case 97:
																																		goto IL_0792;
																																	case 42:
																																	case 64:
																																		goto IL_07a0;
																																	case 153:
																																		goto IL_07d2;
																																	case 46:
																																	case 63:
																																		goto IL_07eb;
																																	case 78:
																																		goto IL_0809;
																																	case 118:
																																		goto IL_0817;
																																	case 161:
																																		goto IL_082a;
																																	case 26:
																																	case 162:
																																		goto IL_0838;
																																	case 74:
																																	case 145:
																																		goto IL_0843;
																																	case 24:
																																		goto IL_0851;
																																	case 94:
																																	case 112:
																																		goto IL_085f;
																																	case 164:
																																		goto IL_0880;
																																	case 132:
																																	case 134:
																																		goto IL_088e;
																																	case 25:
																																		goto IL_08b7;
																																	case 99:
																																		goto IL_08c5;
																																	case 129:
																																		goto IL_08d8;
																																	case 6:
																																	case 130:
																																		goto IL_08e3;
																																	case 137:
																																		goto IL_0922;
																																	case 65:
																																		goto IL_0932;
																																	case 159:
																																		goto IL_093d;
																																	case 58:
																																	case 109:
																																		goto IL_0948;
																																	case 152:
																																		goto IL_0956;
																																	case 77:
																																		goto IL_0977;
																																	case 3:
																																		goto IL_0985;
																																	case 15:
																																	case 18:
																																	case 22:
																																	case 36:
																																	case 43:
																																	case 45:
																																	case 52:
																																	case 54:
																																	case 55:
																																	case 68:
																																	case 69:
																																	case 70:
																																	case 75:
																																	case 82:
																																	case 90:
																																	case 91:
																																	case 95:
																																	case 98:
																																	case 106:
																																	case 114:
																																	case 116:
																																	case 121:
																																	case 128:
																																	case 142:
																																	case 144:
																																	case 146:
																																	case 147:
																																	case 160:
																																		goto end_IL_038c;
																																	case 1:
																																	case 10:
																																	case 31:
																																	case 47:
																																	case 49:
																																	case 73:
																																	case 79:
																																	case 83:
																																	case 88:
																																	case 89:
																																	case 102:
																																	case 103:
																																	case 111:
																																	case 113:
																																	case 119:
																																	case 124:
																																	case 133:
																																	case 139:
																																	case 155:
																																	case 163:
																																		goto end_IL_036f;
																																	case 11:
																																		goto IL_09bb;
																																	case 41:
																																		goto IL_09c5;
																																	case 143:
																																		goto IL_09d0;
																																	case 141:
																																		goto end_IL_02bb;
																																	case 59:
																																	case 140:
																																		goto end_IL_09e9;
																																	case 9:
																																		goto end_IL_09f9;
																																	case 39:
																																	case 92:
																																		goto end_IL_0a09;
																																	case 32:
																																		goto end_IL_0a19;
																																	case 33:
																																		goto end_IL_0a29;
																																	case 20:
																																	case 35:
																																		goto IL_0a44;
																																	}
																																	continue;
																																}
																																num5--;
																																num = 73;
																																goto end_IL_036f;
																																continue;
																																end_IL_02bb:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												num = 44;
																												goto IL_0717;
																												IL_075a:
																												num5++;
																												goto IL_0768;
																												IL_0768:
																												ptr2 += 8;
																												goto end_IL_036f;
																												IL_0717:
																												if (1 < b)
																												{
																													goto end_IL_038c;
																												}
																												goto IL_0725;
																												IL_0725:
																												if (1 > b)
																												{
																													goto end_IL_038c;
																												}
																												goto IL_0733;
																												IL_0733:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_074c;
																												IL_074c:
																												array[num5] = 0;
																												goto IL_075a;
																											}
																											break;
																										}
																										num = 40;
																										goto IL_0784;
																										IL_07a0:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										num = 153;
																										goto IL_07d2;
																										IL_07d2:
																										array[num5 - 1] = 5;
																										goto end_IL_036f;
																										IL_0784:
																										if (3 < b)
																										{
																											goto end_IL_038c;
																										}
																										goto IL_0792;
																										IL_0792:
																										if (3 > b)
																										{
																											goto end_IL_038c;
																										}
																										goto IL_07a0;
																									}
																									break;
																								}
																								goto IL_07eb;
																								IL_0817:
																								num5--;
																								goto end_IL_036f;
																								IL_07eb:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_0809;
																								IL_0809:
																								ptr2 += 8;
																								goto IL_0817;
																							}
																							break;
																						}
																						goto IL_082a;
																						IL_0985:
																						ptr2 += 8;
																						goto end_IL_036f;
																						IL_082a:
																						if (6 < b)
																						{
																							goto IL_0838;
																						}
																						goto IL_08d8;
																						IL_0838:
																						if (7 < b)
																						{
																							goto IL_0843;
																						}
																						goto IL_0880;
																						IL_0843:
																						if (8 < b)
																						{
																							goto end_IL_038c;
																						}
																						goto IL_0851;
																						IL_0851:
																						if (8 > b)
																						{
																							goto end_IL_038c;
																						}
																						goto IL_085f;
																						IL_085f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						num = 31;
																						goto end_IL_036f;
																						IL_0880:
																						if (7 > b)
																						{
																							goto end_IL_038c;
																						}
																						goto IL_088e;
																						IL_088e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_08b7;
																						IL_08b7:
																						ptr2 += 8;
																						goto IL_08c5;
																						IL_08c5:
																						num5--;
																						goto end_IL_036f;
																						IL_08d8:
																						if (6 <= b)
																						{
																							goto IL_08e3;
																						}
																						goto IL_0932;
																						IL_08e3:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0922;
																						IL_0922:
																						num5 -= 3;
																						goto end_IL_036f;
																						IL_0932:
																						if (5 < b)
																						{
																							goto end_IL_038c;
																						}
																						goto IL_093d;
																						IL_093d:
																						if (5 > b)
																						{
																							goto end_IL_038c;
																						}
																						goto IL_0948;
																						IL_0948:
																						array[num5] = 5;
																						goto IL_0956;
																						IL_0956:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						num = 77;
																						goto IL_0977;
																						IL_0977:
																						num5++;
																						goto IL_0985;
																					}
																					goto end_IL_09a8;
																					continue;
																					end_IL_036f:
																					break;
																					IL_036f:;
																				}
																				break;
																			}
																			goto IL_03c7;
																			IL_06a0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)WriteArraycharBuffer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_06df;
																			IL_03c7:
																			if (13 >= b)
																			{
																				goto IL_03d5;
																			}
																			goto IL_04ce;
																			IL_03d5:
																			if (13 > b)
																			{
																				goto IL_03e0;
																			}
																			goto IL_0459;
																			IL_03e0:
																			if (11 >= b)
																			{
																				goto IL_03ee;
																			}
																			goto IL_0539;
																			IL_03ee:
																			if (11 <= b)
																			{
																				goto IL_03fc;
																			}
																			goto IL_0628;
																			IL_03fc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0440;
																			IL_0440:
																			array[num5 - 2] = 0;
																			goto IL_05e3;
																			IL_05e3:
																			num5--;
																			break;
																			IL_0628:
																			if (10 < b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0636;
																			IL_0636:
																			if (10 > b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0644;
																			IL_0644:
																			array[num5] = 0;
																			goto IL_0652;
																			IL_0652:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0675;
																			IL_0675:
																			array2[num5] = null;
																			goto IL_067f;
																			IL_067f:
																			num5++;
																			goto IL_068d;
																			IL_068d:
																			ptr2 += 8;
																			break;
																			IL_0539:
																			if (12 < b)
																			{
																				num = 75;
																				goto end_IL_038c;
																			}
																			goto IL_0552;
																			IL_06df:
																			ptr2 += 8;
																			break;
																			IL_0552:
																			if (12 > b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0560;
																			IL_0560:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05a0;
																			IL_05a0:
																			array[num5 - 2] = 0;
																			goto IL_05b4;
																			IL_05b4:
																			num5--;
																			break;
																			IL_0459:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04bb;
																			IL_04bb:
																			num5 -= 2;
																			break;
																			IL_04ce:
																			if (15 < b)
																			{
																				goto IL_04d9;
																			}
																			goto IL_0518;
																			IL_04d9:
																			if (16 >= b)
																			{
																				goto IL_04e4;
																			}
																			goto IL_04f7;
																			IL_04e4:
																			if (16 > b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_05c7;
																			IL_05c7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_04f7:
																			if (17 < b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0505;
																			IL_0505:
																			if (17 > b)
																			{
																			}
																			goto end_IL_038c;
																			IL_0518:
																			if (15 <= b)
																			{
																				goto IL_0526;
																			}
																			goto IL_05f6;
																			IL_0526:
																			num5--;
																			break;
																			IL_05f6:
																			if (14 < b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0604;
																			IL_0604:
																			if (14 > b)
																			{
																				goto end_IL_038c;
																			}
																			goto IL_0612;
																			IL_0612:
																			array[num5 - 1] = 0;
																			goto IL_06a0;
																		}
																		goto end_IL_039c;
																		continue;
																		end_IL_038c:
																		break;
																		IL_038c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_039c:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a44;
												IL_0a44:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09a8:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_09e9:
								break;
							}
							continue;
							end_IL_09f9:
							break;
						}
						continue;
						end_IL_0a09:
						break;
					}
					continue;
					end_IL_0a19:
					break;
				}
				continue;
				end_IL_0a29:
				break;
			}
		}
	}

	static Class12()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 11;
			while (true)
			{
				if (num != 11)
				{
					if (num == 992)
					{
						switch (num)
						{
						case 1:
							goto end_IL_0035;
						case 0:
						case 2:
						case 4:
							goto IL_0059;
						case 3:
							return;
						}
						continue;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				goto IL_0059;
				IL_0059:
				num = 3;
				return;
				continue;
				end_IL_0035:
				break;
			}
		}
	}
}
