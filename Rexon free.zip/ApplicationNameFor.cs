using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 114)]
internal struct ApplicationNameFor
{
	internal static ApplicationNameFor BeepMAJORVERSION/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 03 00 00 00 02 02 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 04 03 00 00 00 03 03 00 00 00 05 00 00 00 02 02 00 00 00 05 00 00 00 03 03 00 00 00 06 03 00 00 00 04 04 00 00 00 05 00 00 00 04 04 00 00 00 07 00 00 04 41 41 04 00 00 07 00 00 00 0B 0B 00 00 00 08 02 09) */;
}
