using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using BepInEx;
using Photon.Voice.Unity;
using UnityEngine;
using UnityEngine.Networking;

internal static class Class11
{
	internal sealed class _003CLoadAndPlayAudio_003Ed__17 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private UnityWebRequestAsyncOperation unityWebRequestAsyncOperation_0;

		public string string_0;

		public string string_1;

		private string string_2;

		private UnityWebRequest unityWebRequest_0;

		private static IntPtr[] BytesUnknownChangePermissions;

		private static IntPtr[] GetObjectValueAutoResetEvent;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = unityWebRequestAsyncOperation_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = unityWebRequestAsyncOperation_0;
				return obj;
			}
		}

		public _003CLoadAndPlayAudio_003Ed__17(int _003C_003E1__state)
		{
			object obj = this;
			((_003CLoadAndPlayAudio_003Ed__17)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 62;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				num = 61;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							IL_0542:
							object[] array2 = new object[3];
							while (true)
							{
								IL_0532:
								long[] array3 = new long[3];
								while (true)
								{
									IL_0522:
									object[] array4 = new object[1];
									while (true)
									{
										IL_0512:
										array4[0] = this;
										while (true)
										{
											IL_0507:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DXDSNNativeOrStaticEventRegistrationImpl.IsValidAttributeNameReadOnlyArrayList);
											while (true)
											{
												IL_04fd:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_04ea:
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_02f5:
														byte b = *ptr2;
														while (true)
														{
															IL_02e5:
															ptr2++;
															while (true)
															{
																IL_02d8:
																if (b < 1)
																{
																	goto IL_02a2;
																}
																goto IL_02c8;
																IL_02c8:
																if (b <= 8)
																{
																	goto IL_000e;
																}
																goto IL_02a2;
																IL_000e:
																if (4 < b)
																{
																	goto IL_001c;
																}
																num = 28;
																goto IL_01ef;
																IL_0354:
																num5 -= 2;
																goto IL_04ea;
																IL_01ef:
																if (4 > b)
																{
																	goto IL_0248;
																}
																goto IL_032c;
																IL_0248:
																if (2 < b)
																{
																	goto IL_0253;
																}
																goto IL_026e;
																IL_026e:
																if (2 > b)
																{
																	goto IL_027c;
																}
																goto IL_047f;
																IL_027c:
																if (1 >= b)
																{
																	goto IL_0287;
																}
																goto IL_02a2;
																IL_02a2:
																while (true)
																{
																	IL_02a2_2:
																	array2[num5] = array4[*(int*)(ptr2 + num3)];
																	num = 100;
																	while (true)
																	{
																		if (num != 100)
																		{
																			if (num != 1081)
																			{
																				break;
																			}
																			switch (num)
																			{
																			case 5:
																				break;
																			case 93:
																				goto IL_001c;
																			case 24:
																				goto IL_002a;
																			case 45:
																				goto IL_0038;
																			default:
																				continue;
																			case 28:
																				goto IL_01ef;
																			case 34:
																				goto IL_01ff;
																			case 15:
																			case 56:
																				goto IL_0212;
																			case 2:
																				goto IL_021d;
																			case 42:
																				goto IL_022d;
																			case 75:
																				goto IL_0238;
																			case 26:
																			case 90:
																				goto IL_0248;
																			case 16:
																			case 31:
																				goto IL_0253;
																			case 14:
																				goto IL_025e;
																			case 80:
																				goto IL_026e;
																			case 37:
																			case 92:
																				goto IL_027c;
																			case 70:
																				goto IL_0287;
																			case 1:
																			case 3:
																			case 6:
																			case 21:
																			case 22:
																			case 23:
																			case 25:
																			case 33:
																			case 39:
																			case 48:
																			case 57:
																			case 60:
																			case 64:
																			case 65:
																			case 66:
																			case 69:
																			case 71:
																			case 73:
																			case 78:
																			case 87:
																				goto IL_02a2_2;
																			case 54:
																				goto IL_02c8;
																			case 49:
																				goto IL_02d8;
																			case 63:
																				goto IL_02e5;
																			case 36:
																			case 83:
																				goto IL_02f5;
																			case 41:
																			case 43:
																				goto IL_0300;
																			case 35:
																				goto IL_0319;
																			case 29:
																			case 44:
																				goto IL_032c;
																			case 12:
																				goto IL_0354;
																			case 30:
																			case 55:
																				goto IL_0367;
																			case 9:
																			case 77:
																				goto IL_0383;
																			case 53:
																				goto IL_03b1;
																			case 17:
																			case 84:
																				goto IL_03c4;
																			case 86:
																				goto IL_0404;
																			case 88:
																				goto IL_041d;
																			case 19:
																				goto IL_042b;
																			case 38:
																			case 82:
																				goto IL_0447;
																			case 8:
																				goto IL_046f;
																			case 18:
																			case 72:
																				goto IL_047f;
																			case 10:
																				goto IL_0489;
																			case 76:
																				goto IL_04a0;
																			case 91:
																				goto IL_04b0;
																			case 11:
																				goto IL_04ce;
																			case 85:
																				goto IL_04dc;
																			case 4:
																			case 13:
																			case 27:
																			case 32:
																			case 40:
																			case 47:
																			case 51:
																			case 58:
																			case 59:
																			case 67:
																				goto IL_04ea;
																			case 0:
																				goto IL_04fd;
																			case 68:
																				goto IL_0507;
																			case 89:
																				goto IL_0512;
																			case 20:
																				goto IL_0522;
																			case 7:
																			case 79:
																				goto IL_0532;
																			case 81:
																				goto IL_0542;
																			case 46:
																			case 52:
																				goto end_IL_01dc;
																			case 61:
																				goto end_IL_0552;
																			case 62:
																				goto end_IL_0562;
																			case 50:
																			case 74:
																				return;
																			}
																			goto IL_000e;
																		}
																		array[num5] = 5;
																		goto IL_04ce;
																		IL_04ce:
																		num5++;
																		goto IL_04dc;
																		IL_04dc:
																		ptr2 += 8;
																		goto IL_04ea;
																		continue;
																		end_IL_01dc:
																		break;
																	}
																	break;
																}
																break;
																IL_0287:
																if (1 <= b)
																{
																}
																goto IL_02a2;
																IL_0253:
																if (3 >= b)
																{
																	goto IL_025e;
																}
																goto IL_02a2;
																IL_025e:
																if (3 > b)
																{
																	goto IL_02a2;
																}
																goto IL_0447;
																IL_0447:
																((_003CLoadAndPlayAudio_003Ed__17)array2[num5 - 2]).string_2 = (string)array2[num5 - 1];
																goto IL_046f;
																IL_046f:
																num5 -= 2;
																goto IL_04ea;
																IL_001c:
																if (6 >= b)
																{
																	goto IL_002a;
																}
																goto IL_0212;
																IL_002a:
																if (6 > b)
																{
																	goto IL_0038;
																}
																goto IL_03c4;
																IL_0038:
																if (5 >= b)
																{
																	goto IL_01ff;
																}
																goto IL_02a2;
																IL_01ff:
																if (5 > b)
																{
																	goto IL_02a2;
																}
																goto IL_0300;
																IL_0300:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																goto IL_0319;
																IL_0319:
																array[num5] = 0;
																goto IL_041d;
																IL_041d:
																num5++;
																goto IL_042b;
																IL_042b:
																ptr2 += 8;
																num = 4;
																goto IL_04ea;
																IL_03c4:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																goto IL_0404;
																IL_0404:
																array[num5 - 2] = 0;
																goto IL_04b0;
																IL_04b0:
																num5--;
																goto IL_04ea;
																IL_0212:
																if (7 >= b)
																{
																	goto IL_021d;
																}
																goto IL_022d;
																IL_021d:
																if (7 > b)
																{
																	goto IL_02a2;
																}
																goto IL_0383;
																IL_0383:
																((_003CLoadAndPlayAudio_003Ed__17)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																goto IL_03b1;
																IL_03b1:
																num5 -= 2;
																goto IL_04ea;
																IL_022d:
																if (8 >= b)
																{
																	goto IL_0238;
																}
																goto IL_02a2;
																IL_0238:
																if (8 > b)
																{
																	goto IL_02a2;
																}
																goto IL_0367;
																IL_0367:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto IL_04ea;
																IL_047f:
																array2[num5] = null;
																goto IL_0489;
																IL_0489:
																array[num5] = 5;
																num = 76;
																goto IL_04a0;
																IL_04a0:
																num5++;
																goto IL_04ea;
																IL_032c:
																((_003CLoadAndPlayAudio_003Ed__17)array2[num5 - 2]).unityWebRequest_0 = (UnityWebRequest)array2[num5 - 1];
																goto IL_0354;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0552:
						break;
					}
					continue;
					end_IL_0562:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_07b1, IL_07c4, IL_0807, IL_081d, IL_082d, IL_083d, IL_084d, IL_0860, IL_0870, IL_087d, IL_088d, IL_089d, IL_08ad, IL_08bd, IL_08c8, IL_08d8, IL_0918, IL_092e, IL_0941, IL_094f, IL_0972, IL_0981, IL_0994, IL_099f, IL_09ad, IL_09eb, IL_0a04, IL_0a12, IL_0a20, IL_0a52, IL_0a60, IL_0a73, IL_0a81, IL_0a8f, IL_0aac, IL_0aba, IL_0af8, IL_0b0b, IL_0b19, IL_0b27, IL_0b3f, IL_0b56, IL_0b64, IL_0b77, IL_0b85, IL_0b98, IL_0bab, IL_0bb9, IL_0bcc, IL_0bdf, IL_0bed, IL_0c05, IL_0c23, IL_0c47, IL_0c5f, IL_0c7b, IL_0c89, IL_0c97, IL_0ca2, IL_0cb0, IL_0cbe, IL_0cdc, IL_0cea, IL_0cfd, IL_0d0b, IL_0d28, IL_0d77, IL_0d81, IL_0dae, IL_0dc2, IL_0dd0, IL_0dec, IL_0e05, IL_0e13, IL_0e21, IL_0e34, IL_0e3f, IL_0e4d, IL_0e5b, IL_0e84, IL_0e9d, IL_0eab, IL_0eb4, IL_0ef4, IL_0f08, IL_0f1b, IL_0f29, IL_0f37, IL_0f42, IL_0f60, IL_0f6e, IL_0f7c, IL_0f8f, IL_0f9a, IL_0fa8, IL_0fd5, IL_0fe8, IL_0ff6, IL_1004, IL_101c, IL_102a, IL_1038, IL_1046, IL_1063, IL_10b5, IL_10c3, IL_10d6, IL_10e4, IL_10ef, IL_1130, IL_1144, IL_1157, IL_1165, IL_1173, IL_1187, IL_11d4, IL_11e2, IL_11f5, IL_1200, IL_1214, IL_124c, IL_125f, IL_126d, IL_127b, IL_1289, IL_1297, IL_12a5, IL_1307, IL_131a, IL_1328, IL_137a, IL_138d, IL_13b2, IL_13bd, IL_13cb, IL_1402, IL_1415, IL_1423, IL_1431, IL_1469, IL_147d, IL_1490, IL_149e, IL_14ac, IL_14ba, IL_14c5, IL_14d3, IL_14e6, IL_14f4, IL_1502, IL_1510, IL_157e, IL_1591, IL_159a, IL_15b7, IL_1604, IL_1612, IL_1625, IL_1633, IL_163e, IL_164c, IL_165a, IL_1682, IL_1695, IL_16a3, IL_16ad, IL_16bb, IL_16ce, IL_16e2, IL_1720, IL_1733, IL_173e, IL_1767, IL_1775, IL_1788, IL_1796, IL_17a1, IL_17af, IL_17cd, IL_17db, IL_17e9, IL_17fc, IL_180a, IL_1818, IL_1821, IL_1859, IL_186d, IL_1880, IL_188b, IL_18c8, IL_18d6, IL_18f2, IL_18fd, IL_190b, IL_1919, IL_1930, IL_1951, IL_195f, IL_1972, IL_197b, IL_1989, IL_19a7, IL_19b5, IL_19c3, IL_19d6, IL_19e1, IL_1a1e, IL_1a2c, IL_1a3f, IL_1a4d, IL_1a5b, IL_1a69, IL_1a77, IL_1a85, IL_1a93, IL_1aa7, IL_1af4, IL_1b02, IL_1b1e, IL_1b2c, IL_1b40, IL_1b8c, IL_1b9a, IL_1bad, IL_1bb6, IL_1bc4, IL_1bcf, IL_1bdd, IL_1bf1, IL_1c2f, IL_1c42, IL_1c50, IL_1c5e, IL_1cc0, IL_1cd3, IL_1d41, IL_1d54, IL_1d81, IL_1d9d, IL_1dab, IL_1db6, IL_1dec, IL_1dff, IL_1e0a, IL_1e18, IL_1e50, IL_1e64, IL_1e77, IL_1e82, IL_1e90, IL_1ea4, IL_1edc, IL_1eef, IL_1efd, IL_1f0b, IL_1f19, IL_1f27, IL_1f32, IL_1f46, IL_1f84, IL_1f97, IL_1fa5, IL_1fb9, IL_1ff1, IL_2001, IL_200c, IL_2017, IL_2035, IL_2043, IL_2053, IL_2066, IL_2079, IL_2083, IL_208e, IL_209e, IL_20b7, IL_20d0, IL_20e0, IL_20f0, IL_2100, IL_2110, IL_2120, IL_213b, IL_2144 are reachable both inside and outside the pinned region starting at IL_2135. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 166;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2;
				int num3;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef22 = default(int);
				ref int reference = ref __rxRef22;
				object[] array8;
				int num6;
				byte* num7;
				byte* num9;
				int num10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_2120:
						num2 = 1;
						while (true)
						{
							IL_2110:
							num3 = num2 * 4;
							while (true)
							{
								IL_2100:
								array2 = new byte[4];
								while (true)
								{
									IL_20f0:
									array3 = new object[4];
									while (true)
									{
										IL_20e0:
										array4 = new int[4];
										while (true)
										{
											IL_20d0:
											array5 = new int[3];
											while (true)
											{
												IL_20b7:
												array6 = new long[4];
												num = 50;
												while (true)
												{
													IL_209e:
													array7 = new object[9];
													num = 329;
													while (true)
													{
														IL_208e:
														array7[0] = this;
														while (true)
														{
															IL_2083:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetReferenceIsNestedFamORAssem.getCanTransformMultipleBlocksFindComponentsByDefinition);
															while (true)
															{
																IL_2079:
																ptr2 = ptr;
																while (true)
																{
																	IL_2066:
																	if (num4 != 1)
																	{
																		while (true)
																		{
																			IL_08bd:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_08ad:
																				ptr2++;
																				while (true)
																				{
																					IL_089d:
																					if (b >= 1)
																					{
																						while (b <= 51)
																						{
																							while (true)
																							{
																								IL_087d:
																								if (26 >= b)
																								{
																									while (true)
																									{
																										IL_0870:
																										if (26 > b)
																										{
																											while (true)
																											{
																												IL_0860:
																												if (13 >= b)
																												{
																													while (true)
																													{
																														IL_084d:
																														if (13 > b)
																														{
																															num = 452;
																															while (true)
																															{
																																IL_083d:
																																if (6 < b)
																																{
																																	while (true)
																																	{
																																		IL_082d:
																																		if (9 >= b)
																																		{
																																			while (true)
																																			{
																																				IL_081d:
																																				if (9 <= b)
																																				{
																																					while (true)
																																					{
																																						array2[num5 - 1] = 5;
																																						while (true)
																																						{
																																							IL_07c4:
																																							array3[num5 - 1] = ((delegate*<string[], string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																																							num = 485;
																																							while (true)
																																							{
																																								if (num != 485)
																																								{
																																									if (num != 1466)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 166:
																																										break;
																																									default:
																																										continue;
																																									case 125:
																																										goto IL_07c4;
																																									case 126:
																																									case 464:
																																										goto end_IL_07b1;
																																									case 105:
																																										goto IL_081d;
																																									case 66:
																																									case 416:
																																										goto IL_082d;
																																									case 101:
																																									case 452:
																																										goto IL_083d;
																																									case 159:
																																										goto IL_084d;
																																									case 128:
																																										goto IL_0860;
																																									case 186:
																																										goto IL_0870;
																																									case 235:
																																										goto IL_087d;
																																									case 372:
																																										goto IL_088d;
																																									case 80:
																																										goto IL_089d;
																																									case 468:
																																										goto IL_08ad;
																																									case 1:
																																									case 108:
																																										goto IL_08bd;
																																									case 49:
																																										goto IL_08c8;
																																									case 8:
																																									case 225:
																																										goto IL_08d8;
																																									case 70:
																																										goto IL_0918;
																																									case 282:
																																										goto IL_092e;
																																									case 212:
																																									case 285:
																																										goto IL_0941;
																																									case 58:
																																										goto IL_094f;
																																									case 93:
																																										goto IL_0972;
																																									case 388:
																																										goto IL_0981;
																																									case 139:
																																									case 418:
																																										goto IL_0994;
																																									case 137:
																																										goto IL_099f;
																																									case 2:
																																									case 366:
																																										goto IL_09ad;
																																									case 320:
																																										goto IL_09eb;
																																									case 122:
																																										goto IL_0a04;
																																									case 69:
																																										goto IL_0a12;
																																									case 410:
																																									case 411:
																																										goto IL_0a20;
																																									case 56:
																																										goto IL_0a52;
																																									case 213:
																																										goto IL_0a60;
																																									case 424:
																																										goto IL_0a73;
																																									case 216:
																																									case 404:
																																										goto IL_0a81;
																																									case 266:
																																										goto IL_0a8f;
																																									case 425:
																																										goto IL_0aac;
																																									case 227:
																																									case 332:
																																										goto IL_0aba;
																																									case 167:
																																										goto IL_0af8;
																																									case 427:
																																									case 428:
																																										goto IL_0b0b;
																																									case 28:
																																										goto IL_0b19;
																																									case 155:
																																									case 220:
																																										goto IL_0b27;
																																									case 419:
																																										goto IL_0b3f;
																																									case 147:
																																										goto IL_0b56;
																																									case 326:
																																										goto IL_0b64;
																																									case 430:
																																										goto IL_0b77;
																																									case 118:
																																										goto IL_0b85;
																																									case 449:
																																										goto IL_0b98;
																																									case 467:
																																										goto IL_0bab;
																																									case 192:
																																										goto IL_0bb9;
																																									case 478:
																																										goto IL_0bdf;
																																									case 84:
																																									case 380:
																																										goto IL_0bed;
																																									case 460:
																																										goto IL_0c05;
																																									case 244:
																																										goto IL_0c23;
																																									case 59:
																																										goto IL_0c47;
																																									case 64:
																																										goto IL_0c5f;
																																									case 206:
																																										goto IL_0c7b;
																																									case 336:
																																										goto IL_0c89;
																																									case 229:
																																									case 296:
																																										goto IL_0c97;
																																									case 163:
																																									case 173:
																																										goto IL_0ca2;
																																									case 398:
																																										goto IL_0cb0;
																																									case 268:
																																									case 470:
																																										goto IL_0cbe;
																																									case 164:
																																										goto IL_0cdc;
																																									case 67:
																																										goto IL_0cea;
																																									case 272:
																																										goto IL_0cfd;
																																									case 217:
																																									case 420:
																																										goto IL_0d0b;
																																									case 29:
																																										goto IL_0dc2;
																																									case 26:
																																										goto IL_0dd0;
																																									case 245:
																																									case 362:
																																										goto IL_0dec;
																																									case 19:
																																										goto IL_0e05;
																																									case 31:
																																										goto IL_0e13;
																																									case 475:
																																										goto IL_0e21;
																																									case 281:
																																										goto IL_0e34;
																																									case 87:
																																									case 307:
																																										goto IL_0e3f;
																																									case 22:
																																										goto IL_0e4d;
																																									case 39:
																																									case 188:
																																										goto IL_0e5b;
																																									case 434:
																																										goto IL_0e84;
																																									case 161:
																																										goto IL_0e9d;
																																									case 270:
																																									case 290:
																																										goto IL_0eb4;
																																									case 43:
																																										goto IL_0ef4;
																																									case 368:
																																										goto IL_0f08;
																																									case 210:
																																										goto IL_0f1b;
																																									case 104:
																																									case 143:
																																										goto IL_0f29;
																																									case 243:
																																										goto IL_0f37;
																																									case 453:
																																									case 474:
																																										goto IL_0f42;
																																									case 396:
																																										goto IL_0f60;
																																									case 214:
																																										goto IL_0f6e;
																																									case 471:
																																										goto IL_0f7c;
																																									case 376:
																																										goto IL_0f8f;
																																									case 395:
																																										goto IL_0f9a;
																																									case 68:
																																									case 196:
																																										goto IL_0fa8;
																																									case 444:
																																										goto IL_0fd5;
																																									case 351:
																																										goto IL_0fe8;
																																									case 178:
																																										goto IL_0ff6;
																																									case 172:
																																									case 322:
																																										goto IL_1004;
																																									case 197:
																																										goto IL_101c;
																																									case 134:
																																									case 238:
																																										goto IL_102a;
																																									case 413:
																																										goto IL_1038;
																																									case 149:
																																									case 341:
																																										goto IL_1046;
																																									case 305:
																																										goto IL_1063;
																																									case 249:
																																										goto IL_10b5;
																																									case 140:
																																										goto IL_10c3;
																																									case 72:
																																										goto IL_10e4;
																																									case 310:
																																									case 317:
																																										goto IL_10ef;
																																									case 117:
																																										goto IL_1130;
																																									case 250:
																																										goto IL_1144;
																																									case 7:
																																										goto IL_1157;
																																									case 10:
																																										goto IL_1165;
																																									case 257:
																																									case 258:
																																										goto IL_1173;
																																									case 312:
																																										goto IL_1187;
																																									case 40:
																																										goto IL_11d4;
																																									case 144:
																																										goto IL_11e2;
																																									case 234:
																																										goto IL_11f5;
																																									case 201:
																																									case 446:
																																										goto IL_1200;
																																									case 299:
																																										goto IL_1214;
																																									case 157:
																																										goto IL_124c;
																																									case 138:
																																										goto IL_125f;
																																									case 318:
																																										goto IL_126d;
																																									case 284:
																																										goto IL_127b;
																																									case 204:
																																										goto IL_1289;
																																									case 343:
																																										goto IL_1297;
																																									case 265:
																																									case 348:
																																										goto IL_12a5;
																																									case 435:
																																										goto IL_1307;
																																									case 262:
																																										goto IL_131a;
																																									case 17:
																																									case 277:
																																										goto IL_1328;
																																									case 98:
																																										goto IL_137a;
																																									case 223:
																																									case 365:
																																										goto IL_138d;
																																									case 389:
																																										goto IL_13b2;
																																									case 454:
																																										goto IL_13bd;
																																									case 280:
																																									case 423:
																																										goto IL_13cb;
																																									case 119:
																																										goto IL_1402;
																																									case 392:
																																										goto IL_1415;
																																									case 417:
																																										goto IL_1423;
																																									case 146:
																																									case 198:
																																										goto IL_1431;
																																									case 180:
																																										goto IL_1469;
																																									case 261:
																																										goto IL_147d;
																																									case 251:
																																										goto IL_1490;
																																									case 110:
																																									case 230:
																																										goto IL_149e;
																																									case 203:
																																									case 291:
																																										goto IL_14ac;
																																									case 106:
																																									case 390:
																																										goto IL_14ba;
																																									case 335:
																																									case 393:
																																										goto IL_14c5;
																																									case 363:
																																										goto IL_14d3;
																																									case 202:
																																										goto IL_14e6;
																																									case 231:
																																										goto IL_14f4;
																																									case 33:
																																										goto IL_1502;
																																									case 340:
																																									case 383:
																																										goto IL_1510;
																																									case 18:
																																										goto IL_157e;
																																									case 187:
																																									case 458:
																																										goto IL_159a;
																																									case 461:
																																										goto IL_15b7;
																																									case 328:
																																										goto IL_1604;
																																									case 269:
																																										goto IL_1612;
																																									case 401:
																																										goto IL_1625;
																																									case 100:
																																									case 463:
																																										goto IL_1633;
																																									case 113:
																																									case 292:
																																										goto IL_163e;
																																									case 99:
																																										goto IL_164c;
																																									case 32:
																																									case 432:
																																										goto IL_165a;
																																									case 455:
																																										goto IL_1682;
																																									case 37:
																																										goto IL_1695;
																																									case 301:
																																									case 308:
																																										goto IL_16a3;
																																									case 394:
																																										goto IL_16ad;
																																									case 174:
																																										goto IL_16bb;
																																									case 181:
																																									case 367:
																																										goto IL_16ce;
																																									case 177:
																																										goto IL_16e2;
																																									case 129:
																																										goto IL_1720;
																																									case 352:
																																										goto IL_1733;
																																									case 175:
																																									case 254:
																																										goto IL_173e;
																																									case 221:
																																										goto IL_1767;
																																									case 182:
																																										goto IL_1775;
																																									case 431:
																																										goto IL_1788;
																																									case 194:
																																									case 286:
																																										goto IL_1796;
																																									case 61:
																																										goto IL_17a1;
																																									case 13:
																																									case 439:
																																										goto IL_17af;
																																									case 111:
																																										goto IL_17cd;
																																									case 240:
																																										goto IL_17db;
																																									case 42:
																																										goto IL_17e9;
																																									case 295:
																																										goto IL_17fc;
																																									case 278:
																																										goto IL_180a;
																																									case 154:
																																									case 222:
																																										goto IL_1821;
																																									case 236:
																																										goto IL_1859;
																																									case 442:
																																										goto IL_186d;
																																									case 441:
																																										goto IL_1880;
																																									case 21:
																																									case 162:
																																										goto IL_188b;
																																									case 377:
																																										goto IL_18c8;
																																									case 371:
																																										goto IL_18d6;
																																									case 397:
																																										goto IL_18f2;
																																									case 116:
																																										goto IL_18fd;
																																									case 421:
																																										goto IL_190b;
																																									case 54:
																																									case 131:
																																										goto IL_1919;
																																									case 374:
																																										goto IL_1930;
																																									case 169:
																																										goto IL_1951;
																																									case 151:
																																										goto IL_195f;
																																									case 403:
																																										goto IL_197b;
																																									case 136:
																																									case 314:
																																										goto IL_1989;
																																									case 16:
																																										goto IL_19a7;
																																									case 179:
																																										goto IL_19b5;
																																									case 450:
																																										goto IL_19c3;
																																									case 275:
																																										goto IL_19d6;
																																									case 218:
																																									case 267:
																																										goto IL_19e1;
																																									case 355:
																																										goto IL_1a1e;
																																									case 248:
																																										goto IL_1a2c;
																																									case 259:
																																									case 473:
																																										goto IL_1a3f;
																																									case 46:
																																										goto IL_1a4d;
																																									case 4:
																																									case 232:
																																										goto IL_1a5b;
																																									case 347:
																																										goto IL_1a69;
																																									case 44:
																																									case 369:
																																										goto IL_1a77;
																																									case 226:
																																										goto IL_1a85;
																																									case 25:
																																									case 311:
																																										goto IL_1a93;
																																									case 289:
																																										goto IL_1aa7;
																																									case 448:
																																										goto IL_1af4;
																																									case 81:
																																										goto IL_1b02;
																																									case 35:
																																										goto IL_1b1e;
																																									case 114:
																																									case 293:
																																										goto IL_1b2c;
																																									case 360:
																																										goto IL_1b40;
																																									case 379:
																																										goto IL_1b8c;
																																									case 135:
																																										goto IL_1b9a;
																																									case 34:
																																										goto IL_1bb6;
																																									case 107:
																																									case 199:
																																										goto IL_1bc4;
																																									case 23:
																																										goto IL_1bcf;
																																									case 30:
																																									case 150:
																																										goto IL_1bdd;
																																									case 79:
																																										goto IL_1bf1;
																																									case 276:
																																										goto IL_1c2f;
																																									case 264:
																																										goto IL_1c42;
																																									case 241:
																																										goto IL_1c50;
																																									case 339:
																																									case 433:
																																										goto IL_1c5e;
																																									case 246:
																																										goto IL_1cc0;
																																									case 313:
																																									case 477:
																																										goto IL_1cd3;
																																									case 381:
																																										goto IL_1d41;
																																									case 346:
																																									case 386:
																																										goto IL_1d54;
																																									case 350:
																																										goto IL_1d81;
																																									case 130:
																																										goto IL_1d9d;
																																									case 53:
																																										goto IL_1dab;
																																									case 62:
																																									case 63:
																																										goto IL_1db6;
																																									case 90:
																																										goto IL_1dec;
																																									case 415:
																																										goto IL_1dff;
																																									case 465:
																																										goto IL_1e0a;
																																									case 133:
																																									case 344:
																																										goto IL_1e18;
																																									case 255:
																																										goto IL_1e50;
																																									case 233:
																																										goto IL_1e64;
																																									case 207:
																																										goto IL_1e77;
																																									case 103:
																																										goto IL_1e82;
																																									case 145:
																																									case 402:
																																										goto IL_1e90;
																																									case 462:
																																										goto IL_1ea4;
																																									case 86:
																																										goto IL_1edc;
																																									case 358:
																																										goto IL_1efd;
																																									case 414:
																																										goto IL_1f0b;
																																									case 209:
																																									case 237:
																																										goto IL_1f19;
																																									case 438:
																																										goto IL_1f27;
																																									case 303:
																																									case 330:
																																										goto IL_1f32;
																																									case 337:
																																										goto IL_1f46;
																																									case 384:
																																										goto IL_1f84;
																																									case 85:
																																									case 385:
																																										goto IL_1fa5;
																																									case 36:
																																										goto IL_1fb9;
																																									case 333:
																																										goto IL_1ff1;
																																									case 171:
																																										goto IL_2001;
																																									case 112:
																																										goto IL_200c;
																																									case 9:
																																									case 47:
																																										goto IL_2017;
																																									case 20:
																																										goto IL_2035;
																																									case 168:
																																										goto IL_2043;
																																									case 3:
																																									case 5:
																																									case 6:
																																									case 12:
																																									case 14:
																																									case 15:
																																									case 27:
																																									case 38:
																																									case 45:
																																									case 48:
																																									case 51:
																																									case 57:
																																									case 71:
																																									case 73:
																																									case 75:
																																									case 76:
																																									case 77:
																																									case 78:
																																									case 88:
																																									case 91:
																																									case 94:
																																									case 97:
																																									case 102:
																																									case 109:
																																									case 115:
																																									case 123:
																																									case 124:
																																									case 132:
																																									case 158:
																																									case 160:
																																									case 170:
																																									case 176:
																																									case 184:
																																									case 185:
																																									case 189:
																																									case 190:
																																									case 191:
																																									case 193:
																																									case 195:
																																									case 200:
																																									case 205:
																																									case 215:
																																									case 224:
																																									case 239:
																																									case 242:
																																									case 253:
																																									case 256:
																																									case 260:
																																									case 263:
																																									case 271:
																																									case 273:
																																									case 274:
																																									case 294:
																																									case 300:
																																									case 302:
																																									case 304:
																																									case 306:
																																									case 309:
																																									case 315:
																																									case 319:
																																									case 324:
																																									case 325:
																																									case 331:
																																									case 334:
																																									case 342:
																																									case 345:
																																									case 354:
																																									case 356:
																																									case 361:
																																									case 373:
																																									case 375:
																																									case 378:
																																									case 387:
																																									case 391:
																																									case 405:
																																									case 406:
																																									case 408:
																																									case 409:
																																									case 422:
																																									case 436:
																																									case 440:
																																									case 447:
																																									case 457:
																																									case 472:
																																										goto end_IL_088d;
																																									case 0:
																																									case 11:
																																									case 24:
																																									case 41:
																																									case 52:
																																									case 55:
																																									case 60:
																																									case 65:
																																									case 74:
																																									case 89:
																																									case 95:
																																									case 120:
																																									case 121:
																																									case 127:
																																									case 141:
																																									case 142:
																																									case 148:
																																									case 152:
																																									case 153:
																																									case 156:
																																									case 183:
																																									case 211:
																																									case 219:
																																									case 228:
																																									case 247:
																																									case 279:
																																									case 283:
																																									case 287:
																																									case 288:
																																									case 297:
																																									case 298:
																																									case 316:
																																									case 321:
																																									case 323:
																																									case 327:
																																									case 353:
																																									case 359:
																																									case 364:
																																									case 370:
																																									case 382:
																																									case 399:
																																									case 400:
																																									case 412:
																																									case 426:
																																									case 429:
																																									case 437:
																																									case 443:
																																									case 445:
																																									case 451:
																																									case 456:
																																									case 459:
																																									case 466:
																																									case 476:
																																										goto IL_2066;
																																									case 96:
																																										goto IL_2079;
																																									case 357:
																																										goto IL_2083;
																																									case 329:
																																										goto IL_208e;
																																									case 50:
																																										goto IL_209e;
																																									case 83:
																																										goto IL_20b7;
																																									case 338:
																																										goto IL_20d0;
																																									case 252:
																																										goto IL_20e0;
																																									case 407:
																																										goto IL_20f0;
																																									case 208:
																																									case 469:
																																										goto IL_2100;
																																									case 92:
																																										goto IL_2110;
																																									case 165:
																																										goto IL_2120;
																																									case 82:
																																									case 349:
																																										goto IL_2144;
																																									}
																																									goto end_IL_0807;
																																								}
																																								ptr2 += 8;
																																								goto IL_2066;
																																								continue;
																																								end_IL_07b1:
																																								break;
																																							}
																																							break;
																																						}
																																						continue;
																																						end_IL_0807:
																																						break;
																																					}
																																					break;
																																				}
																																				goto IL_08c8;
																																				IL_0af8:
																																				num5 -= 3;
																																				goto IL_2066;
																																				IL_08c8:
																																				if (7 < b)
																																				{
																																					goto IL_092e;
																																				}
																																				goto IL_0a73;
																																				IL_0a73:
																																				if (7 > b)
																																				{
																																					goto end_IL_088d;
																																				}
																																				goto IL_0a81;
																																				IL_0a81:
																																				array2[num5] = 5;
																																				goto IL_0a8f;
																																				IL_0a8f:
																																				array3[num5] = array7[*(int*)(ptr2 + num3)];
																																				goto IL_0bab;
																																				IL_0bab:
																																				num5++;
																																				goto IL_0bb9;
																																				IL_0bb9:
																																				ptr2 += 8;
																																				goto IL_2066;
																																				IL_092e:
																																				if (8 < b)
																																				{
																																					goto end_IL_088d;
																																				}
																																				goto IL_0aac;
																																				IL_0aac:
																																				if (8 > b)
																																				{
																																					goto end_IL_088d;
																																				}
																																				goto IL_0aba;
																																				IL_0aba:
																																				((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																																				goto IL_0af8;
																																			}
																																			break;
																																		}
																																		goto IL_0994;
																																		IL_0a60:
																																		num5--;
																																		goto IL_2066;
																																		IL_0994:
																																		if (11 >= b)
																																		{
																																			goto IL_099f;
																																		}
																																		goto IL_0a04;
																																		IL_099f:
																																		if (11 <= b)
																																		{
																																			goto IL_09ad;
																																		}
																																		goto IL_0b0b;
																																		IL_09ad:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																																		goto IL_09eb;
																																		IL_09eb:
																																		array2[num5 - 1] = 0;
																																		goto IL_0b98;
																																		IL_0b98:
																																		ptr2 += 8;
																																		goto IL_2066;
																																		IL_0b0b:
																																		if (10 < b)
																																		{
																																			goto end_IL_088d;
																																		}
																																		goto IL_0b19;
																																		IL_0b19:
																																		if (10 > b)
																																		{
																																			goto end_IL_088d;
																																		}
																																		goto IL_0b27;
																																		IL_0b27:
																																		array3[num5] = array7[*(int*)(ptr2 + num3)];
																																		goto IL_0b3f;
																																		IL_0b3f:
																																		array2[num5] = 5;
																																		num = 147;
																																		goto IL_0b56;
																																		IL_0b56:
																																		num5++;
																																		goto IL_0b64;
																																		IL_0b64:
																																		ptr2 += 8;
																																		goto IL_2066;
																																		IL_0a04:
																																		if (12 < b)
																																		{
																																			goto end_IL_088d;
																																		}
																																		goto IL_0a12;
																																		IL_0a12:
																																		if (12 > b)
																																		{
																																			goto end_IL_088d;
																																		}
																																		goto IL_0a20;
																																		IL_0a20:
																																		reference = ref array5[*(int*)(ptr2 + num3)];
																																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																		num = 56;
																																		goto IL_0a52;
																																		IL_0a52:
																																		ptr2 += 8;
																																		goto IL_0a60;
																																	}
																																	break;
																																}
																																goto IL_0bdf;
																																IL_0e9d:
																																if (4 > b)
																																{
																																	goto end_IL_088d;
																																}
																																num = 270;
																																goto IL_0eb4;
																																IL_0bdf:
																																if (6 <= b)
																																{
																																	goto IL_0bed;
																																}
																																goto IL_0c7b;
																																IL_0bed:
																																array2[num5] = array2[num5 - 1];
																																goto IL_0c05;
																																IL_0c05:
																																array4[num5 - 0] = array4[num5 - 1];
																																goto IL_0c23;
																																IL_0c23:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_0c47;
																																IL_0c47:
																																array3[num5] = array3[num5 - 1];
																																goto IL_0c5f;
																																IL_0c5f:
																																num5++;
																																num = 466;
																																goto IL_2066;
																																IL_0c7b:
																																if (3 >= b)
																																{
																																	goto IL_0c89;
																																}
																																goto IL_0e34;
																																IL_0c89:
																																if (3 > b)
																																{
																																	goto IL_0c97;
																																}
																																goto IL_0dec;
																																IL_0c97:
																																if (1 < b)
																																{
																																	goto IL_0ca2;
																																}
																																goto IL_0cfd;
																																IL_0ca2:
																																if (2 < b)
																																{
																																	goto end_IL_088d;
																																}
																																goto IL_0cb0;
																																IL_0cb0:
																																if (2 > b)
																																{
																																	goto end_IL_088d;
																																}
																																goto IL_0cbe;
																																IL_0cbe:
																																array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																																goto IL_0cdc;
																																IL_0cdc:
																																ptr2 += 8;
																																goto IL_0cea;
																																IL_0cea:
																																num5--;
																																goto IL_2066;
																																IL_0cfd:
																																if (1 > b)
																																{
																																	goto end_IL_088d;
																																}
																																goto IL_0d0b;
																																IL_0d0b:
																																array8 = array3;
																																num6 = num5;
																																if (array == null)
																																{
																																	goto IL_0d1a;
																																}
																																num7 = ptr2;
																																byte b2 = *num7;
																																ptr2 = num7 + 4;
																																int num8 = *(int*)(ptr2 + num3);
																																ptr2 += 8;
																																byte* ptr3 = ptr2 + num8;
																																byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																																while (ptr2 != ptr3)
																																{
																																	*ptr4 = (byte)(*ptr2 ^ b2);
																																	ptr2++;
																																	ptr4++;
																																}
																																array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																																goto IL_0dc2;
																																IL_0f08:
																																num5--;
																																goto IL_2066;
																																IL_0eb4:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_0ef4;
																																IL_0ef4:
																																array2[num5 - 2] = 0;
																																goto IL_0f08;
																																IL_0dc2:
																																array2[num5] = 5;
																																goto IL_0dd0;
																																IL_0dd0:
																																num5++;
																																num = 52;
																																goto IL_2066;
																																IL_0dec:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																																goto IL_0e05;
																																IL_0e05:
																																array2[num5] = 0;
																																goto IL_0e13;
																																IL_0e13:
																																num5++;
																																goto IL_0e21;
																																IL_0e21:
																																ptr2 += 8;
																																goto IL_2066;
																																IL_0e34:
																																if (4 < b)
																																{
																																	goto IL_0e3f;
																																}
																																goto IL_0e9d;
																																IL_0e3f:
																																if (5 < b)
																																{
																																	goto end_IL_088d;
																																}
																																goto IL_0e4d;
																																IL_0e4d:
																																if (5 > b)
																																{
																																	goto end_IL_088d;
																																}
																																goto IL_0e5b;
																																IL_0e5b:
																																array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																																goto IL_0e84;
																																IL_0e84:
																																array2[num5 - 1] = 5;
																																goto IL_2066;
																															}
																															break;
																														}
																														goto IL_0941;
																														IL_0b77:
																														num5++;
																														goto IL_0b85;
																														IL_0b85:
																														ptr2 += 8;
																														goto IL_2066;
																														IL_0941:
																														array2[num5] = 0;
																														goto IL_094f;
																														IL_094f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																														goto IL_0972;
																														IL_0972:
																														array3[num5] = null;
																														goto IL_0b77;
																													}
																													break;
																												}
																												goto IL_0f1b;
																												IL_1469:
																												array2[num5 - 1] = 5;
																												goto IL_147d;
																												IL_0f1b:
																												if (19 < b)
																												{
																													goto IL_0f29;
																												}
																												goto IL_11f5;
																												IL_0f29:
																												if (22 >= b)
																												{
																													goto IL_0f37;
																												}
																												goto IL_101c;
																												IL_0f37:
																												if (22 <= b)
																												{
																													goto IL_0f42;
																												}
																												goto IL_0f8f;
																												IL_0f42:
																												array3[num5] = ((delegate*<List<string>>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																												goto IL_0f60;
																												IL_0f60:
																												array2[num5] = 5;
																												goto IL_0f6e;
																												IL_0f6e:
																												num5++;
																												goto IL_0f7c;
																												IL_0f7c:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_0f8f:
																												if (20 >= b)
																												{
																													goto IL_0f9a;
																												}
																												goto IL_0fe8;
																												IL_0f9a:
																												if (20 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_0fa8;
																												IL_0fa8:
																												((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).string_2 = (string)array3[num5 - 1];
																												goto IL_0fd5;
																												IL_0fd5:
																												num5 -= 2;
																												goto IL_2066;
																												IL_0fe8:
																												if (21 < b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_0ff6;
																												IL_0ff6:
																												if (21 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1004;
																												IL_1004:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_2066;
																												IL_101c:
																												if (24 < b)
																												{
																													goto IL_102a;
																												}
																												goto IL_10e4;
																												IL_102a:
																												if (25 < b)
																												{
																													num = 45;
																													goto end_IL_088d;
																												}
																												goto IL_1038;
																												IL_1038:
																												if (25 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1046;
																												IL_1046:
																												array2[num5 - 2] = 0;
																												num = 305;
																												goto IL_1063;
																												IL_1063:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = (((delegate*<string, string, bool>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]) ? 1 : 0);
																												goto IL_10b5;
																												IL_10b5:
																												num5--;
																												goto IL_10c3;
																												IL_10c3:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_147d:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_10e4:
																												if (24 <= b)
																												{
																													goto IL_10ef;
																												}
																												goto IL_1157;
																												IL_10ef:
																												array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																												num = 117;
																												goto IL_1130;
																												IL_1130:
																												array2[num5 - 1] = 5;
																												goto IL_1144;
																												IL_1144:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_1157:
																												if (23 < b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1165;
																												IL_1165:
																												if (23 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1173;
																												IL_1173:
																												array2[num5 - 2] = 5;
																												goto IL_1187;
																												IL_1187:
																												array3[num5 - 2] = ((delegate*<List<string>, int, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																												goto IL_11d4;
																												IL_11d4:
																												num5--;
																												goto IL_11e2;
																												IL_11e2:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_11f5:
																												if (19 <= b)
																												{
																													goto IL_1200;
																												}
																												goto IL_125f;
																												IL_1200:
																												array2[num5 - 1] = 5;
																												goto IL_1214;
																												IL_1214:
																												array3[num5 - 1] = ((delegate*<string, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																												goto IL_124c;
																												IL_124c:
																												ptr2 += 8;
																												goto IL_2066;
																												IL_125f:
																												if (16 >= b)
																												{
																													goto IL_126d;
																												}
																												goto IL_13b2;
																												IL_126d:
																												if (16 > b)
																												{
																													goto IL_127b;
																												}
																												goto IL_138d;
																												IL_127b:
																												if (14 < b)
																												{
																													goto IL_1289;
																												}
																												goto IL_131a;
																												IL_1289:
																												if (15 < b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1297;
																												IL_1297:
																												if (15 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_12a5;
																												IL_12a5:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_1307;
																												IL_1307:
																												num5 -= 2;
																												goto IL_2066;
																												IL_131a:
																												if (14 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1328;
																												IL_1328:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_137a;
																												IL_137a:
																												num5--;
																												goto IL_2066;
																												IL_138d:
																												num9 = ptr2;
																												num10 = -200;
																												num4 = 1;
																												ptr2 = num9 + num10;
																												num = 476;
																												goto IL_2066;
																												IL_13b2:
																												if (17 >= b)
																												{
																													goto IL_13bd;
																												}
																												goto IL_1415;
																												IL_13bd:
																												if (17 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_13cb;
																												IL_13cb:
																												((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																												num = 119;
																												goto IL_1402;
																												IL_1402:
																												num5 -= 2;
																												goto IL_2066;
																												IL_1415:
																												if (18 < b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1423;
																												IL_1423:
																												if (18 > b)
																												{
																													goto end_IL_088d;
																												}
																												goto IL_1431;
																												IL_1431:
																												array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																												goto IL_1469;
																											}
																											break;
																										}
																										goto IL_08d8;
																										IL_0981:
																										num5--;
																										goto IL_2066;
																										IL_08d8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0918;
																										IL_0918:
																										array2[num5 - 2] = 0;
																										goto IL_0981;
																									}
																									break;
																								}
																								goto IL_1490;
																								IL_1fb9:
																								array3[num5 - 1] = ((delegate*<UnityWebRequest, AudioClip>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																								goto IL_1ff1;
																								IL_1490:
																								if (39 < b)
																								{
																									goto IL_149e;
																								}
																								goto IL_19d6;
																								IL_149e:
																								if (45 < b)
																								{
																									goto IL_14ac;
																								}
																								goto IL_1733;
																								IL_14ac:
																								if (48 < b)
																								{
																									goto IL_14ba;
																								}
																								goto IL_1625;
																								IL_14ba:
																								if (50 < b)
																								{
																									goto IL_14c5;
																								}
																								goto IL_14e6;
																								IL_14c5:
																								if (51 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_14d3;
																								IL_14d3:
																								if (51 > b)
																								{
																								}
																								goto end_IL_088d;
																								IL_14e6:
																								if (50 > b)
																								{
																									goto IL_14f4;
																								}
																								num = 187;
																								goto IL_159a;
																								IL_14f4:
																								if (49 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1502;
																								IL_1502:
																								if (49 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1510;
																								IL_1510:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_157e;
																								IL_157e:
																								num5 -= 2;
																								goto IL_2066;
																								IL_1ff1:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_159a:
																								array2[num5 - 2] = 5;
																								num = 461;
																								goto IL_15b7;
																								IL_15b7:
																								array3[num5 - 2] = ((delegate*<List<AudioClip>, int, AudioClip>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																								goto IL_1604;
																								IL_1604:
																								num5--;
																								goto IL_1612;
																								IL_1612:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1625:
																								if (48 > b)
																								{
																									goto IL_1633;
																								}
																								goto IL_16ce;
																								IL_1633:
																								if (46 < b)
																								{
																									goto IL_163e;
																								}
																								goto IL_1695;
																								IL_163e:
																								if (47 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_164c;
																								IL_164c:
																								if (47 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_165a;
																								IL_165a:
																								((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequest_0 = (UnityWebRequest)array3[num5 - 1];
																								goto IL_1682;
																								IL_1682:
																								num5 -= 2;
																								goto IL_2066;
																								IL_1695:
																								if (46 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_16a3;
																								IL_16a3:
																								array3[num5] = null;
																								goto IL_16ad;
																								IL_16ad:
																								array2[num5] = 5;
																								goto IL_16bb;
																								IL_16bb:
																								num5++;
																								goto IL_2066;
																								IL_16ce:
																								array2[num5 - 1] = 0;
																								goto IL_16e2;
																								IL_16e2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<List<AudioClip>, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 1]);
																								goto IL_1720;
																								IL_1720:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1733:
																								if (45 <= b)
																								{
																									goto IL_173e;
																								}
																								goto IL_1788;
																								IL_173e:
																								((delegate*<AudioClip, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((AudioClip)array3[num5 - 1]);
																								goto IL_1767;
																								IL_1767:
																								num5--;
																								goto IL_1775;
																								IL_1775:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1788:
																								if (42 < b)
																								{
																									goto IL_1796;
																								}
																								goto IL_1880;
																								IL_1796:
																								if (43 >= b)
																								{
																									goto IL_17a1;
																								}
																								goto IL_17fc;
																								IL_17a1:
																								if (43 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_17af;
																								IL_17af:
																								array3[num5] = ((delegate*<string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																								goto IL_17cd;
																								IL_17cd:
																								array2[num5] = 5;
																								goto IL_17db;
																								IL_17db:
																								num5++;
																								goto IL_17e9;
																								IL_17e9:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_17fc:
																								if (44 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_180a;
																								IL_180a:
																								if (44 > b)
																								{
																									goto end_IL_088d;
																								}
																								num = 222;
																								goto IL_1821;
																								IL_2001:
																								if (38 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_200c;
																								IL_1821:
																								array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																								goto IL_1859;
																								IL_1859:
																								array2[num5 - 1] = 5;
																								goto IL_186d;
																								IL_186d:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1880:
																								if (42 <= b)
																								{
																									goto IL_188b;
																								}
																								goto IL_18f2;
																								IL_188b:
																								((delegate*<List<AudioClip>, AudioClip, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 2], (AudioClip)array3[num5 - 1]);
																								goto IL_18c8;
																								IL_18c8:
																								num5 -= 2;
																								goto IL_18d6;
																								IL_18d6:
																								ptr2 += 8;
																								num = 228;
																								goto IL_2066;
																								IL_18f2:
																								if (40 < b)
																								{
																									goto IL_18fd;
																								}
																								num = 403;
																								goto IL_197b;
																								IL_18fd:
																								if (41 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_190b;
																								IL_190b:
																								if (41 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1919;
																								IL_1919:
																								array2[num5] = 5;
																								num = 374;
																								goto IL_1930;
																								IL_1930:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								num = 169;
																								goto IL_1951;
																								IL_1951:
																								num5++;
																								goto IL_195f;
																								IL_195f:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_200c:
																								if (38 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_2017;
																								IL_197b:
																								if (40 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1989;
																								IL_1989:
																								array3[num5] = ((delegate*<List<AudioClip>>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																								goto IL_19a7;
																								IL_19a7:
																								array2[num5] = 5;
																								goto IL_19b5;
																								IL_19b5:
																								num5++;
																								goto IL_19c3;
																								IL_19c3:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_19d6:
																								if (39 <= b)
																								{
																									goto IL_19e1;
																								}
																								goto IL_1a3f;
																								IL_19e1:
																								((delegate*<List<string>, string, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 2], (string)array3[num5 - 1]);
																								goto IL_1a1e;
																								IL_1a1e:
																								num5 -= 2;
																								goto IL_1a2c;
																								IL_1a2c:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1a3f:
																								if (32 >= b)
																								{
																									goto IL_1a4d;
																								}
																								goto IL_1d9d;
																								IL_1a4d:
																								if (32 > b)
																								{
																									goto IL_1a5b;
																								}
																								goto IL_1d54;
																								IL_1a5b:
																								if (29 < b)
																								{
																									goto IL_1a69;
																								}
																								num = 34;
																								goto IL_1bb6;
																								IL_1a69:
																								if (30 < b)
																								{
																									goto IL_1a77;
																								}
																								goto IL_1b1e;
																								IL_1a77:
																								if (31 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1a85;
																								IL_1a85:
																								if (31 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1a93;
																								IL_1a93:
																								array2[num5 - 2] = 5;
																								goto IL_1aa7;
																								IL_1aa7:
																								array3[num5 - 2] = ((delegate*<string, AudioType, UnityWebRequest>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], *(AudioType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																								goto IL_1af4;
																								IL_1af4:
																								num5--;
																								goto IL_1b02;
																								IL_1b02:
																								ptr2 += 8;
																								num = 95;
																								goto IL_2066;
																								IL_1b1e:
																								if (30 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1b2c;
																								IL_1b2c:
																								array2[num5 - 2] = 5;
																								goto IL_1b40;
																								IL_1b40:
																								array3[num5 - 2] = ((delegate*<string, string, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																								goto IL_1b8c;
																								IL_1b8c:
																								num5--;
																								goto IL_1b9a;
																								IL_1b9a:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_2017:
																								array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_2035;
																								IL_1bb6:
																								if (29 > b)
																								{
																									goto IL_1bc4;
																								}
																								goto IL_1cd3;
																								IL_1bc4:
																								if (27 >= b)
																								{
																									goto IL_1bcf;
																								}
																								goto IL_1c42;
																								IL_1bcf:
																								if (27 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1bdd;
																								IL_1bdd:
																								array2[num5 - 1] = 0;
																								goto IL_1bf1;
																								IL_1bf1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<List<string>, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 1]);
																								goto IL_1c2f;
																								IL_1c2f:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1c42:
																								if (28 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1c50;
																								IL_1c50:
																								if (28 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1c5e;
																								IL_1c5e:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1cc0;
																								IL_1cc0:
																								num5 -= 2;
																								goto IL_2066;
																								IL_1cd3:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1d41;
																								IL_1d41:
																								num5 -= 2;
																								goto IL_2066;
																								IL_1d54:
																								((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequest_0 = (UnityWebRequest)array3[num5 - 1];
																								goto IL_1d81;
																								IL_1d81:
																								num5 -= 2;
																								num = 451;
																								goto IL_2066;
																								IL_1d9d:
																								if (35 >= b)
																								{
																									goto IL_1dab;
																								}
																								goto IL_1efd;
																								IL_1dab:
																								if (35 <= b)
																								{
																									goto IL_1db6;
																								}
																								goto IL_1dff;
																								IL_1db6:
																								((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequestAsyncOperation_0 = (UnityWebRequestAsyncOperation)array3[num5 - 1];
																								num = 90;
																								goto IL_1dec;
																								IL_1dec:
																								num5 -= 2;
																								goto IL_2066;
																								IL_1dff:
																								if (33 >= b)
																								{
																									goto IL_1e0a;
																								}
																								goto IL_1e77;
																								IL_1e0a:
																								if (33 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1e18;
																								IL_1e18:
																								array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, UnityWebRequest>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																								goto IL_1e50;
																								IL_1e50:
																								array2[num5 - 1] = 5;
																								goto IL_1e64;
																								IL_1e64:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_1e77:
																								if (34 < b)
																								{
																									num = 38;
																									goto end_IL_088d;
																								}
																								goto IL_1e82;
																								IL_1e82:
																								if (34 > b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1e90;
																								IL_1e90:
																								array2[num5 - 1] = 5;
																								goto IL_1ea4;
																								IL_1ea4:
																								array3[num5 - 1] = ((delegate*<UnityWebRequest, UnityWebRequestAsyncOperation>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																								goto IL_1edc;
																								IL_1edc:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_2035:
																								ptr2 += 8;
																								goto IL_2043;
																								IL_1efd:
																								if (37 >= b)
																								{
																									goto IL_1f0b;
																								}
																								goto IL_2001;
																								IL_1f0b:
																								if (37 > b)
																								{
																									goto IL_1f19;
																								}
																								goto IL_1fa5;
																								IL_1f19:
																								if (36 < b)
																								{
																									goto end_IL_088d;
																								}
																								goto IL_1f27;
																								IL_1f27:
																								if (36 > b)
																								{
																									num = 215;
																									goto end_IL_088d;
																								}
																								goto IL_1f32;
																								IL_1f32:
																								array2[num5 - 1] = 0;
																								goto IL_1f46;
																								IL_1f46:
																								*(UnityWebRequest.Result*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<UnityWebRequest, UnityWebRequest.Result>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																								goto IL_1f84;
																								IL_1f84:
																								ptr2 += 8;
																								goto IL_2066;
																								IL_2043:
																								num5--;
																								goto IL_2066;
																								IL_1fa5:
																								array2[num5 - 1] = 5;
																								goto IL_1fb9;
																							}
																							goto end_IL_089d;
																							continue;
																							end_IL_088d:
																							break;
																							IL_088d:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_2066;
																					continue;
																					end_IL_089d:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	num = 349;
																	goto IL_2144;
																	IL_2144:
																	return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) != 0;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0d1a:
				while (true)
				{
					IL_0d1a_2:
					array = new byte[4];
					while (true)
					{
						IL_0d28:
						num7 = ptr2;
						byte b2 = *num7;
						ptr2 = num7 + 4;
						int num8 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num8;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num5] = 5;
							while (true)
							{
								IL_0dd0_2:
								num5++;
								num = 52;
								while (true)
								{
									IL_2066_2:
									if (num4 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_089d_2:
													if (b >= 1)
													{
														while (b <= 51)
														{
															while (true)
															{
																if (26 >= b)
																{
																	while (true)
																	{
																		if (26 > b)
																		{
																			while (true)
																			{
																				if (13 >= b)
																				{
																					while (true)
																					{
																						if (13 > b)
																						{
																							num = 452;
																							while (true)
																							{
																								if (6 < b)
																								{
																									while (true)
																									{
																										if (9 >= b)
																										{
																											while (true)
																											{
																												if (9 <= b)
																												{
																													while (true)
																													{
																														array2[num5 - 1] = 5;
																														while (true)
																														{
																															IL_07c4_2:
																															array3[num5 - 1] = ((delegate*<string[], string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																															num = 485;
																															while (true)
																															{
																																if (num != 485)
																																{
																																	if (num != 1466)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 125:
																																		goto IL_07c4_2;
																																	case 126:
																																	case 464:
																																		goto end_IL_07b1_2;
																																	case 105:
																																		goto end_IL_0807_2;
																																	case 66:
																																	case 416:
																																		goto end_IL_081d;
																																	case 101:
																																	case 452:
																																		goto end_IL_082d;
																																	case 159:
																																		goto end_IL_083d;
																																	case 128:
																																		goto end_IL_084d;
																																	case 186:
																																		goto end_IL_0860;
																																	case 235:
																																		goto end_IL_0870;
																																	case 372:
																																		goto end_IL_087d;
																																	case 80:
																																		goto IL_089d_2;
																																	case 468:
																																		goto end_IL_089d_2;
																																	case 1:
																																	case 108:
																																		goto end_IL_08ad;
																																	case 49:
																																		goto IL_08c8_2;
																																	case 8:
																																	case 225:
																																		goto IL_08d8_2;
																																	case 70:
																																		goto IL_0918_2;
																																	case 282:
																																		goto IL_092e_2;
																																	case 212:
																																	case 285:
																																		goto IL_0941_2;
																																	case 58:
																																		goto IL_094f_2;
																																	case 93:
																																		goto IL_0972_2;
																																	case 388:
																																		goto IL_0981_2;
																																	case 139:
																																	case 418:
																																		goto IL_0994_2;
																																	case 137:
																																		goto IL_099f_2;
																																	case 2:
																																	case 366:
																																		goto IL_09ad_2;
																																	case 320:
																																		goto IL_09eb_2;
																																	case 122:
																																		goto IL_0a04_2;
																																	case 69:
																																		goto IL_0a12_2;
																																	case 410:
																																	case 411:
																																		goto IL_0a20_2;
																																	case 56:
																																		goto IL_0a52_2;
																																	case 213:
																																		goto IL_0a60_2;
																																	case 424:
																																		goto IL_0a73_2;
																																	case 216:
																																	case 404:
																																		goto IL_0a81_2;
																																	case 266:
																																		goto IL_0a8f_2;
																																	case 425:
																																		goto IL_0aac_2;
																																	case 227:
																																	case 332:
																																		goto IL_0aba_2;
																																	case 167:
																																		goto IL_0af8_2;
																																	case 427:
																																	case 428:
																																		goto IL_0b0b_2;
																																	case 28:
																																		goto IL_0b19_2;
																																	case 155:
																																	case 220:
																																		goto IL_0b27_2;
																																	case 419:
																																		goto IL_0b3f_2;
																																	case 147:
																																		goto IL_0b56_2;
																																	case 326:
																																		goto IL_0b64_2;
																																	case 430:
																																		goto IL_0b77_2;
																																	case 118:
																																		goto IL_0b85_2;
																																	case 449:
																																		goto IL_0b98_2;
																																	case 467:
																																		goto IL_0bab_2;
																																	case 192:
																																		goto IL_0bb9_2;
																																	case 478:
																																		goto IL_0bdf_2;
																																	case 84:
																																	case 380:
																																		goto IL_0bed_2;
																																	case 460:
																																		goto IL_0c05_2;
																																	case 244:
																																		goto IL_0c23_2;
																																	case 59:
																																		goto IL_0c47_2;
																																	case 64:
																																		goto IL_0c5f_2;
																																	case 206:
																																		goto IL_0c7b_2;
																																	case 336:
																																		goto IL_0c89_2;
																																	case 229:
																																	case 296:
																																		goto IL_0c97_2;
																																	case 163:
																																	case 173:
																																		goto IL_0ca2_2;
																																	case 398:
																																		goto IL_0cb0_2;
																																	case 268:
																																	case 470:
																																		goto IL_0cbe_2;
																																	case 164:
																																		goto IL_0cdc_2;
																																	case 67:
																																		goto IL_0cea_2;
																																	case 272:
																																		goto IL_0cfd_2;
																																	case 217:
																																	case 420:
																																		goto IL_0d0b_2;
																																	case 29:
																																		goto end_IL_08bd;
																																	case 26:
																																		goto IL_0dd0_2;
																																	case 245:
																																	case 362:
																																		goto IL_0dec_2;
																																	case 19:
																																		goto IL_0e05_2;
																																	case 31:
																																		goto IL_0e13_2;
																																	case 475:
																																		goto IL_0e21_2;
																																	case 281:
																																		goto IL_0e34_2;
																																	case 87:
																																	case 307:
																																		goto IL_0e3f_2;
																																	case 22:
																																		goto IL_0e4d_2;
																																	case 39:
																																	case 188:
																																		goto IL_0e5b_2;
																																	case 434:
																																		goto IL_0e84_2;
																																	case 161:
																																		goto IL_0e9d_2;
																																	case 270:
																																	case 290:
																																		goto IL_0eb4_2;
																																	case 43:
																																		goto IL_0ef4_2;
																																	case 368:
																																		goto IL_0f08_2;
																																	case 210:
																																		goto IL_0f1b_2;
																																	case 104:
																																	case 143:
																																		goto IL_0f29_2;
																																	case 243:
																																		goto IL_0f37_2;
																																	case 453:
																																	case 474:
																																		goto IL_0f42_2;
																																	case 396:
																																		goto IL_0f60_2;
																																	case 214:
																																		goto IL_0f6e_2;
																																	case 471:
																																		goto IL_0f7c_2;
																																	case 376:
																																		goto IL_0f8f_2;
																																	case 395:
																																		goto IL_0f9a_2;
																																	case 68:
																																	case 196:
																																		goto IL_0fa8_2;
																																	case 444:
																																		goto IL_0fd5_2;
																																	case 351:
																																		goto IL_0fe8_2;
																																	case 178:
																																		goto IL_0ff6_2;
																																	case 172:
																																	case 322:
																																		goto IL_1004_2;
																																	case 197:
																																		goto IL_101c_2;
																																	case 134:
																																	case 238:
																																		goto IL_102a_2;
																																	case 413:
																																		goto IL_1038_2;
																																	case 149:
																																	case 341:
																																		goto IL_1046_2;
																																	case 305:
																																		goto IL_1063_2;
																																	case 249:
																																		goto IL_10b5_2;
																																	case 140:
																																		goto IL_10c3_2;
																																	case 72:
																																		goto IL_10e4_2;
																																	case 310:
																																	case 317:
																																		goto IL_10ef_2;
																																	case 117:
																																		goto IL_1130_2;
																																	case 250:
																																		goto IL_1144_2;
																																	case 7:
																																		goto IL_1157_2;
																																	case 10:
																																		goto IL_1165_2;
																																	case 257:
																																	case 258:
																																		goto IL_1173_2;
																																	case 312:
																																		goto IL_1187_2;
																																	case 40:
																																		goto IL_11d4_2;
																																	case 144:
																																		goto IL_11e2_2;
																																	case 234:
																																		goto IL_11f5_2;
																																	case 201:
																																	case 446:
																																		goto IL_1200_2;
																																	case 299:
																																		goto IL_1214_2;
																																	case 157:
																																		goto IL_124c_2;
																																	case 138:
																																		goto IL_125f_2;
																																	case 318:
																																		goto IL_126d_2;
																																	case 284:
																																		goto IL_127b_2;
																																	case 204:
																																		goto IL_1289_2;
																																	case 343:
																																		goto IL_1297_2;
																																	case 265:
																																	case 348:
																																		goto IL_12a5_2;
																																	case 435:
																																		goto IL_1307_2;
																																	case 262:
																																		goto IL_131a_2;
																																	case 17:
																																	case 277:
																																		goto IL_1328_2;
																																	case 98:
																																		goto IL_137a_2;
																																	case 223:
																																	case 365:
																																		goto IL_138d_2;
																																	case 389:
																																		goto IL_13b2_2;
																																	case 454:
																																		goto IL_13bd_2;
																																	case 280:
																																	case 423:
																																		goto IL_13cb_2;
																																	case 119:
																																		goto IL_1402_2;
																																	case 392:
																																		goto IL_1415_2;
																																	case 417:
																																		goto IL_1423_2;
																																	case 146:
																																	case 198:
																																		goto IL_1431_2;
																																	case 180:
																																		goto IL_1469_2;
																																	case 261:
																																		goto IL_147d_2;
																																	case 251:
																																		goto IL_1490_2;
																																	case 110:
																																	case 230:
																																		goto IL_149e_2;
																																	case 203:
																																	case 291:
																																		goto IL_14ac_2;
																																	case 106:
																																	case 390:
																																		goto IL_14ba_2;
																																	case 335:
																																	case 393:
																																		goto IL_14c5_2;
																																	case 363:
																																		goto IL_14d3_2;
																																	case 202:
																																		goto IL_14e6_2;
																																	case 231:
																																		goto IL_14f4_2;
																																	case 33:
																																		goto IL_1502_2;
																																	case 340:
																																	case 383:
																																		goto IL_1510_2;
																																	case 18:
																																		goto IL_157e_2;
																																	case 187:
																																	case 458:
																																		goto IL_159a_2;
																																	case 461:
																																		goto IL_15b7_2;
																																	case 328:
																																		goto IL_1604_2;
																																	case 269:
																																		goto IL_1612_2;
																																	case 401:
																																		goto IL_1625_2;
																																	case 100:
																																	case 463:
																																		goto IL_1633_2;
																																	case 113:
																																	case 292:
																																		goto IL_163e_2;
																																	case 99:
																																		goto IL_164c_2;
																																	case 32:
																																	case 432:
																																		goto IL_165a_2;
																																	case 455:
																																		goto IL_1682_2;
																																	case 37:
																																		goto IL_1695_2;
																																	case 301:
																																	case 308:
																																		goto IL_16a3_2;
																																	case 394:
																																		goto IL_16ad_2;
																																	case 174:
																																		goto IL_16bb_2;
																																	case 181:
																																	case 367:
																																		goto IL_16ce_2;
																																	case 177:
																																		goto IL_16e2_2;
																																	case 129:
																																		goto IL_1720_2;
																																	case 352:
																																		goto IL_1733_2;
																																	case 175:
																																	case 254:
																																		goto IL_173e_2;
																																	case 221:
																																		goto IL_1767_2;
																																	case 182:
																																		goto IL_1775_2;
																																	case 431:
																																		goto IL_1788_2;
																																	case 194:
																																	case 286:
																																		goto IL_1796_2;
																																	case 61:
																																		goto IL_17a1_2;
																																	case 13:
																																	case 439:
																																		goto IL_17af_2;
																																	case 111:
																																		goto IL_17cd_2;
																																	case 240:
																																		goto IL_17db_2;
																																	case 42:
																																		goto IL_17e9_2;
																																	case 295:
																																		goto IL_17fc_2;
																																	case 278:
																																		goto IL_180a_2;
																																	case 154:
																																	case 222:
																																		goto IL_1821_2;
																																	case 236:
																																		goto IL_1859_2;
																																	case 442:
																																		goto IL_186d_2;
																																	case 441:
																																		goto IL_1880_2;
																																	case 21:
																																	case 162:
																																		goto IL_188b_2;
																																	case 377:
																																		goto IL_18c8_2;
																																	case 371:
																																		goto IL_18d6_2;
																																	case 397:
																																		goto IL_18f2_2;
																																	case 116:
																																		goto IL_18fd_2;
																																	case 421:
																																		goto IL_190b_2;
																																	case 54:
																																	case 131:
																																		goto IL_1919_2;
																																	case 374:
																																		goto IL_1930_2;
																																	case 169:
																																		goto IL_1951_2;
																																	case 151:
																																		goto IL_195f_2;
																																	case 403:
																																		goto IL_197b_2;
																																	case 136:
																																	case 314:
																																		goto IL_1989_2;
																																	case 16:
																																		goto IL_19a7_2;
																																	case 179:
																																		goto IL_19b5_2;
																																	case 450:
																																		goto IL_19c3_2;
																																	case 275:
																																		goto IL_19d6_2;
																																	case 218:
																																	case 267:
																																		goto IL_19e1_2;
																																	case 355:
																																		goto IL_1a1e_2;
																																	case 248:
																																		goto IL_1a2c_2;
																																	case 259:
																																	case 473:
																																		goto IL_1a3f_2;
																																	case 46:
																																		goto IL_1a4d_2;
																																	case 4:
																																	case 232:
																																		goto IL_1a5b_2;
																																	case 347:
																																		goto IL_1a69_2;
																																	case 44:
																																	case 369:
																																		goto IL_1a77_2;
																																	case 226:
																																		goto IL_1a85_2;
																																	case 25:
																																	case 311:
																																		goto IL_1a93_2;
																																	case 289:
																																		goto IL_1aa7_2;
																																	case 448:
																																		goto IL_1af4_2;
																																	case 81:
																																		goto IL_1b02_2;
																																	case 35:
																																		goto IL_1b1e_2;
																																	case 114:
																																	case 293:
																																		goto IL_1b2c_2;
																																	case 360:
																																		goto IL_1b40_2;
																																	case 379:
																																		goto IL_1b8c_2;
																																	case 135:
																																		goto IL_1b9a_2;
																																	case 34:
																																		goto IL_1bb6_2;
																																	case 107:
																																	case 199:
																																		goto IL_1bc4_2;
																																	case 23:
																																		goto IL_1bcf_2;
																																	case 30:
																																	case 150:
																																		goto IL_1bdd_2;
																																	case 79:
																																		goto IL_1bf1_2;
																																	case 276:
																																		goto IL_1c2f_2;
																																	case 264:
																																		goto IL_1c42_2;
																																	case 241:
																																		goto IL_1c50_2;
																																	case 339:
																																	case 433:
																																		goto IL_1c5e_2;
																																	case 246:
																																		goto IL_1cc0_2;
																																	case 313:
																																	case 477:
																																		goto IL_1cd3_2;
																																	case 381:
																																		goto IL_1d41_2;
																																	case 346:
																																	case 386:
																																		goto IL_1d54_2;
																																	case 350:
																																		goto IL_1d81_2;
																																	case 130:
																																		goto IL_1d9d_2;
																																	case 53:
																																		goto IL_1dab_2;
																																	case 62:
																																	case 63:
																																		goto IL_1db6_2;
																																	case 90:
																																		goto IL_1dec_2;
																																	case 415:
																																		goto IL_1dff_2;
																																	case 465:
																																		goto IL_1e0a_2;
																																	case 133:
																																	case 344:
																																		goto IL_1e18_2;
																																	case 255:
																																		goto IL_1e50_2;
																																	case 233:
																																		goto IL_1e64_2;
																																	case 207:
																																		goto IL_1e77_2;
																																	case 103:
																																		goto IL_1e82_2;
																																	case 145:
																																	case 402:
																																		goto IL_1e90_2;
																																	case 462:
																																		goto IL_1ea4_2;
																																	case 86:
																																		goto IL_1edc_2;
																																	case 358:
																																		goto IL_1efd_2;
																																	case 414:
																																		goto IL_1f0b_2;
																																	case 209:
																																	case 237:
																																		goto IL_1f19_2;
																																	case 438:
																																		goto IL_1f27_2;
																																	case 303:
																																	case 330:
																																		goto IL_1f32_2;
																																	case 337:
																																		goto IL_1f46_2;
																																	case 384:
																																		goto IL_1f84_2;
																																	case 85:
																																	case 385:
																																		goto IL_1fa5_2;
																																	case 36:
																																		goto IL_1fb9_2;
																																	case 333:
																																		goto IL_1ff1_2;
																																	case 171:
																																		goto IL_2001_2;
																																	case 112:
																																		goto IL_200c_2;
																																	case 9:
																																	case 47:
																																		goto IL_2017_2;
																																	case 20:
																																		goto IL_2035_2;
																																	case 168:
																																		goto IL_2043_2;
																																	case 3:
																																	case 5:
																																	case 6:
																																	case 12:
																																	case 14:
																																	case 15:
																																	case 27:
																																	case 38:
																																	case 45:
																																	case 48:
																																	case 51:
																																	case 57:
																																	case 71:
																																	case 73:
																																	case 75:
																																	case 76:
																																	case 77:
																																	case 78:
																																	case 88:
																																	case 91:
																																	case 94:
																																	case 97:
																																	case 102:
																																	case 109:
																																	case 115:
																																	case 123:
																																	case 124:
																																	case 132:
																																	case 158:
																																	case 160:
																																	case 170:
																																	case 176:
																																	case 184:
																																	case 185:
																																	case 189:
																																	case 190:
																																	case 191:
																																	case 193:
																																	case 195:
																																	case 200:
																																	case 205:
																																	case 215:
																																	case 224:
																																	case 239:
																																	case 242:
																																	case 253:
																																	case 256:
																																	case 260:
																																	case 263:
																																	case 271:
																																	case 273:
																																	case 274:
																																	case 294:
																																	case 300:
																																	case 302:
																																	case 304:
																																	case 306:
																																	case 309:
																																	case 315:
																																	case 319:
																																	case 324:
																																	case 325:
																																	case 331:
																																	case 334:
																																	case 342:
																																	case 345:
																																	case 354:
																																	case 356:
																																	case 361:
																																	case 373:
																																	case 375:
																																	case 378:
																																	case 387:
																																	case 391:
																																	case 405:
																																	case 406:
																																	case 408:
																																	case 409:
																																	case 422:
																																	case 436:
																																	case 440:
																																	case 447:
																																	case 457:
																																	case 472:
																																		goto end_IL_088d_2;
																																	case 0:
																																	case 11:
																																	case 24:
																																	case 41:
																																	case 52:
																																	case 55:
																																	case 60:
																																	case 65:
																																	case 74:
																																	case 89:
																																	case 95:
																																	case 120:
																																	case 121:
																																	case 127:
																																	case 141:
																																	case 142:
																																	case 148:
																																	case 152:
																																	case 153:
																																	case 156:
																																	case 183:
																																	case 211:
																																	case 219:
																																	case 228:
																																	case 247:
																																	case 279:
																																	case 283:
																																	case 287:
																																	case 288:
																																	case 297:
																																	case 298:
																																	case 316:
																																	case 321:
																																	case 323:
																																	case 327:
																																	case 353:
																																	case 359:
																																	case 364:
																																	case 370:
																																	case 382:
																																	case 399:
																																	case 400:
																																	case 412:
																																	case 426:
																																	case 429:
																																	case 437:
																																	case 443:
																																	case 445:
																																	case 451:
																																	case 456:
																																	case 459:
																																	case 466:
																																	case 476:
																																		goto IL_2066_2;
																																	case 96:
																																		ptr2 = ptr;
																																		goto IL_2066_2;
																																	case 357:
																																		ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetReferenceIsNestedFamORAssem.getCanTransformMultipleBlocksFindComponentsByDefinition);
																																		goto case 96;
																																	case 329:
																																		array7[0] = this;
																																		goto case 357;
																																	case 50:
																																		array7 = new object[9];
																																		num = 329;
																																		goto case 329;
																																	case 83:
																																		array6 = new long[4];
																																		num = 50;
																																		goto case 50;
																																	case 338:
																																		array5 = new int[3];
																																		goto case 83;
																																	case 252:
																																		array4 = new int[4];
																																		goto case 338;
																																	case 407:
																																		array3 = new object[4];
																																		goto case 252;
																																	case 208:
																																	case 469:
																																		array2 = new byte[4];
																																		goto case 407;
																																	case 92:
																																		num3 = num2 * 4;
																																		goto case 208;
																																	case 165:
																																		num2 = 1;
																																		goto case 92;
																																	case 166:
																																		goto end_IL_0dc2;
																																	case 82:
																																	case 349:
																																		goto IL_2144_2;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto IL_2066_2;
																																continue;
																																end_IL_07b1_2:
																																break;
																															}
																															break;
																														}
																														continue;
																														end_IL_0807_2:
																														break;
																													}
																													continue;
																												}
																												goto IL_08c8_2;
																												IL_0af8_2:
																												num5 -= 3;
																												goto IL_2066_2;
																												IL_08c8_2:
																												if (7 < b)
																												{
																													goto IL_092e_2;
																												}
																												goto IL_0a73_2;
																												IL_0a73_2:
																												if (7 > b)
																												{
																													goto end_IL_088d_2;
																												}
																												goto IL_0a81_2;
																												IL_0a81_2:
																												array2[num5] = 5;
																												goto IL_0a8f_2;
																												IL_0a8f_2:
																												array3[num5] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0bab_2;
																												IL_0bab_2:
																												num5++;
																												goto IL_0bb9_2;
																												IL_0bb9_2:
																												ptr2 += 8;
																												goto IL_2066_2;
																												IL_092e_2:
																												if (8 < b)
																												{
																													goto end_IL_088d_2;
																												}
																												goto IL_0aac_2;
																												IL_0aac_2:
																												if (8 > b)
																												{
																													goto end_IL_088d_2;
																												}
																												goto IL_0aba_2;
																												IL_0aba_2:
																												((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																												goto IL_0af8_2;
																												continue;
																												end_IL_081d:
																												break;
																											}
																											continue;
																										}
																										goto IL_0994_2;
																										IL_0a60_2:
																										num5--;
																										goto IL_2066_2;
																										IL_0994_2:
																										if (11 >= b)
																										{
																											goto IL_099f_2;
																										}
																										goto IL_0a04_2;
																										IL_099f_2:
																										if (11 <= b)
																										{
																											goto IL_09ad_2;
																										}
																										goto IL_0b0b_2;
																										IL_09ad_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																										goto IL_09eb_2;
																										IL_09eb_2:
																										array2[num5 - 1] = 0;
																										goto IL_0b98_2;
																										IL_0b98_2:
																										ptr2 += 8;
																										goto IL_2066_2;
																										IL_0b0b_2:
																										if (10 < b)
																										{
																											goto end_IL_088d_2;
																										}
																										goto IL_0b19_2;
																										IL_0b19_2:
																										if (10 > b)
																										{
																											goto end_IL_088d_2;
																										}
																										goto IL_0b27_2;
																										IL_0b27_2:
																										array3[num5] = array7[*(int*)(ptr2 + num3)];
																										goto IL_0b3f_2;
																										IL_0b3f_2:
																										array2[num5] = 5;
																										num = 147;
																										goto IL_0b56_2;
																										IL_0b56_2:
																										num5++;
																										goto IL_0b64_2;
																										IL_0b64_2:
																										ptr2 += 8;
																										goto IL_2066_2;
																										IL_0a04_2:
																										if (12 < b)
																										{
																											goto end_IL_088d_2;
																										}
																										goto IL_0a12_2;
																										IL_0a12_2:
																										if (12 > b)
																										{
																											goto end_IL_088d_2;
																										}
																										goto IL_0a20_2;
																										IL_0a20_2:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										num = 56;
																										goto IL_0a52_2;
																										IL_0a52_2:
																										ptr2 += 8;
																										goto IL_0a60_2;
																										continue;
																										end_IL_082d:
																										break;
																									}
																									continue;
																								}
																								goto IL_0bdf_2;
																								IL_0ef4_2:
																								array2[num5 - 2] = 0;
																								goto IL_0f08_2;
																								IL_0bdf_2:
																								if (6 <= b)
																								{
																									goto IL_0bed_2;
																								}
																								goto IL_0c7b_2;
																								IL_0bed_2:
																								array2[num5] = array2[num5 - 1];
																								goto IL_0c05_2;
																								IL_0c05_2:
																								array4[num5 - 0] = array4[num5 - 1];
																								goto IL_0c23_2;
																								IL_0c23_2:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0c47_2;
																								IL_0c47_2:
																								array3[num5] = array3[num5 - 1];
																								goto IL_0c5f_2;
																								IL_0c5f_2:
																								num5++;
																								num = 466;
																								goto IL_2066_2;
																								IL_0c7b_2:
																								if (3 >= b)
																								{
																									goto IL_0c89_2;
																								}
																								goto IL_0e34_2;
																								IL_0c89_2:
																								if (3 > b)
																								{
																									goto IL_0c97_2;
																								}
																								goto IL_0dec_2;
																								IL_0c97_2:
																								if (1 < b)
																								{
																									goto IL_0ca2_2;
																								}
																								goto IL_0cfd_2;
																								IL_0ca2_2:
																								if (2 < b)
																								{
																									goto end_IL_088d_2;
																								}
																								goto IL_0cb0_2;
																								IL_0cb0_2:
																								if (2 > b)
																								{
																									goto end_IL_088d_2;
																								}
																								goto IL_0cbe_2;
																								IL_0cbe_2:
																								array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_0cdc_2;
																								IL_0cdc_2:
																								ptr2 += 8;
																								goto IL_0cea_2;
																								IL_0cea_2:
																								num5--;
																								goto IL_2066_2;
																								IL_0cfd_2:
																								if (1 > b)
																								{
																									goto end_IL_088d_2;
																								}
																								goto IL_0d0b_2;
																								IL_0d0b_2:
																								array8 = array3;
																								num6 = num5;
																								if (array == null)
																								{
																									goto IL_0d1a_2;
																								}
																								goto IL_0d28;
																								IL_0dec_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0e05_2;
																								IL_0e05_2:
																								array2[num5] = 0;
																								goto IL_0e13_2;
																								IL_0e13_2:
																								num5++;
																								goto IL_0e21_2;
																								IL_0e21_2:
																								ptr2 += 8;
																								goto IL_2066_2;
																								IL_0e34_2:
																								if (4 < b)
																								{
																									goto IL_0e3f_2;
																								}
																								goto IL_0e9d_2;
																								IL_0e3f_2:
																								if (5 < b)
																								{
																									goto end_IL_088d_2;
																								}
																								goto IL_0e4d_2;
																								IL_0e4d_2:
																								if (5 > b)
																								{
																									goto end_IL_088d_2;
																								}
																								goto IL_0e5b_2;
																								IL_0e5b_2:
																								array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																								goto IL_0e84_2;
																								IL_0e84_2:
																								array2[num5 - 1] = 5;
																								goto IL_2066_2;
																								IL_0e9d_2:
																								if (4 > b)
																								{
																									goto end_IL_088d_2;
																								}
																								num = 270;
																								goto IL_0eb4_2;
																								IL_0f08_2:
																								num5--;
																								goto IL_2066_2;
																								IL_0eb4_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0ef4_2;
																								continue;
																								end_IL_083d:
																								break;
																							}
																							continue;
																						}
																						goto IL_0941_2;
																						IL_0b77_2:
																						num5++;
																						goto IL_0b85_2;
																						IL_0b85_2:
																						ptr2 += 8;
																						goto IL_2066_2;
																						IL_0941_2:
																						array2[num5] = 0;
																						goto IL_094f_2;
																						IL_094f_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0972_2;
																						IL_0972_2:
																						array3[num5] = null;
																						goto IL_0b77_2;
																						continue;
																						end_IL_084d:
																						break;
																					}
																					continue;
																				}
																				goto IL_0f1b_2;
																				IL_1469_2:
																				array2[num5 - 1] = 5;
																				goto IL_147d_2;
																				IL_0f1b_2:
																				if (19 < b)
																				{
																					goto IL_0f29_2;
																				}
																				goto IL_11f5_2;
																				IL_0f29_2:
																				if (22 >= b)
																				{
																					goto IL_0f37_2;
																				}
																				goto IL_101c_2;
																				IL_0f37_2:
																				if (22 <= b)
																				{
																					goto IL_0f42_2;
																				}
																				goto IL_0f8f_2;
																				IL_0f42_2:
																				array3[num5] = ((delegate*<List<string>>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																				goto IL_0f60_2;
																				IL_0f60_2:
																				array2[num5] = 5;
																				goto IL_0f6e_2;
																				IL_0f6e_2:
																				num5++;
																				goto IL_0f7c_2;
																				IL_0f7c_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_0f8f_2:
																				if (20 >= b)
																				{
																					goto IL_0f9a_2;
																				}
																				goto IL_0fe8_2;
																				IL_0f9a_2:
																				if (20 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_0fa8_2;
																				IL_0fa8_2:
																				((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).string_2 = (string)array3[num5 - 1];
																				goto IL_0fd5_2;
																				IL_0fd5_2:
																				num5 -= 2;
																				goto IL_2066_2;
																				IL_0fe8_2:
																				if (21 < b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_0ff6_2;
																				IL_0ff6_2:
																				if (21 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1004_2;
																				IL_1004_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_2066_2;
																				IL_101c_2:
																				if (24 < b)
																				{
																					goto IL_102a_2;
																				}
																				goto IL_10e4_2;
																				IL_102a_2:
																				if (25 < b)
																				{
																					num = 45;
																					goto end_IL_088d_2;
																				}
																				goto IL_1038_2;
																				IL_1038_2:
																				if (25 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1046_2;
																				IL_1046_2:
																				array2[num5 - 2] = 0;
																				num = 305;
																				goto IL_1063_2;
																				IL_1063_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = (((delegate*<string, string, bool>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]) ? 1 : 0);
																				goto IL_10b5_2;
																				IL_10b5_2:
																				num5--;
																				goto IL_10c3_2;
																				IL_10c3_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_147d_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_10e4_2:
																				if (24 <= b)
																				{
																					goto IL_10ef_2;
																				}
																				goto IL_1157_2;
																				IL_10ef_2:
																				array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																				num = 117;
																				goto IL_1130_2;
																				IL_1130_2:
																				array2[num5 - 1] = 5;
																				goto IL_1144_2;
																				IL_1144_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_1157_2:
																				if (23 < b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1165_2;
																				IL_1165_2:
																				if (23 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1173_2;
																				IL_1173_2:
																				array2[num5 - 2] = 5;
																				goto IL_1187_2;
																				IL_1187_2:
																				array3[num5 - 2] = ((delegate*<List<string>, int, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																				goto IL_11d4_2;
																				IL_11d4_2:
																				num5--;
																				goto IL_11e2_2;
																				IL_11e2_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_11f5_2:
																				if (19 <= b)
																				{
																					goto IL_1200_2;
																				}
																				goto IL_125f_2;
																				IL_1200_2:
																				array2[num5 - 1] = 5;
																				goto IL_1214_2;
																				IL_1214_2:
																				array3[num5 - 1] = ((delegate*<string, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																				goto IL_124c_2;
																				IL_124c_2:
																				ptr2 += 8;
																				goto IL_2066_2;
																				IL_125f_2:
																				if (16 >= b)
																				{
																					goto IL_126d_2;
																				}
																				goto IL_13b2_2;
																				IL_126d_2:
																				if (16 > b)
																				{
																					goto IL_127b_2;
																				}
																				goto IL_138d_2;
																				IL_127b_2:
																				if (14 < b)
																				{
																					goto IL_1289_2;
																				}
																				goto IL_131a_2;
																				IL_1289_2:
																				if (15 < b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1297_2;
																				IL_1297_2:
																				if (15 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_12a5_2;
																				IL_12a5_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_1307_2;
																				IL_1307_2:
																				num5 -= 2;
																				goto IL_2066_2;
																				IL_131a_2:
																				if (14 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1328_2;
																				IL_1328_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_137a_2;
																				IL_137a_2:
																				num5--;
																				goto IL_2066_2;
																				IL_138d_2:
																				num9 = ptr2;
																				num10 = -200;
																				num4 = 1;
																				ptr2 = num9 + num10;
																				num = 476;
																				goto IL_2066_2;
																				IL_13b2_2:
																				if (17 >= b)
																				{
																					goto IL_13bd_2;
																				}
																				goto IL_1415_2;
																				IL_13bd_2:
																				if (17 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_13cb_2;
																				IL_13cb_2:
																				((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																				num = 119;
																				goto IL_1402_2;
																				IL_1402_2:
																				num5 -= 2;
																				goto IL_2066_2;
																				IL_1415_2:
																				if (18 < b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1423_2;
																				IL_1423_2:
																				if (18 > b)
																				{
																					goto end_IL_088d_2;
																				}
																				goto IL_1431_2;
																				IL_1431_2:
																				array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																				goto IL_1469_2;
																				continue;
																				end_IL_0860:
																				break;
																			}
																			continue;
																		}
																		goto IL_08d8_2;
																		IL_0981_2:
																		num5--;
																		goto IL_2066_2;
																		IL_08d8_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0918_2;
																		IL_0918_2:
																		array2[num5 - 2] = 0;
																		goto IL_0981_2;
																		continue;
																		end_IL_0870:
																		break;
																	}
																	continue;
																}
																goto IL_1490_2;
																IL_1fb9_2:
																array3[num5 - 1] = ((delegate*<UnityWebRequest, AudioClip>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																goto IL_1ff1_2;
																IL_1490_2:
																if (39 < b)
																{
																	goto IL_149e_2;
																}
																goto IL_19d6_2;
																IL_149e_2:
																if (45 < b)
																{
																	goto IL_14ac_2;
																}
																goto IL_1733_2;
																IL_14ac_2:
																if (48 < b)
																{
																	goto IL_14ba_2;
																}
																goto IL_1625_2;
																IL_14ba_2:
																if (50 < b)
																{
																	goto IL_14c5_2;
																}
																goto IL_14e6_2;
																IL_14c5_2:
																if (51 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_14d3_2;
																IL_14d3_2:
																if (51 > b)
																{
																}
																goto end_IL_088d_2;
																IL_14e6_2:
																if (50 > b)
																{
																	goto IL_14f4_2;
																}
																num = 187;
																goto IL_159a_2;
																IL_14f4_2:
																if (49 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1502_2;
																IL_1502_2:
																if (49 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1510_2;
																IL_1510_2:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_157e_2;
																IL_157e_2:
																num5 -= 2;
																goto IL_2066_2;
																IL_1ff1_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_159a_2:
																array2[num5 - 2] = 5;
																num = 461;
																goto IL_15b7_2;
																IL_15b7_2:
																array3[num5 - 2] = ((delegate*<List<AudioClip>, int, AudioClip>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_1604_2;
																IL_1604_2:
																num5--;
																goto IL_1612_2;
																IL_1612_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1625_2:
																if (48 > b)
																{
																	goto IL_1633_2;
																}
																goto IL_16ce_2;
																IL_1633_2:
																if (46 < b)
																{
																	goto IL_163e_2;
																}
																goto IL_1695_2;
																IL_163e_2:
																if (47 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_164c_2;
																IL_164c_2:
																if (47 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_165a_2;
																IL_165a_2:
																((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequest_0 = (UnityWebRequest)array3[num5 - 1];
																goto IL_1682_2;
																IL_1682_2:
																num5 -= 2;
																goto IL_2066_2;
																IL_1695_2:
																if (46 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_16a3_2;
																IL_16a3_2:
																array3[num5] = null;
																goto IL_16ad_2;
																IL_16ad_2:
																array2[num5] = 5;
																goto IL_16bb_2;
																IL_16bb_2:
																num5++;
																goto IL_2066_2;
																IL_16ce_2:
																array2[num5 - 1] = 0;
																goto IL_16e2_2;
																IL_16e2_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<List<AudioClip>, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 1]);
																goto IL_1720_2;
																IL_1720_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1733_2:
																if (45 <= b)
																{
																	goto IL_173e_2;
																}
																goto IL_1788_2;
																IL_173e_2:
																((delegate*<AudioClip, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((AudioClip)array3[num5 - 1]);
																goto IL_1767_2;
																IL_1767_2:
																num5--;
																goto IL_1775_2;
																IL_1775_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1788_2:
																if (42 < b)
																{
																	goto IL_1796_2;
																}
																goto IL_1880_2;
																IL_1796_2:
																if (43 >= b)
																{
																	goto IL_17a1_2;
																}
																goto IL_17fc_2;
																IL_17a1_2:
																if (43 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_17af_2;
																IL_17af_2:
																array3[num5] = ((delegate*<string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																goto IL_17cd_2;
																IL_17cd_2:
																array2[num5] = 5;
																goto IL_17db_2;
																IL_17db_2:
																num5++;
																goto IL_17e9_2;
																IL_17e9_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_17fc_2:
																if (44 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_180a_2;
																IL_180a_2:
																if (44 > b)
																{
																	goto end_IL_088d_2;
																}
																num = 222;
																goto IL_1821_2;
																IL_2001_2:
																if (38 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_200c_2;
																IL_1821_2:
																array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																goto IL_1859_2;
																IL_1859_2:
																array2[num5 - 1] = 5;
																goto IL_186d_2;
																IL_186d_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1880_2:
																if (42 <= b)
																{
																	goto IL_188b_2;
																}
																goto IL_18f2_2;
																IL_188b_2:
																((delegate*<List<AudioClip>, AudioClip, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<AudioClip>)array3[num5 - 2], (AudioClip)array3[num5 - 1]);
																goto IL_18c8_2;
																IL_18c8_2:
																num5 -= 2;
																goto IL_18d6_2;
																IL_18d6_2:
																ptr2 += 8;
																num = 228;
																goto IL_2066_2;
																IL_18f2_2:
																if (40 < b)
																{
																	goto IL_18fd_2;
																}
																num = 403;
																goto IL_197b_2;
																IL_18fd_2:
																if (41 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_190b_2;
																IL_190b_2:
																if (41 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1919_2;
																IL_1919_2:
																array2[num5] = 5;
																num = 374;
																goto IL_1930_2;
																IL_1930_2:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																num = 169;
																goto IL_1951_2;
																IL_1951_2:
																num5++;
																goto IL_195f_2;
																IL_195f_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_200c_2:
																if (38 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_2017_2;
																IL_197b_2:
																if (40 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1989_2;
																IL_1989_2:
																array3[num5] = ((delegate*<List<AudioClip>>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])();
																goto IL_19a7_2;
																IL_19a7_2:
																array2[num5] = 5;
																goto IL_19b5_2;
																IL_19b5_2:
																num5++;
																goto IL_19c3_2;
																IL_19c3_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_19d6_2:
																if (39 <= b)
																{
																	goto IL_19e1_2;
																}
																goto IL_1a3f_2;
																IL_19e1_2:
																((delegate*<List<string>, string, void>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 2], (string)array3[num5 - 1]);
																goto IL_1a1e_2;
																IL_1a1e_2:
																num5 -= 2;
																goto IL_1a2c_2;
																IL_1a2c_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1a3f_2:
																if (32 >= b)
																{
																	goto IL_1a4d_2;
																}
																goto IL_1d9d_2;
																IL_1a4d_2:
																if (32 > b)
																{
																	goto IL_1a5b_2;
																}
																goto IL_1d54_2;
																IL_1a5b_2:
																if (29 < b)
																{
																	goto IL_1a69_2;
																}
																num = 34;
																goto IL_1bb6_2;
																IL_1a69_2:
																if (30 < b)
																{
																	goto IL_1a77_2;
																}
																goto IL_1b1e_2;
																IL_1a77_2:
																if (31 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1a85_2;
																IL_1a85_2:
																if (31 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1a93_2;
																IL_1a93_2:
																array2[num5 - 2] = 5;
																goto IL_1aa7_2;
																IL_1aa7_2:
																array3[num5 - 2] = ((delegate*<string, AudioType, UnityWebRequest>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], *(AudioType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_1af4_2;
																IL_1af4_2:
																num5--;
																goto IL_1b02_2;
																IL_1b02_2:
																ptr2 += 8;
																num = 95;
																goto IL_2066_2;
																IL_1b1e_2:
																if (30 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1b2c_2;
																IL_1b2c_2:
																array2[num5 - 2] = 5;
																goto IL_1b40_2;
																IL_1b40_2:
																array3[num5 - 2] = ((delegate*<string, string, string>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																goto IL_1b8c_2;
																IL_1b8c_2:
																num5--;
																goto IL_1b9a_2;
																IL_1b9a_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_2017_2:
																array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																goto IL_2035_2;
																IL_1bb6_2:
																if (29 > b)
																{
																	goto IL_1bc4_2;
																}
																goto IL_1cd3_2;
																IL_1bc4_2:
																if (27 >= b)
																{
																	goto IL_1bcf_2;
																}
																goto IL_1c42_2;
																IL_1bcf_2:
																if (27 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1bdd_2;
																IL_1bdd_2:
																array2[num5 - 1] = 0;
																goto IL_1bf1_2;
																IL_1bf1_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<List<string>, int>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((List<string>)array3[num5 - 1]);
																goto IL_1c2f_2;
																IL_1c2f_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1c42_2:
																if (28 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1c50_2;
																IL_1c50_2:
																if (28 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1c5e_2;
																IL_1c5e_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_1cc0_2;
																IL_1cc0_2:
																num5 -= 2;
																goto IL_2066_2;
																IL_1cd3_2:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_1d41_2;
																IL_1d41_2:
																num5 -= 2;
																goto IL_2066_2;
																IL_1d54_2:
																((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequest_0 = (UnityWebRequest)array3[num5 - 1];
																goto IL_1d81_2;
																IL_1d81_2:
																num5 -= 2;
																num = 451;
																goto IL_2066_2;
																IL_1d9d_2:
																if (35 >= b)
																{
																	goto IL_1dab_2;
																}
																goto IL_1efd_2;
																IL_1dab_2:
																if (35 <= b)
																{
																	goto IL_1db6_2;
																}
																goto IL_1dff_2;
																IL_1db6_2:
																((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 2]).unityWebRequestAsyncOperation_0 = (UnityWebRequestAsyncOperation)array3[num5 - 1];
																num = 90;
																goto IL_1dec_2;
																IL_1dec_2:
																num5 -= 2;
																goto IL_2066_2;
																IL_1dff_2:
																if (33 >= b)
																{
																	goto IL_1e0a_2;
																}
																goto IL_1e77_2;
																IL_1e0a_2:
																if (33 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1e18_2;
																IL_1e18_2:
																array3[num5 - 1] = ((delegate*<_003CLoadAndPlayAudio_003Ed__17, UnityWebRequest>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((_003CLoadAndPlayAudio_003Ed__17)array3[num5 - 1]);
																goto IL_1e50_2;
																IL_1e50_2:
																array2[num5 - 1] = 5;
																goto IL_1e64_2;
																IL_1e64_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_1e77_2:
																if (34 < b)
																{
																	num = 38;
																	goto end_IL_088d_2;
																}
																goto IL_1e82_2;
																IL_1e82_2:
																if (34 > b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1e90_2;
																IL_1e90_2:
																array2[num5 - 1] = 5;
																goto IL_1ea4_2;
																IL_1ea4_2:
																array3[num5 - 1] = ((delegate*<UnityWebRequest, UnityWebRequestAsyncOperation>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																goto IL_1edc_2;
																IL_1edc_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_2035_2:
																ptr2 += 8;
																goto IL_2043_2;
																IL_1efd_2:
																if (37 >= b)
																{
																	goto IL_1f0b_2;
																}
																goto IL_2001_2;
																IL_1f0b_2:
																if (37 > b)
																{
																	goto IL_1f19_2;
																}
																goto IL_1fa5_2;
																IL_1f19_2:
																if (36 < b)
																{
																	goto end_IL_088d_2;
																}
																goto IL_1f27_2;
																IL_1f27_2:
																if (36 > b)
																{
																	num = 215;
																	goto end_IL_088d_2;
																}
																goto IL_1f32_2;
																IL_1f32_2:
																array2[num5 - 1] = 0;
																goto IL_1f46_2;
																IL_1f46_2:
																*(UnityWebRequest.Result*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<UnityWebRequest, UnityWebRequest.Result>)BytesUnknownChangePermissions[*(int*)(ptr2 + num3)])((UnityWebRequest)array3[num5 - 1]);
																goto IL_1f84_2;
																IL_1f84_2:
																ptr2 += 8;
																goto IL_2066_2;
																IL_2043_2:
																num5--;
																goto IL_2066_2;
																IL_1fa5_2:
																array2[num5 - 1] = 5;
																goto IL_1fb9_2;
																continue;
																end_IL_087d:
																break;
															}
															continue;
															end_IL_088d_2:
															break;
														}
													}
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_2066_2;
													continue;
													end_IL_089d_2:
													break;
												}
												continue;
												end_IL_08ad:
												break;
											}
											continue;
											end_IL_08bd:
											break;
										}
										break;
									}
									num = 349;
									goto IL_2144_2;
									IL_2144_2:
									return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) != 0;
								}
								break;
							}
							continue;
							end_IL_0dc2:
							break;
						}
						break;
					}
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		unsafe void IEnumerator.Reset()
		{
			int num = 3;
			byte* ptr = default(byte*);
			int num4 = default(int);
			byte* ptr2 = default(byte*);
			int num5 = default(int);
			byte b = default(byte);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[1];
						while (true)
						{
							object[] array2 = new object[1];
							while (true)
							{
								num = 40;
								while (true)
								{
									if (num != 40)
									{
										if (num != 1021)
										{
											goto IL_01b8;
										}
										switch (num)
										{
										case 12:
										case 25:
											goto end_IL_00af;
										case 29:
											goto end_IL_00bf;
										case 27:
										case 31:
											goto end_IL_00ca;
										case 2:
											goto end_IL_00da;
										case 3:
											goto end_IL_00ea;
										case 19:
											goto IL_010e;
										case 15:
										case 28:
										case 33:
											goto IL_0116;
										case 8:
										case 13:
											goto IL_0126;
										case 11:
											goto IL_0138;
										case 16:
											goto IL_0146;
										case 1:
											goto IL_0151;
										case 22:
											goto IL_015c;
										case 21:
											goto IL_0167;
										case 9:
											goto IL_0174;
										case 17:
											goto IL_017f;
										case 6:
											goto IL_018c;
										case 24:
											goto IL_01aa;
										case 18:
											goto IL_01b8;
										case 0:
										case 10:
										case 14:
										case 20:
										case 23:
										case 26:
										case 32:
											goto IL_01cb;
										case 5:
										case 7:
											goto IL_01db;
										case 4:
										case 30:
											return;
										}
										continue;
									}
									ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SponsorshipTimeoutBaseOctet.setPublicKeyStrongNameSignatureVerificationEx);
									goto IL_010e;
									IL_018c:
									array2[num4] = ((delegate*<NotSupportedException>)GetObjectValueAutoResetEvent[*(int*)(ptr2 + num3)])();
									goto IL_01aa;
									IL_01b8:
									ptr2 += 8;
									goto IL_0116;
									IL_01aa:
									num4++;
									goto IL_01b8;
									IL_010e:
									ptr2 = ptr;
									goto IL_0116;
									IL_0116:
									if (num5 == 1)
									{
										return;
									}
									goto IL_0126;
									IL_0126:
									b = *ptr2;
									num = 11;
									goto IL_0138;
									IL_0138:
									ptr2++;
									goto IL_0146;
									IL_0146:
									if (b >= 1)
									{
										goto IL_0151;
									}
									goto IL_01cb;
									IL_0151:
									if (b <= 2)
									{
										goto IL_015c;
									}
									goto IL_01cb;
									IL_015c:
									if (1 >= b)
									{
										goto IL_0167;
									}
									goto IL_0174;
									IL_0167:
									if (1 <= b)
									{
									}
									goto IL_01cb;
									IL_0174:
									if (2 >= b)
									{
										goto IL_017f;
									}
									goto IL_01cb;
									IL_017f:
									if (2 > b)
									{
										goto IL_01cb;
									}
									goto IL_01db;
									IL_01db:
									throw (Exception)array2[num4 - 1];
									IL_01cb:
									array[num4] = 5;
									goto IL_018c;
									continue;
									end_IL_00af:
									break;
								}
								continue;
								end_IL_00bf:
								break;
							}
							continue;
							end_IL_00ca:
							break;
						}
						continue;
						end_IL_00da:
						break;
					}
					continue;
					end_IL_00ea:
					break;
				}
			}
		}

		static _003CLoadAndPlayAudio_003Ed__17()
		{
			int num = 5;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 13;
						while (true)
						{
							if (num == 13 || num != 994)
							{
								return;
							}
							switch (num)
							{
							case 0:
							case 1:
								goto end_IL_003d;
							case 4:
								goto end_IL_004a;
							case 5:
								goto end_IL_0059;
							case 2:
								return;
							case 3:
								return;
							case 6:
								return;
							}
							continue;
							end_IL_003d:
							break;
						}
						continue;
						end_IL_004a:
						break;
					}
					continue;
					end_IL_0059:
					break;
				}
			}
		}
	}

	private static List<string> list_0;

	private static List<AudioClip> list_1;

	private static string string_0;

	private static string string_1;

	private static bool bool_0;

	private static bool bool_1;

	private static bool bool_2;

	private static double double_0;

	private static int int_0;

	private static int int_1;

	private static bool bool_3;

	private static IntPtr[] ThreadPoolTaskSchedulerStringSplitOptions;

	private static IntPtr[] intptr_0;

	private static IntPtr[] UserCustomCulturePostconditionOnException;

	private static IntPtr[] RunContinuationsAsynchronouslyANSIX;

	private static IntPtr[] setTagIsSerializable;

	private static IntPtr[] WriteTimeoutMethodName;

	private static IntPtr[] RSAEncryptionPaddingModeSoapCheckEnabled;

	private static IntPtr[] DateOfBirthSerializationHeaderRecord;

	private static IntPtr[] getNumberFormatAssemblyEvidenceFactory;

	public static string CurrentlyPlaying
	{
		get
		{
			string text = string_1;
			return text;
		}
	}

	public unsafe static bool HearSelf
	{
		get
		{
			int num = 259;
			num = 37;
			num = 418;
			num = 38;
			num = 37;
			num = 3;
			num = 39;
			num = 39;
			num = 238;
			num = 34;
			num = 330;
			num = 30;
			num = 34;
			num = 64;
			num = 956;
			num = 956;
			num = 995;
			num = 720;
			num = 144;
			return bool_0;
		}
		set
		{
			int num = 149;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					num = 181;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									sbyte[] array3 = new sbyte[1];
									while (true)
									{
										int[] array4 = new int[6];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												num = 265;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EventFieldAttributeForkJoin.ProduceLegacyHmacValuesImageRuntimeVersion);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																num = 286;
																while (true)
																{
																	if (num != 286)
																	{
																		if (num != 1267)
																		{
																			goto IL_08f4;
																		}
																		switch (num)
																		{
																		case 113:
																		case 231:
																			goto end_IL_0487;
																		case 172:
																			goto IL_04b9;
																		case 104:
																			goto IL_04c7;
																		case 68:
																			goto IL_04d5;
																		case 24:
																		case 43:
																			goto IL_04e3;
																		case 10:
																			goto IL_04f1;
																		case 9:
																		case 254:
																			goto IL_04ff;
																		case 90:
																		case 242:
																			goto IL_050d;
																		case 8:
																			goto IL_051b;
																		case 210:
																		case 247:
																			goto IL_0526;
																		case 159:
																			goto IL_0534;
																		case 64:
																		case 123:
																			goto IL_054b;
																		case 202:
																			goto IL_0555;
																		case 246:
																			goto IL_0563;
																		case 33:
																		case 261:
																			goto IL_0576;
																		case 173:
																			goto IL_058a;
																		case 52:
																			goto IL_05d7;
																		case 213:
																			goto IL_05e5;
																		case 170:
																		case 251:
																			goto IL_0601;
																		case 109:
																			goto IL_060f;
																		case 208:
																		case 211:
																			goto IL_061d;
																		case 5:
																			goto IL_066f;
																		case 124:
																			goto IL_068b;
																		case 30:
																			goto IL_0699;
																		case 271:
																			goto IL_06a4;
																		case 47:
																		case 116:
																			goto IL_06b2;
																		case 106:
																			goto IL_06d0;
																		case 158:
																			goto IL_06de;
																		case 92:
																			goto IL_06ec;
																		case 260:
																			goto IL_06ff;
																		case 82:
																			goto IL_070d;
																		case 167:
																		case 197:
																			goto IL_071b;
																		case 14:
																			goto IL_0763;
																		case 59:
																		case 276:
																			goto IL_0776;
																		case 241:
																			goto IL_0784;
																		case 166:
																			goto IL_07a2;
																		case 245:
																			goto IL_07b0;
																		case 70:
																		case 229:
																			goto IL_07c3;
																		case 138:
																			goto IL_07d7;
																		case 42:
																			goto IL_080f;
																		case 22:
																		case 224:
																			goto IL_082b;
																		case 21:
																		case 199:
																			goto IL_0839;
																		case 32:
																		case 193:
																			goto IL_0844;
																		case 180:
																			goto IL_0852;
																		case 15:
																		case 133:
																			goto IL_0860;
																		case 141:
																			goto IL_087c;
																		case 46:
																		case 100:
																			goto IL_0887;
																		case 84:
																			goto IL_08c5;
																		case 102:
																			goto IL_08d3;
																		case 243:
																			goto IL_08e6;
																		case 0:
																			goto IL_08f4;
																		case 97:
																		case 216:
																			goto IL_0902;
																		case 230:
																			goto IL_0970;
																		case 188:
																			goto IL_0983;
																		case 61:
																		case 218:
																			goto IL_0991;
																		case 98:
																		case 207:
																			goto IL_099f;
																		case 250:
																			goto IL_09ad;
																		case 175:
																		case 209:
																			goto IL_09bb;
																		case 219:
																			goto IL_09cf;
																		case 54:
																			goto IL_0a1c;
																		case 217:
																			goto IL_0a2a;
																		case 66:
																			goto IL_0a3d;
																		case 74:
																		case 253:
																			goto IL_0a48;
																		case 227:
																			goto IL_0a6f;
																		case 220:
																			goto IL_0a7d;
																		case 267:
																			goto IL_0a8b;
																		case 16:
																			goto IL_0a9e;
																		case 49:
																			goto IL_0aac;
																		case 94:
																		case 146:
																			goto IL_0aba;
																		case 236:
																			goto IL_0ad3;
																		case 91:
																		case 132:
																			goto IL_0ae6;
																		case 37:
																			goto IL_0afa;
																		case 176:
																			goto IL_0b38;
																		case 23:
																			goto IL_0b4b;
																		case 205:
																			goto IL_0b59;
																		case 56:
																		case 80:
																			goto IL_0b67;
																		case 110:
																		case 153:
																			goto IL_0b75;
																		case 189:
																			goto IL_0b83;
																		case 45:
																		case 111:
																			goto IL_0b8e;
																		case 263:
																			goto IL_0ba6;
																		case 51:
																			goto IL_0bb4;
																		case 86:
																		case 115:
																			goto IL_0bc2;
																		case 160:
																			goto IL_0bdb;
																		case 130:
																			goto IL_0be9;
																		case 198:
																			goto IL_0bf7;
																		case 268:
																			goto IL_0c0a;
																		case 139:
																			goto IL_0c18;
																		case 101:
																		case 178:
																			goto IL_0c23;
																		case 11:
																			goto IL_0c46;
																		case 62:
																			goto IL_0c54;
																		case 238:
																			goto IL_0c62;
																		case 77:
																			goto IL_0c83;
																		case 125:
																		case 278:
																			goto IL_0c91;
																		case 72:
																			goto IL_0c9f;
																		case 144:
																			goto IL_0caa;
																		case 179:
																			goto IL_0cb8;
																		case 50:
																		case 164:
																			goto IL_0cc6;
																		case 87:
																		case 162:
																			goto IL_0ce2;
																		case 140:
																			goto IL_0d22;
																		case 63:
																			goto IL_0d36;
																		case 36:
																			goto IL_0d49;
																		case 256:
																			goto IL_0d57;
																		case 73:
																		case 121:
																			goto IL_0d6e;
																		case 279:
																			goto IL_0dd0;
																		case 248:
																			goto IL_0de3;
																		case 25:
																		case 53:
																			goto IL_0df1;
																		case 182:
																			goto IL_0dff;
																		case 6:
																		case 152:
																			goto IL_0e0a;
																		case 190:
																			goto IL_0e33;
																		case 35:
																			goto IL_0e41;
																		case 119:
																			goto IL_0e54;
																		case 34:
																		case 226:
																			goto IL_0e62;
																		case 117:
																			goto IL_0e70;
																		case 71:
																		case 96:
																			goto IL_0e7e;
																		case 4:
																			goto IL_0ebe;
																		case 204:
																			goto IL_0edb;
																		case 99:
																			goto IL_0eee;
																		case 273:
																			goto IL_0f01;
																		case 76:
																		case 212:
																			goto IL_0f0f;
																		case 257:
																			goto IL_0f1d;
																		case 163:
																		case 187:
																			goto IL_0f2b;
																		case 228:
																			goto IL_0f6b;
																		case 157:
																			goto IL_0f7f;
																		case 136:
																			goto IL_0f92;
																		case 259:
																		case 277:
																			goto IL_0fa0;
																		case 13:
																			goto IL_0fb7;
																		case 95:
																		case 120:
																			goto IL_0fc5;
																		case 171:
																			goto IL_0fd3;
																		case 225:
																			goto IL_0ff6;
																		case 222:
																			goto IL_1000;
																		case 126:
																			goto IL_100e;
																		case 118:
																		case 239:
																			goto IL_1021;
																		case 85:
																			goto IL_106a;
																		case 174:
																			goto IL_1087;
																		case 194:
																		case 233:
																			goto IL_109a;
																		case 191:
																			goto IL_10e3;
																		case 17:
																			goto IL_10f7;
																		case 7:
																		case 67:
																			goto IL_1107;
																		case 55:
																			goto IL_112a;
																		case 3:
																		case 26:
																		case 27:
																		case 29:
																		case 31:
																		case 38:
																		case 39:
																		case 41:
																		case 44:
																		case 57:
																		case 81:
																		case 88:
																		case 89:
																		case 93:
																		case 114:
																		case 122:
																		case 127:
																		case 128:
																		case 131:
																		case 135:
																		case 137:
																		case 143:
																		case 147:
																		case 150:
																		case 151:
																		case 155:
																		case 156:
																		case 161:
																		case 169:
																		case 184:
																		case 185:
																		case 186:
																		case 192:
																		case 196:
																		case 201:
																		case 206:
																		case 214:
																		case 215:
																		case 234:
																		case 235:
																		case 244:
																		case 255:
																		case 258:
																		case 264:
																		case 269:
																		case 272:
																		case 274:
																			goto IL_113a;
																		case 200:
																			goto IL_1153;
																		case 1:
																			goto IL_1161;
																		case 129:
																			goto IL_116f;
																		case 2:
																		case 19:
																		case 20:
																		case 28:
																		case 40:
																		case 48:
																		case 58:
																		case 60:
																		case 65:
																		case 69:
																		case 75:
																		case 78:
																		case 83:
																		case 105:
																		case 108:
																		case 134:
																		case 142:
																		case 145:
																		case 154:
																		case 168:
																		case 177:
																		case 195:
																		case 203:
																		case 221:
																		case 223:
																		case 232:
																		case 240:
																		case 249:
																		case 252:
																		case 262:
																		case 266:
																		case 270:
																			goto end_IL_0497;
																		case 183:
																			goto end_IL_117d;
																		case 265:
																			goto end_IL_1190;
																		case 107:
																			goto end_IL_119a;
																		case 103:
																			goto end_IL_11a5;
																		case 237:
																			goto end_IL_11c3;
																		case 12:
																		case 79:
																			goto end_IL_11d3;
																		case 165:
																			goto end_IL_11e3;
																		case 18:
																			goto end_IL_11f3;
																		case 181:
																			goto end_IL_1203;
																		case 148:
																			goto end_IL_1213;
																		case 149:
																			goto end_IL_1223;
																		case 112:
																		case 275:
																			return;
																		}
																		continue;
																	}
																	ptr2++;
																	goto IL_04b9;
																	IL_10e3:
																	array[num6 - 2] = 0;
																	goto IL_10f7;
																	IL_1107:
																	bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																	num = 55;
																	goto IL_112a;
																	IL_10f7:
																	num6--;
																	goto end_IL_0497;
																	IL_04b9:
																	if (b >= 1)
																	{
																		goto IL_04c7;
																	}
																	goto IL_113a;
																	IL_04c7:
																	if (b <= 29)
																	{
																		goto IL_04d5;
																	}
																	goto IL_113a;
																	IL_04d5:
																	if (15 < b)
																	{
																		goto IL_04e3;
																	}
																	goto IL_0b4b;
																	IL_04e3:
																	if (22 >= b)
																	{
																		goto IL_04f1;
																	}
																	goto IL_082b;
																	IL_04f1:
																	if (22 > b)
																	{
																		goto IL_04ff;
																	}
																	goto IL_07c3;
																	IL_04ff:
																	if (18 < b)
																	{
																		goto IL_050d;
																	}
																	goto IL_068b;
																	IL_050d:
																	if (20 >= b)
																	{
																		goto IL_051b;
																	}
																	goto IL_0601;
																	IL_051b:
																	if (20 > b)
																	{
																		goto IL_0526;
																	}
																	goto IL_0576;
																	IL_0526:
																	if (19 >= b)
																	{
																		goto IL_0534;
																	}
																	goto IL_113a;
																	IL_0534:
																	if (19 <= b)
																	{
																		num = 123;
																		goto IL_054b;
																	}
																	goto IL_113a;
																	IL_112a:
																	num6--;
																	goto end_IL_0497;
																	IL_054b:
																	array2[num6] = null;
																	goto IL_0555;
																	IL_0555:
																	array[num6] = 5;
																	goto IL_0563;
																	IL_0563:
																	num6++;
																	goto end_IL_0497;
																	IL_0576:
																	array[num6 - 2] = 0;
																	goto IL_058a;
																	IL_058a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																	goto IL_05d7;
																	IL_05d7:
																	num6--;
																	goto IL_05e5;
																	IL_05e5:
																	ptr2 += 8;
																	num = 252;
																	goto end_IL_0497;
																	IL_0601:
																	if (21 >= b)
																	{
																		goto IL_060f;
																	}
																	goto IL_113a;
																	IL_060f:
																	if (21 <= b)
																	{
																		goto IL_061d;
																	}
																	goto IL_113a;
																	IL_061d:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_066f;
																	IL_066f:
																	num6--;
																	num = 266;
																	goto end_IL_0497;
																	IL_068b:
																	if (18 > b)
																	{
																		goto IL_0699;
																	}
																	goto IL_0776;
																	IL_0699:
																	if (16 >= b)
																	{
																		goto IL_06a4;
																	}
																	goto IL_06ff;
																	IL_06a4:
																	if (16 <= b)
																	{
																		goto IL_06b2;
																	}
																	goto IL_113a;
																	IL_06b2:
																	array2[num6] = ((delegate*<string>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])();
																	goto IL_06d0;
																	IL_06d0:
																	array[num6] = 5;
																	goto IL_06de;
																	IL_06de:
																	num6++;
																	goto IL_06ec;
																	IL_06ec:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_06ff:
																	if (17 >= b)
																	{
																		goto IL_070d;
																	}
																	goto IL_113a;
																	IL_070d:
																	if (17 <= b)
																	{
																		goto IL_071b;
																	}
																	goto IL_113a;
																	IL_071b:
																	ptr2 = ((array2[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0763;
																	IL_0763:
																	num6--;
																	goto end_IL_0497;
																	IL_0776:
																	array[num6] = 5;
																	goto IL_0784;
																	IL_0784:
																	array2[num6] = ((delegate*<GorillaTagger>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])();
																	goto IL_07a2;
																	IL_07a2:
																	num6++;
																	goto IL_07b0;
																	IL_07b0:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_07c3:
																	array[num6 - 1] = 5;
																	goto IL_07d7;
																	IL_07d7:
																	array2[num6 - 1] = ((delegate*<GorillaTagger, Recorder>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																	goto IL_080f;
																	IL_080f:
																	ptr2 += 8;
																	num = 145;
																	goto end_IL_0497;
																	IL_082b:
																	if (26 < b)
																	{
																		goto IL_0839;
																	}
																	goto IL_0983;
																	IL_0839:
																	if (28 < b)
																	{
																		goto IL_0844;
																	}
																	goto IL_087c;
																	IL_0844:
																	if (29 >= b)
																	{
																		goto IL_0852;
																	}
																	goto IL_113a;
																	IL_0852:
																	if (29 <= b)
																	{
																		goto IL_0860;
																	}
																	goto IL_113a;
																	IL_0860:
																	byte* num7 = ptr2;
																	num5 = 1;
																	ptr2 = num7 + -200;
																	goto end_IL_0497;
																	IL_087c:
																	if (28 <= b)
																	{
																		goto IL_0887;
																	}
																	goto IL_08e6;
																	IL_0887:
																	((delegate*<Recorder, bool, void>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0);
																	goto IL_08c5;
																	IL_08c5:
																	num6 -= 2;
																	goto IL_08d3;
																	IL_08d3:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_08e6:
																	if (27 >= b)
																	{
																		goto IL_08f4;
																	}
																	goto IL_113a;
																	IL_08f4:
																	if (27 <= b)
																	{
																		goto IL_0902;
																	}
																	goto IL_113a;
																	IL_0902:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0970;
																	IL_0970:
																	num6 -= 2;
																	goto end_IL_0497;
																	IL_0983:
																	if (26 > b)
																	{
																		goto IL_0991;
																	}
																	goto IL_0ae6;
																	IL_0991:
																	if (24 < b)
																	{
																		goto IL_099f;
																	}
																	goto IL_0a3d;
																	IL_099f:
																	if (25 >= b)
																	{
																		goto IL_09ad;
																	}
																	goto IL_113a;
																	IL_09ad:
																	if (25 <= b)
																	{
																		goto IL_09bb;
																	}
																	goto IL_113a;
																	IL_09bb:
																	array[num6 - 2] = 0;
																	goto IL_09cf;
																	IL_09cf:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																	goto IL_0a1c;
																	IL_0a1c:
																	num6--;
																	goto IL_0a2a;
																	IL_0a2a:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_0a3d:
																	if (24 <= b)
																	{
																		goto IL_0a48;
																	}
																	goto IL_0a9e;
																	IL_0a48:
																	array2[num6] = ((delegate*<Recorder>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])();
																	num = 227;
																	goto IL_0a6f;
																	IL_0a6f:
																	array[num6] = 5;
																	goto IL_0a7d;
																	IL_0a7d:
																	num6++;
																	goto IL_0a8b;
																	IL_0a8b:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_0a9e:
																	if (23 >= b)
																	{
																		goto IL_0aac;
																	}
																	goto IL_113a;
																	IL_0aac:
																	if (23 <= b)
																	{
																		goto IL_0aba;
																	}
																	goto IL_113a;
																	IL_0aba:
																	global::_003CModule_003E.recorder_0 = (Recorder)array2[num6 - 1];
																	goto IL_0ad3;
																	IL_0ad3:
																	num6--;
																	goto end_IL_0497;
																	IL_0ae6:
																	array[num6 - 1] = 0;
																	goto IL_0afa;
																	IL_0afa:
																	*(Recorder.InputSourceType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Recorder, Recorder.InputSourceType>)ThreadPoolTaskSchedulerStringSplitOptions[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 1]);
																	goto IL_0b38;
																	IL_0b38:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_0b4b:
																	if (15 > b)
																	{
																		goto IL_0b59;
																	}
																	goto IL_1107;
																	IL_0b59:
																	if (7 < b)
																	{
																		goto IL_0b67;
																	}
																	goto IL_0de3;
																	IL_0b67:
																	if (11 < b)
																	{
																		goto IL_0b75;
																	}
																	goto IL_0c83;
																	IL_0b75:
																	if (13 >= b)
																	{
																		goto IL_0b83;
																	}
																	goto IL_0c0a;
																	IL_0b83:
																	if (13 <= b)
																	{
																		goto IL_0b8e;
																	}
																	goto IL_0ba6;
																	IL_0b8e:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0497;
																	IL_0ba6:
																	if (12 >= b)
																	{
																		goto IL_0bb4;
																	}
																	goto IL_113a;
																	IL_0bb4:
																	if (12 <= b)
																	{
																		goto IL_0bc2;
																	}
																	goto IL_113a;
																	IL_0bc2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0bdb;
																	IL_0bdb:
																	array[num6] = 1;
																	goto IL_0be9;
																	IL_0be9:
																	num6++;
																	goto IL_0bf7;
																	IL_0bf7:
																	ptr2 += 16;
																	goto end_IL_0497;
																	IL_0c0a:
																	if (14 >= b)
																	{
																		goto IL_0c18;
																	}
																	goto IL_113a;
																	IL_0c18:
																	if (14 <= b)
																	{
																		goto IL_0c23;
																	}
																	num = 184;
																	goto IL_113a;
																	IL_0c23:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0c46;
																	IL_0c46:
																	array[num6] = 0;
																	goto IL_0c54;
																	IL_0c54:
																	num6++;
																	goto IL_0c62;
																	IL_0c62:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_113a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																	goto IL_1153;
																	IL_0c83:
																	if (11 <= b)
																	{
																		goto end_IL_0497;
																	}
																	goto IL_0c91;
																	IL_0c91:
																	if (9 >= b)
																	{
																		goto IL_0c9f;
																	}
																	goto IL_0d49;
																	IL_0c9f:
																	if (9 > b)
																	{
																		goto IL_0caa;
																	}
																	num = 87;
																	goto IL_0ce2;
																	IL_0caa:
																	if (8 >= b)
																	{
																		goto IL_0cb8;
																	}
																	goto IL_113a;
																	IL_0cb8:
																	if (8 <= b)
																	{
																		goto IL_0cc6;
																	}
																	goto IL_113a;
																	IL_0cc6:
																	num6--;
																	goto end_IL_0497;
																	IL_1153:
																	array[num6] = 0;
																	goto IL_1161;
																	IL_0ce2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	goto IL_0d22;
																	IL_0d22:
																	array[num6 - 2] = 0;
																	goto IL_0d36;
																	IL_0d36:
																	num6--;
																	goto end_IL_0497;
																	IL_0d49:
																	if (10 >= b)
																	{
																		goto IL_0d57;
																	}
																	goto IL_113a;
																	IL_0d57:
																	if (10 <= b)
																	{
																		num = 121;
																		goto IL_0d6e;
																	}
																	goto IL_113a;
																	IL_1161:
																	num6++;
																	goto IL_116f;
																	IL_0d6e:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0dd0;
																	IL_0dd0:
																	num6 -= 2;
																	goto end_IL_0497;
																	IL_0de3:
																	if (7 > b)
																	{
																		goto IL_0df1;
																	}
																	goto IL_109a;
																	IL_0df1:
																	if (3 >= b)
																	{
																		goto IL_0dff;
																	}
																	goto IL_0f01;
																	IL_0dff:
																	if (3 <= b)
																	{
																		goto IL_0e0a;
																	}
																	goto IL_0e54;
																	IL_0e0a:
																	ref int reference = ref array4[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	goto IL_0e33;
																	IL_0e33:
																	ptr2 += 8;
																	goto IL_0e41;
																	IL_0e41:
																	num6--;
																	goto end_IL_0497;
																	IL_0e54:
																	if (1 < b)
																	{
																		goto IL_0e62;
																	}
																	goto IL_0eee;
																	IL_0e62:
																	if (2 >= b)
																	{
																		goto IL_0e70;
																	}
																	goto IL_113a;
																	IL_0e70:
																	if (2 <= b)
																	{
																		goto IL_0e7e;
																	}
																	goto IL_113a;
																	IL_0e7e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	goto IL_0ebe;
																	IL_0ebe:
																	array[num6 - 2] = 0;
																	num = 204;
																	goto IL_0edb;
																	IL_0edb:
																	num6--;
																	goto end_IL_0497;
																	IL_0eee:
																	if (1 <= b)
																	{
																	}
																	goto IL_113a;
																	IL_0f01:
																	if (5 < b)
																	{
																		goto IL_0f0f;
																	}
																	goto IL_0f92;
																	IL_0f0f:
																	if (6 >= b)
																	{
																		goto IL_0f1d;
																	}
																	goto IL_113a;
																	IL_0f1d:
																	if (6 <= b)
																	{
																		goto IL_0f2b;
																	}
																	goto IL_113a;
																	IL_0f2b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	goto IL_0f6b;
																	IL_0f6b:
																	array[num6 - 2] = 0;
																	goto IL_0f7f;
																	IL_0f7f:
																	num6--;
																	goto end_IL_0497;
																	IL_0f92:
																	if (5 > b)
																	{
																		goto IL_0fa0;
																	}
																	goto IL_1021;
																	IL_0fa0:
																	if (4 >= b)
																	{
																		num = 13;
																		goto IL_0fb7;
																	}
																	goto IL_113a;
																	IL_116f:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_0fb7:
																	if (4 <= b)
																	{
																		goto IL_0fc5;
																	}
																	goto IL_113a;
																	IL_0fc5:
																	array[num6] = 0;
																	goto IL_0fd3;
																	IL_0fd3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																	goto IL_0ff6;
																	IL_0ff6:
																	array2[num6] = null;
																	goto IL_1000;
																	IL_1000:
																	num6++;
																	goto IL_100e;
																	IL_100e:
																	ptr2 += 8;
																	goto end_IL_0497;
																	IL_1021:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	num = 85;
																	goto IL_106a;
																	IL_106a:
																	array[num6 - 2] = 0;
																	num = 174;
																	goto IL_1087;
																	IL_1087:
																	num6--;
																	goto end_IL_0497;
																	IL_109a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																	num = 191;
																	goto IL_10e3;
																	continue;
																	end_IL_0487:
																	break;
																}
																continue;
																end_IL_0497:
																break;
															}
															continue;
															end_IL_117d:
															break;
														}
														continue;
														end_IL_1190:
														break;
													}
													continue;
													end_IL_119a:
													break;
												}
												continue;
												end_IL_11a5:
												break;
											}
											continue;
											end_IL_11c3:
											break;
										}
										continue;
										end_IL_11d3:
										break;
									}
									continue;
									end_IL_11e3:
									break;
								}
								continue;
								end_IL_11f3:
								break;
							}
							continue;
							end_IL_1203:
							break;
						}
						continue;
						end_IL_1213:
						break;
					}
					continue;
					end_IL_1223:
					break;
				}
			}
		}
	}

	public static void smethod_0()
	{
		int num = 550;
		num = 50;
		num = 627;
		num = 57;
		num = 50;
		num = 11;
		num = 59;
		num = 59;
		num = 532;
		num = 76;
		num = 225;
		num = 75;
		num = 76;
		num = 151;
		num = 5843;
		num = 5843;
		num = 5902;
		num = 725;
		num = 145;
		object obj = "x";
		object obj2 = obj;
		obj = "R";
		object obj3 = obj;
		obj = "i";
		object obj4 = obj;
		obj = "e";
		object obj5 = obj;
		obj = "u";
		object obj6 = obj;
		obj = "s";
		object obj7 = obj;
		obj = "A";
		object obj8 = obj;
		obj = "o";
		object obj9 = obj;
		obj = "d";
		object obj10 = obj;
		obj = "n";
		object obj11 = obj;
		num = 33;
		num = 11;
		obj = new string[11];
		object obj12 = obj;
		object obj13 = obj3;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj5;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj2;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj9;
		((string[])obj12)[3] = (string)obj13;
		obj12 = obj;
		obj13 = obj11;
		((string[])obj12)[4] = (string)obj13;
		obj12 = obj;
		obj13 = obj8;
		((string[])obj12)[5] = (string)obj13;
		obj12 = obj;
		obj13 = obj6;
		((string[])obj12)[6] = (string)obj13;
		obj12 = obj;
		obj13 = obj10;
		((string[])obj12)[7] = (string)obj13;
		obj12 = obj;
		obj13 = obj4;
		((string[])obj12)[8] = (string)obj13;
		obj12 = obj;
		obj13 = obj9;
		((string[])obj12)[9] = (string)obj13;
		obj12 = obj;
		obj13 = obj7;
		((string[])obj12)[10] = (string)obj13;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj14 = obj;
		try
		{
			string pluginPath = Paths.PluginPath;
			obj = pluginPath;
			string text2 = Path.DirectorySeparatorChar.ToString();
			obj12 = text2;
			object obj15 = obj14;
			string text3 = (string)obj + (string)obj12 + (string)obj15;
			obj = text3;
			string_0 = (string)obj;
			obj = string_0;
			if (!Directory.Exists((string)obj))
			{
				obj = string_0;
				DirectoryInfo directoryInfo = Directory.CreateDirectory((string)obj);
				obj = directoryInfo;
			}
		}
		catch
		{
		}
	}

	public static string[] smethod_1()
	{
		int num = 217;
		int num2 = 7;
		num = 31;
		num = 95;
		num2 = 5;
		num = 19;
		num = 31;
		num2 = 19;
		num = 12;
		num2 = 31;
		num2 = 19;
		num = 31;
		num = 31;
		num = 737;
		num2 = 11;
		num = 67;
		num = 988;
		num2 = 13;
		num = 76;
		num = 67;
		num2 = 76;
		num = 143;
		num2 = 67;
		num2 = 5092;
		num = 4971;
		num = 4971;
		num2 = 31;
		num = 5002;
		num = 282;
		num2 = 2;
		num = 141;
		num2 = 741;
		num2 = 247;
		object obj = "g";
		object obj2 = obj;
		obj = "w";
		object obj3 = obj;
		obj = "o";
		object obj4 = obj;
		obj = "a";
		object obj5 = obj;
		obj = "4";
		object obj6 = obj;
		obj = "p";
		object obj7 = obj;
		obj = ".";
		object obj8 = obj;
		obj = "m";
		object obj9 = obj;
		obj = "v";
		object obj10 = obj;
		obj = "3";
		object obj11 = obj;
		num = 12;
		num2 = 3;
		num = 4;
		obj = new string[4];
		object obj12 = obj;
		object obj13 = obj8;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj9;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj7;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj11;
		((string[])obj12)[3] = (string)obj13;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj14 = obj;
		num = 44;
		num2 = 11;
		num = 4;
		obj = new string[4];
		obj12 = obj;
		obj13 = obj8;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj4;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj2;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj2;
		((string[])obj12)[3] = (string)obj13;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj15 = obj;
		num = 8;
		num2 = 2;
		num = 4;
		obj = new string[4];
		obj12 = obj;
		obj13 = obj8;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj9;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj6;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj5;
		((string[])obj12)[3] = (string)obj13;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj16 = obj;
		num = 12;
		num2 = 3;
		num = 4;
		obj = new string[4];
		obj12 = obj;
		obj13 = obj8;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj3;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj5;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj10;
		((string[])obj12)[3] = (string)obj13;
		string text4 = string.Concat((string[])obj);
		obj = text4;
		object obj17 = obj;
		obj = string_0;
		if (obj != null)
		{
			obj = string_0;
			if (((string)obj).Length != 0)
			{
				goto IL_0366;
			}
		}
		smethod_0();
		goto IL_0366;
		IL_0366:
		obj = string_0;
		if (obj != null)
		{
			obj = string_0;
			if (Directory.Exists((string)obj))
			{
				List<string> list = new List<string>();
				obj = list;
				global::_003CModule_003E.list_6 = (List<string>)obj;
				try
				{
					obj = string_0;
					string[] files = Directory.GetFiles((string)obj);
					obj = files;
					global::_003CModule_003E.string_22 = (string[])obj;
					num = 0;
					global::_003CModule_003E.int_56 = 0;
					while (true)
					{
						num = global::_003CModule_003E.int_56;
						obj12 = global::_003CModule_003E.string_22;
						IntPtr intPtr = (nint)((string[])obj12).LongLength;
						num2 = (int)(nint)intPtr;
						if (num >= num2)
						{
							break;
						}
						obj = global::_003CModule_003E.string_22;
						num2 = global::_003CModule_003E.int_56;
						obj = ((string[])obj)[num2];
						global::_003CModule_003E.string_23 = (string)obj;
						obj = global::_003CModule_003E.string_23;
						if (obj != null)
						{
							obj = global::_003CModule_003E.string_23;
							string extension = Path.GetExtension((string)obj);
							obj = extension;
							global::_003CModule_003E.string_24 = (string)obj;
							obj = global::_003CModule_003E.string_24;
							if (obj != null)
							{
								obj = global::_003CModule_003E.string_24;
								string text5 = ((string)obj).ToLower();
								obj = text5;
								global::_003CModule_003E.string_24 = (string)obj;
								num = 0;
								global::_003CModule_003E.bool_25 = false;
								obj = global::_003CModule_003E.string_24;
								obj12 = obj14;
								if ((string)obj == (string)obj12)
								{
									num = 1;
									global::_003CModule_003E.bool_25 = true;
								}
								else
								{
									obj = global::_003CModule_003E.string_24;
									obj12 = obj17;
									if ((string)obj == (string)obj12)
									{
										num = 1;
										global::_003CModule_003E.bool_25 = true;
									}
									else
									{
										obj = global::_003CModule_003E.string_24;
										obj12 = obj15;
										if ((string)obj == (string)obj12)
										{
											num = 1;
											global::_003CModule_003E.bool_25 = true;
										}
										else
										{
											obj = global::_003CModule_003E.string_24;
											obj12 = obj16;
											if ((string)obj == (string)obj12)
											{
												num = 1;
												global::_003CModule_003E.bool_25 = true;
											}
										}
									}
								}
								if (global::_003CModule_003E.bool_25)
								{
									obj = global::_003CModule_003E.string_23;
									string fileNameWithoutExtension = Path.GetFileNameWithoutExtension((string)obj);
									obj = fileNameWithoutExtension;
									global::_003CModule_003E.string_25 = (string)obj;
									obj = global::_003CModule_003E.string_25;
									if (obj != null)
									{
										obj = global::_003CModule_003E.string_25;
										int length = ((string)obj).Length;
										num = length;
										num2 = 0;
										if (num > 0)
										{
											obj = global::_003CModule_003E.list_6;
											obj12 = global::_003CModule_003E.string_25;
											((List<string>)obj).Add((string)obj12);
										}
									}
								}
							}
						}
						num = global::_003CModule_003E.int_56;
						num2 = 1;
						num++;
						global::_003CModule_003E.int_56 = num;
					}
				}
				catch
				{
				}
				obj = global::_003CModule_003E.list_6;
				string[] array = ((List<string>)obj).ToArray();
				obj = array;
				return (string[])obj;
			}
		}
		num = 0;
		obj = new string[0];
		return (string[])obj;
	}

	public unsafe static bool smethod_2(string string_2)
	{
		int num = 57;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = string_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenericDelegateCacheMajorRevision.CMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGRESOURCEFALLBACKCULTUREINTERNALbodyWithStateAndIndex);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 != 1)
														{
															while (true)
															{
																IL_04f9:
																byte b = *ptr2;
																while (true)
																{
																	IL_04e0:
																	ptr2++;
																	num = 206;
																	while (true)
																	{
																		IL_04d0:
																		if (b >= 1)
																		{
																			while (b <= 26)
																			{
																				while (true)
																				{
																					IL_04b0:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_04a0:
																							if (13 > b)
																							{
																								while (true)
																								{
																									IL_0493:
																									if (6 < b)
																									{
																										while (true)
																										{
																											IL_0483:
																											if (9 < b)
																											{
																												while (true)
																												{
																													IL_0473:
																													if (11 >= b)
																													{
																														while (true)
																														{
																															IL_0463:
																															if (11 > b)
																															{
																																while (10 >= b)
																																{
																																	while (10 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_03d3:
																																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																			num = 49;
																																			while (true)
																																			{
																																				IL_03ba:
																																				num6 -= 2;
																																				num = 230;
																																				while (num != 230)
																																				{
																																					if (num != 1211)
																																					{
																																						goto IL_079d;
																																					}
																																					switch (num)
																																					{
																																					case 49:
																																						goto IL_03ba;
																																					case 178:
																																					case 203:
																																						goto IL_03d3;
																																					case 73:
																																						goto IL_0443;
																																					case 139:
																																						goto IL_0453;
																																					case 154:
																																						goto IL_0463;
																																					case 172:
																																						goto IL_0473;
																																					case 132:
																																						goto IL_0483;
																																					case 129:
																																						goto IL_0493;
																																					case 202:
																																						goto IL_04a0;
																																					case 126:
																																						goto IL_04b0;
																																					case 96:
																																						goto IL_04c0;
																																					case 206:
																																						goto IL_04d0;
																																					case 133:
																																						goto IL_04e0;
																																					case 12:
																																					case 42:
																																						goto IL_04f9;
																																					case 8:
																																						goto IL_0504;
																																					case 68:
																																						goto IL_0512;
																																					case 88:
																																						goto IL_0520;
																																					case 61:
																																						goto IL_052e;
																																					case 34:
																																					case 65:
																																						goto IL_053c;
																																					case 38:
																																					case 100:
																																						goto IL_0555;
																																					case 30:
																																						goto IL_056e;
																																					case 163:
																																						goto IL_0581;
																																					case 189:
																																						goto IL_05a4;
																																					case 16:
																																						goto IL_05ae;
																																					case 116:
																																						goto IL_05bc;
																																					case 190:
																																						goto IL_05cf;
																																					case 107:
																																					case 109:
																																						goto IL_05dd;
																																					case 22:
																																						goto IL_060f;
																																					case 50:
																																						goto IL_061d;
																																					case 70:
																																					case 192:
																																						goto IL_0639;
																																					case 23:
																																						goto IL_0679;
																																					case 194:
																																						goto IL_0692;
																																					case 196:
																																						goto IL_069d;
																																					case 86:
																																						goto IL_06ab;
																																					case 19:
																																						goto IL_06b9;
																																					case 45:
																																					case 136:
																																						goto IL_06c7;
																																					case 74:
																																					case 207:
																																						goto IL_06da;
																																					case 4:
																																						goto IL_071a;
																																					case 43:
																																						goto IL_072e;
																																					case 211:
																																						goto IL_0741;
																																					case 135:
																																						goto IL_074f;
																																					case 72:
																																					case 193:
																																						goto IL_075d;
																																					case 210:
																																						goto IL_079d;
																																					case 71:
																																						goto IL_07b1;
																																					case 212:
																																						goto IL_07c4;
																																					case 66:
																																					case 128:
																																						goto IL_07d2;
																																					case 0:
																																						goto IL_0812;
																																					case 162:
																																						goto IL_082f;
																																					case 214:
																																						goto IL_0842;
																																					case 215:
																																						goto IL_0855;
																																					case 134:
																																						goto IL_0860;
																																					case 216:
																																						goto IL_0873;
																																					case 123:
																																						goto IL_0881;
																																					case 217:
																																						goto IL_0894;
																																					case 104:
																																						goto IL_08a2;
																																					case 106:
																																					case 176:
																																						goto IL_08b0;
																																					case 51:
																																					case 219:
																																						goto IL_08fb;
																																					case 59:
																																						goto IL_0914;
																																					case 131:
																																						goto IL_0922;
																																					case 115:
																																						goto IL_0930;
																																					case 221:
																																						goto IL_094c;
																																					case 117:
																																						goto IL_0960;
																																					case 11:
																																					case 220:
																																						goto IL_0973;
																																					case 20:
																																						goto IL_0987;
																																					case 167:
																																						goto IL_09db;
																																					case 175:
																																						goto IL_09e9;
																																					case 164:
																																						goto IL_09fc;
																																					case 64:
																																						goto IL_0a0a;
																																					case 60:
																																						goto IL_0a1d;
																																					case 124:
																																						goto IL_0a2b;
																																					case 89:
																																						goto IL_0a39;
																																					case 112:
																																						goto IL_0a47;
																																					case 18:
																																						goto IL_0a52;
																																					case 110:
																																					case 199:
																																						goto IL_0a69;
																																					case 7:
																																						goto IL_0ab1;
																																					case 191:
																																						goto IL_0ac4;
																																					case 118:
																																						goto IL_0ad2;
																																					case 79:
																																					case 187:
																																						goto IL_0ae9;
																																					case 95:
																																						goto IL_0b02;
																																					case 46:
																																						goto IL_0b10;
																																					case 41:
																																						goto IL_0b1e;
																																					case 55:
																																					case 223:
																																						goto IL_0b31;
																																					case 149:
																																						goto IL_0b45;
																																					case 204:
																																						goto IL_0b84;
																																					case 137:
																																						goto IL_0b97;
																																					case 32:
																																						goto IL_0ba5;
																																					case 111:
																																					case 151:
																																						goto IL_0bb0;
																																					case 200:
																																						goto IL_0bc4;
																																					case 208:
																																						goto IL_0c03;
																																					case 180:
																																						goto IL_0c1f;
																																					case 10:
																																						goto IL_0c2d;
																																					case 13:
																																					case 146:
																																						goto IL_0c3b;
																																					case 17:
																																						goto IL_0c7b;
																																					case 122:
																																						goto IL_0c98;
																																					case 35:
																																						goto IL_0cab;
																																					case 161:
																																						goto IL_0cb9;
																																					case 195:
																																						goto IL_0ccc;
																																					case 63:
																																					case 165:
																																						goto IL_0cd7;
																																					case 170:
																																						goto IL_0cf3;
																																					case 179:
																																						goto IL_0d01;
																																					case 94:
																																					case 153:
																																						goto IL_0d0c;
																																					case 102:
																																						goto IL_0d5e;
																																					case 108:
																																						goto IL_0d71;
																																					case 28:
																																						goto IL_0d7c;
																																					case 53:
																																					case 168:
																																						goto IL_0d8a;
																																					case 31:
																																						goto IL_0da2;
																																					case 218:
																																						goto IL_0db9;
																																					case 148:
																																					case 184:
																																						goto IL_0dd0;
																																					case 97:
																																						goto IL_0e11;
																																					case 58:
																																						goto IL_0e25;
																																					case 121:
																																						goto IL_0e38;
																																					case 1:
																																						goto IL_0e46;
																																					case 173:
																																						goto IL_0e51;
																																					case 84:
																																						goto IL_0e5f;
																																					case 101:
																																					case 142:
																																						goto IL_0e6d;
																																					case 29:
																																						goto IL_0e8b;
																																					case 27:
																																						goto IL_0e99;
																																					case 177:
																																						goto IL_0ea7;
																																					case 209:
																																					case 222:
																																						goto IL_0eba;
																																					case 67:
																																						goto IL_0ed2;
																																					case 150:
																																						goto IL_0ee0;
																																					case 127:
																																						goto IL_0eee;
																																					case 205:
																																						goto IL_0f01;
																																					case 141:
																																						goto IL_0f0f;
																																					case 21:
																																					case 182:
																																						goto IL_0f1d;
																																					case 33:
																																						goto IL_0f31;
																																					case 92:
																																						goto IL_0f83;
																																					case 52:
																																						goto IL_0f91;
																																					case 2:
																																					case 5:
																																					case 24:
																																					case 44:
																																					case 48:
																																					case 69:
																																					case 75:
																																					case 76:
																																					case 80:
																																					case 83:
																																					case 85:
																																					case 87:
																																					case 90:
																																					case 98:
																																					case 103:
																																					case 130:
																																					case 138:
																																					case 140:
																																					case 144:
																																					case 145:
																																					case 155:
																																					case 157:
																																					case 159:
																																					case 160:
																																					case 169:
																																					case 181:
																																					case 183:
																																					case 185:
																																					case 188:
																																						goto end_IL_0443;
																																					case 3:
																																					case 6:
																																					case 9:
																																					case 14:
																																					case 15:
																																					case 25:
																																					case 36:
																																					case 39:
																																					case 47:
																																					case 54:
																																					case 62:
																																					case 77:
																																					case 82:
																																					case 91:
																																					case 99:
																																					case 113:
																																					case 114:
																																					case 119:
																																					case 125:
																																					case 147:
																																					case 152:
																																					case 156:
																																					case 158:
																																					case 166:
																																					case 171:
																																					case 174:
																																					case 186:
																																					case 198:
																																						goto end_IL_03a7;
																																					case 197:
																																						goto end_IL_0fb4;
																																					case 213:
																																						goto end_IL_0fc7;
																																					case 40:
																																						goto end_IL_0fd1;
																																					case 105:
																																						goto end_IL_0fdc;
																																					case 143:
																																						goto end_IL_0fec;
																																					case 81:
																																					case 201:
																																						goto end_IL_0ffc;
																																					case 93:
																																						goto end_IL_100c;
																																					case 37:
																																						goto end_IL_101c;
																																					case 26:
																																						goto end_IL_102c;
																																					case 56:
																																						goto end_IL_103c;
																																					case 57:
																																						goto end_IL_104c;
																																					case 78:
																																					case 120:
																																						goto IL_1067;
																																					}
																																					continue;
																																					end_IL_03a7:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_04d0;
																																		continue;
																																		end_IL_0443:
																																		break;
																																		IL_0443:;
																																	}
																																	break;
																																	IL_0453:;
																																}
																																break;
																															}
																															goto IL_0973;
																															IL_09e9:
																															ptr2 += 8;
																															goto end_IL_04d0;
																															IL_0973:
																															array[num6 - 2] = 0;
																															goto IL_0987;
																															IL_0987:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																															goto IL_09db;
																															IL_09db:
																															num6--;
																															goto IL_09e9;
																														}
																														break;
																													}
																													goto IL_09fc;
																													IL_0a0a:
																													if (12 > b)
																													{
																														break;
																													}
																													goto end_IL_04d0;
																													IL_09fc:
																													if (12 < b)
																													{
																														break;
																													}
																													goto IL_0a0a;
																												}
																												break;
																											}
																											goto IL_0692;
																											IL_072e:
																											num6--;
																											goto end_IL_04d0;
																											IL_0692:
																											if (9 > b)
																											{
																												goto IL_069d;
																											}
																											goto IL_06da;
																											IL_069d:
																											if (7 < b)
																											{
																												goto IL_06ab;
																											}
																											goto IL_07c4;
																											IL_06ab:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_06b9;
																											IL_06b9:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_06c7;
																											IL_06c7:
																											num6--;
																											goto end_IL_04d0;
																											IL_07c4:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_07d2;
																											IL_07d2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0812;
																											IL_0812:
																											array[num6 - 2] = 0;
																											num = 162;
																											goto IL_082f;
																											IL_082f:
																											num6--;
																											goto end_IL_04d0;
																											IL_06da:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_071a;
																											IL_071a:
																											array[num6 - 2] = 0;
																											goto IL_072e;
																										}
																										break;
																									}
																									goto IL_0504;
																									IL_0842:
																									num6--;
																									goto end_IL_04d0;
																									IL_0504:
																									if (6 > b)
																									{
																										goto IL_0512;
																									}
																									goto IL_0639;
																									IL_0512:
																									if (3 < b)
																									{
																										goto IL_0520;
																									}
																									goto IL_05cf;
																									IL_0520:
																									if (4 >= b)
																									{
																										goto IL_052e;
																									}
																									goto IL_0741;
																									IL_052e:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_053c;
																									IL_053c:
																									array[num6] = 0;
																									num = 163;
																									goto IL_0581;
																									IL_0581:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_05a4;
																									IL_05a4:
																									array2[num6] = null;
																									goto IL_05ae;
																									IL_05ae:
																									num6++;
																									goto IL_05bc;
																									IL_05bc:
																									ptr2 += 8;
																									goto end_IL_04d0;
																									IL_0741:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_074f;
																									IL_074f:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_075d;
																									IL_075d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_079d;
																									IL_079d:
																									array[num6 - 2] = 0;
																									goto IL_07b1;
																									IL_07b1:
																									num6--;
																									goto end_IL_04d0;
																									IL_05cf:
																									if (3 <= b)
																									{
																										goto IL_05dd;
																									}
																									goto IL_0855;
																									IL_05dd:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									num = 22;
																									goto IL_060f;
																									IL_060f:
																									ptr2 += 8;
																									goto IL_061d;
																									IL_061d:
																									num6--;
																									num = 91;
																									goto end_IL_04d0;
																									IL_0855:
																									if (1 >= b)
																									{
																										goto IL_0860;
																									}
																									goto IL_0894;
																									IL_0860:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_08fb;
																									IL_08fb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_0914;
																									IL_0914:
																									array[num6] = 0;
																									goto IL_0922;
																									IL_0922:
																									num6++;
																									goto IL_0930;
																									IL_0930:
																									ptr2 += 8;
																									num = 36;
																									goto end_IL_04d0;
																									IL_0894:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_08a2;
																									IL_08a2:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_08b0;
																									IL_08b0:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									num = 221;
																									goto IL_094c;
																									IL_094c:
																									array[num6 - 2] = 0;
																									goto IL_0960;
																									IL_0960:
																									num6--;
																									goto end_IL_04d0;
																									IL_0639:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0679;
																									IL_0679:
																									array[num6 - 2] = 0;
																									goto IL_0842;
																								}
																								break;
																							}
																							goto IL_0555;
																							IL_0881:
																							ptr2 += 16;
																							goto end_IL_04d0;
																							IL_0555:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_056e;
																							IL_056e:
																							array[num6] = 1;
																							goto IL_0873;
																							IL_0873:
																							num6++;
																							goto IL_0881;
																						}
																						break;
																					}
																					goto IL_0a1d;
																					IL_0f0f:
																					if (19 > b)
																					{
																						break;
																					}
																					goto IL_0f1d;
																					IL_0a1d:
																					if (20 < b)
																					{
																						goto IL_0a2b;
																					}
																					goto IL_0ccc;
																					IL_0a2b:
																					if (23 >= b)
																					{
																						goto IL_0a39;
																					}
																					goto IL_0b97;
																					IL_0a39:
																					if (23 > b)
																					{
																						goto IL_0a47;
																					}
																					goto IL_0b31;
																					IL_0a47:
																					if (21 >= b)
																					{
																						goto IL_0a52;
																					}
																					goto IL_0ac4;
																					IL_0a52:
																					if (21 > b)
																					{
																						break;
																					}
																					num = 110;
																					goto IL_0a69;
																					IL_0f1d:
																					array[num6 - 2] = 0;
																					goto IL_0f31;
																					IL_0a69:
																					ptr2 = ((array2[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0ab1;
																					IL_0ab1:
																					num6--;
																					goto end_IL_04d0;
																					IL_0ac4:
																					if (22 < b)
																					{
																						break;
																					}
																					goto IL_0ad2;
																					IL_0ad2:
																					if (22 > b)
																					{
																						break;
																					}
																					num = 79;
																					goto IL_0ae9;
																					IL_0f31:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<string, string, bool>)intptr_0[*(int*)(ptr2 + num3)])((string)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																					goto IL_0f83;
																					IL_0ae9:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																					goto IL_0b02;
																					IL_0b02:
																					array[num6] = 3;
																					goto IL_0b10;
																					IL_0b10:
																					num6++;
																					goto IL_0b1e;
																					IL_0b1e:
																					ptr2 += 16;
																					goto end_IL_04d0;
																					IL_0b31:
																					array[num6 - 1] = 3;
																					goto IL_0b45;
																					IL_0b45:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0b84;
																					IL_0b84:
																					ptr2 += 8;
																					goto end_IL_04d0;
																					IL_0b97:
																					if (25 >= b)
																					{
																						goto IL_0ba5;
																					}
																					goto IL_0cab;
																					IL_0ba5:
																					if (25 <= b)
																					{
																						goto IL_0bb0;
																					}
																					goto IL_0c1f;
																					IL_0bb0:
																					array[num6 - 1] = 0;
																					goto IL_0bc4;
																					IL_0bc4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0c03;
																					IL_0c03:
																					ptr2 += 8;
																					num = 25;
																					goto end_IL_04d0;
																					IL_0c1f:
																					if (24 < b)
																					{
																						break;
																					}
																					goto IL_0c2d;
																					IL_0c2d:
																					if (24 > b)
																					{
																						break;
																					}
																					goto IL_0c3b;
																					IL_0c3b:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0c7b;
																					IL_0c7b:
																					array[num6 - 2] = 3;
																					num = 122;
																					goto IL_0c98;
																					IL_0c98:
																					num6--;
																					goto end_IL_04d0;
																					IL_0cab:
																					if (26 < b)
																					{
																						break;
																					}
																					goto IL_0cb9;
																					IL_0cb9:
																					if (26 > b)
																					{
																					}
																					break;
																					IL_0ccc:
																					if (20 <= b)
																					{
																						goto IL_0cd7;
																					}
																					goto IL_0cf3;
																					IL_0cd7:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_04d0;
																					IL_0cf3:
																					if (16 >= b)
																					{
																						goto IL_0d01;
																					}
																					goto IL_0e38;
																					IL_0d01:
																					if (16 <= b)
																					{
																						goto IL_0d0c;
																					}
																					goto IL_0d71;
																					IL_0d0c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0d5e;
																					IL_0d5e:
																					num6--;
																					goto end_IL_04d0;
																					IL_0d71:
																					if (14 >= b)
																					{
																						goto IL_0d7c;
																					}
																					goto IL_0da2;
																					IL_0d7c:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_0d8a;
																					IL_0d8a:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_04d0;
																					IL_0da2:
																					if (15 < b)
																					{
																						break;
																					}
																					num = 218;
																					goto IL_0db9;
																					IL_0f83:
																					num6--;
																					goto IL_0f91;
																					IL_0db9:
																					if (15 > b)
																					{
																						break;
																					}
																					num = 184;
																					goto IL_0dd0;
																					IL_0f91:
																					ptr2 += 8;
																					goto end_IL_04d0;
																					IL_0dd0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																					goto IL_0e11;
																					IL_0e11:
																					array[num6 - 2] = 0;
																					goto IL_0e25;
																					IL_0e25:
																					num6--;
																					goto end_IL_04d0;
																					IL_0e38:
																					if (18 >= b)
																					{
																						goto IL_0e46;
																					}
																					goto IL_0f01;
																					IL_0e46:
																					if (18 > b)
																					{
																						goto IL_0e51;
																					}
																					goto IL_0eba;
																					IL_0e51:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_0e5f;
																					IL_0e5f:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0e6d;
																					IL_0e6d:
																					array2[num6] = ((delegate*<string>)intptr_0[*(int*)(ptr2 + num3)])();
																					goto IL_0e8b;
																					IL_0e8b:
																					array[num6] = 5;
																					goto IL_0e99;
																					IL_0e99:
																					num6++;
																					goto IL_0ea7;
																					IL_0ea7:
																					ptr2 += 8;
																					goto end_IL_04d0;
																					IL_0eba:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0ed2;
																					IL_0ed2:
																					array[num6] = 5;
																					goto IL_0ee0;
																					IL_0ee0:
																					num6++;
																					goto IL_0eee;
																					IL_0eee:
																					ptr2 += 8;
																					goto end_IL_04d0;
																					IL_0f01:
																					if (19 < b)
																					{
																						break;
																					}
																					goto IL_0f0f;
																				}
																				break;
																				IL_04c0:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_04d0:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_1067;
														IL_1067:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
														continue;
														end_IL_0fb4:
														break;
													}
													continue;
													end_IL_0fc7:
													break;
												}
												continue;
												end_IL_0fd1:
												break;
											}
											continue;
											end_IL_0fdc:
											break;
										}
										continue;
										end_IL_0fec:
										break;
									}
									continue;
									end_IL_0ffc:
									break;
								}
								continue;
								end_IL_100c:
								break;
							}
							continue;
							end_IL_101c:
							break;
						}
						continue;
						end_IL_102c:
						break;
					}
					continue;
					end_IL_103c:
					break;
				}
				continue;
				end_IL_104c:
				break;
			}
		}
	}

	public static bool smethod_3()
	{
		string text = string_1;
		return true;
	}

	public unsafe static void smethod_4(string string_2)
	{
		int num = 200;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 304;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = string_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CompressedSoapNonPositiveInteger.StrongNameHelpersInstance);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0644:
																	if (b >= 1)
																	{
																		while (b <= 42)
																		{
																			while (true)
																			{
																				IL_0627:
																				if (21 < b)
																				{
																					while (true)
																					{
																						IL_0617:
																						if (32 >= b)
																						{
																							while (true)
																							{
																								IL_0607:
																								if (32 > b)
																								{
																									while (true)
																									{
																										IL_05f7:
																										if (26 < b)
																										{
																											while (true)
																											{
																												IL_05e7:
																												if (29 < b)
																												{
																													while (true)
																													{
																														IL_05d7:
																														if (30 >= b)
																														{
																															while (30 <= b)
																															{
																																num = 357;
																																while (true)
																																{
																																	if (num != 357)
																																	{
																																		if (num != 1338)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 3:
																																			goto IL_05c4;
																																		case 316:
																																			goto IL_05d7;
																																		case 156:
																																			goto IL_05e7;
																																		case 220:
																																			goto IL_05f7;
																																		case 116:
																																			goto IL_0607;
																																		case 338:
																																			goto IL_0617;
																																		case 250:
																																			goto IL_0627;
																																		case 167:
																																			goto IL_0634;
																																		case 237:
																																			goto IL_0644;
																																		case 196:
																																			goto end_IL_0644;
																																		case 152:
																																		case 310:
																																			goto end_IL_0654;
																																		case 72:
																																			goto IL_0678;
																																		case 170:
																																			goto IL_0691;
																																		case 129:
																																			goto IL_069f;
																																		case 23:
																																			goto IL_06aa;
																																		case 31:
																																			goto IL_06bd;
																																		case 51:
																																		case 172:
																																			goto IL_06d0;
																																		case 99:
																																			goto IL_06f7;
																																		case 188:
																																			goto IL_0707;
																																		case 198:
																																			goto IL_0717;
																																		case 60:
																																			goto IL_0725;
																																		case 263:
																																			goto IL_0738;
																																		case 48:
																																			goto IL_0746;
																																		case 55:
																																			goto IL_0754;
																																		case 22:
																																		case 155:
																																			goto IL_075f;
																																		case 166:
																																			goto IL_079f;
																																		case 34:
																																			goto IL_07b3;
																																		case 224:
																																			goto IL_07c6;
																																		case 19:
																																			goto IL_07d1;
																																		case 130:
																																		case 244:
																																			goto IL_07dc;
																																		case 221:
																																			goto IL_0821;
																																		case 112:
																																			goto IL_082f;
																																		case 13:
																																			goto IL_0842;
																																		case 141:
																																			goto IL_0855;
																																		case 124:
																																			goto IL_086c;
																																		case 111:
																																		case 216:
																																			goto IL_0877;
																																		case 7:
																																			goto IL_08b7;
																																		case 53:
																																			goto IL_08d0;
																																		case 207:
																																			goto IL_08de;
																																		case 0:
																																		case 44:
																																			goto IL_08f5;
																																		case 93:
																																			goto IL_0935;
																																		case 41:
																																			goto IL_0949;
																																		case 5:
																																		case 256:
																																			goto IL_095c;
																																		case 230:
																																			goto IL_09be;
																																		case 115:
																																		case 272:
																																			goto IL_09d1;
																																		case 186:
																																		case 292:
																																			goto IL_09ed;
																																		case 293:
																																			goto IL_0a0b;
																																		case 178:
																																			goto IL_0a19;
																																		case 195:
																																			goto IL_0a24;
																																		case 1:
																																			goto IL_0a2f;
																																		case 40:
																																			goto IL_0a48;
																																		case 113:
																																			goto IL_0a5b;
																																		case 255:
																																			goto IL_0a66;
																																		case 28:
																																			goto IL_0a82;
																																		case 248:
																																			goto IL_0a90;
																																		case 101:
																																		case 290:
																																			goto IL_0aa3;
																																		case 39:
																																			goto IL_0af2;
																																		case 278:
																																			goto IL_0b00;
																																		case 169:
																																			goto IL_0b0e;
																																		case 223:
																																			goto IL_0b19;
																																		case 81:
																																			goto IL_0b27;
																																		case 192:
																																		case 229:
																																			goto IL_0b35;
																																		case 194:
																																			goto IL_0b53;
																																		case 47:
																																			goto IL_0b6f;
																																		case 102:
																																		case 218:
																																			goto IL_0b7d;
																																		case 25:
																																			goto IL_0bcf;
																																		case 280:
																																		case 291:
																																			goto IL_0be2;
																																		case 251:
																																			goto IL_0bfb;
																																		case 121:
																																			goto IL_0c09;
																																		case 228:
																																			goto IL_0c25;
																																		case 138:
																																			goto IL_0c30;
																																		case 20:
																																		case 71:
																																			goto IL_0c3e;
																																		case 30:
																																			goto IL_0c7e;
																																		case 66:
																																			goto IL_0c92;
																																		case 24:
																																			goto IL_0ca5;
																																		case 294:
																																			goto IL_0cb8;
																																		case 109:
																																		case 295:
																																			goto IL_0ccb;
																																		case 154:
																																			goto IL_0cdf;
																																		case 299:
																																			goto IL_0d23;
																																		case 269:
																																			goto IL_0d2e;
																																		case 36:
																																		case 298:
																																			goto IL_0d3c;
																																		case 17:
																																			goto IL_0d4f;
																																		case 267:
																																			goto IL_0d5d;
																																		case 58:
																																		case 100:
																																			goto IL_0d6b;
																																		case 219:
																																			goto IL_0dab;
																																		case 211:
																																			goto IL_0dbf;
																																		case 303:
																																			goto IL_0dd2;
																																		case 146:
																																		case 306:
																																			goto IL_0deb;
																																		case 69:
																																			goto IL_0e14;
																																		case 38:
																																			goto IL_0e22;
																																		case 312:
																																			goto IL_0e35;
																																		case 257:
																																			goto IL_0e49;
																																		case 281:
																																		case 314:
																																			goto IL_0e5c;
																																		case 183:
																																			goto IL_0e9c;
																																		case 14:
																																			goto IL_0eb9;
																																		case 317:
																																			goto IL_0ecc;
																																		case 321:
																																			goto IL_0edf;
																																		case 323:
																																			goto IL_0ef2;
																																		case 324:
																																			goto IL_0f0e;
																																		case 247:
																																			goto IL_0f1c;
																																		case 133:
																																			goto IL_0f2a;
																																		case 326:
																																			goto IL_0f3d;
																																		case 2:
																																		case 275:
																																			goto IL_0f4b;
																																		case 148:
																																			goto IL_0f93;
																																		case 77:
																																		case 328:
																																			goto IL_0fa6;
																																		case 333:
																																			goto IL_0fbe;
																																		case 114:
																																			goto IL_0fcc;
																																		case 232:
																																		case 284:
																																			goto IL_0fda;
																																		case 6:
																																			goto IL_0fe8;
																																		case 15:
																																			goto IL_100b;
																																		case 173:
																																			goto IL_1015;
																																		case 259:
																																			goto IL_1023;
																																		case 337:
																																			goto IL_1036;
																																		case 52:
																																		case 131:
																																			goto IL_1044;
																																		case 147:
																																			goto IL_1058;
																																		case 253:
																																			goto IL_1097;
																																		case 345:
																																			goto IL_10aa;
																																		case 96:
																																		case 97:
																																			goto IL_10b8;
																																		case 249:
																																			goto IL_10cc;
																																		case 9:
																																			goto IL_110b;
																																		case 222:
																																		case 348:
																																			goto IL_111e;
																																		case 153:
																																			goto IL_1137;
																																		case 82:
																																			goto IL_1145;
																																		case 349:
																																			goto IL_1155;
																																		case 350:
																																			goto IL_1168;
																																		case 142:
																																			goto IL_117b;
																																		case 239:
																																			goto IL_118f;
																																		case 297:
																																			goto IL_11c7;
																																		case 63:
																																			goto IL_11da;
																																		case 236:
																																			goto IL_11e8;
																																		case 163:
																																		case 242:
																																			goto IL_11f6;
																																		case 103:
																																			goto IL_120f;
																																		case 277:
																																			goto IL_1222;
																																		case 54:
																																		case 225:
																																			goto IL_122d;
																																		case 56:
																																			goto IL_1241;
																																		case 98:
																																			goto IL_1280;
																																		case 187:
																																			goto IL_1293;
																																		case 226:
																																			goto IL_12a1;
																																		case 110:
																																		case 128:
																																			goto IL_12af;
																																		case 108:
																																			goto IL_12cc;
																																		case 288:
																																			goto IL_131e;
																																		case 260:
																																			goto IL_132c;
																																		case 76:
																																			goto IL_133f;
																																		case 158:
																																			goto IL_134d;
																																		case 202:
																																		case 238:
																																			goto IL_135b;
																																		case 270:
																																			goto IL_1373;
																																		case 57:
																																			goto IL_1381;
																																		case 85:
																																			goto IL_138f;
																																		case 150:
																																			goto IL_13ab;
																																		case 184:
																																			goto IL_13b6;
																																		case 296:
																																		case 339:
																																			goto IL_13c4;
																																		case 165:
																																			goto IL_140d;
																																		case 233:
																																			goto IL_1421;
																																		case 50:
																																			goto IL_1434;
																																		case 289:
																																			goto IL_1442;
																																		case 35:
																																		case 73:
																																			goto IL_1450;
																																		case 235:
																																			goto IL_1469;
																																		case 215:
																																			goto IL_147c;
																																		case 240:
																																			goto IL_148a;
																																		case 159:
																																		case 287:
																																			goto IL_1498;
																																		case 90:
																																			goto IL_14ac;
																																		case 265:
																																			goto IL_14f8;
																																		case 87:
																																			goto IL_1506;
																																		case 43:
																																			goto IL_1519;
																																		case 309:
																																			goto IL_1527;
																																		case 174:
																																		case 325:
																																			goto IL_1532;
																																		case 160:
																																			goto IL_1546;
																																		case 210:
																																			goto IL_1585;
																																		case 59:
																																			goto IL_1598;
																																		case 332:
																																			goto IL_15a6;
																																		case 175:
																																		case 341:
																																			goto IL_15b4;
																																		case 125:
																																			goto IL_15d2;
																																		case 336:
																																			goto IL_15e0;
																																		case 201:
																																			goto IL_15ee;
																																		case 88:
																																			goto IL_1601;
																																		case 67:
																																			goto IL_160f;
																																		case 151:
																																			goto IL_161d;
																																		case 10:
																																		case 234:
																																			goto IL_162b;
																																		case 136:
																																			goto IL_163f;
																																		case 241:
																																			goto IL_168b;
																																		case 94:
																																			goto IL_1699;
																																		case 342:
																																			goto IL_16b5;
																																		case 191:
																																		case 318:
																																			goto IL_16c3;
																																		case 180:
																																			goto IL_16d1;
																																		case 209:
																																			goto IL_16ef;
																																		case 106:
																																			goto end_IL_05b1;
																																		case 189:
																																			goto IL_1710;
																																		case 320:
																																			goto IL_171e;
																																		case 33:
																																			goto IL_172c;
																																		case 42:
																																			goto IL_173a;
																																		case 74:
																																			goto IL_1748;
																																		case 61:
																																		case 302:
																																			goto IL_1756;
																																		case 203:
																																			goto IL_176a;
																																		case 268:
																																			goto IL_17a8;
																																		case 344:
																																			goto IL_17cd;
																																		case 68:
																																		case 214:
																																			goto IL_17db;
																																		case 18:
																																			goto IL_17ef;
																																		case 190:
																																			goto IL_182e;
																																		case 105:
																																		case 193:
																																			goto IL_1841;
																																		case 26:
																																			goto IL_18a8;
																																		case 120:
																																			goto IL_18bb;
																																		case 252:
																																			goto IL_18c6;
																																		case 182:
																																		case 273:
																																			goto IL_18d1;
																																		case 64:
																																			goto IL_18e5;
																																		case 62:
																																			goto IL_1924;
																																		case 204:
																																			goto IL_1934;
																																		case 45:
																																			goto IL_193f;
																																		case 16:
																																		case 21:
																																		case 29:
																																		case 32:
																																		case 37:
																																		case 49:
																																		case 65:
																																		case 78:
																																		case 91:
																																		case 95:
																																		case 107:
																																		case 123:
																																		case 126:
																																		case 132:
																																		case 134:
																																		case 135:
																																		case 137:
																																		case 139:
																																		case 143:
																																		case 145:
																																		case 149:
																																		case 161:
																																		case 162:
																																		case 164:
																																		case 171:
																																		case 177:
																																		case 181:
																																		case 197:
																																		case 205:
																																		case 206:
																																		case 208:
																																		case 212:
																																		case 231:
																																		case 245:
																																		case 254:
																																		case 261:
																																		case 276:
																																		case 300:
																																		case 301:
																																		case 307:
																																		case 308:
																																		case 331:
																																		case 340:
																																		case 343:
																																		case 347:
																																			goto end_IL_05c4;
																																		case 4:
																																		case 8:
																																		case 11:
																																		case 12:
																																		case 46:
																																		case 75:
																																		case 79:
																																		case 80:
																																		case 83:
																																		case 84:
																																		case 86:
																																		case 89:
																																		case 92:
																																		case 104:
																																		case 117:
																																		case 118:
																																		case 119:
																																		case 122:
																																		case 127:
																																		case 144:
																																		case 157:
																																		case 176:
																																		case 179:
																																		case 185:
																																		case 213:
																																		case 227:
																																		case 243:
																																		case 246:
																																		case 264:
																																		case 266:
																																		case 279:
																																		case 282:
																																		case 283:
																																		case 285:
																																		case 286:
																																		case 305:
																																		case 311:
																																		case 313:
																																		case 319:
																																		case 322:
																																		case 327:
																																		case 330:
																																		case 334:
																																		case 335:
																																		case 346:
																																			goto end_IL_0664;
																																		case 315:
																																			goto end_IL_195d;
																																		case 271:
																																			goto end_IL_1970;
																																		case 27:
																																			goto end_IL_197a;
																																		case 140:
																																			goto end_IL_1985;
																																		case 304:
																																			goto end_IL_1995;
																																		case 70:
																																		case 168:
																																			goto end_IL_19a5;
																																		case 217:
																																			goto end_IL_19b5;
																																		case 274:
																																			goto end_IL_19ce;
																																		case 329:
																																			goto end_IL_19de;
																																		case 199:
																																			goto end_IL_19ee;
																																		case 200:
																																			goto end_IL_19fe;
																																		case 258:
																																		case 262:
																																			return;
																																		}
																																		continue;
																																	}
																																	goto IL_117b;
																																	IL_118f:
																																	array2[num6 - 1] = ((delegate*<string, string>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])((string)array2[num6 - 1]);
																																	goto IL_11c7;
																																	IL_11c7:
																																	ptr2 += 8;
																																	goto end_IL_0664;
																																	IL_117b:
																																	array[num6 - 1] = 5;
																																	goto IL_118f;
																																	continue;
																																	end_IL_05b1:
																																	break;
																																}
																																goto IL_16fd;
																																continue;
																																end_IL_05c4:
																																break;
																																IL_05c4:;
																															}
																															break;
																														}
																														goto IL_11da;
																														IL_120f:
																														num6--;
																														goto end_IL_0664;
																														IL_11da:
																														if (31 < b)
																														{
																															break;
																														}
																														goto IL_11e8;
																														IL_11e8:
																														if (31 > b)
																														{
																															break;
																														}
																														goto IL_11f6;
																														IL_11f6:
																														global::_003CModule_003E.string_26 = (string)array2[num6 - 1];
																														goto IL_120f;
																													}
																													break;
																												}
																												goto IL_0691;
																												IL_0ef2:
																												ptr2 += 8;
																												num = 279;
																												goto end_IL_0664;
																												IL_0691:
																												if (29 > b)
																												{
																													goto IL_069f;
																												}
																												goto IL_0ccb;
																												IL_069f:
																												if (27 >= b)
																												{
																													goto IL_06aa;
																												}
																												goto IL_06bd;
																												IL_06aa:
																												if (27 > b)
																												{
																													break;
																												}
																												goto IL_0e5c;
																												IL_0e5c:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0e9c;
																												IL_0e9c:
																												array[num6 - 2] = 3;
																												num = 14;
																												goto IL_0eb9;
																												IL_0eb9:
																												num6--;
																												goto end_IL_0664;
																												IL_06bd:
																												if (28 < b)
																												{
																													break;
																												}
																												goto IL_0f3d;
																												IL_0f3d:
																												if (28 > b)
																												{
																													break;
																												}
																												goto IL_0f4b;
																												IL_0f4b:
																												ptr2 = ((array2[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0f93;
																												IL_0f93:
																												num6--;
																												goto end_IL_0664;
																												IL_0ccb:
																												array[num6 - 1] = 3;
																												goto IL_0cdf;
																												IL_0cdf:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_0ef2;
																											}
																											break;
																										}
																										goto IL_1222;
																										IL_1469:
																										num6--;
																										goto end_IL_0664;
																										IL_1222:
																										if (26 <= b)
																										{
																											goto IL_122d;
																										}
																										goto IL_1293;
																										IL_122d:
																										array[num6 - 1] = 3;
																										goto IL_1241;
																										IL_1241:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_1280;
																										IL_1280:
																										ptr2 += 8;
																										goto end_IL_0664;
																										IL_1293:
																										if (23 >= b)
																										{
																											goto IL_12a1;
																										}
																										goto IL_13ab;
																										IL_12a1:
																										if (23 <= b)
																										{
																											goto IL_12af;
																										}
																										goto IL_133f;
																										IL_12af:
																										array[num6 - 2] = 0;
																										num = 108;
																										goto IL_12cc;
																										IL_12cc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<string, string, bool>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])((string)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																										goto IL_131e;
																										IL_131e:
																										num6--;
																										goto IL_132c;
																										IL_132c:
																										ptr2 += 8;
																										goto end_IL_0664;
																										IL_133f:
																										if (22 < b)
																										{
																											break;
																										}
																										goto IL_134d;
																										IL_134d:
																										if (22 > b)
																										{
																											break;
																										}
																										goto IL_135b;
																										IL_135b:
																										array2[num6] = array5[*(int*)(ptr2 + num3)];
																										goto IL_1373;
																										IL_1373:
																										array[num6] = 5;
																										goto IL_1381;
																										IL_1381:
																										num6++;
																										goto IL_138f;
																										IL_138f:
																										ptr2 += 8;
																										num = 179;
																										goto end_IL_0664;
																										IL_13ab:
																										if (24 >= b)
																										{
																											goto IL_13b6;
																										}
																										goto IL_1434;
																										IL_13b6:
																										if (24 > b)
																										{
																											break;
																										}
																										goto IL_13c4;
																										IL_13c4:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 165;
																										goto IL_140d;
																										IL_140d:
																										array[num6 - 2] = 3;
																										goto IL_1421;
																										IL_1421:
																										num6--;
																										goto end_IL_0664;
																										IL_1434:
																										if (25 < b)
																										{
																											break;
																										}
																										goto IL_1442;
																										IL_1442:
																										if (25 > b)
																										{
																											break;
																										}
																										goto IL_1450;
																										IL_1450:
																										string_1 = (string)array2[num6 - 1];
																										goto IL_1469;
																									}
																									break;
																								}
																								goto IL_09d1;
																								IL_09d1:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								goto end_IL_0664;
																							}
																							break;
																						}
																						goto IL_147c;
																						IL_1934:
																						if (42 < b)
																						{
																							break;
																						}
																						goto IL_193f;
																						IL_147c:
																						if (37 >= b)
																						{
																							goto IL_148a;
																						}
																						goto IL_1710;
																						IL_148a:
																						if (37 <= b)
																						{
																							goto IL_1498;
																						}
																						goto IL_1519;
																						IL_1498:
																						array[num6 - 2] = 5;
																						goto IL_14ac;
																						IL_14ac:
																						array2[num6 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (IEnumerator)array2[num6 - 1]);
																						goto IL_14f8;
																						IL_14f8:
																						num6--;
																						goto IL_1506;
																						IL_1506:
																						ptr2 += 8;
																						goto end_IL_0664;
																						IL_1519:
																						if (34 >= b)
																						{
																							goto IL_1527;
																						}
																						goto IL_1601;
																						IL_1527:
																						if (34 <= b)
																						{
																							goto IL_1532;
																						}
																						goto IL_1598;
																						IL_1532:
																						array[num6 - 1] = 3;
																						goto IL_1546;
																						IL_1546:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1585;
																						IL_1585:
																						ptr2 += 8;
																						goto end_IL_0664;
																						IL_1598:
																						if (33 < b)
																						{
																							break;
																						}
																						goto IL_15a6;
																						IL_15a6:
																						if (33 > b)
																						{
																							break;
																						}
																						goto IL_15b4;
																						IL_15b4:
																						array2[num6] = ((delegate*<string>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])();
																						goto IL_15d2;
																						IL_15d2:
																						array[num6] = 5;
																						goto IL_15e0;
																						IL_15e0:
																						num6++;
																						goto IL_15ee;
																						IL_15ee:
																						ptr2 += 8;
																						goto end_IL_0664;
																						IL_1601:
																						if (35 < b)
																						{
																							goto IL_160f;
																						}
																						goto IL_16b5;
																						IL_160f:
																						if (36 < b)
																						{
																							break;
																						}
																						goto IL_161d;
																						IL_161d:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_162b;
																						IL_162b:
																						array[num6 - 2] = 5;
																						goto IL_163f;
																						IL_163f:
																						array2[num6 - 2] = ((delegate*<string, string, IEnumerator>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])((string)array2[num6 - 2], (string)array2[num6 - 1]);
																						goto IL_168b;
																						IL_168b:
																						num6--;
																						goto IL_1699;
																						IL_1699:
																						ptr2 += 8;
																						num = 118;
																						goto end_IL_0664;
																						IL_16b5:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_16c3;
																						IL_16c3:
																						array[num6] = 5;
																						goto IL_16d1;
																						IL_16d1:
																						array2[num6] = ((delegate*<GorillaTagger>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])();
																						goto IL_16ef;
																						IL_16ef:
																						num6++;
																						goto IL_16fd;
																						IL_16fd:
																						ptr2 += 8;
																						goto end_IL_0664;
																						IL_1710:
																						if (40 >= b)
																						{
																							goto IL_171e;
																						}
																						goto IL_18bb;
																						IL_171e:
																						if (40 > b)
																						{
																							goto IL_172c;
																						}
																						goto IL_1841;
																						IL_172c:
																						if (38 < b)
																						{
																							goto IL_173a;
																						}
																						num = 344;
																						goto IL_17cd;
																						IL_173a:
																						if (39 < b)
																						{
																							break;
																						}
																						goto IL_1748;
																						IL_1748:
																						if (39 > b)
																						{
																							break;
																						}
																						goto IL_1756;
																						IL_1756:
																						array[num6 - 1] = 0;
																						goto IL_176a;
																						IL_176a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (((delegate*<string, bool>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])((string)array2[num6 - 1]) ? 1 : 0);
																						goto IL_17a8;
																						IL_17a8:
																						ptr2 += 8;
																						num = 335;
																						goto end_IL_0664;
																						IL_193f:
																						if (42 <= b)
																						{
																						}
																						break;
																						IL_17cd:
																						if (38 > b)
																						{
																							break;
																						}
																						goto IL_17db;
																						IL_17db:
																						array[num6 - 1] = 3;
																						goto IL_17ef;
																						IL_17ef:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_182e;
																						IL_182e:
																						ptr2 += 8;
																						goto end_IL_0664;
																						IL_1841:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						num = 26;
																						goto IL_18a8;
																						IL_18a8:
																						num6--;
																						goto end_IL_0664;
																						IL_18bb:
																						if (41 >= b)
																						{
																							goto IL_18c6;
																						}
																						goto IL_1934;
																						IL_18c6:
																						if (41 > b)
																						{
																							break;
																						}
																						goto IL_18d1;
																						IL_18d1:
																						array[num6 - 1] = 3;
																						goto IL_18e5;
																						IL_18e5:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1924;
																						IL_1924:
																						ptr2 += 8;
																						goto end_IL_0664;
																					}
																					break;
																				}
																				num = 72;
																				goto IL_0678;
																				IL_0c3e:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0c7e;
																				IL_0c7e:
																				array[num6 - 2] = 3;
																				goto IL_0c92;
																				IL_0678:
																				if (21 <= b)
																				{
																					num = 51;
																					goto IL_06d0;
																				}
																				goto IL_0707;
																				IL_0c92:
																				num6--;
																				goto end_IL_0664;
																				IL_06d0:
																				array2[num6] = ((delegate*<string>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])();
																				num = 99;
																				goto IL_06f7;
																				IL_06f7:
																				array[num6] = 5;
																				goto IL_0717;
																				IL_0717:
																				num6++;
																				goto IL_0725;
																				IL_0725:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_0707:
																				if (10 >= b)
																				{
																					goto IL_0738;
																				}
																				goto IL_0a0b;
																				IL_0738:
																				if (10 > b)
																				{
																					goto IL_0746;
																				}
																				goto IL_095c;
																				IL_0746:
																				if (5 >= b)
																				{
																					goto IL_0754;
																				}
																				goto IL_0855;
																				IL_0754:
																				if (5 <= b)
																				{
																					goto IL_075f;
																				}
																				goto IL_07c6;
																				IL_075f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_079f;
																				IL_079f:
																				array[num6 - 2] = 0;
																				goto IL_07b3;
																				IL_07b3:
																				num6--;
																				goto end_IL_0664;
																				IL_07c6:
																				if (2 >= b)
																				{
																					goto IL_07d1;
																				}
																				goto IL_0842;
																				IL_07d1:
																				if (2 <= b)
																				{
																					goto IL_07dc;
																				}
																				goto IL_0821;
																				IL_07dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0dd2;
																				IL_0dd2:
																				array[num6 - 2] = 0;
																				goto IL_0edf;
																				IL_0edf:
																				num6--;
																				goto end_IL_0664;
																				IL_0821:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_082f;
																				IL_082f:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_09ed;
																				IL_09ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0f0e;
																				IL_0f0e:
																				array[num6] = 0;
																				goto IL_0f1c;
																				IL_0f1c:
																				num6++;
																				goto IL_0f2a;
																				IL_0f2a:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_0842:
																				if (3 >= b)
																				{
																					goto IL_0cb8;
																				}
																				goto IL_0fbe;
																				IL_0cb8:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0deb;
																				IL_0deb:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0e14;
																				IL_0e14:
																				ptr2 += 8;
																				goto IL_0e22;
																				IL_0e22:
																				num6--;
																				goto end_IL_0664;
																				IL_0fbe:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0fcc;
																				IL_0fcc:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0fda;
																				IL_0fda:
																				array[num6] = 0;
																				goto IL_0fe8;
																				IL_0fe8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_100b;
																				IL_100b:
																				array2[num6] = null;
																				goto IL_1015;
																				IL_1015:
																				num6++;
																				goto IL_1023;
																				IL_1023:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_0855:
																				if (7 >= b)
																				{
																					num = 124;
																					goto IL_086c;
																				}
																				goto IL_0d23;
																				IL_0ca5:
																				if (20 < b)
																				{
																					break;
																				}
																				goto IL_1036;
																				IL_086c:
																				if (7 <= b)
																				{
																					goto IL_0877;
																				}
																				goto IL_08d0;
																				IL_0877:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_08b7;
																				IL_08b7:
																				array[num6 - 2] = 0;
																				goto IL_0ecc;
																				IL_0ecc:
																				num6--;
																				goto end_IL_0664;
																				IL_08d0:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_08de;
																				IL_08de:
																				if (6 > b)
																				{
																					break;
																				}
																				num = 44;
																				goto IL_08f5;
																				IL_1036:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_1044;
																				IL_08f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0935;
																				IL_0935:
																				array[num6 - 2] = 0;
																				goto IL_0949;
																				IL_0949:
																				num6--;
																				goto end_IL_0664;
																				IL_0d23:
																				if (8 >= b)
																				{
																					goto IL_0d2e;
																				}
																				goto IL_0d4f;
																				IL_0d2e:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0d3c;
																				IL_0d3c:
																				num6--;
																				goto end_IL_0664;
																				IL_0d4f:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0d5d;
																				IL_0d5d:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0d6b;
																				IL_0d6b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0dab;
																				IL_0dab:
																				array[num6 - 2] = 0;
																				goto IL_0dbf;
																				IL_0dbf:
																				num6--;
																				goto end_IL_0664;
																				IL_095c:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_09be;
																				IL_09be:
																				num6 -= 2;
																				goto end_IL_0664;
																				IL_0a0b:
																				if (15 >= b)
																				{
																					goto IL_0a19;
																				}
																				goto IL_0af2;
																				IL_0a19:
																				if (15 > b)
																				{
																					goto IL_0a24;
																				}
																				goto IL_0aa3;
																				IL_0a24:
																				if (12 >= b)
																				{
																					goto IL_0a2f;
																				}
																				goto IL_0a5b;
																				IL_0a2f:
																				if (12 <= b)
																				{
																					num = 176;
																					goto end_IL_0664;
																				}
																				goto IL_0a48;
																				IL_1044:
																				array[num6 - 1] = 0;
																				goto IL_1058;
																				IL_0a48:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_10aa;
																				IL_10aa:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_10b8;
																				IL_10b8:
																				array[num6 - 1] = 0;
																				goto IL_10cc;
																				IL_10cc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_110b;
																				IL_110b:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_0a5b:
																				if (13 >= b)
																				{
																					goto IL_0a66;
																				}
																				goto IL_0a82;
																				IL_0a66:
																				if (13 > b)
																				{
																					break;
																				}
																				num = 348;
																				goto IL_111e;
																				IL_1058:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1097;
																				IL_111e:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_1137;
																				IL_1137:
																				array[num6] = 1;
																				goto IL_1145;
																				IL_1145:
																				num6++;
																				goto IL_1168;
																				IL_1168:
																				ptr2 += 16;
																				goto end_IL_0664;
																				IL_0a82:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_0a90;
																				IL_0a90:
																				if (14 > b)
																				{
																					break;
																				}
																				goto IL_0fa6;
																				IL_0fa6:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0664;
																				IL_0aa3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				num = 312;
																				goto IL_0e35;
																				IL_0e35:
																				array[num6 - 2] = 0;
																				goto IL_0e49;
																				IL_0e49:
																				num6--;
																				goto end_IL_0664;
																				IL_0af2:
																				if (18 >= b)
																				{
																					goto IL_0b00;
																				}
																				goto IL_0c25;
																				IL_0b00:
																				if (18 > b)
																				{
																					goto IL_0b0e;
																				}
																				goto IL_0be2;
																				IL_0b0e:
																				if (16 < b)
																				{
																					goto IL_0b19;
																				}
																				num = 47;
																				goto IL_0b6f;
																				IL_0b19:
																				if (17 < b)
																				{
																					break;
																				}
																				goto IL_0b27;
																				IL_0b27:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_0b35;
																				IL_0b35:
																				((delegate*<void>)UserCustomCulturePostconditionOnException[*(int*)(ptr2 + num3)])();
																				num = 194;
																				goto IL_0b53;
																				IL_0b53:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_1097:
																				ptr2 += 8;
																				goto end_IL_0664;
																				IL_0b6f:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_0b7d;
																				IL_0b7d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0bcf;
																				IL_0bcf:
																				num6--;
																				goto end_IL_0664;
																				IL_0be2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_0bfb;
																				IL_0bfb:
																				array[num6] = 3;
																				goto IL_0c09;
																				IL_0c09:
																				num6++;
																				num = 349;
																				goto IL_1155;
																				IL_1155:
																				ptr2 += 16;
																				goto end_IL_0664;
																				IL_0c25:
																				if (19 >= b)
																				{
																					goto IL_0c30;
																				}
																				goto IL_0ca5;
																				IL_0c30:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_0c3e;
																			}
																			break;
																			IL_0634:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0664;
																	continue;
																	end_IL_0644:
																	break;
																}
																continue;
																end_IL_0654:
																break;
															}
															continue;
															end_IL_0664:
															break;
														}
														continue;
														end_IL_195d:
														break;
													}
													continue;
													end_IL_1970:
													break;
												}
												continue;
												end_IL_197a:
												break;
											}
											continue;
											end_IL_1985:
											break;
										}
										continue;
										end_IL_1995:
										break;
									}
									continue;
									end_IL_19a5:
									break;
								}
								continue;
								end_IL_19b5:
								break;
							}
							continue;
							end_IL_19ce:
							break;
						}
						continue;
						end_IL_19de:
						break;
					}
					continue;
					end_IL_19ee:
					break;
				}
				continue;
				end_IL_19fe:
				break;
			}
		}
	}

	public unsafe static void smethod_5()
	{
		int num = 28;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 115;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TrustedTOKENSTATISTICS.DesktopVTPTR);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													IL_0712:
													byte b = *ptr2;
													while (true)
													{
														IL_0702:
														ptr2++;
														while (true)
														{
															IL_06f2:
															if (b >= 1)
															{
																while (b <= 45)
																{
																	while (true)
																	{
																		IL_06d5:
																		if (23 < b)
																		{
																			while (true)
																			{
																				IL_06c5:
																				if (34 < b)
																				{
																					while (true)
																					{
																						IL_06b5:
																						if (40 < b)
																						{
																							while (true)
																							{
																								IL_06a5:
																								if (43 >= b)
																								{
																									while (true)
																									{
																										IL_0695:
																										if (43 > b)
																										{
																											while (true)
																											{
																												IL_0685:
																												if (41 >= b)
																												{
																													while (41 <= b)
																													{
																														while (true)
																														{
																															IL_065f:
																															array[num6 - 1] = 0;
																															while (true)
																															{
																																IL_061f:
																																*(Recorder.InputSourceType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Recorder, Recorder.InputSourceType>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 1]);
																																while (true)
																																{
																																	IL_0606:
																																	ptr2 += 8;
																																	num = 377;
																																	while (num != 377)
																																	{
																																		if (num != 1358)
																																		{
																																			goto IL_178e;
																																		}
																																		switch (num)
																																		{
																																		case 165:
																																			goto IL_0606;
																																		case 166:
																																			goto IL_061f;
																																		case 20:
																																		case 235:
																																			goto IL_065f;
																																		case 297:
																																			goto IL_0675;
																																		case 365:
																																			goto IL_0685;
																																		case 85:
																																			goto IL_0695;
																																		case 232:
																																			goto IL_06a5;
																																		case 200:
																																			goto IL_06b5;
																																		case 87:
																																			goto IL_06c5;
																																		case 44:
																																			goto IL_06d5;
																																		case 47:
																																			goto IL_06e2;
																																		case 339:
																																			goto IL_06f2;
																																		case 260:
																																			goto IL_0702;
																																		case 122:
																																		case 331:
																																			goto IL_0712;
																																		case 130:
																																			goto IL_071d;
																																		case 238:
																																			goto IL_0736;
																																		case 84:
																																			goto IL_0744;
																																		case 26:
																																			goto IL_0752;
																																		case 154:
																																			goto IL_075d;
																																		case 54:
																																			goto IL_076b;
																																		case 4:
																																			goto IL_0779;
																																		case 101:
																																			goto IL_0795;
																																		case 92:
																																		case 188:
																																			goto IL_07a9;
																																		case 218:
																																			goto IL_07ee;
																																		case 167:
																																			goto IL_07f9;
																																		case 99:
																																			goto IL_080c;
																																		case 49:
																																			goto IL_0817;
																																		case 66:
																																			goto IL_0825;
																																		case 263:
																																			goto IL_0838;
																																		case 9:
																																		case 71:
																																			goto IL_0846;
																																		case 261:
																																			goto IL_086f;
																																		case 40:
																																			goto IL_0886;
																																		case 98:
																																		case 269:
																																			goto IL_08a2;
																																		case 252:
																																			goto IL_08e2;
																																		case 139:
																																			goto IL_08f6;
																																		case 7:
																																		case 271:
																																			goto IL_0909;
																																		case 276:
																																			goto IL_092b;
																																		case 185:
																																			goto IL_0939;
																																		case 298:
																																			goto IL_094c;
																																		case 300:
																																			goto IL_0965;
																																		case 69:
																																		case 226:
																																			goto IL_097c;
																																		case 246:
																																			goto IL_09de;
																																		case 175:
																																		case 308:
																																			goto IL_09f1;
																																		case 317:
																																			goto IL_0a0a;
																																		case 283:
																																			goto IL_0a5e;
																																		case 83:
																																			goto IL_0a6c;
																																		case 321:
																																			goto IL_0a7f;
																																		case 323:
																																			goto IL_0a92;
																																		case 288:
																																			goto IL_0aa0;
																																		case 108:
																																			goto IL_0aae;
																																		case 86:
																																			goto IL_0abc;
																																		case 51:
																																			goto IL_0ac7;
																																		case 70:
																																		case 146:
																																			goto IL_0ad5;
																																		case 121:
																																			goto IL_0b13;
																																		case 155:
																																			goto IL_0b21;
																																		case 102:
																																			goto IL_0b34;
																																		case 192:
																																			goto IL_0b42;
																																		case 57:
																																		case 211:
																																			goto IL_0b50;
																																		case 78:
																																			goto IL_0b80;
																																		case 233:
																																			goto IL_0b8b;
																																		case 314:
																																			goto IL_0ba7;
																																		case 149:
																																			goto IL_0bb5;
																																		case 174:
																																		case 194:
																																			goto IL_0bc3;
																																		case 257:
																																			goto IL_0bdc;
																																		case 222:
																																			goto IL_0bea;
																																		case 240:
																																			goto IL_0bf8;
																																		case 100:
																																		case 335:
																																			goto IL_0c14;
																																		case 183:
																																			goto IL_0c2d;
																																		case 244:
																																			goto IL_0c3b;
																																		case 201:
																																			goto IL_0c49;
																																		case 206:
																																		case 336:
																																			goto IL_0c5c;
																																		case 315:
																																			goto IL_0c6a;
																																		case 56:
																																			goto IL_0c8d;
																																		case 221:
																																			goto IL_0c97;
																																		case 319:
																																			goto IL_0ca5;
																																		case 117:
																																		case 341:
																																			goto IL_0cb8;
																																		case 338:
																																			goto IL_0ccd;
																																		case 342:
																																			goto IL_0ce0;
																																		case 13:
																																		case 159:
																																			goto IL_0cf7;
																																		case 349:
																																			goto IL_0d0a;
																																		case 295:
																																		case 351:
																																			goto IL_0d23;
																																		case 133:
																																		case 352:
																																			goto IL_0d3f;
																																		case 249:
																																			goto IL_0d7f;
																																		case 125:
																																			goto IL_0d93;
																																		case 354:
																																			goto IL_0da6;
																																		case 171:
																																			goto IL_0de5;
																																		case 366:
																																			goto IL_0e01;
																																		case 272:
																																			goto IL_0e0c;
																																		case 113:
																																		case 279:
																																			goto IL_0e1a;
																																		case 230:
																																			goto IL_0e5a;
																																		case 23:
																																			goto IL_0e77;
																																		case 29:
																																			goto IL_0e8a;
																																		case 128:
																																			goto IL_0e98;
																																		case 301:
																																		case 309:
																																			goto IL_0ea6;
																																		case 16:
																																			goto IL_0ee6;
																																		case 110:
																																			goto IL_0efa;
																																		case 368:
																																			goto IL_0f0d;
																																		case 77:
																																		case 216:
																																			goto IL_0f1b;
																																		case 294:
																																			goto IL_0f5b;
																																		case 74:
																																			goto IL_0f6f;
																																		case 369:
																																			goto IL_0f82;
																																		case 145:
																																		case 305:
																																			goto IL_0f8d;
																																		case 258:
																																			goto IL_0fab;
																																		case 140:
																																			goto IL_0fb9;
																																		case 21:
																																			goto IL_0fc7;
																																		case 208:
																																			goto IL_0fda;
																																		case 109:
																																			goto IL_0fe8;
																																		case 5:
																																		case 204:
																																			goto IL_0ff3;
																																		case 162:
																																			goto IL_100b;
																																		case 169:
																																			goto IL_1016;
																																		case 151:
																																			goto IL_1029;
																																		case 148:
																																			goto IL_1037;
																																		case 68:
																																		case 364:
																																			goto IL_1045;
																																		case 286:
																																			goto IL_105e;
																																		case 229:
																																			goto IL_106c;
																																		case 103:
																																			goto IL_107a;
																																		case 290:
																																			goto IL_108d;
																																		case 35:
																																			goto IL_1098;
																																		case 73:
																																		case 131:
																																			goto IL_10a6;
																																		case 224:
																																			goto IL_10e7;
																																		case 46:
																																			goto IL_10fb;
																																		case 332:
																																			goto IL_110e;
																																		case 6:
																																			goto IL_111c;
																																		case 180:
																																		case 285:
																																			goto IL_112a;
																																		case 307:
																																			goto IL_117c;
																																		case 11:
																																			goto IL_118f;
																																		case 178:
																																			goto IL_119d;
																																		case 253:
																																		case 291:
																																			goto IL_11ab;
																																		case 326:
																																			goto IL_1219;
																																		case 316:
																																			goto IL_122c;
																																		case 18:
																																			goto IL_1237;
																																		case 14:
																																		case 292:
																																			goto IL_1245;
																																		case 39:
																																			goto IL_1283;
																																		case 312:
																																			goto IL_1291;
																																		case 360:
																																			goto IL_12a4;
																																		case 362:
																																			goto IL_12b2;
																																		case 275:
																																			goto IL_12c5;
																																		case 15:
																																			goto IL_12d3;
																																		case 112:
																																			goto IL_12e1;
																																		case 53:
																																			goto IL_12ec;
																																		case 190:
																																		case 370:
																																			goto IL_12fa;
																																		case 299:
																																			goto IL_130e;
																																		case 256:
																																			goto IL_1346;
																																		case 350:
																																			goto IL_1359;
																																		case 94:
																																			goto IL_1367;
																																		case 36:
																																		case 89:
																																			goto IL_1375;
																																		case 116:
																																			goto IL_138e;
																																		case 225:
																																			goto IL_13aa;
																																		case 184:
																																		case 330:
																																			goto IL_13b5;
																																		case 168:
																																			goto IL_13c9;
																																		case 265:
																																			goto IL_1408;
																																		case 118:
																																			goto IL_141b;
																																		case 212:
																																			goto IL_1426;
																																		case 250:
																																		case 367:
																																			goto IL_1434;
																																		case 179:
																																			goto IL_1472;
																																		case 247:
																																			goto IL_1480;
																																		case 136:
																																			goto IL_1493;
																																		case 213:
																																			goto IL_14a1;
																																		case 191:
																																		case 361:
																																			goto IL_14af;
																																		case 153:
																																			goto IL_14c3;
																																		case 132:
																																		case 359:
																																			goto IL_14d6;
																																		case 157:
																																			goto IL_14ea;
																																		case 111:
																																			goto IL_1529;
																																		case 41:
																																			goto IL_153c;
																																		case 1:
																																		case 65:
																																			goto IL_1547;
																																		case 88:
																																			goto IL_1587;
																																		case 320:
																																			goto IL_159b;
																																		case 105:
																																			goto IL_15ae;
																																		case 267:
																																			goto IL_15bc;
																																		case 10:
																																		case 106:
																																			goto IL_15c7;
																																		case 186:
																																			goto IL_1607;
																																		case 346:
																																			goto IL_161b;
																																		case 254:
																																			goto IL_162e;
																																		case 214:
																																			goto IL_163c;
																																		case 134:
																																			goto IL_1647;
																																		case 33:
																																		case 293:
																																			goto IL_1655;
																																		case 217:
																																			goto IL_165f;
																																		case 311:
																																			goto IL_166d;
																																		case 61:
																																			goto IL_1680;
																																		case 93:
																																			goto IL_1697;
																																		case 124:
																																		case 239:
																																			goto IL_16a5;
																																		case 17:
																																			goto IL_16b9;
																																		case 289:
																																			goto IL_1706;
																																		case 243:
																																			goto IL_1714;
																																		case 25:
																																			goto IL_1730;
																																		case 144:
																																		case 264:
																																			goto IL_173b;
																																		case 353:
																																			goto IL_174f;
																																		case 90:
																																			goto IL_178e;
																																		case 251:
																																			goto IL_17a1;
																																		case 273:
																																			goto IL_17b8;
																																		case 129:
																																		case 172:
																																			goto IL_17c6;
																																		case 182:
																																			goto IL_1806;
																																		case 38:
																																			goto IL_181a;
																																		case 337:
																																			goto IL_182d;
																																		case 95:
																																			goto IL_183b;
																																		case 187:
																																		case 210:
																																			goto IL_1846;
																																		case 197:
																																			goto IL_185a;
																																		case 123:
																																			goto IL_1899;
																																		case 173:
																																			goto IL_18ac;
																																		case 32:
																																			goto IL_18b7;
																																		case 79:
																																		case 302:
																																			goto IL_18c5;
																																		case 126:
																																			goto IL_18d3;
																																		case 347:
																																			goto IL_18f1;
																																		case 333:
																																			goto IL_18ff;
																																		case 59:
																																			goto IL_1912;
																																		case 3:
																																			goto IL_1920;
																																		case 30:
																																		case 259:
																																			goto IL_192e;
																																		case 227:
																																			goto IL_1942;
																																		case 0:
																																			goto IL_198f;
																																		case 161:
																																			goto IL_199d;
																																		case 199:
																																			goto IL_19b0;
																																		case 156:
																																			goto IL_19be;
																																		case 81:
																																			goto IL_19cc;
																																		case 91:
																																		case 203:
																																			goto IL_19da;
																																		case 143:
																																			goto IL_19ee;
																																		case 277:
																																			goto IL_1a2d;
																																		case 274:
																																			goto IL_1a49;
																																		case 158:
																																		case 236:
																																			goto IL_1a54;
																																		case 147:
																																			goto IL_1a92;
																																		case 280:
																																			goto IL_1aa0;
																																		case 2:
																																		case 8:
																																		case 12:
																																		case 19:
																																		case 22:
																																		case 24:
																																		case 31:
																																		case 34:
																																		case 42:
																																		case 43:
																																		case 55:
																																		case 58:
																																		case 60:
																																		case 63:
																																		case 64:
																																		case 76:
																																		case 96:
																																		case 107:
																																		case 119:
																																		case 127:
																																		case 137:
																																		case 141:
																																		case 152:
																																		case 163:
																																		case 170:
																																		case 181:
																																		case 189:
																																		case 193:
																																		case 202:
																																		case 215:
																																		case 220:
																																		case 223:
																																		case 228:
																																		case 231:
																																		case 242:
																																		case 266:
																																		case 270:
																																		case 303:
																																		case 306:
																																		case 313:
																																		case 322:
																																		case 324:
																																		case 329:
																																		case 334:
																																		case 340:
																																		case 344:
																																		case 358:
																																		case 363:
																																			goto end_IL_0675;
																																		case 37:
																																		case 45:
																																		case 48:
																																		case 50:
																																		case 52:
																																		case 62:
																																		case 67:
																																		case 72:
																																		case 75:
																																		case 80:
																																		case 82:
																																		case 97:
																																		case 104:
																																		case 114:
																																		case 120:
																																		case 135:
																																		case 138:
																																		case 142:
																																		case 150:
																																		case 160:
																																		case 164:
																																		case 177:
																																		case 195:
																																		case 196:
																																		case 205:
																																		case 207:
																																		case 209:
																																		case 219:
																																		case 234:
																																		case 237:
																																		case 241:
																																		case 245:
																																		case 255:
																																		case 262:
																																		case 268:
																																		case 281:
																																		case 284:
																																		case 287:
																																		case 310:
																																		case 318:
																																		case 325:
																																		case 328:
																																		case 343:
																																		case 348:
																																		case 355:
																																		case 356:
																																		case 357:
																																			goto end_IL_05f3;
																																		case 296:
																																			goto end_IL_1ac3;
																																		case 327:
																																			goto end_IL_1ad6;
																																		case 248:
																																			goto end_IL_1ae0;
																																		case 278:
																																		case 345:
																																			goto end_IL_1aeb;
																																		case 198:
																																			goto end_IL_1afb;
																																		case 176:
																																			goto end_IL_1b0b;
																																		case 115:
																																			goto end_IL_1b1b;
																																		case 27:
																																			goto end_IL_1b2b;
																																		case 28:
																																			goto end_IL_1b3b;
																																		case 282:
																																		case 304:
																																			return;
																																		}
																																		continue;
																																		end_IL_05f3:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_06f2;
																														continue;
																														end_IL_0675:
																														break;
																														IL_0675:;
																													}
																													break;
																												}
																												goto IL_118f;
																												IL_1219:
																												num6 -= 2;
																												goto end_IL_06f2;
																												IL_118f:
																												if (42 < b)
																												{
																													break;
																												}
																												goto IL_119d;
																												IL_119d:
																												if (42 > b)
																												{
																													break;
																												}
																												goto IL_11ab;
																												IL_11ab:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_1219;
																											}
																											break;
																										}
																										goto IL_0d3f;
																										IL_0d93:
																										num6--;
																										goto end_IL_06f2;
																										IL_0d3f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0d7f;
																										IL_0d7f:
																										array[num6 - 2] = 3;
																										goto IL_0d93;
																									}
																									break;
																								}
																								goto IL_122c;
																								IL_12b2:
																								if (45 > b)
																								{
																								}
																								break;
																								IL_122c:
																								if (44 >= b)
																								{
																									goto IL_1237;
																								}
																								goto IL_12a4;
																								IL_1237:
																								if (44 > b)
																								{
																									break;
																								}
																								goto IL_1245;
																								IL_1245:
																								((delegate*<Recorder, bool, void>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																								goto IL_1283;
																								IL_1283:
																								num6 -= 2;
																								goto IL_1291;
																								IL_1291:
																								ptr2 += 8;
																								goto end_IL_06f2;
																								IL_12a4:
																								if (45 < b)
																								{
																									break;
																								}
																								goto IL_12b2;
																							}
																							break;
																						}
																						goto IL_12c5;
																						IL_14ea:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1529;
																						IL_12c5:
																						if (40 > b)
																						{
																							goto IL_12d3;
																						}
																						goto IL_14d6;
																						IL_12d3:
																						if (37 < b)
																						{
																							goto IL_12e1;
																						}
																						num = 225;
																						goto IL_13aa;
																						IL_12e1:
																						if (38 >= b)
																						{
																							goto IL_12ec;
																						}
																						goto IL_1359;
																						IL_12ec:
																						if (38 > b)
																						{
																							break;
																						}
																						goto IL_12fa;
																						IL_12fa:
																						array[num6 - 1] = 5;
																						goto IL_130e;
																						IL_130e:
																						array2[num6 - 1] = ((delegate*<GorillaTagger, Recorder>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																						goto IL_1346;
																						IL_1346:
																						ptr2 += 8;
																						goto end_IL_06f2;
																						IL_1359:
																						if (39 < b)
																						{
																							break;
																						}
																						goto IL_1367;
																						IL_1367:
																						if (39 > b)
																						{
																							break;
																						}
																						goto IL_1375;
																						IL_1375:
																						global::_003CModule_003E.recorder_1 = (Recorder)array2[num6 - 1];
																						goto IL_138e;
																						IL_138e:
																						num6--;
																						goto end_IL_06f2;
																						IL_1529:
																						ptr2 += 8;
																						goto end_IL_06f2;
																						IL_13aa:
																						if (37 <= b)
																						{
																							goto IL_13b5;
																						}
																						goto IL_141b;
																						IL_13b5:
																						array[num6 - 1] = 3;
																						goto IL_13c9;
																						IL_13c9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1408;
																						IL_1408:
																						ptr2 += 8;
																						goto end_IL_06f2;
																						IL_141b:
																						if (35 >= b)
																						{
																							goto IL_1426;
																						}
																						goto IL_1493;
																						IL_1426:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_1434;
																						IL_1434:
																						((delegate*<Recorder, Recorder.InputSourceType, void>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], *(Recorder.InputSourceType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1472;
																						IL_1472:
																						num6 -= 2;
																						goto IL_1480;
																						IL_1480:
																						ptr2 += 8;
																						goto end_IL_06f2;
																						IL_1493:
																						if (36 < b)
																						{
																							break;
																						}
																						goto IL_14a1;
																						IL_14a1:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_14af;
																						IL_14af:
																						string_1 = (string)array2[num6 - 1];
																						goto IL_14c3;
																						IL_14c3:
																						num6--;
																						goto end_IL_06f2;
																						IL_14d6:
																						array[num6 - 1] = 3;
																						goto IL_14ea;
																					}
																					break;
																				}
																				goto IL_153c;
																				IL_1aa0:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_153c:
																				if (34 <= b)
																				{
																					goto IL_1547;
																				}
																				goto IL_15ae;
																				IL_1547:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1587;
																				IL_1587:
																				array[num6 - 2] = 3;
																				goto IL_159b;
																				IL_159b:
																				num6--;
																				goto end_IL_06f2;
																				IL_15ae:
																				if (28 >= b)
																				{
																					goto IL_15bc;
																				}
																				goto IL_182d;
																				IL_15bc:
																				if (28 <= b)
																				{
																					goto IL_15c7;
																				}
																				goto IL_162e;
																				IL_15c7:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1607;
																				IL_1607:
																				array[num6 - 2] = 3;
																				goto IL_161b;
																				IL_161b:
																				num6--;
																				goto end_IL_06f2;
																				IL_162e:
																				if (25 < b)
																				{
																					goto IL_163c;
																				}
																				num = 25;
																				goto IL_1730;
																				IL_163c:
																				if (26 >= b)
																				{
																					goto IL_1647;
																				}
																				goto IL_1680;
																				IL_1647:
																				if (26 > b)
																				{
																					break;
																				}
																				goto IL_1655;
																				IL_1655:
																				array2[num6] = null;
																				goto IL_165f;
																				IL_165f:
																				array[num6] = 5;
																				goto IL_166d;
																				IL_166d:
																				num6++;
																				goto end_IL_06f2;
																				IL_1680:
																				if (27 < b)
																				{
																					break;
																				}
																				num = 93;
																				goto IL_1697;
																				IL_1a54:
																				((delegate*<Recorder, bool, void>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																				goto IL_1a92;
																				IL_1697:
																				if (27 > b)
																				{
																					break;
																				}
																				goto IL_16a5;
																				IL_16a5:
																				array[num6 - 2] = 0;
																				goto IL_16b9;
																				IL_16b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_1706;
																				IL_1706:
																				num6--;
																				goto IL_1714;
																				IL_1714:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_1a49:
																				if (32 > b)
																				{
																					break;
																				}
																				goto IL_1a54;
																				IL_1730:
																				if (25 <= b)
																				{
																					goto IL_173b;
																				}
																				goto IL_17a1;
																				IL_173b:
																				array[num6 - 1] = 0;
																				goto IL_174f;
																				IL_174f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_178e;
																				IL_178e:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_17a1:
																				if (24 < b)
																				{
																					break;
																				}
																				num = 273;
																				goto IL_17b8;
																				IL_1a92:
																				num6 -= 2;
																				goto IL_1aa0;
																				IL_17b8:
																				if (24 > b)
																				{
																					break;
																				}
																				goto IL_17c6;
																				IL_17c6:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1806;
																				IL_1806:
																				array[num6 - 2] = 3;
																				goto IL_181a;
																				IL_181a:
																				num6--;
																				goto end_IL_06f2;
																				IL_182d:
																				if (31 >= b)
																				{
																					goto IL_183b;
																				}
																				goto IL_19b0;
																				IL_183b:
																				if (31 <= b)
																				{
																					goto IL_1846;
																				}
																				goto IL_18ac;
																				IL_1846:
																				array[num6 - 1] = 3;
																				goto IL_185a;
																				IL_185a:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1899;
																				IL_1899:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_18ac:
																				if (29 >= b)
																				{
																					goto IL_18b7;
																				}
																				goto IL_1912;
																				IL_18b7:
																				if (29 > b)
																				{
																					break;
																				}
																				goto IL_18c5;
																				IL_18c5:
																				array[num6] = 5;
																				goto IL_18d3;
																				IL_18d3:
																				array2[num6] = ((delegate*<GorillaTagger>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])();
																				goto IL_18f1;
																				IL_18f1:
																				num6++;
																				goto IL_18ff;
																				IL_18ff:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_1912:
																				if (30 < b)
																				{
																					break;
																				}
																				goto IL_1920;
																				IL_1920:
																				if (30 > b)
																				{
																					break;
																				}
																				goto IL_192e;
																				IL_192e:
																				array[num6 - 2] = 0;
																				goto IL_1942;
																				IL_1942:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_198f;
																				IL_198f:
																				num6--;
																				goto IL_199d;
																				IL_199d:
																				ptr2 += 8;
																				goto end_IL_06f2;
																				IL_19b0:
																				if (32 < b)
																				{
																					goto IL_19be;
																				}
																				num = 274;
																				goto IL_1a49;
																				IL_19be:
																				if (33 < b)
																				{
																					break;
																				}
																				goto IL_19cc;
																				IL_19cc:
																				if (33 > b)
																				{
																					break;
																				}
																				goto IL_19da;
																				IL_19da:
																				array[num6 - 1] = 3;
																				goto IL_19ee;
																				IL_19ee:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1a2d;
																				IL_1a2d:
																				ptr2 += 8;
																				goto end_IL_06f2;
																			}
																			break;
																		}
																		goto IL_071d;
																		IL_10a6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																		goto IL_10e7;
																		IL_071d:
																		if (23 > b)
																		{
																			goto IL_0736;
																		}
																		num = 308;
																		goto IL_09f1;
																		IL_10e7:
																		array[num6 - 2] = 0;
																		goto IL_10fb;
																		IL_09f1:
																		array[num6 - 1] = 3;
																		goto IL_0da6;
																		IL_0da6:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0de5;
																		IL_0de5:
																		ptr2 += 8;
																		num = 142;
																		goto end_IL_06f2;
																		IL_0736:
																		if (11 >= b)
																		{
																			goto IL_0744;
																		}
																		goto IL_0a92;
																		IL_0744:
																		if (11 > b)
																		{
																			goto IL_0752;
																		}
																		goto IL_0909;
																		IL_0752:
																		if (5 < b)
																		{
																			goto IL_075d;
																		}
																		num = 101;
																		goto IL_0795;
																		IL_075d:
																		if (8 < b)
																		{
																			goto IL_076b;
																		}
																		goto IL_0ce0;
																		IL_076b:
																		if (9 < b)
																		{
																			goto IL_0779;
																		}
																		goto IL_0f0d;
																		IL_0779:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_0965;
																		IL_0965:
																		if (10 > b)
																		{
																			break;
																		}
																		num = 226;
																		goto IL_097c;
																		IL_110e:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_111c;
																		IL_097c:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_09de;
																		IL_09de:
																		num6 -= 2;
																		goto end_IL_06f2;
																		IL_0f0d:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_0f1b;
																		IL_0f1b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0f5b;
																		IL_0f5b:
																		array[num6 - 2] = 0;
																		goto IL_0f6f;
																		IL_0f6f:
																		num6--;
																		goto end_IL_06f2;
																		IL_0ce0:
																		if (8 <= b)
																		{
																			num = 13;
																			goto IL_0cf7;
																		}
																		goto IL_0e01;
																		IL_111c:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_112a;
																		IL_0cf7:
																		num6--;
																		goto end_IL_06f2;
																		IL_0e01:
																		if (6 >= b)
																		{
																			goto IL_0e0c;
																		}
																		goto IL_0e8a;
																		IL_0e0c:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_0e1a;
																		IL_0e1a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0e5a;
																		IL_0e5a:
																		array[num6 - 2] = 0;
																		num = 23;
																		goto IL_0e77;
																		IL_0e77:
																		num6--;
																		goto end_IL_06f2;
																		IL_0e8a:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_0e98;
																		IL_0e98:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0ea6;
																		IL_0ea6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0ee6;
																		IL_0ee6:
																		array[num6 - 2] = 0;
																		goto IL_0efa;
																		IL_0efa:
																		num6--;
																		goto end_IL_06f2;
																		IL_10fb:
																		num6--;
																		goto end_IL_06f2;
																		IL_0795:
																		if (5 <= b)
																		{
																			num = 92;
																			goto IL_07a9;
																		}
																		goto IL_07ee;
																		IL_112a:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_117c;
																		IL_07a9:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_094c;
																		IL_094c:
																		array[num6 - 2] = 0;
																		goto IL_0a7f;
																		IL_0a7f:
																		num6--;
																		goto end_IL_06f2;
																		IL_07ee:
																		if (2 >= b)
																		{
																			goto IL_07f9;
																		}
																		goto IL_080c;
																		IL_07f9:
																		if (2 <= b)
																		{
																			goto IL_08a2;
																		}
																		goto IL_092b;
																		IL_08a2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_08e2;
																		IL_08e2:
																		array[num6 - 2] = 0;
																		goto IL_08f6;
																		IL_08f6:
																		num6--;
																		goto end_IL_06f2;
																		IL_092b:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0939;
																		IL_0939:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0c14;
																		IL_0c14:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0c2d;
																		IL_0c2d:
																		array[num6] = 0;
																		goto IL_0c3b;
																		IL_0c3b:
																		num6++;
																		goto IL_0c49;
																		IL_0c49:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_080c:
																		if (3 < b)
																		{
																			goto IL_0817;
																		}
																		goto IL_0838;
																		IL_0817:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_0825;
																		IL_0825:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_0c5c;
																		IL_0c5c:
																		array[num6] = 0;
																		goto IL_0c6a;
																		IL_0c6a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0c8d;
																		IL_0c8d:
																		array2[num6] = null;
																		goto IL_0c97;
																		IL_0c97:
																		num6++;
																		goto IL_0ca5;
																		IL_0ca5:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_0838:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0846;
																		IL_0846:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_086f;
																		IL_086f:
																		ptr2 += 8;
																		num = 40;
																		goto IL_0886;
																		IL_0886:
																		num6--;
																		num = 195;
																		goto end_IL_06f2;
																		IL_0909:
																		array[num6 - 2] = 0;
																		num = 317;
																		goto IL_0a0a;
																		IL_0a0a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0a5e;
																		IL_0a5e:
																		num6--;
																		goto IL_0a6c;
																		IL_0a6c:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_0a92:
																		if (17 < b)
																		{
																			goto IL_0aa0;
																		}
																		goto IL_0f82;
																		IL_0aa0:
																		if (20 >= b)
																		{
																			goto IL_0aae;
																		}
																		goto IL_0b80;
																		IL_0aae:
																		if (20 > b)
																		{
																			goto IL_0abc;
																		}
																		goto IL_0d23;
																		IL_0abc:
																		if (18 >= b)
																		{
																			goto IL_0ac7;
																		}
																		goto IL_0b34;
																		IL_0ac7:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0ad5;
																		IL_0ad5:
																		((delegate*<Recorder, bool, void>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																		goto IL_0b13;
																		IL_0b13:
																		num6 -= 2;
																		goto IL_0b21;
																		IL_0b21:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_0b34:
																		if (19 < b)
																		{
																			break;
																		}
																		goto IL_0b42;
																		IL_0b42:
																		if (19 > b)
																		{
																			break;
																		}
																		goto IL_0b50;
																		IL_0b50:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0d0a;
																		IL_0d0a:
																		array[num6 - 1] = 0;
																		goto end_IL_06f2;
																		IL_0d23:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		goto end_IL_06f2;
																		IL_0b80:
																		if (21 >= b)
																		{
																			goto IL_0b8b;
																		}
																		goto IL_0ba7;
																		IL_0b8b:
																		if (21 > b)
																		{
																			break;
																		}
																		num = 341;
																		goto IL_0cb8;
																		IL_117c:
																		num6--;
																		goto end_IL_06f2;
																		IL_0cb8:
																		((delegate*<void>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])();
																		goto IL_0ccd;
																		IL_0ccd:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_0ba7:
																		if (22 < b)
																		{
																			break;
																		}
																		goto IL_0bb5;
																		IL_0bb5:
																		if (22 > b)
																		{
																			break;
																		}
																		goto IL_0bc3;
																		IL_0bc3:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0bdc;
																		IL_0bdc:
																		array[num6] = 3;
																		goto IL_0bea;
																		IL_0bea:
																		num6++;
																		goto IL_0bf8;
																		IL_0bf8:
																		ptr2 += 16;
																		num = 268;
																		goto end_IL_06f2;
																		IL_0f82:
																		if (17 <= b)
																		{
																			goto IL_0f8d;
																		}
																		goto IL_0fda;
																		IL_0f8d:
																		array2[num6] = ((delegate*<Recorder>)RunContinuationsAsynchronouslyANSIX[*(int*)(ptr2 + num3)])();
																		goto IL_0fab;
																		IL_0fab:
																		array[num6] = 5;
																		goto IL_0fb9;
																		IL_0fb9:
																		num6++;
																		goto IL_0fc7;
																		IL_0fc7:
																		ptr2 += 8;
																		goto end_IL_06f2;
																		IL_0fda:
																		if (14 >= b)
																		{
																			goto IL_0fe8;
																		}
																		goto IL_108d;
																		IL_0fe8:
																		if (14 <= b)
																		{
																			goto IL_0ff3;
																		}
																		goto IL_100b;
																		IL_0ff3:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_06f2;
																		IL_100b:
																		if (12 >= b)
																		{
																			goto IL_1016;
																		}
																		goto IL_1029;
																		IL_1016:
																		if (12 > b)
																		{
																			break;
																		}
																		goto end_IL_06f2;
																		IL_1029:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_1037;
																		IL_1037:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_1045;
																		IL_1045:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		goto IL_105e;
																		IL_105e:
																		array[num6] = 1;
																		goto IL_106c;
																		IL_106c:
																		num6++;
																		goto IL_107a;
																		IL_107a:
																		ptr2 += 16;
																		goto end_IL_06f2;
																		IL_108d:
																		if (15 >= b)
																		{
																			goto IL_1098;
																		}
																		goto IL_110e;
																		IL_1098:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_10a6;
																	}
																	break;
																	IL_06e2:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															continue;
															end_IL_06f2:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_1ac3:
												break;
											}
											continue;
											end_IL_1ad6:
											break;
										}
										continue;
										end_IL_1ae0:
										break;
									}
									continue;
									end_IL_1aeb:
									break;
								}
								continue;
								end_IL_1afb:
								break;
							}
							continue;
							end_IL_1b0b:
							break;
						}
						continue;
						end_IL_1b1b:
						break;
					}
					continue;
					end_IL_1b2b:
					break;
				}
				continue;
				end_IL_1b3b:
				break;
			}
		}
	}

	private unsafe static string smethod_6(string string_2)
	{
		//The blocks IL_000e, IL_001e, IL_06e3, IL_06f6, IL_070f, IL_071f, IL_072f, IL_073f, IL_074f, IL_075f, IL_076f, IL_077c, IL_078c, IL_079c, IL_07ac, IL_07bc, IL_07c7, IL_07e5, IL_07f3, IL_07fe, IL_080c, IL_082a, IL_0838, IL_084b, IL_0859, IL_0862, IL_0870, IL_0899, IL_08b2, IL_08c6, IL_08fe, IL_0911, IL_0932, IL_0950, IL_0974, IL_098c, IL_099f, IL_09ad, IL_09bb, IL_09ce, IL_09e6, IL_09f4, IL_0a07, IL_0a15, IL_0a1e, IL_0a2c, IL_0a73, IL_0a86, IL_0a94, IL_0a9f, IL_0ae0, IL_0af4, IL_0b10, IL_0b1b, IL_0b29, IL_0b42, IL_0b50, IL_0b5e, IL_0b71, IL_0b7f, IL_0b88, IL_0b96, IL_0bae, IL_0bbc, IL_0bc7, IL_0be5, IL_0bf3, IL_0c01, IL_0c14, IL_0c22, IL_0c30, IL_0c82, IL_0c95, IL_0ca3, IL_0cb1, IL_0d05, IL_0d18, IL_0d26, IL_0d43, IL_0d92, IL_0d9c, IL_0dc9, IL_0ddd, IL_0deb, IL_0e07, IL_0e15, IL_0e23, IL_0e2e, IL_0e6e, IL_0e82, IL_0e95, IL_0ea0, IL_0eae, IL_0eee, IL_0f02, IL_0f15, IL_0f23, IL_0f31, IL_0f44, IL_0f52, IL_0f60, IL_0f74, IL_0fc8, IL_0fd6, IL_0fe9, IL_0ff7, IL_1005, IL_1067, IL_107a, IL_1088, IL_109b, IL_10a4, IL_10b2, IL_10c0, IL_10cb, IL_10f4, IL_110b, IL_111e, IL_1129, IL_1137, IL_1150, IL_115e, IL_116c, IL_117f, IL_118d, IL_1196, IL_11a4, IL_11ed, IL_1201, IL_1214, IL_121f, IL_122d, IL_123b, IL_125e, IL_1268, IL_127f, IL_1292, IL_12a0, IL_12a9, IL_12b7, IL_12f7, IL_130b, IL_131e, IL_1327, IL_1367, IL_137b, IL_138e, IL_139c, IL_13aa, IL_13b8, IL_13c6, IL_13d4, IL_13df, IL_13ed, IL_1401, IL_143f, IL_1452, IL_1460, IL_146e, IL_1477, IL_14d5, IL_14e8, IL_14f3, IL_1507, IL_1546, IL_1559, IL_1564, IL_1572, IL_1586, IL_15c5, IL_15d8, IL_15e6, IL_15f4, IL_1634, IL_1648, IL_165b, IL_166f, IL_16ae, IL_16c1, IL_16cf, IL_16dd, IL_16e8, IL_16f6, IL_1736, IL_174a, IL_175d, IL_176b, IL_1779, IL_1790, IL_17a3, IL_17b1, IL_17c4, IL_17d8, IL_184b, IL_185e, IL_1869, IL_1877, IL_1885, IL_189e, IL_18b1, IL_18bf, IL_18d3, IL_1947, IL_1955, IL_1971, IL_197f, IL_1988, IL_1996, IL_19ae, IL_19bc, IL_19ca, IL_19dd, IL_19e6, IL_1a04, IL_1a12, IL_1a20, IL_1a33, IL_1a41, IL_1a4c, IL_1a6a, IL_1a81, IL_1a98, IL_1aab, IL_1ab9, IL_1ac7, IL_1ad2, IL_1adc, IL_1aea, IL_1afd, IL_1b0b, IL_1b19, IL_1b44, IL_1b5d, IL_1b6b, IL_1b79, IL_1b92, IL_1ba5, IL_1bae, IL_1bb9, IL_1bce, IL_1be1, IL_1bec, IL_1bfa, IL_1c0e, IL_1c4c, IL_1c5f, IL_1c6d, IL_1c7b, IL_1c97, IL_1ca5, IL_1cb0, IL_1cc9, IL_1cdc, IL_1ce7, IL_1cf5, IL_1d0e, IL_1d21, IL_1d2f, IL_1d3d, IL_1d5b, IL_1d69, IL_1d77, IL_1d8a, IL_1d98, IL_1da3, IL_1db1, IL_1dbf, IL_1ddd, IL_1df4, IL_1e02, IL_1e15, IL_1e5d, IL_1e76, IL_1e81, IL_1e8c, IL_1ea8, IL_1ebb, IL_1ec5, IL_1ed0, IL_1ee0, IL_1ef0, IL_1f00, IL_1f10, IL_1f20, IL_1f39, IL_1f52, IL_1f62, IL_1f72, IL_1f8d, IL_1f96 are reachable both inside and outside the pinned region starting at IL_1f87. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 198;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef23 = default(int);
			ref int reference = ref __rxRef23;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1f72:
					num2 = 1;
					while (true)
					{
						IL_1f62:
						num3 = num2 * 4;
						while (true)
						{
							IL_1f52:
							num4 = num2 * 8;
							while (true)
							{
								IL_1f39:
								array2 = new byte[4];
								num = 206;
								while (true)
								{
									IL_1f20:
									array3 = new object[4];
									num = 31;
									while (true)
									{
										IL_1f10:
										array4 = new int[4];
										while (true)
										{
											IL_1f00:
											array5 = new int[7];
											while (true)
											{
												IL_1ef0:
												array6 = new long[4];
												while (true)
												{
													IL_1ee0:
													array7 = new object[15];
													while (true)
													{
														IL_1ed0:
														array7[0] = string_2;
														while (true)
														{
															IL_1ec5:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSoapActionControlBreak.CollectionCountCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGALLOWDELAYEDBINDING);
															while (true)
															{
																IL_1ebb:
																ptr2 = ptr;
																while (true)
																{
																	IL_1ea8:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_07bc:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_07ac:
																				ptr2++;
																				while (true)
																				{
																					IL_079c:
																					if (b >= 1)
																					{
																						while (b <= 52)
																						{
																							while (true)
																							{
																								IL_077c:
																								if (26 >= b)
																								{
																									while (true)
																									{
																										IL_076f:
																										if (26 > b)
																										{
																											while (true)
																											{
																												IL_075f:
																												if (13 < b)
																												{
																													while (true)
																													{
																														IL_074f:
																														if (19 >= b)
																														{
																															while (true)
																															{
																																IL_073f:
																																if (19 > b)
																																{
																																	while (true)
																																	{
																																		IL_072f:
																																		if (16 < b)
																																		{
																																			while (true)
																																			{
																																				IL_071f:
																																				if (17 >= b)
																																				{
																																					while (17 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_06f6:
																																							array2[num6] = 5;
																																							num = 437;
																																							while (true)
																																							{
																																								if (num != 437)
																																								{
																																									if (num != 1418)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 198:
																																										break;
																																									default:
																																										continue;
																																									case 59:
																																									case 323:
																																										goto IL_06f6;
																																									case 219:
																																										goto IL_070f;
																																									case 10:
																																										goto IL_071f;
																																									case 414:
																																										goto IL_072f;
																																									case 191:
																																										goto IL_073f;
																																									case 314:
																																										goto IL_074f;
																																									case 317:
																																										goto IL_075f;
																																									case 336:
																																										goto IL_076f;
																																									case 22:
																																										goto IL_077c;
																																									case 319:
																																										goto IL_078c;
																																									case 106:
																																										goto IL_079c;
																																									case 401:
																																										goto IL_07ac;
																																									case 175:
																																									case 348:
																																										goto IL_07bc;
																																									case 129:
																																									case 168:
																																										goto IL_07c7;
																																									case 351:
																																										goto IL_07e5;
																																									case 187:
																																										goto IL_07f3;
																																									case 320:
																																										goto IL_07fe;
																																									case 239:
																																									case 308:
																																										goto IL_080c;
																																									case 138:
																																										goto IL_082a;
																																									case 123:
																																										goto IL_0838;
																																									case 158:
																																										goto IL_084b;
																																									case 47:
																																										goto IL_0862;
																																									case 154:
																																									case 184:
																																										goto IL_0870;
																																									case 288:
																																										goto IL_0899;
																																									case 233:
																																									case 378:
																																										goto IL_08b2;
																																									case 85:
																																										goto IL_08c6;
																																									case 307:
																																										goto IL_08fe;
																																									case 146:
																																									case 399:
																																										goto IL_0911;
																																									case 363:
																																										goto IL_0932;
																																									case 81:
																																										goto IL_0950;
																																									case 103:
																																										goto IL_0974;
																																									case 121:
																																										goto IL_098c;
																																									case 400:
																																										goto IL_099f;
																																									case 90:
																																										goto IL_09ad;
																																									case 382:
																																										goto IL_09bb;
																																									case 214:
																																										goto IL_09e6;
																																									case 355:
																																										goto IL_09f4;
																																									case 98:
																																										goto IL_0a07;
																																									case 169:
																																										goto IL_0a1e;
																																									case 133:
																																									case 243:
																																										goto IL_0a2c;
																																									case 56:
																																										goto IL_0a73;
																																									case 3:
																																										goto IL_0a86;
																																									case 132:
																																										goto IL_0a94;
																																									case 134:
																																									case 145:
																																										goto IL_0a9f;
																																									case 304:
																																										goto IL_0ae0;
																																									case 359:
																																										goto IL_0af4;
																																									case 209:
																																										goto IL_0b10;
																																									case 151:
																																										goto IL_0b1b;
																																									case 312:
																																									case 420:
																																										goto IL_0b29;
																																									case 41:
																																										goto IL_0b42;
																																									case 310:
																																										goto IL_0b50;
																																									case 101:
																																										goto IL_0b5e;
																																									case 384:
																																										goto IL_0b71;
																																									case 73:
																																										goto IL_0b88;
																																									case 43:
																																									case 262:
																																										goto IL_0b96;
																																									case 284:
																																										goto IL_0bae;
																																									case 345:
																																										goto IL_0bbc;
																																									case 113:
																																									case 408:
																																										goto IL_0bc7;
																																									case 413:
																																										goto IL_0be5;
																																									case 389:
																																										goto IL_0bf3;
																																									case 100:
																																										goto IL_0c01;
																																									case 14:
																																										goto IL_0c14;
																																									case 142:
																																										goto IL_0c22;
																																									case 257:
																																									case 267:
																																										goto IL_0c30;
																																									case 253:
																																										goto IL_0c82;
																																									case 32:
																																										goto IL_0c95;
																																									case 57:
																																										goto IL_0ca3;
																																									case 19:
																																									case 40:
																																										goto IL_0cb1;
																																									case 34:
																																										goto IL_0d05;
																																									case 295:
																																										goto IL_0d18;
																																									case 120:
																																									case 165:
																																										goto IL_0d26;
																																									case 64:
																																										goto IL_0ddd;
																																									case 385:
																																										goto IL_0deb;
																																									case 299:
																																										goto IL_0e07;
																																									case 174:
																																										goto IL_0e15;
																																									case 290:
																																										goto IL_0e23;
																																									case 76:
																																									case 272:
																																										goto IL_0e2e;
																																									case 260:
																																										goto IL_0e6e;
																																									case 4:
																																										goto IL_0e82;
																																									case 259:
																																										goto IL_0e95;
																																									case 20:
																																										goto IL_0ea0;
																																									case 23:
																																									case 97:
																																										goto IL_0eae;
																																									case 374:
																																										goto IL_0eee;
																																									case 58:
																																										goto IL_0f02;
																																									case 405:
																																										goto IL_0f15;
																																									case 391:
																																										goto IL_0f23;
																																									case 225:
																																									case 419:
																																										goto IL_0f31;
																																									case 171:
																																										goto IL_0f44;
																																									case 79:
																																										goto IL_0f52;
																																									case 228:
																																									case 332:
																																										goto IL_0f60;
																																									case 417:
																																										goto IL_0f74;
																																									case 285:
																																										goto IL_0fc8;
																																									case 428:
																																										goto IL_0fd6;
																																									case 341:
																																										goto IL_0fe9;
																																									case 369:
																																										goto IL_0ff7;
																																									case 6:
																																									case 237:
																																										goto IL_1005;
																																									case 24:
																																										goto IL_1067;
																																									case 337:
																																										goto IL_107a;
																																									case 144:
																																										goto IL_1088;
																																									case 334:
																																										goto IL_10a4;
																																									case 188:
																																										goto IL_10b2;
																																									case 416:
																																										goto IL_10c0;
																																									case 119:
																																									case 375:
																																										goto IL_10cb;
																																									case 229:
																																										goto IL_10f4;
																																									case 235:
																																										goto IL_110b;
																																									case 421:
																																										goto IL_111e;
																																									case 407:
																																										goto IL_1129;
																																									case 276:
																																									case 293:
																																										goto IL_1137;
																																									case 92:
																																										goto IL_1150;
																																									case 273:
																																										goto IL_115e;
																																									case 258:
																																										goto IL_116c;
																																									case 220:
																																										goto IL_117f;
																																									case 18:
																																										goto IL_1196;
																																									case 25:
																																									case 291:
																																										goto IL_11a4;
																																									case 255:
																																										goto IL_11ed;
																																									case 94:
																																										goto IL_1201;
																																									case 36:
																																										goto IL_1214;
																																									case 409:
																																										goto IL_121f;
																																									case 216:
																																									case 271:
																																										goto IL_122d;
																																									case 423:
																																										goto IL_123b;
																																									case 75:
																																										goto IL_125e;
																																									case 316:
																																										goto IL_1268;
																																									case 179:
																																										goto IL_127f;
																																									case 45:
																																										goto IL_1292;
																																									case 392:
																																										goto IL_12a9;
																																									case 70:
																																									case 269:
																																										goto IL_12b7;
																																									case 364:
																																										goto IL_12f7;
																																									case 131:
																																										goto IL_130b;
																																									case 252:
																																									case 366:
																																										goto IL_1327;
																																									case 186:
																																										goto IL_1367;
																																									case 246:
																																										goto IL_137b;
																																									case 46:
																																										goto IL_138e;
																																									case 289:
																																										goto IL_139c;
																																									case 72:
																																										goto IL_13aa;
																																									case 300:
																																										goto IL_13b8;
																																									case 234:
																																										goto IL_13c6;
																																									case 218:
																																										goto IL_13d4;
																																									case 194:
																																										goto IL_13df;
																																									case 204:
																																									case 265:
																																										goto IL_13ed;
																																									case 280:
																																										goto IL_1401;
																																									case 74:
																																										goto IL_143f;
																																									case 150:
																																										goto IL_1452;
																																									case 12:
																																										goto IL_1460;
																																									case 213:
																																									case 356:
																																										goto IL_1477;
																																									case 395:
																																										goto IL_14d5;
																																									case 377:
																																										goto IL_14e8;
																																									case 136:
																																									case 226:
																																										goto IL_14f3;
																																									case 415:
																																										goto IL_1507;
																																									case 135:
																																										goto IL_1546;
																																									case 96:
																																										goto IL_1559;
																																									case 313:
																																										goto IL_1564;
																																									case 78:
																																									case 118:
																																										goto IL_1572;
																																									case 139:
																																										goto IL_1586;
																																									case 178:
																																										goto IL_15c5;
																																									case 329:
																																										goto IL_15d8;
																																									case 232:
																																										goto IL_15e6;
																																									case 141:
																																									case 373:
																																										goto IL_15f4;
																																									case 429:
																																										goto IL_1634;
																																									case 361:
																																										goto IL_1648;
																																									case 30:
																																									case 128:
																																										goto IL_165b;
																																									case 160:
																																										goto IL_166f;
																																									case 49:
																																										goto IL_16ae;
																																									case 275:
																																										goto IL_16c1;
																																									case 110:
																																										goto IL_16cf;
																																									case 406:
																																										goto IL_16dd;
																																									case 264:
																																										goto IL_16e8;
																																									case 80:
																																									case 402:
																																										goto IL_16f6;
																																									case 172:
																																										goto IL_1736;
																																									case 318:
																																										goto IL_174a;
																																									case 99:
																																										goto IL_175d;
																																									case 180:
																																										goto IL_176b;
																																									case 156:
																																									case 207:
																																										goto IL_1779;
																																									case 29:
																																										goto IL_1790;
																																									case 126:
																																										goto IL_17a3;
																																									case 278:
																																										goto IL_17b1;
																																									case 212:
																																									case 331:
																																										goto IL_17c4;
																																									case 222:
																																										goto IL_17d8;
																																									case 117:
																																										goto IL_184b;
																																									case 347:
																																										goto IL_185e;
																																									case 298:
																																										goto IL_1869;
																																									case 403:
																																										goto IL_1877;
																																									case 21:
																																									case 387:
																																										goto IL_1885;
																																									case 147:
																																										goto IL_189e;
																																									case 376:
																																										goto IL_18b1;
																																									case 63:
																																									case 371:
																																										goto IL_18bf;
																																									case 159:
																																										goto IL_18d3;
																																									case 8:
																																										goto IL_1947;
																																									case 115:
																																										goto IL_1955;
																																									case 153:
																																										goto IL_1971;
																																									case 202:
																																										goto IL_1988;
																																									case 17:
																																									case 354:
																																										goto IL_1996;
																																									case 281:
																																										goto IL_19ae;
																																									case 404:
																																										goto IL_19bc;
																																									case 183:
																																										goto IL_19ca;
																																									case 39:
																																									case 177:
																																										goto IL_19e6;
																																									case 48:
																																										goto IL_1a04;
																																									case 190:
																																										goto IL_1a12;
																																									case 66:
																																										goto IL_1a20;
																																									case 396:
																																										goto IL_1a33;
																																									case 109:
																																										goto IL_1a41;
																																									case 52:
																																									case 411:
																																										goto IL_1a4c;
																																									case 301:
																																										goto IL_1a6a;
																																									case 88:
																																										goto IL_1a81;
																																									case 193:
																																										goto IL_1a98;
																																									case 321:
																																										goto IL_1aab;
																																									case 227:
																																										goto IL_1ab9;
																																									case 390:
																																										goto IL_1ac7;
																																									case 221:
																																									case 309:
																																										goto IL_1ad2;
																																									case 51:
																																										goto IL_1adc;
																																									case 326:
																																										goto IL_1aea;
																																									case 333:
																																										goto IL_1afd;
																																									case 339:
																																										goto IL_1b0b;
																																									case 83:
																																									case 424:
																																										goto IL_1b19;
																																									case 108:
																																										goto IL_1b44;
																																									case 380:
																																										goto IL_1b5d;
																																									case 125:
																																										goto IL_1b6b;
																																									case 155:
																																									case 418:
																																										goto IL_1b79;
																																									case 15:
																																										goto IL_1b92;
																																									case 223:
																																										goto IL_1bae;
																																									case 247:
																																									case 325:
																																										goto IL_1bb9;
																																									case 386:
																																										goto IL_1bce;
																																									case 242:
																																										goto IL_1be1;
																																									case 82:
																																										goto IL_1bec;
																																									case 422:
																																									case 430:
																																										goto IL_1bfa;
																																									case 35:
																																										goto IL_1c0e;
																																									case 54:
																																										goto IL_1c4c;
																																									case 335:
																																										goto IL_1c5f;
																																									case 426:
																																										goto IL_1c6d;
																																									case 189:
																																									case 350:
																																										goto IL_1c7b;
																																									case 230:
																																										goto IL_1c97;
																																									case 286:
																																										goto IL_1ca5;
																																									case 27:
																																									case 42:
																																										goto IL_1cb0;
																																									case 127:
																																										goto IL_1cc9;
																																									case 268:
																																										goto IL_1cdc;
																																									case 412:
																																										goto IL_1ce7;
																																									case 1:
																																									case 368:
																																										goto IL_1cf5;
																																									case 282:
																																										goto IL_1d0e;
																																									case 130:
																																										goto IL_1d21;
																																									case 217:
																																										goto IL_1d2f;
																																									case 176:
																																									case 279:
																																										goto IL_1d3d;
																																									case 86:
																																										goto IL_1d5b;
																																									case 427:
																																										goto IL_1d69;
																																									case 388:
																																										goto IL_1d77;
																																									case 16:
																																										goto IL_1d8a;
																																									case 362:
																																										goto IL_1d98;
																																									case 306:
																																										goto IL_1da3;
																																									case 398:
																																										goto IL_1db1;
																																									case 224:
																																									case 256:
																																										goto IL_1dbf;
																																									case 394:
																																										goto IL_1ddd;
																																									case 173:
																																										goto IL_1df4;
																																									case 196:
																																										goto IL_1e02;
																																									case 201:
																																									case 352:
																																										goto IL_1e15;
																																									case 211:
																																										goto end_IL_06e3;
																																									case 13:
																																										goto IL_1e76;
																																									case 157:
																																										goto IL_1e81;
																																									case 5:
																																									case 11:
																																									case 37:
																																									case 38:
																																									case 50:
																																									case 55:
																																									case 61:
																																									case 62:
																																									case 65:
																																									case 68:
																																									case 77:
																																									case 87:
																																									case 102:
																																									case 104:
																																									case 107:
																																									case 114:
																																									case 116:
																																									case 122:
																																									case 137:
																																									case 148:
																																									case 149:
																																									case 152:
																																									case 161:
																																									case 170:
																																									case 181:
																																									case 182:
																																									case 200:
																																									case 203:
																																									case 215:
																																									case 238:
																																									case 241:
																																									case 244:
																																									case 245:
																																									case 248:
																																									case 250:
																																									case 263:
																																									case 266:
																																									case 270:
																																									case 287:
																																									case 302:
																																									case 303:
																																									case 315:
																																									case 322:
																																									case 328:
																																									case 340:
																																									case 342:
																																									case 344:
																																									case 346:
																																									case 349:
																																									case 353:
																																									case 365:
																																									case 370:
																																									case 379:
																																									case 393:
																																									case 397:
																																										goto end_IL_070f;
																																									case 0:
																																									case 2:
																																									case 7:
																																									case 28:
																																									case 33:
																																									case 44:
																																									case 60:
																																									case 67:
																																									case 69:
																																									case 84:
																																									case 91:
																																									case 93:
																																									case 95:
																																									case 105:
																																									case 111:
																																									case 112:
																																									case 124:
																																									case 140:
																																									case 143:
																																									case 162:
																																									case 163:
																																									case 164:
																																									case 166:
																																									case 167:
																																									case 192:
																																									case 195:
																																									case 199:
																																									case 205:
																																									case 208:
																																									case 210:
																																									case 231:
																																									case 236:
																																									case 249:
																																									case 251:
																																									case 254:
																																									case 274:
																																									case 277:
																																									case 283:
																																									case 292:
																																									case 294:
																																									case 296:
																																									case 297:
																																									case 305:
																																									case 311:
																																									case 324:
																																									case 327:
																																									case 330:
																																									case 338:
																																									case 343:
																																									case 357:
																																									case 360:
																																									case 367:
																																									case 372:
																																									case 381:
																																									case 383:
																																										goto IL_1ea8;
																																									case 358:
																																										goto IL_1ebb;
																																									case 240:
																																										goto IL_1ec5;
																																									case 9:
																																										goto IL_1ed0;
																																									case 425:
																																										goto IL_1ee0;
																																									case 410:
																																										goto IL_1ef0;
																																									case 53:
																																										goto IL_1f00;
																																									case 31:
																																										goto IL_1f10;
																																									case 206:
																																										goto IL_1f20;
																																									case 26:
																																										goto IL_1f39;
																																									case 261:
																																										goto IL_1f52;
																																									case 185:
																																										goto IL_1f62;
																																									case 197:
																																										goto IL_1f72;
																																									case 71:
																																									case 89:
																																										goto IL_1f96;
																																									}
																																									goto end_IL_079c;
																																								}
																																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																																								goto IL_09e6;
																																								IL_09e6:
																																								num6++;
																																								goto IL_09f4;
																																								IL_09f4:
																																								ptr2 += 8;
																																								goto IL_1ea8;
																																								continue;
																																								end_IL_06e3:
																																								break;
																																							}
																																							break;
																																						}
																																						goto IL_1e5d;
																																						continue;
																																						end_IL_070f:
																																						break;
																																						IL_070f:;
																																					}
																																					break;
																																				}
																																				goto IL_0a07;
																																				IL_0a2c:
																																				((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																																				num = 56;
																																				goto IL_0a73;
																																				IL_0a07:
																																				if (18 < b)
																																				{
																																					break;
																																				}
																																				num = 169;
																																				goto IL_0a1e;
																																				IL_0a73:
																																				num6 -= 3;
																																				goto IL_1ea8;
																																				IL_0a1e:
																																				if (18 > b)
																																				{
																																					break;
																																				}
																																				goto IL_0a2c;
																																			}
																																			break;
																																		}
																																		goto IL_07e5;
																																		IL_0974:
																																		array3[num6] = array3[num6 - 1];
																																		goto IL_098c;
																																		IL_07e5:
																																		if (16 > b)
																																		{
																																			goto IL_07f3;
																																		}
																																		goto IL_0911;
																																		IL_07f3:
																																		if (14 >= b)
																																		{
																																			goto IL_07fe;
																																		}
																																		goto IL_084b;
																																		IL_07fe:
																																		if (14 > b)
																																		{
																																			break;
																																		}
																																		goto IL_080c;
																																		IL_080c:
																																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																		goto IL_082a;
																																		IL_082a:
																																		ptr2 += 8;
																																		goto IL_0838;
																																		IL_0838:
																																		num6--;
																																		goto IL_1ea8;
																																		IL_084b:
																																		if (15 < b)
																																		{
																																			break;
																																		}
																																		num = 47;
																																		goto IL_0862;
																																		IL_098c:
																																		num6++;
																																		goto IL_1ea8;
																																		IL_0862:
																																		if (15 > b)
																																		{
																																			break;
																																		}
																																		goto IL_0870;
																																		IL_0870:
																																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																		goto IL_0899;
																																		IL_0899:
																																		array2[num6 - 1] = 5;
																																		goto IL_1ea8;
																																		IL_0911:
																																		array2[num6] = array2[num6 - 1];
																																		num = 363;
																																		goto IL_0932;
																																		IL_0932:
																																		array4[num6 - 0] = array4[num6 - 1];
																																		goto IL_0950;
																																		IL_0950:
																																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_0974;
																																	}
																																	break;
																																}
																																goto IL_08b2;
																																IL_08fe:
																																ptr2 += 8;
																																goto IL_1ea8;
																																IL_08b2:
																																array2[num6 - 1] = 5;
																																goto IL_08c6;
																																IL_08c6:
																																array3[num6 - 1] = ((delegate*<string[], string>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																goto IL_08fe;
																															}
																															break;
																														}
																														goto IL_0a86;
																														IL_0cb1:
																														ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_0d05;
																														IL_0a86:
																														if (22 >= b)
																														{
																															goto IL_0a94;
																														}
																														goto IL_0bae;
																														IL_0a94:
																														if (22 <= b)
																														{
																															goto IL_0a9f;
																														}
																														goto IL_0b10;
																														IL_0a9f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																														goto IL_0ae0;
																														IL_0ae0:
																														array2[num6 - 2] = 0;
																														goto IL_0af4;
																														IL_0af4:
																														num6--;
																														num = 84;
																														goto IL_1ea8;
																														IL_0b10:
																														if (20 >= b)
																														{
																															goto IL_0b1b;
																														}
																														goto IL_0b71;
																														IL_0b1b:
																														if (20 > b)
																														{
																															break;
																														}
																														goto IL_0b29;
																														IL_0b29:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																														goto IL_0b42;
																														IL_0b42:
																														array2[num6] = 1;
																														goto IL_0b50;
																														IL_0b50:
																														num6++;
																														goto IL_0b5e;
																														IL_0b5e:
																														ptr2 += 16;
																														goto IL_1ea8;
																														IL_0b71:
																														if (21 < b)
																														{
																															break;
																														}
																														num = 73;
																														goto IL_0b88;
																														IL_0d05:
																														num6--;
																														goto IL_1ea8;
																														IL_0b88:
																														if (21 > b)
																														{
																															break;
																														}
																														goto IL_0b96;
																														IL_0b96:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														goto IL_1ea8;
																														IL_0bae:
																														if (24 >= b)
																														{
																															goto IL_0bbc;
																														}
																														goto IL_0c95;
																														IL_0bbc:
																														if (24 <= b)
																														{
																															goto IL_0bc7;
																														}
																														goto IL_0c14;
																														IL_0bc7:
																														array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																														goto IL_0be5;
																														IL_0be5:
																														array2[num6] = 5;
																														goto IL_0bf3;
																														IL_0bf3:
																														num6++;
																														goto IL_0c01;
																														IL_0c01:
																														ptr2 += 8;
																														goto IL_1ea8;
																														IL_0c14:
																														if (23 < b)
																														{
																															break;
																														}
																														goto IL_0c22;
																														IL_0c22:
																														if (23 > b)
																														{
																															break;
																														}
																														goto IL_0c30;
																														IL_0c30:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_0c82;
																														IL_0c82:
																														num6--;
																														goto IL_1ea8;
																														IL_0c95:
																														if (25 < b)
																														{
																															break;
																														}
																														goto IL_0ca3;
																														IL_0ca3:
																														if (25 > b)
																														{
																															break;
																														}
																														goto IL_0cb1;
																													}
																													break;
																												}
																												goto IL_0d18;
																												IL_12a9:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_12b7;
																												IL_0d18:
																												if (13 <= b)
																												{
																													goto IL_0d26;
																												}
																												goto IL_0e07;
																												IL_0d26:
																												array8 = array3;
																												num7 = num6;
																												if (array == null)
																												{
																													goto IL_0d35;
																												}
																												num8 = ptr2;
																												byte b2 = *num8;
																												ptr2 = num8 + 4;
																												int num9 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num9;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_0ddd;
																												IL_12b7:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_12f7;
																												IL_12f7:
																												array2[num6 - 2] = 0;
																												goto IL_130b;
																												IL_130b:
																												num6--;
																												goto IL_1ea8;
																												IL_0ddd:
																												array2[num6] = 5;
																												goto IL_0deb;
																												IL_0deb:
																												num6++;
																												num = 294;
																												goto IL_1ea8;
																												IL_0e07:
																												if (6 < b)
																												{
																													goto IL_0e15;
																												}
																												num = 334;
																												goto IL_10a4;
																												IL_0e15:
																												if (9 >= b)
																												{
																													goto IL_0e23;
																												}
																												goto IL_0f44;
																												IL_0e23:
																												if (9 <= b)
																												{
																													goto IL_0e2e;
																												}
																												goto IL_0e95;
																												IL_0e2e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0e6e;
																												IL_0e6e:
																												array2[num6 - 2] = 0;
																												goto IL_0e82;
																												IL_0e82:
																												num6--;
																												goto IL_1ea8;
																												IL_0e95:
																												if (7 >= b)
																												{
																													goto IL_0ea0;
																												}
																												goto IL_0f15;
																												IL_0ea0:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_0eae;
																												IL_0eae:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0eee;
																												IL_0eee:
																												array2[num6 - 2] = 0;
																												goto IL_0f02;
																												IL_0f02:
																												num6--;
																												goto IL_1ea8;
																												IL_0f15:
																												if (8 < b)
																												{
																													break;
																												}
																												goto IL_0f23;
																												IL_0f23:
																												if (8 > b)
																												{
																													break;
																												}
																												goto IL_0f31;
																												IL_0f31:
																												num6--;
																												goto IL_1ea8;
																												IL_0f44:
																												if (11 >= b)
																												{
																													goto IL_0f52;
																												}
																												goto IL_107a;
																												IL_0f52:
																												if (11 <= b)
																												{
																													goto IL_0f60;
																												}
																												goto IL_0fe9;
																												IL_0f60:
																												array2[num6 - 2] = 0;
																												goto IL_0f74;
																												IL_0f74:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_0fc8;
																												IL_0fc8:
																												num6--;
																												goto IL_0fd6;
																												IL_0fd6:
																												ptr2 += 8;
																												goto IL_1ea8;
																												IL_0fe9:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_0ff7;
																												IL_0ff7:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_1005;
																												IL_1005:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_1067;
																												IL_1067:
																												num6 -= 2;
																												goto IL_1ea8;
																												IL_107a:
																												if (12 < b)
																												{
																													break;
																												}
																												goto IL_1088;
																												IL_1088:
																												if (12 > b)
																												{
																													break;
																												}
																												goto IL_1ea8;
																												IL_1327:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_1367;
																												IL_10a4:
																												if (6 > b)
																												{
																													goto IL_10b2;
																												}
																												num = 252;
																												goto IL_1327;
																												IL_10b2:
																												if (3 >= b)
																												{
																													goto IL_10c0;
																												}
																												goto IL_1214;
																												IL_10c0:
																												if (3 <= b)
																												{
																													goto IL_10cb;
																												}
																												goto IL_111e;
																												IL_10cb:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_10f4;
																												IL_10f4:
																												ptr2 += 8;
																												num = 235;
																												goto IL_110b;
																												IL_110b:
																												num6--;
																												goto IL_1ea8;
																												IL_111e:
																												if (1 >= b)
																												{
																													goto IL_1129;
																												}
																												goto IL_117f;
																												IL_1129:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_1137;
																												IL_1137:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																												goto IL_1150;
																												IL_1150:
																												array2[num6] = 0;
																												goto IL_115e;
																												IL_115e:
																												num6++;
																												goto IL_116c;
																												IL_116c:
																												ptr2 += 8;
																												goto IL_1ea8;
																												IL_117f:
																												if (2 < b)
																												{
																													break;
																												}
																												num = 18;
																												goto IL_1196;
																												IL_1367:
																												array2[num6 - 2] = 0;
																												goto IL_137b;
																												IL_1196:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_11a4;
																												IL_11a4:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 255;
																												goto IL_11ed;
																												IL_11ed:
																												array2[num6 - 2] = 0;
																												goto IL_1201;
																												IL_1201:
																												num6--;
																												goto IL_1ea8;
																												IL_1214:
																												if (4 >= b)
																												{
																													goto IL_121f;
																												}
																												goto IL_1292;
																												IL_121f:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_122d;
																												IL_122d:
																												array2[num6] = 0;
																												goto IL_123b;
																												IL_123b:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												goto IL_125e;
																												IL_125e:
																												array3[num6] = null;
																												goto IL_1268;
																												IL_1268:
																												num6++;
																												num = 179;
																												goto IL_127f;
																												IL_127f:
																												ptr2 += 8;
																												goto IL_1ea8;
																												IL_1292:
																												if (5 < b)
																												{
																													break;
																												}
																												num = 392;
																												goto IL_12a9;
																												IL_137b:
																												num6--;
																												goto IL_1ea8;
																											}
																											break;
																										}
																										goto IL_07c7;
																										IL_09bb:
																										ptr2 += 16;
																										goto IL_1ea8;
																										IL_07c7:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																										goto IL_099f;
																										IL_099f:
																										array2[num6] = 3;
																										goto IL_09ad;
																										IL_09ad:
																										num6++;
																										goto IL_09bb;
																									}
																									break;
																								}
																								goto IL_138e;
																								IL_1e02:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_138e:
																								if (39 >= b)
																								{
																									goto IL_139c;
																								}
																								goto IL_1a33;
																								IL_139c:
																								if (39 > b)
																								{
																									goto IL_13aa;
																								}
																								num = 39;
																								goto IL_19e6;
																								IL_13aa:
																								if (32 >= b)
																								{
																									goto IL_13b8;
																								}
																								goto IL_16c1;
																								IL_13b8:
																								if (32 > b)
																								{
																									goto IL_13c6;
																								}
																								goto IL_165b;
																								IL_13c6:
																								if (29 < b)
																								{
																									goto IL_13d4;
																								}
																								goto IL_14e8;
																								IL_13d4:
																								if (30 >= b)
																								{
																									goto IL_13df;
																								}
																								goto IL_1452;
																								IL_13df:
																								if (30 > b)
																								{
																									break;
																								}
																								goto IL_13ed;
																								IL_13ed:
																								array2[num6 - 1] = 0;
																								goto IL_1401;
																								IL_1401:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<string, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_143f;
																								IL_143f:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1452:
																								if (31 < b)
																								{
																									break;
																								}
																								goto IL_1460;
																								IL_1460:
																								if (31 > b)
																								{
																									break;
																								}
																								num = 356;
																								goto IL_1477;
																								IL_1e5d:
																								num6--;
																								num = 311;
																								goto IL_1ea8;
																								IL_1477:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_14d5;
																								IL_14d5:
																								num6--;
																								goto IL_1ea8;
																								IL_14e8:
																								if (29 <= b)
																								{
																									goto IL_14f3;
																								}
																								goto IL_1559;
																								IL_14f3:
																								array2[num6 - 1] = 0;
																								goto IL_1507;
																								IL_1507:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1546;
																								IL_1546:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1559:
																								if (27 >= b)
																								{
																									goto IL_1564;
																								}
																								goto IL_15d8;
																								IL_1564:
																								if (27 > b)
																								{
																									break;
																								}
																								goto IL_1572;
																								IL_1572:
																								array2[num6 - 1] = 3;
																								goto IL_1586;
																								IL_1586:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_15c5;
																								IL_15c5:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_15d8:
																								if (28 < b)
																								{
																									break;
																								}
																								goto IL_15e6;
																								IL_15e6:
																								if (28 > b)
																								{
																									break;
																								}
																								goto IL_15f4;
																								IL_15f4:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1634;
																								IL_1634:
																								array2[num6 - 2] = 3;
																								goto IL_1648;
																								IL_1648:
																								num6--;
																								goto IL_1ea8;
																								IL_165b:
																								array2[num6 - 1] = 3;
																								goto IL_166f;
																								IL_166f:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_16ae;
																								IL_16ae:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_16c1:
																								if (35 >= b)
																								{
																									goto IL_16cf;
																								}
																								goto IL_185e;
																								IL_16cf:
																								if (35 > b)
																								{
																									goto IL_16dd;
																								}
																								goto IL_17c4;
																								IL_16dd:
																								if (33 >= b)
																								{
																									goto IL_16e8;
																								}
																								goto IL_175d;
																								IL_16e8:
																								if (33 > b)
																								{
																									break;
																								}
																								goto IL_16f6;
																								IL_16f6:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1736;
																								IL_1736:
																								array2[num6 - 2] = 3;
																								goto IL_174a;
																								IL_174a:
																								num6--;
																								goto IL_1ea8;
																								IL_175d:
																								if (34 < b)
																								{
																									break;
																								}
																								goto IL_176b;
																								IL_176b:
																								if (34 > b)
																								{
																									break;
																								}
																								goto IL_1779;
																								IL_1779:
																								array2[num6] = 15;
																								num = 29;
																								goto IL_1790;
																								IL_1790:
																								array4[num6] = *(int*)(ptr2 + num3);
																								goto IL_17a3;
																								IL_17a3:
																								ptr2 += 8;
																								goto IL_17b1;
																								IL_17b1:
																								num6++;
																								goto IL_1ea8;
																								IL_17c4:
																								array2[num6 - 1] = 5;
																								goto IL_17d8;
																								IL_17d8:
																								array3[num6 - 1] = ((delegate*<ref char, string>)setTagIsSerializable[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref char>)setTagIsSerializable[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																								num = 117;
																								goto IL_184b;
																								IL_184b:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_185e:
																								if (37 < b)
																								{
																									goto IL_1869;
																								}
																								goto IL_18b1;
																								IL_1869:
																								if (38 < b)
																								{
																									break;
																								}
																								goto IL_1877;
																								IL_1877:
																								if (38 > b)
																								{
																									break;
																								}
																								goto IL_1885;
																								IL_1885:
																								global::_003CModule_003E.string_27 = (string)array3[num6 - 1];
																								goto IL_189e;
																								IL_189e:
																								num6--;
																								goto IL_1ea8;
																								IL_18b1:
																								if (37 <= b)
																								{
																									goto IL_18bf;
																								}
																								goto IL_1971;
																								IL_18bf:
																								array2[num6 - 4] = 5;
																								goto IL_18d3;
																								IL_18d3:
																								array3[num6 - 4] = ((delegate*<string, string, string, string, string>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 4], (string)array3[num6 - 3], (string)array3[num6 - 2], (string)array3[num6 - 1]);
																								goto IL_1947;
																								IL_1947:
																								num6 -= 3;
																								goto IL_1955;
																								IL_1955:
																								ptr2 += 8;
																								num = 357;
																								goto IL_1ea8;
																								IL_1971:
																								if (36 < b)
																								{
																									break;
																								}
																								num = 202;
																								goto IL_1988;
																								IL_1e76:
																								if (52 < b)
																								{
																									break;
																								}
																								goto IL_1e81;
																								IL_1988:
																								if (36 > b)
																								{
																									break;
																								}
																								goto IL_1996;
																								IL_1996:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_19ae;
																								IL_19ae:
																								array2[num6] = 5;
																								goto IL_19bc;
																								IL_19bc:
																								num6++;
																								goto IL_19ca;
																								IL_19ca:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1e15:
																								ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1e5d;
																								IL_19e6:
																								array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																								goto IL_1a04;
																								IL_1a04:
																								array2[num6] = 5;
																								goto IL_1a12;
																								IL_1a12:
																								num6++;
																								goto IL_1a20;
																								IL_1a20:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1a33:
																								if (46 >= b)
																								{
																									goto IL_1a41;
																								}
																								goto IL_1c97;
																								IL_1a41:
																								if (46 <= b)
																								{
																									goto IL_1a4c;
																								}
																								goto IL_1aab;
																								IL_1a4c:
																								array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																								goto IL_1a6a;
																								IL_1a6a:
																								array2[num6] = 5;
																								num = 88;
																								goto IL_1a81;
																								IL_1a81:
																								num6++;
																								num = 193;
																								goto IL_1a98;
																								IL_1a98:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1aab:
																								if (42 < b)
																								{
																									goto IL_1ab9;
																								}
																								num = 223;
																								goto IL_1bae;
																								IL_1ab9:
																								if (44 >= b)
																								{
																									goto IL_1ac7;
																								}
																								goto IL_1b5d;
																								IL_1ac7:
																								if (44 <= b)
																								{
																									goto IL_1ad2;
																								}
																								goto IL_1afd;
																								IL_1ad2:
																								array3[num6] = null;
																								goto IL_1adc;
																								IL_1adc:
																								array2[num6] = 5;
																								goto IL_1aea;
																								IL_1aea:
																								num6++;
																								goto IL_1ea8;
																								IL_1afd:
																								if (43 < b)
																								{
																									break;
																								}
																								goto IL_1b0b;
																								IL_1b0b:
																								if (43 > b)
																								{
																									break;
																								}
																								goto IL_1b19;
																								IL_1b19:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1b44;
																								IL_1b44:
																								array2[num6 - 1] = 0;
																								goto IL_1ea8;
																								IL_1b5d:
																								if (45 < b)
																								{
																									break;
																								}
																								goto IL_1b6b;
																								IL_1b6b:
																								if (45 > b)
																								{
																									break;
																								}
																								goto IL_1b79;
																								IL_1b79:
																								global::_003CModule_003E.string_28 = (string)array3[num6 - 1];
																								goto IL_1b92;
																								IL_1b92:
																								num6--;
																								goto IL_1ea8;
																								IL_1e81:
																								if (52 <= b)
																								{
																								}
																								break;
																								IL_1bae:
																								if (42 <= b)
																								{
																									goto IL_1bb9;
																								}
																								goto IL_1be1;
																								IL_1bb9:
																								((delegate*<void>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																								goto IL_1bce;
																								IL_1bce:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1be1:
																								if (40 >= b)
																								{
																									goto IL_1bec;
																								}
																								goto IL_1c5f;
																								IL_1bec:
																								if (40 > b)
																								{
																									break;
																								}
																								goto IL_1bfa;
																								IL_1bfa:
																								array2[num6 - 1] = 0;
																								goto IL_1c0e;
																								IL_1c0e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<string, bool>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]) ? 1 : 0);
																								goto IL_1c4c;
																								IL_1c4c:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1c5f:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_1c6d;
																								IL_1c6d:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_1c7b;
																								IL_1c7b:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_1ea8;
																								IL_1c97:
																								if (49 >= b)
																								{
																									goto IL_1ca5;
																								}
																								goto IL_1d8a;
																								IL_1ca5:
																								if (49 <= b)
																								{
																									goto IL_1cb0;
																								}
																								goto IL_1cdc;
																								IL_1cb0:
																								global::_003CModule_003E.string_30 = (string)array3[num6 - 1];
																								goto IL_1cc9;
																								IL_1cc9:
																								num6--;
																								goto IL_1ea8;
																								IL_1cdc:
																								if (47 >= b)
																								{
																									goto IL_1ce7;
																								}
																								goto IL_1d21;
																								IL_1ce7:
																								if (47 > b)
																								{
																									break;
																								}
																								goto IL_1cf5;
																								IL_1cf5:
																								global::_003CModule_003E.string_29 = (string)array3[num6 - 1];
																								goto IL_1d0e;
																								IL_1d0e:
																								num6--;
																								goto IL_1ea8;
																								IL_1d21:
																								if (48 < b)
																								{
																									break;
																								}
																								goto IL_1d2f;
																								IL_1d2f:
																								if (48 > b)
																								{
																									break;
																								}
																								goto IL_1d3d;
																								IL_1d3d:
																								array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																								goto IL_1d5b;
																								IL_1d5b:
																								array2[num6] = 5;
																								goto IL_1d69;
																								IL_1d69:
																								num6++;
																								goto IL_1d77;
																								IL_1d77:
																								ptr2 += 8;
																								goto IL_1ea8;
																								IL_1d8a:
																								if (51 >= b)
																								{
																									goto IL_1d98;
																								}
																								goto IL_1e76;
																								IL_1d98:
																								if (51 > b)
																								{
																									goto IL_1da3;
																								}
																								goto IL_1e15;
																								IL_1da3:
																								if (50 < b)
																								{
																									break;
																								}
																								goto IL_1db1;
																								IL_1db1:
																								if (50 > b)
																								{
																									break;
																								}
																								goto IL_1dbf;
																								IL_1dbf:
																								array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																								goto IL_1ddd;
																								IL_1ddd:
																								array2[num6] = 5;
																								num = 173;
																								goto IL_1df4;
																								IL_1df4:
																								num6++;
																								goto IL_1e02;
																							}
																							break;
																							IL_078c:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					num = 381;
																					goto IL_1ea8;
																					continue;
																					end_IL_079c:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	num = 71;
																	goto IL_1f96;
																	IL_1f96:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0d35:
			while (true)
			{
				IL_0d35_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0ddd_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0deb_2:
							num6++;
							num = 294;
							while (true)
							{
								IL_1ea8_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_079c_2:
												if (b >= 1)
												{
													while (b <= 52)
													{
														while (true)
														{
															IL_077c_2:
															if (26 >= b)
															{
																while (true)
																{
																	IL_076f_2:
																	if (26 > b)
																	{
																		while (true)
																		{
																			IL_075f_2:
																			if (13 < b)
																			{
																				while (true)
																				{
																					IL_074f_2:
																					if (19 >= b)
																					{
																						while (true)
																						{
																							IL_073f_2:
																							if (19 > b)
																							{
																								while (true)
																								{
																									IL_072f_2:
																									if (16 < b)
																									{
																										while (true)
																										{
																											IL_071f_2:
																											if (17 >= b)
																											{
																												while (17 <= b)
																												{
																													while (true)
																													{
																														IL_06f6_2:
																														array2[num6] = 5;
																														num = 437;
																														while (true)
																														{
																															if (num != 437)
																															{
																																if (num != 1418)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 59:
																																case 323:
																																	goto IL_06f6_2;
																																case 219:
																																	goto IL_070f_2;
																																case 10:
																																	goto IL_071f_2;
																																case 414:
																																	goto IL_072f_2;
																																case 191:
																																	goto IL_073f_2;
																																case 314:
																																	goto IL_074f_2;
																																case 317:
																																	goto IL_075f_2;
																																case 336:
																																	goto IL_076f_2;
																																case 22:
																																	goto IL_077c_2;
																																case 319:
																																	goto IL_078c_2;
																																case 106:
																																	goto IL_079c_2;
																																case 401:
																																	goto end_IL_079c_2;
																																case 175:
																																case 348:
																																	goto end_IL_07ac;
																																case 129:
																																case 168:
																																	goto IL_07c7_2;
																																case 351:
																																	goto IL_07e5_2;
																																case 187:
																																	goto IL_07f3_2;
																																case 320:
																																	goto IL_07fe_2;
																																case 239:
																																case 308:
																																	goto IL_080c_2;
																																case 138:
																																	goto IL_082a_2;
																																case 123:
																																	goto IL_0838_2;
																																case 158:
																																	goto IL_084b_2;
																																case 47:
																																	goto IL_0862_2;
																																case 154:
																																case 184:
																																	goto IL_0870_2;
																																case 288:
																																	goto IL_0899_2;
																																case 233:
																																case 378:
																																	goto IL_08b2_2;
																																case 85:
																																	goto IL_08c6_2;
																																case 307:
																																	goto IL_08fe_2;
																																case 146:
																																case 399:
																																	goto IL_0911_2;
																																case 363:
																																	goto IL_0932_2;
																																case 81:
																																	goto IL_0950_2;
																																case 103:
																																	goto IL_0974_2;
																																case 121:
																																	goto IL_098c_2;
																																case 400:
																																	goto IL_099f_2;
																																case 90:
																																	goto IL_09ad_2;
																																case 382:
																																	goto IL_09bb_2;
																																case 214:
																																	goto IL_09e6_2;
																																case 355:
																																	goto IL_09f4_2;
																																case 98:
																																	goto IL_0a07_2;
																																case 169:
																																	goto IL_0a1e_2;
																																case 133:
																																case 243:
																																	goto IL_0a2c_2;
																																case 56:
																																	goto IL_0a73_2;
																																case 3:
																																	goto IL_0a86_2;
																																case 132:
																																	goto IL_0a94_2;
																																case 134:
																																case 145:
																																	goto IL_0a9f_2;
																																case 304:
																																	goto IL_0ae0_2;
																																case 359:
																																	goto IL_0af4_2;
																																case 209:
																																	goto IL_0b10_2;
																																case 151:
																																	goto IL_0b1b_2;
																																case 312:
																																case 420:
																																	goto IL_0b29_2;
																																case 41:
																																	goto IL_0b42_2;
																																case 310:
																																	goto IL_0b50_2;
																																case 101:
																																	goto IL_0b5e_2;
																																case 384:
																																	goto IL_0b71_2;
																																case 73:
																																	goto IL_0b88_2;
																																case 43:
																																case 262:
																																	goto IL_0b96_2;
																																case 284:
																																	goto IL_0bae_2;
																																case 345:
																																	goto IL_0bbc_2;
																																case 113:
																																case 408:
																																	goto IL_0bc7_2;
																																case 413:
																																	goto IL_0be5_2;
																																case 389:
																																	goto IL_0bf3_2;
																																case 100:
																																	goto IL_0c01_2;
																																case 14:
																																	goto IL_0c14_2;
																																case 142:
																																	goto IL_0c22_2;
																																case 257:
																																case 267:
																																	goto IL_0c30_2;
																																case 253:
																																	goto IL_0c82_2;
																																case 32:
																																	goto IL_0c95_2;
																																case 57:
																																	goto IL_0ca3_2;
																																case 19:
																																case 40:
																																	goto IL_0cb1_2;
																																case 34:
																																	goto IL_0d05_2;
																																case 295:
																																	goto IL_0d18_2;
																																case 120:
																																case 165:
																																	goto end_IL_07bc;
																																case 64:
																																	goto IL_0ddd_2;
																																case 385:
																																	goto IL_0deb_2;
																																case 299:
																																	goto IL_0e07_2;
																																case 174:
																																	goto IL_0e15_2;
																																case 290:
																																	goto IL_0e23_2;
																																case 76:
																																case 272:
																																	goto IL_0e2e_2;
																																case 260:
																																	goto IL_0e6e_2;
																																case 4:
																																	goto IL_0e82_2;
																																case 259:
																																	goto IL_0e95_2;
																																case 20:
																																	goto IL_0ea0_2;
																																case 23:
																																case 97:
																																	goto IL_0eae_2;
																																case 374:
																																	goto IL_0eee_2;
																																case 58:
																																	goto IL_0f02_2;
																																case 405:
																																	goto IL_0f15_2;
																																case 391:
																																	goto IL_0f23_2;
																																case 225:
																																case 419:
																																	goto IL_0f31_2;
																																case 171:
																																	goto IL_0f44_2;
																																case 79:
																																	goto IL_0f52_2;
																																case 228:
																																case 332:
																																	goto IL_0f60_2;
																																case 417:
																																	goto IL_0f74_2;
																																case 285:
																																	goto IL_0fc8_2;
																																case 428:
																																	goto IL_0fd6_2;
																																case 341:
																																	goto IL_0fe9_2;
																																case 369:
																																	goto IL_0ff7_2;
																																case 6:
																																case 237:
																																	goto IL_1005_2;
																																case 24:
																																	goto IL_1067_2;
																																case 337:
																																	goto IL_107a_2;
																																case 144:
																																	goto IL_1088_2;
																																case 334:
																																	goto IL_10a4_2;
																																case 188:
																																	goto IL_10b2_2;
																																case 416:
																																	goto IL_10c0_2;
																																case 119:
																																case 375:
																																	goto IL_10cb_2;
																																case 229:
																																	goto IL_10f4_2;
																																case 235:
																																	goto IL_110b_2;
																																case 421:
																																	goto IL_111e_2;
																																case 407:
																																	goto IL_1129_2;
																																case 276:
																																case 293:
																																	goto IL_1137_2;
																																case 92:
																																	goto IL_1150_2;
																																case 273:
																																	goto IL_115e_2;
																																case 258:
																																	goto IL_116c_2;
																																case 220:
																																	goto IL_117f_2;
																																case 18:
																																	goto IL_1196_2;
																																case 25:
																																case 291:
																																	goto IL_11a4_2;
																																case 255:
																																	goto IL_11ed_2;
																																case 94:
																																	goto IL_1201_2;
																																case 36:
																																	goto IL_1214_2;
																																case 409:
																																	goto IL_121f_2;
																																case 216:
																																case 271:
																																	goto IL_122d_2;
																																case 423:
																																	goto IL_123b_2;
																																case 75:
																																	goto IL_125e_2;
																																case 316:
																																	goto IL_1268_2;
																																case 179:
																																	goto IL_127f_2;
																																case 45:
																																	goto IL_1292_2;
																																case 392:
																																	goto IL_12a9_2;
																																case 70:
																																case 269:
																																	goto IL_12b7_2;
																																case 364:
																																	goto IL_12f7_2;
																																case 131:
																																	goto IL_130b_2;
																																case 252:
																																case 366:
																																	goto IL_1327_2;
																																case 186:
																																	goto IL_1367_2;
																																case 246:
																																	goto IL_137b_2;
																																case 46:
																																	goto IL_138e_2;
																																case 289:
																																	goto IL_139c_2;
																																case 72:
																																	goto IL_13aa_2;
																																case 300:
																																	goto IL_13b8_2;
																																case 234:
																																	goto IL_13c6_2;
																																case 218:
																																	goto IL_13d4_2;
																																case 194:
																																	goto IL_13df_2;
																																case 204:
																																case 265:
																																	goto IL_13ed_2;
																																case 280:
																																	goto IL_1401_2;
																																case 74:
																																	goto IL_143f_2;
																																case 150:
																																	goto IL_1452_2;
																																case 12:
																																	goto IL_1460_2;
																																case 213:
																																case 356:
																																	goto IL_1477_2;
																																case 395:
																																	goto IL_14d5_2;
																																case 377:
																																	goto IL_14e8_2;
																																case 136:
																																case 226:
																																	goto IL_14f3_2;
																																case 415:
																																	goto IL_1507_2;
																																case 135:
																																	goto IL_1546_2;
																																case 96:
																																	goto IL_1559_2;
																																case 313:
																																	goto IL_1564_2;
																																case 78:
																																case 118:
																																	goto IL_1572_2;
																																case 139:
																																	goto IL_1586_2;
																																case 178:
																																	goto IL_15c5_2;
																																case 329:
																																	goto IL_15d8_2;
																																case 232:
																																	goto IL_15e6_2;
																																case 141:
																																case 373:
																																	goto IL_15f4_2;
																																case 429:
																																	goto IL_1634_2;
																																case 361:
																																	goto IL_1648_2;
																																case 30:
																																case 128:
																																	goto IL_165b_2;
																																case 160:
																																	goto IL_166f_2;
																																case 49:
																																	goto IL_16ae_2;
																																case 275:
																																	goto IL_16c1_2;
																																case 110:
																																	goto IL_16cf_2;
																																case 406:
																																	goto IL_16dd_2;
																																case 264:
																																	goto IL_16e8_2;
																																case 80:
																																case 402:
																																	goto IL_16f6_2;
																																case 172:
																																	goto IL_1736_2;
																																case 318:
																																	goto IL_174a_2;
																																case 99:
																																	goto IL_175d_2;
																																case 180:
																																	goto IL_176b_2;
																																case 156:
																																case 207:
																																	goto IL_1779_2;
																																case 29:
																																	goto IL_1790_2;
																																case 126:
																																	goto IL_17a3_2;
																																case 278:
																																	goto IL_17b1_2;
																																case 212:
																																case 331:
																																	goto IL_17c4_2;
																																case 222:
																																	goto IL_17d8_2;
																																case 117:
																																	goto IL_184b_2;
																																case 347:
																																	goto IL_185e_2;
																																case 298:
																																	goto IL_1869_2;
																																case 403:
																																	goto IL_1877_2;
																																case 21:
																																case 387:
																																	goto IL_1885_2;
																																case 147:
																																	goto IL_189e_2;
																																case 376:
																																	goto IL_18b1_2;
																																case 63:
																																case 371:
																																	goto IL_18bf_2;
																																case 159:
																																	goto IL_18d3_2;
																																case 8:
																																	goto IL_1947_2;
																																case 115:
																																	goto IL_1955_2;
																																case 153:
																																	goto IL_1971_2;
																																case 202:
																																	goto IL_1988_2;
																																case 17:
																																case 354:
																																	goto IL_1996_2;
																																case 281:
																																	goto IL_19ae_2;
																																case 404:
																																	goto IL_19bc_2;
																																case 183:
																																	goto IL_19ca_2;
																																case 39:
																																case 177:
																																	goto IL_19e6_2;
																																case 48:
																																	goto IL_1a04_2;
																																case 190:
																																	goto IL_1a12_2;
																																case 66:
																																	goto IL_1a20_2;
																																case 396:
																																	goto IL_1a33_2;
																																case 109:
																																	goto IL_1a41_2;
																																case 52:
																																case 411:
																																	goto IL_1a4c_2;
																																case 301:
																																	goto IL_1a6a_2;
																																case 88:
																																	goto IL_1a81_2;
																																case 193:
																																	goto IL_1a98_2;
																																case 321:
																																	goto IL_1aab_2;
																																case 227:
																																	goto IL_1ab9_2;
																																case 390:
																																	goto IL_1ac7_2;
																																case 221:
																																case 309:
																																	goto IL_1ad2_2;
																																case 51:
																																	goto IL_1adc_2;
																																case 326:
																																	goto IL_1aea_2;
																																case 333:
																																	goto IL_1afd_2;
																																case 339:
																																	goto IL_1b0b_2;
																																case 83:
																																case 424:
																																	goto IL_1b19_2;
																																case 108:
																																	goto IL_1b44_2;
																																case 380:
																																	goto IL_1b5d_2;
																																case 125:
																																	goto IL_1b6b_2;
																																case 155:
																																case 418:
																																	goto IL_1b79_2;
																																case 15:
																																	goto IL_1b92_2;
																																case 223:
																																	goto IL_1bae_2;
																																case 247:
																																case 325:
																																	goto IL_1bb9_2;
																																case 386:
																																	goto IL_1bce_2;
																																case 242:
																																	goto IL_1be1_2;
																																case 82:
																																	goto IL_1bec_2;
																																case 422:
																																case 430:
																																	goto IL_1bfa_2;
																																case 35:
																																	goto IL_1c0e_2;
																																case 54:
																																	goto IL_1c4c_2;
																																case 335:
																																	goto IL_1c5f_2;
																																case 426:
																																	goto IL_1c6d_2;
																																case 189:
																																case 350:
																																	goto IL_1c7b_2;
																																case 230:
																																	goto IL_1c97_2;
																																case 286:
																																	goto IL_1ca5_2;
																																case 27:
																																case 42:
																																	goto IL_1cb0_2;
																																case 127:
																																	goto IL_1cc9_2;
																																case 268:
																																	goto IL_1cdc_2;
																																case 412:
																																	goto IL_1ce7_2;
																																case 1:
																																case 368:
																																	goto IL_1cf5_2;
																																case 282:
																																	goto IL_1d0e_2;
																																case 130:
																																	goto IL_1d21_2;
																																case 217:
																																	goto IL_1d2f_2;
																																case 176:
																																case 279:
																																	goto IL_1d3d_2;
																																case 86:
																																	goto IL_1d5b_2;
																																case 427:
																																	goto IL_1d69_2;
																																case 388:
																																	goto IL_1d77_2;
																																case 16:
																																	goto IL_1d8a_2;
																																case 362:
																																	goto IL_1d98_2;
																																case 306:
																																	goto IL_1da3_2;
																																case 398:
																																	goto IL_1db1_2;
																																case 224:
																																case 256:
																																	goto IL_1dbf_2;
																																case 394:
																																	goto IL_1ddd_2;
																																case 173:
																																	goto IL_1df4_2;
																																case 196:
																																	goto IL_1e02_2;
																																case 201:
																																case 352:
																																	goto IL_1e15_2;
																																case 211:
																																	goto end_IL_06e3_2;
																																case 13:
																																	goto IL_1e76_2;
																																case 157:
																																	goto IL_1e81_2;
																																case 5:
																																case 11:
																																case 37:
																																case 38:
																																case 50:
																																case 55:
																																case 61:
																																case 62:
																																case 65:
																																case 68:
																																case 77:
																																case 87:
																																case 102:
																																case 104:
																																case 107:
																																case 114:
																																case 116:
																																case 122:
																																case 137:
																																case 148:
																																case 149:
																																case 152:
																																case 161:
																																case 170:
																																case 181:
																																case 182:
																																case 200:
																																case 203:
																																case 215:
																																case 238:
																																case 241:
																																case 244:
																																case 245:
																																case 248:
																																case 250:
																																case 263:
																																case 266:
																																case 270:
																																case 287:
																																case 302:
																																case 303:
																																case 315:
																																case 322:
																																case 328:
																																case 340:
																																case 342:
																																case 344:
																																case 346:
																																case 349:
																																case 353:
																																case 365:
																																case 370:
																																case 379:
																																case 393:
																																case 397:
																																	goto end_IL_070f_2;
																																case 0:
																																case 2:
																																case 7:
																																case 28:
																																case 33:
																																case 44:
																																case 60:
																																case 67:
																																case 69:
																																case 84:
																																case 91:
																																case 93:
																																case 95:
																																case 105:
																																case 111:
																																case 112:
																																case 124:
																																case 140:
																																case 143:
																																case 162:
																																case 163:
																																case 164:
																																case 166:
																																case 167:
																																case 192:
																																case 195:
																																case 199:
																																case 205:
																																case 208:
																																case 210:
																																case 231:
																																case 236:
																																case 249:
																																case 251:
																																case 254:
																																case 274:
																																case 277:
																																case 283:
																																case 292:
																																case 294:
																																case 296:
																																case 297:
																																case 305:
																																case 311:
																																case 324:
																																case 327:
																																case 330:
																																case 338:
																																case 343:
																																case 357:
																																case 360:
																																case 367:
																																case 372:
																																case 381:
																																case 383:
																																	goto IL_1ea8_2;
																																case 358:
																																	ptr2 = ptr;
																																	goto IL_1ea8_2;
																																case 240:
																																	ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSoapActionControlBreak.CollectionCountCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGALLOWDELAYEDBINDING);
																																	goto case 358;
																																case 9:
																																	array7[0] = string_2;
																																	goto case 240;
																																case 425:
																																	array7 = new object[15];
																																	goto case 9;
																																case 410:
																																	array6 = new long[4];
																																	goto case 425;
																																case 53:
																																	array5 = new int[7];
																																	goto case 410;
																																case 31:
																																	array4 = new int[4];
																																	goto case 53;
																																case 206:
																																	array3 = new object[4];
																																	num = 31;
																																	goto case 31;
																																case 26:
																																	array2 = new byte[4];
																																	num = 206;
																																	goto case 206;
																																case 261:
																																	num4 = num2 * 8;
																																	goto case 26;
																																case 185:
																																	num3 = num2 * 4;
																																	goto case 261;
																																case 197:
																																	num2 = 1;
																																	goto case 185;
																																case 198:
																																	goto end_IL_0d43;
																																case 71:
																																case 89:
																																	goto IL_1f96_2;
																																}
																																continue;
																															}
																															array3[num6] = array7[*(int*)(ptr2 + num3)];
																															goto IL_09e6_2;
																															IL_09e6_2:
																															num6++;
																															goto IL_09f4_2;
																															IL_09f4_2:
																															ptr2 += 8;
																															goto IL_1ea8_2;
																															continue;
																															end_IL_06e3_2:
																															break;
																														}
																														break;
																													}
																													goto IL_1e5d_2;
																													continue;
																													end_IL_070f_2:
																													break;
																													IL_070f_2:;
																												}
																												break;
																											}
																											goto IL_0a07_2;
																											IL_0a2c_2:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											num = 56;
																											goto IL_0a73_2;
																											IL_0a07_2:
																											if (18 < b)
																											{
																												break;
																											}
																											num = 169;
																											goto IL_0a1e_2;
																											IL_0a73_2:
																											num6 -= 3;
																											goto IL_1ea8_2;
																											IL_0a1e_2:
																											if (18 > b)
																											{
																												break;
																											}
																											goto IL_0a2c_2;
																										}
																										break;
																									}
																									goto IL_07e5_2;
																									IL_0974_2:
																									array3[num6] = array3[num6 - 1];
																									goto IL_098c_2;
																									IL_07e5_2:
																									if (16 > b)
																									{
																										goto IL_07f3_2;
																									}
																									goto IL_0911_2;
																									IL_07f3_2:
																									if (14 >= b)
																									{
																										goto IL_07fe_2;
																									}
																									goto IL_084b_2;
																									IL_07fe_2:
																									if (14 > b)
																									{
																										break;
																									}
																									goto IL_080c_2;
																									IL_080c_2:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_082a_2;
																									IL_082a_2:
																									ptr2 += 8;
																									goto IL_0838_2;
																									IL_0838_2:
																									num6--;
																									goto IL_1ea8_2;
																									IL_084b_2:
																									if (15 < b)
																									{
																										break;
																									}
																									num = 47;
																									goto IL_0862_2;
																									IL_098c_2:
																									num6++;
																									goto IL_1ea8_2;
																									IL_0862_2:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_0870_2;
																									IL_0870_2:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0899_2;
																									IL_0899_2:
																									array2[num6 - 1] = 5;
																									goto IL_1ea8_2;
																									IL_0911_2:
																									array2[num6] = array2[num6 - 1];
																									num = 363;
																									goto IL_0932_2;
																									IL_0932_2:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0950_2;
																									IL_0950_2:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0974_2;
																								}
																								break;
																							}
																							goto IL_08b2_2;
																							IL_08fe_2:
																							ptr2 += 8;
																							goto IL_1ea8_2;
																							IL_08b2_2:
																							array2[num6 - 1] = 5;
																							goto IL_08c6_2;
																							IL_08c6_2:
																							array3[num6 - 1] = ((delegate*<string[], string>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_08fe_2;
																						}
																						break;
																					}
																					goto IL_0a86_2;
																					IL_0cb1_2:
																					ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0d05_2;
																					IL_0a86_2:
																					if (22 >= b)
																					{
																						goto IL_0a94_2;
																					}
																					goto IL_0bae_2;
																					IL_0a94_2:
																					if (22 <= b)
																					{
																						goto IL_0a9f_2;
																					}
																					goto IL_0b10_2;
																					IL_0a9f_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																					goto IL_0ae0_2;
																					IL_0ae0_2:
																					array2[num6 - 2] = 0;
																					goto IL_0af4_2;
																					IL_0af4_2:
																					num6--;
																					num = 84;
																					goto IL_1ea8_2;
																					IL_0b10_2:
																					if (20 >= b)
																					{
																						goto IL_0b1b_2;
																					}
																					goto IL_0b71_2;
																					IL_0b1b_2:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0b29_2;
																					IL_0b29_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																					goto IL_0b42_2;
																					IL_0b42_2:
																					array2[num6] = 1;
																					goto IL_0b50_2;
																					IL_0b50_2:
																					num6++;
																					goto IL_0b5e_2;
																					IL_0b5e_2:
																					ptr2 += 16;
																					goto IL_1ea8_2;
																					IL_0b71_2:
																					if (21 < b)
																					{
																						break;
																					}
																					num = 73;
																					goto IL_0b88_2;
																					IL_0d05_2:
																					num6--;
																					goto IL_1ea8_2;
																					IL_0b88_2:
																					if (21 > b)
																					{
																						break;
																					}
																					goto IL_0b96_2;
																					IL_0b96_2:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_1ea8_2;
																					IL_0bae_2:
																					if (24 >= b)
																					{
																						goto IL_0bbc_2;
																					}
																					goto IL_0c95_2;
																					IL_0bbc_2:
																					if (24 <= b)
																					{
																						goto IL_0bc7_2;
																					}
																					goto IL_0c14_2;
																					IL_0bc7_2:
																					array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
																					goto IL_0be5_2;
																					IL_0be5_2:
																					array2[num6] = 5;
																					goto IL_0bf3_2;
																					IL_0bf3_2:
																					num6++;
																					goto IL_0c01_2;
																					IL_0c01_2:
																					ptr2 += 8;
																					goto IL_1ea8_2;
																					IL_0c14_2:
																					if (23 < b)
																					{
																						break;
																					}
																					goto IL_0c22_2;
																					IL_0c22_2:
																					if (23 > b)
																					{
																						break;
																					}
																					goto IL_0c30_2;
																					IL_0c30_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0c82_2;
																					IL_0c82_2:
																					num6--;
																					goto IL_1ea8_2;
																					IL_0c95_2:
																					if (25 < b)
																					{
																						break;
																					}
																					goto IL_0ca3_2;
																					IL_0ca3_2:
																					if (25 > b)
																					{
																						break;
																					}
																					goto IL_0cb1_2;
																				}
																				break;
																			}
																			goto IL_0d18_2;
																			IL_130b_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_0d18_2:
																			if (13 <= b)
																			{
																				goto end_IL_07bc;
																			}
																			goto IL_0e07_2;
																			IL_0e07_2:
																			if (6 < b)
																			{
																				goto IL_0e15_2;
																			}
																			num = 334;
																			goto IL_10a4_2;
																			IL_0e15_2:
																			if (9 >= b)
																			{
																				goto IL_0e23_2;
																			}
																			goto IL_0f44_2;
																			IL_0e23_2:
																			if (9 <= b)
																			{
																				goto IL_0e2e_2;
																			}
																			goto IL_0e95_2;
																			IL_0e2e_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0e6e_2;
																			IL_0e6e_2:
																			array2[num6 - 2] = 0;
																			goto IL_0e82_2;
																			IL_0e82_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_0e95_2:
																			if (7 >= b)
																			{
																				goto IL_0ea0_2;
																			}
																			goto IL_0f15_2;
																			IL_0ea0_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0eae_2;
																			IL_0eae_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0eee_2;
																			IL_0eee_2:
																			array2[num6 - 2] = 0;
																			goto IL_0f02_2;
																			IL_0f02_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_0f15_2:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0f23_2;
																			IL_0f23_2:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0f31_2;
																			IL_0f31_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_0f44_2:
																			if (11 >= b)
																			{
																				goto IL_0f52_2;
																			}
																			goto IL_107a_2;
																			IL_0f52_2:
																			if (11 <= b)
																			{
																				goto IL_0f60_2;
																			}
																			goto IL_0fe9_2;
																			IL_0f60_2:
																			array2[num6 - 2] = 0;
																			goto IL_0f74_2;
																			IL_0f74_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_0fc8_2;
																			IL_0fc8_2:
																			num6--;
																			goto IL_0fd6_2;
																			IL_0fd6_2:
																			ptr2 += 8;
																			goto IL_1ea8_2;
																			IL_0fe9_2:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0ff7_2;
																			IL_0ff7_2:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_1005_2;
																			IL_1005_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_1067_2;
																			IL_1067_2:
																			num6 -= 2;
																			goto IL_1ea8_2;
																			IL_107a_2:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_1088_2;
																			IL_1088_2:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_1ea8_2;
																			IL_1327_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_1367_2;
																			IL_10a4_2:
																			if (6 > b)
																			{
																				goto IL_10b2_2;
																			}
																			num = 252;
																			goto IL_1327_2;
																			IL_10b2_2:
																			if (3 >= b)
																			{
																				goto IL_10c0_2;
																			}
																			goto IL_1214_2;
																			IL_10c0_2:
																			if (3 <= b)
																			{
																				goto IL_10cb_2;
																			}
																			goto IL_111e_2;
																			IL_10cb_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_10f4_2;
																			IL_10f4_2:
																			ptr2 += 8;
																			num = 235;
																			goto IL_110b_2;
																			IL_110b_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_111e_2:
																			if (1 >= b)
																			{
																				goto IL_1129_2;
																			}
																			goto IL_117f_2;
																			IL_1129_2:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_1137_2;
																			IL_1137_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_1150_2;
																			IL_1150_2:
																			array2[num6] = 0;
																			goto IL_115e_2;
																			IL_115e_2:
																			num6++;
																			goto IL_116c_2;
																			IL_116c_2:
																			ptr2 += 8;
																			goto IL_1ea8_2;
																			IL_117f_2:
																			if (2 < b)
																			{
																				break;
																			}
																			num = 18;
																			goto IL_1196_2;
																			IL_1367_2:
																			array2[num6 - 2] = 0;
																			goto IL_137b_2;
																			IL_1196_2:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_11a4_2;
																			IL_11a4_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 255;
																			goto IL_11ed_2;
																			IL_11ed_2:
																			array2[num6 - 2] = 0;
																			goto IL_1201_2;
																			IL_1201_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_1214_2:
																			if (4 >= b)
																			{
																				goto IL_121f_2;
																			}
																			goto IL_1292_2;
																			IL_121f_2:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_122d_2;
																			IL_122d_2:
																			array2[num6] = 0;
																			goto IL_123b_2;
																			IL_123b_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_125e_2;
																			IL_125e_2:
																			array3[num6] = null;
																			goto IL_1268_2;
																			IL_1268_2:
																			num6++;
																			num = 179;
																			goto IL_127f_2;
																			IL_127f_2:
																			ptr2 += 8;
																			goto IL_1ea8_2;
																			IL_1292_2:
																			if (5 < b)
																			{
																				break;
																			}
																			num = 392;
																			goto IL_12a9_2;
																			IL_137b_2:
																			num6--;
																			goto IL_1ea8_2;
																			IL_12a9_2:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_12b7_2;
																			IL_12b7_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_12f7_2;
																			IL_12f7_2:
																			array2[num6 - 2] = 0;
																			goto IL_130b_2;
																		}
																		break;
																	}
																	goto IL_07c7_2;
																	IL_09bb_2:
																	ptr2 += 16;
																	goto IL_1ea8_2;
																	IL_07c7_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																	goto IL_099f_2;
																	IL_099f_2:
																	array2[num6] = 3;
																	goto IL_09ad_2;
																	IL_09ad_2:
																	num6++;
																	goto IL_09bb_2;
																}
																break;
															}
															goto IL_138e_2;
															IL_1e02_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_138e_2:
															if (39 >= b)
															{
																goto IL_139c_2;
															}
															goto IL_1a33_2;
															IL_139c_2:
															if (39 > b)
															{
																goto IL_13aa_2;
															}
															num = 39;
															goto IL_19e6_2;
															IL_13aa_2:
															if (32 >= b)
															{
																goto IL_13b8_2;
															}
															goto IL_16c1_2;
															IL_13b8_2:
															if (32 > b)
															{
																goto IL_13c6_2;
															}
															goto IL_165b_2;
															IL_13c6_2:
															if (29 < b)
															{
																goto IL_13d4_2;
															}
															goto IL_14e8_2;
															IL_13d4_2:
															if (30 >= b)
															{
																goto IL_13df_2;
															}
															goto IL_1452_2;
															IL_13df_2:
															if (30 > b)
															{
																break;
															}
															goto IL_13ed_2;
															IL_13ed_2:
															array2[num6 - 1] = 0;
															goto IL_1401_2;
															IL_1401_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<string, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
															goto IL_143f_2;
															IL_143f_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1452_2:
															if (31 < b)
															{
																break;
															}
															goto IL_1460_2;
															IL_1460_2:
															if (31 > b)
															{
																break;
															}
															num = 356;
															goto IL_1477_2;
															IL_1e5d_2:
															num6--;
															num = 311;
															goto IL_1ea8_2;
															IL_1477_2:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_14d5_2;
															IL_14d5_2:
															num6--;
															goto IL_1ea8_2;
															IL_14e8_2:
															if (29 <= b)
															{
																goto IL_14f3_2;
															}
															goto IL_1559_2;
															IL_14f3_2:
															array2[num6 - 1] = 0;
															goto IL_1507_2;
															IL_1507_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1546_2;
															IL_1546_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1559_2:
															if (27 >= b)
															{
																goto IL_1564_2;
															}
															goto IL_15d8_2;
															IL_1564_2:
															if (27 > b)
															{
																break;
															}
															goto IL_1572_2;
															IL_1572_2:
															array2[num6 - 1] = 3;
															goto IL_1586_2;
															IL_1586_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_15c5_2;
															IL_15c5_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_15d8_2:
															if (28 < b)
															{
																break;
															}
															goto IL_15e6_2;
															IL_15e6_2:
															if (28 > b)
															{
																break;
															}
															goto IL_15f4_2;
															IL_15f4_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1634_2;
															IL_1634_2:
															array2[num6 - 2] = 3;
															goto IL_1648_2;
															IL_1648_2:
															num6--;
															goto IL_1ea8_2;
															IL_165b_2:
															array2[num6 - 1] = 3;
															goto IL_166f_2;
															IL_166f_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)setTagIsSerializable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_16ae_2;
															IL_16ae_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_16c1_2:
															if (35 >= b)
															{
																goto IL_16cf_2;
															}
															goto IL_185e_2;
															IL_16cf_2:
															if (35 > b)
															{
																goto IL_16dd_2;
															}
															goto IL_17c4_2;
															IL_16dd_2:
															if (33 >= b)
															{
																goto IL_16e8_2;
															}
															goto IL_175d_2;
															IL_16e8_2:
															if (33 > b)
															{
																break;
															}
															goto IL_16f6_2;
															IL_16f6_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1736_2;
															IL_1736_2:
															array2[num6 - 2] = 3;
															goto IL_174a_2;
															IL_174a_2:
															num6--;
															goto IL_1ea8_2;
															IL_175d_2:
															if (34 < b)
															{
																break;
															}
															goto IL_176b_2;
															IL_176b_2:
															if (34 > b)
															{
																break;
															}
															goto IL_1779_2;
															IL_1779_2:
															array2[num6] = 15;
															num = 29;
															goto IL_1790_2;
															IL_1790_2:
															array4[num6] = *(int*)(ptr2 + num3);
															goto IL_17a3_2;
															IL_17a3_2:
															ptr2 += 8;
															goto IL_17b1_2;
															IL_17b1_2:
															num6++;
															goto IL_1ea8_2;
															IL_17c4_2:
															array2[num6 - 1] = 5;
															goto IL_17d8_2;
															IL_17d8_2:
															array3[num6 - 1] = ((delegate*<ref char, string>)setTagIsSerializable[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref char>)setTagIsSerializable[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
															num = 117;
															goto IL_184b_2;
															IL_184b_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_185e_2:
															if (37 < b)
															{
																goto IL_1869_2;
															}
															goto IL_18b1_2;
															IL_1869_2:
															if (38 < b)
															{
																break;
															}
															goto IL_1877_2;
															IL_1877_2:
															if (38 > b)
															{
																break;
															}
															goto IL_1885_2;
															IL_1885_2:
															global::_003CModule_003E.string_27 = (string)array3[num6 - 1];
															goto IL_189e_2;
															IL_189e_2:
															num6--;
															goto IL_1ea8_2;
															IL_18b1_2:
															if (37 <= b)
															{
																goto IL_18bf_2;
															}
															goto IL_1971_2;
															IL_18bf_2:
															array2[num6 - 4] = 5;
															goto IL_18d3_2;
															IL_18d3_2:
															array3[num6 - 4] = ((delegate*<string, string, string, string, string>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 4], (string)array3[num6 - 3], (string)array3[num6 - 2], (string)array3[num6 - 1]);
															goto IL_1947_2;
															IL_1947_2:
															num6 -= 3;
															goto IL_1955_2;
															IL_1955_2:
															ptr2 += 8;
															num = 357;
															goto IL_1ea8_2;
															IL_1971_2:
															if (36 < b)
															{
																break;
															}
															num = 202;
															goto IL_1988_2;
															IL_1e76_2:
															if (52 < b)
															{
																break;
															}
															goto IL_1e81_2;
															IL_1988_2:
															if (36 > b)
															{
																break;
															}
															goto IL_1996_2;
															IL_1996_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_19ae_2;
															IL_19ae_2:
															array2[num6] = 5;
															goto IL_19bc_2;
															IL_19bc_2:
															num6++;
															goto IL_19ca_2;
															IL_19ca_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1e15_2:
															ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_1e5d_2;
															IL_19e6_2:
															array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
															goto IL_1a04_2;
															IL_1a04_2:
															array2[num6] = 5;
															goto IL_1a12_2;
															IL_1a12_2:
															num6++;
															goto IL_1a20_2;
															IL_1a20_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1a33_2:
															if (46 >= b)
															{
																goto IL_1a41_2;
															}
															goto IL_1c97_2;
															IL_1a41_2:
															if (46 <= b)
															{
																goto IL_1a4c_2;
															}
															goto IL_1aab_2;
															IL_1a4c_2:
															array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
															goto IL_1a6a_2;
															IL_1a6a_2:
															array2[num6] = 5;
															num = 88;
															goto IL_1a81_2;
															IL_1a81_2:
															num6++;
															num = 193;
															goto IL_1a98_2;
															IL_1a98_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1aab_2:
															if (42 < b)
															{
																goto IL_1ab9_2;
															}
															num = 223;
															goto IL_1bae_2;
															IL_1ab9_2:
															if (44 >= b)
															{
																goto IL_1ac7_2;
															}
															goto IL_1b5d_2;
															IL_1ac7_2:
															if (44 <= b)
															{
																goto IL_1ad2_2;
															}
															goto IL_1afd_2;
															IL_1ad2_2:
															array3[num6] = null;
															goto IL_1adc_2;
															IL_1adc_2:
															array2[num6] = 5;
															goto IL_1aea_2;
															IL_1aea_2:
															num6++;
															goto IL_1ea8_2;
															IL_1afd_2:
															if (43 < b)
															{
																break;
															}
															goto IL_1b0b_2;
															IL_1b0b_2:
															if (43 > b)
															{
																break;
															}
															goto IL_1b19_2;
															IL_1b19_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1b44_2;
															IL_1b44_2:
															array2[num6 - 1] = 0;
															goto IL_1ea8_2;
															IL_1b5d_2:
															if (45 < b)
															{
																break;
															}
															goto IL_1b6b_2;
															IL_1b6b_2:
															if (45 > b)
															{
																break;
															}
															goto IL_1b79_2;
															IL_1b79_2:
															global::_003CModule_003E.string_28 = (string)array3[num6 - 1];
															goto IL_1b92_2;
															IL_1b92_2:
															num6--;
															goto IL_1ea8_2;
															IL_1e81_2:
															if (52 <= b)
															{
															}
															break;
															IL_1bae_2:
															if (42 <= b)
															{
																goto IL_1bb9_2;
															}
															goto IL_1be1_2;
															IL_1bb9_2:
															((delegate*<void>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
															goto IL_1bce_2;
															IL_1bce_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1be1_2:
															if (40 >= b)
															{
																goto IL_1bec_2;
															}
															goto IL_1c5f_2;
															IL_1bec_2:
															if (40 > b)
															{
																break;
															}
															goto IL_1bfa_2;
															IL_1bfa_2:
															array2[num6 - 1] = 0;
															goto IL_1c0e_2;
															IL_1c0e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<string, bool>)setTagIsSerializable[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]) ? 1 : 0);
															goto IL_1c4c_2;
															IL_1c4c_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1c5f_2:
															if (41 < b)
															{
																break;
															}
															goto IL_1c6d_2;
															IL_1c6d_2:
															if (41 > b)
															{
																break;
															}
															goto IL_1c7b_2;
															IL_1c7b_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_1ea8_2;
															IL_1c97_2:
															if (49 >= b)
															{
																goto IL_1ca5_2;
															}
															goto IL_1d8a_2;
															IL_1ca5_2:
															if (49 <= b)
															{
																goto IL_1cb0_2;
															}
															goto IL_1cdc_2;
															IL_1cb0_2:
															global::_003CModule_003E.string_30 = (string)array3[num6 - 1];
															goto IL_1cc9_2;
															IL_1cc9_2:
															num6--;
															goto IL_1ea8_2;
															IL_1cdc_2:
															if (47 >= b)
															{
																goto IL_1ce7_2;
															}
															goto IL_1d21_2;
															IL_1ce7_2:
															if (47 > b)
															{
																break;
															}
															goto IL_1cf5_2;
															IL_1cf5_2:
															global::_003CModule_003E.string_29 = (string)array3[num6 - 1];
															goto IL_1d0e_2;
															IL_1d0e_2:
															num6--;
															goto IL_1ea8_2;
															IL_1d21_2:
															if (48 < b)
															{
																break;
															}
															goto IL_1d2f_2;
															IL_1d2f_2:
															if (48 > b)
															{
																break;
															}
															goto IL_1d3d_2;
															IL_1d3d_2:
															array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
															goto IL_1d5b_2;
															IL_1d5b_2:
															array2[num6] = 5;
															goto IL_1d69_2;
															IL_1d69_2:
															num6++;
															goto IL_1d77_2;
															IL_1d77_2:
															ptr2 += 8;
															goto IL_1ea8_2;
															IL_1d8a_2:
															if (51 >= b)
															{
																goto IL_1d98_2;
															}
															goto IL_1e76_2;
															IL_1d98_2:
															if (51 > b)
															{
																goto IL_1da3_2;
															}
															goto IL_1e15_2;
															IL_1da3_2:
															if (50 < b)
															{
																break;
															}
															goto IL_1db1_2;
															IL_1db1_2:
															if (50 > b)
															{
																break;
															}
															goto IL_1dbf_2;
															IL_1dbf_2:
															array3[num6] = ((delegate*<string>)setTagIsSerializable[*(int*)(ptr2 + num3)])();
															goto IL_1ddd_2;
															IL_1ddd_2:
															array2[num6] = 5;
															num = 173;
															goto IL_1df4_2;
															IL_1df4_2:
															num6++;
															goto IL_1e02_2;
														}
														break;
														IL_078c_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 381;
												goto IL_1ea8_2;
												continue;
												end_IL_079c_2:
												break;
											}
											continue;
											end_IL_07ac:
											break;
										}
										continue;
										end_IL_07bc:
										break;
									}
									break;
								}
								num = 71;
								goto IL_1f96_2;
								IL_1f96_2:
								return (string)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0d35_2;
					}
					continue;
					end_IL_0d43:
					break;
				}
				break;
			}
		}
	}

	private unsafe static IEnumerator smethod_7(string string_2, string string_3)
	{
		int num = 30;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											object[] array6 = new object[2];
											while (true)
											{
												array6[0] = string_2;
												while (true)
												{
													array6[1] = string_3;
													while (true)
													{
														byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UrtSystemCOREIO.ContractAbbreviatorAttributeVARFLAGFDEFAULTBIND);
														while (true)
														{
															byte* ptr2 = ptr;
															while (true)
															{
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_04ac:
																		byte b = *ptr2;
																		num = 203;
																		while (true)
																		{
																			IL_049c:
																			ptr2++;
																			while (true)
																			{
																				IL_048c:
																				if (b >= 1)
																				{
																					while (b <= 23)
																					{
																						while (true)
																						{
																							IL_046c:
																							if (12 < b)
																							{
																								while (true)
																								{
																									IL_045c:
																									if (18 >= b)
																									{
																										while (true)
																										{
																											IL_044c:
																											if (18 > b)
																											{
																												while (true)
																												{
																													IL_043c:
																													if (15 < b)
																													{
																														while (true)
																														{
																															IL_042c:
																															if (16 >= b)
																															{
																																while (16 <= b)
																																{
																																	num = 101;
																																	while (true)
																																	{
																																		IL_03c5:
																																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																		while (true)
																																		{
																																			IL_03ac:
																																			num6--;
																																			num = 223;
																																			while (num != 223)
																																			{
																																				if (num != 1204)
																																				{
																																					goto IL_09af;
																																				}
																																				switch (num)
																																				{
																																				case 106:
																																					goto IL_03ac;
																																				case 101:
																																				case 141:
																																					goto IL_03c5;
																																				case 84:
																																					goto IL_0419;
																																				case 28:
																																					goto IL_042c;
																																				case 160:
																																					goto IL_043c;
																																				case 120:
																																					goto IL_044c;
																																				case 145:
																																				case 146:
																																					goto IL_045c;
																																				case 121:
																																					goto IL_046c;
																																				case 62:
																																					goto IL_047c;
																																				case 124:
																																					goto IL_048c;
																																				case 203:
																																					goto IL_049c;
																																				case 6:
																																				case 125:
																																					goto IL_04ac;
																																				case 4:
																																				case 98:
																																					goto IL_04c0;
																																				case 173:
																																					goto IL_04d3;
																																				case 161:
																																				case 170:
																																					goto IL_04de;
																																				case 48:
																																				case 143:
																																					goto IL_04eb;
																																				case 88:
																																				case 181:
																																					goto IL_0531;
																																				case 65:
																																					goto IL_053f;
																																				case 182:
																																					goto IL_054f;
																																				case 169:
																																				case 179:
																																					goto IL_055d;
																																				case 52:
																																					goto IL_0576;
																																				case 81:
																																					goto IL_058d;
																																				case 45:
																																					goto IL_059b;
																																				case 108:
																																				case 187:
																																					goto IL_05ae;
																																				case 192:
																																					goto IL_05c6;
																																				case 80:
																																				case 119:
																																					goto IL_05d4;
																																				case 166:
																																					goto IL_05e8;
																																				case 184:
																																					goto IL_0621;
																																				case 198:
																																					goto IL_0634;
																																				case 165:
																																					goto IL_0648;
																																				case 27:
																																				case 33:
																																					goto IL_065b;
																																				case 204:
																																					goto IL_0673;
																																				case 73:
																																					goto IL_0691;
																																				case 60:
																																					goto IL_06b5;
																																				case 214:
																																					goto IL_06cd;
																																				case 171:
																																					goto IL_06e9;
																																				case 156:
																																				case 189:
																																					goto IL_06f4;
																																				case 72:
																																					goto IL_06ff;
																																				case 44:
																																				case 149:
																																					goto IL_070d;
																																				case 115:
																																					goto IL_0729;
																																				case 152:
																																					goto IL_0737;
																																				case 212:
																																					goto IL_074a;
																																				case 85:
																																					goto IL_0758;
																																				case 195:
																																					goto IL_0763;
																																				case 8:
																																				case 132:
																																					goto IL_0771;
																																				case 68:
																																					goto IL_0789;
																																				case 158:
																																					goto IL_0797;
																																				case 107:
																																					goto IL_07a5;
																																				case 118:
																																					goto IL_07b8;
																																				case 216:
																																					goto IL_07c6;
																																				case 11:
																																				case 24:
																																					goto IL_07d4;
																																				case 32:
																																					goto IL_0801;
																																				case 76:
																																				case 133:
																																					goto IL_081d;
																																				case 177:
																																					goto IL_0853;
																																				case 144:
																																					goto IL_0866;
																																				case 215:
																																					goto IL_0874;
																																				case 213:
																																					goto IL_0882;
																																				case 89:
																																				case 109:
																																					goto IL_088d;
																																				case 190:
																																					goto IL_08cd;
																																				case 123:
																																					goto IL_08e1;
																																				case 163:
																																					goto IL_08f4;
																																				case 153:
																																					goto IL_0902;
																																				case 174:
																																					goto IL_0910;
																																				case 155:
																																					goto IL_091e;
																																				case 191:
																																					goto IL_092c;
																																				case 57:
																																				case 96:
																																					goto IL_093a;
																																				case 18:
																																					goto IL_097a;
																																				case 77:
																																					goto IL_098e;
																																				case 17:
																																					goto IL_09a1;
																																				case 87:
																																				case 209:
																																					goto IL_09af;
																																				case 175:
																																					goto IL_09c8;
																																				case 162:
																																					goto IL_09d6;
																																				case 138:
																																					goto IL_09e4;
																																				case 23:
																																				case 111:
																																					goto IL_09f7;
																																				case 135:
																																					goto IL_0a20;
																																				case 19:
																																					goto IL_0a2e;
																																				case 154:
																																					goto IL_0a41;
																																				case 2:
																																					goto IL_0a4c;
																																				case 42:
																																				case 126:
																																					goto IL_0a63;
																																				case 159:
																																					goto IL_0a71;
																																				case 136:
																																					goto IL_0a94;
																																				case 25:
																																					goto IL_0a9e;
																																				case 10:
																																					goto IL_0aac;
																																				case 37:
																																					goto IL_0abf;
																																				case 148:
																																					goto IL_0acd;
																																				case 50:
																																				case 100:
																																					goto IL_0adb;
																																				case 180:
																																					goto IL_0b1b;
																																				case 79:
																																					goto IL_0b2f;
																																				case 110:
																																					goto IL_0b42;
																																				case 9:
																																					goto IL_0b59;
																																				case 86:
																																				case 95:
																																					goto IL_0b67;
																																				case 38:
																																					goto IL_0b72;
																																				case 102:
																																				case 201:
																																					goto IL_0b80;
																																				case 172:
																																					goto IL_0bc9;
																																				case 112:
																																					goto IL_0bdd;
																																				case 75:
																																					goto IL_0bf0;
																																				case 71:
																																					goto IL_0bfe;
																																				case 14:
																																				case 183:
																																					goto IL_0c0c;
																																				case 3:
																																				case 41:
																																					goto IL_0c1f;
																																				case 90:
																																					goto IL_0c5f;
																																				case 210:
																																					goto IL_0c7c;
																																				case 59:
																																					goto IL_0c8f;
																																				case 35:
																																					goto IL_0c9d;
																																				case 91:
																																					goto IL_0cab;
																																				case 16:
																																				case 208:
																																					goto IL_0cb9;
																																				case 167:
																																					goto IL_0ccd;
																																				case 178:
																																					goto IL_0d0c;
																																				case 130:
																																					goto IL_0d1f;
																																				case 40:
																																				case 78:
																																					goto IL_0d2a;
																																				case 5:
																																					goto IL_0d8c;
																																				case 1:
																																				case 12:
																																				case 13:
																																				case 15:
																																				case 21:
																																				case 22:
																																				case 26:
																																				case 43:
																																				case 47:
																																				case 53:
																																				case 55:
																																				case 58:
																																				case 63:
																																				case 64:
																																				case 69:
																																				case 70:
																																				case 82:
																																				case 83:
																																				case 93:
																																				case 94:
																																				case 97:
																																				case 99:
																																				case 104:
																																				case 114:
																																				case 117:
																																				case 128:
																																				case 134:
																																				case 139:
																																				case 140:
																																				case 151:
																																				case 168:
																																				case 176:
																																				case 185:
																																				case 193:
																																				case 194:
																																				case 199:
																																				case 202:
																																				case 206:
																																				case 207:
																																					goto end_IL_0419;
																																				case 7:
																																				case 20:
																																				case 31:
																																				case 34:
																																				case 36:
																																				case 39:
																																				case 49:
																																				case 51:
																																				case 54:
																																				case 56:
																																				case 74:
																																				case 92:
																																				case 116:
																																				case 122:
																																				case 127:
																																				case 129:
																																				case 137:
																																				case 150:
																																				case 157:
																																				case 164:
																																				case 186:
																																				case 188:
																																				case 197:
																																				case 205:
																																				case 211:
																																					goto end_IL_0399;
																																				case 131:
																																					goto end_IL_0daf;
																																				case 105:
																																					goto end_IL_0dc2;
																																				case 113:
																																					goto end_IL_0dcc;
																																				case 46:
																																					goto end_IL_0dd7;
																																				case 61:
																																					goto end_IL_0de7;
																																				case 67:
																																					goto end_IL_0df7;
																																				case 196:
																																					goto end_IL_0e07;
																																				case 66:
																																					goto end_IL_0e17;
																																				case 103:
																																					goto end_IL_0e27;
																																				case 147:
																																					goto end_IL_0e37;
																																				case 200:
																																					goto end_IL_0e47;
																																				case 29:
																																					goto end_IL_0e57;
																																				case 30:
																																					goto end_IL_0e67;
																																				case 0:
																																				case 142:
																																					goto IL_0e82;
																																				}
																																				continue;
																																				end_IL_0399:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto end_IL_048c;
																																	continue;
																																	end_IL_0419:
																																	break;
																																	IL_0419:;
																																}
																																break;
																															}
																															goto IL_04c0;
																															IL_0621:
																															ptr2 += 8;
																															goto end_IL_048c;
																															IL_04c0:
																															if (17 < b)
																															{
																																break;
																															}
																															goto IL_05c6;
																															IL_05c6:
																															if (17 > b)
																															{
																																break;
																															}
																															goto IL_05d4;
																															IL_05d4:
																															array[num6 - 1] = 5;
																															goto IL_05e8;
																															IL_05e8:
																															array2[num6 - 1] = ((delegate*<int, _003CLoadAndPlayAudio_003Ed__17>)WriteTimeoutMethodName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																															goto IL_0621;
																														}
																														break;
																													}
																													goto IL_04d3;
																													IL_0648:
																													num6--;
																													goto end_IL_048c;
																													IL_04d3:
																													if (15 > b)
																													{
																														goto IL_04de;
																													}
																													goto IL_04eb;
																													IL_04de:
																													if (13 < b)
																													{
																														goto IL_0531;
																													}
																													goto IL_054f;
																													IL_0531:
																													if (14 < b)
																													{
																														break;
																													}
																													goto IL_053f;
																													IL_053f:
																													if (14 > b)
																													{
																														break;
																													}
																													goto IL_05ae;
																													IL_05ae:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto end_IL_048c;
																													IL_054f:
																													if (13 > b)
																													{
																														break;
																													}
																													goto IL_055d;
																													IL_055d:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																													goto IL_0576;
																													IL_0576:
																													array[num6] = 1;
																													num = 81;
																													goto IL_058d;
																													IL_058d:
																													num6++;
																													goto IL_059b;
																													IL_059b:
																													ptr2 += 16;
																													goto end_IL_048c;
																													IL_04eb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																													goto IL_0634;
																													IL_0634:
																													array[num6 - 2] = 0;
																													goto IL_0648;
																												}
																												break;
																											}
																											goto IL_065b;
																											IL_06cd:
																											num6++;
																											num = 56;
																											goto end_IL_048c;
																											IL_065b:
																											array[num6] = array[num6 - 1];
																											goto IL_0673;
																											IL_0673:
																											array3[num6 - 0] = array3[num6 - 1];
																											goto IL_0691;
																											IL_0691:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_06b5;
																											IL_06b5:
																											array2[num6] = array2[num6 - 1];
																											goto IL_06cd;
																										}
																										break;
																									}
																									goto IL_06e9;
																									IL_0853:
																									num6 -= 2;
																									goto end_IL_048c;
																									IL_06e9:
																									if (21 < b)
																									{
																										goto IL_06f4;
																									}
																									goto IL_074a;
																									IL_06f4:
																									if (22 >= b)
																									{
																										goto IL_06ff;
																									}
																									goto IL_0729;
																									IL_06ff:
																									if (22 > b)
																									{
																										break;
																									}
																									goto IL_070d;
																									IL_070d:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_048c;
																									IL_0729:
																									if (23 < b)
																									{
																										break;
																									}
																									goto IL_0737;
																									IL_0737:
																									if (23 > b)
																									{
																									}
																									break;
																									IL_074a:
																									if (21 > b)
																									{
																										goto IL_0758;
																									}
																									goto IL_081d;
																									IL_0758:
																									if (19 >= b)
																									{
																										goto IL_0763;
																									}
																									goto IL_07b8;
																									IL_0763:
																									if (19 > b)
																									{
																										break;
																									}
																									goto IL_0771;
																									IL_0771:
																									array2[num6] = array6[*(int*)(ptr2 + num3)];
																									goto IL_0789;
																									IL_0789:
																									array[num6] = 5;
																									goto IL_0797;
																									IL_0797:
																									num6++;
																									goto IL_07a5;
																									IL_07a5:
																									ptr2 += 8;
																									goto end_IL_048c;
																									IL_07b8:
																									if (20 < b)
																									{
																										break;
																									}
																									goto IL_07c6;
																									IL_07c6:
																									if (20 > b)
																									{
																										break;
																									}
																									goto IL_07d4;
																									IL_07d4:
																									((_003CLoadAndPlayAudio_003Ed__17)array2[num6 - 2]).string_0 = (string)array2[num6 - 1];
																									goto IL_0801;
																									IL_0801:
																									num6 -= 2;
																									num = 164;
																									goto end_IL_048c;
																									IL_081d:
																									((_003CLoadAndPlayAudio_003Ed__17)array2[num6 - 2]).string_1 = (string)array2[num6 - 1];
																									num = 177;
																									goto IL_0853;
																								}
																								break;
																							}
																							goto IL_0866;
																							IL_0d1f:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0d2a;
																							IL_0866:
																							if (12 <= b)
																							{
																								goto end_IL_048c;
																							}
																							goto IL_0874;
																							IL_0874:
																							if (6 >= b)
																							{
																								goto IL_0882;
																							}
																							goto IL_0b42;
																							IL_0882:
																							if (6 <= b)
																							{
																								goto IL_088d;
																							}
																							goto IL_08f4;
																							IL_088d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_08cd;
																							IL_08cd:
																							array[num6 - 2] = 0;
																							goto IL_08e1;
																							IL_08e1:
																							num6--;
																							goto end_IL_048c;
																							IL_08f4:
																							if (3 >= b)
																							{
																								goto IL_0902;
																							}
																							goto IL_0a41;
																							IL_0902:
																							if (3 > b)
																							{
																								goto IL_0910;
																							}
																							goto IL_09f7;
																							IL_0910:
																							if (1 < b)
																							{
																								goto IL_091e;
																							}
																							goto IL_09a1;
																							IL_091e:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_092c;
																							IL_092c:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_093a;
																							IL_093a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_097a;
																							IL_097a:
																							array[num6 - 2] = 0;
																							goto IL_098e;
																							IL_098e:
																							num6--;
																							goto end_IL_048c;
																							IL_09a1:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_09af;
																							IL_09af:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																							goto IL_09c8;
																							IL_09c8:
																							array[num6] = 0;
																							goto IL_09d6;
																							IL_09d6:
																							num6++;
																							goto IL_09e4;
																							IL_09e4:
																							ptr2 += 8;
																							goto end_IL_048c;
																							IL_09f7:
																							ref int reference = ref array4[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0a20;
																							IL_0a20:
																							ptr2 += 8;
																							goto IL_0a2e;
																							IL_0a2e:
																							num6--;
																							goto end_IL_048c;
																							IL_0a41:
																							if (4 >= b)
																							{
																								goto IL_0a4c;
																							}
																							goto IL_0abf;
																							IL_0a4c:
																							if (4 > b)
																							{
																								break;
																							}
																							num = 42;
																							goto IL_0a63;
																							IL_0d2a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0d8c;
																							IL_0a63:
																							array[num6] = 0;
																							goto IL_0a71;
																							IL_0a71:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																							goto IL_0a94;
																							IL_0a94:
																							array2[num6] = null;
																							goto IL_0a9e;
																							IL_0a9e:
																							num6++;
																							goto IL_0aac;
																							IL_0aac:
																							ptr2 += 8;
																							goto end_IL_048c;
																							IL_0abf:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0acd;
																							IL_0acd:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0adb;
																							IL_0adb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0b1b;
																							IL_0b1b:
																							array[num6 - 2] = 0;
																							goto IL_0b2f;
																							IL_0b2f:
																							num6--;
																							goto end_IL_048c;
																							IL_0b42:
																							if (9 >= b)
																							{
																								num = 9;
																								goto IL_0b59;
																							}
																							goto IL_0c8f;
																							IL_0d8c:
																							num6 -= 2;
																							goto end_IL_048c;
																							IL_0b59:
																							if (9 > b)
																							{
																								goto IL_0b67;
																							}
																							goto IL_0c1f;
																							IL_0b67:
																							if (7 >= b)
																							{
																								goto IL_0b72;
																							}
																							goto IL_0bf0;
																							IL_0b72:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0b80;
																							IL_0b80:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							num = 172;
																							goto IL_0bc9;
																							IL_0bc9:
																							array[num6 - 2] = 0;
																							goto IL_0bdd;
																							IL_0bdd:
																							num6--;
																							goto end_IL_048c;
																							IL_0bf0:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0bfe;
																							IL_0bfe:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0c0c;
																							IL_0c0c:
																							num6--;
																							goto end_IL_048c;
																							IL_0c1f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0c5f;
																							IL_0c5f:
																							array[num6 - 2] = 0;
																							num = 210;
																							goto IL_0c7c;
																							IL_0c7c:
																							num6--;
																							goto end_IL_048c;
																							IL_0c8f:
																							if (10 < b)
																							{
																								goto IL_0c9d;
																							}
																							goto IL_0d1f;
																							IL_0c9d:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0cab;
																							IL_0cab:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_0cb9;
																							IL_0cb9:
																							array[num6 - 1] = 0;
																							goto IL_0ccd;
																							IL_0ccd:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<int, int>)WriteTimeoutMethodName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0d0c;
																							IL_0d0c:
																							ptr2 += 8;
																							goto end_IL_048c;
																						}
																						break;
																						IL_047c:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				continue;
																				end_IL_048c:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																}
																goto IL_0e82;
																IL_0e82:
																return (IEnumerator)array2[num6 - 1];
																continue;
																end_IL_0daf:
																break;
															}
															continue;
															end_IL_0dc2:
															break;
														}
														continue;
														end_IL_0dcc:
														break;
													}
													continue;
													end_IL_0dd7:
													break;
												}
												continue;
												end_IL_0de7:
												break;
											}
											continue;
											end_IL_0df7:
											break;
										}
										continue;
										end_IL_0e07:
										break;
									}
									continue;
									end_IL_0e17:
									break;
								}
								continue;
								end_IL_0e27:
								break;
							}
							continue;
							end_IL_0e37:
							break;
						}
						continue;
						end_IL_0e47:
						break;
					}
					continue;
					end_IL_0e57:
					break;
				}
				continue;
				end_IL_0e67:
				break;
			}
		}
	}

	private unsafe static void smethod_8(AudioClip audioClip_0)
	{
		int num = 154;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 69;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = audioClip_0;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentThreadView.CreationTimeGetNumericValue);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 228;
																while (true)
																{
																	IL_06b0:
																	if (b >= 1)
																	{
																		while (b <= 45)
																		{
																			while (true)
																			{
																				IL_0690:
																				if (23 < b)
																				{
																					while (true)
																					{
																						IL_0683:
																						if (34 < b)
																						{
																							while (true)
																							{
																								IL_0673:
																								if (40 < b)
																								{
																									while (true)
																									{
																										IL_0663:
																										if (43 >= b)
																										{
																											while (true)
																											{
																												IL_0653:
																												if (43 > b)
																												{
																													while (true)
																													{
																														IL_0643:
																														if (41 < b)
																														{
																															while (42 >= b)
																															{
																																num = 384;
																																while (true)
																																{
																																	if (num != 384)
																																	{
																																		if (num != 1365)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 126:
																																			goto IL_0630;
																																		case 276:
																																			goto IL_0643;
																																		case 60:
																																			goto IL_0653;
																																		case 22:
																																			goto IL_0663;
																																		case 280:
																																			goto IL_0673;
																																		case 4:
																																			goto IL_0683;
																																		case 314:
																																			goto IL_0690;
																																		case 178:
																																			goto IL_06a0;
																																		case 228:
																																			goto IL_06b0;
																																		case 19:
																																			goto end_IL_06b0;
																																		case 59:
																																		case 377:
																																			goto end_IL_06c0;
																																		case 222:
																																			goto IL_06e4;
																																		case 86:
																																		case 198:
																																			goto IL_06ef;
																																		case 2:
																																			goto IL_072f;
																																		case 91:
																																			goto IL_0748;
																																		case 203:
																																			goto IL_0756;
																																		case 17:
																																		case 29:
																																			goto IL_0761;
																																		case 192:
																																			goto IL_0784;
																																		case 205:
																																			goto IL_078f;
																																		case 72:
																																			goto IL_079d;
																																		case 78:
																																			goto IL_07ab;
																																		case 67:
																																		case 201:
																																			goto IL_07b9;
																																		case 190:
																																			goto IL_07cd;
																																		case 73:
																																			goto IL_080e;
																																		case 28:
																																			goto IL_0821;
																																		case 241:
																																			goto IL_0834;
																																		case 244:
																																			goto IL_0847;
																																		case 14:
																																		case 216:
																																			goto IL_0855;
																																		case 114:
																																			goto IL_0895;
																																		case 45:
																																			goto IL_08a9;
																																		case 256:
																																			goto IL_08bc;
																																		case 133:
																																		case 218:
																																			goto IL_08ca;
																																		case 20:
																																			goto IL_08de;
																																		case 191:
																																			goto IL_092b;
																																		case 261:
																																			goto IL_093e;
																																		case 272:
																																			goto IL_0951;
																																		case 104:
																																		case 234:
																																			goto IL_095f;
																																		case 267:
																																			goto IL_097c;
																																		case 118:
																																			goto IL_09c9;
																																		case 254:
																																			goto IL_09d7;
																																		case 284:
																																			goto IL_09ea;
																																		case 124:
																																			goto IL_09f8;
																																		case 163:
																																		case 278:
																																			goto IL_0a0f;
																																		case 237:
																																			goto IL_0a23;
																																		case 224:
																																			goto IL_0a62;
																																		case 326:
																																			goto IL_0a75;
																																		case 57:
																																		case 275:
																																			goto IL_0a80;
																																		case 18:
																																			goto IL_0abe;
																																		case 61:
																																			goto IL_0ad7;
																																		case 204:
																																			goto IL_0ae5;
																																		case 68:
																																		case 172:
																																			goto IL_0af3;
																																		case 165:
																																			goto IL_0b31;
																																		case 93:
																																			goto IL_0b3f;
																																		case 328:
																																			goto IL_0b52;
																																		case 338:
																																			goto IL_0b65;
																																		case 333:
																																		case 349:
																																			goto IL_0b78;
																																		case 240:
																																			goto IL_0b82;
																																		case 353:
																																			goto IL_0b95;
																																		case 297:
																																			goto IL_0ba3;
																																		case 339:
																																			goto IL_0bb1;
																																		case 362:
																																			goto IL_0bc4;
																																		case 360:
																																			goto IL_0bd2;
																																		case 89:
																																		case 260:
																																			goto IL_0be9;
																																		case 143:
																																			goto IL_0bfd;
																																		case 76:
																																			goto IL_0c3c;
																																		case 364:
																																			goto IL_0c4f;
																																		case 370:
																																			goto IL_0c62;
																																		case 120:
																																			goto IL_0c70;
																																		case 39:
																																		case 147:
																																			goto IL_0c7b;
																																		case 83:
																																			goto IL_0c89;
																																		case 34:
																																			goto IL_0cad;
																																		case 325:
																																			goto IL_0cbb;
																																		case 271:
																																			goto IL_0cce;
																																		case 345:
																																			goto IL_0cdc;
																																		case 3:
																																		case 252:
																																			goto IL_0ce7;
																																		case 306:
																																			goto IL_0d27;
																																		case 354:
																																			goto IL_0d3b;
																																		case 350:
																																			goto IL_0d4e;
																																		case 324:
																																			goto IL_0d5c;
																																		case 189:
																																		case 207:
																																			goto IL_0d67;
																																		case 221:
																																			goto IL_0da7;
																																		case 225:
																																			goto IL_0dbb;
																																		case 27:
																																			goto IL_0dce;
																																		case 361:
																																			goto IL_0ddc;
																																		case 209:
																																		case 296:
																																			goto IL_0dea;
																																		case 289:
																																			goto IL_0e03;
																																		case 331:
																																			goto IL_0e11;
																																		case 281:
																																			goto IL_0e24;
																																		case 356:
																																			goto IL_0e2f;
																																		case 24:
																																		case 40:
																																			goto IL_0e3d;
																																		case 31:
																																			goto IL_0e6b;
																																		case 346:
																																			goto IL_0e79;
																																		case 79:
																																		case 173:
																																			goto IL_0e87;
																																		case 213:
																																			goto IL_0e95;
																																		case 23:
																																			goto IL_0eb8;
																																		case 63:
																																			goto IL_0ec2;
																																		case 193:
																																			goto IL_0ed0;
																																		case 367:
																																			goto IL_0ee3;
																																		case 179:
																																			goto IL_0ef1;
																																		case 332:
																																			goto IL_0efc;
																																		case 223:
																																		case 365:
																																			goto IL_0f0a;
																																		case 210:
																																			goto IL_0f4a;
																																		case 208:
																																			goto IL_0f5e;
																																		case 119:
																																			goto IL_0f7a;
																																		case 13:
																																			goto IL_0f91;
																																		case 162:
																																			goto IL_0fad;
																																		case 64:
																																		case 263:
																																			goto IL_0fb8;
																																		case 175:
																																			goto IL_0fcb;
																																		case 171:
																																			goto IL_0fd9;
																																		case 170:
																																			goto IL_0fe7;
																																		case 21:
																																		case 310:
																																			goto IL_0ff5;
																																		case 146:
																																			goto IL_1035;
																																		case 58:
																																			goto IL_1049;
																																		case 359:
																																			goto IL_1065;
																																		case 81:
																																		case 151:
																																			goto IL_1073;
																																		case 283:
																																			goto IL_10b3;
																																		case 82:
																																			goto IL_10c7;
																																		case 220:
																																			goto IL_10da;
																																		case 348:
																																			goto IL_10e8;
																																		case 7:
																																		case 141:
																																			goto IL_10f3;
																																		case 113:
																																			goto IL_110f;
																																		case 30:
																																			goto IL_111d;
																																		case 194:
																																		case 230:
																																			goto IL_1128;
																																		case 318:
																																			goto IL_1140;
																																		case 176:
																																			goto IL_114b;
																																		case 341:
																																			goto IL_115e;
																																		case 277:
																																			goto IL_116c;
																																		case 273:
																																		case 327:
																																			goto IL_117a;
																																		case 196:
																																			goto IL_1193;
																																		case 148:
																																			goto IL_11a1;
																																		case 343:
																																			goto IL_11af;
																																		case 227:
																																			goto IL_11cb;
																																		case 35:
																																			goto IL_11d6;
																																		case 103:
																																		case 111:
																																			goto IL_11e4;
																																		case 340:
																																			goto IL_1225;
																																		case 149:
																																			goto IL_1239;
																																		case 100:
																																			goto IL_124c;
																																		case 320:
																																			goto IL_125a;
																																		case 295:
																																		case 355:
																																			goto IL_1271;
																																		case 180:
																																			goto IL_12c3;
																																		case 132:
																																			goto IL_12d6;
																																		case 54:
																																			goto IL_12e4;
																																		case 49:
																																		case 84:
																																			goto IL_12ef;
																																		case 329:
																																			goto IL_1308;
																																		case 106:
																																			goto IL_131b;
																																		case 123:
																																			goto IL_1326;
																																		case 74:
																																			goto IL_1334;
																																		case 44:
																																		case 286:
																																			goto IL_1342;
																																		case 183:
																																			goto IL_1356;
																																		case 253:
																																			goto IL_138e;
																																		case 164:
																																			goto IL_13aa;
																																		case 270:
																																		case 369:
																																			goto end_IL_061d;
																																		case 311:
																																			goto IL_13c6;
																																		case 129:
																																			goto IL_13e4;
																																		case 43:
																																			goto IL_13f2;
																																		case 98:
																																			goto IL_140e;
																																		case 177:
																																			goto IL_1419;
																																		case 322:
																																		case 358:
																																			goto IL_1427;
																																		case 312:
																																			goto IL_1440;
																																		case 302:
																																			goto IL_144e;
																																		case 10:
																																			goto IL_145c;
																																		case 293:
																																			goto IL_146f;
																																		case 342:
																																			goto IL_147d;
																																		case 229:
																																		case 259:
																																			goto IL_148b;
																																		case 336:
																																			goto IL_149f;
																																		case 127:
																																			goto IL_14de;
																																		case 371:
																																			goto IL_14f1;
																																		case 309:
																																			goto IL_14ff;
																																		case 285:
																																		case 373:
																																			goto IL_1512;
																																		case 9:
																																			goto IL_1574;
																																		case 374:
																																			goto IL_1587;
																																		case 376:
																																			goto IL_159a;
																																		case 344:
																																			goto IL_15a5;
																																		case 96:
																																		case 265:
																																			goto IL_15b3;
																																		case 246:
																																			goto IL_15d1;
																																		case 80:
																																			goto IL_15e4;
																																		case 301:
																																			goto IL_15f2;
																																		case 109:
																																		case 215:
																																			goto IL_1600;
																																		case 16:
																																			goto IL_1614;
																																		case 264:
																																			goto IL_1653;
																																		case 122:
																																		case 158:
																																			goto IL_1674;
																																		case 108:
																																			goto IL_16b4;
																																		case 242:
																																			goto IL_16c8;
																																		case 138:
																																		case 323:
																																			goto IL_16e4;
																																		case 125:
																																			goto IL_1721;
																																		case 15:
																																			goto IL_172f;
																																		case 300:
																																			goto IL_1742;
																																		case 169:
																																			goto IL_174d;
																																		case 12:
																																		case 117:
																																			goto IL_175b;
																																		case 131:
																																			goto IL_1786;
																																		case 319:
																																			goto IL_179f;
																																		case 105:
																																			goto IL_17ad;
																																		case 168:
																																			goto IL_17c0;
																																		case 50:
																																			goto IL_17ce;
																																		case 8:
																																			goto IL_17dc;
																																		case 47:
																																		case 290:
																																			goto IL_17e7;
																																		case 243:
																																			goto IL_1827;
																																		case 255:
																																			goto IL_183b;
																																		case 305:
																																			goto IL_184e;
																																		case 202:
																																			goto IL_1859;
																																		case 1:
																																		case 115:
																																			goto IL_1867;
																																		case 85:
																																			goto IL_188b;
																																		case 160:
																																			goto IL_1899;
																																		case 197:
																																			goto IL_18a7;
																																		case 248:
																																			goto IL_18ba;
																																		case 142:
																																			goto IL_18c8;
																																		case 25:
																																		case 167:
																																			goto IL_18d6;
																																		case 139:
																																			goto IL_191d;
																																		case 250:
																																			goto IL_192b;
																																		case 36:
																																			goto IL_193e;
																																		case 347:
																																			goto IL_194c;
																																		case 134:
																																		case 155:
																																			goto IL_195a;
																																		case 53:
																																			goto IL_196e;
																																		case 217:
																																			goto IL_19bb;
																																		case 199:
																																			goto IL_19c9;
																																		case 62:
																																			goto IL_19dc;
																																		case 335:
																																			goto IL_19ea;
																																		case 107:
																																		case 317:
																																			goto IL_19f8;
																																		case 71:
																																			goto IL_1a36;
																																		case 121:
																																			goto IL_1a44;
																																		case 159:
																																		case 366:
																																			goto IL_1a54;
																																		case 316:
																																			goto IL_1a6c;
																																		case 128:
																																			goto IL_1a7a;
																																		case 137:
																																			goto IL_1a88;
																																		case 11:
																																		case 26:
																																		case 33:
																																		case 38:
																																		case 41:
																																		case 42:
																																		case 46:
																																		case 66:
																																		case 70:
																																		case 87:
																																		case 88:
																																		case 90:
																																		case 92:
																																		case 94:
																																		case 97:
																																		case 99:
																																		case 102:
																																		case 112:
																																		case 135:
																																		case 140:
																																		case 144:
																																		case 145:
																																		case 150:
																																		case 156:
																																		case 174:
																																		case 185:
																																		case 186:
																																		case 195:
																																		case 200:
																																		case 206:
																																		case 212:
																																		case 219:
																																		case 233:
																																		case 236:
																																		case 238:
																																		case 262:
																																		case 266:
																																		case 268:
																																		case 269:
																																		case 274:
																																		case 287:
																																		case 292:
																																		case 298:
																																		case 321:
																																		case 337:
																																		case 352:
																																		case 357:
																																		case 372:
																																			goto end_IL_0630;
																																		case 0:
																																		case 5:
																																		case 6:
																																		case 32:
																																		case 51:
																																		case 52:
																																		case 56:
																																		case 65:
																																		case 75:
																																		case 77:
																																		case 95:
																																		case 101:
																																		case 116:
																																		case 136:
																																		case 152:
																																		case 157:
																																		case 161:
																																		case 181:
																																		case 182:
																																		case 184:
																																		case 187:
																																		case 188:
																																		case 211:
																																		case 226:
																																		case 231:
																																		case 232:
																																		case 235:
																																		case 245:
																																		case 251:
																																		case 257:
																																		case 258:
																																		case 279:
																																		case 282:
																																		case 288:
																																		case 291:
																																		case 299:
																																		case 303:
																																		case 304:
																																		case 307:
																																		case 308:
																																		case 313:
																																		case 315:
																																		case 330:
																																		case 334:
																																		case 351:
																																		case 363:
																																		case 368:
																																		case 375:
																																			goto end_IL_06d9;
																																		case 37:
																																			goto end_IL_1aab;
																																		case 110:
																																			goto end_IL_1abe;
																																		case 239:
																																			goto end_IL_1ac8;
																																		case 130:
																																			goto end_IL_1ad3;
																																		case 69:
																																			goto end_IL_1ae3;
																																		case 249:
																																		case 294:
																																			goto end_IL_1af3;
																																		case 214:
																																			goto end_IL_1b03;
																																		case 55:
																																			goto end_IL_1b1c;
																																		case 48:
																																			goto end_IL_1b2c;
																																		case 153:
																																			goto end_IL_1b3c;
																																		case 154:
																																			goto end_IL_1b4c;
																																		case 166:
																																		case 247:
																																			return;
																																		}
																																		continue;
																																	}
																																	if (42 > b)
																																	{
																																		goto end_IL_0630;
																																	}
																																	goto IL_1674;
																																	IL_1674:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	goto IL_16b4;
																																	IL_16c8:
																																	num6--;
																																	num = 77;
																																	goto end_IL_06d9;
																																	IL_16b4:
																																	array[num6 - 2] = 3;
																																	goto IL_16c8;
																																	continue;
																																	end_IL_061d:
																																	break;
																																}
																																goto IL_13b8;
																																continue;
																																end_IL_0630:
																																break;
																																IL_0630:;
																															}
																															break;
																														}
																														goto IL_08bc;
																														IL_0b65:
																														ptr2 += 8;
																														goto end_IL_06d9;
																														IL_08bc:
																														if (41 > b)
																														{
																															break;
																														}
																														goto IL_08ca;
																														IL_08ca:
																														array[num6 - 2] = 0;
																														goto IL_08de;
																														IL_08de:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((AudioClip)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																														goto IL_092b;
																														IL_092b:
																														num6--;
																														goto IL_0b65;
																													}
																													break;
																												}
																												goto IL_16e4;
																												IL_172f:
																												ptr2 += 8;
																												goto end_IL_06d9;
																												IL_16e4:
																												((delegate*<Recorder, AudioClip, void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (AudioClip)array2[num6 - 1]);
																												goto IL_1721;
																												IL_1721:
																												num6 -= 2;
																												goto IL_172f;
																											}
																											break;
																										}
																										goto IL_1742;
																										IL_17ad:
																										if (45 > b)
																										{
																										}
																										break;
																										IL_1742:
																										if (44 >= b)
																										{
																											goto IL_174d;
																										}
																										goto IL_179f;
																										IL_174d:
																										if (44 > b)
																										{
																											break;
																										}
																										goto IL_175b;
																										IL_175b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_1786;
																										IL_1786:
																										array[num6 - 1] = 0;
																										goto end_IL_06d9;
																										IL_179f:
																										if (45 < b)
																										{
																											break;
																										}
																										goto IL_17ad;
																									}
																									break;
																								}
																								goto IL_17c0;
																								IL_1a88:
																								ptr2 += 8;
																								goto end_IL_06d9;
																								IL_17c0:
																								if (40 > b)
																								{
																									goto IL_17ce;
																								}
																								goto IL_1a54;
																								IL_17ce:
																								if (37 >= b)
																								{
																									goto IL_17dc;
																								}
																								goto IL_193e;
																								IL_17dc:
																								if (37 <= b)
																								{
																									goto IL_17e7;
																								}
																								goto IL_184e;
																								IL_17e7:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_1827;
																								IL_1827:
																								array[num6 - 2] = 3;
																								goto IL_183b;
																								IL_183b:
																								num6--;
																								goto end_IL_06d9;
																								IL_184e:
																								if (35 >= b)
																								{
																									goto IL_1859;
																								}
																								goto IL_18ba;
																								IL_1859:
																								if (35 > b)
																								{
																									break;
																								}
																								goto IL_1867;
																								IL_1867:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_188b;
																								IL_188b:
																								array[num6] = 0;
																								goto IL_1899;
																								IL_1899:
																								num6++;
																								goto IL_18a7;
																								IL_18a7:
																								ptr2 += 8;
																								goto end_IL_06d9;
																								IL_18ba:
																								if (36 < b)
																								{
																									break;
																								}
																								goto IL_18c8;
																								IL_18c8:
																								if (36 > b)
																								{
																									break;
																								}
																								goto IL_18d6;
																								IL_18d6:
																								((delegate*<Recorder, bool, void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																								num = 139;
																								goto IL_191d;
																								IL_191d:
																								num6 -= 2;
																								goto IL_192b;
																								IL_192b:
																								ptr2 += 8;
																								goto end_IL_06d9;
																								IL_193e:
																								if (38 >= b)
																								{
																									goto IL_194c;
																								}
																								goto IL_19dc;
																								IL_194c:
																								if (38 > b)
																								{
																									break;
																								}
																								goto IL_195a;
																								IL_195a:
																								array[num6 - 2] = 0;
																								goto IL_196e;
																								IL_196e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																								goto IL_19bb;
																								IL_19bb:
																								num6--;
																								goto IL_19c9;
																								IL_19c9:
																								ptr2 += 8;
																								goto end_IL_06d9;
																								IL_19dc:
																								if (39 < b)
																								{
																									break;
																								}
																								goto IL_19ea;
																								IL_19ea:
																								if (39 > b)
																								{
																									break;
																								}
																								goto IL_19f8;
																								IL_19f8:
																								((delegate*<Recorder, bool, void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																								goto IL_1a36;
																								IL_1a36:
																								num6 -= 2;
																								goto IL_1a44;
																								IL_1a44:
																								ptr2 += 8;
																								goto end_IL_06d9;
																								IL_1a54:
																								array2[num6] = array5[*(int*)(ptr2 + num3)];
																								goto IL_1a6c;
																								IL_1a6c:
																								array[num6] = 5;
																								goto IL_1a7a;
																								IL_1a7a:
																								num6++;
																								goto IL_1a88;
																							}
																							break;
																						}
																						goto IL_06e4;
																						IL_1600:
																						array[num6 - 1] = 3;
																						goto IL_1614;
																						IL_06e4:
																						if (34 <= b)
																						{
																							goto IL_06ef;
																						}
																						goto IL_0748;
																						IL_06ef:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_072f;
																						IL_072f:
																						array[num6 - 2] = 3;
																						goto IL_093e;
																						IL_093e:
																						num6--;
																						goto end_IL_06d9;
																						IL_0748:
																						if (28 >= b)
																						{
																							goto IL_0756;
																						}
																						goto IL_0821;
																						IL_0756:
																						if (28 <= b)
																						{
																							goto IL_0761;
																						}
																						goto IL_0784;
																						IL_0761:
																						array2[num6] = ((delegate*<Recorder>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])();
																						goto IL_0b95;
																						IL_0b95:
																						array[num6] = 5;
																						goto IL_0ba3;
																						IL_0ba3:
																						num6++;
																						goto IL_0bb1;
																						IL_0bb1:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0784:
																						if (25 >= b)
																						{
																							goto IL_078f;
																						}
																						goto IL_080e;
																						IL_078f:
																						if (25 > b)
																						{
																							goto IL_079d;
																						}
																						goto IL_0b78;
																						IL_079d:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_07ab;
																						IL_07ab:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_07b9;
																						IL_07b9:
																						array[num6 - 1] = 0;
																						goto IL_07cd;
																						IL_07cd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0834;
																						IL_0834:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0b78:
																						array2[num6] = null;
																						goto IL_0b82;
																						IL_0b82:
																						array[num6] = 5;
																						goto IL_0c4f;
																						IL_0c4f:
																						num6++;
																						goto end_IL_06d9;
																						IL_080e:
																						if (26 >= b)
																						{
																							goto IL_0951;
																						}
																						goto IL_09ea;
																						IL_0951:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_095f;
																						IL_095f:
																						array[num6 - 2] = 0;
																						num = 267;
																						goto IL_097c;
																						IL_097c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																						goto IL_09c9;
																						IL_09c9:
																						num6--;
																						goto IL_09d7;
																						IL_09d7:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_09ea:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_09f8;
																						IL_09f8:
																						if (27 > b)
																						{
																							break;
																						}
																						num = 278;
																						goto IL_0a0f;
																						IL_1614:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1653;
																						IL_0a0f:
																						array[num6 - 1] = 3;
																						goto IL_0a23;
																						IL_0a23:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0a62;
																						IL_0a62:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0821:
																						if (31 >= b)
																						{
																							goto IL_0a75;
																						}
																						goto IL_159a;
																						IL_0a75:
																						if (31 <= b)
																						{
																							goto IL_0a80;
																						}
																						goto IL_0ad7;
																						IL_0a80:
																						((delegate*<Recorder, Recorder.InputSourceType, void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], *(Recorder.InputSourceType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0abe;
																						IL_0abe:
																						num6 -= 2;
																						num = 328;
																						goto IL_0b52;
																						IL_0b52:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0ad7:
																						if (29 >= b)
																						{
																							goto IL_0ae5;
																						}
																						goto IL_0bc4;
																						IL_0ae5:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_0af3;
																						IL_0af3:
																						((delegate*<Recorder, bool, void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((Recorder)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																						goto IL_0b31;
																						IL_0b31:
																						num6 -= 2;
																						goto IL_0b3f;
																						IL_0b3f:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0bc4:
																						if (30 < b)
																						{
																							break;
																						}
																						goto IL_0bd2;
																						IL_0bd2:
																						if (30 > b)
																						{
																							break;
																						}
																						num = 89;
																						goto IL_0be9;
																						IL_1653:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_0be9:
																						array[num6 - 1] = 3;
																						goto IL_0bfd;
																						IL_0bfd:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0c3c;
																						IL_0c3c:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_159a:
																						if (32 >= b)
																						{
																							goto IL_15a5;
																						}
																						goto IL_15e4;
																						IL_15a5:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_15b3;
																						IL_15b3:
																						((delegate*<void>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])();
																						num = 246;
																						goto IL_15d1;
																						IL_15d1:
																						ptr2 += 8;
																						goto end_IL_06d9;
																						IL_15e4:
																						if (33 < b)
																						{
																							break;
																						}
																						goto IL_15f2;
																						IL_15f2:
																						if (33 > b)
																						{
																							break;
																						}
																						goto IL_1600;
																					}
																					break;
																				}
																				goto IL_0847;
																				IL_145c:
																				ptr2 += 16;
																				goto end_IL_06d9;
																				IL_0847:
																				if (23 <= b)
																				{
																					goto IL_0855;
																				}
																				goto IL_0c62;
																				IL_0855:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0895;
																				IL_0895:
																				array[num6 - 2] = 3;
																				goto IL_08a9;
																				IL_08a9:
																				num6--;
																				goto end_IL_06d9;
																				IL_0c62:
																				if (11 >= b)
																				{
																					goto IL_0c70;
																				}
																				goto IL_10da;
																				IL_0c70:
																				if (11 <= b)
																				{
																					goto IL_0c7b;
																				}
																				goto IL_0cce;
																				IL_0c7b:
																				array[num6] = 0;
																				goto IL_0c89;
																				IL_0c89:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])();
																				goto IL_0cad;
																				IL_0cad:
																				num6++;
																				goto IL_0cbb;
																				IL_0cbb:
																				ptr2 += 8;
																				goto end_IL_06d9;
																				IL_0cce:
																				if (5 >= b)
																				{
																					goto IL_0cdc;
																				}
																				goto IL_0ee3;
																				IL_0cdc:
																				if (5 <= b)
																				{
																					goto IL_0ce7;
																				}
																				goto IL_0d4e;
																				IL_0ce7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0d27;
																				IL_0d27:
																				array[num6 - 2] = 0;
																				goto IL_0d3b;
																				IL_0d3b:
																				num6--;
																				goto end_IL_06d9;
																				IL_0d4e:
																				if (2 >= b)
																				{
																					goto IL_0d5c;
																				}
																				goto IL_0e24;
																				IL_0d5c:
																				if (2 <= b)
																				{
																					goto IL_0d67;
																				}
																				goto IL_0dce;
																				IL_0d67:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0da7;
																				IL_0da7:
																				array[num6 - 2] = 0;
																				goto IL_0dbb;
																				IL_0dbb:
																				num6--;
																				goto end_IL_06d9;
																				IL_0dce:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0ddc;
																				IL_0ddc:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0dea;
																				IL_0dea:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0e03;
																				IL_0e03:
																				array[num6] = 0;
																				goto IL_0e11;
																				IL_0e11:
																				num6++;
																				goto IL_1587;
																				IL_1587:
																				ptr2 += 8;
																				goto end_IL_06d9;
																				IL_0e24:
																				if (3 >= b)
																				{
																					goto IL_0e2f;
																				}
																				goto IL_0e6b;
																				IL_0e2f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0e3d;
																				IL_0e3d:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_14f1;
																				IL_14f1:
																				ptr2 += 8;
																				goto IL_14ff;
																				IL_14ff:
																				num6--;
																				goto end_IL_06d9;
																				IL_0e6b:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0e79;
																				IL_0e79:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0e87;
																				IL_0e87:
																				array[num6] = 0;
																				goto IL_0e95;
																				IL_0e95:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0eb8;
																				IL_0eb8:
																				array2[num6] = null;
																				goto IL_0ec2;
																				IL_0ec2:
																				num6++;
																				goto IL_0ed0;
																				IL_0ed0:
																				ptr2 += 8;
																				goto end_IL_06d9;
																				IL_0ee3:
																				if (8 < b)
																				{
																					goto IL_0ef1;
																				}
																				num = 162;
																				goto IL_0fad;
																				IL_0ef1:
																				if (9 >= b)
																				{
																					goto IL_0efc;
																				}
																				goto IL_0f7a;
																				IL_0efc:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0f0a;
																				IL_0f0a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0f4a;
																				IL_0f4a:
																				array[num6 - 2] = 0;
																				goto IL_0f5e;
																				IL_0f5e:
																				num6--;
																				num = 152;
																				goto end_IL_06d9;
																				IL_0f7a:
																				if (10 < b)
																				{
																					break;
																				}
																				num = 13;
																				goto IL_0f91;
																				IL_147d:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_148b;
																				IL_0f91:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_1512;
																				IL_1512:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_1574;
																				IL_1574:
																				num6 -= 2;
																				goto end_IL_06d9;
																				IL_146f:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_147d;
																				IL_0fad:
																				if (8 <= b)
																				{
																					goto IL_0fb8;
																				}
																				goto IL_0fcb;
																				IL_0fb8:
																				num6--;
																				goto end_IL_06d9;
																				IL_0fcb:
																				if (6 < b)
																				{
																					goto IL_0fd9;
																				}
																				num = 359;
																				goto IL_1065;
																				IL_0fd9:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0fe7;
																				IL_0fe7:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0ff5;
																				IL_0ff5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1035;
																				IL_1035:
																				array[num6 - 2] = 0;
																				goto IL_1049;
																				IL_1049:
																				num6--;
																				goto end_IL_06d9;
																				IL_148b:
																				array[num6 - 1] = 3;
																				goto IL_149f;
																				IL_1065:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_1073;
																				IL_1073:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_10b3;
																				IL_10b3:
																				array[num6 - 2] = 0;
																				goto IL_10c7;
																				IL_10c7:
																				num6--;
																				goto end_IL_06d9;
																				IL_10da:
																				if (17 >= b)
																				{
																					goto IL_10e8;
																				}
																				goto IL_12d6;
																				IL_10e8:
																				if (17 <= b)
																				{
																					goto IL_10f3;
																				}
																				goto IL_110f;
																				IL_10f3:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_06d9;
																				IL_110f:
																				if (14 >= b)
																				{
																					goto IL_111d;
																				}
																				goto IL_11cb;
																				IL_111d:
																				if (14 <= b)
																				{
																					goto IL_1128;
																				}
																				goto IL_1140;
																				IL_1128:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_06d9;
																				IL_1140:
																				if (12 >= b)
																				{
																					goto IL_114b;
																				}
																				goto IL_115e;
																				IL_114b:
																				if (12 > b)
																				{
																					break;
																				}
																				goto end_IL_06d9;
																				IL_115e:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_116c;
																				IL_116c:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_117a;
																				IL_117a:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_1193;
																				IL_1193:
																				array[num6] = 1;
																				goto IL_11a1;
																				IL_11a1:
																				num6++;
																				goto IL_11af;
																				IL_11af:
																				ptr2 += 16;
																				num = 307;
																				goto end_IL_06d9;
																				IL_11cb:
																				if (15 >= b)
																				{
																					goto IL_11d6;
																				}
																				goto IL_124c;
																				IL_11d6:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_11e4;
																				IL_11e4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_1225;
																				IL_1225:
																				array[num6 - 2] = 0;
																				goto IL_1239;
																				IL_1239:
																				num6--;
																				goto end_IL_06d9;
																				IL_124c:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_125a;
																				IL_125a:
																				if (16 > b)
																				{
																					break;
																				}
																				num = 295;
																				goto IL_1271;
																				IL_149f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_14de;
																				IL_1271:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_12c3;
																				IL_12c3:
																				num6--;
																				goto end_IL_06d9;
																				IL_12d6:
																				if (20 >= b)
																				{
																					goto IL_12e4;
																				}
																				goto IL_140e;
																				IL_12e4:
																				if (20 <= b)
																				{
																					goto IL_12ef;
																				}
																				goto IL_131b;
																				IL_12ef:
																				global::_003CModule_003E.recorder_2 = (Recorder)array2[num6 - 1];
																				goto IL_1308;
																				IL_1308:
																				num6--;
																				goto end_IL_06d9;
																				IL_131b:
																				if (18 < b)
																				{
																					goto IL_1326;
																				}
																				num = 164;
																				goto IL_13aa;
																				IL_1326:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_1334;
																				IL_1334:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_1342;
																				IL_1342:
																				array[num6 - 1] = 5;
																				goto IL_1356;
																				IL_1356:
																				array2[num6 - 1] = ((delegate*<GorillaTagger, Recorder>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																				goto IL_138e;
																				IL_138e:
																				ptr2 += 8;
																				goto end_IL_06d9;
																				IL_14de:
																				ptr2 += 8;
																				goto end_IL_06d9;
																				IL_13aa:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_13b8;
																				IL_13b8:
																				array[num6] = 5;
																				goto IL_13c6;
																				IL_13c6:
																				array2[num6] = ((delegate*<GorillaTagger>)RSAEncryptionPaddingModeSoapCheckEnabled[*(int*)(ptr2 + num3)])();
																				goto IL_13e4;
																				IL_13e4:
																				num6++;
																				goto IL_13f2;
																				IL_13f2:
																				ptr2 += 8;
																				num = 51;
																				goto end_IL_06d9;
																				IL_140e:
																				if (21 >= b)
																				{
																					goto IL_1419;
																				}
																				goto IL_146f;
																				IL_1419:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_1427;
																				IL_1427:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_1440;
																				IL_1440:
																				array[num6] = 3;
																				goto IL_144e;
																				IL_144e:
																				num6++;
																				goto IL_145c;
																			}
																			break;
																			IL_06a0:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_06d9;
																	continue;
																	end_IL_06b0:
																	break;
																}
																continue;
																end_IL_06c0:
																break;
															}
															continue;
															end_IL_06d9:
															break;
														}
														continue;
														end_IL_1aab:
														break;
													}
													continue;
													end_IL_1abe:
													break;
												}
												continue;
												end_IL_1ac8:
												break;
											}
											continue;
											end_IL_1ad3:
											break;
										}
										continue;
										end_IL_1ae3:
										break;
									}
									continue;
									end_IL_1af3:
									break;
								}
								continue;
								end_IL_1b03:
								break;
							}
							continue;
							end_IL_1b1c:
							break;
						}
						continue;
						end_IL_1b2c:
						break;
					}
					continue;
					end_IL_1b3c:
					break;
				}
				continue;
				end_IL_1b4c:
				break;
			}
		}
	}

	public unsafe static void smethod_9()
	{
		int num = 23;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 32;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref schedulerLeaseTime.CltImportAsArm);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_043c:
															if (b >= 1)
															{
																while (b <= 26)
																{
																	while (true)
																	{
																		IL_041c:
																		if (13 < b)
																		{
																			while (true)
																			{
																				IL_040c:
																				if (20 < b)
																				{
																					while (true)
																					{
																						IL_03fc:
																						if (23 >= b)
																						{
																							while (true)
																							{
																								IL_03ec:
																								if (23 > b)
																								{
																									while (true)
																									{
																										IL_03df:
																										if (21 < b)
																										{
																											while (22 >= b)
																											{
																												while (22 <= b)
																												{
																													num = 227;
																													while (true)
																													{
																														if (num != 227)
																														{
																															if (num != 1208)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 207:
																																goto IL_03bc;
																															case 84:
																																goto IL_03cf;
																															case 124:
																																goto IL_03df;
																															case 116:
																																goto IL_03ec;
																															case 178:
																																goto IL_03fc;
																															case 220:
																																goto IL_040c;
																															case 49:
																																goto IL_041c;
																															case 50:
																																goto IL_042c;
																															case 72:
																																goto IL_043c;
																															case 149:
																																goto end_IL_043c;
																															case 94:
																															case 99:
																																goto end_IL_044c;
																															case 138:
																																goto IL_0467;
																															case 67:
																															case 122:
																																goto IL_0475;
																															case 6:
																																goto IL_0493;
																															case 105:
																																goto IL_04a1;
																															case 2:
																																goto IL_04af;
																															case 142:
																																goto IL_04c2;
																															case 128:
																																goto IL_04d0;
																															case 129:
																																goto IL_04db;
																															case 39:
																																goto IL_04ee;
																															case 1:
																																goto IL_04f9;
																															case 59:
																															case 74:
																																goto IL_0504;
																															case 80:
																																goto IL_0546;
																															case 157:
																																goto IL_0559;
																															case 34:
																																goto IL_056d;
																															case 165:
																																goto IL_0580;
																															case 43:
																																goto IL_058b;
																															case 40:
																																goto IL_0599;
																															case 69:
																															case 113:
																																goto IL_05a7;
																															case 73:
																																goto IL_05c3;
																															case 181:
																																goto IL_05d6;
																															case 127:
																																goto IL_05e4;
																															case 31:
																															case 107:
																																goto IL_05ef;
																															case 177:
																																goto IL_0618;
																															case 110:
																																goto IL_0626;
																															case 41:
																																goto IL_0639;
																															case 51:
																																goto IL_0647;
																															case 89:
																																goto IL_0655;
																															case 87:
																															case 98:
																																goto IL_0663;
																															case 47:
																																goto IL_06a3;
																															case 139:
																																goto IL_06b7;
																															case 90:
																																goto IL_06ca;
																															case 42:
																																goto IL_06d8;
																															case 20:
																															case 185:
																																goto IL_06eb;
																															case 71:
																																goto IL_072b;
																															case 63:
																																goto IL_0748;
																															case 4:
																															case 187:
																																goto IL_075b;
																															case 190:
																																goto IL_0773;
																															case 68:
																																goto IL_0781;
																															case 184:
																																goto IL_078f;
																															case 25:
																															case 148:
																																goto IL_079d;
																															case 24:
																																goto end_IL_03a9;
																															case 192:
																																goto IL_0812;
																															case 26:
																															case 93:
																																goto IL_081d;
																															case 29:
																																goto IL_0831;
																															case 36:
																																goto IL_0870;
																															case 182:
																																goto IL_0883;
																															case 46:
																																goto IL_0891;
																															case 135:
																															case 183:
																																goto IL_089c;
																															case 27:
																																goto IL_08ba;
																															case 17:
																																goto IL_08c8;
																															case 160:
																																goto IL_08db;
																															case 96:
																																goto IL_08e6;
																															case 62:
																															case 166:
																																goto IL_08fd;
																															case 191:
																																goto IL_0943;
																															case 133:
																																goto IL_0951;
																															case 83:
																															case 106:
																																goto IL_0968;
																															case 35:
																																goto IL_09ba;
																															case 195:
																																goto IL_09cd;
																															case 130:
																																goto IL_09d8;
																															case 111:
																															case 175:
																																goto IL_09e6;
																															case 137:
																																goto IL_09ff;
																															case 123:
																																goto IL_0a0d;
																															case 21:
																																goto IL_0a1b;
																															case 9:
																																goto IL_0a37;
																															case 196:
																																goto IL_0a45;
																															case 11:
																															case 197:
																																goto IL_0a58;
																															case 78:
																																goto IL_0a6f;
																															case 12:
																																goto IL_0a92;
																															case 61:
																																goto IL_0a9c;
																															case 170:
																																goto IL_0aaa;
																															case 200:
																																goto IL_0abd;
																															case 203:
																																goto IL_0acd;
																															case 33:
																															case 155:
																																goto IL_0adb;
																															case 204:
																																goto IL_0af9;
																															case 141:
																															case 198:
																																goto IL_0b07;
																															case 205:
																																goto IL_0b47;
																															case 152:
																																goto IL_0b5b;
																															case 171:
																															case 210:
																																goto IL_0b6e;
																															case 37:
																																goto IL_0bae;
																															case 52:
																																goto IL_0bc2;
																															case 211:
																																goto IL_0bd5;
																															case 199:
																																goto IL_0bec;
																															case 132:
																																goto IL_0bfa;
																															case 213:
																																goto IL_0c0d;
																															case 214:
																																goto IL_0c20;
																															case 151:
																																goto IL_0c2e;
																															case 95:
																															case 167:
																																goto IL_0c3c;
																															case 112:
																																goto IL_0c65;
																															case 77:
																																goto IL_0c73;
																															case 215:
																																goto IL_0c86;
																															case 131:
																																goto IL_0c9a;
																															case 216:
																																goto IL_0cad;
																															case 169:
																																goto IL_0cbb;
																															case 5:
																															case 193:
																																goto IL_0cc9;
																															case 194:
																																goto IL_0ce2;
																															case 10:
																																goto IL_0cf0;
																															case 202:
																																goto IL_0cfe;
																															case 121:
																															case 218:
																																goto IL_0d11;
																															case 101:
																																goto IL_0d51;
																															case 56:
																																goto IL_0d65;
																															case 156:
																																goto IL_0d78;
																															case 108:
																																goto IL_0da1;
																															case 45:
																																goto IL_0db8;
																															case 8:
																															case 91:
																																goto IL_0dcb;
																															case 14:
																																goto IL_0ddf;
																															case 176:
																																goto IL_0e27;
																															case 57:
																																goto IL_0e43;
																															case 168:
																																goto IL_0e51;
																															case 15:
																															case 109:
																																goto IL_0e5c;
																															case 19:
																																goto IL_0e78;
																															case 64:
																																goto IL_0e86;
																															case 146:
																															case 158:
																																goto IL_0e91;
																															case 100:
																																goto IL_0ed1;
																															case 28:
																																goto IL_0ee5;
																															case 55:
																																goto IL_0ef5;
																															case 104:
																																goto IL_0f00;
																															case 3:
																															case 7:
																															case 38:
																															case 44:
																															case 53:
																															case 54:
																															case 58:
																															case 70:
																															case 79:
																															case 85:
																															case 92:
																															case 103:
																															case 117:
																															case 119:
																															case 120:
																															case 136:
																															case 140:
																															case 145:
																															case 147:
																															case 153:
																															case 154:
																															case 162:
																															case 163:
																															case 164:
																															case 172:
																															case 179:
																															case 206:
																															case 209:
																															case 212:
																																goto end_IL_03bc;
																															case 0:
																															case 13:
																															case 16:
																															case 18:
																															case 30:
																															case 48:
																															case 60:
																															case 65:
																															case 75:
																															case 81:
																															case 82:
																															case 86:
																															case 88:
																															case 97:
																															case 102:
																															case 114:
																															case 115:
																															case 118:
																															case 125:
																															case 126:
																															case 134:
																															case 144:
																															case 161:
																															case 174:
																															case 186:
																															case 188:
																															case 189:
																															case 208:
																															case 219:
																																goto end_IL_045c;
																															case 173:
																																goto end_IL_0f1e;
																															case 150:
																																goto end_IL_0f31;
																															case 32:
																																goto end_IL_0f3b;
																															case 66:
																															case 76:
																																goto end_IL_0f46;
																															case 201:
																																goto end_IL_0f56;
																															case 143:
																																goto end_IL_0f6f;
																															case 159:
																																goto end_IL_0f7f;
																															case 22:
																																goto end_IL_0f8f;
																															case 23:
																																goto end_IL_0f9f;
																															case 180:
																															case 217:
																																return;
																															}
																															continue;
																														}
																														goto IL_0d78;
																														IL_0da1:
																														num6--;
																														num = 45;
																														goto IL_0db8;
																														IL_0db8:
																														ptr2 += 8;
																														goto end_IL_045c;
																														IL_0d78:
																														((delegate*<List<AudioClip>, void>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])((List<AudioClip>)array2[num6 - 1]);
																														goto IL_0da1;
																														continue;
																														end_IL_03a9:
																														break;
																													}
																													goto IL_07ff;
																													continue;
																													end_IL_03bc:
																													break;
																													IL_03bc:;
																												}
																												break;
																												IL_03cf:;
																											}
																											break;
																										}
																										goto IL_0467;
																										IL_04af:
																										ptr2 += 8;
																										goto end_IL_045c;
																										IL_0467:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_0475;
																										IL_0475:
																										array2[num6] = ((delegate*<List<AudioClip>>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])();
																										goto IL_0493;
																										IL_0493:
																										array[num6] = 5;
																										goto IL_04a1;
																										IL_04a1:
																										num6++;
																										goto IL_04af;
																									}
																									break;
																								}
																								goto IL_0dcb;
																								IL_0e27:
																								ptr2 += 8;
																								num = 48;
																								goto end_IL_045c;
																								IL_0dcb:
																								array[num6 - 1] = 3;
																								goto IL_0ddf;
																								IL_0ddf:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								num = 176;
																								goto IL_0e27;
																							}
																							break;
																						}
																						goto IL_0e43;
																						IL_0f00:
																						if (26 <= b)
																						{
																						}
																						break;
																						IL_0e43:
																						if (25 >= b)
																						{
																							goto IL_0e51;
																						}
																						goto IL_0ef5;
																						IL_0e51:
																						if (25 <= b)
																						{
																							goto IL_0e5c;
																						}
																						goto IL_0e78;
																						IL_0e5c:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_045c;
																						IL_0e78:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_0e86;
																						IL_0e86:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_0e91;
																						IL_0e91:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0ed1;
																						IL_0ed1:
																						array[num6 - 2] = 3;
																						goto IL_0ee5;
																						IL_0ee5:
																						num6--;
																						goto end_IL_045c;
																						IL_0ef5:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0f00;
																					}
																					break;
																				}
																				goto IL_0812;
																				IL_0b6e:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0bae;
																				IL_0812:
																				if (20 <= b)
																				{
																					goto IL_081d;
																				}
																				goto IL_0883;
																				IL_081d:
																				array[num6 - 1] = 0;
																				goto IL_0831;
																				IL_0831:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0870;
																				IL_0870:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_0883:
																				if (16 >= b)
																				{
																					goto IL_0891;
																				}
																				goto IL_09cd;
																				IL_0891:
																				if (16 <= b)
																				{
																					goto IL_089c;
																				}
																				goto IL_08db;
																				IL_089c:
																				array2[num6] = ((delegate*<List<string>>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])();
																				goto IL_08ba;
																				IL_08ba:
																				array[num6] = 5;
																				goto IL_08c8;
																				IL_08c8:
																				num6++;
																				goto IL_0c0d;
																				IL_0c0d:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_08db:
																				if (14 >= b)
																				{
																					goto IL_08e6;
																				}
																				goto IL_0943;
																				IL_08e6:
																				if (14 > b)
																				{
																					break;
																				}
																				num = 166;
																				goto IL_08fd;
																				IL_0bae:
																				array[num6 - 2] = 3;
																				goto IL_0bc2;
																				IL_08fd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_0c86;
																				IL_0c86:
																				array[num6 - 2] = 0;
																				goto IL_0c9a;
																				IL_0c9a:
																				num6--;
																				goto end_IL_045c;
																				IL_0943:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0951;
																				IL_0951:
																				if (15 > b)
																				{
																					break;
																				}
																				num = 106;
																				goto IL_0968;
																				IL_0bc2:
																				num6--;
																				goto end_IL_045c;
																				IL_0968:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_09ba;
																				IL_09ba:
																				num6--;
																				goto end_IL_045c;
																				IL_09cd:
																				if (18 >= b)
																				{
																					goto IL_09d8;
																				}
																				goto IL_0a37;
																				IL_09d8:
																				if (18 <= b)
																				{
																					goto IL_09e6;
																				}
																				goto IL_0c20;
																				IL_09e6:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_09ff;
																				IL_09ff:
																				array[num6] = 3;
																				goto IL_0a0d;
																				IL_0a0d:
																				num6++;
																				goto IL_0a1b;
																				IL_0a1b:
																				ptr2 += 16;
																				num = 144;
																				goto end_IL_045c;
																				IL_0c20:
																				if (17 < b)
																				{
																					break;
																				}
																				goto IL_0c2e;
																				IL_0c2e:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_0c3c;
																				IL_0c3c:
																				((delegate*<List<string>, void>)DateOfBirthSerializationHeaderRecord[*(int*)(ptr2 + num3)])((List<string>)array2[num6 - 1]);
																				goto IL_0c65;
																				IL_0c65:
																				num6--;
																				goto IL_0c73;
																				IL_0c73:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_0a37:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_0a45;
																				IL_0a45:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_0b6e;
																			}
																			break;
																		}
																		goto IL_04c2;
																		IL_0cfe:
																		ptr2 += 16;
																		goto end_IL_045c;
																		IL_04c2:
																		if (13 > b)
																		{
																			goto IL_04d0;
																		}
																		goto IL_075b;
																		IL_04d0:
																		if (6 >= b)
																		{
																			goto IL_04db;
																		}
																		goto IL_04ee;
																		IL_04db:
																		if (6 > b)
																		{
																			goto IL_05d6;
																		}
																		goto IL_0d11;
																		IL_05d6:
																		if (3 >= b)
																		{
																			goto IL_05e4;
																		}
																		goto IL_06ca;
																		IL_05e4:
																		if (3 <= b)
																		{
																			goto IL_05ef;
																		}
																		goto IL_0639;
																		IL_05ef:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0618;
																		IL_0618:
																		ptr2 += 8;
																		goto IL_0626;
																		IL_0626:
																		num6--;
																		goto end_IL_045c;
																		IL_0639:
																		if (1 < b)
																		{
																			goto IL_0647;
																		}
																		goto IL_0acd;
																		IL_0647:
																		if (2 < b)
																		{
																			break;
																		}
																		goto IL_0655;
																		IL_0655:
																		if (2 > b)
																		{
																			break;
																		}
																		goto IL_0663;
																		IL_0663:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_06a3;
																		IL_06a3:
																		array[num6 - 2] = 0;
																		goto IL_06b7;
																		IL_06b7:
																		num6--;
																		goto end_IL_045c;
																		IL_0acd:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0adb;
																		IL_0adb:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0bd5;
																		IL_0bd5:
																		array[num6] = 0;
																		num = 199;
																		goto IL_0bec;
																		IL_0bec:
																		num6++;
																		goto IL_0bfa;
																		IL_0bfa:
																		ptr2 += 8;
																		goto end_IL_045c;
																		IL_06ca:
																		if (4 >= b)
																		{
																			goto IL_06d8;
																		}
																		goto IL_0abd;
																		IL_06d8:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_0a58;
																		IL_0a58:
																		array[num6] = 0;
																		num = 78;
																		goto IL_0a6f;
																		IL_0a6f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0a92;
																		IL_0a92:
																		array2[num6] = null;
																		goto IL_0a9c;
																		IL_0a9c:
																		num6++;
																		goto IL_0aaa;
																		IL_0aaa:
																		ptr2 += 8;
																		goto end_IL_045c;
																		IL_0abd:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_0af9;
																		IL_0af9:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_0b07;
																		IL_0b07:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0b47;
																		IL_0b47:
																		array[num6 - 2] = 0;
																		goto IL_0b5b;
																		IL_0b5b:
																		num6--;
																		goto end_IL_045c;
																		IL_0d11:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0d51;
																		IL_0d51:
																		array[num6 - 2] = 0;
																		goto IL_0d65;
																		IL_0d65:
																		num6--;
																		goto end_IL_045c;
																		IL_04ee:
																		if (9 >= b)
																		{
																			goto IL_04f9;
																		}
																		goto IL_0546;
																		IL_04f9:
																		if (9 <= b)
																		{
																			goto IL_0504;
																		}
																		goto IL_0580;
																		IL_0504:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0559;
																		IL_0559:
																		array[num6 - 2] = 0;
																		goto IL_056d;
																		IL_056d:
																		num6--;
																		goto end_IL_045c;
																		IL_0580:
																		if (7 < b)
																		{
																			goto IL_058b;
																		}
																		num = 73;
																		goto IL_05c3;
																		IL_058b:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0599;
																		IL_0599:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_05a7;
																		IL_05a7:
																		num6--;
																		goto end_IL_045c;
																		IL_075b:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_045c;
																		IL_05c3:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_06eb;
																		IL_06eb:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_072b;
																		IL_072b:
																		array[num6 - 2] = 0;
																		num = 63;
																		goto IL_0748;
																		IL_0748:
																		num6--;
																		goto end_IL_045c;
																		IL_0546:
																		if (11 >= b)
																		{
																			goto IL_0773;
																		}
																		goto IL_0cad;
																		IL_0773:
																		if (11 <= b)
																		{
																			goto end_IL_045c;
																		}
																		goto IL_0781;
																		IL_0781:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_078f;
																		IL_078f:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_079d;
																		IL_079d:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_07ff;
																		IL_07ff:
																		num6 -= 2;
																		goto end_IL_045c;
																		IL_0cad:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_0cbb;
																		IL_0cbb:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0cc9;
																		IL_0cc9:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0ce2;
																		IL_0ce2:
																		array[num6] = 1;
																		goto IL_0cf0;
																		IL_0cf0:
																		num6++;
																		goto IL_0cfe;
																	}
																	break;
																	IL_042c:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_045c;
															continue;
															end_IL_043c:
															break;
														}
														continue;
														end_IL_044c:
														break;
													}
													continue;
													end_IL_045c:
													break;
												}
												continue;
												end_IL_0f1e:
												break;
											}
											continue;
											end_IL_0f31:
											break;
										}
										continue;
										end_IL_0f3b:
										break;
									}
									continue;
									end_IL_0f46:
									break;
								}
								continue;
								end_IL_0f56:
								break;
							}
							continue;
							end_IL_0f6f:
							break;
						}
						continue;
						end_IL_0f7f:
						break;
					}
					continue;
					end_IL_0f8f:
					break;
				}
				continue;
				end_IL_0f9f:
				break;
			}
		}
	}

	unsafe static Class11()
	{
		int num = 39;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 38;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					num = 82;
					while (true)
					{
						int num3 = num2 * 4;
						while (true)
						{
							byte[] array = new byte[1];
							while (true)
							{
								object[] array2 = new object[1];
								while (true)
								{
									long[] array3 = new long[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReferenceIdentitycArgs.getIsVirtualANSICodePage);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_03ec:
															if (b >= 1)
															{
																while (b <= 23)
																{
																	while (true)
																	{
																		IL_03cc:
																		if (12 >= b)
																		{
																			while (true)
																			{
																				IL_03bc:
																				if (12 > b)
																				{
																					while (true)
																					{
																						IL_03ac:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_039f:
																								if (9 < b)
																								{
																									while (true)
																									{
																										IL_038f:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_037c:
																												if (10 > b)
																												{
																													num = 211;
																													while (num != 211)
																													{
																														if (num != 1192)
																														{
																															goto IL_0492;
																														}
																														switch (num)
																														{
																														case 123:
																															goto IL_037c;
																														case 194:
																															goto IL_038f;
																														case 187:
																														case 192:
																															goto IL_039f;
																														case 6:
																														case 100:
																															goto IL_03ac;
																														case 144:
																															goto IL_03bc;
																														case 88:
																															goto IL_03cc;
																														case 202:
																															goto IL_03dc;
																														case 66:
																															goto IL_03ec;
																														case 89:
																															goto end_IL_03ec;
																														case 23:
																														case 190:
																															goto end_IL_03fc;
																														case 51:
																															goto IL_0417;
																														case 122:
																															goto IL_0425;
																														case 94:
																															goto IL_0433;
																														case 30:
																														case 126:
																															goto IL_0446;
																														case 166:
																															goto IL_045b;
																														case 52:
																														case 167:
																															goto IL_046e;
																														case 7:
																														case 44:
																															goto IL_047c;
																														case 86:
																															goto IL_0487;
																														case 18:
																														case 58:
																															goto IL_0492;
																														case 108:
																															goto IL_04a9;
																														case 41:
																															goto IL_04bc;
																														case 28:
																															goto IL_04e1;
																														case 21:
																														case 76:
																															goto IL_04ef;
																														case 141:
																															goto IL_04ff;
																														case 110:
																														case 128:
																															goto IL_050d;
																														case 111:
																															goto IL_0517;
																														case 43:
																															goto IL_0525;
																														case 97:
																														case 170:
																															goto IL_0538;
																														case 22:
																															goto IL_054d;
																														case 172:
																															goto IL_0560;
																														case 19:
																														case 20:
																															goto IL_056e;
																														case 118:
																															goto IL_0582;
																														case 115:
																														case 175:
																															goto IL_059e;
																														case 155:
																															goto IL_05b8;
																														case 109:
																														case 188:
																															goto IL_05cb;
																														case 85:
																															goto IL_05d9;
																														case 1:
																														case 47:
																															goto IL_05e4;
																														case 107:
																															goto IL_05fd;
																														case 93:
																															goto IL_0610;
																														case 12:
																															goto IL_061b;
																														case 56:
																														case 61:
																															goto IL_0629;
																														case 146:
																															goto IL_063e;
																														case 143:
																															goto IL_0651;
																														case 112:
																															goto IL_0668;
																														case 60:
																														case 176:
																															goto IL_0676;
																														case 80:
																															goto IL_0692;
																														case 157:
																															goto IL_069d;
																														case 33:
																														case 50:
																															goto IL_06a8;
																														case 139:
																															goto IL_06c9;
																														case 16:
																															goto IL_06d7;
																														case 5:
																														case 178:
																															goto IL_06e5;
																														case 37:
																															goto IL_06fe;
																														case 191:
																															goto IL_0711;
																														case 116:
																															goto IL_071f;
																														case 92:
																														case 165:
																															goto IL_072d;
																														case 148:
																															goto IL_0741;
																														case 193:
																															goto IL_0754;
																														case 0:
																															goto IL_0772;
																														case 55:
																															goto IL_0780;
																														case 127:
																														case 196:
																															goto IL_0793;
																														case 74:
																														case 197:
																															goto IL_07af;
																														case 87:
																															goto IL_07bd;
																														case 57:
																														case 198:
																															goto IL_07d0;
																														case 78:
																															goto IL_07e5;
																														case 200:
																															goto IL_07f8;
																														case 199:
																															goto IL_0816;
																														case 96:
																															goto IL_0824;
																														case 48:
																														case 201:
																															goto IL_0837;
																														case 150:
																															goto IL_0850;
																														case 45:
																															goto IL_085e;
																														case 79:
																															goto IL_086c;
																														case 10:
																														case 204:
																															goto IL_087f;
																														case 32:
																															goto IL_0894;
																														case 171:
																															goto IL_08a7;
																														case 24:
																															goto IL_08b5;
																														case 106:
																														case 114:
																															goto IL_08c3;
																														case 153:
																															goto IL_08d8;
																														case 95:
																															goto IL_08eb;
																														case 140:
																														case 168:
																															goto IL_08f6;
																														case 102:
																															goto IL_090b;
																														case 68:
																															goto IL_091e;
																														case 138:
																															goto IL_092c;
																														case 9:
																														case 189:
																															goto IL_0937;
																														case 158:
																															goto IL_094c;
																														case 142:
																															goto IL_095f;
																														case 145:
																															goto IL_096a;
																														case 77:
																															goto IL_097d;
																														case 156:
																															goto IL_098b;
																														case 27:
																														case 164:
																															goto IL_0999;
																														case 203:
																															goto IL_09ae;
																														case 53:
																															goto IL_09c1;
																														case 84:
																														case 147:
																															goto IL_09d5;
																														case 149:
																															goto IL_09e3;
																														case 40:
																														case 159:
																															goto IL_09ee;
																														case 70:
																															goto IL_0a03;
																														case 104:
																															goto IL_0a13;
																														case 3:
																														case 13:
																															goto IL_0a1e;
																														case 179:
																															goto IL_0a33;
																														case 183:
																														case 185:
																															goto IL_0a43;
																														case 181:
																															goto IL_0a58;
																														case 2:
																														case 4:
																														case 8:
																														case 26:
																														case 29:
																														case 31:
																														case 35:
																														case 36:
																														case 46:
																														case 54:
																														case 62:
																														case 63:
																														case 65:
																														case 67:
																														case 69:
																														case 71:
																														case 72:
																														case 81:
																														case 83:
																														case 90:
																														case 91:
																														case 98:
																														case 101:
																														case 103:
																														case 117:
																														case 121:
																														case 129:
																														case 130:
																														case 131:
																														case 154:
																														case 161:
																														case 169:
																														case 184:
																															goto end_IL_0369;
																														case 42:
																															goto IL_0a7d;
																														case 11:
																														case 14:
																														case 15:
																														case 17:
																														case 25:
																														case 49:
																														case 59:
																														case 64:
																														case 75:
																														case 119:
																														case 120:
																														case 125:
																														case 132:
																														case 134:
																														case 135:
																														case 136:
																														case 151:
																														case 152:
																														case 160:
																														case 163:
																														case 173:
																														case 174:
																														case 177:
																														case 180:
																														case 186:
																															goto end_IL_040c;
																														case 73:
																															goto end_IL_0a8b;
																														case 99:
																															goto end_IL_0a9e;
																														case 105:
																														case 162:
																															goto end_IL_0aa8;
																														case 182:
																															goto end_IL_0ab3;
																														case 133:
																														case 137:
																															goto end_IL_0ac3;
																														case 82:
																															goto end_IL_0ad3;
																														case 34:
																														case 195:
																															goto end_IL_0ae3;
																														case 38:
																															goto end_IL_0af3;
																														case 39:
																															goto end_IL_0b0a;
																														case 113:
																														case 124:
																															return;
																														}
																														continue;
																														end_IL_0369:
																														break;
																													}
																													break;
																												}
																												goto IL_0446;
																												IL_0446:
																												((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																												goto IL_045b;
																												IL_045b:
																												ptr2 += 8;
																												goto end_IL_040c;
																											}
																											break;
																										}
																										goto IL_08a7;
																										IL_08d8:
																										ptr2 += 8;
																										goto end_IL_040c;
																										IL_08a7:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_08b5;
																										IL_08b5:
																										if (11 > b)
																										{
																											break;
																										}
																										goto IL_08c3;
																										IL_08c3:
																										((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																										goto IL_08d8;
																									}
																									break;
																								}
																								goto IL_0417;
																								IL_054d:
																								ptr2 += 8;
																								goto end_IL_040c;
																								IL_0417:
																								if (9 > b)
																								{
																									goto IL_0425;
																								}
																								goto IL_0538;
																								IL_0425:
																								if (7 >= b)
																								{
																									goto IL_0433;
																								}
																								goto IL_07af;
																								IL_0433:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_07d0;
																								IL_07d0:
																								((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																								goto IL_07e5;
																								IL_07e5:
																								ptr2 += 8;
																								goto end_IL_040c;
																								IL_07af:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_07bd;
																								IL_07bd:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_087f;
																								IL_087f:
																								((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																								goto IL_0894;
																								IL_0894:
																								ptr2 += 8;
																								goto end_IL_040c;
																								IL_0538:
																								((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																								goto IL_054d;
																							}
																							break;
																						}
																						goto IL_08eb;
																						IL_0a1e:
																						((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																						goto IL_0a33;
																						IL_08eb:
																						if (6 <= b)
																						{
																							goto IL_08f6;
																						}
																						goto IL_091e;
																						IL_08f6:
																						((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																						goto IL_090b;
																						IL_090b:
																						ptr2 += 8;
																						goto end_IL_040c;
																						IL_091e:
																						if (3 >= b)
																						{
																							goto IL_092c;
																						}
																						goto IL_09c1;
																						IL_092c:
																						if (3 <= b)
																						{
																							goto IL_0937;
																						}
																						goto IL_095f;
																						IL_0937:
																						((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																						goto IL_094c;
																						IL_094c:
																						ptr2 += 8;
																						goto end_IL_040c;
																						IL_095f:
																						if (1 >= b)
																						{
																							goto IL_096a;
																						}
																						goto IL_097d;
																						IL_096a:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_097d:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_098b;
																						IL_098b:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_0999;
																						IL_0999:
																						((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																						goto IL_09ae;
																						IL_09ae:
																						ptr2 += 8;
																						goto end_IL_040c;
																						IL_09c1:
																						if (4 < b)
																						{
																							num = 84;
																							goto IL_09d5;
																						}
																						goto IL_0a13;
																						IL_0a33:
																						ptr2 += 8;
																						goto end_IL_040c;
																						IL_09d5:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_09e3;
																						IL_09e3:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_09ee;
																						IL_09ee:
																						((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																						goto IL_0a03;
																						IL_0a03:
																						ptr2 += 8;
																						goto end_IL_040c;
																						IL_0a13:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0a1e;
																					}
																					break;
																				}
																				goto IL_0a43;
																				IL_0a58:
																				ptr2 += 8;
																				goto end_IL_040c;
																				IL_0a43:
																				((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																				goto IL_0a58;
																			}
																			break;
																		}
																		goto IL_046e;
																		IL_0780:
																		ptr2 += 8;
																		goto end_IL_040c;
																		IL_046e:
																		if (18 < b)
																		{
																			goto IL_047c;
																		}
																		goto IL_04ff;
																		IL_047c:
																		if (21 < b)
																		{
																			goto IL_0487;
																		}
																		num = 28;
																		goto IL_04e1;
																		IL_0487:
																		if (22 < b)
																		{
																			goto IL_0492;
																		}
																		goto IL_04bc;
																		IL_0492:
																		if (23 < b)
																		{
																			break;
																		}
																		num = 108;
																		goto IL_04a9;
																		IL_06c9:
																		if (17 < b)
																		{
																			break;
																		}
																		goto IL_06d7;
																		IL_04a9:
																		if (23 > b)
																		{
																			break;
																		}
																		goto IL_0793;
																		IL_0793:
																		byte* num5 = ptr2;
																		num4 = 1;
																		ptr2 = num5 + -200;
																		goto end_IL_040c;
																		IL_04bc:
																		if (22 > b)
																		{
																			break;
																		}
																		num = 175;
																		goto IL_059e;
																		IL_06d7:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_06e5;
																		IL_059e:
																		bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num6 - 1])) != 0;
																		goto IL_05b8;
																		IL_05b8:
																		num6--;
																		goto end_IL_040c;
																		IL_06fe:
																		num6--;
																		goto end_IL_040c;
																		IL_04e1:
																		if (21 > b)
																		{
																			goto IL_04ef;
																		}
																		goto IL_0837;
																		IL_04ef:
																		if (19 >= b)
																		{
																			goto IL_0560;
																		}
																		goto IL_0711;
																		IL_0560:
																		if (19 > b)
																		{
																			break;
																		}
																		goto IL_056e;
																		IL_056e:
																		string_0 = (string)array2[num6 - 1];
																		goto IL_0582;
																		IL_0582:
																		num6--;
																		num = 14;
																		goto end_IL_040c;
																		IL_0711:
																		if (20 < b)
																		{
																			break;
																		}
																		goto IL_071f;
																		IL_071f:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_072d;
																		IL_072d:
																		string_1 = (string)array2[num6 - 1];
																		goto IL_0741;
																		IL_0741:
																		num6--;
																		goto end_IL_040c;
																		IL_0837:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0850;
																		IL_0850:
																		array[num6] = 0;
																		goto IL_085e;
																		IL_085e:
																		num6++;
																		goto IL_086c;
																		IL_086c:
																		ptr2 += 8;
																		goto end_IL_040c;
																		IL_04ff:
																		if (18 <= b)
																		{
																			goto IL_050d;
																		}
																		goto IL_05cb;
																		IL_050d:
																		array2[num6] = null;
																		goto IL_0517;
																		IL_0517:
																		array[num6] = 5;
																		goto IL_0525;
																		IL_0525:
																		num6++;
																		goto end_IL_040c;
																		IL_05cb:
																		if (15 >= b)
																		{
																			goto IL_05d9;
																		}
																		goto IL_0692;
																		IL_05d9:
																		if (15 <= b)
																		{
																			goto IL_05e4;
																		}
																		goto IL_0610;
																		IL_05e4:
																		list_0 = (List<string>)array2[num6 - 1];
																		goto IL_05fd;
																		IL_05fd:
																		num6--;
																		goto end_IL_040c;
																		IL_0610:
																		if (13 >= b)
																		{
																			goto IL_061b;
																		}
																		goto IL_0651;
																		IL_061b:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_0629;
																		IL_0629:
																		((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																		goto IL_063e;
																		IL_063e:
																		ptr2 += 8;
																		goto end_IL_040c;
																		IL_0651:
																		if (14 < b)
																		{
																			break;
																		}
																		num = 112;
																		goto IL_0668;
																		IL_06e5:
																		list_1 = (List<AudioClip>)array2[num6 - 1];
																		goto IL_06fe;
																		IL_0668:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_0676;
																		IL_0676:
																		array[num6] = 5;
																		num = 200;
																		goto IL_07f8;
																		IL_07f8:
																		array2[num6] = ((delegate*<List<string>>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																		goto IL_0816;
																		IL_0816:
																		num6++;
																		goto IL_0824;
																		IL_0824:
																		ptr2 += 8;
																		goto end_IL_040c;
																		IL_0692:
																		if (16 >= b)
																		{
																			goto IL_069d;
																		}
																		goto IL_06c9;
																		IL_069d:
																		if (16 > b)
																		{
																			num = 31;
																			break;
																		}
																		goto IL_06a8;
																		IL_06a8:
																		array[num6] = 5;
																		goto IL_0754;
																		IL_0754:
																		array2[num6] = ((delegate*<List<AudioClip>>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
																		goto IL_0772;
																		IL_0772:
																		num6++;
																		goto IL_0780;
																	}
																	break;
																	IL_03dc:;
																}
															}
															((delegate*<void>)getNumberFormatAssemblyEvidenceFactory[*(int*)(ptr2 + num3)])();
															goto IL_0a7d;
															IL_0a7d:
															ptr2 += 8;
															goto end_IL_040c;
															continue;
															end_IL_03ec:
															break;
														}
														continue;
														end_IL_03fc:
														break;
													}
													continue;
													end_IL_040c:
													break;
												}
												continue;
												end_IL_0a8b:
												break;
											}
											continue;
											end_IL_0a9e:
											break;
										}
										continue;
										end_IL_0aa8:
										break;
									}
									continue;
									end_IL_0ab3:
									break;
								}
								continue;
								end_IL_0ac3:
								break;
							}
							continue;
							end_IL_0ad3:
							break;
						}
						continue;
						end_IL_0ae3:
						break;
					}
					continue;
					end_IL_0af3:
					break;
				}
				continue;
				end_IL_0b0a:
				break;
			}
		}
	}

	private unsafe static int smethod_10(int int_2)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 49;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetClassLayoutEvent.setRemotingConfigurationATTType);
										num = 87;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0281:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0264:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0254:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0244:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0237:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0227:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													num = 121;
																													while (true)
																													{
																														if (num != 121)
																														{
																															if (num != 1102)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 14:
																																goto IL_0214;
																															case 83:
																																goto IL_0227;
																															case 48:
																																goto IL_0237;
																															case 104:
																																goto IL_0244;
																															case 70:
																																goto IL_0254;
																															case 5:
																																goto IL_0264;
																															case 43:
																																goto IL_0271;
																															case 54:
																																goto IL_0281;
																															case 13:
																																goto end_IL_0281;
																															case 33:
																															case 89:
																																goto end_IL_0291;
																															case 4:
																															case 21:
																																goto IL_02ac;
																															case 58:
																															case 90:
																																goto IL_02c4;
																															case 46:
																															case 50:
																																goto IL_02d2;
																															case 20:
																															case 99:
																																goto IL_02e5;
																															case 76:
																																goto IL_0325;
																															case 98:
																																goto IL_0339;
																															case 10:
																															case 100:
																																goto IL_034c;
																															case 71:
																																goto IL_035a;
																															case 15:
																															case 60:
																																goto IL_0368;
																															case 19:
																																goto IL_0391;
																															case 63:
																																goto IL_039f;
																															case 77:
																															case 103:
																																goto end_IL_0201;
																															case 27:
																																goto IL_03c9;
																															case 109:
																																goto IL_03dc;
																															case 39:
																															case 97:
																																goto IL_03e7;
																															case 69:
																																goto IL_0449;
																															case 35:
																																goto IL_045c;
																															case 6:
																															case 47:
																																goto IL_0467;
																															case 93:
																																goto IL_0475;
																															case 7:
																																goto IL_0488;
																															case 53:
																															case 91:
																																goto IL_0493;
																															case 2:
																																goto IL_04d3;
																															case 12:
																																goto IL_04e7;
																															case 111:
																																goto IL_0508;
																															case 30:
																															case 36:
																																goto IL_0516;
																															case 68:
																															case 114:
																																goto IL_0532;
																															case 31:
																																goto IL_0555;
																															case 94:
																																goto IL_0563;
																															case 82:
																																goto IL_0571;
																															case 65:
																																goto IL_0584;
																															case 78:
																																goto IL_059d;
																															case 92:
																																goto IL_05ab;
																															case 16:
																																goto IL_05b9;
																															case 11:
																																goto IL_05cc;
																															case 51:
																															case 75:
																																goto IL_05d7;
																															case 112:
																																goto IL_05e2;
																															case 3:
																															case 67:
																																goto IL_05ed;
																															case 17:
																																goto IL_05fb;
																															case 56:
																																goto IL_061e;
																															case 34:
																																goto IL_0628;
																															case 113:
																																goto IL_0636;
																															case 73:
																																goto IL_0646;
																															case 8:
																															case 23:
																															case 24:
																															case 26:
																															case 32:
																															case 37:
																															case 38:
																															case 40:
																															case 52:
																															case 55:
																															case 62:
																															case 74:
																															case 79:
																															case 85:
																															case 95:
																															case 96:
																															case 101:
																															case 102:
																															case 106:
																															case 107:
																															case 108:
																																goto end_IL_0214;
																															case 22:
																															case 25:
																															case 28:
																															case 44:
																															case 45:
																															case 57:
																															case 59:
																															case 61:
																															case 72:
																															case 80:
																															case 81:
																															case 84:
																															case 86:
																															case 88:
																																goto end_IL_02a1;
																															case 87:
																																goto end_IL_066f;
																															case 29:
																																goto end_IL_0682;
																															case 105:
																																goto end_IL_068c;
																															case 0:
																																goto end_IL_06a0;
																															case 1:
																															case 110:
																																goto end_IL_06b5;
																															case 49:
																																goto end_IL_06c5;
																															case 9:
																															case 18:
																																goto end_IL_06d5;
																															case 41:
																																goto end_IL_06e5;
																															case 42:
																																goto end_IL_06fe;
																															case 64:
																															case 66:
																																goto IL_0719;
																															}
																															continue;
																														}
																														goto IL_0584;
																														IL_05ab:
																														num5++;
																														goto IL_05b9;
																														IL_05b9:
																														ptr2 += 8;
																														goto end_IL_02a1;
																														IL_0584:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														goto IL_059d;
																														IL_059d:
																														array[num5] = 0;
																														goto IL_05ab;
																														continue;
																														end_IL_0201:
																														break;
																													}
																													goto IL_03bb;
																													continue;
																													end_IL_0214:
																													break;
																													IL_0214:;
																												}
																												break;
																											}
																											goto IL_034c;
																											IL_039f:
																											num5--;
																											num = 80;
																											goto end_IL_02a1;
																											IL_034c:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_035a;
																											IL_035a:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0368;
																											IL_0368:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0391;
																											IL_0391:
																											ptr2 += 8;
																											goto IL_039f;
																										}
																										break;
																									}
																									goto IL_02ac;
																									IL_02ac:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02a1;
																								}
																								break;
																							}
																							goto IL_05cc;
																							IL_0646:
																							if (4 <= b)
																							{
																								goto end_IL_02a1;
																							}
																							break;
																							IL_05cc:
																							if (4 < b)
																							{
																								goto IL_05d7;
																							}
																							goto IL_0646;
																							IL_05d7:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_05e2;
																							IL_05e2:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_05ed;
																							IL_05ed:
																							array[num5] = 0;
																							goto IL_05fb;
																							IL_05fb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_061e;
																							IL_061e:
																							array2[num5] = null;
																							goto IL_0628;
																							IL_0628:
																							num5++;
																							goto IL_0636;
																							IL_0636:
																							ptr2 += 8;
																							goto end_IL_02a1;
																						}
																						break;
																					}
																					goto IL_02e5;
																					IL_0339:
																					num5--;
																					goto end_IL_02a1;
																					IL_02e5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0325;
																					IL_0325:
																					array[num5 - 2] = 0;
																					goto IL_0339;
																				}
																				break;
																			}
																			goto IL_02c4;
																			IL_04e7:
																			num5--;
																			goto end_IL_02a1;
																			IL_02c4:
																			if (9 < b)
																			{
																				goto IL_02d2;
																			}
																			goto IL_03dc;
																			IL_02d2:
																			if (10 < b)
																			{
																				goto IL_03bb;
																			}
																			goto IL_0508;
																			IL_03bb:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03c9;
																			IL_03c9:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_0508:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0516;
																			IL_0516:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a1;
																			IL_03dc:
																			if (9 <= b)
																			{
																				goto IL_03e7;
																			}
																			goto IL_045c;
																			IL_03e7:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0449;
																			IL_0449:
																			num5 -= 2;
																			goto end_IL_02a1;
																			IL_045c:
																			if (7 < b)
																			{
																				goto IL_0467;
																			}
																			goto IL_0488;
																			IL_0467:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0475;
																			IL_0475:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0532;
																			IL_0532:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0555;
																			IL_0555:
																			array[num5] = 0;
																			goto IL_0563;
																			IL_0563:
																			num5++;
																			goto IL_0571;
																			IL_0571:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_0488:
																			if (7 > b)
																			{
																				num = 38;
																				break;
																			}
																			goto IL_0493;
																			IL_0493:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04d3;
																			IL_04d3:
																			array[num5 - 2] = 0;
																			goto IL_04e7;
																		}
																		break;
																		IL_0271:;
																	}
																}
																else
																{
																	num = 85;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a1;
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
														end_IL_02a1:
														break;
													}
													continue;
												}
												goto IL_0719;
												IL_0719:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_066f:
												break;
											}
											continue;
											end_IL_0682:
											break;
										}
										continue;
										end_IL_068c:
										break;
									}
									continue;
									end_IL_06a0:
									break;
								}
								continue;
								end_IL_06b5:
								break;
							}
							continue;
							end_IL_06c5:
							break;
						}
						continue;
						end_IL_06d5:
						break;
					}
					continue;
					end_IL_06e5:
					break;
				}
				continue;
				end_IL_06fe:
				break;
			}
		}
	}

	private unsafe static int smethod_11(int int_2)
	{
		int num = 22;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 92;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPositiveSignRSASignaturePadding.getPositiveSignRSASignaturePadding_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 9;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_029f:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_027c:
																			if (5 < b)
																			{
																				num = 3;
																				while (true)
																				{
																					IL_026c:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_025c:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_024f:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_01f4:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 113;
																												while (true)
																												{
																													if (num != 113)
																													{
																														if (num != 1094)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 20:
																														case 61:
																															goto IL_01f4;
																														case 45:
																															goto IL_023f;
																														case 99:
																															goto IL_024f;
																														case 54:
																															goto IL_025c;
																														case 3:
																														case 98:
																															goto IL_026c;
																														case 42:
																															goto IL_027c;
																														case 58:
																															goto IL_028f;
																														case 36:
																															goto IL_029f;
																														case 9:
																															goto end_IL_029f;
																														case 38:
																														case 62:
																															goto end_IL_02af;
																														case 52:
																														case 63:
																															goto IL_02d3;
																														case 57:
																															goto IL_02e1;
																														case 4:
																														case 49:
																															goto IL_02ef;
																														case 30:
																															goto IL_0312;
																														case 68:
																															goto IL_0320;
																														case 72:
																														case 78:
																															goto IL_0330;
																														case 6:
																															goto IL_0392;
																														case 106:
																															goto IL_03a5;
																														case 97:
																															goto IL_03cc;
																														case 27:
																															goto IL_03df;
																														case 8:
																															goto IL_03ea;
																														case 35:
																														case 48:
																															goto end_IL_01e1;
																														case 101:
																															goto IL_041f;
																														case 76:
																															goto IL_042d;
																														case 100:
																															goto IL_0440;
																														case 73:
																														case 95:
																															goto IL_044e;
																														case 50:
																														case 74:
																															goto IL_0459;
																														case 86:
																															goto IL_0464;
																														case 75:
																														case 88:
																															goto IL_0472;
																														case 40:
																															goto IL_0493;
																														case 77:
																															goto IL_04a1;
																														case 65:
																															goto IL_04b4;
																														case 85:
																														case 90:
																															goto IL_04bf;
																														case 104:
																															goto IL_04e8;
																														case 105:
																															goto IL_04f6;
																														case 11:
																														case 37:
																															goto IL_0509;
																														case 47:
																															goto IL_0520;
																														case 46:
																														case 89:
																															goto IL_0539;
																														case 67:
																															goto IL_0552;
																														case 34:
																															goto IL_0560;
																														case 102:
																															goto IL_056e;
																														case 17:
																														case 81:
																															goto IL_057e;
																														case 43:
																															goto IL_058c;
																														case 82:
																															goto IL_05af;
																														case 33:
																															goto IL_05b9;
																														case 31:
																															goto IL_05c7;
																														case 1:
																														case 2:
																														case 7:
																														case 13:
																														case 23:
																														case 24:
																														case 26:
																														case 28:
																														case 29:
																														case 32:
																														case 41:
																														case 53:
																														case 59:
																														case 60:
																														case 64:
																														case 71:
																														case 79:
																														case 87:
																														case 91:
																														case 94:
																														case 96:
																															goto end_IL_023f;
																														case 0:
																														case 10:
																														case 12:
																														case 14:
																														case 15:
																														case 16:
																														case 39:
																														case 44:
																														case 55:
																														case 70:
																														case 80:
																														case 83:
																														case 84:
																															goto end_IL_02bf;
																														case 18:
																															goto end_IL_05f3;
																														case 19:
																															goto end_IL_0606;
																														case 103:
																															goto end_IL_0610;
																														case 69:
																															goto end_IL_061b;
																														case 56:
																														case 93:
																															goto end_IL_0630;
																														case 92:
																															goto end_IL_0640;
																														case 25:
																														case 66:
																															goto end_IL_0650;
																														case 21:
																															goto end_IL_0660;
																														case 22:
																															goto end_IL_0679;
																														case 5:
																														case 51:
																															goto IL_0694;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													goto IL_03cc;
																													IL_03cc:
																													num5--;
																													goto end_IL_02bf;
																													continue;
																													end_IL_01e1:
																													break;
																												}
																												break;
																											}
																											goto IL_03f5;
																											continue;
																											end_IL_023f:
																											break;
																											IL_023f:;
																										}
																										break;
																									}
																									goto IL_02d3;
																									IL_03a5:
																									ptr2 += 8;
																									goto end_IL_02bf;
																									IL_02d3:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_02e1;
																									IL_02e1:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_02ef;
																									IL_02ef:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0312;
																									IL_0312:
																									array[num5] = 0;
																									goto IL_0320;
																									IL_0320:
																									num5++;
																									goto IL_03a5;
																								}
																								break;
																							}
																							goto IL_0330;
																							IL_0392:
																							num5 -= 2;
																							goto end_IL_02bf;
																							IL_0330:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0392;
																						}
																						break;
																					}
																					goto IL_03df;
																					IL_041f:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_042d;
																					IL_03df:
																					if (9 >= b)
																					{
																						goto IL_03ea;
																					}
																					goto IL_041f;
																					IL_03ea:
																					if (9 > b)
																					{
																						num = 71;
																						break;
																					}
																					goto IL_03f5;
																					IL_03f5:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02bf;
																					IL_042d:
																					if (10 <= b)
																					{
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_0440;
																			IL_058c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05af;
																			IL_05af:
																			array2[num5] = null;
																			goto IL_05b9;
																			IL_0440:
																			if (5 > b)
																			{
																				goto IL_044e;
																			}
																			goto IL_057e;
																			IL_044e:
																			if (2 < b)
																			{
																				goto IL_0459;
																			}
																			goto IL_04b4;
																			IL_0459:
																			if (3 >= b)
																			{
																				goto IL_0464;
																			}
																			goto IL_0493;
																			IL_0464:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0472;
																			IL_0472:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 10;
																			goto end_IL_02bf;
																			IL_0493:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_04a1;
																			IL_04a1:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02bf;
																			IL_04b4:
																			if (2 <= b)
																			{
																				goto IL_04bf;
																			}
																			goto IL_0509;
																			IL_04bf:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e8;
																			IL_04e8:
																			ptr2 += 8;
																			goto IL_04f6;
																			IL_04f6:
																			num5--;
																			goto end_IL_02bf;
																			IL_0509:
																			if (1 < b)
																			{
																				break;
																			}
																			num = 47;
																			goto IL_0520;
																			IL_05b9:
																			num5++;
																			goto IL_05c7;
																			IL_0520:
																			if (1 > b)
																			{
																				num = 79;
																				break;
																			}
																			goto IL_0539;
																			IL_05c7:
																			ptr2 += 8;
																			goto end_IL_02bf;
																			IL_0539:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0552;
																			IL_0552:
																			array[num5] = 0;
																			goto IL_0560;
																			IL_0560:
																			num5++;
																			goto IL_056e;
																			IL_056e:
																			ptr2 += 8;
																			goto end_IL_02bf;
																			IL_057e:
																			array[num5] = 0;
																			goto IL_058c;
																		}
																		break;
																		IL_028f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 55;
																goto end_IL_02bf;
																continue;
																end_IL_029f:
																break;
															}
															continue;
															end_IL_02af:
															break;
														}
														continue;
														end_IL_02bf:
														break;
													}
													continue;
												}
												goto IL_0694;
												IL_0694:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f3:
												break;
											}
											continue;
											end_IL_0606:
											break;
										}
										continue;
										end_IL_0610:
										break;
									}
									continue;
									end_IL_061b:
									break;
								}
								continue;
								end_IL_0630:
								break;
							}
							continue;
							end_IL_0640:
							break;
						}
						continue;
						end_IL_0650:
						break;
					}
					continue;
					end_IL_0660:
					break;
				}
				continue;
				end_IL_0679:
				break;
			}
		}
	}

	private static int smethod_12(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		num += num2;
		int num3 = num;
		num = int_2;
		num2 = int_3;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 99;
		num2 = 9;
		return num + 9;
	}

	private unsafe static int smethod_13(int int_2, int int_3)
	{
		int num = 34;
		long[] array4 = default(long[]);
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							num = 111;
							while (true)
							{
								if (num != 111)
								{
									if (num != 1092)
									{
										break;
									}
									switch (num)
									{
									case 53:
									case 55:
										goto end_IL_01cb;
									case 10:
										goto end_IL_01db;
									case 0:
									case 84:
										goto end_IL_01f4;
									case 33:
										goto end_IL_0204;
									case 34:
										goto end_IL_0214;
									case 2:
										goto IL_023d;
									case 73:
										goto IL_0250;
									case 30:
										goto IL_0263;
									case 43:
										goto IL_026c;
									case 18:
									case 32:
									case 37:
									case 45:
									case 51:
									case 57:
									case 64:
									case 82:
									case 98:
									case 101:
									case 103:
										goto IL_0274;
									case 11:
										goto IL_0284;
									case 8:
										goto IL_028d;
									case 40:
										goto IL_0296;
									case 46:
										goto IL_02a4;
									case 22:
										goto IL_02b2;
									case 96:
										goto IL_02c0;
									case 31:
										goto IL_02ce;
									case 92:
									case 102:
										goto IL_02dc;
									case 95:
										goto IL_02e7;
									case 38:
										goto IL_02f5;
									case 16:
									case 65:
										goto IL_0303;
									case 13:
										goto IL_0328;
									case 56:
									case 85:
										goto IL_0336;
									case 39:
										goto IL_0376;
									case 104:
										goto IL_038a;
									case 97:
										goto IL_039d;
									case 87:
									case 90:
										goto IL_03a8;
									case 29:
										goto IL_03c1;
									case 68:
										goto IL_03cf;
									case 58:
										goto IL_03dd;
									case 44:
										goto IL_03f0;
									case 26:
										goto IL_03fb;
									case 41:
									case 61:
										goto IL_0409;
									case 83:
										goto IL_0449;
									case 78:
										goto IL_045d;
									case 25:
										goto IL_0487;
									case 49:
									case 89:
										goto IL_0495;
									case 62:
										goto IL_04a3;
									case 71:
									case 91:
										goto IL_04ae;
									case 70:
										goto IL_04bc;
									case 76:
									case 81:
										goto IL_04cf;
									case 9:
										goto IL_050f;
									case 66:
										goto IL_0523;
									case 93:
										goto IL_0536;
									case 3:
									case 67:
										goto IL_0544;
									case 77:
										goto IL_0552;
									case 4:
									case 7:
										goto IL_0560;
									case 36:
										goto IL_05a0;
									case 23:
										goto IL_05b4;
									case 59:
										goto IL_05c7;
									case 28:
									case 100:
										goto IL_05d5;
									case 74:
										goto IL_05fe;
									case 69:
										goto IL_060c;
									case 35:
									case 63:
										goto IL_061f;
									case 5:
										goto IL_062d;
									case 24:
										goto IL_0650;
									case 20:
										goto IL_065a;
									case 75:
										goto IL_0668;
									case 15:
										goto IL_067b;
									case 60:
										goto IL_0689;
									case 42:
										goto IL_06a0;
									case 1:
									case 6:
									case 12:
									case 14:
									case 17:
									case 19:
									case 21:
									case 27:
									case 47:
									case 48:
									case 50:
									case 54:
									case 72:
									case 79:
									case 80:
									case 86:
									case 94:
									case 99:
										goto IL_06b3;
									case 52:
									case 88:
										goto IL_06d8;
									}
									continue;
								}
								array4 = new long[3];
								goto IL_023d;
								IL_065a:
								num4++;
								goto IL_0668;
								IL_06b3:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_067b;
								IL_0668:
								ptr += 8;
								goto IL_0274;
								IL_023d:
								array3[0] = int_2;
								goto IL_0250;
								IL_0250:
								array3[1] = int_3;
								goto IL_0263;
								IL_0263:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetVersionAccessRule.UseNonExportableKeyDaylightTimeStruct);
								goto IL_026c;
								IL_026c:
								ptr = ptr2;
								goto IL_0274;
								IL_0274:
								if (num5 != 1)
								{
									goto IL_0284;
								}
								goto IL_06d8;
								IL_06d8:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								IL_0284:
								num = 8;
								goto IL_028d;
								IL_028d:
								b = *ptr;
								goto IL_0296;
								IL_0296:
								ptr++;
								goto IL_02a4;
								IL_02a4:
								if (b >= 1)
								{
									goto IL_02b2;
								}
								goto IL_06b3;
								IL_02b2:
								if (b <= 9)
								{
									goto IL_02c0;
								}
								goto IL_06b3;
								IL_02c0:
								if (5 < b)
								{
									goto IL_02ce;
								}
								num = 25;
								goto IL_0487;
								IL_02ce:
								if (7 < b)
								{
									goto IL_02dc;
								}
								goto IL_039d;
								IL_02dc:
								if (8 < b)
								{
									goto IL_02e7;
								}
								num = 13;
								goto IL_0328;
								IL_02e7:
								if (9 >= b)
								{
									goto IL_02f5;
								}
								goto IL_06b3;
								IL_02f5:
								if (9 <= b)
								{
									goto IL_0303;
								}
								goto IL_06b3;
								IL_0303:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0274;
								IL_0689:
								num4++;
								num = 42;
								goto IL_06a0;
								IL_0328:
								if (8 <= b)
								{
									goto IL_0336;
								}
								goto IL_06b3;
								IL_0336:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0376;
								IL_0376:
								array[num4 - 2] = 0;
								goto IL_038a;
								IL_038a:
								num4--;
								goto IL_0274;
								IL_039d:
								if (7 <= b)
								{
									goto IL_03a8;
								}
								goto IL_03f0;
								IL_03a8:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
								goto IL_03c1;
								IL_03c1:
								array[num4] = 0;
								goto IL_03cf;
								IL_03cf:
								num4++;
								goto IL_03dd;
								IL_03dd:
								ptr += 8;
								goto IL_0274;
								IL_03f0:
								if (6 >= b)
								{
									goto IL_03fb;
								}
								num = 12;
								goto IL_06b3;
								IL_03fb:
								if (6 <= b)
								{
									goto IL_0409;
								}
								goto IL_06b3;
								IL_0409:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0449;
								IL_0449:
								array[num4 - 2] = 0;
								goto IL_045d;
								IL_045d:
								num4--;
								goto IL_0274;
								IL_06a0:
								ptr += 8;
								goto IL_0274;
								IL_067b:
								array[num4] = 0;
								goto IL_0689;
								IL_0487:
								if (5 > b)
								{
									goto IL_0495;
								}
								goto IL_061f;
								IL_0495:
								if (2 >= b)
								{
									goto IL_04a3;
								}
								goto IL_0536;
								IL_04a3:
								if (2 > b)
								{
									goto IL_04ae;
								}
								goto IL_04cf;
								IL_04ae:
								if (1 >= b)
								{
									goto IL_04bc;
								}
								goto IL_06b3;
								IL_04bc:
								if (1 > b)
								{
								}
								goto IL_06b3;
								IL_04cf:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_050f;
								IL_050f:
								array[num4 - 2] = 0;
								goto IL_0523;
								IL_0523:
								num4--;
								goto IL_0274;
								IL_0536:
								if (3 < b)
								{
									goto IL_0544;
								}
								goto IL_05c7;
								IL_0544:
								if (4 >= b)
								{
									goto IL_0552;
								}
								goto IL_06b3;
								IL_0552:
								if (4 <= b)
								{
									goto IL_0560;
								}
								goto IL_06b3;
								IL_0560:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_05a0;
								IL_05a0:
								array[num4 - 2] = 0;
								goto IL_05b4;
								IL_05b4:
								num4--;
								goto IL_0274;
								IL_05c7:
								if (3 <= b)
								{
									goto IL_05d5;
								}
								goto IL_06b3;
								IL_05d5:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_05fe;
								IL_05fe:
								ptr += 8;
								goto IL_060c;
								IL_060c:
								num4--;
								goto IL_0274;
								IL_061f:
								array[num4] = 0;
								goto IL_062d;
								IL_062d:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_0650;
								IL_0650:
								array2[num4] = null;
								goto IL_065a;
								continue;
								end_IL_01cb:
								break;
							}
							continue;
							end_IL_01db:
							break;
						}
						continue;
						end_IL_01f4:
						break;
					}
					continue;
					end_IL_0204:
					break;
				}
				continue;
				end_IL_0214:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_2, int int_3)
	{
		int num = 76;
		byte[] array = default(byte[]);
		int num4 = default(int);
		object[] array2 = default(object[]);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 111;
				while (true)
				{
					if (num == 111)
					{
						goto IL_01ff;
					}
					if (num != 1092)
					{
						goto IL_05be;
					}
					switch (num)
					{
					case 75:
						goto end_IL_01cb;
					case 76:
						goto end_IL_01db;
					case 13:
						goto IL_01ff;
					case 7:
						goto IL_0216;
					case 47:
					case 58:
						goto IL_0224;
					case 73:
						goto IL_0232;
					case 29:
						goto IL_0240;
					case 42:
						goto IL_0253;
					case 67:
						goto IL_0266;
					case 18:
						goto IL_026f;
					case 1:
					case 14:
					case 15:
					case 51:
					case 56:
					case 59:
					case 61:
					case 66:
					case 80:
					case 82:
					case 101:
						goto IL_0277;
					case 6:
						goto IL_0287;
					case 68:
						goto IL_0290;
					case 35:
						goto IL_02a2;
					case 46:
						goto IL_02b0;
					case 98:
						goto IL_02be;
					case 5:
						goto IL_02cc;
					case 74:
						goto IL_02da;
					case 22:
						goto IL_02e8;
					case 95:
						goto IL_02f6;
					case 85:
					case 97:
						goto IL_0301;
					case 88:
						goto IL_030f;
					case 16:
					case 49:
						goto IL_0322;
					case 20:
						goto IL_0362;
					case 60:
						goto IL_0376;
					case 37:
						goto IL_0389;
					case 71:
					case 96:
						goto IL_0397;
					case 103:
						goto IL_03a5;
					case 25:
					case 55:
						goto IL_03b3;
					case 62:
						goto IL_03f3;
					case 26:
						goto IL_0407;
					case 91:
						goto IL_041a;
					case 81:
					case 87:
						goto IL_0428;
					case 9:
						goto IL_0451;
					case 100:
						goto IL_045f;
					case 63:
					case 104:
						goto IL_0472;
					case 36:
						goto IL_0480;
					case 83:
						goto IL_04a3;
					case 99:
						goto IL_04ad;
					case 40:
						goto IL_04bb;
					case 64:
						goto IL_04ce;
					case 70:
					case 94:
						goto IL_04dc;
					case 11:
					case 21:
						goto IL_04e7;
					case 52:
						goto IL_04f5;
					case 19:
					case 27:
						goto IL_0503;
					case 78:
						goto IL_051f;
					case 45:
					case 69:
						goto IL_052d;
					case 23:
						goto IL_056d;
					case 3:
						goto IL_0581;
					case 33:
						goto IL_0594;
					case 31:
					case 72:
						goto IL_05a2;
					case 48:
						goto IL_05b0;
					case 10:
					case 24:
						goto IL_05be;
					case 38:
						goto IL_05fe;
					case 93:
						goto IL_0612;
					case 34:
					case 54:
						goto IL_0625;
					case 92:
						goto IL_063e;
					case 17:
						goto IL_0655;
					case 57:
						goto IL_0663;
					case 43:
						goto IL_0676;
					case 89:
						goto IL_0684;
					case 8:
						goto IL_0692;
					case 0:
					case 2:
					case 12:
					case 28:
					case 30:
					case 32:
					case 41:
					case 44:
					case 50:
					case 53:
					case 65:
					case 77:
					case 79:
					case 84:
					case 86:
					case 90:
					case 102:
						goto IL_06a5;
					case 4:
					case 39:
						goto IL_06d3;
					}
					continue;
					IL_0676:
					array[num4] = 0;
					goto IL_0684;
					IL_0684:
					num4++;
					goto IL_0692;
					IL_01ff:
					array = new byte[3];
					num = 7;
					goto IL_0216;
					IL_0216:
					array2 = new object[3];
					goto IL_0224;
					IL_0224:
					array3 = new int[5];
					goto IL_0232;
					IL_0232:
					array4 = new long[3];
					goto IL_0240;
					IL_0240:
					array3[0] = int_2;
					goto IL_0253;
					IL_0253:
					array3[1] = int_3;
					goto IL_0266;
					IL_0266:
					ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getUseLegacyPathHandlingTokenSessionId.IPersistFileSatelliteContractVersionAttribute);
					goto IL_026f;
					IL_026f:
					ptr2 = ptr;
					goto IL_0277;
					IL_0277:
					if (num5 != 1)
					{
						goto IL_0287;
					}
					num = 39;
					goto IL_06d3;
					IL_0692:
					ptr2 += 8;
					goto IL_0277;
					IL_06d3:
					return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					IL_0287:
					num = 68;
					goto IL_0290;
					IL_0290:
					b = *ptr2;
					num = 35;
					goto IL_02a2;
					IL_02a2:
					ptr2++;
					goto IL_02b0;
					IL_02b0:
					if (b >= 1)
					{
						goto IL_02be;
					}
					goto IL_06a5;
					IL_02be:
					if (b <= 9)
					{
						goto IL_02cc;
					}
					goto IL_06a5;
					IL_02cc:
					if (5 >= b)
					{
						goto IL_02da;
					}
					goto IL_04ce;
					IL_02da:
					if (5 > b)
					{
						goto IL_02e8;
					}
					goto IL_0472;
					IL_02e8:
					if (2 >= b)
					{
						goto IL_02f6;
					}
					goto IL_0389;
					IL_02f6:
					if (2 > b)
					{
						goto IL_0301;
					}
					goto IL_0322;
					IL_0301:
					if (1 >= b)
					{
						goto IL_030f;
					}
					goto IL_06a5;
					IL_030f:
					if (1 <= b)
					{
					}
					goto IL_06a5;
					IL_0322:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_0362;
					IL_0362:
					array[num4 - 2] = 0;
					goto IL_0376;
					IL_0376:
					num4--;
					goto IL_0277;
					IL_0389:
					if (3 < b)
					{
						goto IL_0397;
					}
					goto IL_041a;
					IL_0397:
					if (4 >= b)
					{
						goto IL_03a5;
					}
					goto IL_06a5;
					IL_03a5:
					if (4 <= b)
					{
						goto IL_03b3;
					}
					goto IL_06a5;
					IL_03b3:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_03f3;
					IL_03f3:
					array[num4 - 2] = 0;
					goto IL_0407;
					IL_0407:
					num4--;
					goto IL_0277;
					IL_041a:
					if (3 <= b)
					{
						goto IL_0428;
					}
					goto IL_06a5;
					IL_0428:
					ref int reference = ref array3[*(int*)(ptr2 + num3)];
					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_0451;
					IL_0451:
					ptr2 += 8;
					goto IL_045f;
					IL_045f:
					num4--;
					goto IL_0277;
					IL_0472:
					array[num4] = 0;
					goto IL_0480;
					IL_0480:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
					goto IL_04a3;
					IL_04a3:
					array2[num4] = null;
					goto IL_04ad;
					IL_04ad:
					num4++;
					goto IL_04bb;
					IL_04bb:
					ptr2 += 8;
					goto IL_0277;
					IL_04ce:
					if (7 < b)
					{
						goto IL_04dc;
					}
					goto IL_0594;
					IL_04dc:
					if (8 < b)
					{
						goto IL_04e7;
					}
					goto IL_051f;
					IL_04e7:
					if (9 >= b)
					{
						goto IL_04f5;
					}
					goto IL_06a5;
					IL_04f5:
					if (9 <= b)
					{
						goto IL_0503;
					}
					goto IL_06a5;
					IL_0503:
					byte* num6 = ptr2;
					num5 = 1;
					ptr2 = num6 + -200;
					goto IL_0277;
					IL_051f:
					if (8 <= b)
					{
						goto IL_052d;
					}
					goto IL_06a5;
					IL_052d:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_056d;
					IL_056d:
					array[num4 - 2] = 0;
					goto IL_0581;
					IL_0581:
					num4--;
					goto IL_0277;
					IL_0594:
					if (7 > b)
					{
						goto IL_05a2;
					}
					goto IL_0625;
					IL_05a2:
					if (6 >= b)
					{
						goto IL_05b0;
					}
					goto IL_06a5;
					IL_05b0:
					if (6 <= b)
					{
						goto IL_05be;
					}
					goto IL_06a5;
					IL_05be:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_05fe;
					IL_05fe:
					array[num4 - 2] = 0;
					goto IL_0612;
					IL_0612:
					num4--;
					goto IL_0277;
					IL_0625:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
					goto IL_063e;
					IL_063e:
					array[num4] = 0;
					num = 17;
					goto IL_0655;
					IL_0655:
					num4++;
					goto IL_0663;
					IL_0663:
					ptr2 += 8;
					goto IL_0277;
					IL_06a5:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
					goto IL_0676;
					continue;
					end_IL_01cb:
					break;
				}
				continue;
				end_IL_01db:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_2)
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 5;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TitlecaseLetterSoapHexBinary.getRegisteredHandlersgetVariantType);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 91;
												while (true)
												{
													num = 100;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_024c:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_022c:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_020c:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01fc:
																											if (2 > b)
																											{
																												num = 115;
																												while (true)
																												{
																													if (num != 115)
																													{
																														if (num != 1096)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 30:
																															goto IL_01fc;
																														case 82:
																														case 103:
																															goto IL_020c;
																														case 57:
																															goto IL_021c;
																														case 36:
																															goto IL_022c;
																														case 20:
																															goto end_IL_022c;
																														case 33:
																															goto IL_024c;
																														case 79:
																															goto end_IL_024c;
																														case 34:
																														case 107:
																															goto end_IL_025c;
																														case 4:
																														case 16:
																															goto IL_0277;
																														case 13:
																															goto IL_02a0;
																														case 7:
																														case 55:
																															goto IL_02b3;
																														case 73:
																															goto IL_02c1;
																														case 65:
																														case 75:
																															goto IL_02e9;
																														case 40:
																															goto IL_02f7;
																														case 2:
																														case 78:
																															goto IL_0302;
																														case 9:
																															goto IL_036d;
																														case 87:
																															goto IL_0380;
																														case 38:
																															goto IL_038e;
																														case 92:
																															goto IL_03a1;
																														case 95:
																															goto IL_03ab;
																														case 86:
																															goto IL_03b9;
																														case 96:
																															goto IL_03cc;
																														case 59:
																														case 98:
																															goto IL_03df;
																														case 74:
																														case 84:
																															goto IL_03ea;
																														case 93:
																															goto IL_03f8;
																														case 17:
																															goto IL_040b;
																														case 3:
																														case 50:
																															goto IL_0419;
																														case 49:
																														case 101:
																															goto IL_0435;
																														case 10:
																														case 41:
																															goto IL_0440;
																														case 89:
																															goto IL_044e;
																														case 27:
																															goto IL_0461;
																														case 63:
																														case 66:
																															goto IL_046f;
																														case 52:
																														case 105:
																															goto IL_0490;
																														case 99:
																															goto IL_049e;
																														case 90:
																														case 102:
																															goto IL_04ac;
																														case 11:
																															goto end_IL_01e9;
																														case 88:
																															goto IL_04dd;
																														case 26:
																															goto IL_04f4;
																														case 56:
																														case 108:
																															goto IL_0507;
																														case 19:
																															goto IL_0547;
																														case 71:
																															goto IL_055b;
																														case 60:
																															goto IL_056b;
																														case 94:
																															goto IL_0576;
																														case 21:
																														case 67:
																															goto IL_0581;
																														case 14:
																															goto IL_059a;
																														case 45:
																															goto IL_05a8;
																														case 106:
																															goto IL_05b6;
																														case 1:
																														case 8:
																														case 15:
																														case 18:
																														case 23:
																														case 25:
																														case 28:
																														case 32:
																														case 35:
																														case 43:
																														case 51:
																														case 53:
																														case 54:
																														case 62:
																														case 69:
																														case 70:
																														case 80:
																														case 85:
																														case 97:
																														case 104:
																															goto end_IL_023c;
																														case 12:
																														case 22:
																														case 24:
																														case 29:
																														case 31:
																														case 39:
																														case 44:
																														case 68:
																														case 72:
																														case 76:
																														case 83:
																														case 100:
																															goto end_IL_026c;
																														case 91:
																															goto end_IL_05d9;
																														case 42:
																															goto end_IL_05ec;
																														case 48:
																															goto end_IL_05f7;
																														case 77:
																															goto end_IL_060a;
																														case 37:
																															goto end_IL_0615;
																														case 6:
																														case 58:
																															goto end_IL_062a;
																														case 64:
																															goto end_IL_063a;
																														case 5:
																															goto end_IL_064a;
																														case 81:
																															goto end_IL_065a;
																														case 46:
																															goto end_IL_066a;
																														case 47:
																															goto end_IL_0675;
																														case 0:
																														case 61:
																															goto IL_0690;
																														}
																														continue;
																													}
																													goto IL_056b;
																													IL_05a8:
																													num5++;
																													goto IL_05b6;
																													IL_05b6:
																													ptr2 += 8;
																													goto end_IL_026c;
																													IL_056b:
																													if (1 < b)
																													{
																														goto end_IL_023c;
																													}
																													goto IL_0576;
																													IL_0576:
																													if (1 > b)
																													{
																														goto end_IL_023c;
																													}
																													goto IL_0581;
																													IL_0581:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_059a;
																													IL_059a:
																													array[num5] = 0;
																													goto IL_05a8;
																													continue;
																													end_IL_01e9:
																													break;
																												}
																												break;
																											}
																											goto IL_0277;
																											IL_02a0:
																											ptr2 += 8;
																											goto IL_03cc;
																											IL_03cc:
																											num5--;
																											goto end_IL_026c;
																											IL_0277:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_02a0;
																										}
																										break;
																									}
																									goto IL_0435;
																									IL_046f:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									num = 68;
																									goto end_IL_026c;
																									IL_0435:
																									if (3 < b)
																									{
																										goto IL_0440;
																									}
																									goto IL_0461;
																									IL_0440:
																									if (4 < b)
																									{
																										goto end_IL_023c;
																									}
																									goto IL_044e;
																									IL_044e:
																									if (4 <= b)
																									{
																										goto end_IL_026c;
																									}
																									goto end_IL_023c;
																									IL_0461:
																									if (3 > b)
																									{
																										goto end_IL_023c;
																									}
																									goto IL_046f;
																								}
																								break;
																							}
																							goto IL_02b3;
																							IL_03b9:
																							ptr2 += 8;
																							goto end_IL_026c;
																							IL_02b3:
																							array[num5] = 0;
																							goto IL_02c1;
																							IL_02c1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03a1;
																							IL_03a1:
																							array2[num5] = null;
																							goto IL_03ab;
																							IL_03ab:
																							num5++;
																							goto IL_03b9;
																						}
																						goto IL_04cf;
																					}
																					goto IL_02e9;
																					IL_0419:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_026c;
																					IL_02e9:
																					if (8 >= b)
																					{
																						goto IL_02f7;
																					}
																					goto IL_03df;
																					IL_02f7:
																					if (8 <= b)
																					{
																						goto IL_0302;
																					}
																					goto IL_0380;
																					IL_0302:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 9;
																					goto IL_036d;
																					IL_036d:
																					num5 -= 2;
																					goto end_IL_026c;
																					IL_0380:
																					if (6 >= b)
																					{
																						goto IL_038e;
																					}
																					goto IL_0490;
																					IL_038e:
																					if (6 > b)
																					{
																						goto end_IL_023c;
																					}
																					goto IL_0507;
																					IL_0507:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0547;
																					IL_0547:
																					array[num5 - 2] = 0;
																					goto IL_055b;
																					IL_055b:
																					num5--;
																					goto end_IL_026c;
																					IL_0490:
																					if (7 < b)
																					{
																						goto end_IL_023c;
																					}
																					goto IL_049e;
																					IL_049e:
																					if (7 > b)
																					{
																						goto end_IL_023c;
																					}
																					goto IL_04ac;
																					IL_04ac:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04cf;
																					IL_04cf:
																					array[num5] = 0;
																					goto IL_04dd;
																					IL_04dd:
																					num5++;
																					num = 26;
																					goto IL_04f4;
																					IL_04f4:
																					ptr2 += 8;
																					goto end_IL_026c;
																					IL_03df:
																					if (9 < b)
																					{
																						goto IL_03ea;
																					}
																					goto IL_040b;
																					IL_03ea:
																					if (10 < b)
																					{
																						goto end_IL_023c;
																					}
																					goto IL_03f8;
																					IL_03f8:
																					if (10 <= b)
																					{
																					}
																					goto end_IL_023c;
																					IL_040b:
																					if (9 > b)
																					{
																						goto end_IL_023c;
																					}
																					goto IL_0419;
																					continue;
																					end_IL_022c:
																					break;
																				}
																				continue;
																				end_IL_023c:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_026c;
																		continue;
																		end_IL_024c:
																		break;
																	}
																	continue;
																	end_IL_025c:
																	break;
																}
																continue;
																end_IL_026c:
																break;
															}
															continue;
														}
														goto IL_0690;
														IL_0690:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_05d9:
														break;
													}
													continue;
													end_IL_05ec:
													break;
												}
												continue;
												end_IL_05f7:
												break;
											}
											continue;
											end_IL_060a:
											break;
										}
										continue;
										end_IL_0615:
										break;
									}
									continue;
									end_IL_062a:
									break;
								}
								continue;
								end_IL_063a:
								break;
							}
							continue;
							end_IL_064a:
							break;
						}
						continue;
						end_IL_065a:
						break;
					}
					continue;
					end_IL_066a:
					break;
				}
				continue;
				end_IL_0675:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_2, int int_3)
	{
		int num = 2;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								IL_06c7:
								long[] array4 = new long[3];
								while (true)
								{
									IL_06b2:
									array3[0] = int_2;
									while (true)
									{
										IL_0694:
										array3[1] = int_3;
										num = 22;
										while (true)
										{
											IL_0680:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setServerIdentityObjectReadLines.StringComparergetLastWriteTimeUtc);
											num = 23;
											while (true)
											{
												IL_066d:
												byte* ptr2 = ptr;
												num = 42;
												while (true)
												{
													IL_0662:
													num = 73;
													while (true)
													{
														IL_064f:
														if (num4 != 1)
														{
															while (true)
															{
																IL_0269:
																byte b = *ptr2;
																while (true)
																{
																	IL_0250:
																	ptr2++;
																	num = 29;
																	while (true)
																	{
																		IL_0240:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0220:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_0210:
																							if (7 < b)
																							{
																								while (true)
																								{
																									IL_0203:
																									if (8 < b)
																									{
																										while (9 >= b)
																										{
																											num = 112;
																											while (true)
																											{
																												if (num != 112)
																												{
																													if (num != 1093)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 10:
																														goto IL_01f0;
																													case 13:
																														goto IL_0203;
																													case 16:
																													case 80:
																														goto IL_0210;
																													case 60:
																														goto IL_0220;
																													case 44:
																														goto IL_0230;
																													case 29:
																														goto IL_0240;
																													case 35:
																														goto IL_0250;
																													case 51:
																													case 82:
																														goto IL_0269;
																													case 8:
																														goto IL_0274;
																													case 31:
																													case 76:
																														goto IL_0282;
																													case 87:
																														goto IL_02c2;
																													case 79:
																														goto IL_02d6;
																													case 15:
																													case 90:
																														goto IL_02f7;
																													case 88:
																														goto IL_0313;
																													case 17:
																													case 34:
																														goto IL_031e;
																													case 62:
																														goto IL_0337;
																													case 55:
																														goto IL_0345;
																													case 54:
																														goto IL_0353;
																													case 27:
																														goto IL_0366;
																													case 58:
																														goto IL_0374;
																													case 0:
																													case 50:
																														goto IL_0382;
																													case 98:
																														goto IL_03c2;
																													case 93:
																														goto IL_03df;
																													case 6:
																														goto IL_03fb;
																													case 9:
																													case 83:
																														goto IL_0406;
																													case 78:
																														goto IL_0414;
																													case 36:
																														goto IL_0437;
																													case 46:
																														goto IL_0441;
																													case 59:
																														goto IL_044f;
																													case 102:
																														goto IL_0462;
																													case 104:
																														goto IL_0470;
																													case 53:
																														goto IL_047b;
																													case 65:
																														goto IL_0486;
																													case 30:
																													case 92:
																														goto IL_04a7;
																													case 19:
																														goto IL_04e7;
																													case 48:
																														goto IL_04fb;
																													case 52:
																														goto IL_050e;
																													case 20:
																														goto IL_051c;
																													case 77:
																														goto IL_052a;
																													case 45:
																													case 56:
																														goto IL_0535;
																													case 21:
																														goto IL_0575;
																													case 95:
																														goto IL_0589;
																													case 105:
																														goto IL_05a7;
																													case 4:
																													case 5:
																													case 18:
																													case 25:
																													case 26:
																													case 33:
																													case 37:
																													case 39:
																													case 40:
																													case 41:
																													case 43:
																													case 68:
																													case 70:
																													case 71:
																													case 74:
																													case 81:
																													case 85:
																													case 86:
																													case 91:
																													case 96:
																													case 99:
																													case 103:
																														goto end_IL_01f0;
																													case 66:
																														goto IL_05d5;
																													case 57:
																														goto IL_05e3;
																													case 100:
																														goto IL_05f1;
																													case 38:
																													case 94:
																														goto IL_0601;
																													case 63:
																														goto IL_062a;
																													case 72:
																														goto IL_0638;
																													case 3:
																													case 28:
																													case 32:
																													case 47:
																													case 64:
																													case 69:
																													case 73:
																													case 84:
																													case 89:
																													case 101:
																														goto IL_064f;
																													case 42:
																														goto IL_0662;
																													case 23:
																														goto IL_066d;
																													case 22:
																														goto IL_0680;
																													case 61:
																														goto IL_0694;
																													case 49:
																														goto IL_06b2;
																													case 14:
																														goto IL_06c7;
																													case 75:
																													case 97:
																														goto end_IL_01dd;
																													case 24:
																														goto end_IL_06d7;
																													case 12:
																													case 67:
																														goto end_IL_06e7;
																													case 1:
																														goto end_IL_06f7;
																													case 2:
																														goto end_IL_0707;
																													case 7:
																													case 11:
																														goto IL_0722;
																													}
																													continue;
																												}
																												if (9 > b)
																												{
																													goto end_IL_01f0;
																												}
																												goto IL_02f7;
																												IL_02f7:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												goto IL_064f;
																												continue;
																												end_IL_01dd:
																												break;
																											}
																											goto end_IL_0240;
																											continue;
																											end_IL_01f0:
																											break;
																											IL_01f0:;
																										}
																										break;
																									}
																									goto IL_0274;
																									IL_02d6:
																									num6--;
																									goto IL_064f;
																									IL_0274:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0282;
																									IL_0282:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_02c2;
																									IL_02c2:
																									array[num6 - 2] = 0;
																									goto IL_02d6;
																								}
																								break;
																							}
																							goto IL_0313;
																							IL_03df:
																							num6--;
																							num = 64;
																							goto IL_064f;
																							IL_0313:
																							if (7 <= b)
																							{
																								goto IL_031e;
																							}
																							goto IL_0366;
																							IL_031e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0337;
																							IL_0337:
																							array[num6] = 0;
																							goto IL_0345;
																							IL_0345:
																							num6++;
																							goto IL_0353;
																							IL_0353:
																							ptr2 += 8;
																							goto IL_064f;
																							IL_0366:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0374;
																							IL_0374:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0382;
																							IL_0382:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_03c2;
																							IL_03c2:
																							array[num6 - 2] = 0;
																							num = 93;
																							goto IL_03df;
																						}
																						break;
																					}
																					goto IL_03fb;
																					IL_0601:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_062a;
																					IL_03fb:
																					if (5 <= b)
																					{
																						goto IL_0406;
																					}
																					goto IL_0462;
																					IL_0406:
																					array[num6] = 0;
																					goto IL_0414;
																					IL_0414:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0437;
																					IL_0437:
																					array2[num6] = null;
																					goto IL_0441;
																					IL_0441:
																					num6++;
																					goto IL_044f;
																					IL_044f:
																					ptr2 += 8;
																					goto IL_064f;
																					IL_0462:
																					if (2 >= b)
																					{
																						goto IL_0470;
																					}
																					goto IL_050e;
																					IL_0470:
																					if (2 > b)
																					{
																						goto IL_047b;
																					}
																					goto IL_04a7;
																					IL_047b:
																					if (1 < b)
																					{
																						num = 85;
																						break;
																					}
																					goto IL_0486;
																					IL_0486:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_062a:
																					ptr2 += 8;
																					goto IL_0638;
																					IL_04a7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_04e7;
																					IL_04e7:
																					array[num6 - 2] = 0;
																					goto IL_04fb;
																					IL_04fb:
																					num6--;
																					goto IL_064f;
																					IL_050e:
																					if (3 < b)
																					{
																						goto IL_051c;
																					}
																					goto IL_05a7;
																					IL_051c:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_052a;
																					IL_052a:
																					if (4 > b)
																					{
																						num = 81;
																						break;
																					}
																					goto IL_0535;
																					IL_0535:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0575;
																					IL_0575:
																					array[num6 - 2] = 0;
																					goto IL_0589;
																					IL_0589:
																					num6--;
																					goto IL_064f;
																					IL_0638:
																					num6--;
																					num = 32;
																					goto IL_064f;
																					IL_05a7:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0601;
																				}
																				break;
																				IL_0230:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05d5;
																		IL_05f1:
																		ptr2 += 8;
																		goto IL_064f;
																		IL_05e3:
																		num6++;
																		goto IL_05f1;
																		IL_05d5:
																		array[num6] = 0;
																		goto IL_05e3;
																		continue;
																		end_IL_0240:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_0722;
														IL_0722:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_06d7:
							break;
						}
						continue;
						end_IL_06e7:
						break;
					}
					continue;
					end_IL_06f7:
					break;
				}
				continue;
				end_IL_0707:
				break;
			}
		}
	}

	private unsafe static int smethod_17()
	{
		int num = 144;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EntityDeclIClientFormatterSinkProvider.GetLifetimeServiceTaskWrapperAsyncResult);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 7;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_031c:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02fc:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02ec:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02df:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02cf:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02bf:
																											if (2 >= b)
																											{
																												while (true)
																												{
																													IL_02af:
																													if (2 > b)
																													{
																														while (1 >= b)
																														{
																															num = 155;
																															while (true)
																															{
																																if (num != 155)
																																{
																																	if (num != 1136)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 21:
																																	case 76:
																																		goto IL_029c;
																																	case 22:
																																		goto IL_02af;
																																	case 51:
																																	case 145:
																																		goto IL_02bf;
																																	case 124:
																																		goto IL_02cf;
																																	case 112:
																																		goto IL_02df;
																																	case 122:
																																		goto IL_02ec;
																																	case 131:
																																		goto IL_02fc;
																																	case 35:
																																		goto IL_030c;
																																	case 38:
																																		goto IL_031c;
																																	case 7:
																																		goto end_IL_031c;
																																	case 49:
																																	case 84:
																																		goto end_IL_032c;
																																	case 27:
																																	case 33:
																																		goto IL_0350;
																																	case 54:
																																		goto IL_035e;
																																	case 73:
																																	case 86:
																																		goto IL_036c;
																																	case 44:
																																		goto IL_03ab;
																																	case 23:
																																	case 98:
																																		goto IL_03be;
																																	case 60:
																																		goto IL_03dc;
																																	case 79:
																																		goto IL_03ea;
																																	case 100:
																																		goto IL_03fd;
																																	case 96:
																																		goto IL_040b;
																																	case 78:
																																	case 101:
																																		goto IL_0419;
																																	case 125:
																																		goto IL_0442;
																																	case 53:
																																		goto end_IL_0289;
																																	case 110:
																																	case 138:
																																		goto IL_0463;
																																	case 0:
																																		goto IL_0471;
																																	case 1:
																																	case 130:
																																		goto IL_047f;
																																	case 119:
																																	case 142:
																																		goto IL_04aa;
																																	case 5:
																																		goto IL_04b8;
																																	case 41:
																																	case 50:
																																		goto IL_04c6;
																																	case 126:
																																		goto IL_04d4;
																																	case 31:
																																		goto IL_04ec;
																																	case 82:
																																		goto IL_04fa;
																																	case 146:
																																		goto IL_050d;
																																	case 34:
																																	case 36:
																																		goto IL_053f;
																																	case 135:
																																		goto IL_0558;
																																	case 39:
																																		goto IL_0566;
																																	case 6:
																																		goto IL_0574;
																																	case 48:
																																	case 109:
																																		goto IL_0587;
																																	case 133:
																																		goto IL_05c7;
																																	case 107:
																																		goto IL_05db;
																																	case 18:
																																	case 94:
																																		goto IL_05ee;
																																	case 108:
																																		goto IL_0606;
																																	case 139:
																																		goto IL_0614;
																																	case 28:
																																	case 97:
																																		goto IL_061f;
																																	case 57:
																																		goto IL_065f;
																																	case 20:
																																		goto IL_0673;
																																	case 25:
																																		goto IL_0686;
																																	case 46:
																																	case 118:
																																		goto IL_0694;
																																	case 30:
																																		goto IL_06a2;
																																	case 2:
																																	case 72:
																																		goto IL_06b0;
																																	case 14:
																																		goto IL_06f4;
																																	case 140:
																																		goto IL_0708;
																																	case 37:
																																		goto IL_0724;
																																	case 90:
																																	case 136:
																																		goto IL_072f;
																																	case 102:
																																		goto IL_073d;
																																	case 123:
																																	case 147:
																																		goto IL_0759;
																																	case 58:
																																		goto IL_0767;
																																	case 70:
																																		goto IL_078a;
																																	case 114:
																																		goto IL_0794;
																																	case 93:
																																		goto IL_07a2;
																																	case 26:
																																		goto IL_07b5;
																																	case 91:
																																	case 128:
																																		goto IL_07c0;
																																	case 8:
																																		goto IL_07ce;
																																	case 120:
																																		goto IL_07e1;
																																	case 45:
																																	case 103:
																																		goto IL_07ec;
																																	case 80:
																																		goto IL_0808;
																																	case 32:
																																		goto IL_0813;
																																	case 15:
																																	case 47:
																																		goto IL_081e;
																																	case 89:
																																		goto IL_0880;
																																	case 3:
																																	case 9:
																																	case 11:
																																	case 16:
																																	case 17:
																																	case 19:
																																	case 24:
																																	case 40:
																																	case 43:
																																	case 52:
																																	case 55:
																																	case 61:
																																	case 63:
																																	case 65:
																																	case 67:
																																	case 74:
																																	case 75:
																																	case 87:
																																	case 95:
																																	case 99:
																																	case 104:
																																	case 105:
																																	case 106:
																																	case 116:
																																	case 117:
																																	case 127:
																																	case 132:
																																		goto end_IL_029c;
																																	case 10:
																																	case 12:
																																	case 13:
																																	case 29:
																																	case 59:
																																	case 64:
																																	case 68:
																																	case 69:
																																	case 71:
																																	case 77:
																																	case 83:
																																	case 85:
																																	case 88:
																																	case 92:
																																	case 111:
																																	case 113:
																																	case 129:
																																	case 137:
																																		goto end_IL_033c;
																																	case 62:
																																		goto end_IL_08a3;
																																	case 81:
																																		goto end_IL_08b6;
																																	case 115:
																																		goto end_IL_08c0;
																																	case 4:
																																		goto end_IL_08cb;
																																	case 56:
																																	case 134:
																																		goto end_IL_08db;
																																	case 141:
																																		goto end_IL_08eb;
																																	case 66:
																																	case 121:
																																		goto end_IL_08fb;
																																	case 143:
																																		goto end_IL_090b;
																																	case 144:
																																		goto end_IL_091b;
																																	case 42:
																																	case 148:
																																		goto IL_0936;
																																	}
																																	continue;
																																}
																																if (1 > b)
																																{
																																	num = 19;
																																	goto end_IL_029c;
																																}
																																goto IL_053f;
																																IL_053f:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																goto IL_0558;
																																IL_0566:
																																num5++;
																																goto IL_0574;
																																IL_0558:
																																array[num5] = 0;
																																goto IL_0566;
																																IL_0574:
																																ptr2 += 8;
																																goto end_IL_033c;
																																continue;
																																end_IL_0289:
																																break;
																															}
																															goto IL_0450;
																															continue;
																															end_IL_029c:
																															break;
																															IL_029c:;
																														}
																														break;
																													}
																													goto IL_0587;
																													IL_05db:
																													num5--;
																													goto end_IL_033c;
																													IL_0587:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_05c7;
																													IL_05c7:
																													array[num5 - 2] = 0;
																													goto IL_05db;
																												}
																												break;
																											}
																											goto IL_0463;
																											IL_050d:
																											array[num5 - 1] = 5;
																											goto end_IL_033c;
																											IL_0463:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0471;
																											IL_0471:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_047f;
																											IL_047f:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_050d;
																										}
																										break;
																									}
																									goto IL_03be;
																									IL_03ea:
																									num5--;
																									goto end_IL_033c;
																									IL_03be:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_03dc;
																									IL_03dc:
																									ptr2 += 8;
																									goto IL_03ea;
																								}
																								break;
																							}
																							goto IL_0350;
																							IL_0450:
																							num5--;
																							goto end_IL_033c;
																							IL_0350:
																							if (6 >= b)
																							{
																								goto IL_035e;
																							}
																							goto IL_03fd;
																							IL_035e:
																							if (6 <= b)
																							{
																								goto IL_036c;
																							}
																							goto IL_04aa;
																							IL_036c:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03ab;
																							IL_03ab:
																							num5 -= 3;
																							goto end_IL_033c;
																							IL_04aa:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_04b8;
																							IL_04b8:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_04c6;
																							IL_04c6:
																							array[num5] = 5;
																							goto IL_04d4;
																							IL_04d4:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_04ec;
																							IL_04ec:
																							num5++;
																							goto IL_04fa;
																							IL_04fa:
																							ptr2 += 8;
																							goto end_IL_033c;
																							IL_03fd:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_040b;
																							IL_040b:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0419;
																							IL_0419:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0442;
																							IL_0442:
																							ptr2 += 8;
																							goto IL_0450;
																						}
																						break;
																					}
																					goto IL_05ee;
																					IL_05ee:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_033c;
																				}
																				break;
																			}
																			goto IL_0606;
																			IL_081e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0880;
																			IL_0606:
																			if (12 >= b)
																			{
																				goto IL_0614;
																			}
																			goto IL_07b5;
																			IL_0614:
																			if (12 <= b)
																			{
																				goto IL_061f;
																			}
																			goto IL_0686;
																			IL_061f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_065f;
																			IL_065f:
																			array[num5 - 2] = 0;
																			goto IL_0673;
																			IL_0673:
																			num5--;
																			goto end_IL_033c;
																			IL_0686:
																			if (10 < b)
																			{
																				goto IL_0694;
																			}
																			goto IL_0724;
																			IL_0694:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_06a2;
																			IL_06a2:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_06b0;
																			IL_06b0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06f4;
																			IL_06f4:
																			array[num5 - 2] = 0;
																			goto IL_0708;
																			IL_0708:
																			num5--;
																			num = 113;
																			goto end_IL_033c;
																			IL_0724:
																			if (10 > b)
																			{
																				goto IL_072f;
																			}
																			goto IL_0759;
																			IL_072f:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_073d;
																			IL_073d:
																			if (9 <= b)
																			{
																				goto end_IL_033c;
																			}
																			num = 105;
																			break;
																			IL_0880:
																			num5 -= 2;
																			goto end_IL_033c;
																			IL_0759:
																			array[num5] = 0;
																			goto IL_0767;
																			IL_0767:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_078a;
																			IL_078a:
																			array2[num5] = null;
																			goto IL_0794;
																			IL_0794:
																			num5++;
																			goto IL_07a2;
																			IL_07a2:
																			ptr2 += 8;
																			goto end_IL_033c;
																			IL_07b5:
																			if (14 < b)
																			{
																				goto IL_07c0;
																			}
																			goto IL_07e1;
																			IL_07c0:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_07ce;
																			IL_07ce:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_07e1:
																			if (14 <= b)
																			{
																				goto IL_07ec;
																			}
																			goto IL_0808;
																			IL_07ec:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_033c;
																			IL_0808:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0813;
																			IL_0813:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_081e;
																		}
																		break;
																		IL_030c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_033c;
																continue;
																end_IL_031c:
																break;
															}
															continue;
															end_IL_032c:
															break;
														}
														continue;
														end_IL_033c:
														break;
													}
													continue;
												}
												goto IL_0936;
												IL_0936:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a3:
												break;
											}
											continue;
											end_IL_08b6:
											break;
										}
										continue;
										end_IL_08c0:
										break;
									}
									continue;
									end_IL_08cb:
									break;
								}
								continue;
								end_IL_08db:
								break;
							}
							continue;
							end_IL_08eb:
							break;
						}
						continue;
						end_IL_08fb:
						break;
					}
					continue;
					end_IL_090b:
					break;
				}
				continue;
				end_IL_091b:
				break;
			}
		}
	}
}
