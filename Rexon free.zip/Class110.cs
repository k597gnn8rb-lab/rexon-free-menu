using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Vibrating Spring Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns vibrating springs.", false, 12, ModType.const_0, false)]
internal class Class110 : Class93
{
	private static bool bool_0;

	private static float float_0;

	private static bool bool_1;

	private static double double_1;

	private static IntPtr[] CheckedOneWayGetImplTypeCustData;

	private static IntPtr[] stateContinueParsing;

	private static IntPtr[] getIsStoppedgetResourceScope;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0371, IL_0384, IL_0397, IL_03a4, IL_03b4, IL_03c1, IL_03d1, IL_03e1, IL_03f1, IL_03fc, IL_040c, IL_041a, IL_0428, IL_0436, IL_0454, IL_0462, IL_046d, IL_047b, IL_0489, IL_04eb, IL_0507, IL_0515, IL_0555, IL_0569, IL_057c, IL_0587, IL_0595, IL_05ad, IL_05c0, IL_05cb, IL_05d6, IL_05e9, IL_05f4, IL_0602, IL_0615, IL_0633, IL_0641, IL_0654, IL_0662, IL_068b, IL_06a4, IL_06b2, IL_06cf, IL_071e, IL_0728, IL_0755, IL_076b, IL_0779, IL_0789, IL_0797, IL_07aa, IL_07c2, IL_07d5, IL_07e3, IL_07f1, IL_0804, IL_0812, IL_0820, IL_082e, IL_086e, IL_0882, IL_0895, IL_08a8, IL_08b6, IL_08c4, IL_0904, IL_0918, IL_092b, IL_0943, IL_096a, IL_098e, IL_09a6, IL_09b9, IL_09c7, IL_09d5, IL_09f1, IL_09fc, IL_0a0a, IL_0a48, IL_0a5b, IL_0a69, IL_0a77, IL_0a8b, IL_0ac3, IL_0ad6, IL_0b16, IL_0b2a, IL_0b3d, IL_0b4b, IL_0b56, IL_0b64, IL_0b72, IL_0b80, IL_0ba3, IL_0bad, IL_0bbb, IL_0bce, IL_0bdc, IL_0c05, IL_0c13, IL_0c26, IL_0c31, IL_0c71, IL_0c85, IL_0c95, IL_0ca0, IL_0cab, IL_0cc4, IL_0cd2, IL_0ce0, IL_0cee, IL_0d01, IL_0d0b, IL_0d1f, IL_0d2f, IL_0d3f, IL_0d4f, IL_0d5f, IL_0d6f, IL_0d7f, IL_0d8f, IL_0d9f, IL_0dc3 are reachable both inside and outside the pinned region starting at IL_0db4. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 37;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef24 = default(int);
				ref int reference = ref __rxRef24;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					num = 36;
					while (true)
					{
						IL_0d9f:
						num2 = 1;
						while (true)
						{
							IL_0d8f:
							num3 = num2 * 4;
							while (true)
							{
								IL_0d7f:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d6f:
									array2 = new byte[4];
									while (true)
									{
										IL_0d5f:
										array3 = new object[4];
										while (true)
										{
											IL_0d4f:
											array4 = new int[4];
											while (true)
											{
												IL_0d3f:
												array5 = new int[6];
												while (true)
												{
													IL_0d2f:
													array6 = new long[4];
													while (true)
													{
														IL_0d1f:
														array7 = new object[13];
														while (true)
														{
															IL_0d0b:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRandomlyGeneratedMethodRental.getXmlTypeNamespaceTYPEFLAGFDUAL);
															num = 137;
															while (true)
															{
																IL_0d01:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_03f1:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_03e1:
																				ptr2++;
																				while (true)
																				{
																					IL_03d1:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_03b4:
																								if (11 >= b)
																								{
																									while (11 > b)
																									{
																										while (true)
																										{
																											IL_0397:
																											if (5 >= b)
																											{
																												while (true)
																												{
																													IL_0384:
																													if (5 <= b)
																													{
																														num = 213;
																														while (true)
																														{
																															if (num != 213)
																															{
																																if (num != 1194)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 37:
																																	break;
																																default:
																																	continue;
																																case 187:
																																	goto IL_0384;
																																case 85:
																																	goto IL_0397;
																																case 126:
																																	goto IL_03a4;
																																case 28:
																																	goto IL_03b4;
																																case 49:
																																	goto IL_03c1;
																																case 79:
																																	goto IL_03d1;
																																case 50:
																																	goto IL_03e1;
																																case 6:
																																case 144:
																																	goto IL_03f1;
																																case 25:
																																	goto IL_03fc;
																																case 86:
																																case 140:
																																	goto IL_040c;
																																case 71:
																																case 123:
																																	goto IL_041a;
																																case 2:
																																	goto IL_0428;
																																case 10:
																																case 113:
																																	goto IL_0436;
																																case 141:
																																	goto IL_0454;
																																case 39:
																																case 93:
																																	goto IL_0462;
																																case 128:
																																	goto IL_047b;
																																case 101:
																																case 130:
																																	goto IL_0489;
																																case 136:
																																	goto IL_04eb;
																																case 7:
																																	goto IL_0507;
																																case 11:
																																case 114:
																																	goto IL_0515;
																																case 134:
																																	goto IL_0555;
																																case 38:
																																	goto IL_0569;
																																case 165:
																																	goto IL_057c;
																																case 35:
																																case 45:
																																	goto IL_0587;
																																case 98:
																																	goto IL_0595;
																																case 142:
																																	goto IL_05ad;
																																case 138:
																																	goto IL_05c0;
																																case 14:
																																	goto IL_05cb;
																																case 43:
																																case 161:
																																	goto IL_05d6;
																																case 84:
																																	goto IL_05e9;
																																case 29:
																																case 155:
																																	goto IL_05f4;
																																case 91:
																																	goto IL_0602;
																																case 21:
																																case 171:
																																	goto IL_0615;
																																case 42:
																																	goto IL_0633;
																																case 95:
																																	goto IL_0641;
																																case 177:
																																	goto IL_0654;
																																case 56:
																																case 152:
																																	goto IL_0662;
																																case 61:
																																	goto IL_068b;
																																case 178:
																																	goto IL_06a4;
																																case 63:
																																case 127:
																																	goto IL_06b2;
																																case 183:
																																	goto IL_076b;
																																case 40:
																																	goto IL_0779;
																																case 186:
																																	goto IL_0789;
																																case 176:
																																	goto IL_0797;
																																case 100:
																																case 194:
																																	goto IL_07aa;
																																case 195:
																																	goto IL_07c2;
																																case 197:
																																	goto IL_07d5;
																																case 73:
																																	goto IL_07e3;
																																case 33:
																																	goto IL_07f1;
																																case 199:
																																	goto IL_0804;
																																case 70:
																																	goto IL_0812;
																																case 87:
																																	goto IL_0820;
																																case 83:
																																case 175:
																																	goto IL_082e;
																																case 192:
																																	goto IL_086e;
																																case 180:
																																	goto IL_0882;
																																case 57:
																																case 147:
																																	goto IL_0895;
																																case 62:
																																case 200:
																																	goto IL_08a8;
																																case 198:
																																	goto IL_08b6;
																																case 112:
																																case 132:
																																	goto IL_08c4;
																																case 118:
																																	goto IL_0904;
																																case 156:
																																	goto IL_0918;
																																case 129:
																																case 201:
																																	goto IL_092b;
																																case 110:
																																	goto IL_0943;
																																case 55:
																																	goto IL_096a;
																																case 115:
																																	goto IL_098e;
																																case 196:
																																	goto IL_09a6;
																																case 125:
																																case 205:
																																	goto IL_09b9;
																																case 47:
																																	goto IL_09c7;
																																case 46:
																																case 173:
																																	goto IL_09d5;
																																case 206:
																																	goto IL_09f1;
																																case 203:
																																	goto IL_09fc;
																																case 15:
																																case 160:
																																	goto IL_0a0a;
																																case 184:
																																	goto IL_0a48;
																																case 122:
																																	goto IL_0a5b;
																																case 103:
																																	goto IL_0a69;
																																case 26:
																																case 44:
																																	goto IL_0a77;
																																case 54:
																																	goto IL_0a8b;
																																case 162:
																																	goto IL_0ac3;
																																case 27:
																																	goto IL_0ad6;
																																case 77:
																																	goto IL_0b16;
																																case 22:
																																	goto IL_0b2a;
																																case 34:
																																	goto IL_0b3d;
																																case 107:
																																case 145:
																																	goto IL_0b4b;
																																case 102:
																																case 193:
																																	goto IL_0b56;
																																case 202:
																																	goto IL_0b64;
																																case 108:
																																case 135:
																																	goto IL_0b72;
																																case 96:
																																	goto IL_0b80;
																																case 8:
																																	goto IL_0ba3;
																																case 1:
																																	goto IL_0bad;
																																case 204:
																																	goto IL_0bbb;
																																case 188:
																																	goto IL_0bce;
																																case 41:
																																case 190:
																																	goto IL_0bdc;
																																case 31:
																																	goto IL_0c05;
																																case 99:
																																	goto IL_0c13;
																																case 90:
																																	goto IL_0c26;
																																case 64:
																																case 174:
																																	goto IL_0c31;
																																case 189:
																																	goto IL_0c71;
																																case 5:
																																	goto IL_0c85;
																																case 166:
																																	goto IL_0c95;
																																case 82:
																																	goto IL_0ca0;
																																case 0:
																																case 4:
																																case 16:
																																case 17:
																																case 23:
																																case 24:
																																case 30:
																																case 32:
																																case 51:
																																case 53:
																																case 59:
																																case 66:
																																case 67:
																																case 78:
																																case 80:
																																case 89:
																																case 92:
																																case 94:
																																case 105:
																																case 111:
																																case 116:
																																case 117:
																																case 119:
																																case 120:
																																case 131:
																																case 133:
																																case 153:
																																case 157:
																																case 158:
																																case 163:
																																case 164:
																																case 167:
																																case 168:
																																case 169:
																																case 170:
																																case 172:
																																case 181:
																																case 185:
																																	goto end_IL_0371;
																																case 106:
																																	goto IL_0cc4;
																																case 72:
																																	goto IL_0cd2;
																																case 12:
																																	goto IL_0ce0;
																																case 3:
																																case 9:
																																case 13:
																																case 48:
																																case 58:
																																case 60:
																																case 65:
																																case 68:
																																case 74:
																																case 75:
																																case 76:
																																case 81:
																																case 88:
																																case 104:
																																case 124:
																																case 139:
																																case 143:
																																case 148:
																																case 149:
																																case 151:
																																case 154:
																																case 159:
																																case 179:
																																case 182:
																																	goto end_IL_03a4;
																																case 137:
																																	goto IL_0d01;
																																case 109:
																																	goto IL_0d0b;
																																case 20:
																																	goto IL_0d1f;
																																case 19:
																																	goto IL_0d2f;
																																case 191:
																																	goto IL_0d3f;
																																case 97:
																																	goto IL_0d4f;
																																case 150:
																																	goto IL_0d5f;
																																case 52:
																																	goto IL_0d6f;
																																case 146:
																																	goto IL_0d7f;
																																case 121:
																																	goto IL_0d8f;
																																case 36:
																																	goto IL_0d9f;
																																case 18:
																																case 69:
																																	goto IL_0dc3;
																																}
																																goto end_IL_0cee;
																															}
																															goto IL_0ad6;
																															IL_0b16:
																															array2[num6 - 2] = 0;
																															goto IL_0b2a;
																															IL_0b2a:
																															num6--;
																															goto end_IL_03a4;
																															IL_0ad6:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_0b16;
																															continue;
																															end_IL_0371:
																															break;
																														}
																														break;
																													}
																													goto IL_0b3d;
																													IL_0c95:
																													if (1 < b)
																													{
																														break;
																													}
																													goto IL_0ca0;
																													IL_0ca0:
																													if (1 <= b)
																													{
																													}
																													break;
																													IL_0b3d:
																													if (2 < b)
																													{
																														goto IL_0b4b;
																													}
																													goto IL_0c26;
																													IL_0b4b:
																													if (3 < b)
																													{
																														goto IL_0b56;
																													}
																													goto IL_0bce;
																													IL_0b56:
																													if (4 < b)
																													{
																														break;
																													}
																													goto IL_0b64;
																													IL_0b64:
																													if (4 > b)
																													{
																														break;
																													}
																													goto IL_0b72;
																													IL_0b72:
																													array2[num6] = 0;
																													goto IL_0b80;
																													IL_0b80:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																													goto IL_0ba3;
																													IL_0ba3:
																													array3[num6] = null;
																													goto IL_0bad;
																													IL_0bad:
																													num6++;
																													goto IL_0bbb;
																													IL_0bbb:
																													ptr2 += 8;
																													goto end_IL_03a4;
																													IL_0bce:
																													if (3 > b)
																													{
																														break;
																													}
																													goto IL_0bdc;
																													IL_0bdc:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0c05;
																													IL_0c05:
																													ptr2 += 8;
																													goto IL_0c13;
																													IL_0c13:
																													num6--;
																													goto end_IL_03a4;
																													IL_0c26:
																													if (2 <= b)
																													{
																														goto IL_0c31;
																													}
																													goto IL_0c95;
																													IL_0c31:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0c71;
																													IL_0c71:
																													array2[num6 - 2] = 0;
																													goto IL_0c85;
																													IL_0c85:
																													num6--;
																													goto end_IL_03a4;
																												}
																												break;
																											}
																											goto IL_03fc;
																											IL_0918:
																											num6--;
																											goto end_IL_03a4;
																											IL_03fc:
																											if (8 < b)
																											{
																												goto IL_0454;
																											}
																											goto IL_0804;
																											IL_0454:
																											if (9 < b)
																											{
																												goto IL_0462;
																											}
																											goto IL_0507;
																											IL_0462:
																											if (10 < b)
																											{
																												num = 157;
																												break;
																											}
																											goto IL_047b;
																											IL_0895:
																											num6--;
																											goto end_IL_03a4;
																											IL_047b:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_0489;
																											IL_0489:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_04eb;
																											IL_04eb:
																											num6 -= 2;
																											num = 74;
																											goto end_IL_03a4;
																											IL_0507:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_0515;
																											IL_0515:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0555;
																											IL_0555:
																											array2[num6 - 2] = 0;
																											goto IL_0569;
																											IL_0569:
																											num6--;
																											goto end_IL_03a4;
																											IL_0804:
																											if (8 > b)
																											{
																												goto IL_0812;
																											}
																											goto IL_0895;
																											IL_0812:
																											if (6 >= b)
																											{
																												goto IL_0820;
																											}
																											goto IL_08a8;
																											IL_0820:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_082e;
																											IL_082e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_086e;
																											IL_086e:
																											array2[num6 - 2] = 0;
																											goto IL_0882;
																											IL_0882:
																											num6--;
																											goto end_IL_03a4;
																											IL_08a8:
																											if (7 < b)
																											{
																												break;
																											}
																											goto IL_08b6;
																											IL_08b6:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_08c4;
																											IL_08c4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0904;
																											IL_0904:
																											array2[num6 - 2] = 0;
																											goto IL_0918;
																										}
																										goto end_IL_03c1;
																										continue;
																										end_IL_03a4:
																										break;
																										IL_03a4:;
																									}
																									break;
																								}
																								goto IL_040c;
																								IL_09a6:
																								num6++;
																								break;
																								IL_040c:
																								if (16 < b)
																								{
																									goto IL_041a;
																								}
																								goto IL_057c;
																								IL_041a:
																								if (19 >= b)
																								{
																									goto IL_0428;
																								}
																								goto IL_076b;
																								IL_0428:
																								if (19 <= b)
																								{
																									goto IL_0436;
																								}
																								goto IL_09f1;
																								IL_0436:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_07d5;
																								IL_07d5:
																								array2[num6] = 1;
																								goto IL_07e3;
																								IL_07e3:
																								num6++;
																								goto IL_07f1;
																								IL_07f1:
																								ptr2 += 16;
																								break;
																								IL_09f1:
																								if (17 >= b)
																								{
																									goto IL_09fc;
																								}
																								goto IL_0a5b;
																								IL_09fc:
																								if (17 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_0a0a;
																								IL_0a0a:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_0a48;
																								IL_0a48:
																								num6 -= 3;
																								break;
																								IL_0a5b:
																								if (18 < b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_0a69;
																								IL_0a69:
																								if (18 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_0a77;
																								IL_0a77:
																								array2[num6 - 1] = 5;
																								goto IL_0a8b;
																								IL_0a8b:
																								array3[num6 - 1] = ((delegate*<string[], string>)CheckedOneWayGetImplTypeCustData[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0ac3;
																								IL_0ac3:
																								ptr2 += 8;
																								break;
																								IL_076b:
																								if (20 >= b)
																								{
																									goto IL_0779;
																								}
																								goto IL_09b9;
																								IL_0779:
																								if (20 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_07aa;
																								IL_07aa:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_09b9:
																								if (21 < b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_09c7;
																								IL_09c7:
																								if (21 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_09d5;
																								IL_09d5:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								break;
																								IL_057c:
																								if (16 <= b)
																								{
																									goto IL_0587;
																								}
																								goto IL_05c0;
																								IL_0587:
																								array2[num6] = 5;
																								goto IL_0595;
																								IL_0595:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_05ad;
																								IL_05ad:
																								num6++;
																								goto IL_07c2;
																								IL_07c2:
																								ptr2 += 8;
																								break;
																								IL_05c0:
																								if (13 >= b)
																								{
																									goto IL_05cb;
																								}
																								goto IL_05e9;
																								IL_05cb:
																								if (13 > b)
																								{
																									goto IL_05d6;
																								}
																								goto IL_0615;
																								IL_05d6:
																								if (12 < b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_06a4;
																								IL_06a4:
																								if (12 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_06b2;
																								IL_06b2:
																								array8 = array3;
																								num9 = num6;
																								if (array == null)
																								{
																									goto IL_06c1;
																								}
																								num10 = ptr2;
																								byte b2 = *num10;
																								ptr2 = num10 + 4;
																								int num11 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num11;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0789;
																								IL_0654:
																								if (14 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_0662;
																								IL_0662:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_068b;
																								IL_068b:
																								array2[num6 - 1] = 5;
																								break;
																								IL_0789:
																								array2[num6] = 5;
																								goto IL_0797;
																								IL_0797:
																								num6++;
																								break;
																								IL_0615:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0633;
																								IL_0633:
																								ptr2 += 8;
																								goto IL_0641;
																								IL_0641:
																								num6--;
																								break;
																								IL_05e9:
																								if (14 < b)
																								{
																									goto IL_05f4;
																								}
																								goto IL_0654;
																								IL_05f4:
																								if (15 < b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_0602;
																								IL_0602:
																								if (15 > b)
																								{
																									goto end_IL_03c1;
																								}
																								goto IL_092b;
																								IL_092b:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0943;
																								IL_0943:
																								array4[num6 - 0] = array4[num6 - 1];
																								num = 55;
																								goto IL_096a;
																								IL_096a:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_098e;
																								IL_098e:
																								array3[num6] = array3[num6 - 1];
																								goto IL_09a6;
																							}
																							goto end_IL_03d1;
																							continue;
																							end_IL_03c1:
																							break;
																							IL_03c1:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0cc4;
																					IL_0ce0:
																					ptr2 += 8;
																					break;
																					IL_0cd2:
																					num6++;
																					goto IL_0ce0;
																					IL_0cc4:
																					array2[num6] = 0;
																					goto IL_0cd2;
																					continue;
																					end_IL_03d1:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0dc3;
																	IL_0dc3:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0cee:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_06c1:
				while (true)
				{
					IL_06c1_2:
					array = new byte[4];
					while (true)
					{
						IL_06cf:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0797_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_03f1_2:
											byte b = *ptr2;
											while (true)
											{
												IL_03e1_2:
												ptr2++;
												while (true)
												{
													IL_03d1_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03b4_2:
																if (11 >= b)
																{
																	while (11 > b)
																	{
																		while (true)
																		{
																			IL_0397_2:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0384_2:
																					if (5 <= b)
																					{
																						num = 213;
																						while (true)
																						{
																							if (num != 213)
																							{
																								if (num != 1194)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 187:
																									goto IL_0384_2;
																								case 85:
																									goto IL_0397_2;
																								case 126:
																									goto IL_03a4_2;
																								case 28:
																									goto IL_03b4_2;
																								case 49:
																									goto IL_03c1_2;
																								case 79:
																									goto IL_03d1_2;
																								case 50:
																									goto IL_03e1_2;
																								case 6:
																								case 144:
																									goto IL_03f1_2;
																								case 25:
																									goto IL_03fc_2;
																								case 86:
																								case 140:
																									goto IL_040c_2;
																								case 71:
																								case 123:
																									goto IL_041a_2;
																								case 2:
																									goto IL_0428_2;
																								case 10:
																								case 113:
																									goto IL_0436_2;
																								case 141:
																									goto IL_0454_2;
																								case 39:
																								case 93:
																									goto IL_0462_2;
																								case 128:
																									goto IL_047b_2;
																								case 101:
																								case 130:
																									goto IL_0489_2;
																								case 136:
																									goto IL_04eb_2;
																								case 7:
																									goto IL_0507_2;
																								case 11:
																								case 114:
																									goto IL_0515_2;
																								case 134:
																									goto IL_0555_2;
																								case 38:
																									goto IL_0569_2;
																								case 165:
																									goto IL_057c_2;
																								case 35:
																								case 45:
																									goto IL_0587_2;
																								case 98:
																									goto IL_0595_2;
																								case 142:
																									goto IL_05ad_2;
																								case 138:
																									goto IL_05c0_2;
																								case 14:
																									goto IL_05cb_2;
																								case 43:
																								case 161:
																									goto IL_05d6_2;
																								case 84:
																									goto IL_05e9_2;
																								case 29:
																								case 155:
																									goto IL_05f4_2;
																								case 91:
																									goto IL_0602_2;
																								case 21:
																								case 171:
																									goto IL_0615_2;
																								case 42:
																									goto IL_0633_2;
																								case 95:
																									goto IL_0641_2;
																								case 177:
																									goto IL_0654_2;
																								case 56:
																								case 152:
																									goto IL_0662_2;
																								case 61:
																									goto IL_068b_2;
																								case 178:
																									goto IL_06a4_2;
																								case 63:
																								case 127:
																									goto IL_06b2_2;
																								case 183:
																									goto IL_076b_2;
																								case 40:
																									goto IL_0779_2;
																								case 186:
																									goto end_IL_0cee_2;
																								case 176:
																									goto IL_0797_2;
																								case 100:
																								case 194:
																									goto IL_07aa_2;
																								case 195:
																									goto IL_07c2_2;
																								case 197:
																									goto IL_07d5_2;
																								case 73:
																									goto IL_07e3_2;
																								case 33:
																									goto IL_07f1_2;
																								case 199:
																									goto IL_0804_2;
																								case 70:
																									goto IL_0812_2;
																								case 87:
																									goto IL_0820_2;
																								case 83:
																								case 175:
																									goto IL_082e_2;
																								case 192:
																									goto IL_086e_2;
																								case 180:
																									goto IL_0882_2;
																								case 57:
																								case 147:
																									goto IL_0895_2;
																								case 62:
																								case 200:
																									goto IL_08a8_2;
																								case 198:
																									goto IL_08b6_2;
																								case 112:
																								case 132:
																									goto IL_08c4_2;
																								case 118:
																									goto IL_0904_2;
																								case 156:
																									goto IL_0918_2;
																								case 129:
																								case 201:
																									goto IL_092b_2;
																								case 110:
																									goto IL_0943_2;
																								case 55:
																									goto IL_096a_2;
																								case 115:
																									goto IL_098e_2;
																								case 196:
																									goto IL_09a6_2;
																								case 125:
																								case 205:
																									goto IL_09b9_2;
																								case 47:
																									goto IL_09c7_2;
																								case 46:
																								case 173:
																									goto IL_09d5_2;
																								case 206:
																									goto IL_09f1_2;
																								case 203:
																									goto IL_09fc_2;
																								case 15:
																								case 160:
																									goto IL_0a0a_2;
																								case 184:
																									goto IL_0a48_2;
																								case 122:
																									goto IL_0a5b_2;
																								case 103:
																									goto IL_0a69_2;
																								case 26:
																								case 44:
																									goto IL_0a77_2;
																								case 54:
																									goto IL_0a8b_2;
																								case 162:
																									goto IL_0ac3_2;
																								case 27:
																									goto IL_0ad6_2;
																								case 77:
																									goto IL_0b16_2;
																								case 22:
																									goto IL_0b2a_2;
																								case 34:
																									goto IL_0b3d_2;
																								case 107:
																								case 145:
																									goto IL_0b4b_2;
																								case 102:
																								case 193:
																									goto IL_0b56_2;
																								case 202:
																									goto IL_0b64_2;
																								case 108:
																								case 135:
																									goto IL_0b72_2;
																								case 96:
																									goto IL_0b80_2;
																								case 8:
																									goto IL_0ba3_2;
																								case 1:
																									goto IL_0bad_2;
																								case 204:
																									goto IL_0bbb_2;
																								case 188:
																									goto IL_0bce_2;
																								case 41:
																								case 190:
																									goto IL_0bdc_2;
																								case 31:
																									goto IL_0c05_2;
																								case 99:
																									goto IL_0c13_2;
																								case 90:
																									goto IL_0c26_2;
																								case 64:
																								case 174:
																									goto IL_0c31_2;
																								case 189:
																									goto IL_0c71_2;
																								case 5:
																									goto IL_0c85_2;
																								case 166:
																									goto IL_0c95_2;
																								case 82:
																									goto IL_0ca0_2;
																								case 0:
																								case 4:
																								case 16:
																								case 17:
																								case 23:
																								case 24:
																								case 30:
																								case 32:
																								case 51:
																								case 53:
																								case 59:
																								case 66:
																								case 67:
																								case 78:
																								case 80:
																								case 89:
																								case 92:
																								case 94:
																								case 105:
																								case 111:
																								case 116:
																								case 117:
																								case 119:
																								case 120:
																								case 131:
																								case 133:
																								case 153:
																								case 157:
																								case 158:
																								case 163:
																								case 164:
																								case 167:
																								case 168:
																								case 169:
																								case 170:
																								case 172:
																								case 181:
																								case 185:
																									goto end_IL_0371_2;
																								case 106:
																									goto IL_0cc4_2;
																								case 72:
																									goto IL_0cd2_2;
																								case 12:
																									goto IL_0ce0_2;
																								case 3:
																								case 9:
																								case 13:
																								case 48:
																								case 58:
																								case 60:
																								case 65:
																								case 68:
																								case 74:
																								case 75:
																								case 76:
																								case 81:
																								case 88:
																								case 104:
																								case 124:
																								case 139:
																								case 143:
																								case 148:
																								case 149:
																								case 151:
																								case 154:
																								case 159:
																								case 179:
																								case 182:
																									goto end_IL_03a4_2;
																								case 137:
																									ptr2 = ptr;
																									goto end_IL_03a4_2;
																								case 109:
																									ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRandomlyGeneratedMethodRental.getXmlTypeNamespaceTYPEFLAGFDUAL);
																									num = 137;
																									goto case 137;
																								case 20:
																									array7 = new object[13];
																									goto case 109;
																								case 19:
																									array6 = new long[4];
																									goto case 20;
																								case 191:
																									array5 = new int[6];
																									goto case 19;
																								case 97:
																									array4 = new int[4];
																									goto case 191;
																								case 150:
																									array3 = new object[4];
																									goto case 97;
																								case 52:
																									array2 = new byte[4];
																									goto case 150;
																								case 146:
																									num4 = num2 * 8;
																									goto case 52;
																								case 121:
																									num3 = num2 * 4;
																									goto case 146;
																								case 36:
																									num2 = 1;
																									goto case 121;
																								case 37:
																									goto end_IL_0789;
																								case 18:
																								case 69:
																									goto IL_0dc3_2;
																								}
																								continue;
																							}
																							goto IL_0ad6_2;
																							IL_0b16_2:
																							array2[num6 - 2] = 0;
																							goto IL_0b2a_2;
																							IL_0b2a_2:
																							num6--;
																							goto end_IL_03a4_2;
																							IL_0ad6_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0b16_2;
																							continue;
																							end_IL_0371_2:
																							break;
																						}
																						break;
																					}
																					goto IL_0b3d_2;
																					IL_0c95_2:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0ca0_2;
																					IL_0ca0_2:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_0b3d_2:
																					if (2 < b)
																					{
																						goto IL_0b4b_2;
																					}
																					goto IL_0c26_2;
																					IL_0b4b_2:
																					if (3 < b)
																					{
																						goto IL_0b56_2;
																					}
																					goto IL_0bce_2;
																					IL_0b56_2:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0b64_2;
																					IL_0b64_2:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0b72_2;
																					IL_0b72_2:
																					array2[num6] = 0;
																					goto IL_0b80_2;
																					IL_0b80_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																					goto IL_0ba3_2;
																					IL_0ba3_2:
																					array3[num6] = null;
																					goto IL_0bad_2;
																					IL_0bad_2:
																					num6++;
																					goto IL_0bbb_2;
																					IL_0bbb_2:
																					ptr2 += 8;
																					goto end_IL_03a4_2;
																					IL_0bce_2:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0bdc_2;
																					IL_0bdc_2:
																					reference = ref array5[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0c05_2;
																					IL_0c05_2:
																					ptr2 += 8;
																					goto IL_0c13_2;
																					IL_0c13_2:
																					num6--;
																					goto end_IL_03a4_2;
																					IL_0c26_2:
																					if (2 <= b)
																					{
																						goto IL_0c31_2;
																					}
																					goto IL_0c95_2;
																					IL_0c31_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0c71_2;
																					IL_0c71_2:
																					array2[num6 - 2] = 0;
																					goto IL_0c85_2;
																					IL_0c85_2:
																					num6--;
																					goto end_IL_03a4_2;
																				}
																				break;
																			}
																			goto IL_03fc_2;
																			IL_0918_2:
																			num6--;
																			goto end_IL_03a4_2;
																			IL_03fc_2:
																			if (8 < b)
																			{
																				goto IL_0454_2;
																			}
																			goto IL_0804_2;
																			IL_0454_2:
																			if (9 < b)
																			{
																				goto IL_0462_2;
																			}
																			goto IL_0507_2;
																			IL_0462_2:
																			if (10 < b)
																			{
																				num = 157;
																				break;
																			}
																			goto IL_047b_2;
																			IL_0895_2:
																			num6--;
																			goto end_IL_03a4_2;
																			IL_047b_2:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0489_2;
																			IL_0489_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04eb_2;
																			IL_04eb_2:
																			num6 -= 2;
																			num = 74;
																			goto end_IL_03a4_2;
																			IL_0507_2:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0515_2;
																			IL_0515_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0555_2;
																			IL_0555_2:
																			array2[num6 - 2] = 0;
																			goto IL_0569_2;
																			IL_0569_2:
																			num6--;
																			goto end_IL_03a4_2;
																			IL_0804_2:
																			if (8 > b)
																			{
																				goto IL_0812_2;
																			}
																			goto IL_0895_2;
																			IL_0812_2:
																			if (6 >= b)
																			{
																				goto IL_0820_2;
																			}
																			goto IL_08a8_2;
																			IL_0820_2:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_082e_2;
																			IL_082e_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_086e_2;
																			IL_086e_2:
																			array2[num6 - 2] = 0;
																			goto IL_0882_2;
																			IL_0882_2:
																			num6--;
																			goto end_IL_03a4_2;
																			IL_08a8_2:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_08b6_2;
																			IL_08b6_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_08c4_2;
																			IL_08c4_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0904_2;
																			IL_0904_2:
																			array2[num6 - 2] = 0;
																			goto IL_0918_2;
																		}
																		goto end_IL_03c1_2;
																		continue;
																		end_IL_03a4_2:
																		break;
																		IL_03a4_2:;
																	}
																	break;
																}
																goto IL_040c_2;
																IL_068b_2:
																array2[num6 - 1] = 5;
																break;
																IL_040c_2:
																if (16 < b)
																{
																	goto IL_041a_2;
																}
																goto IL_057c_2;
																IL_041a_2:
																if (19 >= b)
																{
																	goto IL_0428_2;
																}
																goto IL_076b_2;
																IL_0428_2:
																if (19 <= b)
																{
																	goto IL_0436_2;
																}
																goto IL_09f1_2;
																IL_0436_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_07d5_2;
																IL_07d5_2:
																array2[num6] = 1;
																goto IL_07e3_2;
																IL_07e3_2:
																num6++;
																goto IL_07f1_2;
																IL_07f1_2:
																ptr2 += 16;
																break;
																IL_09f1_2:
																if (17 >= b)
																{
																	goto IL_09fc_2;
																}
																goto IL_0a5b_2;
																IL_09fc_2:
																if (17 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_0a0a_2;
																IL_0a0a_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0a48_2;
																IL_0a48_2:
																num6 -= 3;
																break;
																IL_0a5b_2:
																if (18 < b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_0a69_2;
																IL_0a69_2:
																if (18 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_0a77_2;
																IL_0a77_2:
																array2[num6 - 1] = 5;
																goto IL_0a8b_2;
																IL_0a8b_2:
																array3[num6 - 1] = ((delegate*<string[], string>)CheckedOneWayGetImplTypeCustData[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0ac3_2;
																IL_0ac3_2:
																ptr2 += 8;
																break;
																IL_076b_2:
																if (20 >= b)
																{
																	goto IL_0779_2;
																}
																goto IL_09b9_2;
																IL_0779_2:
																if (20 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_07aa_2;
																IL_07aa_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_09b9_2:
																if (21 < b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_09c7_2;
																IL_09c7_2:
																if (21 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_09d5_2;
																IL_09d5_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																break;
																IL_057c_2:
																if (16 <= b)
																{
																	goto IL_0587_2;
																}
																goto IL_05c0_2;
																IL_0587_2:
																array2[num6] = 5;
																goto IL_0595_2;
																IL_0595_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_05ad_2;
																IL_05ad_2:
																num6++;
																goto IL_07c2_2;
																IL_07c2_2:
																ptr2 += 8;
																break;
																IL_05c0_2:
																if (13 >= b)
																{
																	goto IL_05cb_2;
																}
																goto IL_05e9_2;
																IL_05cb_2:
																if (13 > b)
																{
																	goto IL_05d6_2;
																}
																goto IL_0615_2;
																IL_05d6_2:
																if (12 < b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_06a4_2;
																IL_06a4_2:
																if (12 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_06b2_2;
																IL_06b2_2:
																array8 = array3;
																num9 = num6;
																if (array == null)
																{
																	goto IL_06c1_2;
																}
																goto IL_06cf;
																IL_0615_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0633_2;
																IL_0633_2:
																ptr2 += 8;
																goto IL_0641_2;
																IL_0641_2:
																num6--;
																break;
																IL_05e9_2:
																if (14 < b)
																{
																	goto IL_05f4_2;
																}
																goto IL_0654_2;
																IL_05f4_2:
																if (15 < b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_0602_2;
																IL_0602_2:
																if (15 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_092b_2;
																IL_092b_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0943_2;
																IL_0943_2:
																array4[num6 - 0] = array4[num6 - 1];
																num = 55;
																goto IL_096a_2;
																IL_096a_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_098e_2;
																IL_098e_2:
																array3[num6] = array3[num6 - 1];
																goto IL_09a6_2;
																IL_09a6_2:
																num6++;
																break;
																IL_0654_2:
																if (14 > b)
																{
																	goto end_IL_03c1_2;
																}
																goto IL_0662_2;
																IL_0662_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_068b_2;
															}
															goto end_IL_03d1_2;
															continue;
															end_IL_03c1_2:
															break;
															IL_03c1_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0cc4_2;
													IL_0ce0_2:
													ptr2 += 8;
													break;
													IL_0cd2_2:
													num6++;
													goto IL_0ce0_2;
													IL_0cc4_2:
													array2[num6] = 0;
													goto IL_0cd2_2;
													continue;
													end_IL_03d1_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0dc3_2;
									IL_0dc3_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0cee_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0789:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_0353, IL_0366, IL_03af, IL_03bf, IL_03cf, IL_03df, IL_03ef, IL_03fc, IL_0409, IL_0419, IL_0429, IL_0439, IL_0444, IL_0454, IL_0467, IL_0472, IL_0480, IL_04c2, IL_04cd, IL_04d8, IL_04eb, IL_0504, IL_0512, IL_0520, IL_052e, IL_0541, IL_054f, IL_055d, IL_056b, IL_05ab, IL_05bf, IL_05d2, IL_05e2, IL_05f0, IL_0608, IL_0616, IL_0629, IL_0669, IL_0682, IL_068d, IL_069b, IL_06c4, IL_06dd, IL_06eb, IL_06f9, IL_0711, IL_0734, IL_0774, IL_078d, IL_07a0, IL_07ae, IL_07bc, IL_0823, IL_082e, IL_084c, IL_085a, IL_086d, IL_087b, IL_0889, IL_08a6, IL_08f5, IL_08ff, IL_092c, IL_0949, IL_0957, IL_096a, IL_0978, IL_098c, IL_09c4, IL_09d7, IL_09f3, IL_0a06, IL_0a2a, IL_0a42, IL_0a55, IL_0a63, IL_0a6e, IL_0a7c, IL_0a8a, IL_0a98, IL_0abb, IL_0ac5, IL_0ad3, IL_0ae6, IL_0af6, IL_0b01, IL_0b46, IL_0b54, IL_0b67, IL_0b99, IL_0ba7, IL_0bba, IL_0bcd, IL_0be1, IL_0bf4, IL_0c07, IL_0c1a, IL_0c3c, IL_0c4a, IL_0c58, IL_0c6b, IL_0c76, IL_0c81, IL_0c99, IL_0ca4, IL_0caf, IL_0cc8, IL_0cd1, IL_0cea, IL_0cf8, IL_0d0f, IL_0d1d, IL_0d30, IL_0d3a, IL_0d45, IL_0d55, IL_0d65, IL_0d75, IL_0d85, IL_0d95, IL_0da5, IL_0db5, IL_0dc5, IL_0de0 are reachable both inside and outside the pinned region starting at IL_0dda. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 29;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef25 = default(int);
				ref int reference = ref __rxRef25;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0dc5:
						num2 = 1;
						while (true)
						{
							IL_0db5:
							num3 = num2 * 4;
							while (true)
							{
								IL_0da5:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d95:
									array2 = new byte[4];
									while (true)
									{
										IL_0d85:
										array3 = new object[4];
										while (true)
										{
											IL_0d75:
											array4 = new int[4];
											while (true)
											{
												IL_0d65:
												array5 = new int[6];
												while (true)
												{
													IL_0d55:
													array6 = new long[4];
													while (true)
													{
														IL_0d45:
														array7 = new object[19];
														while (true)
														{
															IL_0d3a:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectionEntrySetActivityId.StrongNameSerializationHeaderRecord);
															while (true)
															{
																IL_0d30:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d1d:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0439:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0429:
																				ptr2++;
																				while (true)
																				{
																					IL_0419:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_03fc:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_03ef:
																										if (16 < b)
																										{
																											while (true)
																											{
																												IL_03df:
																												if (19 >= b)
																												{
																													while (true)
																													{
																														IL_03cf:
																														if (19 > b)
																														{
																															while (true)
																															{
																																IL_03bf:
																																if (17 >= b)
																																{
																																	while (17 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_0366:
																																			((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																																			num = 209;
																																			while (true)
																																			{
																																				if (num != 209)
																																				{
																																					if (num != 1190)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 29:
																																						break;
																																					default:
																																						continue;
																																					case 24:
																																					case 156:
																																						goto IL_0366;
																																					case 73:
																																						goto IL_03af;
																																					case 67:
																																						goto IL_03bf;
																																					case 199:
																																						goto IL_03cf;
																																					case 21:
																																						goto IL_03df;
																																					case 74:
																																						goto IL_03ef;
																																					case 4:
																																						goto IL_03fc;
																																					case 46:
																																						goto IL_0409;
																																					case 124:
																																						goto IL_0419;
																																					case 160:
																																						goto IL_0429;
																																					case 52:
																																					case 60:
																																						goto IL_0439;
																																					case 43:
																																						goto IL_0444;
																																					case 47:
																																						goto IL_0454;
																																					case 41:
																																					case 87:
																																						goto IL_0467;
																																					case 20:
																																						goto IL_0472;
																																					case 55:
																																					case 62:
																																						goto IL_0480;
																																					case 2:
																																						goto IL_04c2;
																																					case 16:
																																						goto IL_04cd;
																																					case 30:
																																					case 104:
																																						goto IL_04d8;
																																					case 111:
																																						goto IL_04eb;
																																					case 125:
																																						goto IL_0504;
																																					case 15:
																																					case 129:
																																						goto IL_0520;
																																					case 1:
																																						goto IL_052e;
																																					case 49:
																																					case 138:
																																						goto IL_0541;
																																					case 13:
																																						goto IL_054f;
																																					case 26:
																																						goto IL_055d;
																																					case 69:
																																					case 71:
																																						goto IL_056b;
																																					case 97:
																																						goto IL_05ab;
																																					case 95:
																																						goto IL_05bf;
																																					case 25:
																																						goto IL_05d2;
																																					case 132:
																																					case 140:
																																						goto IL_05e2;
																																					case 83:
																																						goto IL_05f0;
																																					case 92:
																																						goto IL_0608;
																																					case 100:
																																						goto IL_0616;
																																					case 63:
																																					case 148:
																																						goto IL_0629;
																																					case 56:
																																						goto IL_0669;
																																					case 149:
																																					case 158:
																																						goto IL_0682;
																																					case 136:
																																						goto IL_068d;
																																					case 86:
																																					case 103:
																																						goto IL_069b;
																																					case 115:
																																						goto IL_06c4;
																																					case 85:
																																						goto IL_06dd;
																																					case 155:
																																						goto IL_06eb;
																																					case 6:
																																					case 68:
																																						goto IL_06f9;
																																					case 80:
																																						goto IL_0711;
																																					case 35:
																																					case 167:
																																						goto IL_0734;
																																					case 159:
																																						goto IL_0774;
																																					case 126:
																																					case 171:
																																						goto IL_078d;
																																					case 177:
																																						goto IL_07a0;
																																					case 168:
																																						goto IL_07ae;
																																					case 166:
																																					case 170:
																																						goto IL_07bc;
																																					case 184:
																																						goto IL_0823;
																																					case 18:
																																					case 101:
																																						goto IL_082e;
																																					case 90:
																																						goto IL_084c;
																																					case 32:
																																						goto IL_085a;
																																					case 123:
																																						goto IL_086d;
																																					case 33:
																																						goto IL_087b;
																																					case 17:
																																					case 182:
																																						goto IL_0889;
																																					case 121:
																																						goto IL_0949;
																																					case 143:
																																						goto IL_0957;
																																					case 185:
																																						goto IL_096a;
																																					case 36:
																																					case 144:
																																						goto IL_0978;
																																					case 109:
																																						goto IL_098c;
																																					case 70:
																																						goto IL_09c4;
																																					case 190:
																																						goto IL_09d7;
																																					case 191:
																																						goto IL_09f3;
																																					case 192:
																																						goto IL_0a06;
																																					case 161:
																																						goto IL_0a2a;
																																					case 99:
																																						goto IL_0a42;
																																					case 145:
																																					case 193:
																																						goto IL_0a55;
																																					case 117:
																																					case 187:
																																						goto IL_0a63;
																																					case 146:
																																						goto IL_0a6e;
																																					case 50:
																																						goto IL_0a7c;
																																					case 75:
																																					case 164:
																																						goto IL_0a8a;
																																					case 127:
																																						goto IL_0a98;
																																					case 10:
																																						goto IL_0abb;
																																					case 14:
																																						goto IL_0ac5;
																																					case 72:
																																						goto IL_0ad3;
																																					case 51:
																																						goto IL_0ae6;
																																					case 178:
																																						goto IL_0af6;
																																					case 58:
																																					case 105:
																																						goto IL_0b01;
																																					case 89:
																																					case 102:
																																						goto IL_0b46;
																																					case 116:
																																						goto IL_0b54;
																																					case 93:
																																					case 195:
																																						goto IL_0b67;
																																					case 197:
																																						goto IL_0b99;
																																					case 165:
																																						goto IL_0ba7;
																																					case 198:
																																						goto IL_0bba;
																																					case 201:
																																						goto IL_0bcd;
																																					case 19:
																																						goto IL_0be1;
																																					case 202:
																																						goto IL_0bf4;
																																					case 37:
																																					case 48:
																																						goto IL_0c1a;
																																					case 150:
																																						goto IL_0c3c;
																																					case 139:
																																						goto IL_0c4a;
																																					case 9:
																																						goto IL_0c58;
																																					case 153:
																																						goto IL_0c6b;
																																					case 27:
																																						goto IL_0c76;
																																					case 3:
																																					case 147:
																																						goto IL_0c81;
																																					case 34:
																																						goto IL_0c99;
																																					case 130:
																																						goto IL_0ca4;
																																					case 44:
																																					case 122:
																																						goto IL_0caf;
																																					case 11:
																																					case 39:
																																					case 40:
																																					case 45:
																																					case 53:
																																					case 54:
																																					case 64:
																																					case 65:
																																					case 79:
																																					case 81:
																																					case 82:
																																					case 84:
																																					case 88:
																																					case 94:
																																					case 106:
																																					case 110:
																																					case 112:
																																					case 113:
																																					case 118:
																																					case 120:
																																					case 133:
																																					case 134:
																																					case 137:
																																					case 141:
																																					case 151:
																																					case 157:
																																					case 162:
																																					case 163:
																																					case 172:
																																					case 173:
																																					case 176:
																																					case 179:
																																					case 183:
																																					case 186:
																																					case 189:
																																						goto end_IL_0353;
																																					case 42:
																																						goto IL_0cea;
																																					case 22:
																																						goto IL_0cf8;
																																					case 128:
																																						goto IL_0d0f;
																																					case 0:
																																					case 5:
																																					case 7:
																																					case 8:
																																					case 38:
																																					case 59:
																																					case 61:
																																					case 66:
																																					case 76:
																																					case 77:
																																					case 78:
																																					case 91:
																																					case 98:
																																					case 107:
																																					case 108:
																																					case 114:
																																					case 135:
																																					case 142:
																																					case 152:
																																					case 154:
																																					case 174:
																																					case 180:
																																					case 194:
																																					case 200:
																																						goto IL_0d1d;
																																					case 57:
																																						goto IL_0d30;
																																					case 31:
																																						goto IL_0d3a;
																																					case 181:
																																						goto IL_0d45;
																																					case 196:
																																						goto IL_0d55;
																																					case 175:
																																						goto IL_0d65;
																																					case 131:
																																						goto IL_0d75;
																																					case 188:
																																						goto IL_0d85;
																																					case 23:
																																						goto IL_0d95;
																																					case 119:
																																						goto IL_0da5;
																																					case 169:
																																						goto IL_0db5;
																																					case 28:
																																						goto IL_0dc5;
																																					case 12:
																																					case 96:
																																						goto IL_0de0;
																																					}
																																					goto end_IL_0419;
																																				}
																																				num6 -= 3;
																																				goto IL_0d1d;
																																				continue;
																																				end_IL_0353:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																		IL_03af:;
																																	}
																																	break;
																																}
																																goto IL_078d;
																																IL_09c4:
																																ptr2 += 8;
																																goto IL_0d1d;
																																IL_078d:
																																if (18 < b)
																																{
																																	break;
																																}
																																goto IL_096a;
																																IL_096a:
																																if (18 > b)
																																{
																																	break;
																																}
																																goto IL_0978;
																																IL_0978:
																																array2[num6 - 1] = 5;
																																goto IL_098c;
																																IL_098c:
																																array3[num6 - 1] = ((delegate*<string[], string>)stateContinueParsing[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																goto IL_09c4;
																															}
																															break;
																														}
																														goto IL_0c1a;
																														IL_0c58:
																														ptr2 += 16;
																														goto IL_0d1d;
																														IL_0c1a:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																														num = 150;
																														goto IL_0c3c;
																														IL_0c3c:
																														array2[num6] = 1;
																														goto IL_0c4a;
																														IL_0c4a:
																														num6++;
																														goto IL_0c58;
																													}
																													break;
																												}
																												goto IL_0c6b;
																												IL_0caf:
																												num7 = ptr2;
																												num8 = -200;
																												num5 = 1;
																												ptr2 = num7 + num8;
																												goto IL_0d1d;
																												IL_0c6b:
																												if (20 >= b)
																												{
																													goto IL_0c76;
																												}
																												goto IL_0c99;
																												IL_0c76:
																												if (20 > b)
																												{
																													break;
																												}
																												goto IL_0c81;
																												IL_0c81:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_0d1d;
																												IL_0c99:
																												if (21 < b)
																												{
																													break;
																												}
																												goto IL_0ca4;
																												IL_0ca4:
																												if (21 > b)
																												{
																													num = 94;
																													break;
																												}
																												goto IL_0caf;
																											}
																											break;
																										}
																										goto IL_0454;
																										IL_0957:
																										num6++;
																										goto IL_0d1d;
																										IL_0454:
																										if (16 > b)
																										{
																											goto IL_0504;
																										}
																										goto IL_05e2;
																										IL_05e2:
																										array2[num6] = 5;
																										goto IL_05f0;
																										IL_05f0:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_0608;
																										IL_0608:
																										num6++;
																										goto IL_0616;
																										IL_0616:
																										ptr2 += 8;
																										goto IL_0d1d;
																										IL_0504:
																										if (13 < b)
																										{
																											num = 158;
																											goto IL_0682;
																										}
																										goto IL_0823;
																										IL_0949:
																										array2[num6] = 5;
																										goto IL_0957;
																										IL_0682:
																										if (14 >= b)
																										{
																											goto IL_068d;
																										}
																										goto IL_06dd;
																										IL_068d:
																										if (14 > b)
																										{
																											break;
																										}
																										goto IL_069b;
																										IL_069b:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_06c4;
																										IL_06c4:
																										array2[num6 - 1] = 5;
																										goto IL_0d1d;
																										IL_06dd:
																										if (15 < b)
																										{
																											break;
																										}
																										goto IL_06eb;
																										IL_06eb:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_06f9;
																										IL_06f9:
																										array2[num6] = array2[num6 - 1];
																										goto IL_0711;
																										IL_0711:
																										array4[num6 - 0] = array4[num6 - 1];
																										goto IL_0a06;
																										IL_0a06:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0a2a;
																										IL_0a2a:
																										array3[num6] = array3[num6 - 1];
																										goto IL_0a42;
																										IL_0a42:
																										num6++;
																										goto IL_0d1d;
																										IL_0823:
																										if (13 <= b)
																										{
																											goto IL_082e;
																										}
																										goto IL_086d;
																										IL_082e:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_084c;
																										IL_084c:
																										ptr2 += 8;
																										goto IL_085a;
																										IL_085a:
																										num6--;
																										goto IL_0d1d;
																										IL_086d:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_087b;
																										IL_087b:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0889;
																										IL_0889:
																										array8 = array3;
																										num9 = num6;
																										if (array == null)
																										{
																											goto IL_0898;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										num = 121;
																										goto IL_0949;
																									}
																									break;
																								}
																								goto IL_0444;
																								IL_09d7:
																								num6 -= 2;
																								num = 152;
																								goto IL_0d1d;
																								IL_0444:
																								if (11 <= b)
																								{
																									goto IL_0d1d;
																								}
																								goto IL_0467;
																								IL_0467:
																								if (5 >= b)
																								{
																									goto IL_0472;
																								}
																								goto IL_04c2;
																								IL_0472:
																								if (5 <= b)
																								{
																									goto IL_0480;
																								}
																								goto IL_0a55;
																								IL_0480:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_04eb;
																								IL_04eb:
																								array2[num6 - 2] = 0;
																								goto IL_0bf4;
																								IL_0bf4:
																								num6--;
																								goto IL_0d1d;
																								IL_0a55:
																								if (2 < b)
																								{
																									goto IL_0a63;
																								}
																								goto IL_0af6;
																								IL_0a63:
																								if (3 < b)
																								{
																									goto IL_0a6e;
																								}
																								goto IL_0ae6;
																								IL_0a6e:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0a7c;
																								IL_0a7c:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0a8a;
																								IL_0a8a:
																								array2[num6] = 0;
																								goto IL_0a98;
																								IL_0a98:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0abb;
																								IL_0abb:
																								array3[num6] = null;
																								goto IL_0ac5;
																								IL_0ac5:
																								num6++;
																								goto IL_0ad3;
																								IL_0ad3:
																								ptr2 += 8;
																								goto IL_0d1d;
																								IL_0ae6:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0b67;
																								IL_0b67:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 197;
																								goto IL_0b99;
																								IL_0b99:
																								ptr2 += 8;
																								goto IL_0ba7;
																								IL_0ba7:
																								num6--;
																								goto IL_0d1d;
																								IL_0af6:
																								if (2 <= b)
																								{
																									goto IL_0b01;
																								}
																								goto IL_0b46;
																								IL_0b01:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0bcd;
																								IL_0bcd:
																								array2[num6 - 2] = 0;
																								goto IL_0be1;
																								IL_0be1:
																								num6--;
																								goto IL_0d1d;
																								IL_0b46:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0b54;
																								IL_0b54:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_04c2:
																								if (8 >= b)
																								{
																									goto IL_04cd;
																								}
																								goto IL_0520;
																								IL_04cd:
																								if (8 <= b)
																								{
																									goto IL_04d8;
																								}
																								goto IL_0541;
																								IL_04d8:
																								num6--;
																								goto IL_0d1d;
																								IL_0541:
																								if (6 < b)
																								{
																									goto IL_054f;
																								}
																								goto IL_05d2;
																								IL_054f:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_055d;
																								IL_055d:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_056b;
																								IL_056b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_05ab;
																								IL_05ab:
																								array2[num6 - 2] = 0;
																								goto IL_05bf;
																								IL_05bf:
																								num6--;
																								goto IL_0d1d;
																								IL_05d2:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0629;
																								IL_0629:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0669;
																								IL_0669:
																								array2[num6 - 2] = 0;
																								goto IL_0bba;
																								IL_0bba:
																								num6--;
																								goto IL_0d1d;
																								IL_0520:
																								if (9 >= b)
																								{
																									goto IL_052e;
																								}
																								goto IL_07a0;
																								IL_052e:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0734;
																								IL_0734:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0774;
																								IL_0774:
																								array2[num6 - 2] = 0;
																								goto IL_09f3;
																								IL_09f3:
																								num6--;
																								goto IL_0d1d;
																								IL_07a0:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_07ae;
																								IL_07ae:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_07bc;
																								IL_07bc:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_09d7;
																							}
																							break;
																							IL_0409:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0cea;
																					IL_0d0f:
																					ptr2 += 8;
																					goto IL_0d1d;
																					IL_0cf8:
																					num6++;
																					num = 128;
																					goto IL_0d0f;
																					IL_0cea:
																					array2[num6] = 0;
																					goto IL_0cf8;
																					continue;
																					end_IL_0419:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0de0;
																	IL_0de0:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0898:
				while (true)
				{
					IL_0898_2:
					array = new byte[4];
					while (true)
					{
						IL_08a6:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						num = 121;
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0957_2:
								num6++;
								while (true)
								{
									IL_0d1d_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0419_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03fc_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_03ef_2:
																		if (16 < b)
																		{
																			while (true)
																			{
																				IL_03df_2:
																				if (19 >= b)
																				{
																					while (true)
																					{
																						IL_03cf_2:
																						if (19 > b)
																						{
																							while (true)
																							{
																								IL_03bf_2:
																								if (17 >= b)
																								{
																									while (17 <= b)
																									{
																										while (true)
																										{
																											IL_0366_2:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											num = 209;
																											while (true)
																											{
																												if (num != 209)
																												{
																													if (num != 1190)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 24:
																													case 156:
																														goto IL_0366_2;
																													case 73:
																														goto IL_03af_2;
																													case 67:
																														goto IL_03bf_2;
																													case 199:
																														goto IL_03cf_2;
																													case 21:
																														goto IL_03df_2;
																													case 74:
																														goto IL_03ef_2;
																													case 4:
																														goto IL_03fc_2;
																													case 46:
																														goto IL_0409_2;
																													case 124:
																														goto IL_0419_2;
																													case 160:
																														goto end_IL_0419_2;
																													case 52:
																													case 60:
																														goto end_IL_0429;
																													case 43:
																														goto IL_0444_2;
																													case 47:
																														goto IL_0454_2;
																													case 41:
																													case 87:
																														goto IL_0467_2;
																													case 20:
																														goto IL_0472_2;
																													case 55:
																													case 62:
																														goto IL_0480_2;
																													case 2:
																														goto IL_04c2_2;
																													case 16:
																														goto IL_04cd_2;
																													case 30:
																													case 104:
																														goto IL_04d8_2;
																													case 111:
																														goto IL_04eb_2;
																													case 125:
																														goto IL_0504_2;
																													case 15:
																													case 129:
																														goto IL_0520_2;
																													case 1:
																														goto IL_052e_2;
																													case 49:
																													case 138:
																														goto IL_0541_2;
																													case 13:
																														goto IL_054f_2;
																													case 26:
																														goto IL_055d_2;
																													case 69:
																													case 71:
																														goto IL_056b_2;
																													case 97:
																														goto IL_05ab_2;
																													case 95:
																														goto IL_05bf_2;
																													case 25:
																														goto IL_05d2_2;
																													case 132:
																													case 140:
																														goto IL_05e2_2;
																													case 83:
																														goto IL_05f0_2;
																													case 92:
																														goto IL_0608_2;
																													case 100:
																														goto IL_0616_2;
																													case 63:
																													case 148:
																														goto IL_0629_2;
																													case 56:
																														goto IL_0669_2;
																													case 149:
																													case 158:
																														goto IL_0682_2;
																													case 136:
																														goto IL_068d_2;
																													case 86:
																													case 103:
																														goto IL_069b_2;
																													case 115:
																														goto IL_06c4_2;
																													case 85:
																														goto IL_06dd_2;
																													case 155:
																														goto IL_06eb_2;
																													case 6:
																													case 68:
																														goto IL_06f9_2;
																													case 80:
																														goto IL_0711_2;
																													case 35:
																													case 167:
																														goto IL_0734_2;
																													case 159:
																														goto IL_0774_2;
																													case 126:
																													case 171:
																														goto IL_078d_2;
																													case 177:
																														goto IL_07a0_2;
																													case 168:
																														goto IL_07ae_2;
																													case 166:
																													case 170:
																														goto IL_07bc_2;
																													case 184:
																														goto IL_0823_2;
																													case 18:
																													case 101:
																														goto IL_082e_2;
																													case 90:
																														goto IL_084c_2;
																													case 32:
																														goto IL_085a_2;
																													case 123:
																														goto IL_086d_2;
																													case 33:
																														goto IL_087b_2;
																													case 17:
																													case 182:
																														goto IL_0889_2;
																													case 121:
																														goto end_IL_0439;
																													case 143:
																														goto IL_0957_2;
																													case 185:
																														goto IL_096a_2;
																													case 36:
																													case 144:
																														goto IL_0978_2;
																													case 109:
																														goto IL_098c_2;
																													case 70:
																														goto IL_09c4_2;
																													case 190:
																														goto IL_09d7_2;
																													case 191:
																														goto IL_09f3_2;
																													case 192:
																														goto IL_0a06_2;
																													case 161:
																														goto IL_0a2a_2;
																													case 99:
																														goto IL_0a42_2;
																													case 145:
																													case 193:
																														goto IL_0a55_2;
																													case 117:
																													case 187:
																														goto IL_0a63_2;
																													case 146:
																														goto IL_0a6e_2;
																													case 50:
																														goto IL_0a7c_2;
																													case 75:
																													case 164:
																														goto IL_0a8a_2;
																													case 127:
																														goto IL_0a98_2;
																													case 10:
																														goto IL_0abb_2;
																													case 14:
																														goto IL_0ac5_2;
																													case 72:
																														goto IL_0ad3_2;
																													case 51:
																														goto IL_0ae6_2;
																													case 178:
																														goto IL_0af6_2;
																													case 58:
																													case 105:
																														goto IL_0b01_2;
																													case 89:
																													case 102:
																														goto IL_0b46_2;
																													case 116:
																														goto IL_0b54_2;
																													case 93:
																													case 195:
																														goto IL_0b67_2;
																													case 197:
																														goto IL_0b99_2;
																													case 165:
																														goto IL_0ba7_2;
																													case 198:
																														goto IL_0bba_2;
																													case 201:
																														goto IL_0bcd_2;
																													case 19:
																														goto IL_0be1_2;
																													case 202:
																														goto IL_0bf4_2;
																													case 37:
																													case 48:
																														goto IL_0c1a_2;
																													case 150:
																														goto IL_0c3c_2;
																													case 139:
																														goto IL_0c4a_2;
																													case 9:
																														goto IL_0c58_2;
																													case 153:
																														goto IL_0c6b_2;
																													case 27:
																														goto IL_0c76_2;
																													case 3:
																													case 147:
																														goto IL_0c81_2;
																													case 34:
																														goto IL_0c99_2;
																													case 130:
																														goto IL_0ca4_2;
																													case 44:
																													case 122:
																														goto IL_0caf_2;
																													case 11:
																													case 39:
																													case 40:
																													case 45:
																													case 53:
																													case 54:
																													case 64:
																													case 65:
																													case 79:
																													case 81:
																													case 82:
																													case 84:
																													case 88:
																													case 94:
																													case 106:
																													case 110:
																													case 112:
																													case 113:
																													case 118:
																													case 120:
																													case 133:
																													case 134:
																													case 137:
																													case 141:
																													case 151:
																													case 157:
																													case 162:
																													case 163:
																													case 172:
																													case 173:
																													case 176:
																													case 179:
																													case 183:
																													case 186:
																													case 189:
																														goto end_IL_0353_2;
																													case 42:
																														goto IL_0cea_2;
																													case 22:
																														goto IL_0cf8_2;
																													case 128:
																														goto IL_0d0f_2;
																													case 0:
																													case 5:
																													case 7:
																													case 8:
																													case 38:
																													case 59:
																													case 61:
																													case 66:
																													case 76:
																													case 77:
																													case 78:
																													case 91:
																													case 98:
																													case 107:
																													case 108:
																													case 114:
																													case 135:
																													case 142:
																													case 152:
																													case 154:
																													case 174:
																													case 180:
																													case 194:
																													case 200:
																														goto IL_0d1d_2;
																													case 57:
																														ptr2 = ptr;
																														goto IL_0d1d_2;
																													case 31:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectionEntrySetActivityId.StrongNameSerializationHeaderRecord);
																														goto case 57;
																													case 181:
																														array7 = new object[19];
																														goto case 31;
																													case 196:
																														array6 = new long[4];
																														goto case 181;
																													case 175:
																														array5 = new int[6];
																														goto case 196;
																													case 131:
																														array4 = new int[4];
																														goto case 175;
																													case 188:
																														array3 = new object[4];
																														goto case 131;
																													case 23:
																														array2 = new byte[4];
																														goto case 188;
																													case 119:
																														num4 = num2 * 8;
																														goto case 23;
																													case 169:
																														num3 = num2 * 4;
																														goto case 119;
																													case 28:
																														num2 = 1;
																														goto case 169;
																													case 29:
																														goto end_IL_0949;
																													case 12:
																													case 96:
																														goto IL_0de0_2;
																													}
																													continue;
																												}
																												num6 -= 3;
																												goto IL_0d1d_2;
																												continue;
																												end_IL_0353_2:
																												break;
																											}
																											break;
																										}
																										break;
																										IL_03af_2:;
																									}
																									break;
																								}
																								goto IL_078d_2;
																								IL_09c4_2:
																								ptr2 += 8;
																								goto IL_0d1d_2;
																								IL_078d_2:
																								if (18 < b)
																								{
																									break;
																								}
																								goto IL_096a_2;
																								IL_096a_2:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_0978_2;
																								IL_0978_2:
																								array2[num6 - 1] = 5;
																								goto IL_098c_2;
																								IL_098c_2:
																								array3[num6 - 1] = ((delegate*<string[], string>)stateContinueParsing[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_09c4_2;
																							}
																							break;
																						}
																						goto IL_0c1a_2;
																						IL_0c58_2:
																						ptr2 += 16;
																						goto IL_0d1d_2;
																						IL_0c1a_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						num = 150;
																						goto IL_0c3c_2;
																						IL_0c3c_2:
																						array2[num6] = 1;
																						goto IL_0c4a_2;
																						IL_0c4a_2:
																						num6++;
																						goto IL_0c58_2;
																					}
																					break;
																				}
																				goto IL_0c6b_2;
																				IL_0caf_2:
																				num7 = ptr2;
																				num8 = -200;
																				num5 = 1;
																				ptr2 = num7 + num8;
																				goto IL_0d1d_2;
																				IL_0c6b_2:
																				if (20 >= b)
																				{
																					goto IL_0c76_2;
																				}
																				goto IL_0c99_2;
																				IL_0c76_2:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_0c81_2;
																				IL_0c81_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0d1d_2;
																				IL_0c99_2:
																				if (21 < b)
																				{
																					break;
																				}
																				goto IL_0ca4_2;
																				IL_0ca4_2:
																				if (21 > b)
																				{
																					num = 94;
																					break;
																				}
																				goto IL_0caf_2;
																			}
																			break;
																		}
																		goto IL_0454_2;
																		IL_087b_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0889_2;
																		IL_0454_2:
																		if (16 > b)
																		{
																			goto IL_0504_2;
																		}
																		goto IL_05e2_2;
																		IL_05e2_2:
																		array2[num6] = 5;
																		goto IL_05f0_2;
																		IL_05f0_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_0608_2;
																		IL_0608_2:
																		num6++;
																		goto IL_0616_2;
																		IL_0616_2:
																		ptr2 += 8;
																		goto IL_0d1d_2;
																		IL_0504_2:
																		if (13 < b)
																		{
																			num = 158;
																			goto IL_0682_2;
																		}
																		goto IL_0823_2;
																		IL_0889_2:
																		array8 = array3;
																		num9 = num6;
																		if (array == null)
																		{
																			goto IL_0898_2;
																		}
																		goto IL_08a6;
																		IL_0682_2:
																		if (14 >= b)
																		{
																			goto IL_068d_2;
																		}
																		goto IL_06dd_2;
																		IL_068d_2:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_069b_2;
																		IL_069b_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_06c4_2;
																		IL_06c4_2:
																		array2[num6 - 1] = 5;
																		goto IL_0d1d_2;
																		IL_06dd_2:
																		if (15 < b)
																		{
																			break;
																		}
																		goto IL_06eb_2;
																		IL_06eb_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_06f9_2;
																		IL_06f9_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_0711_2;
																		IL_0711_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_0a06_2;
																		IL_0a06_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0a2a_2;
																		IL_0a2a_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_0a42_2;
																		IL_0a42_2:
																		num6++;
																		goto IL_0d1d_2;
																		IL_0823_2:
																		if (13 <= b)
																		{
																			goto IL_082e_2;
																		}
																		goto IL_086d_2;
																		IL_082e_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_084c_2;
																		IL_084c_2:
																		ptr2 += 8;
																		goto IL_085a_2;
																		IL_085a_2:
																		num6--;
																		goto IL_0d1d_2;
																		IL_086d_2:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_087b_2;
																	}
																	break;
																}
																goto IL_0444_2;
																IL_09d7_2:
																num6 -= 2;
																num = 152;
																goto IL_0d1d_2;
																IL_0444_2:
																if (11 <= b)
																{
																	goto IL_0d1d_2;
																}
																goto IL_0467_2;
																IL_0467_2:
																if (5 >= b)
																{
																	goto IL_0472_2;
																}
																goto IL_04c2_2;
																IL_0472_2:
																if (5 <= b)
																{
																	goto IL_0480_2;
																}
																goto IL_0a55_2;
																IL_0480_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_04eb_2;
																IL_04eb_2:
																array2[num6 - 2] = 0;
																goto IL_0bf4_2;
																IL_0bf4_2:
																num6--;
																goto IL_0d1d_2;
																IL_0a55_2:
																if (2 < b)
																{
																	goto IL_0a63_2;
																}
																goto IL_0af6_2;
																IL_0a63_2:
																if (3 < b)
																{
																	goto IL_0a6e_2;
																}
																goto IL_0ae6_2;
																IL_0a6e_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_0a7c_2;
																IL_0a7c_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0a8a_2;
																IL_0a8a_2:
																array2[num6] = 0;
																goto IL_0a98_2;
																IL_0a98_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0abb_2;
																IL_0abb_2:
																array3[num6] = null;
																goto IL_0ac5_2;
																IL_0ac5_2:
																num6++;
																goto IL_0ad3_2;
																IL_0ad3_2:
																ptr2 += 8;
																goto IL_0d1d_2;
																IL_0ae6_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_0b67_2;
																IL_0b67_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 197;
																goto IL_0b99_2;
																IL_0b99_2:
																ptr2 += 8;
																goto IL_0ba7_2;
																IL_0ba7_2:
																num6--;
																goto IL_0d1d_2;
																IL_0af6_2:
																if (2 <= b)
																{
																	goto IL_0b01_2;
																}
																goto IL_0b46_2;
																IL_0b01_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0bcd_2;
																IL_0bcd_2:
																array2[num6 - 2] = 0;
																goto IL_0be1_2;
																IL_0be1_2:
																num6--;
																goto IL_0d1d_2;
																IL_0b46_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_0b54_2;
																IL_0b54_2:
																if (1 <= b)
																{
																}
																break;
																IL_04c2_2:
																if (8 >= b)
																{
																	goto IL_04cd_2;
																}
																goto IL_0520_2;
																IL_04cd_2:
																if (8 <= b)
																{
																	goto IL_04d8_2;
																}
																goto IL_0541_2;
																IL_04d8_2:
																num6--;
																goto IL_0d1d_2;
																IL_0541_2:
																if (6 < b)
																{
																	goto IL_054f_2;
																}
																goto IL_05d2_2;
																IL_054f_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_055d_2;
																IL_055d_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_056b_2;
																IL_056b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_05ab_2;
																IL_05ab_2:
																array2[num6 - 2] = 0;
																goto IL_05bf_2;
																IL_05bf_2:
																num6--;
																goto IL_0d1d_2;
																IL_05d2_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0629_2;
																IL_0629_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0669_2;
																IL_0669_2:
																array2[num6 - 2] = 0;
																goto IL_0bba_2;
																IL_0bba_2:
																num6--;
																goto IL_0d1d_2;
																IL_0520_2:
																if (9 >= b)
																{
																	goto IL_052e_2;
																}
																goto IL_07a0_2;
																IL_052e_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_0734_2;
																IL_0734_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0774_2;
																IL_0774_2:
																array2[num6 - 2] = 0;
																goto IL_09f3_2;
																IL_09f3_2:
																num6--;
																goto IL_0d1d_2;
																IL_07a0_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_07ae_2;
																IL_07ae_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_07bc_2;
																IL_07bc_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_09d7_2;
															}
															break;
															IL_0409_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0cea_2;
													IL_0d0f_2:
													ptr2 += 8;
													goto IL_0d1d_2;
													IL_0cf8_2:
													num6++;
													num = 128;
													goto IL_0d0f_2;
													IL_0cea_2:
													array2[num6] = 0;
													goto IL_0cf8_2;
													continue;
													end_IL_0419_2:
													break;
												}
												continue;
												end_IL_0429:
												break;
											}
											continue;
											end_IL_0439:
											break;
										}
										break;
									}
									goto IL_0de0_2;
									IL_0de0_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0949:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class110()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13()
	{
		int num = 110;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 3;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InternalLowEnforceJapaneseEraYearRanges.SoapIntegerTables);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 148;
														while (true)
														{
															if (num != 148)
															{
																if (num != 1129)
																{
																	goto IL_0549;
																}
																switch (num)
																{
																case 64:
																case 91:
																	goto end_IL_025f;
																case 141:
																	goto IL_0291;
																case 71:
																	goto IL_029f;
																case 101:
																	goto IL_02ad;
																case 22:
																	goto IL_02bb;
																case 56:
																case 58:
																	goto IL_02c6;
																case 68:
																	goto IL_02de;
																case 40:
																	goto IL_02ec;
																case 107:
																case 119:
																	goto IL_02fa;
																case 88:
																	goto IL_0308;
																case 11:
																case 45:
																	goto IL_0313;
																case 26:
																	goto IL_0353;
																case 2:
																	goto IL_0367;
																case 137:
																	goto IL_037a;
																case 73:
																	goto IL_0388;
																case 19:
																case 86:
																	goto IL_0396;
																case 12:
																	goto IL_03af;
																case 66:
																	goto IL_03bd;
																case 23:
																	goto IL_03cb;
																case 53:
																	goto IL_03de;
																case 125:
																	goto IL_03ec;
																case 20:
																case 98:
																	goto IL_03fa;
																case 105:
																	goto IL_0423;
																case 37:
																case 77:
																	goto IL_043c;
																case 129:
																	goto IL_045a;
																case 10:
																	goto IL_0468;
																case 106:
																	goto IL_047b;
																case 79:
																	goto IL_0489;
																case 8:
																	goto IL_0494;
																case 17:
																	goto IL_04a2;
																case 32:
																case 108:
																	goto IL_04b0;
																case 0:
																	goto IL_04be;
																case 67:
																	goto IL_04d6;
																case 33:
																	goto IL_04e4;
																case 50:
																case 99:
																	goto IL_04f7;
																case 94:
																	goto IL_0536;
																case 62:
																	goto IL_0549;
																case 90:
																	goto IL_0557;
																case 51:
																case 139:
																	goto IL_0565;
																case 81:
																	goto IL_0597;
																case 96:
																	goto IL_05a5;
																case 60:
																	goto IL_05b8;
																case 39:
																case 85:
																	goto IL_05c6;
																case 112:
																case 133:
																	goto IL_05d1;
																case 6:
																	goto IL_05df;
																case 128:
																	goto IL_05f2;
																case 104:
																case 126:
																	goto IL_0600;
																case 111:
																	goto IL_060e;
																case 78:
																case 130:
																	goto IL_061c;
																case 121:
																	goto IL_067e;
																case 44:
																case 59:
																	goto IL_0691;
																case 82:
																	goto IL_06ad;
																case 28:
																case 118:
																	goto IL_06b8;
																case 55:
																	goto IL_06f8;
																case 13:
																	goto IL_070c;
																case 131:
																	goto IL_0728;
																case 117:
																	goto IL_0736;
																case 5:
																case 24:
																	goto IL_0741;
																case 92:
																	goto IL_074f;
																case 75:
																	goto IL_0772;
																case 138:
																	goto IL_077c;
																case 116:
																	goto IL_078a;
																case 38:
																	goto IL_079d;
																case 74:
																	goto IL_07ab;
																case 103:
																	goto IL_07be;
																case 25:
																	goto IL_07c9;
																case 87:
																case 113:
																	goto IL_07d4;
																case 34:
																	goto IL_0818;
																case 57:
																	goto IL_082c;
																case 9:
																case 15:
																case 18:
																case 21:
																case 27:
																case 31:
																case 36:
																case 41:
																case 46:
																case 47:
																case 49:
																case 61:
																case 63:
																case 65:
																case 69:
																case 84:
																case 89:
																case 95:
																case 97:
																case 115:
																case 123:
																case 127:
																case 134:
																case 140:
																	goto IL_0850;
																case 1:
																case 7:
																case 29:
																case 35:
																case 43:
																case 54:
																case 72:
																case 80:
																case 83:
																case 93:
																case 100:
																case 102:
																case 114:
																case 120:
																case 122:
																case 132:
																case 135:
																case 136:
																	goto end_IL_026f;
																case 42:
																	goto end_IL_0863;
																case 4:
																	goto end_IL_0876;
																case 3:
																	goto end_IL_0880;
																case 14:
																	goto end_IL_088b;
																case 16:
																case 52:
																	goto end_IL_089b;
																case 30:
																	goto end_IL_08b4;
																case 48:
																case 70:
																	goto end_IL_08c4;
																case 109:
																	goto end_IL_08d4;
																case 110:
																	goto end_IL_08e4;
																case 76:
																case 124:
																	goto IL_08ff;
																}
																continue;
															}
															ptr2++;
															goto IL_0291;
															IL_0818:
															array[num5 - 2] = 0;
															goto IL_082c;
															IL_0850:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_026f;
															IL_082c:
															num5--;
															goto end_IL_026f;
															IL_0291:
															if (b >= 1)
															{
																goto IL_029f;
															}
															goto IL_0850;
															IL_029f:
															if (b <= 15)
															{
																goto IL_02ad;
															}
															num = 36;
															goto IL_0850;
															IL_02ad:
															if (8 >= b)
															{
																goto IL_02bb;
															}
															goto IL_05b8;
															IL_02bb:
															if (8 <= b)
															{
																goto IL_02c6;
															}
															goto IL_02de;
															IL_02c6:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_026f;
															IL_02de:
															if (4 >= b)
															{
																goto IL_02ec;
															}
															goto IL_047b;
															IL_02ec:
															if (4 > b)
															{
																goto IL_02fa;
															}
															goto IL_043c;
															IL_02fa:
															if (2 >= b)
															{
																goto IL_0308;
															}
															goto IL_03de;
															IL_0308:
															if (2 <= b)
															{
																goto IL_0313;
															}
															goto IL_037a;
															IL_0313:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0353;
															IL_0353:
															array[num5 - 2] = 0;
															goto IL_0367;
															IL_0367:
															num5--;
															goto end_IL_026f;
															IL_037a:
															if (1 >= b)
															{
																goto IL_0388;
															}
															goto IL_0850;
															IL_0388:
															if (1 <= b)
															{
																goto IL_0396;
															}
															goto IL_0850;
															IL_0396:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_03af;
															IL_03af:
															array[num5] = 0;
															goto IL_03bd;
															IL_03bd:
															num5++;
															goto IL_03cb;
															IL_03cb:
															ptr2 += 8;
															goto end_IL_026f;
															IL_03de:
															if (3 >= b)
															{
																goto IL_03ec;
															}
															goto IL_0850;
															IL_03ec:
															if (3 <= b)
															{
																goto IL_03fa;
															}
															goto IL_0850;
															IL_03fa:
															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_0423;
															IL_0423:
															array[num5 - 1] = 5;
															goto end_IL_026f;
															IL_043c:
															array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
															goto IL_045a;
															IL_045a:
															ptr2 += 8;
															goto IL_0468;
															IL_0468:
															num5--;
															goto end_IL_026f;
															IL_047b:
															if (6 >= b)
															{
																goto IL_0489;
															}
															goto IL_0549;
															IL_0489:
															if (6 > b)
															{
																goto IL_0494;
															}
															goto IL_04f7;
															IL_0494:
															if (5 >= b)
															{
																goto IL_04a2;
															}
															goto IL_0850;
															IL_04a2:
															if (5 <= b)
															{
																goto IL_04b0;
															}
															goto IL_0850;
															IL_04b0:
															array[num5] = 5;
															goto IL_04be;
															IL_04be:
															array2[num5] = array5[*(int*)(ptr2 + num3)];
															goto IL_04d6;
															IL_04d6:
															num5++;
															goto IL_04e4;
															IL_04e4:
															ptr2 += 8;
															goto end_IL_026f;
															IL_04f7:
															((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0536;
															IL_0536:
															num5 -= 3;
															goto end_IL_026f;
															IL_0549:
															if (7 >= b)
															{
																goto IL_0557;
															}
															goto IL_0850;
															IL_0557:
															if (7 <= b)
															{
																goto IL_0565;
															}
															goto IL_0850;
															IL_0565:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															num = 81;
															goto IL_0597;
															IL_0597:
															ptr2 += 8;
															goto IL_05a5;
															IL_05a5:
															num5--;
															goto end_IL_026f;
															IL_05b8:
															if (12 < b)
															{
																goto IL_05c6;
															}
															goto IL_06ad;
															IL_05c6:
															if (14 < b)
															{
																goto IL_05d1;
															}
															goto IL_05f2;
															IL_05d1:
															if (15 >= b)
															{
																goto IL_05df;
															}
															goto IL_0850;
															IL_05df:
															if (15 > b)
															{
															}
															goto IL_0850;
															IL_05f2:
															if (14 > b)
															{
																goto IL_0600;
															}
															goto IL_0691;
															IL_0600:
															if (13 >= b)
															{
																goto IL_060e;
															}
															goto IL_0850;
															IL_060e:
															if (13 <= b)
															{
																goto IL_061c;
															}
															goto IL_0850;
															IL_061c:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_067e;
															IL_067e:
															num5 -= 2;
															goto end_IL_026f;
															IL_0691:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto end_IL_026f;
															IL_06ad:
															if (12 <= b)
															{
																goto IL_06b8;
															}
															goto IL_0728;
															IL_06b8:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_06f8;
															IL_06f8:
															array[num5 - 2] = 0;
															goto IL_070c;
															IL_070c:
															num5--;
															num = 29;
															goto end_IL_026f;
															IL_0728:
															if (10 >= b)
															{
																goto IL_0736;
															}
															goto IL_07be;
															IL_0736:
															if (10 <= b)
															{
																goto IL_0741;
															}
															goto IL_079d;
															IL_0741:
															array[num5] = 0;
															goto IL_074f;
															IL_074f:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_0772;
															IL_0772:
															array2[num5] = null;
															goto IL_077c;
															IL_077c:
															num5++;
															goto IL_078a;
															IL_078a:
															ptr2 += 8;
															goto end_IL_026f;
															IL_079d:
															if (9 >= b)
															{
																goto IL_07ab;
															}
															goto IL_0850;
															IL_07ab:
															if (9 <= b)
															{
																goto end_IL_026f;
															}
															goto IL_0850;
															IL_07be:
															if (11 >= b)
															{
																goto IL_07c9;
															}
															num = 65;
															goto IL_0850;
															IL_07c9:
															if (11 <= b)
															{
																goto IL_07d4;
															}
															goto IL_0850;
															IL_07d4:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
															goto IL_0818;
															continue;
															end_IL_025f:
															break;
														}
														continue;
														end_IL_026f:
														break;
													}
													continue;
												}
												goto IL_08ff;
												IL_08ff:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0863:
												break;
											}
											continue;
											end_IL_0876:
											break;
										}
										continue;
										end_IL_0880:
										break;
									}
									continue;
									end_IL_088b:
									break;
								}
								continue;
								end_IL_089b:
								break;
							}
							continue;
							end_IL_08b4:
							break;
						}
						continue;
						end_IL_08c4:
						break;
					}
					continue;
					end_IL_08d4:
					break;
				}
				continue;
				end_IL_08e4:
				break;
			}
		}
	}

	private unsafe static int smethod_14()
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 45;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getTwoLetterISORegionNameGetApplicationStateFilesystemLocation.getIsSingleByteStaticIndexRangePartition);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03a9:
														byte b = *ptr2;
														while (true)
														{
															IL_0399:
															ptr2++;
															while (true)
															{
																IL_0389:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_036c:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_035c:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_034f:
																							if (13 <= b)
																							{
																								while (true)
																								{
																									IL_02eb:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									while (true)
																									{
																										IL_02d2:
																										num5 -= 2;
																										num = 172;
																										while (num != 172)
																										{
																											if (num != 1153)
																											{
																												goto IL_079c;
																											}
																											switch (num)
																											{
																											case 36:
																												goto IL_02d2;
																											case 19:
																											case 106:
																												goto IL_02eb;
																											case 69:
																												goto IL_034f;
																											case 78:
																												goto IL_035c;
																											case 111:
																												goto IL_036c;
																											case 48:
																												goto IL_0379;
																											case 165:
																												goto IL_0389;
																											case 24:
																												goto IL_0399;
																											case 9:
																											case 129:
																												goto IL_03a9;
																											case 35:
																												goto IL_03b4;
																											case 5:
																												goto IL_03bf;
																											case 21:
																												goto IL_03cd;
																											case 32:
																												goto IL_03db;
																											case 46:
																												goto IL_03ee;
																											case 54:
																											case 64:
																												goto IL_0401;
																											case 67:
																												goto IL_0418;
																											case 12:
																											case 86:
																												goto IL_0428;
																											case 72:
																											case 91:
																												goto IL_043b;
																											case 55:
																											case 122:
																												goto IL_047d;
																											case 13:
																												goto IL_04c1;
																											case 94:
																												goto IL_04d5;
																											case 50:
																											case 124:
																												goto IL_04e8;
																											case 145:
																												goto IL_04fb;
																											case 85:
																												goto IL_050f;
																											case 148:
																												goto IL_0522;
																											case 104:
																												goto IL_052d;
																											case 87:
																												goto IL_053b;
																											case 99:
																											case 105:
																												goto IL_0549;
																											case 146:
																												goto IL_055d;
																											case 52:
																											case 66:
																												goto IL_05aa;
																											case 152:
																												goto IL_05bd;
																											case 125:
																											case 133:
																												goto IL_05cb;
																											case 92:
																												goto IL_05d9;
																											case 56:
																												goto IL_05e4;
																											case 17:
																											case 142:
																												goto IL_05f2;
																											case 108:
																												goto IL_061b;
																											case 139:
																												goto IL_0632;
																											case 127:
																												goto IL_0645;
																											case 80:
																												goto IL_0653;
																											case 123:
																											case 140:
																												goto IL_0661;
																											case 62:
																												goto IL_0679;
																											case 1:
																											case 90:
																												goto IL_0684;
																											case 23:
																												goto IL_06a2;
																											case 44:
																												goto IL_06b0;
																											case 22:
																												goto IL_06c3;
																											case 79:
																											case 102:
																												goto IL_06ce;
																											case 29:
																												goto IL_06dc;
																											case 119:
																											case 126:
																												goto IL_06f5;
																											case 103:
																												goto IL_0727;
																											case 153:
																												goto IL_0740;
																											case 42:
																												goto IL_074b;
																											case 150:
																												goto IL_0759;
																											case 88:
																											case 93:
																												goto IL_0767;
																											case 120:
																												goto IL_0780;
																											case 47:
																												goto IL_078e;
																											case 59:
																												goto IL_079c;
																											case 81:
																											case 107:
																												goto IL_07af;
																											case 130:
																												goto IL_07ef;
																											case 112:
																												goto IL_0803;
																											case 156:
																												goto IL_0816;
																											case 38:
																												goto IL_0839;
																											case 63:
																												goto IL_0843;
																											case 39:
																												goto IL_0851;
																											case 14:
																											case 160:
																												goto IL_086d;
																											case 65:
																											case 144:
																												goto IL_0878;
																											case 98:
																												goto IL_0886;
																											case 151:
																												goto IL_0899;
																											case 74:
																											case 159:
																												goto IL_08a7;
																											case 161:
																												goto IL_08c3;
																											case 164:
																												goto IL_08d6;
																											case 101:
																											case 141:
																												goto IL_08e1;
																											case 155:
																												goto IL_08ef;
																											case 100:
																											case 162:
																												goto IL_08fd;
																											case 135:
																												goto IL_0914;
																											case 113:
																												goto IL_092c;
																											case 75:
																												goto IL_093a;
																											case 34:
																											case 83:
																												goto IL_094a;
																											case 76:
																												goto IL_0989;
																											case 2:
																											case 6:
																											case 7:
																											case 8:
																											case 10:
																											case 11:
																											case 26:
																											case 28:
																											case 30:
																											case 41:
																											case 53:
																											case 57:
																											case 58:
																											case 60:
																											case 70:
																											case 73:
																											case 77:
																											case 82:
																											case 97:
																											case 109:
																											case 110:
																											case 114:
																											case 116:
																											case 118:
																											case 121:
																											case 128:
																											case 132:
																											case 137:
																											case 143:
																											case 147:
																											case 149:
																											case 158:
																											case 163:
																												goto end_IL_0379;
																											case 15:
																											case 16:
																											case 18:
																											case 20:
																											case 27:
																											case 33:
																											case 37:
																											case 40:
																											case 68:
																											case 71:
																											case 89:
																											case 95:
																											case 96:
																											case 115:
																											case 117:
																											case 131:
																											case 136:
																											case 138:
																											case 157:
																												goto end_IL_02bf;
																											case 84:
																												goto end_IL_09ac;
																											case 61:
																												goto end_IL_09bf;
																											case 25:
																												goto end_IL_09c9;
																											case 45:
																												goto end_IL_09d4;
																											case 43:
																											case 51:
																												goto end_IL_09e4;
																											case 134:
																												goto end_IL_09f4;
																											case 0:
																											case 49:
																												goto end_IL_0a0d;
																											case 3:
																												goto end_IL_0a1d;
																											case 4:
																												goto end_IL_0a2d;
																											case 31:
																											case 154:
																												goto IL_0a48;
																											}
																											continue;
																											end_IL_02bf:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_03b4;
																							IL_04fb:
																							array[num5 - 2] = 0;
																							goto IL_050f;
																							IL_03b4:
																							if (11 >= b)
																							{
																								goto IL_03bf;
																							}
																							goto IL_0401;
																							IL_03bf:
																							if (11 > b)
																							{
																								goto IL_03cd;
																							}
																							goto IL_047d;
																							IL_03cd:
																							if (10 < b)
																							{
																								goto end_IL_0379;
																							}
																							goto IL_03db;
																							IL_03db:
																							if (10 > b)
																							{
																								goto end_IL_0379;
																							}
																							goto IL_04e8;
																							IL_04e8:
																							array[num5] = 0;
																							goto IL_0816;
																							IL_0816:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0839;
																							IL_0839:
																							array2[num5] = null;
																							goto IL_0843;
																							IL_0843:
																							num5++;
																							goto IL_0851;
																							IL_0851:
																							ptr2 += 8;
																							num = 89;
																							break;
																							IL_047d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_04c1;
																							IL_04c1:
																							array[num5 - 2] = 0;
																							goto IL_04d5;
																							IL_04d5:
																							num5--;
																							break;
																							IL_0401:
																							if (12 < b)
																							{
																								goto end_IL_0379;
																							}
																							num = 67;
																							goto IL_0418;
																							IL_050f:
																							num5--;
																							break;
																							IL_0418:
																							if (12 > b)
																							{
																								goto end_IL_0379;
																							}
																							goto IL_043b;
																							IL_043b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fb;
																						}
																						break;
																					}
																					goto IL_0428;
																					IL_05aa:
																					num5--;
																					break;
																					IL_0428:
																					if (15 >= b)
																					{
																						goto IL_0522;
																					}
																					goto IL_086d;
																					IL_086d:
																					if (16 < b)
																					{
																						goto IL_0878;
																					}
																					goto IL_0899;
																					IL_0878:
																					if (17 < b)
																					{
																						goto end_IL_0379;
																					}
																					goto IL_0886;
																					IL_0886:
																					if (17 > b)
																					{
																					}
																					goto end_IL_0379;
																					IL_0899:
																					if (16 > b)
																					{
																						goto end_IL_0379;
																					}
																					goto IL_08a7;
																					IL_08a7:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0522:
																					if (15 > b)
																					{
																						goto IL_052d;
																					}
																					num = 52;
																					goto IL_05aa;
																					IL_052d:
																					if (14 < b)
																					{
																						goto end_IL_0379;
																					}
																					goto IL_053b;
																					IL_053b:
																					if (14 > b)
																					{
																						goto end_IL_0379;
																					}
																					goto IL_0549;
																					IL_0549:
																					array[num5 - 1] = 0;
																					goto IL_055d;
																					IL_055d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getIsStoppedgetResourceScope[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_08c3;
																					IL_08c3:
																					ptr2 += 8;
																					break;
																				}
																				break;
																			}
																			goto IL_03ee;
																			IL_07ef:
																			array[num5 - 2] = 0;
																			goto IL_0803;
																			IL_03ee:
																			if (9 <= b)
																			{
																				break;
																			}
																			goto IL_05bd;
																			IL_05bd:
																			if (4 < b)
																			{
																				goto IL_05cb;
																			}
																			goto IL_0679;
																			IL_05cb:
																			if (6 < b)
																			{
																				goto IL_05d9;
																			}
																			goto IL_08d6;
																			IL_05d9:
																			if (7 >= b)
																			{
																				goto IL_05e4;
																			}
																			goto IL_0645;
																			IL_05e4:
																			if (7 > b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_05f2;
																			IL_05f2:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_061b;
																			IL_061b:
																			ptr2 += 8;
																			num = 139;
																			goto IL_0632;
																			IL_0632:
																			num5--;
																			break;
																			IL_0645:
																			if (8 < b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_0653;
																			IL_0653:
																			if (8 > b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_0661;
																			IL_0661:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_08d6:
																			if (6 > b)
																			{
																				goto IL_08e1;
																			}
																			goto IL_094a;
																			IL_08e1:
																			if (5 < b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_08ef;
																			IL_08ef:
																			if (5 > b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_08fd;
																			IL_08fd:
																			array[num5] = 5;
																			num = 135;
																			goto IL_0914;
																			IL_0914:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_092c;
																			IL_092c:
																			num5++;
																			goto IL_093a;
																			IL_093a:
																			ptr2 += 8;
																			break;
																			IL_094a:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0989;
																			IL_0989:
																			num5 -= 3;
																			break;
																			IL_0679:
																			if (4 <= b)
																			{
																				goto IL_0684;
																			}
																			goto IL_06c3;
																			IL_0684:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_06a2;
																			IL_06a2:
																			ptr2 += 8;
																			goto IL_06b0;
																			IL_06b0:
																			num5--;
																			break;
																			IL_06c3:
																			if (2 < b)
																			{
																				goto IL_06ce;
																			}
																			goto IL_0740;
																			IL_06ce:
																			if (3 < b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_06dc;
																			IL_06dc:
																			if (3 > b)
																			{
																				num = 77;
																				goto end_IL_0379;
																			}
																			goto IL_06f5;
																			IL_0803:
																			num5--;
																			break;
																			IL_06f5:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 103;
																			goto IL_0727;
																			IL_0727:
																			array[num5 - 1] = 5;
																			break;
																			IL_0740:
																			if (2 > b)
																			{
																				goto IL_074b;
																			}
																			goto IL_07af;
																			IL_074b:
																			if (1 < b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_0759;
																			IL_0759:
																			if (1 > b)
																			{
																				goto end_IL_0379;
																			}
																			goto IL_0767;
																			IL_0767:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0780;
																			IL_0780:
																			array[num5] = 0;
																			goto IL_078e;
																			IL_078e:
																			num5++;
																			goto IL_079c;
																			IL_079c:
																			ptr2 += 8;
																			break;
																			IL_07af:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07ef;
																		}
																		goto end_IL_0389;
																		continue;
																		end_IL_0379:
																		break;
																		IL_0379:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0389:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a48;
												IL_0a48:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ac:
												break;
											}
											continue;
											end_IL_09bf:
											break;
										}
										continue;
										end_IL_09c9:
										break;
									}
									continue;
									end_IL_09d4:
									break;
								}
								continue;
								end_IL_09e4:
								break;
							}
							continue;
							end_IL_09f4:
							break;
						}
						continue;
						end_IL_0a0d:
						break;
					}
					continue;
					end_IL_0a1d:
					break;
				}
				continue;
				end_IL_0a2d:
				break;
			}
		}
	}

	private unsafe static int smethod_15()
	{
		int num = 85;
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 84;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 43;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FDefaultBindClassSemanticsMask.EventWaitHandleSecurityBackup);
											num = 127;
											while (true)
											{
												byte* ptr2 = ptr;
												num = 154;
												while (true)
												{
													if (num == 154)
													{
														goto IL_0330;
													}
													if (num != 1135)
													{
														goto IL_03f2;
													}
													switch (num)
													{
													case 127:
														goto end_IL_0277;
													case 91:
														goto end_IL_028a;
													case 107:
														goto end_IL_029d;
													case 78:
														goto end_IL_02b1;
													case 43:
														goto end_IL_02c1;
													case 67:
														goto end_IL_02d1;
													case 19:
														goto end_IL_02e1;
													case 111:
													case 112:
														goto end_IL_02ec;
													case 84:
														goto end_IL_02fc;
													case 85:
														goto end_IL_030c;
													case 1:
													case 5:
													case 11:
													case 15:
													case 22:
													case 29:
													case 50:
													case 51:
													case 54:
													case 59:
													case 65:
													case 79:
													case 82:
													case 90:
													case 95:
													case 97:
													case 146:
														goto IL_0330;
													case 3:
													case 106:
														goto IL_0340;
													case 36:
														goto IL_0349;
													case 24:
														goto IL_0357;
													case 39:
														goto IL_0365;
													case 60:
														goto IL_0373;
													case 117:
														goto IL_0381;
													case 71:
													case 99:
														goto IL_038c;
													case 26:
														goto IL_03a1;
													case 44:
													case 141:
														goto IL_03af;
													case 105:
														goto IL_03bd;
													case 10:
													case 86:
														goto IL_03c8;
													case 57:
														goto IL_03d6;
													case 45:
													case 49:
														goto IL_03e4;
													case 114:
														goto IL_03f2;
													case 34:
														goto IL_040a;
													case 35:
														goto IL_0418;
													case 101:
													case 142:
														goto IL_042b;
													case 62:
														goto IL_046a;
													case 75:
													case 113:
														goto IL_047d;
													case 124:
														goto IL_048b;
													case 47:
													case 96:
														goto IL_0499;
													case 18:
														goto IL_04c2;
													case 38:
														goto IL_04d0;
													case 134:
														goto IL_04e3;
													case 73:
													case 131:
														goto IL_04f1;
													case 66:
														goto IL_04ff;
													case 14:
													case 61:
														goto IL_050a;
													case 53:
														goto IL_0518;
													case 88:
													case 147:
														goto IL_052f;
													case 89:
														goto IL_0548;
													case 41:
														goto IL_0556;
													case 48:
														goto IL_0564;
													case 80:
													case 109:
														goto IL_0577;
													case 64:
														goto IL_05b7;
													case 46:
														goto IL_05d4;
													case 7:
														goto IL_05e7;
													case 20:
														goto IL_05f5;
													case 8:
													case 13:
														goto IL_0603;
													case 81:
														goto IL_062c;
													case 40:
													case 76:
														goto IL_0645;
													case 52:
														goto IL_0663;
													case 133:
														goto IL_0671;
													case 132:
														goto IL_0684;
													case 63:
														goto IL_0692;
													case 55:
														goto IL_06a0;
													case 16:
														goto IL_06ae;
													case 0:
													case 135:
														goto IL_06b9;
													case 21:
														goto IL_06c7;
													case 138:
														goto IL_06ea;
													case 58:
														goto IL_06f4;
													case 144:
														goto IL_0702;
													case 140:
														goto IL_0715;
													case 83:
														goto IL_0723;
													case 42:
														goto IL_0736;
													case 32:
														goto IL_0744;
													case 2:
													case 128:
														goto IL_0752;
													case 104:
														goto IL_079f;
													case 68:
														goto IL_07b3;
													case 98:
													case 100:
														goto IL_07cf;
													case 137:
														goto IL_080f;
													case 87:
														goto IL_0823;
													case 33:
														goto IL_0836;
													case 123:
														goto IL_0844;
													case 6:
													case 129:
														goto IL_0852;
													case 116:
														goto IL_0860;
													case 118:
													case 119:
														goto IL_086e;
													case 130:
														goto IL_08d0;
													case 25:
													case 28:
														goto IL_08e3;
													case 72:
														goto IL_08ff;
													case 136:
														goto IL_090a;
													case 4:
													case 9:
													case 12:
													case 17:
													case 23:
													case 27:
													case 30:
													case 31:
													case 37:
													case 56:
													case 69:
													case 70:
													case 74:
													case 77:
													case 92:
													case 93:
													case 94:
													case 103:
													case 110:
													case 115:
													case 120:
													case 121:
													case 122:
													case 125:
													case 126:
													case 139:
													case 143:
													case 145:
														goto IL_0915;
													case 102:
													case 108:
														goto IL_092d;
													}
													continue;
													IL_08e3:
													byte* num4 = ptr2;
													num5 = 1;
													ptr2 = num4 + -200;
													goto IL_0330;
													IL_08ff:
													if (15 >= b)
													{
														goto IL_090a;
													}
													goto IL_0915;
													IL_0330:
													if (num5 != 1)
													{
														goto IL_0340;
													}
													goto IL_092d;
													IL_092d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													IL_0340:
													b = *ptr2;
													goto IL_0349;
													IL_0349:
													ptr2++;
													goto IL_0357;
													IL_0357:
													if (b >= 1)
													{
														goto IL_0365;
													}
													goto IL_0915;
													IL_0365:
													if (b <= 15)
													{
														goto IL_0373;
													}
													goto IL_0915;
													IL_0373:
													if (8 >= b)
													{
														goto IL_0381;
													}
													goto IL_0684;
													IL_0381:
													if (8 <= b)
													{
														goto IL_038c;
													}
													goto IL_03a1;
													IL_038c:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0330;
													IL_03a1:
													if (4 < b)
													{
														goto IL_03af;
													}
													goto IL_04e3;
													IL_03af:
													if (6 >= b)
													{
														goto IL_03bd;
													}
													goto IL_047d;
													IL_03bd:
													if (6 > b)
													{
														goto IL_03c8;
													}
													goto IL_042b;
													IL_03c8:
													if (5 >= b)
													{
														goto IL_03d6;
													}
													goto IL_0915;
													IL_03d6:
													if (5 <= b)
													{
														goto IL_03e4;
													}
													goto IL_0915;
													IL_03e4:
													array[num6] = 5;
													goto IL_03f2;
													IL_03f2:
													array2[num6] = array5[*(int*)(ptr2 + num3)];
													goto IL_040a;
													IL_040a:
													num6++;
													goto IL_0418;
													IL_0418:
													ptr2 += 8;
													goto IL_0330;
													IL_042b:
													((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_046a;
													IL_046a:
													num6 -= 3;
													goto IL_0330;
													IL_047d:
													if (7 >= b)
													{
														goto IL_048b;
													}
													goto IL_0915;
													IL_048b:
													if (7 <= b)
													{
														goto IL_0499;
													}
													goto IL_0915;
													IL_0499:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_04c2;
													IL_04c2:
													ptr2 += 8;
													goto IL_04d0;
													IL_04d0:
													num6--;
													goto IL_0330;
													IL_04e3:
													if (4 > b)
													{
														goto IL_04f1;
													}
													goto IL_0645;
													IL_04f1:
													if (2 >= b)
													{
														goto IL_04ff;
													}
													goto IL_05e7;
													IL_04ff:
													if (2 > b)
													{
														goto IL_050a;
													}
													goto IL_0577;
													IL_050a:
													if (1 >= b)
													{
														goto IL_0518;
													}
													goto IL_0915;
													IL_0518:
													if (1 <= b)
													{
														num = 88;
														goto IL_052f;
													}
													goto IL_0915;
													IL_090a:
													if (15 > b)
													{
													}
													goto IL_0915;
													IL_052f:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
													goto IL_0548;
													IL_0548:
													array[num6] = 0;
													goto IL_0556;
													IL_0556:
													num6++;
													goto IL_0564;
													IL_0564:
													ptr2 += 8;
													goto IL_0330;
													IL_0577:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_05b7;
													IL_05b7:
													array[num6 - 2] = 0;
													num = 46;
													goto IL_05d4;
													IL_05d4:
													num6--;
													goto IL_0330;
													IL_05e7:
													if (3 >= b)
													{
														goto IL_05f5;
													}
													goto IL_0915;
													IL_05f5:
													if (3 <= b)
													{
														goto IL_0603;
													}
													goto IL_0915;
													IL_0603:
													array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
													goto IL_062c;
													IL_062c:
													array[num6 - 1] = 5;
													goto IL_0330;
													IL_0645:
													array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
													goto IL_0663;
													IL_0663:
													ptr2 += 8;
													goto IL_0671;
													IL_0671:
													num6--;
													goto IL_0330;
													IL_0684:
													if (12 >= b)
													{
														goto IL_0692;
													}
													goto IL_0836;
													IL_0692:
													if (12 > b)
													{
														goto IL_06a0;
													}
													num = 100;
													goto IL_07cf;
													IL_06a0:
													if (10 >= b)
													{
														goto IL_06ae;
													}
													goto IL_0736;
													IL_06ae:
													if (10 <= b)
													{
														goto IL_06b9;
													}
													goto IL_0715;
													IL_06b9:
													array[num6] = 0;
													goto IL_06c7;
													IL_06c7:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
													goto IL_06ea;
													IL_06ea:
													array2[num6] = null;
													goto IL_06f4;
													IL_06f4:
													num6++;
													goto IL_0702;
													IL_0702:
													ptr2 += 8;
													goto IL_0330;
													IL_0715:
													if (9 >= b)
													{
														goto IL_0723;
													}
													goto IL_0915;
													IL_0723:
													if (9 <= b)
													{
														goto IL_0330;
													}
													goto IL_0915;
													IL_0736:
													if (11 >= b)
													{
														goto IL_0744;
													}
													goto IL_0915;
													IL_0744:
													if (11 <= b)
													{
														goto IL_0752;
													}
													goto IL_0915;
													IL_0752:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
													num = 104;
													goto IL_079f;
													IL_079f:
													array[num6 - 2] = 0;
													goto IL_07b3;
													IL_07b3:
													num6--;
													goto IL_0330;
													IL_0915:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0330;
													IL_07cf:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													goto IL_080f;
													IL_080f:
													array[num6 - 2] = 0;
													goto IL_0823;
													IL_0823:
													num6--;
													goto IL_0330;
													IL_0836:
													if (14 >= b)
													{
														goto IL_0844;
													}
													goto IL_08ff;
													IL_0844:
													if (14 > b)
													{
														goto IL_0852;
													}
													goto IL_08e3;
													IL_0852:
													if (13 >= b)
													{
														goto IL_0860;
													}
													goto IL_0915;
													IL_0860:
													if (13 <= b)
													{
														goto IL_086e;
													}
													goto IL_0915;
													IL_086e:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_08d0;
													IL_08d0:
													num6 -= 2;
													goto IL_0330;
													continue;
													end_IL_0277:
													break;
												}
												continue;
												end_IL_028a:
												break;
											}
											continue;
											end_IL_029d:
											break;
										}
										continue;
										end_IL_02b1:
										break;
									}
									continue;
									end_IL_02c1:
									break;
								}
								continue;
								end_IL_02d1:
								break;
							}
							continue;
							end_IL_02e1:
							break;
						}
						continue;
						end_IL_02ec:
						break;
					}
					continue;
					end_IL_02fc:
					break;
				}
				continue;
				end_IL_030c:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_3)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getEndOffsetsetAbbreviatedMonthGenitiveNames.MetadataSectionDeploymentDataNestedFamANDAssem);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02ee:
														byte b = *ptr2;
														num = 17;
														while (true)
														{
															IL_02de:
															ptr2++;
															while (true)
															{
																IL_02ce:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02ae:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_029e:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0291:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0284:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											while (true)
																											{
																												IL_0229:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 14;
																												while (true)
																												{
																													IL_0213:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_01fa:
																														num5--;
																														num = 118;
																														while (num != 118)
																														{
																															if (num != 1099)
																															{
																																goto IL_05d3;
																															}
																															switch (num)
																															{
																															case 42:
																																goto IL_01fa;
																															case 14:
																																goto IL_0213;
																															case 27:
																															case 35:
																																goto IL_0229;
																															case 104:
																																goto IL_0274;
																															case 83:
																																goto IL_0284;
																															case 72:
																																goto IL_0291;
																															case 44:
																															case 62:
																																goto IL_029e;
																															case 9:
																																goto IL_02ae;
																															case 20:
																																goto IL_02be;
																															case 85:
																																goto IL_02ce;
																															case 17:
																																goto IL_02de;
																															case 76:
																															case 111:
																																goto IL_02ee;
																															case 37:
																															case 47:
																																goto IL_030d;
																															case 12:
																																goto IL_031b;
																															case 63:
																															case 81:
																																goto IL_0329;
																															case 71:
																																goto IL_034c;
																															case 54:
																																goto IL_035a;
																															case 56:
																																goto IL_0368;
																															case 61:
																															case 98:
																																goto IL_037b;
																															case 3:
																																goto IL_03dd;
																															case 39:
																																goto IL_03f0;
																															case 2:
																																goto IL_03fb;
																															case 30:
																															case 108:
																																goto IL_0409;
																															case 46:
																															case 99:
																																goto IL_0425;
																															case 0:
																																goto IL_0433;
																															case 105:
																																goto IL_0446;
																															case 65:
																																goto IL_0454;
																															case 36:
																																goto IL_0462;
																															case 13:
																															case 97:
																																goto IL_046d;
																															case 4:
																															case 86:
																																goto IL_0485;
																															case 29:
																																goto IL_0490;
																															case 6:
																															case 43:
																																goto IL_049e;
																															case 59:
																																goto IL_04b7;
																															case 103:
																																goto IL_04ce;
																															case 66:
																																goto IL_04dc;
																															case 21:
																																goto IL_04ef;
																															case 11:
																																goto IL_04fa;
																															case 68:
																															case 87:
																																goto IL_0508;
																															case 19:
																																goto IL_0531;
																															case 41:
																																goto IL_053f;
																															case 38:
																																goto IL_0560;
																															case 69:
																															case 92:
																																goto IL_056e;
																															case 23:
																																goto IL_057c;
																															case 25:
																															case 100:
																																goto IL_058a;
																															case 96:
																																goto IL_0598;
																															case 55:
																																goto IL_05bb;
																															case 48:
																																goto IL_05c5;
																															case 33:
																																goto IL_05d3;
																															case 88:
																																goto IL_05ef;
																															case 18:
																															case 93:
																																goto IL_05ff;
																															case 82:
																																goto IL_063f;
																															case 15:
																																goto IL_0653;
																															case 5:
																															case 7:
																															case 8:
																															case 26:
																															case 28:
																															case 40:
																															case 50:
																															case 52:
																															case 58:
																															case 60:
																															case 67:
																															case 74:
																															case 75:
																															case 89:
																															case 90:
																															case 91:
																															case 95:
																															case 106:
																															case 109:
																																goto end_IL_0274;
																															case 1:
																															case 16:
																															case 31:
																															case 32:
																															case 45:
																															case 49:
																															case 53:
																															case 70:
																															case 73:
																															case 79:
																															case 80:
																															case 107:
																															case 110:
																																goto end_IL_01e7;
																															case 94:
																																goto end_IL_067f;
																															case 102:
																																goto end_IL_0692;
																															case 22:
																																goto end_IL_069c;
																															case 64:
																																goto end_IL_06a7;
																															case 84:
																															case 101:
																																goto end_IL_06bc;
																															case 57:
																																goto end_IL_06cc;
																															case 24:
																															case 51:
																																goto end_IL_06dc;
																															case 77:
																																goto end_IL_06ec;
																															case 78:
																																goto end_IL_06fc;
																															case 10:
																															case 34:
																																goto IL_0720;
																															}
																															continue;
																															end_IL_01e7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_02ce;
																											continue;
																											end_IL_0274:
																											break;
																											IL_0274:;
																										}
																										break;
																									}
																									goto IL_030d;
																									IL_0368:
																									ptr2 += 8;
																									goto end_IL_02ce;
																									IL_030d:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_031b;
																									IL_031b:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0329;
																									IL_0329:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_034c;
																									IL_034c:
																									array[num5] = 0;
																									goto IL_035a;
																									IL_035a:
																									num5++;
																									goto IL_0368;
																								}
																								break;
																							}
																							num = 61;
																							goto IL_037b;
																							IL_037b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03dd;
																							IL_03dd:
																							num5 -= 2;
																							goto end_IL_02ce;
																						}
																						break;
																					}
																					goto IL_03f0;
																					IL_0433:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_03f0:
																					if (10 >= b)
																					{
																						goto IL_03fb;
																					}
																					goto IL_0425;
																					IL_03fb:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0409;
																					IL_0409:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02ce;
																					IL_0425:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0433;
																				}
																				break;
																			}
																			goto IL_0446;
																			IL_063f:
																			array[num5 - 2] = 0;
																			goto IL_0653;
																			IL_0446:
																			if (6 > b)
																			{
																				goto IL_0454;
																			}
																			goto IL_05ff;
																			IL_0454:
																			if (3 >= b)
																			{
																				goto IL_0462;
																			}
																			goto IL_0560;
																			IL_0462:
																			if (3 <= b)
																			{
																				goto IL_046d;
																			}
																			goto IL_0485;
																			IL_046d:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02ce;
																			IL_0485:
																			if (1 >= b)
																			{
																				goto IL_0490;
																			}
																			goto IL_04ef;
																			IL_0490:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_049e;
																			IL_049e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04b7;
																			IL_04b7:
																			array[num5] = 0;
																			num = 103;
																			goto IL_04ce;
																			IL_04ce:
																			num5++;
																			goto IL_04dc;
																			IL_04dc:
																			ptr2 += 8;
																			goto end_IL_02ce;
																			IL_04ef:
																			if (2 < b)
																			{
																				num = 60;
																				break;
																			}
																			goto IL_04fa;
																			IL_04fa:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0508;
																			IL_0508:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0531;
																			IL_0531:
																			ptr2 += 8;
																			goto IL_053f;
																			IL_053f:
																			num5--;
																			goto end_IL_02ce;
																			IL_0653:
																			num5--;
																			num = 110;
																			goto end_IL_02ce;
																			IL_0560:
																			if (4 < b)
																			{
																				goto IL_056e;
																			}
																			goto IL_05ef;
																			IL_056e:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_057c;
																			IL_057c:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_058a;
																			IL_058a:
																			array[num5] = 0;
																			goto IL_0598;
																			IL_0598:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05bb;
																			IL_05bb:
																			array2[num5] = null;
																			goto IL_05c5;
																			IL_05c5:
																			num5++;
																			goto IL_05d3;
																			IL_05d3:
																			ptr2 += 8;
																			num = 16;
																			goto end_IL_02ce;
																			IL_05ef:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02ce;
																			IL_05ff:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_063f;
																		}
																		break;
																		IL_02be:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02ce:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 10;
												goto IL_0720;
												IL_0720:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067f:
												break;
											}
											continue;
											end_IL_0692:
											break;
										}
										continue;
										end_IL_069c:
										break;
									}
									continue;
									end_IL_06a7:
									break;
								}
								continue;
								end_IL_06bc:
								break;
							}
							continue;
							end_IL_06cc:
							break;
						}
						continue;
						end_IL_06dc:
						break;
					}
					continue;
					end_IL_06ec:
					break;
				}
				continue;
				end_IL_06fc:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_3, int int_4)
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 4;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_0591:
					num = 21;
					while (true)
					{
						IL_0581:
						byte[] array = new byte[2];
						while (true)
						{
							IL_0571:
							object[] array2 = new object[2];
							while (true)
							{
								IL_0561:
								int[] array3 = new int[3];
								while (true)
								{
									IL_0551:
									long[] array4 = new long[2];
									while (true)
									{
										IL_053c:
										array3[0] = int_3;
										while (true)
										{
											IL_0527:
											array3[1] = int_4;
											while (true)
											{
												IL_0513:
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EncodeTagsIsSurrogate.HasDefaultCMSASSEMBLYDEPLOYMENTFLAG);
												num = 35;
												while (true)
												{
													IL_0509:
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0279:
																byte b = *ptr2;
																while (true)
																{
																	IL_0269:
																	ptr2++;
																	while (true)
																	{
																		IL_0259:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_0239:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_022c:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_021c:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											while (true)
																											{
																												IL_01fc:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_01d7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_01cb:
																														array2[num5] = null;
																														while (true)
																														{
																															IL_01bb:
																															num5++;
																															while (true)
																															{
																																IL_01a2:
																																ptr2 += 8;
																																num = 96;
																																while (num != 96)
																																{
																																	if (num != 1077)
																																	{
																																		goto end_IL_04f6;
																																	}
																																	switch (num)
																																	{
																																	case 11:
																																		goto IL_01a2;
																																	case 30:
																																		goto IL_01bb;
																																	case 37:
																																		goto IL_01cb;
																																	case 8:
																																		goto IL_01d7;
																																	case 44:
																																	case 62:
																																		goto IL_01fc;
																																	case 34:
																																		goto IL_020c;
																																	case 88:
																																		goto IL_021c;
																																	case 73:
																																	case 81:
																																		goto IL_022c;
																																	case 64:
																																		goto IL_0239;
																																	case 57:
																																		goto IL_0249;
																																	case 38:
																																		goto IL_0259;
																																	case 47:
																																		goto IL_0269;
																																	case 33:
																																	case 80:
																																		goto IL_0279;
																																	case 56:
																																		goto IL_0284;
																																	case 26:
																																	case 85:
																																		goto IL_0292;
																																	case 48:
																																		goto IL_02a0;
																																	case 60:
																																	case 74:
																																		goto IL_02ae;
																																	case 14:
																																	case 50:
																																		goto IL_02c6;
																																	case 54:
																																		goto IL_02dd;
																																	case 12:
																																	case 18:
																																		goto IL_02eb;
																																	case 9:
																																		goto IL_0307;
																																	case 31:
																																	case 77:
																																		goto IL_0312;
																																	case 6:
																																		goto IL_033b;
																																	case 65:
																																		goto IL_0349;
																																	case 10:
																																		goto IL_035c;
																																	case 29:
																																	case 49:
																																		goto IL_036a;
																																	case 86:
																																		goto IL_0378;
																																	case 0:
																																	case 36:
																																		goto IL_0386;
																																	case 75:
																																		goto IL_03c6;
																																	case 16:
																																		goto IL_03da;
																																	case 83:
																																		goto IL_03ed;
																																	case 51:
																																	case 53:
																																		goto IL_03f8;
																																	case 20:
																																		goto IL_0406;
																																	case 13:
																																	case 43:
																																		goto IL_0419;
																																	case 2:
																																		goto IL_0490;
																																	case 7:
																																	case 19:
																																	case 23:
																																	case 25:
																																	case 28:
																																	case 39:
																																	case 40:
																																	case 42:
																																	case 52:
																																	case 66:
																																	case 67:
																																	case 69:
																																	case 72:
																																	case 76:
																																	case 84:
																																	case 87:
																																		goto end_IL_020c;
																																	case 79:
																																		goto IL_04cc;
																																	case 32:
																																		goto IL_04da;
																																	case 45:
																																		goto IL_04e8;
																																	case 1:
																																	case 15:
																																	case 17:
																																	case 22:
																																	case 24:
																																	case 46:
																																	case 58:
																																	case 61:
																																	case 68:
																																	case 82:
																																		goto end_IL_018f;
																																	case 35:
																																		goto IL_0509;
																																	case 41:
																																		goto IL_0513;
																																	case 63:
																																		goto IL_0527;
																																	case 70:
																																		goto IL_053c;
																																	case 71:
																																		goto IL_0551;
																																	case 3:
																																	case 59:
																																		goto IL_0561;
																																	case 27:
																																		goto IL_0571;
																																	case 21:
																																		goto IL_0581;
																																	case 89:
																																		goto IL_0591;
																																	case 4:
																																		goto end_IL_04f6;
																																	case 5:
																																		goto end_IL_059c;
																																	case 55:
																																	case 78:
																																		goto IL_05c0;
																																	}
																																	continue;
																																	end_IL_018f:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_0259;
																											continue;
																											end_IL_020c:
																											break;
																											IL_020c:;
																										}
																										break;
																									}
																									goto IL_02c6;
																									IL_02dd:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_02eb;
																									IL_02c6:
																									if (8 < b)
																									{
																										break;
																									}
																									num = 54;
																									goto IL_02dd;
																									IL_02eb:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0259;
																								}
																								break;
																							}
																							goto IL_0284;
																							IL_02ae:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0259;
																							IL_0284:
																							if (6 <= b)
																							{
																								goto end_IL_0259;
																							}
																							goto IL_0292;
																							IL_0292:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_02a0;
																							IL_02a0:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_02ae;
																						}
																						break;
																					}
																					goto IL_0307;
																					IL_0490:
																					num5 -= 2;
																					goto end_IL_0259;
																					IL_0307:
																					if (4 <= b)
																					{
																						goto IL_0312;
																					}
																					goto IL_035c;
																					IL_0312:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_033b;
																					IL_033b:
																					ptr2 += 8;
																					goto IL_0349;
																					IL_0349:
																					num5--;
																					goto end_IL_0259;
																					IL_035c:
																					if (2 < b)
																					{
																						goto IL_036a;
																					}
																					goto IL_03ed;
																					IL_036a:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0378;
																					IL_0378:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0386;
																					IL_0386:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c6;
																					IL_03c6:
																					array[num5 - 2] = 0;
																					goto IL_03da;
																					IL_03da:
																					num5--;
																					goto end_IL_0259;
																					IL_03ed:
																					if (2 > b)
																					{
																						goto IL_03f8;
																					}
																					goto IL_0419;
																					IL_03f8:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0406;
																					IL_0406:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0419:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 2;
																					goto IL_0490;
																				}
																				break;
																				IL_0249:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 79;
																		goto IL_04cc;
																		IL_04e8:
																		ptr2 += 8;
																		break;
																		IL_04da:
																		num5++;
																		goto IL_04e8;
																		IL_04cc:
																		array[num5] = 0;
																		goto IL_04da;
																		continue;
																		end_IL_0259:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05c0;
														IL_05c0:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04f6:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_059c:
				break;
			}
		}
	}

	private unsafe static int smethod_18()
	{
		int num = 142;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 101;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsPublicGenericPar.FnPtrFindConnectionPoint);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f4:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			if (8 >= b)
																			{
																				while (true)
																				{
																					if (8 > b)
																					{
																						while (true)
																						{
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02a7:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_027e:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											num = 151;
																											while (true)
																											{
																												if (num != 151)
																												{
																													if (num != 1132)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 50:
																													case 65:
																														goto IL_027e;
																													case 123:
																														goto IL_02a7;
																													case 12:
																													case 120:
																														goto end_IL_02a7;
																													case 1:
																														goto end_IL_02b7;
																													case 115:
																														goto end_IL_02c7;
																													case 15:
																														goto end_IL_02d7;
																													case 89:
																														goto IL_02f4;
																													case 72:
																														goto end_IL_02f4;
																													case 41:
																													case 75:
																														goto end_IL_0304;
																													case 97:
																													case 98:
																														goto IL_031f;
																													case 5:
																														goto IL_032d;
																													case 18:
																													case 48:
																														goto IL_0338;
																													case 35:
																														goto IL_0378;
																													case 40:
																														goto IL_038c;
																													case 86:
																														goto IL_039f;
																													case 73:
																														goto IL_03aa;
																													case 69:
																														goto IL_03b5;
																													case 62:
																													case 81:
																														goto IL_03c3;
																													case 46:
																														goto IL_042e;
																													case 8:
																														goto IL_0439;
																													case 36:
																														goto IL_044c;
																													case 26:
																														goto IL_0457;
																													case 104:
																														goto IL_0478;
																													case 24:
																													case 52:
																														goto IL_0486;
																													case 60:
																														goto IL_0494;
																													case 58:
																														goto IL_04b7;
																													case 16:
																														goto IL_04c1;
																													case 37:
																														goto IL_04cf;
																													case 64:
																													case 106:
																														goto IL_04e2;
																													case 107:
																														goto IL_04fe;
																													case 3:
																														goto IL_050c;
																													case 102:
																													case 116:
																														goto IL_051a;
																													case 100:
																													case 121:
																														goto IL_057e;
																													case 19:
																														goto IL_0589;
																													case 128:
																														goto IL_05aa;
																													case 28:
																													case 129:
																														goto IL_05bd;
																													case 113:
																														goto IL_05c8;
																													case 111:
																														goto IL_05d6;
																													case 70:
																													case 122:
																														goto IL_05e4;
																													case 55:
																														goto IL_061b;
																													case 9:
																													case 71:
																														goto IL_0626;
																													case 66:
																														goto end_IL_026b;
																													case 20:
																													case 118:
																														goto IL_0642;
																													case 117:
																														goto IL_065b;
																													case 29:
																														goto IL_0669;
																													case 49:
																														goto IL_0677;
																													case 61:
																													case 136:
																														goto IL_068a;
																													case 91:
																														goto IL_06ca;
																													case 30:
																														goto IL_06de;
																													case 140:
																														goto IL_06f1;
																													case 4:
																														goto IL_0705;
																													case 144:
																														goto IL_0718;
																													case 34:
																														goto IL_073f;
																													case 130:
																														goto IL_0752;
																													case 143:
																														goto IL_0760;
																													case 33:
																													case 108:
																														goto IL_076b;
																													case 21:
																														goto IL_07aa;
																													case 57:
																														goto IL_07bd;
																													case 74:
																														goto IL_07c8;
																													case 114:
																													case 124:
																														goto IL_07d6;
																													case 42:
																														goto IL_07e4;
																													case 47:
																														goto IL_07fc;
																													case 92:
																														goto IL_080a;
																													case 25:
																														goto IL_0828;
																													case 23:
																														goto IL_0833;
																													case 39:
																													case 131:
																														goto IL_083e;
																													case 0:
																														goto IL_0867;
																													case 44:
																														goto IL_087e;
																													case 7:
																													case 87:
																														goto IL_088e;
																													case 6:
																													case 10:
																													case 13:
																													case 14:
																													case 17:
																													case 22:
																													case 27:
																													case 31:
																													case 51:
																													case 53:
																													case 54:
																													case 67:
																													case 68:
																													case 78:
																													case 79:
																													case 83:
																													case 99:
																													case 105:
																													case 126:
																													case 127:
																													case 133:
																													case 134:
																													case 135:
																													case 137:
																													case 138:
																													case 139:
																														goto end_IL_02e4;
																													case 2:
																													case 11:
																													case 32:
																													case 38:
																													case 45:
																													case 59:
																													case 76:
																													case 84:
																													case 85:
																													case 90:
																													case 93:
																													case 94:
																													case 103:
																													case 109:
																													case 112:
																													case 119:
																													case 125:
																													case 132:
																														goto end_IL_0314;
																													case 56:
																														goto end_IL_08b6;
																													case 88:
																														goto end_IL_08c9;
																													case 77:
																														goto end_IL_08d3;
																													case 80:
																														goto end_IL_08de;
																													case 95:
																													case 101:
																														goto end_IL_08ee;
																													case 110:
																														goto end_IL_08fe;
																													case 43:
																													case 63:
																														goto end_IL_090e;
																													case 141:
																														goto end_IL_0927;
																													case 142:
																														goto end_IL_0937;
																													case 82:
																													case 96:
																														goto IL_0952;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto IL_073f;
																												IL_073f:
																												num5--;
																												goto end_IL_0314;
																												continue;
																												end_IL_026b:
																												break;
																											}
																											break;
																										}
																										goto IL_0634;
																									}
																									goto IL_05bd;
																									IL_06ca:
																									array[num5 - 2] = 0;
																									goto IL_06de;
																									IL_05bd:
																									if (2 < b)
																									{
																										goto IL_05c8;
																									}
																									num = 55;
																									goto IL_061b;
																									IL_05c8:
																									if (3 < b)
																									{
																										goto end_IL_02e4;
																									}
																									goto IL_05d6;
																									IL_05d6:
																									if (3 > b)
																									{
																										goto end_IL_02e4;
																									}
																									goto IL_05e4;
																									IL_05e4:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0718;
																									IL_0718:
																									array[num5 - 1] = 5;
																									goto end_IL_0314;
																									IL_06de:
																									num5--;
																									goto end_IL_0314;
																									IL_061b:
																									if (2 > b)
																									{
																										goto IL_0626;
																									}
																									goto IL_068a;
																									IL_0626:
																									if (1 < b)
																									{
																										goto end_IL_02e4;
																									}
																									goto IL_0634;
																									IL_0634:
																									if (1 > b)
																									{
																										goto end_IL_02e4;
																									}
																									goto IL_0642;
																									IL_0642:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_065b;
																									IL_065b:
																									array[num5] = 0;
																									goto IL_0669;
																									IL_0669:
																									num5++;
																									goto IL_0677;
																									IL_0677:
																									ptr2 += 8;
																									goto end_IL_0314;
																									IL_068a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_06ca;
																									continue;
																									end_IL_02a7:
																									break;
																								}
																								continue;
																							}
																							goto IL_0752;
																							IL_0867:
																							ptr2 += 8;
																							num = 44;
																							goto IL_087e;
																							IL_0752:
																							if (6 >= b)
																							{
																								goto IL_0760;
																							}
																							goto IL_0828;
																							IL_0760:
																							if (6 <= b)
																							{
																								goto IL_076b;
																							}
																							goto IL_07bd;
																							IL_076b:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07aa;
																							IL_07aa:
																							num5 -= 3;
																							goto end_IL_0314;
																							IL_07bd:
																							if (5 < b)
																							{
																								num = 133;
																								goto end_IL_02e4;
																							}
																							goto IL_07c8;
																							IL_07c8:
																							if (5 > b)
																							{
																								goto end_IL_02e4;
																							}
																							goto IL_07d6;
																							IL_07d6:
																							array[num5] = 5;
																							goto IL_07e4;
																							IL_07e4:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_07fc;
																							IL_07fc:
																							num5++;
																							goto IL_080a;
																							IL_080a:
																							ptr2 += 8;
																							goto end_IL_0314;
																							IL_087e:
																							num5--;
																							goto end_IL_0314;
																							IL_0828:
																							if (7 < b)
																							{
																								goto end_IL_02e4;
																							}
																							goto IL_0833;
																							IL_0833:
																							if (7 > b)
																							{
																								goto end_IL_02e4;
																							}
																							goto IL_083e;
																							IL_083e:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0867;
																							continue;
																							end_IL_02b7:
																							break;
																						}
																						continue;
																					}
																					goto IL_088e;
																					IL_088e:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0314;
																					continue;
																					end_IL_02c7:
																					break;
																				}
																				continue;
																			}
																			goto IL_031f;
																			IL_051a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05aa;
																			IL_031f:
																			if (12 >= b)
																			{
																				goto IL_032d;
																			}
																			goto IL_042e;
																			IL_032d:
																			if (12 <= b)
																			{
																				goto IL_0338;
																			}
																			goto IL_039f;
																			IL_0338:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0378;
																			IL_0378:
																			array[num5 - 2] = 0;
																			goto IL_038c;
																			IL_038c:
																			num5--;
																			goto end_IL_0314;
																			IL_039f:
																			if (10 < b)
																			{
																				goto IL_03aa;
																			}
																			num = 104;
																			goto IL_0478;
																			IL_03aa:
																			if (11 < b)
																			{
																				num = 17;
																				goto end_IL_02e4;
																			}
																			goto IL_03b5;
																			IL_03b5:
																			if (11 > b)
																			{
																				goto end_IL_02e4;
																			}
																			goto IL_03c3;
																			IL_03c3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 140;
																			goto IL_06f1;
																			IL_06f1:
																			array[num5 - 2] = 0;
																			goto IL_0705;
																			IL_0705:
																			num5--;
																			goto end_IL_0314;
																			IL_044c:
																			if (15 < b)
																			{
																				num = 31;
																				goto end_IL_02e4;
																			}
																			goto IL_0457;
																			IL_05aa:
																			num5 -= 2;
																			goto end_IL_0314;
																			IL_0478:
																			if (10 <= b)
																			{
																				goto IL_0486;
																			}
																			goto IL_057e;
																			IL_0486:
																			array[num5] = 0;
																			goto IL_0494;
																			IL_0494:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04b7;
																			IL_04b7:
																			array2[num5] = null;
																			goto IL_04c1;
																			IL_04c1:
																			num5++;
																			goto IL_04cf;
																			IL_04cf:
																			ptr2 += 8;
																			goto end_IL_0314;
																			IL_057e:
																			if (9 < b)
																			{
																				num = 134;
																				goto end_IL_02e4;
																			}
																			goto IL_0589;
																			IL_0589:
																			if (9 > b)
																			{
																				goto end_IL_02e4;
																			}
																			goto end_IL_0314;
																			IL_0457:
																			if (15 <= b)
																			{
																			}
																			goto end_IL_02e4;
																			IL_042e:
																			if (14 >= b)
																			{
																				goto IL_0439;
																			}
																			goto IL_044c;
																			IL_0439:
																			if (14 <= b)
																			{
																				goto IL_04e2;
																			}
																			goto IL_04fe;
																			IL_04e2:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0314;
																			IL_04fe:
																			if (13 < b)
																			{
																				goto end_IL_02e4;
																			}
																			goto IL_050c;
																			IL_050c:
																			if (13 > b)
																			{
																				goto end_IL_02e4;
																			}
																			goto IL_051a;
																			continue;
																			end_IL_02d7:
																			break;
																		}
																		continue;
																		end_IL_02e4:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0314;
																continue;
																end_IL_02f4:
																break;
															}
															continue;
															end_IL_0304:
															break;
														}
														continue;
														end_IL_0314:
														break;
													}
													continue;
												}
												goto IL_0952;
												IL_0952:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b6:
												break;
											}
											continue;
											end_IL_08c9:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08de:
									break;
								}
								continue;
								end_IL_08ee:
								break;
							}
							continue;
							end_IL_08fe:
							break;
						}
						continue;
						end_IL_090e:
						break;
					}
					continue;
					end_IL_0927:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_3)
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllowBracesgetContinuationOptions.RuntimeCompatibilityAttributeCaster);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03b9:
														byte b = *ptr2;
														while (true)
														{
															IL_03a9:
															ptr2++;
															while (true)
															{
																IL_0399:
																if (b >= 1)
																{
																	goto IL_020a;
																}
																goto IL_0378;
																IL_0378:
																while (true)
																{
																	IL_0378_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 122;
																	while (num != 122 && num == 1103)
																	{
																		switch (num)
																		{
																		case 12:
																			goto IL_020a;
																		case 8:
																			goto IL_0221;
																		case 19:
																			goto IL_022c;
																		case 10:
																			goto IL_0237;
																		case 20:
																			goto IL_0247;
																		case 39:
																		case 66:
																			goto IL_025a;
																		case 5:
																		case 13:
																			goto IL_0265;
																		case 18:
																			goto IL_0273;
																		case 60:
																			goto IL_0286;
																		case 33:
																		case 92:
																			goto IL_02a2;
																		case 86:
																			goto IL_02ad;
																		case 27:
																		case 108:
																			goto IL_02c9;
																		case 102:
																			goto IL_02d7;
																		case 74:
																		case 109:
																			goto IL_02ea;
																		case 48:
																			goto IL_02f5;
																		case 71:
																			goto IL_0303;
																		case 51:
																			goto IL_030e;
																		case 0:
																			goto IL_031e;
																		case 95:
																			goto IL_0332;
																		case 94:
																			goto IL_0342;
																		case 50:
																		case 101:
																			goto IL_034d;
																		case 38:
																			goto IL_035a;
																		case 115:
																			goto IL_036a;
																		case 3:
																		case 4:
																		case 7:
																		case 16:
																		case 17:
																		case 28:
																		case 32:
																		case 41:
																		case 42:
																		case 43:
																		case 45:
																		case 46:
																		case 56:
																		case 62:
																		case 69:
																		case 82:
																		case 83:
																		case 85:
																		case 90:
																		case 91:
																		case 105:
																		case 107:
																			goto IL_0378_2;
																		case 24:
																			goto IL_0399;
																		case 53:
																			goto IL_03a9;
																		case 80:
																		case 111:
																			goto IL_03b9;
																		case 9:
																		case 23:
																			goto IL_03c4;
																		case 55:
																			goto IL_03e7;
																		case 52:
																			goto IL_03f5;
																		case 15:
																			goto IL_0403;
																		case 14:
																		case 89:
																			goto IL_0416;
																		case 47:
																			goto IL_0456;
																		case 37:
																		case 93:
																			goto IL_046f;
																		case 21:
																		case 104:
																			goto IL_0494;
																		case 84:
																			goto IL_04d4;
																		case 81:
																			goto IL_04e8;
																		case 54:
																		case 106:
																			goto IL_04fb;
																		case 70:
																			goto IL_055d;
																		case 35:
																		case 57:
																			goto IL_0570;
																		case 99:
																			goto IL_0589;
																		case 34:
																			goto IL_0597;
																		case 36:
																			goto IL_05a5;
																		case 6:
																		case 73:
																			goto IL_05b8;
																		case 97:
																			goto IL_05ea;
																		case 100:
																			goto IL_05f8;
																		case 110:
																			goto IL_0608;
																		case 98:
																		case 114:
																			goto IL_0618;
																		case 79:
																		case 88:
																			goto IL_062d;
																		case 65:
																			goto IL_063b;
																		case 77:
																			goto IL_065e;
																		case 26:
																			goto IL_0668;
																		case 31:
																			goto IL_0676;
																		case 1:
																		case 2:
																		case 11:
																		case 25:
																		case 29:
																		case 44:
																		case 61:
																		case 63:
																		case 64:
																		case 75:
																		case 78:
																		case 87:
																		case 113:
																			goto end_IL_01f7;
																		case 103:
																			goto end_IL_0684;
																		case 40:
																			goto end_IL_0697;
																		case 22:
																			goto end_IL_06a1;
																		case 112:
																			goto end_IL_06ac;
																		case 30:
																		case 49:
																			goto end_IL_06c1;
																		case 72:
																			goto end_IL_06d1;
																		case 58:
																		case 96:
																			goto end_IL_06e1;
																		case 67:
																			goto end_IL_06f1;
																		case 68:
																			goto end_IL_0701;
																		case 59:
																		case 76:
																			goto IL_071c;
																		}
																		continue;
																		end_IL_01f7:
																		break;
																	}
																	break;
																}
																break;
																IL_020a:
																if (b <= 11)
																{
																	num = 8;
																	goto IL_0221;
																}
																goto IL_0378;
																IL_035a:
																if (4 <= b)
																{
																	break;
																}
																goto IL_0378;
																IL_0221:
																if (6 < b)
																{
																	goto IL_022c;
																}
																goto IL_0247;
																IL_022c:
																if (9 >= b)
																{
																	goto IL_0237;
																}
																goto IL_02a2;
																IL_0237:
																if (9 > b)
																{
																	goto IL_025a;
																}
																goto IL_04fb;
																IL_025a:
																if (7 < b)
																{
																	goto IL_0265;
																}
																goto IL_0286;
																IL_0265:
																if (8 >= b)
																{
																	goto IL_0273;
																}
																goto IL_0378;
																IL_0273:
																if (8 > b)
																{
																	goto IL_0378;
																}
																goto IL_03c4;
																IL_03c4:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_03e7;
																IL_03e7:
																array[num5] = 0;
																goto IL_03f5;
																IL_03f5:
																num5++;
																goto IL_0403;
																IL_0403:
																ptr2 += 8;
																break;
																IL_0286:
																if (7 > b)
																{
																	num = 69;
																	goto IL_0378;
																}
																goto IL_0494;
																IL_0416:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0456;
																IL_0494:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04d4;
																IL_04d4:
																array[num5 - 2] = 0;
																goto IL_04e8;
																IL_04e8:
																num5--;
																break;
																IL_04fb:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_055d;
																IL_055d:
																num5 -= 2;
																break;
																IL_02a2:
																if (10 >= b)
																{
																	goto IL_02ad;
																}
																goto IL_02c9;
																IL_02ad:
																if (10 > b)
																{
																	num = 28;
																	goto IL_0378;
																}
																goto IL_046f;
																IL_0456:
																array[num5 - 2] = 0;
																goto IL_0608;
																IL_046f:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																num = 2;
																break;
																IL_02c9:
																if (11 >= b)
																{
																	goto IL_02d7;
																}
																goto IL_0378;
																IL_02d7:
																if (11 > b)
																{
																}
																goto IL_0378;
																IL_0247:
																if (6 > b)
																{
																	goto IL_02ea;
																}
																goto IL_0416;
																IL_02ea:
																if (3 >= b)
																{
																	goto IL_02f5;
																}
																goto IL_0342;
																IL_02f5:
																if (3 > b)
																{
																	goto IL_0303;
																}
																goto IL_0618;
																IL_0303:
																if (1 >= b)
																{
																	goto IL_030e;
																}
																goto IL_031e;
																IL_030e:
																if (1 > b)
																{
																	goto IL_0378;
																}
																goto IL_0570;
																IL_0570:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0589;
																IL_0589:
																array[num5] = 0;
																goto IL_0597;
																IL_0597:
																num5++;
																goto IL_05a5;
																IL_05a5:
																ptr2 += 8;
																break;
																IL_031e:
																if (2 >= b)
																{
																	num = 95;
																	goto IL_0332;
																}
																goto IL_0378;
																IL_0608:
																num5--;
																break;
																IL_0332:
																if (2 > b)
																{
																	goto IL_0378;
																}
																goto IL_05b8;
																IL_05b8:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 97;
																goto IL_05ea;
																IL_05ea:
																ptr2 += 8;
																goto IL_05f8;
																IL_05f8:
																num5--;
																break;
																IL_0618:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0342:
																if (4 < b)
																{
																	goto IL_034d;
																}
																goto IL_035a;
																IL_034d:
																if (5 >= b)
																{
																	goto IL_036a;
																}
																goto IL_0378;
																IL_036a:
																if (5 > b)
																{
																	goto IL_0378;
																}
																goto IL_062d;
																IL_062d:
																array[num5] = 0;
																goto IL_063b;
																IL_063b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_065e;
																IL_065e:
																array2[num5] = null;
																goto IL_0668;
																IL_0668:
																num5++;
																goto IL_0676;
																IL_0676:
																ptr2 += 8;
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_071c;
												IL_071c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0684:
												break;
											}
											continue;
											end_IL_0697:
											break;
										}
										continue;
										end_IL_06a1:
										break;
									}
									continue;
									end_IL_06ac:
									break;
								}
								continue;
								end_IL_06c1:
								break;
							}
							continue;
							end_IL_06d1:
							break;
						}
						continue;
						end_IL_06e1:
						break;
					}
					continue;
					end_IL_06f1:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_3)
	{
		int num = 80;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XmlElementNameGetDocument.ScheduledExclusiveDebugView);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0347:
														byte b = *ptr2;
														while (true)
														{
															IL_0337:
															ptr2++;
															while (true)
															{
																IL_0327:
																if (b >= 1)
																{
																	goto IL_01d6;
																}
																goto IL_0306;
																IL_0306:
																while (true)
																{
																	IL_0306_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 109;
																	while (num != 109)
																	{
																		if (num != 1090)
																		{
																			goto IL_045e;
																		}
																		switch (num)
																		{
																		case 52:
																			goto IL_01d6;
																		case 48:
																			goto IL_01e4;
																		case 45:
																			goto IL_01ef;
																		case 25:
																		case 36:
																			goto IL_01fd;
																		case 41:
																			goto IL_0211;
																		case 32:
																			goto IL_0224;
																		case 20:
																			goto IL_0232;
																		case 64:
																			goto IL_0245;
																		case 2:
																			goto IL_0253;
																		case 50:
																			goto IL_025e;
																		case 46:
																			goto IL_026c;
																		case 9:
																			goto IL_027c;
																		case 12:
																		case 62:
																			goto IL_0287;
																		case 10:
																			goto IL_0294;
																		case 71:
																			goto IL_02a4;
																		case 73:
																			goto IL_02b4;
																		case 100:
																			goto IL_02c4;
																		case 57:
																			goto IL_02d2;
																		case 5:
																		case 89:
																			goto IL_02dd;
																		case 66:
																			goto IL_02e8;
																		case 51:
																			goto IL_02f8;
																		case 11:
																		case 14:
																		case 15:
																		case 21:
																		case 22:
																		case 26:
																		case 34:
																		case 35:
																		case 40:
																		case 43:
																		case 53:
																		case 67:
																		case 68:
																		case 69:
																		case 70:
																		case 72:
																		case 92:
																		case 96:
																		case 97:
																			goto IL_0306_2;
																		case 59:
																			goto IL_0327;
																		case 30:
																			goto IL_0337;
																		case 4:
																		case 7:
																			goto IL_0347;
																		case 1:
																		case 65:
																			goto IL_0352;
																		case 58:
																			goto IL_036b;
																		case 78:
																			goto IL_0379;
																		case 13:
																			goto IL_0387;
																		case 17:
																		case 81:
																			goto IL_039a;
																		case 60:
																		case 84:
																			goto IL_03b6;
																		case 42:
																			goto IL_03cd;
																		case 83:
																			goto IL_03f0;
																		case 82:
																			goto IL_03fa;
																		case 47:
																		case 86:
																			goto IL_040d;
																		case 85:
																			goto IL_0436;
																		case 8:
																		case 87:
																			goto IL_0446;
																		case 88:
																			goto IL_045e;
																		case 16:
																		case 44:
																			goto IL_0471;
																		case 63:
																			goto IL_0494;
																		case 54:
																			goto IL_04a2;
																		case 94:
																			goto IL_04b0;
																		case 31:
																		case 91:
																			goto IL_04c3;
																		case 77:
																			goto IL_0503;
																		case 49:
																			goto IL_0517;
																		case 33:
																		case 76:
																			goto IL_0533;
																		case 90:
																			goto IL_0595;
																		case 102:
																			goto IL_05ae;
																		case 0:
																		case 3:
																		case 6:
																		case 18:
																		case 19:
																		case 23:
																		case 28:
																		case 56:
																		case 61:
																		case 95:
																		case 99:
																		case 101:
																			goto end_IL_01c3;
																		case 37:
																			goto end_IL_05bc;
																		case 38:
																			goto end_IL_05cf;
																		case 75:
																			goto end_IL_05d9;
																		case 29:
																			goto end_IL_05e4;
																		case 74:
																		case 93:
																			goto end_IL_05f9;
																		case 39:
																			goto end_IL_0609;
																		case 27:
																		case 98:
																			goto end_IL_0619;
																		case 79:
																			goto end_IL_0629;
																		case 80:
																			goto end_IL_0639;
																		case 24:
																		case 55:
																			goto IL_0654;
																		}
																		continue;
																		end_IL_01c3:
																		break;
																	}
																	break;
																}
																break;
																IL_01d6:
																if (b <= 10)
																{
																	goto IL_01e4;
																}
																goto IL_0306;
																IL_01e4:
																if (5 < b)
																{
																	goto IL_01ef;
																}
																goto IL_0245;
																IL_01ef:
																if (8 < b)
																{
																	goto IL_01fd;
																}
																goto IL_02c4;
																IL_01fd:
																if (9 >= b)
																{
																	num = 41;
																	goto IL_0211;
																}
																goto IL_0224;
																IL_05ae:
																ptr2 += 8;
																break;
																IL_0211:
																if (9 > b)
																{
																	goto IL_0306;
																}
																goto IL_039a;
																IL_039a:
																byte* num5 = ptr2;
																num4 = 1;
																ptr2 = num5 + -200;
																break;
																IL_0224:
																if (10 >= b)
																{
																	goto IL_0232;
																}
																goto IL_0306;
																IL_0232:
																if (10 <= b)
																{
																}
																goto IL_0306;
																IL_02c4:
																if (8 > b)
																{
																	goto IL_02d2;
																}
																goto IL_0533;
																IL_02d2:
																if (6 < b)
																{
																	goto IL_02dd;
																}
																goto IL_02f8;
																IL_02dd:
																if (7 >= b)
																{
																	goto IL_02e8;
																}
																goto IL_0306;
																IL_02e8:
																if (7 > b)
																{
																	goto IL_0306;
																}
																goto IL_0471;
																IL_0471:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0494;
																IL_0494:
																array[num6] = 0;
																goto IL_04a2;
																IL_04a2:
																num6++;
																goto IL_04b0;
																IL_04b0:
																ptr2 += 8;
																break;
																IL_02f8:
																if (6 > b)
																{
																	goto IL_0306;
																}
																goto IL_04c3;
																IL_04c3:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0503;
																IL_0503:
																array[num6 - 2] = 0;
																goto IL_0517;
																IL_0517:
																num6--;
																num = 101;
																break;
																IL_0533:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0595;
																IL_0595:
																num6 -= 2;
																num = 18;
																break;
																IL_0245:
																if (5 > b)
																{
																	goto IL_0253;
																}
																goto IL_03b6;
																IL_0253:
																if (2 >= b)
																{
																	goto IL_025e;
																}
																goto IL_027c;
																IL_025e:
																if (2 > b)
																{
																	goto IL_026c;
																}
																goto IL_040d;
																IL_026c:
																if (1 >= b)
																{
																	goto IL_02b4;
																}
																goto IL_0306;
																IL_02b4:
																if (1 > b)
																{
																	goto IL_0306;
																}
																goto IL_0352;
																IL_0352:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																goto IL_036b;
																IL_036b:
																array[num6] = 0;
																goto IL_0379;
																IL_0379:
																num6++;
																goto IL_0387;
																IL_0387:
																ptr2 += 8;
																break;
																IL_040d:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0436;
																IL_0436:
																ptr2 += 8;
																goto IL_045e;
																IL_045e:
																num6--;
																break;
																IL_027c:
																if (3 < b)
																{
																	goto IL_0287;
																}
																goto IL_0294;
																IL_0287:
																if (4 >= b)
																{
																	goto IL_02a4;
																}
																goto IL_0306;
																IL_02a4:
																if (4 <= b)
																{
																	break;
																}
																goto IL_0306;
																IL_0294:
																if (3 > b)
																{
																	goto IL_0306;
																}
																goto IL_0446;
																IL_0446:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_03b6:
																array[num6] = 0;
																num = 42;
																goto IL_03cd;
																IL_03cd:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_03f0;
																IL_03f0:
																array2[num6] = null;
																goto IL_03fa;
																IL_03fa:
																num6++;
																goto IL_05ae;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0654;
												IL_0654:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05bc:
												break;
											}
											continue;
											end_IL_05cf:
											break;
										}
										continue;
										end_IL_05d9:
										break;
									}
									continue;
									end_IL_05e4:
									break;
								}
								continue;
								end_IL_05f9:
								break;
							}
							continue;
							end_IL_0609:
							break;
						}
						continue;
						end_IL_0619:
						break;
					}
					continue;
					end_IL_0629:
					break;
				}
				continue;
				end_IL_0639:
				break;
			}
		}
	}

	static Class110()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0064:
				Class300.smethod_0();
				num = 5;
				while (true)
				{
					IL_0052:
					num = 3;
					while (true)
					{
						IL_0046:
						num = 12;
						while (true)
						{
							if (num != 12)
							{
								if (num != 993)
								{
									break;
								}
								switch (num)
								{
								case 3:
									goto IL_0046;
								case 2:
								case 4:
								case 5:
									goto IL_0052;
								case 0:
									goto IL_0064;
								case 1:
									goto end_IL_0039;
								}
								continue;
							}
							return;
							continue;
							end_IL_0039:
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
