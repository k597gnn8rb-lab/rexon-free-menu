using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 162)]
internal struct AssemblyIsPrivatesetSign
{
	internal static AssemblyIsPrivatesetSign ResourceManagerAddingCultureFromConfigFileAddArgument/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 03 00 00 00 02 02 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 04 03 00 00 00 03 03 00 00 00 05 00 00 00 02 02 00 00 00 05 00 00 00 03 03 00 00 00 06 03 00 00 00 04 04 00 00 00 05 00 00 00 04 04 00 00 00 07 00 00 00 69 69 00 00 00 07 00 00 00 05 05 00 00 00 08 02 07 00 00 00 8C 8C 00 00 00 07 00 00 00 07 07 00 00 00 08 07 00 00 00 96 96 00 00 00 07 00 00 00 05 05 00 00 00 08 09 00 00 00 00 00 00 00 00 0A 0B) */;
}
