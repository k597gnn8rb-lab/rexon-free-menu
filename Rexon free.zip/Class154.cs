using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Remove Snowball Knockback", "Safety", "Removes snowball knockback.", false, 9, ModType.const_0, false)]
internal class Class154 : MonoBehaviour
{
	internal static bool bool_0;

	private static float float_0;

	private static int int_0;

	private static float float_1;

	private static double double_0;

	private static int int_1;

	private static bool bool_1;

	private static IntPtr[] NumberBufferThreadPoolWorkQueueThreadLocals;

	private static IntPtr[] GetSystemVersionObjectWithMapAssemId;

	private static IntPtr[] PreferredBitCreateSpecificCulture;

	private static IntPtr[] getParentWindowHandleConstructorOnTypeBuilderInstantiation;

	private unsafe void OnEnable()
	{
		int num = 24;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							num = 51;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ThreadStartExceptionRuntimeType.setWindowTopDNNd);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											num = 29;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_02f8:
															if (b >= 1)
															{
																while (b <= 14)
																{
																	while (true)
																	{
																		IL_02d8:
																		if (7 >= b)
																		{
																			while (true)
																			{
																				IL_02c8:
																				if (7 > b)
																				{
																					while (true)
																					{
																						IL_02b8:
																						if (3 >= b)
																						{
																							while (true)
																							{
																								IL_02ab:
																								if (3 > b)
																								{
																									while (true)
																									{
																										IL_029b:
																										if (1 >= b)
																										{
																											while (1 > b)
																											{
																												num = 150;
																												while (num != 150)
																												{
																													if (num != 1131)
																													{
																														goto IL_0363;
																													}
																													switch (num)
																													{
																													case 106:
																														goto IL_0288;
																													case 83:
																														goto IL_029b;
																													case 107:
																														goto IL_02ab;
																													case 54:
																														goto IL_02b8;
																													case 122:
																														goto IL_02c8;
																													case 115:
																														goto IL_02d8;
																													case 3:
																														goto IL_02e8;
																													case 46:
																														goto IL_02f8;
																													case 126:
																														goto end_IL_02f8;
																													case 96:
																													case 123:
																														goto end_IL_0308;
																													case 1:
																													case 6:
																														goto IL_0323;
																													case 45:
																														goto IL_0355;
																													case 82:
																														goto IL_0363;
																													case 30:
																													case 110:
																														goto IL_0376;
																													case 119:
																														goto IL_0384;
																													case 62:
																													case 74:
																														goto IL_0392;
																													case 92:
																														goto IL_03d2;
																													case 47:
																														goto IL_03e6;
																													case 137:
																														goto IL_03f9;
																													case 70:
																														goto IL_0407;
																													case 21:
																													case 84:
																														goto IL_0412;
																													case 104:
																														goto IL_0452;
																													case 15:
																														goto IL_0466;
																													case 13:
																														goto IL_0479;
																													case 25:
																														goto IL_0487;
																													case 59:
																													case 66:
																														goto IL_0495;
																													case 18:
																														goto IL_04a3;
																													case 112:
																														goto IL_04c6;
																													case 75:
																														goto IL_04d0;
																													case 99:
																														goto IL_04e7;
																													case 72:
																														goto IL_04fa;
																													case 53:
																														goto IL_0508;
																													case 9:
																													case 76:
																														goto IL_0516;
																													case 42:
																														goto IL_0556;
																													case 80:
																														goto IL_0573;
																													case 77:
																													case 93:
																														goto IL_0586;
																													case 140:
																														goto IL_05cf;
																													case 108:
																														goto IL_05e3;
																													case 61:
																														goto IL_05f6;
																													case 10:
																													case 41:
																														goto IL_0604;
																													case 113:
																													case 135:
																														goto IL_060f;
																													case 71:
																														goto IL_061d;
																													case 11:
																													case 132:
																														goto IL_062b;
																													case 44:
																														goto IL_0647;
																													case 58:
																													case 117:
																														goto IL_0652;
																													case 38:
																														goto IL_0660;
																													case 31:
																													case 67:
																														goto IL_0673;
																													case 100:
																														goto IL_068d;
																													case 88:
																														goto IL_06a0;
																													case 97:
																														goto IL_06ae;
																													case 12:
																													case 69:
																														goto IL_06bc;
																													case 134:
																														goto IL_06ca;
																													case 55:
																													case 91:
																														goto IL_06d8;
																													case 79:
																														goto IL_073a;
																													case 4:
																														goto IL_074d;
																													case 2:
																													case 5:
																														goto IL_0758;
																													case 131:
																														goto IL_0766;
																													case 28:
																													case 111:
																														goto IL_0774;
																													case 20:
																													case 121:
																														goto IL_0787;
																													case 22:
																														goto IL_07c7;
																													case 143:
																														goto IL_07db;
																													case 26:
																													case 85:
																														goto IL_07f7;
																													case 48:
																														goto IL_080b;
																													case 102:
																														goto IL_085f;
																													case 133:
																														goto IL_086d;
																													case 7:
																													case 8:
																													case 14:
																													case 16:
																													case 40:
																													case 43:
																													case 52:
																													case 56:
																													case 57:
																													case 60:
																													case 63:
																													case 64:
																													case 65:
																													case 68:
																													case 73:
																													case 78:
																													case 81:
																													case 87:
																													case 90:
																													case 95:
																													case 98:
																													case 109:
																													case 127:
																													case 128:
																													case 129:
																													case 136:
																													case 138:
																													case 139:
																														goto end_IL_0275;
																													case 34:
																														goto IL_0896;
																													case 89:
																														goto IL_08a4;
																													case 33:
																														goto IL_08b2;
																													case 0:
																													case 17:
																													case 19:
																													case 29:
																													case 36:
																													case 37:
																													case 49:
																													case 50:
																													case 86:
																													case 101:
																													case 105:
																													case 114:
																													case 120:
																													case 125:
																													case 130:
																													case 141:
																														goto end_IL_0318;
																													case 116:
																														goto end_IL_08c0;
																													case 142:
																														goto end_IL_08d3;
																													case 35:
																														goto end_IL_08de;
																													case 51:
																														goto end_IL_08e8;
																													case 27:
																													case 39:
																														goto end_IL_08f3;
																													case 103:
																														goto end_IL_0903;
																													case 32:
																													case 118:
																														goto end_IL_091c;
																													case 23:
																														goto end_IL_092c;
																													case 24:
																														goto end_IL_093c;
																													case 94:
																													case 124:
																														return;
																													}
																													continue;
																													end_IL_0275:
																													break;
																												}
																												break;
																												IL_0288:;
																											}
																											break;
																										}
																										goto IL_0376;
																										IL_03e6:
																										num5--;
																										goto end_IL_0318;
																										IL_0376:
																										if (2 < b)
																										{
																											break;
																										}
																										goto IL_0384;
																										IL_0384:
																										if (2 > b)
																										{
																											break;
																										}
																										goto IL_0392;
																										IL_0392:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03d2;
																										IL_03d2:
																										array[num5 - 2] = 0;
																										goto IL_03e6;
																									}
																									break;
																								}
																								goto IL_0323;
																								IL_0363:
																								num5--;
																								goto end_IL_0318;
																								IL_0323:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 45;
																								goto IL_0355;
																								IL_0355:
																								ptr2 += 8;
																								goto IL_0363;
																							}
																							break;
																						}
																						goto IL_03f9;
																						IL_0573:
																						num5--;
																						goto end_IL_0318;
																						IL_03f9:
																						if (5 >= b)
																						{
																							goto IL_0407;
																						}
																						goto IL_04fa;
																						IL_0407:
																						if (5 <= b)
																						{
																							goto IL_0412;
																						}
																						goto IL_0479;
																						IL_0412:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0452;
																						IL_0452:
																						array[num5 - 2] = 0;
																						goto IL_0466;
																						IL_0466:
																						num5--;
																						goto end_IL_0318;
																						IL_0479:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0487;
																						IL_0487:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0495;
																						IL_0495:
																						array[num5] = 0;
																						goto IL_04a3;
																						IL_04a3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_04c6;
																						IL_04c6:
																						array2[num5] = null;
																						goto IL_04d0;
																						IL_04d0:
																						num5++;
																						num = 99;
																						goto IL_04e7;
																						IL_04e7:
																						ptr2 += 8;
																						goto end_IL_0318;
																						IL_04fa:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0508;
																						IL_0508:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0516;
																						IL_0516:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0556;
																						IL_0556:
																						array[num5 - 2] = 0;
																						num = 80;
																						goto IL_0573;
																					}
																					break;
																				}
																				goto IL_0586;
																				IL_05e3:
																				num5--;
																				goto end_IL_0318;
																				IL_0586:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 140;
																				goto IL_05cf;
																				IL_05cf:
																				array[num5 - 2] = 0;
																				goto IL_05e3;
																			}
																			break;
																		}
																		goto IL_05f6;
																		IL_085f:
																		num5--;
																		goto IL_086d;
																		IL_05f6:
																		if (11 < b)
																		{
																			goto IL_0604;
																		}
																		goto IL_06a0;
																		IL_0604:
																		if (13 < b)
																		{
																			goto IL_060f;
																		}
																		goto IL_0647;
																		IL_060f:
																		if (14 < b)
																		{
																			break;
																		}
																		goto IL_061d;
																		IL_061d:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_062b;
																		IL_062b:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_0318;
																		IL_0647:
																		if (13 > b)
																		{
																			goto IL_0652;
																		}
																		goto IL_0673;
																		IL_0652:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_0660;
																		IL_0660:
																		if (12 <= b)
																		{
																			goto end_IL_0318;
																		}
																		break;
																		IL_0673:
																		bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																		goto IL_068d;
																		IL_068d:
																		num5--;
																		goto end_IL_0318;
																		IL_06a0:
																		if (11 > b)
																		{
																			goto IL_06ae;
																		}
																		num = 85;
																		goto IL_07f7;
																		IL_06ae:
																		if (9 < b)
																		{
																			goto IL_06bc;
																		}
																		goto IL_074d;
																		IL_06bc:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_06ca;
																		IL_06ca:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_06d8;
																		IL_06d8:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_073a;
																		IL_073a:
																		num5 -= 2;
																		goto end_IL_0318;
																		IL_074d:
																		if (9 > b)
																		{
																			goto IL_0758;
																		}
																		goto IL_0787;
																		IL_0758:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0766;
																		IL_0766:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0774;
																		IL_0774:
																		num5--;
																		goto end_IL_0318;
																		IL_0787:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_07c7;
																		IL_07c7:
																		array[num5 - 2] = 0;
																		goto IL_07db;
																		IL_07db:
																		num5--;
																		goto end_IL_0318;
																		IL_086d:
																		ptr2 += 8;
																		goto end_IL_0318;
																		IL_07f7:
																		array[num5 - 2] = 0;
																		goto IL_080b;
																		IL_080b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)NumberBufferThreadPoolWorkQueueThreadLocals[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																		goto IL_085f;
																	}
																	break;
																	IL_02e8:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_0896;
															IL_08b2:
															ptr2 += 8;
															goto end_IL_0318;
															IL_08a4:
															num5++;
															goto IL_08b2;
															IL_0896:
															array[num5] = 0;
															goto IL_08a4;
															continue;
															end_IL_02f8:
															break;
														}
														continue;
														end_IL_0308:
														break;
													}
													continue;
													end_IL_0318:
													break;
												}
												continue;
												end_IL_08c0:
												break;
											}
											continue;
											end_IL_08d3:
											break;
										}
										continue;
										end_IL_08de:
										break;
									}
									continue;
									end_IL_08e8:
									break;
								}
								continue;
								end_IL_08f3:
								break;
							}
							continue;
							end_IL_0903:
							break;
						}
						continue;
						end_IL_091c:
						break;
					}
					continue;
					end_IL_092c:
					break;
				}
				continue;
				end_IL_093c:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIgnorePortablePDBsInStackTracesgetModule.ApplicationActivatorsetForegroundColor);
									while (true)
									{
										byte* ptr2 = ptr;
										num = 29;
										while (true)
										{
											if (num4 != 1)
											{
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_0320:
															if (b >= 1)
															{
																while (b <= 14)
																{
																	while (true)
																	{
																		IL_0300:
																		if (7 >= b)
																		{
																			goto IL_055f;
																		}
																		while (true)
																		{
																			IL_02f0:
																			if (11 >= b)
																			{
																				while (true)
																				{
																					IL_02e3:
																					if (11 <= b)
																					{
																						while (true)
																						{
																							IL_02cd:
																							array[num5 - 2] = 0;
																							while (true)
																							{
																								IL_026e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)GetSystemVersionObjectWithMapAssemId[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								num = 147;
																								while (true)
																								{
																									if (num != 147)
																									{
																										if (num != 1128)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 42:
																											goto IL_026e;
																										case 9:
																										case 99:
																											goto IL_02cd;
																										case 28:
																											goto IL_02e3;
																										case 30:
																										case 104:
																											goto IL_02f0;
																										case 45:
																											goto IL_0300;
																										case 111:
																											goto end_IL_0300;
																										case 15:
																											goto IL_0320;
																										case 93:
																											goto end_IL_0320;
																										case 34:
																										case 91:
																											goto end_IL_0330;
																										case 58:
																											goto IL_034b;
																										case 40:
																											goto IL_0356;
																										case 19:
																										case 125:
																											goto IL_0364;
																										case 65:
																											goto IL_0372;
																										case 73:
																										case 134:
																											goto IL_0385;
																										case 54:
																											goto IL_0393;
																										case 21:
																										case 114:
																											goto IL_03a1;
																										case 81:
																											goto IL_0403;
																										case 44:
																										case 139:
																											goto IL_0416;
																										case 78:
																										case 140:
																											goto IL_0429;
																										case 55:
																											goto IL_0472;
																										case 13:
																											goto IL_0486;
																										case 41:
																											goto IL_04b0;
																										case 31:
																										case 109:
																											goto IL_04c3;
																										case 67:
																										case 88:
																											goto IL_04ce;
																										case 79:
																											goto IL_04dc;
																										case 17:
																										case 25:
																											goto IL_04ea;
																										case 103:
																											goto IL_0506;
																										case 37:
																										case 84:
																											goto IL_0511;
																										case 107:
																											goto IL_052b;
																										case 94:
																											goto IL_053e;
																										case 10:
																											goto IL_054c;
																										case 63:
																											goto IL_055f;
																										case 0:
																										case 23:
																											goto IL_056a;
																										case 98:
																											goto IL_05aa;
																										case 50:
																											goto IL_05be;
																										case 101:
																											goto IL_05d1;
																										case 5:
																											goto IL_05df;
																										case 43:
																											goto IL_05ed;
																										case 52:
																										case 86:
																											goto IL_05f8;
																										case 82:
																											goto IL_0638;
																										case 32:
																											goto IL_064c;
																										case 112:
																											goto IL_065f;
																										case 80:
																											goto IL_066d;
																										case 11:
																										case 18:
																											goto IL_067b;
																										case 72:
																											goto IL_0689;
																										case 138:
																											goto IL_06ac;
																										case 117:
																											goto IL_06b6;
																										case 33:
																											goto IL_06c4;
																										case 127:
																											goto end_IL_025b;
																										case 90:
																											goto IL_06ee;
																										case 64:
																										case 110:
																											goto IL_06fc;
																										case 69:
																											goto IL_073c;
																										case 128:
																											goto IL_0750;
																										case 76:
																											goto IL_0763;
																										case 12:
																										case 71:
																											goto IL_0771;
																										case 129:
																										case 136:
																											goto IL_0788;
																										case 14:
																											goto IL_0796;
																										case 16:
																										case 89:
																											goto IL_07a4;
																										case 35:
																											goto IL_07e4;
																										case 70:
																											goto IL_07f8;
																										case 60:
																											goto IL_080b;
																										case 92:
																										case 126:
																											goto IL_0818;
																										case 100:
																											goto IL_0841;
																										case 6:
																											goto IL_0858;
																										case 1:
																										case 4:
																										case 8:
																										case 20:
																										case 24:
																										case 27:
																										case 38:
																										case 47:
																										case 51:
																										case 53:
																										case 62:
																										case 66:
																										case 77:
																										case 87:
																										case 96:
																										case 105:
																										case 115:
																										case 118:
																										case 119:
																										case 120:
																										case 124:
																										case 130:
																										case 132:
																										case 133:
																										case 137:
																											goto end_IL_0310;
																										case 22:
																											goto IL_0881;
																										case 48:
																											goto IL_088f;
																										case 39:
																											goto IL_08a6;
																										case 2:
																										case 3:
																										case 7:
																										case 29:
																										case 36:
																										case 46:
																										case 49:
																										case 68:
																										case 75:
																										case 83:
																										case 95:
																										case 97:
																										case 102:
																										case 106:
																										case 108:
																										case 113:
																										case 131:
																											goto end_IL_0340;
																										case 135:
																											goto end_IL_08b4;
																										case 122:
																											goto end_IL_08c4;
																										case 85:
																											goto end_IL_08d7;
																										case 116:
																										case 123:
																											goto end_IL_08e2;
																										case 121:
																											goto end_IL_08f2;
																										case 59:
																										case 61:
																											goto end_IL_0902;
																										case 56:
																											goto end_IL_0912;
																										case 57:
																											goto end_IL_0922;
																										case 26:
																										case 74:
																											return;
																										}
																										continue;
																									}
																									num5--;
																									num = 41;
																									goto IL_04b0;
																									IL_04b0:
																									ptr2 += 8;
																									goto end_IL_0340;
																									continue;
																									end_IL_025b:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_034b;
																					IL_0403:
																					num5 -= 2;
																					goto end_IL_0340;
																					IL_034b:
																					if (9 >= b)
																					{
																						goto IL_0356;
																					}
																					goto IL_0385;
																					IL_0356:
																					if (9 > b)
																					{
																						goto IL_0364;
																					}
																					goto IL_0429;
																					IL_0364:
																					if (8 < b)
																					{
																						goto end_IL_0310;
																					}
																					goto IL_0372;
																					IL_0372:
																					if (8 > b)
																					{
																						goto end_IL_0310;
																					}
																					goto IL_0416;
																					IL_0416:
																					num5--;
																					goto end_IL_0340;
																					IL_0429:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 55;
																					goto IL_0472;
																					IL_0472:
																					array[num5 - 2] = 0;
																					goto IL_0486;
																					IL_0486:
																					num5--;
																					goto end_IL_0340;
																					IL_0385:
																					if (10 < b)
																					{
																						goto end_IL_0310;
																					}
																					goto IL_0393;
																					IL_0393:
																					if (10 > b)
																					{
																						goto end_IL_0310;
																					}
																					goto IL_03a1;
																					IL_03a1:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0403;
																				}
																				break;
																			}
																			goto IL_04c3;
																			IL_054c:
																			if (12 <= b)
																			{
																				goto end_IL_0340;
																			}
																			goto end_IL_0310;
																			IL_04c3:
																			if (13 < b)
																			{
																				goto IL_04ce;
																			}
																			goto IL_0506;
																			IL_04ce:
																			if (14 < b)
																			{
																				goto end_IL_0310;
																			}
																			goto IL_04dc;
																			IL_04dc:
																			if (14 > b)
																			{
																				goto end_IL_0310;
																			}
																			goto IL_04ea;
																			IL_04ea:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0340;
																			IL_0506:
																			if (13 <= b)
																			{
																				goto IL_0511;
																			}
																			goto IL_053e;
																			IL_0511:
																			bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_052b;
																			IL_052b:
																			num5--;
																			goto end_IL_0340;
																			IL_053e:
																			if (12 < b)
																			{
																				goto end_IL_0310;
																			}
																			goto IL_054c;
																		}
																		goto IL_06e0;
																		IL_0841:
																		ptr2 += 8;
																		num = 6;
																		goto IL_0858;
																		IL_055f:
																		if (7 <= b)
																		{
																			goto IL_056a;
																		}
																		goto IL_05d1;
																		IL_056a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05aa;
																		IL_05aa:
																		array[num5 - 2] = 0;
																		goto IL_05be;
																		IL_05be:
																		num5--;
																		goto end_IL_0340;
																		IL_05d1:
																		if (3 < b)
																		{
																			goto IL_05df;
																		}
																		goto IL_0763;
																		IL_05df:
																		if (5 >= b)
																		{
																			goto IL_05ed;
																		}
																		goto IL_06e0;
																		IL_05ed:
																		if (5 <= b)
																		{
																			goto IL_05f8;
																		}
																		goto IL_065f;
																		IL_05f8:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0638;
																		IL_0638:
																		array[num5 - 2] = 0;
																		goto IL_064c;
																		IL_064c:
																		num5--;
																		goto end_IL_0340;
																		IL_065f:
																		if (4 < b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_066d;
																		IL_066d:
																		if (4 > b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_067b;
																		IL_067b:
																		array[num5] = 0;
																		goto IL_0689;
																		IL_0689:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06ac;
																		IL_06ac:
																		array2[num5] = null;
																		goto IL_06b6;
																		IL_06b6:
																		num5++;
																		goto IL_06c4;
																		IL_06c4:
																		ptr2 += 8;
																		num = 108;
																		goto end_IL_0340;
																		IL_06e0:
																		if (6 < b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_06ee;
																		IL_06ee:
																		if (6 > b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_06fc;
																		IL_06fc:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_073c;
																		IL_073c:
																		array[num5 - 2] = 0;
																		goto IL_0750;
																		IL_0750:
																		num5--;
																		goto end_IL_0340;
																		IL_0763:
																		if (3 > b)
																		{
																			goto IL_0771;
																		}
																		goto IL_0818;
																		IL_0771:
																		if (1 < b)
																		{
																			num = 129;
																			goto IL_0788;
																		}
																		goto IL_080b;
																		IL_0858:
																		num5--;
																		goto end_IL_0340;
																		IL_0788:
																		if (2 < b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_0796;
																		IL_0796:
																		if (2 > b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_07a4;
																		IL_07a4:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_07e4;
																		IL_07e4:
																		array[num5 - 2] = 0;
																		goto IL_07f8;
																		IL_07f8:
																		num5--;
																		goto end_IL_0340;
																		IL_080b:
																		if (1 > b)
																		{
																		}
																		goto end_IL_0310;
																		IL_0818:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0841;
																		continue;
																		end_IL_0300:
																		break;
																	}
																	continue;
																	end_IL_0310:
																	break;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_0881;
															IL_08a6:
															ptr2 += 8;
															goto end_IL_0340;
															IL_088f:
															num5++;
															num = 39;
															goto IL_08a6;
															IL_0881:
															array[num5] = 0;
															goto IL_088f;
															continue;
															end_IL_0320:
															break;
														}
														continue;
														end_IL_0330:
														break;
													}
													continue;
													end_IL_0340:
													break;
												}
												continue;
											}
											num = 26;
											return;
											continue;
											end_IL_08b4:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08d7:
									break;
								}
								continue;
								end_IL_08e2:
								break;
							}
							continue;
							end_IL_08f2:
							break;
						}
						continue;
						end_IL_0902:
						break;
					}
					continue;
					end_IL_0912:
					break;
				}
				continue;
				end_IL_0922:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		int num = 45;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaiwanLunisolarCalendarStackCrawlMarkHandle.ByteTypeInfoInlineR);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_03ad:
																if (b >= 1)
																{
																	while (b <= 21)
																	{
																		while (true)
																		{
																			IL_0390:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_0380:
																					if (16 >= b)
																					{
																						while (true)
																						{
																							IL_0373:
																							if (16 > b)
																							{
																								while (true)
																								{
																									IL_0363:
																									if (13 >= b)
																									{
																										while (true)
																										{
																											IL_0356:
																											if (13 > b)
																											{
																												while (12 >= b)
																												{
																													while (12 <= b)
																													{
																														while (true)
																														{
																															IL_031b:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																															while (true)
																															{
																																IL_0302:
																																array[num6] = 1;
																																num = 184;
																																while (true)
																																{
																																	if (num != 184)
																																	{
																																		if (num != 1165)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 122:
																																			goto IL_0302;
																																		case 57:
																																		case 119:
																																			goto IL_031b;
																																		case 128:
																																			goto IL_0336;
																																		case 19:
																																			goto IL_0346;
																																		case 25:
																																			goto IL_0356;
																																		case 43:
																																			goto IL_0363;
																																		case 97:
																																			goto IL_0373;
																																		case 158:
																																			goto IL_0380;
																																		case 176:
																																			goto IL_0390;
																																		case 162:
																																			goto IL_039d;
																																		case 93:
																																			goto IL_03ad;
																																		case 123:
																																			goto end_IL_03ad;
																																		case 33:
																																		case 106:
																																			goto end_IL_03bd;
																																		case 82:
																																		case 88:
																																			goto IL_03d8;
																																		case 60:
																																		case 102:
																																			goto IL_03f0;
																																		case 141:
																																			goto IL_040c;
																																		case 146:
																																			goto IL_041f;
																																		case 166:
																																			goto IL_0432;
																																		case 41:
																																			goto IL_043d;
																																		case 26:
																																			goto IL_044b;
																																		case 51:
																																		case 160:
																																			goto IL_0459;
																																		case 78:
																																			goto IL_0475;
																																		case 47:
																																		case 81:
																																			goto IL_0483;
																																		case 3:
																																			goto IL_0497;
																																		case 15:
																																			goto IL_04d6;
																																		case 167:
																																			goto IL_04e9;
																																		case 34:
																																			goto IL_04f7;
																																		case 38:
																																		case 133:
																																			goto IL_0502;
																																		case 75:
																																			goto IL_0542;
																																		case 50:
																																			goto IL_0556;
																																		case 137:
																																			goto IL_0569;
																																		case 79:
																																			goto IL_0577;
																																		case 103:
																																		case 163:
																																			goto IL_0582;
																																		case 87:
																																			goto IL_05c2;
																																		case 42:
																																			goto IL_05d6;
																																		case 73:
																																			goto IL_05e9;
																																		case 143:
																																			goto IL_05f7;
																																		case 74:
																																		case 86:
																																			goto IL_0605;
																																		case 142:
																																			goto IL_061e;
																																		case 85:
																																			goto IL_0635;
																																		case 145:
																																			goto IL_0643;
																																		case 53:
																																			goto IL_0656;
																																		case 77:
																																			goto IL_0661;
																																		case 125:
																																		case 132:
																																			goto IL_0678;
																																		case 83:
																																			goto IL_06a1;
																																		case 49:
																																			goto IL_06af;
																																		case 84:
																																			goto IL_06c2;
																																		case 156:
																																			goto IL_06d0;
																																		case 92:
																																		case 127:
																																			goto IL_06de;
																																		case 11:
																																			goto IL_06ec;
																																		case 152:
																																			goto IL_070f;
																																		case 24:
																																			goto IL_0719;
																																		case 161:
																																			goto IL_0727;
																																		case 164:
																																			goto IL_073a;
																																		case 20:
																																			goto IL_0748;
																																		case 35:
																																			goto IL_0753;
																																		case 6:
																																		case 148:
																																			goto IL_0761;
																																		case 0:
																																			goto IL_07a6;
																																		case 90:
																																			goto IL_07b4;
																																		case 9:
																																		case 153:
																																			goto IL_07c2;
																																		case 67:
																																			goto IL_0824;
																																		case 171:
																																			goto IL_0837;
																																		case 71:
																																			goto IL_0845;
																																		case 72:
																																			goto IL_0853;
																																		case 29:
																																		case 94:
																																			goto IL_0861;
																																		case 100:
																																			goto IL_08a1;
																																		case 159:
																																			goto IL_08b5;
																																		case 172:
																																			goto IL_08c8;
																																		case 17:
																																		case 21:
																																			goto IL_08d6;
																																		case 116:
																																			goto IL_08ef;
																																		case 7:
																																			goto IL_08fd;
																																		case 76:
																																			goto IL_090b;
																																		case 173:
																																			goto IL_091e;
																																		case 101:
																																			goto IL_092c;
																																		case 174:
																																			goto IL_093f;
																																		case 13:
																																			goto IL_094d;
																																		case 4:
																																			goto IL_0958;
																																		case 48:
																																		case 130:
																																			goto IL_0966;
																																		case 70:
																																			goto IL_09a6;
																																		case 66:
																																			goto IL_09ba;
																																		case 115:
																																			goto IL_09cd;
																																		case 31:
																																			goto IL_09db;
																																		case 113:
																																		case 168:
																																			goto IL_09e9;
																																		case 150:
																																			goto IL_0a29;
																																		case 8:
																																			goto IL_0a3d;
																																		case 175:
																																			goto IL_0a50;
																																		case 14:
																																			goto end_IL_02ef;
																																		case 22:
																																		case 177:
																																			goto IL_0a77;
																																		case 55:
																																			goto IL_0aa1;
																																		case 144:
																																			goto IL_0ab4;
																																		case 147:
																																			goto IL_0abf;
																																		case 135:
																																		case 140:
																																			goto IL_0acd;
																																		case 28:
																																			goto IL_0b0e;
																																		case 121:
																																			goto IL_0b22;
																																		case 104:
																																			goto IL_0b35;
																																		case 105:
																																			goto IL_0b40;
																																		case 68:
																																		case 151:
																																			goto IL_0b4b;
																																		case 65:
																																			goto IL_0b9d;
																																		case 1:
																																		case 23:
																																		case 30:
																																		case 32:
																																		case 36:
																																		case 39:
																																		case 40:
																																		case 54:
																																		case 61:
																																		case 62:
																																		case 69:
																																		case 80:
																																		case 91:
																																		case 108:
																																		case 111:
																																		case 117:
																																		case 118:
																																		case 120:
																																		case 129:
																																		case 134:
																																		case 136:
																																		case 149:
																																		case 154:
																																		case 170:
																																			goto end_IL_0336;
																																		case 2:
																																		case 5:
																																		case 12:
																																		case 16:
																																		case 18:
																																		case 27:
																																		case 37:
																																		case 52:
																																		case 56:
																																		case 58:
																																		case 59:
																																		case 63:
																																		case 64:
																																		case 89:
																																		case 95:
																																		case 96:
																																		case 98:
																																		case 99:
																																		case 107:
																																		case 139:
																																		case 155:
																																		case 157:
																																		case 165:
																																		case 169:
																																			goto end_IL_03cd;
																																		case 10:
																																			goto end_IL_0bc0;
																																		case 112:
																																			goto end_IL_0bd3;
																																		case 131:
																																			goto end_IL_0bdd;
																																		case 114:
																																		case 124:
																																			goto end_IL_0be8;
																																		case 126:
																																			goto end_IL_0bf8;
																																		case 110:
																																			goto end_IL_0c08;
																																		case 46:
																																			goto end_IL_0c18;
																																		case 44:
																																			goto end_IL_0c28;
																																		case 45:
																																			goto end_IL_0c38;
																																		case 109:
																																		case 138:
																																			return;
																																		}
																																		continue;
																																	}
																																	num6++;
																																	goto IL_0aa1;
																																	IL_0aa1:
																																	ptr2 += 16;
																																	goto end_IL_03cd;
																																	continue;
																																	end_IL_02ef:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0a64;
																														continue;
																														end_IL_0336:
																														break;
																														IL_0336:;
																													}
																													break;
																													IL_0346:;
																												}
																												break;
																											}
																											goto IL_03d8;
																											IL_03d8:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_03cd;
																										}
																										break;
																									}
																									goto IL_0ab4;
																									IL_0b9d:
																									num6--;
																									goto end_IL_03cd;
																									IL_0ab4:
																									if (14 >= b)
																									{
																										goto IL_0abf;
																									}
																									goto IL_0b35;
																									IL_0abf:
																									if (14 > b)
																									{
																										break;
																									}
																									goto IL_0acd;
																									IL_0acd:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_0b0e;
																									IL_0b0e:
																									array[num6 - 2] = 0;
																									goto IL_0b22;
																									IL_0b22:
																									num6--;
																									goto end_IL_03cd;
																									IL_0b35:
																									if (15 < b)
																									{
																										break;
																									}
																									goto IL_0b40;
																									IL_0b40:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_0b4b;
																									IL_0b4b:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0b9d;
																								}
																								break;
																							}
																							goto IL_03f0;
																							IL_041f:
																							num6--;
																							goto end_IL_03cd;
																							IL_03f0:
																							bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																							goto IL_041f;
																						}
																						break;
																					}
																					goto IL_0432;
																					IL_090b:
																					ptr2 += 16;
																					goto end_IL_03cd;
																					IL_0432:
																					if (19 < b)
																					{
																						goto IL_043d;
																					}
																					goto IL_0475;
																					IL_043d:
																					if (20 >= b)
																					{
																						goto IL_044b;
																					}
																					goto IL_091e;
																					IL_044b:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0459;
																					IL_0459:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_03cd;
																					IL_091e:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_092c;
																					IL_092c:
																					if (21 > b)
																					{
																					}
																					break;
																					IL_0475:
																					if (19 <= b)
																					{
																						goto IL_0483;
																					}
																					goto IL_0837;
																					IL_0483:
																					array[num6 - 1] = 0;
																					goto IL_0497;
																					IL_0497:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)PreferredBitCreateSpecificCulture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_04d6;
																					IL_04d6:
																					ptr2 += 8;
																					goto end_IL_03cd;
																					IL_0837:
																					if (17 < b)
																					{
																						goto IL_0845;
																					}
																					goto IL_08c8;
																					IL_0845:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_0853;
																					IL_0853:
																					if (18 > b)
																					{
																						break;
																					}
																					goto IL_0861;
																					IL_0861:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_08a1;
																					IL_08a1:
																					array[num6 - 2] = 3;
																					goto IL_08b5;
																					IL_08b5:
																					num6--;
																					goto end_IL_03cd;
																					IL_08c8:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_08d6;
																					IL_08d6:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																					goto IL_08ef;
																					IL_08ef:
																					array[num6] = 3;
																					goto IL_08fd;
																					IL_08fd:
																					num6++;
																					goto IL_090b;
																				}
																				break;
																			}
																			goto IL_040c;
																			IL_0a3d:
																			num6--;
																			goto end_IL_03cd;
																			IL_040c:
																			if (11 <= b)
																			{
																				goto end_IL_03cd;
																			}
																			goto IL_04e9;
																			IL_04e9:
																			if (5 >= b)
																			{
																				goto IL_04f7;
																			}
																			goto IL_073a;
																			IL_04f7:
																			if (5 <= b)
																			{
																				goto IL_0502;
																			}
																			goto IL_0569;
																			IL_0502:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0542;
																			IL_0542:
																			array[num6 - 2] = 0;
																			goto IL_0556;
																			IL_0556:
																			num6--;
																			goto end_IL_03cd;
																			IL_0569:
																			if (2 >= b)
																			{
																				goto IL_0577;
																			}
																			goto IL_0656;
																			IL_0577:
																			if (2 <= b)
																			{
																				goto IL_0582;
																			}
																			goto IL_05e9;
																			IL_0582:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_05c2;
																			IL_05c2:
																			array[num6 - 2] = 0;
																			goto IL_05d6;
																			IL_05d6:
																			num6--;
																			goto end_IL_03cd;
																			IL_05e9:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_05f7;
																			IL_05f7:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0605;
																			IL_0605:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_061e;
																			IL_061e:
																			array[num6] = 0;
																			num = 85;
																			goto IL_0635;
																			IL_0635:
																			num6++;
																			goto IL_0643;
																			IL_0643:
																			ptr2 += 8;
																			goto end_IL_03cd;
																			IL_0656:
																			if (3 >= b)
																			{
																				goto IL_0661;
																			}
																			goto IL_06c2;
																			IL_0661:
																			if (3 > b)
																			{
																				break;
																			}
																			num = 125;
																			goto IL_0678;
																			IL_0a77:
																			num6--;
																			num = 63;
																			goto end_IL_03cd;
																			IL_0678:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_06a1;
																			IL_06a1:
																			ptr2 += 8;
																			goto IL_06af;
																			IL_06af:
																			num6--;
																			goto end_IL_03cd;
																			IL_06c2:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_06d0;
																			IL_06d0:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_06de;
																			IL_06de:
																			array[num6] = 0;
																			goto IL_06ec;
																			IL_06ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_070f;
																			IL_070f:
																			array2[num6] = null;
																			goto IL_0719;
																			IL_0719:
																			num6++;
																			goto IL_0727;
																			IL_0727:
																			ptr2 += 8;
																			goto end_IL_03cd;
																			IL_073a:
																			if (8 < b)
																			{
																				goto IL_0748;
																			}
																			goto IL_093f;
																			IL_0748:
																			if (9 >= b)
																			{
																				goto IL_0753;
																			}
																			goto IL_07a6;
																			IL_0753:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0761;
																			IL_0761:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0a50;
																			IL_0a50:
																			array[num6 - 2] = 0;
																			goto IL_0a64;
																			IL_0a64:
																			num6--;
																			goto end_IL_03cd;
																			IL_07a6:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_07b4;
																			IL_07b4:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_07c2;
																			IL_07c2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0824;
																			IL_0824:
																			num6 -= 2;
																			goto end_IL_03cd;
																			IL_093f:
																			if (8 > b)
																			{
																				goto IL_094d;
																			}
																			goto IL_0a77;
																			IL_094d:
																			if (6 >= b)
																			{
																				goto IL_0958;
																			}
																			goto IL_09cd;
																			IL_0958:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0966;
																			IL_0966:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_09a6;
																			IL_09a6:
																			array[num6 - 2] = 0;
																			goto IL_09ba;
																			IL_09ba:
																			num6--;
																			goto end_IL_03cd;
																			IL_09cd:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_09db;
																			IL_09db:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_09e9;
																			IL_09e9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0a29;
																			IL_0a29:
																			array[num6 - 2] = 0;
																			goto IL_0a3d;
																		}
																		break;
																		IL_039d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_03cd;
																continue;
																end_IL_03ad:
																break;
															}
															continue;
															end_IL_03bd:
															break;
														}
														continue;
														end_IL_03cd:
														break;
													}
													continue;
												}
												num = 138;
												return;
												continue;
												end_IL_0bc0:
												break;
											}
											continue;
											end_IL_0bd3:
											break;
										}
										continue;
										end_IL_0bdd:
										break;
									}
									continue;
									end_IL_0be8:
									break;
								}
								continue;
								end_IL_0bf8:
								break;
							}
							continue;
							end_IL_0c08:
							break;
						}
						continue;
						end_IL_0c18:
						break;
					}
					continue;
					end_IL_0c28:
					break;
				}
				continue;
				end_IL_0c38:
				break;
			}
		}
	}

	public Class154()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 67;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							IL_055a:
							int[] array3 = new int[3];
							while (true)
							{
								IL_054a:
								long[] array4 = new long[2];
								while (true)
								{
									IL_0535:
									array3[0] = int_2;
									while (true)
									{
										IL_0520:
										array3[1] = int_3;
										while (true)
										{
											IL_0515:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetBindOptionsArrayWithOffset.ClientContextTerminatorSinkThrowOnUnmappableCharEnabled);
											while (true)
											{
												IL_050b:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02a1:
															byte b = *ptr2;
															while (true)
															{
																IL_0291:
																ptr2++;
																while (true)
																{
																	IL_0281:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0264:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_0254:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_0244:
																								if (2 < b)
																								{
																									while (3 >= b)
																									{
																										num = 79;
																										while (3 <= b)
																										{
																											while (true)
																											{
																												IL_01df:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01c9:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_01b0:
																														num5--;
																														num = 96;
																														while (num != 96)
																														{
																															if (num != 1077)
																															{
																																goto end_IL_04f8;
																															}
																															switch (num)
																															{
																															case 53:
																																goto IL_01b0;
																															case 81:
																																goto IL_01c9;
																															case 3:
																															case 11:
																																goto IL_01df;
																															case 79:
																																goto IL_0221;
																															case 56:
																															case 58:
																																goto IL_0231;
																															case 32:
																															case 46:
																																goto IL_0244;
																															case 44:
																																goto IL_0254;
																															case 18:
																																goto IL_0264;
																															case 17:
																																goto IL_0271;
																															case 26:
																																goto IL_0281;
																															case 15:
																																goto IL_0291;
																															case 5:
																															case 85:
																																goto IL_02a1;
																															case 8:
																															case 76:
																																goto IL_02ac;
																															case 49:
																																goto IL_02b7;
																															case 36:
																																goto IL_02c5;
																															case 10:
																																goto IL_02d3;
																															case 51:
																															case 68:
																																goto IL_02e1;
																															case 29:
																																goto IL_02f9;
																															case 50:
																																goto IL_0304;
																															case 22:
																																goto IL_0312;
																															case 28:
																															case 43:
																																goto IL_0320;
																															case 69:
																																goto IL_033c;
																															case 80:
																																goto IL_034f;
																															case 1:
																															case 20:
																																goto IL_035d;
																															case 27:
																																goto IL_03cb;
																															case 19:
																															case 41:
																																goto IL_03de;
																															case 14:
																																goto IL_03ec;
																															case 42:
																															case 82:
																																goto IL_03ff;
																															case 54:
																																goto IL_040d;
																															case 57:
																																goto IL_0430;
																															case 23:
																																goto IL_043a;
																															case 88:
																																goto IL_0448;
																															case 45:
																															case 61:
																																goto IL_045b;
																															case 25:
																																goto IL_0484;
																															case 71:
																																goto IL_0492;
																															case 2:
																															case 6:
																															case 12:
																															case 13:
																															case 24:
																															case 31:
																															case 33:
																															case 39:
																															case 52:
																															case 59:
																															case 60:
																															case 63:
																															case 72:
																															case 75:
																															case 83:
																															case 84:
																															case 89:
																																goto end_IL_0221;
																															case 65:
																																goto IL_04ce;
																															case 7:
																																goto IL_04dc;
																															case 0:
																																goto IL_04ea;
																															case 4:
																															case 21:
																															case 30:
																															case 34:
																															case 48:
																															case 62:
																															case 70:
																															case 73:
																															case 86:
																															case 87:
																																goto end_IL_019d;
																															case 35:
																																goto IL_050b;
																															case 64:
																																goto IL_0515;
																															case 77:
																																goto IL_0520;
																															case 40:
																																goto IL_0535;
																															case 47:
																																goto IL_054a;
																															case 37:
																															case 38:
																																goto IL_055a;
																															case 9:
																																goto end_IL_04f8;
																															case 74:
																															case 78:
																																goto end_IL_056a;
																															case 66:
																																goto end_IL_057a;
																															case 67:
																																goto end_IL_058a;
																															case 16:
																															case 55:
																																goto IL_05a5;
																															}
																															continue;
																															end_IL_019d:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_0281;
																											continue;
																											end_IL_0221:
																											break;
																											IL_0221:;
																										}
																										break;
																										IL_0231:;
																									}
																									break;
																								}
																								goto IL_034f;
																								IL_03ec:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_034f:
																								if (2 <= b)
																								{
																									goto IL_035d;
																								}
																								goto IL_03de;
																								IL_035d:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_03cb;
																								IL_03cb:
																								num5 -= 2;
																								goto end_IL_0281;
																								IL_03de:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_03ec;
																							}
																							break;
																						}
																						goto IL_045b;
																						IL_0492:
																						num5--;
																						goto end_IL_0281;
																						IL_045b:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0484;
																						IL_0484:
																						ptr2 += 8;
																						goto IL_0492;
																					}
																					break;
																				}
																				goto IL_02ac;
																				IL_0448:
																				ptr2 += 8;
																				goto end_IL_0281;
																				IL_02ac:
																				if (6 >= b)
																				{
																					goto IL_02b7;
																				}
																				goto IL_02f9;
																				IL_02b7:
																				if (6 <= b)
																				{
																					goto end_IL_0281;
																				}
																				goto IL_02c5;
																				IL_02c5:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_02d3;
																				IL_02d3:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_02e1;
																				IL_02e1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0281;
																				IL_02f9:
																				if (7 < b)
																				{
																					goto IL_0304;
																				}
																				goto IL_033c;
																				IL_0304:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0312;
																				IL_0312:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0320;
																				IL_0320:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0281;
																				IL_033c:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03ff;
																				IL_03ff:
																				array[num5] = 0;
																				goto IL_040d;
																				IL_040d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0430;
																				IL_0430:
																				array2[num5] = null;
																				goto IL_043a;
																				IL_043a:
																				num5++;
																				goto IL_0448;
																			}
																			break;
																			IL_0271:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 65;
																	goto IL_04ce;
																	IL_04ea:
																	ptr2 += 8;
																	break;
																	IL_04dc:
																	num5++;
																	goto IL_04ea;
																	IL_04ce:
																	array[num5] = 0;
																	goto IL_04dc;
																	continue;
																	end_IL_0281:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a5;
													IL_05a5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f8:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_056a:
						break;
					}
					continue;
					end_IL_057a:
					break;
				}
				continue;
				end_IL_058a:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MutexAuditRuleCurrentCultureIgnoreCase.DeclareLocalSelfSid);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02a8:
														byte b = *ptr2;
														while (true)
														{
															IL_0298:
															ptr2++;
															while (true)
															{
																IL_0288:
																if (b >= 1)
																{
																	while (b <= 12)
																	{
																		while (true)
																		{
																			IL_026b:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_025b:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_023b:
																									if (4 >= b)
																									{
																										while (4 <= b)
																										{
																											num = 126;
																											while (num != 126)
																											{
																												if (num != 1107)
																												{
																													goto IL_0497;
																												}
																												switch (num)
																												{
																												case 37:
																													goto IL_0228;
																												case 20:
																													goto IL_023b;
																												case 16:
																													goto IL_024b;
																												case 47:
																													goto IL_025b;
																												case 79:
																													goto IL_026b;
																												case 27:
																													goto IL_0278;
																												case 43:
																													goto IL_0288;
																												case 75:
																													goto IL_0298;
																												case 66:
																												case 115:
																													goto IL_02a8;
																												case 22:
																												case 56:
																													goto IL_02b3;
																												case 101:
																													goto IL_02c1;
																												case 86:
																													goto IL_02cc;
																												case 88:
																													goto IL_02da;
																												case 107:
																													goto IL_02ed;
																												case 54:
																												case 94:
																													goto IL_02f8;
																												case 9:
																													goto IL_0314;
																												case 33:
																													goto IL_0322;
																												case 31:
																												case 84:
																													goto IL_032d;
																												case 59:
																												case 116:
																													goto IL_034e;
																												case 117:
																													goto IL_0365;
																												case 61:
																												case 63:
																													goto IL_0373;
																												case 106:
																													goto IL_0381;
																												case 30:
																													goto IL_03a4;
																												case 4:
																													goto IL_03ae;
																												case 114:
																													goto IL_03bc;
																												case 118:
																													goto IL_03cf;
																												case 28:
																												case 73:
																													goto IL_03da;
																												case 89:
																													goto IL_03e8;
																												case 58:
																													goto IL_040c;
																												case 11:
																													goto IL_041a;
																												case 10:
																													goto IL_042d;
																												case 49:
																													goto IL_0438;
																												case 8:
																												case 44:
																													goto IL_0446;
																												case 90:
																													goto IL_0469;
																												case 87:
																													goto IL_0480;
																												case 71:
																													goto IL_0497;
																												case 80:
																													goto IL_04aa;
																												case 46:
																													goto IL_04b8;
																												case 1:
																												case 65:
																													goto IL_04c6;
																												case 0:
																													goto IL_0528;
																												case 96:
																													goto IL_0552;
																												case 12:
																												case 69:
																													goto IL_0560;
																												case 32:
																												case 76:
																													goto IL_056b;
																												case 109:
																													goto IL_0579;
																												case 100:
																												case 105:
																													goto IL_0587;
																												case 26:
																													goto IL_05b0;
																												case 3:
																													goto IL_05be;
																												case 23:
																													goto IL_05d1;
																												case 42:
																												case 103:
																													goto IL_05df;
																												case 70:
																													goto IL_05f8;
																												case 62:
																													goto IL_0606;
																												case 45:
																													goto IL_0614;
																												case 19:
																												case 74:
																													goto IL_0627;
																												case 6:
																												case 99:
																													goto IL_063f;
																												case 53:
																													goto IL_0688;
																												case 14:
																													goto IL_06a5;
																												case 15:
																												case 18:
																												case 35:
																												case 36:
																												case 38:
																												case 40:
																												case 50:
																												case 51:
																												case 55:
																												case 60:
																												case 67:
																												case 72:
																												case 77:
																												case 78:
																												case 81:
																												case 83:
																												case 93:
																												case 98:
																												case 108:
																												case 110:
																												case 111:
																												case 113:
																													goto end_IL_0228;
																												case 2:
																												case 5:
																												case 7:
																												case 17:
																												case 21:
																												case 25:
																												case 29:
																												case 34:
																												case 52:
																												case 68:
																												case 82:
																												case 85:
																												case 97:
																												case 104:
																													goto end_IL_0215;
																												case 24:
																													goto end_IL_06c8;
																												case 39:
																													goto end_IL_06db;
																												case 41:
																													goto end_IL_06e5;
																												case 13:
																													goto end_IL_06f0;
																												case 102:
																												case 119:
																													goto end_IL_0705;
																												case 48:
																													goto end_IL_0715;
																												case 64:
																												case 95:
																													goto end_IL_0725;
																												case 91:
																													goto end_IL_0735;
																												case 92:
																													goto end_IL_0745;
																												case 57:
																												case 112:
																													goto IL_0760;
																												}
																												continue;
																												end_IL_0215:
																												break;
																											}
																											goto end_IL_0288;
																											continue;
																											end_IL_0228:
																											break;
																											IL_0228:;
																										}
																										break;
																									}
																									goto IL_034e;
																									IL_03ae:
																									num5++;
																									goto IL_03bc;
																									IL_034e:
																									if (5 < b)
																									{
																										break;
																									}
																									num = 117;
																									goto IL_0365;
																									IL_03bc:
																									ptr2 += 8;
																									goto end_IL_0288;
																									IL_0365:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0373;
																									IL_0373:
																									array[num5] = 0;
																									goto IL_0381;
																									IL_0381:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03a4;
																									IL_03a4:
																									array2[num5] = null;
																									goto IL_03ae;
																								}
																								break;
																							}
																							num = 96;
																							goto IL_0552;
																							IL_0614:
																							ptr2 += 8;
																							goto end_IL_0288;
																							IL_0627:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0288;
																							IL_0552:
																							if (3 > b)
																							{
																								goto IL_0560;
																							}
																							goto IL_0627;
																							IL_0560:
																							if (1 < b)
																							{
																								goto IL_056b;
																							}
																							goto IL_05d1;
																							IL_056b:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0579;
																							IL_0579:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0587;
																							IL_0587:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05b0;
																							IL_05b0:
																							ptr2 += 8;
																							goto IL_05be;
																							IL_05be:
																							num5--;
																							goto end_IL_0288;
																							IL_05d1:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_05df;
																							IL_05df:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05f8;
																							IL_05f8:
																							array[num5] = 0;
																							goto IL_0606;
																							IL_0606:
																							num5++;
																							goto IL_0614;
																						}
																						break;
																					}
																					goto IL_063f;
																					IL_06a5:
																					num5--;
																					goto end_IL_0288;
																					IL_063f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 53;
																					goto IL_0688;
																					IL_0688:
																					array[num5 - 2] = 0;
																					num = 14;
																					goto IL_06a5;
																				}
																				break;
																			}
																			goto IL_02b3;
																			IL_04c6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0528;
																			IL_02b3:
																			if (9 < b)
																			{
																				goto IL_02c1;
																			}
																			goto IL_03cf;
																			IL_02c1:
																			if (11 < b)
																			{
																				goto IL_02cc;
																			}
																			goto IL_02ed;
																			IL_02cc:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_02da;
																			IL_02da:
																			if (12 > b)
																			{
																			}
																			break;
																			IL_02ed:
																			if (11 <= b)
																			{
																				goto IL_02f8;
																			}
																			goto IL_0314;
																			IL_02f8:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0288;
																			IL_0314:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0322;
																			IL_0322:
																			if (10 > b)
																			{
																				num = 50;
																				break;
																			}
																			goto IL_032d;
																			IL_032d:
																			num5--;
																			goto end_IL_0288;
																			IL_0528:
																			num5 -= 2;
																			goto end_IL_0288;
																			IL_03cf:
																			if (9 <= b)
																			{
																				goto IL_03da;
																			}
																			goto IL_042d;
																			IL_03da:
																			array[num5] = 0;
																			goto IL_03e8;
																			IL_03e8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getParentWindowHandleConstructorOnTypeBuilderInstantiation[*(int*)(ptr2 + num3)])();
																			goto IL_040c;
																			IL_040c:
																			num5++;
																			goto IL_041a;
																			IL_041a:
																			ptr2 += 8;
																			goto end_IL_0288;
																			IL_042d:
																			if (7 >= b)
																			{
																				goto IL_0438;
																			}
																			goto IL_04aa;
																			IL_0438:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0446;
																			IL_0446:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0469;
																			IL_0469:
																			array[num5] = 0;
																			num = 87;
																			goto IL_0480;
																			IL_0480:
																			num5++;
																			num = 71;
																			goto IL_0497;
																			IL_0497:
																			ptr2 += 8;
																			goto end_IL_0288;
																			IL_04aa:
																			if (8 < b)
																			{
																				num = 83;
																				break;
																			}
																			goto IL_04b8;
																			IL_04b8:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04c6;
																		}
																		break;
																		IL_0278:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0288:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0760;
												IL_0760:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06c8:
												break;
											}
											continue;
											end_IL_06db:
											break;
										}
										continue;
										end_IL_06e5:
										break;
									}
									continue;
									end_IL_06f0:
									break;
								}
								continue;
								end_IL_0705:
								break;
							}
							continue;
							end_IL_0715:
							break;
						}
						continue;
						end_IL_0725:
						break;
					}
					continue;
					end_IL_0735:
					break;
				}
				continue;
				end_IL_0745:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 6;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CFBResolveFieldHandle.InterfaceIsIInspectableStubHelpers);
											num = 67;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_023a:
															byte b = *ptr2;
															while (true)
															{
																IL_022a:
																ptr2++;
																while (true)
																{
																	IL_0217:
																	if (b >= 1)
																	{
																		num = 13;
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01fa:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01ea:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (5 <= b)
																									{
																										while (true)
																										{
																											IL_019c:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 91;
																											while (num != 91)
																											{
																												if (num != 1072)
																												{
																													goto IL_046d;
																												}
																												switch (num)
																												{
																												case 32:
																												case 60:
																													goto IL_019c;
																												case 62:
																													goto IL_01ba;
																												case 38:
																													goto IL_01ca;
																												case 59:
																													goto IL_01da;
																												case 81:
																													goto IL_01ea;
																												case 61:
																													goto IL_01fa;
																												case 13:
																													goto IL_0207;
																												case 21:
																													goto IL_0217;
																												case 63:
																													goto IL_022a;
																												case 36:
																												case 46:
																													goto IL_023a;
																												case 57:
																													goto IL_0245;
																												case 11:
																												case 22:
																													goto IL_0250;
																												case 4:
																												case 55:
																													goto IL_025d;
																												case 2:
																													goto IL_0286;
																												case 26:
																													goto IL_0294;
																												case 58:
																													goto IL_02a7;
																												case 7:
																													goto IL_02b5;
																												case 65:
																													goto IL_02c5;
																												case 48:
																													goto IL_02d0;
																												case 49:
																													goto IL_02de;
																												case 35:
																												case 70:
																													goto IL_02f1;
																												case 40:
																												case 77:
																													goto IL_033f;
																												case 79:
																													goto IL_03b6;
																												case 83:
																													goto IL_03c9;
																												case 9:
																													goto IL_03dd;
																												case 1:
																													goto IL_03f0;
																												case 43:
																													goto IL_03fb;
																												case 23:
																												case 73:
																													goto IL_0409;
																												case 12:
																													goto IL_0417;
																												case 17:
																													goto IL_043a;
																												case 37:
																													goto IL_0444;
																												case 69:
																													goto IL_0452;
																												case 54:
																													goto IL_0462;
																												case 64:
																													goto IL_046d;
																												case 18:
																												case 27:
																													goto IL_0478;
																												case 16:
																												case 25:
																												case 29:
																												case 31:
																												case 34:
																												case 42:
																												case 44:
																												case 45:
																												case 50:
																												case 51:
																												case 52:
																												case 53:
																												case 71:
																												case 78:
																												case 82:
																													goto end_IL_01ba;
																												case 19:
																													goto IL_04b4;
																												case 75:
																													goto IL_04c2;
																												case 24:
																													goto IL_04d0;
																												case 3:
																												case 14:
																												case 28:
																												case 41:
																												case 47:
																												case 56:
																												case 68:
																												case 72:
																												case 74:
																												case 84:
																													goto end_IL_0189;
																												case 67:
																													goto end_IL_04de;
																												case 0:
																													goto end_IL_04f1;
																												case 76:
																													goto end_IL_04fb;
																												case 39:
																													goto end_IL_050f;
																												case 15:
																													goto end_IL_0524;
																												case 8:
																												case 20:
																													goto end_IL_0539;
																												case 10:
																													goto end_IL_0549;
																												case 30:
																												case 80:
																													goto end_IL_0559;
																												case 5:
																													goto end_IL_0569;
																												case 6:
																													goto end_IL_0579;
																												case 33:
																												case 66:
																													goto IL_0594;
																												}
																												continue;
																												end_IL_0189:
																												break;
																											}
																											break;
																										}
																										goto end_IL_01da;
																										continue;
																										end_IL_01ba:
																										break;
																										IL_01ba:;
																									}
																									break;
																									IL_01ca:;
																								}
																								goto end_IL_0207;
																								continue;
																								end_IL_01da:
																								break;
																								IL_01da:;
																							}
																							break;
																						}
																						goto IL_03f0;
																						IL_0478:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_03f0:
																						if (7 >= b)
																						{
																							goto IL_03fb;
																						}
																						goto IL_0462;
																						IL_03fb:
																						if (7 > b)
																						{
																							goto end_IL_0207;
																						}
																						goto IL_0409;
																						IL_0409:
																						array[num6] = 0;
																						goto IL_0417;
																						IL_0417:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_043a;
																						IL_043a:
																						array2[num6] = null;
																						goto IL_0444;
																						IL_0444:
																						num6++;
																						goto IL_0452;
																						IL_0452:
																						ptr2 += 8;
																						break;
																						IL_0462:
																						if (8 < b)
																						{
																							goto end_IL_0207;
																						}
																						goto IL_046d;
																						IL_046d:
																						if (8 > b)
																						{
																							goto end_IL_0207;
																						}
																						goto IL_0478;
																					}
																					break;
																				}
																				goto IL_0245;
																				IL_0294:
																				num6--;
																				break;
																				IL_0245:
																				if (4 > b)
																				{
																					goto IL_0250;
																				}
																				goto IL_025d;
																				IL_0250:
																				if (2 < b)
																				{
																					goto IL_02a7;
																				}
																				goto IL_02c5;
																				IL_02a7:
																				if (3 < b)
																				{
																					goto end_IL_0207;
																				}
																				goto IL_02b5;
																				IL_02b5:
																				if (3 > b)
																				{
																					goto end_IL_0207;
																				}
																				goto IL_02f1;
																				IL_02f1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 83;
																				goto IL_03c9;
																				IL_03c9:
																				array[num6 - 2] = 0;
																				goto IL_03dd;
																				IL_03dd:
																				num6--;
																				break;
																				IL_02c5:
																				if (2 > b)
																				{
																					goto IL_02d0;
																				}
																				goto IL_033f;
																				IL_02d0:
																				if (1 < b)
																				{
																					goto end_IL_0207;
																				}
																				goto IL_02de;
																				IL_02de:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0207;
																				IL_033f:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 79;
																				goto IL_03b6;
																				IL_03b6:
																				num6 -= 2;
																				break;
																				IL_025d:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0286;
																				IL_0286:
																				ptr2 += 8;
																				goto IL_0294;
																			}
																			goto end_IL_0217;
																			continue;
																			end_IL_0207:
																			break;
																			IL_0207:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b4;
																	IL_04c2:
																	num6++;
																	goto IL_04d0;
																	IL_04d0:
																	ptr2 += 8;
																	break;
																	IL_04b4:
																	array[num6] = 0;
																	goto IL_04c2;
																	continue;
																	end_IL_0217:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0594;
													IL_0594:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04de:
													break;
												}
												continue;
												end_IL_04f1:
												break;
											}
											continue;
											end_IL_04fb:
											break;
										}
										continue;
										end_IL_050f:
										break;
									}
									continue;
									end_IL_0524:
									break;
								}
								continue;
								end_IL_0539:
								break;
							}
							continue;
							end_IL_0549:
							break;
						}
						continue;
						end_IL_0559:
						break;
					}
					continue;
					end_IL_0569:
					break;
				}
				continue;
				end_IL_0579:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 25;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 47;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										IL_089c:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DarkMagentagetParamTypes.TransformMetadataSizeWriteObjectData);
										while (true)
										{
											IL_0892:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_087f:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02e4:
														byte b = *ptr2;
														while (true)
														{
															IL_02d4:
															ptr2++;
															while (true)
															{
																IL_02c4:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02a7:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0294:
																					if (8 > b)
																					{
																						num = 153;
																						while (true)
																						{
																							if (num != 153)
																							{
																								if (num != 1134)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 83:
																									goto IL_0294;
																								case 50:
																									goto IL_02a7;
																								case 73:
																									goto IL_02b4;
																								case 87:
																									goto IL_02c4;
																								case 107:
																									goto IL_02d4;
																								case 11:
																								case 22:
																									goto IL_02e4;
																								case 98:
																								case 121:
																									goto IL_02ef;
																								case 129:
																									goto IL_02fd;
																								case 111:
																								case 118:
																									goto IL_0308;
																								case 56:
																									goto IL_0316;
																								case 42:
																								case 110:
																									goto IL_0321;
																								case 34:
																									goto IL_0331;
																								case 80:
																								case 102:
																									goto IL_0344;
																								case 130:
																									goto IL_0384;
																								case 9:
																									goto IL_0398;
																								case 131:
																									goto IL_03ab;
																								case 3:
																									goto IL_03ce;
																								case 71:
																									goto IL_03d8;
																								case 33:
																									goto IL_03e6;
																								case 124:
																								case 132:
																									goto IL_03f9;
																								case 133:
																									goto IL_0411;
																								case 142:
																									goto IL_0424;
																								case 125:
																									goto IL_0432;
																								case 6:
																								case 16:
																									goto IL_0440;
																								case 58:
																									goto IL_0484;
																								case 92:
																									goto IL_0498;
																								case 115:
																								case 143:
																									goto IL_04ab;
																								case 19:
																								case 39:
																									goto IL_04b6;
																								case 78:
																									goto IL_04c4;
																								case 82:
																									goto IL_04d7;
																								case 85:
																								case 108:
																									goto IL_04e5;
																								case 28:
																									goto IL_04f3;
																								case 66:
																								case 88:
																									goto IL_0501;
																								case 52:
																									goto IL_0563;
																								case 62:
																								case 100:
																									goto IL_0576;
																								case 32:
																									goto IL_059b;
																								case 84:
																									goto IL_05a9;
																								case 54:
																									goto IL_05b7;
																								case 7:
																									goto IL_05c5;
																								case 89:
																								case 109:
																									goto IL_05d0;
																								case 5:
																									goto IL_05de;
																								case 46:
																								case 75:
																									goto IL_05ec;
																								case 137:
																									goto IL_0605;
																								case 8:
																									goto IL_0613;
																								case 51:
																									goto IL_0621;
																								case 38:
																								case 112:
																									goto IL_0634;
																								case 96:
																									goto IL_0674;
																								case 123:
																									goto IL_0688;
																								case 29:
																									goto IL_069b;
																								case 68:
																									goto IL_06a9;
																								case 41:
																								case 134:
																									goto IL_06b7;
																								case 67:
																									goto IL_06e0;
																								case 120:
																								case 135:
																									goto IL_06f9;
																								case 117:
																									goto IL_0720;
																								case 93:
																									goto IL_072e;
																								case 65:
																									goto IL_0741;
																								case 10:
																								case 55:
																									goto IL_074c;
																								case 113:
																									goto IL_075a;
																								case 61:
																								case 140:
																									goto IL_0768;
																								case 146:
																									goto IL_0791;
																								case 116:
																									goto IL_079f;
																								case 40:
																									goto IL_07b2;
																								case 31:
																								case 86:
																									goto IL_07bd;
																								case 101:
																									goto IL_07cb;
																								case 23:
																								case 90:
																									goto IL_07d9;
																								case 126:
																									goto IL_07e7;
																								case 21:
																									goto IL_07ff;
																								case 36:
																									goto IL_080d;
																								case 69:
																								case 95:
																									goto IL_081d;
																								case 94:
																									goto IL_085c;
																								case 0:
																								case 12:
																								case 13:
																								case 20:
																								case 30:
																								case 43:
																								case 45:
																								case 49:
																								case 57:
																								case 60:
																								case 64:
																								case 72:
																								case 76:
																								case 79:
																								case 81:
																								case 99:
																								case 103:
																								case 106:
																								case 114:
																								case 122:
																								case 127:
																								case 138:
																								case 139:
																								case 141:
																									goto end_IL_02b4;
																								case 2:
																								case 4:
																								case 14:
																								case 17:
																								case 18:
																								case 26:
																								case 27:
																								case 44:
																								case 48:
																								case 59:
																								case 63:
																								case 70:
																								case 77:
																								case 91:
																								case 97:
																								case 128:
																								case 136:
																								case 145:
																									goto IL_087f;
																								case 37:
																									goto IL_0892;
																								case 119:
																									goto IL_089c;
																								case 104:
																									goto end_IL_0281;
																								case 47:
																									goto end_IL_08a7;
																								case 35:
																								case 105:
																									goto end_IL_08b7;
																								case 15:
																									goto end_IL_08c7;
																								case 1:
																								case 74:
																									goto end_IL_08e0;
																								case 24:
																									goto end_IL_08f0;
																								case 25:
																									goto end_IL_0900;
																								case 53:
																								case 144:
																									goto IL_091b;
																								}
																								continue;
																							}
																							goto IL_059b;
																							IL_081d:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_085c;
																							IL_085c:
																							num5 -= 3;
																							goto IL_087f;
																							IL_059b:
																							if (4 >= b)
																							{
																								goto IL_05a9;
																							}
																							goto IL_0741;
																							IL_05a9:
																							if (4 > b)
																							{
																								goto IL_05b7;
																							}
																							goto IL_06f9;
																							IL_05b7:
																							if (2 >= b)
																							{
																								goto IL_05c5;
																							}
																							goto IL_069b;
																							IL_05c5:
																							if (2 > b)
																							{
																								goto IL_05d0;
																							}
																							goto IL_0634;
																							IL_05d0:
																							if (1 < b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_05de;
																							IL_05de:
																							if (1 > b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_05ec;
																							IL_05ec:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0605;
																							IL_0605:
																							array[num5] = 0;
																							goto IL_0613;
																							IL_0613:
																							num5++;
																							goto IL_0621;
																							IL_0621:
																							ptr2 += 8;
																							goto IL_087f;
																							IL_0634:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0674;
																							IL_0674:
																							array[num5 - 2] = 0;
																							goto IL_0688;
																							IL_0688:
																							num5--;
																							goto IL_087f;
																							IL_069b:
																							if (3 < b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_06a9;
																							IL_06a9:
																							if (3 > b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_06b7;
																							IL_06b7:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_06e0;
																							IL_06e0:
																							array[num5 - 1] = 5;
																							goto IL_087f;
																							IL_06f9:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							num = 117;
																							goto IL_0720;
																							IL_0720:
																							ptr2 += 8;
																							goto IL_072e;
																							IL_072e:
																							num5--;
																							goto IL_087f;
																							IL_0741:
																							if (6 < b)
																							{
																								goto IL_074c;
																							}
																							goto IL_07b2;
																							IL_074c:
																							if (7 < b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_075a;
																							IL_075a:
																							if (7 > b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_0768;
																							IL_0768:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0791;
																							IL_0791:
																							ptr2 += 8;
																							goto IL_079f;
																							IL_079f:
																							num5--;
																							goto IL_087f;
																							IL_07b2:
																							if (6 > b)
																							{
																								goto IL_07bd;
																							}
																							goto IL_081d;
																							IL_07bd:
																							if (5 < b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_07cb;
																							IL_07cb:
																							if (5 > b)
																							{
																								goto end_IL_02b4;
																							}
																							goto IL_07d9;
																							IL_07d9:
																							array[num5] = 5;
																							goto IL_07e7;
																							IL_07e7:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_07ff;
																							IL_07ff:
																							num5++;
																							goto IL_080d;
																							IL_080d:
																							ptr2 += 8;
																							goto IL_087f;
																							continue;
																							end_IL_0281:
																							break;
																						}
																						break;
																					}
																					goto IL_03f9;
																					IL_03f9:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_087f;
																				}
																				break;
																			}
																			goto IL_02ef;
																			IL_0576:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 145;
																			goto IL_087f;
																			IL_02ef:
																			if (12 >= b)
																			{
																				goto IL_02fd;
																			}
																			goto IL_04ab;
																			IL_02fd:
																			if (12 > b)
																			{
																				goto IL_0308;
																			}
																			goto IL_0344;
																			IL_0308:
																			if (10 >= b)
																			{
																				goto IL_0316;
																			}
																			goto IL_0424;
																			IL_0316:
																			if (10 <= b)
																			{
																				goto IL_0321;
																			}
																			goto IL_0331;
																			IL_0321:
																			array[num5] = 0;
																			goto IL_03ab;
																			IL_03ab:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03ce;
																			IL_03ce:
																			array2[num5] = null;
																			goto IL_03d8;
																			IL_03d8:
																			num5++;
																			goto IL_03e6;
																			IL_03e6:
																			ptr2 += 8;
																			goto IL_087f;
																			IL_0331:
																			if (9 < b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_0411;
																			IL_0411:
																			if (9 > b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_087f;
																			IL_0424:
																			if (11 < b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_0432;
																			IL_0432:
																			if (11 > b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_0440;
																			IL_0440:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0484;
																			IL_0484:
																			array[num5 - 2] = 0;
																			goto IL_0498;
																			IL_0498:
																			num5--;
																			goto IL_087f;
																			IL_0344:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0384;
																			IL_0384:
																			array[num5 - 2] = 0;
																			goto IL_0398;
																			IL_0398:
																			num5--;
																			goto IL_087f;
																			IL_04ab:
																			if (14 < b)
																			{
																				goto IL_04b6;
																			}
																			goto IL_04d7;
																			IL_04b6:
																			if (15 < b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_04c4;
																			IL_04c4:
																			if (15 > b)
																			{
																			}
																			goto end_IL_02b4;
																			IL_04d7:
																			if (14 > b)
																			{
																				goto IL_04e5;
																			}
																			goto IL_0576;
																			IL_04e5:
																			if (13 < b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_04f3;
																			IL_04f3:
																			if (13 > b)
																			{
																				goto end_IL_02b4;
																			}
																			goto IL_0501;
																			IL_0501:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0563;
																			IL_0563:
																			num5 -= 2;
																			goto IL_087f;
																		}
																		goto end_IL_02c4;
																		continue;
																		end_IL_02b4:
																		break;
																		IL_02b4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_087f;
																continue;
																end_IL_02c4:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_091b;
												IL_091b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									continue;
									end_IL_08a7:
									break;
								}
								continue;
								end_IL_08b7:
								break;
							}
							continue;
							end_IL_08c7:
							break;
						}
						continue;
						end_IL_08e0:
						break;
					}
					continue;
					end_IL_08f0:
					break;
				}
				continue;
				end_IL_0900:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 86;
		byte[] array = default(byte[]);
		int num4 = default(int);
		byte* ptr = default(byte*);
		object[] array2 = default(object[]);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 96;
					while (true)
					{
						if (num != 96)
						{
							if (num != 1077)
							{
								goto IL_057d;
							}
							switch (num)
							{
							case 49:
								goto end_IL_018f;
							case 85:
								goto end_IL_019f;
							case 86:
								goto end_IL_01aa;
							case 0:
								goto IL_01d3;
							case 17:
								goto IL_01e1;
							case 4:
								goto IL_01ea;
							case 88:
								goto IL_01f8;
							case 45:
								goto IL_0206;
							case 37:
								goto IL_0219;
							case 35:
								goto IL_0235;
							case 30:
								goto IL_023e;
							case 74:
								goto IL_0246;
							case 3:
							case 11:
							case 14:
							case 21:
							case 44:
							case 59:
							case 60:
							case 61:
							case 63:
							case 76:
								goto IL_024f;
							case 13:
								goto IL_025f;
							case 55:
								goto IL_0268;
							case 71:
								goto IL_0271;
							case 83:
								goto IL_027f;
							case 64:
								goto IL_028d;
							case 33:
								goto IL_029b;
							case 23:
								goto IL_02a9;
							case 31:
							case 58:
								goto IL_02b4;
							case 1:
								goto IL_02dd;
							case 67:
								goto IL_02eb;
							case 80:
								goto IL_02fe;
							case 73:
							case 82:
								goto IL_030c;
							case 20:
								goto IL_031a;
							case 22:
							case 79:
								goto IL_0328;
							case 48:
								goto IL_0368;
							case 50:
								goto IL_0385;
							case 15:
								goto IL_03a1;
							case 47:
							case 70:
								goto IL_03ac;
							case 43:
								goto IL_03ba;
							case 34:
							case 78:
								goto IL_03cd;
							case 52:
								goto IL_043b;
							case 28:
								goto IL_044e;
							case 7:
								goto IL_045c;
							case 42:
							case 57:
								goto IL_0467;
							case 2:
								goto IL_0475;
							case 38:
							case 89:
								goto IL_0483;
							case 84:
								goto IL_04a8;
							case 40:
							case 46:
								goto IL_04b6;
							case 27:
								goto IL_04c4;
							case 6:
								goto IL_04e7;
							case 36:
								goto IL_04f1;
							case 54:
								goto IL_04ff;
							case 87:
								goto IL_0512;
							case 41:
								goto IL_0520;
							case 53:
								goto IL_052b;
							case 19:
							case 51:
								goto IL_0536;
							case 65:
								goto IL_054e;
							case 24:
								goto IL_055c;
							case 69:
								goto IL_056a;
							case 5:
							case 8:
							case 9:
							case 10:
							case 12:
							case 16:
							case 18:
							case 25:
							case 26:
							case 29:
							case 32:
							case 39:
							case 56:
							case 66:
							case 68:
							case 72:
							case 75:
							case 81:
								goto IL_057d;
							case 62:
							case 77:
								goto IL_05a2;
							}
							continue;
						}
						array = new byte[2];
						goto IL_01d3;
						IL_054e:
						array[num4] = 0;
						goto IL_055c;
						IL_056a:
						ptr += 8;
						goto IL_024f;
						IL_055c:
						num4++;
						goto IL_056a;
						IL_01d3:
						array2 = new object[2];
						goto IL_01e1;
						IL_01e1:
						num = 4;
						goto IL_01ea;
						IL_01ea:
						array3 = new int[3];
						goto IL_01f8;
						IL_01f8:
						array4 = new long[2];
						goto IL_0206;
						IL_0206:
						array3[0] = int_2;
						goto IL_0219;
						IL_0219:
						array3[1] = int_3;
						num = 35;
						goto IL_0235;
						IL_0235:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemotingTypeCachedDataChangeExtension.getPlatformBinaryArrayTypeEnum);
						goto IL_023e;
						IL_023e:
						ptr = ptr2;
						goto IL_0246;
						IL_0246:
						num = 60;
						goto IL_024f;
						IL_024f:
						if (num5 != 1)
						{
							goto IL_025f;
						}
						goto IL_05a2;
						IL_05a2:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						IL_025f:
						num = 55;
						goto IL_0268;
						IL_0268:
						b = *ptr;
						goto IL_0271;
						IL_0271:
						ptr++;
						goto IL_027f;
						IL_027f:
						if (b >= 1)
						{
							goto IL_028d;
						}
						goto IL_057d;
						IL_028d:
						if (b <= 8)
						{
							goto IL_029b;
						}
						goto IL_057d;
						IL_029b:
						if (4 >= b)
						{
							goto IL_02a9;
						}
						goto IL_044e;
						IL_02a9:
						if (4 <= b)
						{
							goto IL_02b4;
						}
						goto IL_02fe;
						IL_02b4:
						ref int reference = ref array3[*(int*)(ptr + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						goto IL_02dd;
						IL_02dd:
						ptr += 8;
						goto IL_02eb;
						IL_02eb:
						num4--;
						goto IL_024f;
						IL_02fe:
						if (2 < b)
						{
							goto IL_030c;
						}
						goto IL_03a1;
						IL_030c:
						if (3 >= b)
						{
							goto IL_031a;
						}
						goto IL_057d;
						IL_031a:
						if (3 <= b)
						{
							goto IL_0328;
						}
						goto IL_057d;
						IL_0328:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						goto IL_0368;
						IL_0368:
						array[num4 - 2] = 0;
						num = 50;
						goto IL_0385;
						IL_0385:
						num4--;
						num = 61;
						goto IL_024f;
						IL_03a1:
						if (2 > b)
						{
							goto IL_03ac;
						}
						goto IL_03cd;
						IL_03ac:
						if (1 >= b)
						{
							goto IL_03ba;
						}
						goto IL_057d;
						IL_03ba:
						if (1 > b)
						{
						}
						goto IL_057d;
						IL_03cd:
						ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						goto IL_043b;
						IL_043b:
						num4 -= 2;
						goto IL_024f;
						IL_044e:
						if (6 < b)
						{
							goto IL_045c;
						}
						goto IL_0512;
						IL_045c:
						if (7 < b)
						{
							goto IL_0467;
						}
						goto IL_04a8;
						IL_0467:
						if (8 >= b)
						{
							goto IL_0475;
						}
						goto IL_057d;
						IL_0475:
						if (8 <= b)
						{
							goto IL_0483;
						}
						goto IL_057d;
						IL_0483:
						byte* num6 = ptr;
						num5 = 1;
						ptr = num6 + -200;
						num = 63;
						goto IL_024f;
						IL_04a8:
						if (7 <= b)
						{
							goto IL_04b6;
						}
						goto IL_057d;
						IL_04b6:
						array[num4] = 0;
						goto IL_04c4;
						IL_04c4:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
						goto IL_04e7;
						IL_04e7:
						array2[num4] = null;
						goto IL_04f1;
						IL_04f1:
						num4++;
						goto IL_04ff;
						IL_04ff:
						ptr += 8;
						goto IL_024f;
						IL_0512:
						if (6 <= b)
						{
							goto IL_024f;
						}
						goto IL_0520;
						IL_0520:
						if (5 >= b)
						{
							goto IL_052b;
						}
						goto IL_057d;
						IL_052b:
						if (5 <= b)
						{
							goto IL_0536;
						}
						goto IL_057d;
						IL_0536:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_024f;
						IL_057d:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
						goto IL_054e;
						continue;
						end_IL_018f:
						break;
					}
					continue;
					end_IL_019f:
					break;
				}
				continue;
				end_IL_01aa:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRenewalTimeRest.SwitchValueStategetInstalledUICulture);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0229:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0209:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01f9:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01e9:
																								if (2 >= b)
																								{
																									num = 20;
																									while (true)
																									{
																										IL_01d9:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												num = 98;
																												while (true)
																												{
																													if (num != 98)
																													{
																														if (num != 1079)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 6:
																														case 44:
																															goto IL_01c6;
																														case 20:
																															goto IL_01d9;
																														case 14:
																														case 83:
																															goto IL_01e9;
																														case 2:
																															goto IL_01f9;
																														case 40:
																															goto IL_0209;
																														case 35:
																															goto IL_0219;
																														case 76:
																															goto IL_0229;
																														case 69:
																															goto end_IL_0229;
																														case 27:
																														case 89:
																															goto end_IL_0239;
																														case 71:
																															goto IL_0254;
																														case 51:
																															goto IL_0262;
																														case 46:
																														case 66:
																															goto IL_0270;
																														case 65:
																															goto IL_02b0;
																														case 54:
																															goto IL_02c4;
																														case 33:
																														case 39:
																															goto IL_02ea;
																														case 32:
																															goto IL_0358;
																														case 48:
																														case 58:
																															goto IL_036b;
																														case 80:
																															goto IL_0394;
																														case 57:
																															goto IL_03a2;
																														case 1:
																															goto IL_03be;
																														case 3:
																														case 18:
																															goto IL_03cc;
																														case 7:
																															goto IL_03d7;
																														case 25:
																															goto IL_03e5;
																														case 85:
																														case 86:
																															goto IL_03f3;
																														case 60:
																															goto IL_0418;
																														case 36:
																														case 82:
																															goto IL_0426;
																														case 29:
																															goto IL_0434;
																														case 26:
																															goto IL_0457;
																														case 50:
																															goto IL_046a;
																														case 30:
																															goto IL_0478;
																														case 55:
																															goto IL_048b;
																														case 59:
																														case 81:
																															goto IL_0499;
																														case 31:
																															goto IL_04a4;
																														case 5:
																														case 16:
																															goto IL_04af;
																														case 10:
																														case 11:
																														case 13:
																														case 15:
																														case 17:
																														case 19:
																														case 23:
																														case 38:
																														case 43:
																														case 45:
																														case 64:
																														case 67:
																														case 68:
																														case 70:
																														case 79:
																														case 84:
																														case 88:
																														case 90:
																														case 91:
																															goto end_IL_01b3;
																														case 0:
																															goto IL_04e7;
																														case 49:
																															goto IL_04f5;
																														case 4:
																															goto IL_0503;
																														case 8:
																														case 12:
																														case 22:
																														case 28:
																														case 42:
																														case 52:
																														case 56:
																														case 61:
																														case 62:
																														case 75:
																														case 87:
																															goto end_IL_0249;
																														case 24:
																															goto end_IL_051a;
																														case 72:
																															goto end_IL_052d;
																														case 63:
																															goto end_IL_0537;
																														case 47:
																															goto end_IL_0542;
																														case 37:
																															goto end_IL_0557;
																														case 41:
																														case 74:
																															goto end_IL_056c;
																														case 34:
																															goto end_IL_057c;
																														case 9:
																														case 21:
																															goto end_IL_058c;
																														case 77:
																															goto end_IL_059c;
																														case 78:
																															goto end_IL_05ac;
																														case 53:
																														case 73:
																															goto IL_05c7;
																														}
																														continue;
																													}
																													if (1 > b)
																													{
																													}
																													break;
																													continue;
																													end_IL_01b3:
																													break;
																												}
																												break;
																												IL_01c6:;
																											}
																											break;
																										}
																										goto IL_02ea;
																										IL_0358:
																										num5 -= 2;
																										goto end_IL_0249;
																										IL_02ea:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0358;
																									}
																									break;
																								}
																								goto IL_0254;
																								IL_02b0:
																								array[num5 - 2] = 0;
																								goto IL_02c4;
																								IL_02c4:
																								num5--;
																								goto end_IL_0249;
																								IL_0254:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0262;
																								IL_0262:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0270;
																								IL_0270:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02b0;
																							}
																							break;
																						}
																						goto IL_036b;
																						IL_03a2:
																						num5--;
																						num = 12;
																						goto end_IL_0249;
																						IL_036b:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0394;
																						IL_0394:
																						ptr2 += 8;
																						goto IL_03a2;
																					}
																					break;
																				}
																				goto IL_03be;
																				IL_04a4:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_04af;
																				IL_03be:
																				if (6 < b)
																				{
																					goto IL_03cc;
																				}
																				goto IL_048b;
																				IL_03cc:
																				if (7 < b)
																				{
																					goto IL_03d7;
																				}
																				num = 60;
																				goto IL_0418;
																				IL_03d7:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03e5;
																				IL_03e5:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03f3;
																				IL_03f3:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0249;
																				IL_04af:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0249;
																				IL_0418:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0426;
																				IL_0426:
																				array[num5] = 0;
																				goto IL_0434;
																				IL_0434:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0457;
																				IL_0457:
																				array2[num5] = null;
																				num = 50;
																				goto IL_046a;
																				IL_046a:
																				num5++;
																				goto IL_0478;
																				IL_0478:
																				ptr2 += 8;
																				goto end_IL_0249;
																				IL_048b:
																				if (6 <= b)
																				{
																					goto end_IL_0249;
																				}
																				goto IL_0499;
																				IL_0499:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04a4;
																			}
																			break;
																			IL_0219:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04e7;
																	IL_0503:
																	ptr2 += 8;
																	num = 42;
																	goto end_IL_0249;
																	IL_04f5:
																	num5++;
																	goto IL_0503;
																	IL_04e7:
																	array[num5] = 0;
																	goto IL_04f5;
																	continue;
																	end_IL_0229:
																	break;
																}
																continue;
																end_IL_0239:
																break;
															}
															continue;
															end_IL_0249:
															break;
														}
														continue;
													}
													goto IL_05c7;
													IL_05c7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_051a:
													break;
												}
												continue;
												end_IL_052d:
												break;
											}
											continue;
											end_IL_0537:
											break;
										}
										continue;
										end_IL_0542:
										break;
									}
									continue;
									end_IL_0557:
									break;
								}
								continue;
								end_IL_056c:
								break;
							}
							continue;
							end_IL_057c:
							break;
						}
						continue;
						end_IL_058c:
						break;
					}
					continue;
					end_IL_059c:
					break;
				}
				continue;
				end_IL_05ac:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 88;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 83;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OrdinalIgnoreCasegetBytesUnknown.OrderOk);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 34;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0317:
														byte b = *ptr2;
														while (true)
														{
															IL_0307:
															ptr2++;
															while (true)
															{
																IL_02f7:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02d4:
																			if (6 >= b)
																			{
																				num = 36;
																				while (true)
																				{
																					IL_02c4:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_02b7:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_02a7:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_026e:
																													array[num5] = 0;
																													num = 57;
																													while (true)
																													{
																														IL_0249:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_023d:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_022d:
																																num5++;
																																while (true)
																																{
																																	IL_0214:
																																	ptr2 += 8;
																																	num = 121;
																																	while (num != 121)
																																	{
																																		if (num != 1102)
																																		{
																																			goto IL_03a3;
																																		}
																																		switch (num)
																																		{
																																		case 93:
																																			goto IL_0214;
																																		case 84:
																																			goto IL_022d;
																																		case 17:
																																			goto IL_023d;
																																		case 57:
																																			goto IL_0249;
																																		case 53:
																																		case 89:
																																			goto IL_026e;
																																		case 21:
																																			goto IL_0287;
																																		case 47:
																																		case 102:
																																			goto IL_0297;
																																		case 28:
																																			goto IL_02a7;
																																		case 108:
																																			goto IL_02b7;
																																		case 36:
																																			goto IL_02c4;
																																		case 35:
																																			goto IL_02d4;
																																		case 55:
																																			goto IL_02e7;
																																		case 96:
																																			goto IL_02f7;
																																		case 66:
																																			goto IL_0307;
																																		case 19:
																																		case 59:
																																			goto IL_0317;
																																		case 100:
																																			goto IL_0322;
																																		case 8:
																																		case 26:
																																			goto IL_032d;
																																		case 81:
																																			goto IL_0345;
																																		case 11:
																																		case 64:
																																			goto IL_0350;
																																		case 46:
																																			goto IL_035e;
																																		case 22:
																																		case 24:
																																			goto IL_036c;
																																		case 91:
																																			goto IL_0395;
																																		case 4:
																																			goto IL_03a3;
																																		case 1:
																																			goto IL_03b6;
																																		case 73:
																																		case 90:
																																			goto IL_03c4;
																																		case 12:
																																			goto IL_03dd;
																																		case 69:
																																			goto IL_03eb;
																																		case 54:
																																			goto IL_03f9;
																																		case 60:
																																		case 103:
																																			goto IL_040c;
																																		case 70:
																																			goto IL_044c;
																																		case 38:
																																			goto IL_0460;
																																		case 114:
																																			goto IL_0473;
																																		case 61:
																																			goto IL_0486;
																																		case 62:
																																		case 111:
																																			goto IL_0491;
																																		case 25:
																																		case 50:
																																			goto IL_049c;
																																		case 63:
																																			goto IL_04aa;
																																		case 16:
																																			goto IL_04bd;
																																		case 45:
																																		case 58:
																																			goto IL_04cb;
																																		case 101:
																																			goto IL_04e7;
																																		case 94:
																																		case 98:
																																			goto IL_04fe;
																																		case 40:
																																		case 77:
																																			goto IL_0509;
																																		case 51:
																																			goto IL_0517;
																																		case 7:
																																		case 41:
																																			goto IL_0525;
																																		case 110:
																																			goto IL_0548;
																																		case 18:
																																			goto IL_0556;
																																		case 32:
																																			goto IL_0564;
																																		case 106:
																																			goto IL_0577;
																																		case 52:
																																		case 76:
																																			goto IL_0585;
																																		case 42:
																																			goto IL_05c5;
																																		case 95:
																																			goto IL_05d9;
																																		case 15:
																																		case 82:
																																			goto IL_05ec;
																																		case 107:
																																			goto IL_0657;
																																		case 3:
																																		case 5:
																																		case 9:
																																		case 10:
																																		case 20:
																																		case 27:
																																		case 30:
																																		case 37:
																																		case 43:
																																		case 44:
																																		case 48:
																																		case 49:
																																		case 56:
																																		case 67:
																																		case 72:
																																		case 75:
																																		case 78:
																																		case 80:
																																		case 92:
																																		case 97:
																																		case 109:
																																			goto end_IL_0287;
																																		case 14:
																																		case 23:
																																		case 29:
																																		case 31:
																																		case 34:
																																		case 39:
																																		case 65:
																																		case 71:
																																		case 85:
																																		case 86:
																																		case 99:
																																		case 105:
																																		case 113:
																																			goto end_IL_0201;
																																		case 0:
																																			goto end_IL_067a;
																																		case 2:
																																			goto end_IL_068d;
																																		case 104:
																																			goto end_IL_06a0;
																																		case 112:
																																			goto end_IL_06ab;
																																		case 13:
																																		case 74:
																																			goto end_IL_06c0;
																																		case 83:
																																			goto end_IL_06d0;
																																		case 6:
																																		case 68:
																																			goto end_IL_06e0;
																																		case 87:
																																			goto end_IL_06f0;
																																		case 88:
																																			goto end_IL_0709;
																																		case 33:
																																		case 79:
																																			goto IL_0724;
																																		}
																																		continue;
																																		end_IL_0201:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02f7;
																												continue;
																												end_IL_0287:
																												break;
																												IL_0287:;
																											}
																											break;
																											IL_0297:;
																										}
																										break;
																									}
																									goto IL_0473;
																									IL_0473:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02f7;
																								}
																								break;
																							}
																							goto IL_0322;
																							IL_03f9:
																							ptr2 += 8;
																							goto end_IL_02f7;
																							IL_0322:
																							if (3 <= b)
																							{
																								goto IL_032d;
																							}
																							goto IL_0345;
																							IL_032d:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02f7;
																							IL_0345:
																							if (1 < b)
																							{
																								goto IL_0350;
																							}
																							goto IL_03b6;
																							IL_0350:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_035e;
																							IL_035e:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_036c;
																							IL_036c:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0395;
																							IL_0395:
																							ptr2 += 8;
																							goto IL_03a3;
																							IL_03a3:
																							num5--;
																							goto end_IL_02f7;
																							IL_03b6:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_03c4;
																							IL_03c4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03dd;
																							IL_03dd:
																							array[num5] = 0;
																							goto IL_03eb;
																							IL_03eb:
																							num5++;
																							goto IL_03f9;
																						}
																						break;
																					}
																					goto IL_040c;
																					IL_0460:
																					num5--;
																					goto end_IL_02f7;
																					IL_040c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_044c;
																					IL_044c:
																					array[num5 - 2] = 0;
																					goto IL_0460;
																				}
																				break;
																			}
																			goto IL_0486;
																			IL_05d9:
																			num5--;
																			goto end_IL_02f7;
																			IL_05ec:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 107;
																			goto IL_0657;
																			IL_0486:
																			if (9 < b)
																			{
																				goto IL_0491;
																			}
																			goto IL_04e7;
																			IL_0491:
																			if (10 < b)
																			{
																				goto IL_049c;
																			}
																			goto IL_04bd;
																			IL_049c:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04aa;
																			IL_04aa:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_04bd:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04cb;
																			IL_04cb:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02f7;
																			IL_04e7:
																			if (9 > b)
																			{
																				num = 98;
																				goto IL_04fe;
																			}
																			goto IL_05ec;
																			IL_0657:
																			num5 -= 2;
																			goto end_IL_02f7;
																			IL_04fe:
																			if (7 < b)
																			{
																				goto IL_0509;
																			}
																			goto IL_0577;
																			IL_0509:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0517;
																			IL_0517:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0525;
																			IL_0525:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0548;
																			IL_0548:
																			array[num5] = 0;
																			goto IL_0556;
																			IL_0556:
																			num5++;
																			goto IL_0564;
																			IL_0564:
																			ptr2 += 8;
																			goto end_IL_02f7;
																			IL_0577:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0585;
																			IL_0585:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05c5;
																			IL_05c5:
																			array[num5 - 2] = 0;
																			goto IL_05d9;
																		}
																		break;
																		IL_02e7:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02f7:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0724;
												IL_0724:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067a:
												break;
											}
											continue;
											end_IL_068d:
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e0:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0709:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 65;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CovariantUIntPtrTypeInfo.POLICYNOTIFICATIONSafeAccessTokenHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0346:
																	if (b < 1)
																	{
																		goto IL_030e;
																	}
																	goto IL_0336;
																	IL_0336:
																	if (b <= 9)
																	{
																		goto IL_000e;
																	}
																	goto IL_030e;
																	IL_000e:
																	if (5 < b)
																	{
																		goto IL_001c;
																	}
																	goto IL_0290;
																	IL_0290:
																	if (5 > b)
																	{
																		goto IL_029e;
																	}
																	goto IL_045c;
																	IL_029e:
																	if (2 >= b)
																	{
																		goto IL_02a9;
																	}
																	goto IL_02b9;
																	IL_02b9:
																	if (3 >= b)
																	{
																		goto IL_02c4;
																	}
																	goto IL_02d4;
																	IL_02d4:
																	if (4 >= b)
																	{
																		goto IL_02df;
																	}
																	goto IL_030e;
																	IL_030e:
																	while (true)
																	{
																		IL_030e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_0227:
																			array[num5] = 0;
																			num = 114;
																			while (true)
																			{
																				if (num != 114)
																				{
																					if (num != 1095)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 79:
																						break;
																					case 105:
																						goto IL_001c;
																					case 19:
																						goto IL_002a;
																					case 54:
																						goto IL_0038;
																					default:
																						continue;
																					case 60:
																						goto IL_0227;
																					case 24:
																					case 32:
																						goto IL_0240;
																					case 7:
																						goto IL_024e;
																					case 52:
																						goto IL_0261;
																					case 68:
																						goto end_IL_0214;
																					case 1:
																						goto IL_027d;
																					case 82:
																						goto IL_0290;
																					case 2:
																					case 59:
																						goto IL_029e;
																					case 18:
																						goto IL_02a9;
																					case 44:
																						goto IL_02b9;
																					case 55:
																						goto IL_02c4;
																					case 71:
																					case 83:
																						goto IL_02d4;
																					case 78:
																						goto IL_02df;
																					case 66:
																					case 99:
																						goto IL_02ef;
																					case 37:
																						goto IL_0303;
																					case 4:
																					case 10:
																					case 14:
																					case 15:
																					case 22:
																					case 23:
																					case 25:
																					case 34:
																					case 41:
																					case 43:
																					case 49:
																					case 70:
																					case 74:
																					case 76:
																					case 84:
																					case 90:
																					case 91:
																					case 93:
																					case 96:
																					case 101:
																					case 107:
																						goto IL_030e_2;
																					case 51:
																						goto IL_0336;
																					case 16:
																						goto IL_0346;
																					case 88:
																						goto end_IL_0346;
																					case 42:
																					case 47:
																						goto end_IL_0353;
																					case 46:
																					case 57:
																						goto IL_036e;
																					case 31:
																					case 69:
																						goto IL_038a;
																					case 45:
																						goto IL_03a3;
																					case 77:
																						goto IL_03b1;
																					case 17:
																					case 61:
																						goto IL_03c4;
																					case 20:
																					case 30:
																						goto IL_0409;
																					case 38:
																						goto IL_043b;
																					case 73:
																						goto IL_0449;
																					case 12:
																					case 29:
																						goto IL_045c;
																					case 36:
																						goto IL_046a;
																					case 80:
																						goto IL_048d;
																					case 75:
																						goto IL_0497;
																					case 53:
																						goto IL_04a5;
																					case 8:
																					case 86:
																						goto IL_04b8;
																					case 35:
																						goto IL_04f8;
																					case 81:
																						goto IL_050c;
																					case 67:
																					case 89:
																						goto IL_051f;
																					case 72:
																						goto IL_055f;
																					case 40:
																					case 92:
																						goto IL_0578;
																					case 63:
																						goto IL_05b8;
																					case 56:
																						goto IL_05cc;
																					case 100:
																						goto IL_05dc;
																					case 85:
																						goto IL_05f0;
																					case 104:
																						goto IL_0600;
																					case 106:
																						goto IL_0619;
																					case 13:
																						goto IL_0637;
																					case 0:
																					case 9:
																					case 21:
																					case 28:
																					case 58:
																					case 62:
																					case 64:
																					case 87:
																					case 94:
																					case 98:
																					case 102:
																						goto end_IL_0363;
																					case 26:
																						goto end_IL_0645;
																					case 11:
																						goto end_IL_0658;
																					case 33:
																						goto end_IL_0662;
																					case 3:
																						goto end_IL_066d;
																					case 97:
																						goto end_IL_0682;
																					case 48:
																					case 50:
																						goto end_IL_0697;
																					case 95:
																						goto end_IL_06a7;
																					case 65:
																					case 103:
																						goto end_IL_06b7;
																					case 5:
																						goto end_IL_06c7;
																					case 6:
																						goto end_IL_06d7;
																					case 27:
																					case 39:
																						goto IL_06fb;
																					}
																					goto IL_000e;
																				}
																				num5++;
																				goto IL_0637;
																				IL_0637:
																				ptr2 += 8;
																				goto end_IL_0363;
																				continue;
																				end_IL_0214:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_026f;
																	IL_02df:
																	if (4 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_051f;
																	IL_051f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_055f;
																	IL_055f:
																	array[num5 - 2] = 0;
																	goto IL_0619;
																	IL_0619:
																	num5--;
																	goto end_IL_0363;
																	IL_02c4:
																	if (3 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0409;
																	IL_0409:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 38;
																	goto IL_043b;
																	IL_043b:
																	ptr2 += 8;
																	goto IL_0449;
																	IL_0449:
																	num5--;
																	goto end_IL_0363;
																	IL_02a9:
																	if (2 > b)
																	{
																		goto IL_02ef;
																	}
																	goto IL_03c4;
																	IL_02ef:
																	if (1 >= b)
																	{
																		num = 37;
																		goto IL_0303;
																	}
																	goto IL_030e;
																	IL_04a5:
																	ptr2 += 8;
																	goto end_IL_0363;
																	IL_0303:
																	if (1 > b)
																	{
																	}
																	goto IL_030e;
																	IL_03c4:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05dc;
																	IL_05dc:
																	array[num5 - 2] = 0;
																	goto IL_05f0;
																	IL_05f0:
																	num5--;
																	goto end_IL_0363;
																	IL_001c:
																	if (7 < b)
																	{
																		goto IL_002a;
																	}
																	goto IL_0261;
																	IL_002a:
																	if (8 >= b)
																	{
																		goto IL_0038;
																	}
																	goto IL_0240;
																	IL_0038:
																	if (8 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0578;
																	IL_0578:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05b8;
																	IL_05b8:
																	array[num5 - 2] = 0;
																	goto IL_05cc;
																	IL_05cc:
																	num5--;
																	goto end_IL_0363;
																	IL_0240:
																	if (9 >= b)
																	{
																		goto IL_024e;
																	}
																	goto IL_030e;
																	IL_024e:
																	if (9 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_036e;
																	IL_036e:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_0363;
																	IL_0261:
																	if (7 > b)
																	{
																		goto IL_026f;
																	}
																	goto IL_038a;
																	IL_026f:
																	if (6 >= b)
																	{
																		goto IL_027d;
																	}
																	goto IL_030e;
																	IL_027d:
																	if (6 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_04b8;
																	IL_04b8:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04f8;
																	IL_04f8:
																	array[num5 - 2] = 0;
																	goto IL_050c;
																	IL_050c:
																	num5--;
																	goto end_IL_0363;
																	IL_038a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_03a3;
																	IL_03a3:
																	array[num5] = 0;
																	goto IL_03b1;
																	IL_03b1:
																	num5++;
																	goto IL_0600;
																	IL_0600:
																	ptr2 += 8;
																	num = 28;
																	goto end_IL_0363;
																	IL_045c:
																	array[num5] = 0;
																	goto IL_046a;
																	IL_046a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_048d;
																	IL_048d:
																	array2[num5] = null;
																	goto IL_0497;
																	IL_0497:
																	num5++;
																	goto IL_04a5;
																	continue;
																	end_IL_0346:
																	break;
																}
																continue;
																end_IL_0353:
																break;
															}
															continue;
															end_IL_0363:
															break;
														}
														continue;
													}
													goto IL_06fb;
													IL_06fb:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0645:
													break;
												}
												continue;
												end_IL_0658:
												break;
											}
											continue;
											end_IL_0662:
											break;
										}
										continue;
										end_IL_066d:
										break;
									}
									continue;
									end_IL_0682:
									break;
								}
								continue;
								end_IL_0697:
								break;
							}
							continue;
							end_IL_06a7:
							break;
						}
						continue;
						end_IL_06b7:
						break;
					}
					continue;
					end_IL_06c7:
					break;
				}
				continue;
				end_IL_06d7:
				break;
			}
		}
	}

	static Class154()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_004a:
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 1:
							case 3:
							case 6:
								goto IL_004a;
							case 4:
								goto end_IL_003d;
							case 5:
								goto end_IL_005c;
							case 0:
								return;
							case 2:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					break;
				}
				continue;
				end_IL_005c:
				break;
			}
		}
	}
}
