using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Mute Gun (CS)", "Rig", "Client-side mute via gun.", false, 44, ModType.const_0, false)]
internal class Class187 : MonoBehaviour
{
	internal sealed class _003C_003Ec__DisplayClass1_0
	{
		public NetPlayer netPlayer_0;

		private static IntPtr[] ApplicationStateDispositionGetNextArgType;

		public _003C_003Ec__DisplayClass1_0()
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
		}

		internal unsafe bool method_0(GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine_0)
		{
			int num = 3;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								long[] array3 = new long[2];
								while (true)
								{
									object[] array4 = new object[2];
									while (true)
									{
										array4[0] = gorillaPlayerScoreboardLine_0;
										while (true)
										{
											array4[1] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPrivilegeNamegetMemberName.ConfigIV);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01d0:
																		if (b >= 1)
																		{
																			while (b <= 6)
																			{
																				while (true)
																				{
																					IL_01b3:
																					if (3 >= b)
																					{
																						while (true)
																						{
																							IL_01a3:
																							if (3 > b)
																							{
																								while (true)
																								{
																									IL_0193:
																									if (1 >= b)
																									{
																										while (1 <= b)
																										{
																											num = 84;
																											while (num != 84 && num == 1065)
																											{
																												switch (num)
																												{
																												case 25:
																													goto IL_0180;
																												case 12:
																												case 14:
																													goto IL_0193;
																												case 51:
																													goto IL_01a3;
																												case 68:
																													goto IL_01b3;
																												case 76:
																													goto IL_01c0;
																												case 27:
																													goto IL_01d0;
																												case 1:
																													goto end_IL_01d0;
																												case 35:
																												case 56:
																													goto end_IL_01e0;
																												case 0:
																												case 19:
																													goto IL_01fb;
																												case 33:
																													goto IL_0206;
																												case 31:
																													goto IL_0214;
																												case 23:
																												case 48:
																													goto IL_0224;
																												case 53:
																													goto IL_0237;
																												case 21:
																												case 26:
																													goto IL_0245;
																												case 20:
																													goto IL_027d;
																												case 15:
																													goto IL_0291;
																												case 49:
																												case 62:
																													goto IL_02a4;
																												case 18:
																													goto IL_02b2;
																												case 65:
																													goto IL_02c2;
																												case 5:
																												case 43:
																													goto IL_02d0;
																												case 59:
																												case 69:
																													goto IL_02ec;
																												case 32:
																													goto IL_0324;
																												case 54:
																													goto IL_0338;
																												case 52:
																												case 77:
																													goto IL_034b;
																												case 60:
																													goto IL_038a;
																												case 75:
																													goto IL_03a7;
																												case 8:
																												case 11:
																												case 24:
																												case 29:
																												case 38:
																												case 39:
																												case 41:
																												case 42:
																												case 44:
																												case 57:
																												case 64:
																												case 71:
																												case 74:
																													goto end_IL_016d;
																												case 73:
																													goto IL_03d2;
																												case 55:
																													goto IL_03e0;
																												case 72:
																													goto IL_03ee;
																												case 28:
																												case 63:
																													goto IL_03fe;
																												case 9:
																													goto IL_0416;
																												case 50:
																													goto IL_0424;
																												case 7:
																													goto IL_043b;
																												case 4:
																												case 16:
																												case 30:
																												case 34:
																												case 36:
																												case 37:
																												case 47:
																												case 66:
																													goto end_IL_01f0;
																												case 40:
																													goto end_IL_0449;
																												case 46:
																													goto end_IL_045c;
																												case 13:
																													goto end_IL_0466;
																												case 22:
																													goto end_IL_0471;
																												case 61:
																													goto end_IL_0481;
																												case 10:
																												case 17:
																													goto end_IL_0491;
																												case 45:
																													goto end_IL_04a1;
																												case 58:
																												case 70:
																													goto end_IL_04b1;
																												case 2:
																													goto end_IL_04c1;
																												case 3:
																													goto end_IL_04d1;
																												case 6:
																												case 67:
																													goto IL_04ec;
																												}
																												continue;
																												end_IL_016d:
																												break;
																											}
																											break;
																											IL_0180:;
																										}
																										break;
																									}
																									goto IL_02a4;
																									IL_0338:
																									ptr2 += 8;
																									goto end_IL_01f0;
																									IL_02a4:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_02b2;
																									IL_02b2:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_02ec;
																									IL_02ec:
																									array2[num5 - 1] = ((delegate*<GorillaPlayerScoreboardLine, NetPlayer>)ApplicationStateDispositionGetNextArgType[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine)array2[num5 - 1]);
																									goto IL_0324;
																									IL_0324:
																									array[num5 - 1] = 5;
																									goto IL_0338;
																								}
																								break;
																							}
																							goto IL_03fe;
																							IL_043b:
																							ptr2 += 8;
																							goto end_IL_01f0;
																							IL_03fe:
																							array2[num5] = array4[*(int*)(ptr2 + num3)];
																							goto IL_0416;
																							IL_0416:
																							array[num5] = 5;
																							goto IL_0424;
																							IL_0424:
																							num5++;
																							num = 7;
																							goto IL_043b;
																						}
																						break;
																					}
																					goto IL_01fb;
																					IL_02d0:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_01f0;
																					IL_01fb:
																					if (5 >= b)
																					{
																						goto IL_0206;
																					}
																					goto IL_0224;
																					IL_0206:
																					if (5 > b)
																					{
																						goto IL_0214;
																					}
																					goto IL_034b;
																					IL_0214:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0237;
																					IL_0237:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0245;
																					IL_0245:
																					array2[num5 - 1] = ((delegate*<_003C_003Ec__DisplayClass1_0, NetPlayer>)ApplicationStateDispositionGetNextArgType[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array2[num5 - 1]);
																					goto IL_027d;
																					IL_027d:
																					array[num5 - 1] = 5;
																					goto IL_0291;
																					IL_0291:
																					ptr2 += 8;
																					goto end_IL_01f0;
																					IL_034b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = (((NetPlayer)array2[num5 - 2] == (NetPlayer)array2[num5 - 1]) ? 1 : 0);
																					goto IL_038a;
																					IL_038a:
																					array[num5 - 2] = 0;
																					num = 75;
																					goto IL_03a7;
																					IL_03a7:
																					num5--;
																					goto end_IL_01f0;
																					IL_0224:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_02c2;
																					IL_02c2:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_02d0;
																				}
																				break;
																				IL_01c0:;
																			}
																		}
																		array2[num5] = array4[*(int*)(ptr2 + num3)];
																		goto IL_03d2;
																		IL_03ee:
																		ptr2 += 8;
																		goto end_IL_01f0;
																		IL_03e0:
																		num5++;
																		goto IL_03ee;
																		IL_03d2:
																		array[num5] = 5;
																		goto IL_03e0;
																		continue;
																		end_IL_01d0:
																		break;
																	}
																	continue;
																	end_IL_01e0:
																	break;
																}
																continue;
																end_IL_01f0:
																break;
															}
															continue;
														}
														goto IL_04ec;
														IL_04ec:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1])) != 0;
														continue;
														end_IL_0449:
														break;
													}
													continue;
													end_IL_045c:
													break;
												}
												continue;
												end_IL_0466:
												break;
											}
											continue;
											end_IL_0471:
											break;
										}
										continue;
										end_IL_0481:
										break;
									}
									continue;
									end_IL_0491:
									break;
								}
								continue;
								end_IL_04a1:
								break;
							}
							continue;
							end_IL_04b1:
							break;
						}
						continue;
						end_IL_04c1:
						break;
					}
					continue;
					end_IL_04d1:
					break;
				}
			}
		}

		static _003C_003Ec__DisplayClass1_0()
		{
			int num = 2;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					num = 10;
					while (true)
					{
						if (num == 10 || num != 991)
						{
							return;
						}
						switch (num)
						{
						case 1:
							goto end_IL_0031;
						case 2:
							goto end_IL_003e;
						case 0:
							return;
						case 3:
							return;
						}
						continue;
						end_IL_0031:
						break;
					}
					continue;
					end_IL_003e:
					break;
				}
			}
		}
	}

	private static string string_0;

	private static double double_0;

	private static bool bool_0;

	private static int int_0;

	private static int int_1;

	private static float float_0;

	private static Class8.GunResult MutexAccessRuleCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGVISIBLE;

	private static IntPtr[] ILegacyEvidenceAdapterIEnumReferenceIdentity;

	private static IntPtr[] FindIndexUseUserOverride;

	private static IntPtr[] CompressedStackRunDataFromBaseString;

	private static IntPtr[] FormatProviderNameIdentifier;

	private static IntPtr[] intptr_0;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_08db, IL_08ee, IL_0939, IL_0949, IL_0959, IL_0969, IL_0979, IL_0989, IL_0999, IL_09a9, IL_09b9, IL_09c9, IL_09d9, IL_09e9, IL_09f9, IL_0a12, IL_0a1d, IL_0a28, IL_0a33, IL_0a46, IL_0a86, IL_0a99, IL_0aac, IL_0af6, IL_0b09, IL_0b19, IL_0b2c, IL_0b3a, IL_0b63, IL_0b71, IL_0b84, IL_0b8f, IL_0b98, IL_0bd8, IL_0bf5, IL_0c08, IL_0c16, IL_0c24, IL_0c2d, IL_0c46, IL_0c54, IL_0c62, IL_0c75, IL_0c98, IL_0ca2, IL_0cb9, IL_0ccc, IL_0ce0, IL_0cfc, IL_0d07, IL_0d47, IL_0d5b, IL_0d6e, IL_0d7c, IL_0d8a, IL_0dd3, IL_0de7, IL_0e03, IL_0e11, IL_0e1f, IL_0e3c, IL_0e8b, IL_0e95, IL_0ec2, IL_0ed6, IL_0ee4, IL_0ef7, IL_0f05, IL_0f10, IL_0f72, IL_0f85, IL_0f93, IL_0fa1, IL_0fe1, IL_0ff5, IL_1008, IL_1016, IL_1029, IL_1037, IL_1042, IL_1050, IL_105e, IL_107c, IL_108a, IL_109d, IL_10c6, IL_10df, IL_10ed, IL_10fb, IL_1113, IL_1131, IL_1155, IL_116d, IL_1180, IL_118e, IL_119c, IL_11aa, IL_11c2, IL_11d0, IL_11e3, IL_11f1, IL_11fc, IL_1216, IL_1224, IL_1232, IL_124e, IL_125c, IL_1267, IL_127e, IL_12ab, IL_12c2, IL_12d5, IL_12e3, IL_12ec, IL_12f7, IL_1310, IL_1327, IL_1335, IL_1348, IL_1356, IL_1364, IL_1378, IL_13b0, IL_13c3, IL_13d1, IL_13df, IL_13e8, IL_1400, IL_140e, IL_141c, IL_142a, IL_1438, IL_1496, IL_14a9, IL_14b2, IL_14db, IL_14e9, IL_14fc, IL_150a, IL_1518, IL_1534, IL_1542, IL_1550, IL_155e, IL_1569, IL_1591, IL_159f, IL_15b2, IL_15c0, IL_15ce, IL_15e2, IL_1673, IL_1681, IL_1694, IL_16a2, IL_16b0, IL_16be, IL_16e0, IL_16ee, IL_1701, IL_1748, IL_175c, IL_176f, IL_177d, IL_1788, IL_1791, IL_17e3, IL_17f6, IL_1804, IL_1812, IL_1850, IL_1864, IL_1877, IL_1882, IL_1890, IL_18ce, IL_18e2, IL_18f5, IL_1903, IL_1911, IL_1949, IL_195d, IL_1970, IL_197e, IL_198c, IL_19a0, IL_19ec, IL_19fa, IL_1a0d, IL_1a1b, IL_1a29, IL_1a37, IL_1a42, IL_1a50, IL_1a65, IL_1a73, IL_1a86, IL_1a94, IL_1aa2, IL_1ab6, IL_1b03, IL_1b11, IL_1b24, IL_1b2d, IL_1b3b, IL_1b49, IL_1b57, IL_1bab, IL_1bbe, IL_1bd5, IL_1bf3, IL_1c01, IL_1c14, IL_1c22, IL_1c30, IL_1c3e, IL_1c4c, IL_1c5a, IL_1c6e, IL_1cac, IL_1cbf, IL_1cd3, IL_1d20, IL_1d2e, IL_1d4a, IL_1d58, IL_1d66, IL_1d93, IL_1da6, IL_1dde, IL_1df2, IL_1e05, IL_1e10, IL_1e1e, IL_1e36, IL_1e44, IL_1e57, IL_1e65, IL_1e70, IL_1e8e, IL_1e9c, IL_1eaf, IL_1ebd, IL_1ec8, IL_1ee6, IL_1ef4, IL_1f10, IL_1f1e, IL_1f2c, IL_1f3a, IL_1f58, IL_1f66, IL_1f79, IL_1f87, IL_1f95, IL_1fa3, IL_1fc1, IL_1fcf, IL_1fe2, IL_1ff0, IL_1ffb, IL_2005, IL_2013, IL_2026, IL_2034, IL_2042, IL_2050, IL_2068, IL_2076, IL_2089, IL_2097, IL_20a5, IL_20b9, IL_2106, IL_2114, IL_2127, IL_2135, IL_2140, IL_2154, IL_219c, IL_21af, IL_21bd, IL_21c8, IL_21f2, IL_220b, IL_2216, IL_2224, IL_2232, IL_2240, IL_2258, IL_2266, IL_2279, IL_2284, IL_22a2, IL_22b0, IL_22c3, IL_22d1, IL_22df, IL_22f3, IL_232b, IL_233e, IL_2349, IL_2357, IL_2365, IL_237e, IL_238c, IL_239a, IL_23ad, IL_23b8, IL_23f1, IL_2405, IL_2418, IL_2426, IL_2434, IL_2487, IL_249a, IL_24a8, IL_24b3, IL_24eb, IL_24ff, IL_2512, IL_2520, IL_252e, IL_253c, IL_254a, IL_258a, IL_259e, IL_25ba, IL_25c3, IL_25d7, IL_2616, IL_2629, IL_2637, IL_2645, IL_2698, IL_26a6, IL_26b9, IL_26c7, IL_26d2, IL_26fb, IL_2709, IL_271c, IL_272a, IL_2738, IL_2766, IL_2779, IL_2784, IL_278f, IL_2798, IL_27c3, IL_27d9, IL_27e4, IL_27ef, IL_2802, IL_2815, IL_281f, IL_282a, IL_2840, IL_2850, IL_2860, IL_2870, IL_2880, IL_2890, IL_28a0, IL_28b0, IL_28c0 are reachable both inside and outside the pinned region starting at IL_28d5. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 94;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef88 = default(int);
			ref int reference = ref __rxRef88;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_28c0:
					num2 = 1;
					while (true)
					{
						IL_28b0:
						num3 = num2 * 4;
						while (true)
						{
							IL_28a0:
							num4 = num2 * 8;
							while (true)
							{
								IL_2890:
								array2 = new byte[5];
								while (true)
								{
									IL_2880:
									array3 = new object[5];
									while (true)
									{
										IL_2870:
										array4 = new int[5];
										while (true)
										{
											IL_2860:
											array5 = new int[7];
											while (true)
											{
												IL_2850:
												array6 = new long[5];
												while (true)
												{
													IL_2840:
													array7 = new object[14];
													while (true)
													{
														IL_282a:
														array7[0] = MutexAccessRuleCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGVISIBLE;
														while (true)
														{
															IL_281f:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TrySetCanceledgetIsFullTypeNameSetExplicit.ProxyAttributewIDLFlags);
															while (true)
															{
																IL_2815:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0a1d:
																		num = 405;
																		while (true)
																		{
																			IL_0a12:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_09f9:
																				ptr2++;
																				num = 67;
																				while (true)
																				{
																					IL_09e9:
																					if (b >= 1)
																					{
																						while (b <= 67)
																						{
																							while (true)
																							{
																								IL_09c9:
																								if (34 >= b)
																								{
																									while (true)
																									{
																										IL_09b9:
																										if (34 > b)
																										{
																											while (true)
																											{
																												IL_09a9:
																												if (17 >= b)
																												{
																													while (true)
																													{
																														IL_0999:
																														if (17 > b)
																														{
																															while (true)
																															{
																																IL_0989:
																																if (8 >= b)
																																{
																																	while (true)
																																	{
																																		IL_0979:
																																		if (8 > b)
																																		{
																																			while (true)
																																			{
																																				IL_0969:
																																				if (4 < b)
																																				{
																																					while (true)
																																					{
																																						IL_0959:
																																						if (6 < b)
																																						{
																																							while (7 >= b)
																																							{
																																								while (7 <= b)
																																								{
																																									while (true)
																																									{
																																										IL_08ee:
																																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																										num = 563;
																																										while (true)
																																										{
																																											if (num != 563)
																																											{
																																												if (num != 1544)
																																												{
																																													break;
																																												}
																																												switch (num)
																																												{
																																												case 94:
																																													break;
																																												default:
																																													continue;
																																												case 323:
																																												case 536:
																																													goto IL_08ee;
																																												case 490:
																																													goto IL_0939;
																																												case 466:
																																													goto IL_0949;
																																												case 151:
																																													goto IL_0959;
																																												case 72:
																																													goto IL_0969;
																																												case 11:
																																													goto IL_0979;
																																												case 479:
																																													goto IL_0989;
																																												case 491:
																																													goto IL_0999;
																																												case 111:
																																													goto IL_09a9;
																																												case 369:
																																													goto IL_09b9;
																																												case 143:
																																													goto IL_09c9;
																																												case 146:
																																													goto IL_09d9;
																																												case 67:
																																													goto IL_09e9;
																																												case 286:
																																													goto IL_09f9;
																																												case 405:
																																													goto IL_0a12;
																																												case 424:
																																													goto IL_0a1d;
																																												case 135:
																																													goto IL_0a28;
																																												case 18:
																																													goto IL_0a33;
																																												case 99:
																																												case 248:
																																													goto IL_0a46;
																																												case 304:
																																												case 355:
																																													goto IL_0a86;
																																												case 309:
																																												case 360:
																																													goto IL_0a99;
																																												case 103:
																																												case 363:
																																													goto IL_0aac;
																																												case 416:
																																													goto IL_0af6;
																																												case 460:
																																													goto IL_0b09;
																																												case 484:
																																													goto IL_0b19;
																																												case 493:
																																													goto IL_0b2c;
																																												case 228:
																																												case 436:
																																													goto IL_0b3a;
																																												case 212:
																																													goto IL_0b63;
																																												case 64:
																																													goto IL_0b71;
																																												case 504:
																																													goto IL_0b84;
																																												case 121:
																																												case 377:
																																													goto IL_0b98;
																																												case 489:
																																													goto IL_0bd8;
																																												case 207:
																																													goto IL_0bf5;
																																												case 548:
																																													goto IL_0c08;
																																												case 210:
																																													goto IL_0c16;
																																												case 441:
																																												case 459:
																																													goto IL_0c2d;
																																												case 185:
																																													goto IL_0c46;
																																												case 468:
																																													goto IL_0c54;
																																												case 518:
																																													goto IL_0c62;
																																												case 554:
																																													goto IL_0c75;
																																												case 497:
																																													goto IL_0c98;
																																												case 334:
																																													goto IL_0ca2;
																																												case 138:
																																													goto IL_0cb9;
																																												case 485:
																																													goto IL_0ce0;
																																												case 388:
																																													goto IL_0cfc;
																																												case 98:
																																												case 256:
																																													goto IL_0d07;
																																												case 105:
																																													goto IL_0d47;
																																												case 387:
																																													goto IL_0d5b;
																																												case 455:
																																													goto IL_0d6e;
																																												case 446:
																																													goto IL_0d7c;
																																												case 142:
																																												case 291:
																																													goto IL_0d8a;
																																												case 87:
																																													goto IL_0dd3;
																																												case 408:
																																													goto IL_0de7;
																																												case 432:
																																													goto IL_0e03;
																																												case 382:
																																													goto IL_0e11;
																																												case 239:
																																												case 483:
																																													goto IL_0e1f;
																																												case 150:
																																													goto IL_0ed6;
																																												case 555:
																																													goto IL_0ee4;
																																												case 84:
																																													goto IL_0ef7;
																																												case 294:
																																													goto IL_0f05;
																																												case 267:
																																												case 333:
																																													goto IL_0f10;
																																												case 454:
																																													goto IL_0f72;
																																												case 246:
																																													goto IL_0f85;
																																												case 553:
																																													goto IL_0f93;
																																												case 122:
																																												case 407:
																																													goto IL_0fa1;
																																												case 373:
																																													goto IL_0fe1;
																																												case 77:
																																													goto IL_0ff5;
																																												case 389:
																																													goto IL_1008;
																																												case 398:
																																													goto IL_1016;
																																												case 231:
																																													goto IL_1029;
																																												case 237:
																																													goto IL_1037;
																																												case 36:
																																													goto IL_1042;
																																												case 136:
																																													goto IL_1050;
																																												case 183:
																																												case 495:
																																													goto IL_105e;
																																												case 91:
																																													goto IL_107c;
																																												case 319:
																																													goto IL_108a;
																																												case 5:
																																												case 66:
																																													goto IL_109d;
																																												case 335:
																																													goto IL_10c6;
																																												case 517:
																																													goto IL_10df;
																																												case 396:
																																													goto IL_10ed;
																																												case 4:
																																												case 287:
																																													goto IL_10fb;
																																												case 116:
																																													goto IL_1113;
																																												case 80:
																																													goto IL_1131;
																																												case 537:
																																													goto IL_1155;
																																												case 356:
																																													goto IL_116d;
																																												case 392:
																																													goto IL_1180;
																																												case 204:
																																													goto IL_118e;
																																												case 133:
																																												case 453:
																																													goto IL_119c;
																																												case 448:
																																													goto IL_11aa;
																																												case 522:
																																													goto IL_11c2;
																																												case 198:
																																													goto IL_11d0;
																																												case 362:
																																													goto IL_11e3;
																																												case 279:
																																													goto IL_11f1;
																																												case 97:
																																												case 208:
																																													goto IL_11fc;
																																												case 194:
																																													goto IL_1216;
																																												case 114:
																																													goto IL_1224;
																																												case 12:
																																													goto IL_1232;
																																												case 14:
																																													goto IL_124e;
																																												case 260:
																																													goto IL_125c;
																																												case 196:
																																												case 475:
																																													goto IL_1267;
																																												case 352:
																																													goto IL_127e;
																																												case 508:
																																													goto IL_12ab;
																																												case 480:
																																													goto IL_12c2;
																																												case 403:
																																													goto IL_12d5;
																																												case 545:
																																													goto IL_12ec;
																																												case 110:
																																												case 381:
																																													goto IL_12f7;
																																												case 289:
																																													goto IL_1310;
																																												case 73:
																																													goto IL_1327;
																																												case 81:
																																													goto IL_1335;
																																												case 269:
																																													goto IL_1348;
																																												case 399:
																																													goto IL_1356;
																																												case 6:
																																												case 552:
																																													goto IL_1364;
																																												case 447:
																																													goto IL_1378;
																																												case 255:
																																													goto IL_13b0;
																																												case 507:
																																													goto IL_13c3;
																																												case 144:
																																													goto IL_13d1;
																																												case 390:
																																												case 410:
																																													goto IL_13e8;
																																												case 541:
																																													goto IL_1400;
																																												case 86:
																																													goto IL_140e;
																																												case 37:
																																													goto IL_141c;
																																												case 90:
																																													goto IL_142a;
																																												case 2:
																																												case 295:
																																													goto IL_1438;
																																												case 250:
																																													goto IL_1496;
																																												case 160:
																																												case 166:
																																													goto IL_14b2;
																																												case 238:
																																													goto IL_14db;
																																												case 393:
																																													goto IL_14e9;
																																												case 543:
																																													goto IL_14fc;
																																												case 314:
																																													goto IL_150a;
																																												case 186:
																																												case 380:
																																													goto IL_1518;
																																												case 521:
																																													goto IL_1534;
																																												case 402:
																																													goto IL_1542;
																																												case 285:
																																													goto IL_1550;
																																												case 112:
																																													goto IL_155e;
																																												case 268:
																																												case 462:
																																													goto IL_1569;
																																												case 277:
																																													goto IL_1591;
																																												case 123:
																																													goto IL_159f;
																																												case 129:
																																													goto IL_15b2;
																																												case 140:
																																													goto IL_15c0;
																																												case 56:
																																												case 226:
																																													goto IL_15ce;
																																												case 31:
																																													goto IL_15e2;
																																												case 127:
																																													goto IL_1673;
																																												case 452:
																																													goto IL_1681;
																																												case 95:
																																													goto IL_1694;
																																												case 330:
																																													goto IL_16a2;
																																												case 385:
																																												case 492:
																																													goto IL_16b0;
																																												case 337:
																																													goto IL_16be;
																																												case 32:
																																													goto IL_16e0;
																																												case 425:
																																													goto IL_16ee;
																																												case 300:
																																												case 529:
																																													goto IL_1701;
																																												case 232:
																																													goto IL_1748;
																																												case 225:
																																													goto IL_175c;
																																												case 343:
																																													goto IL_176f;
																																												case 514:
																																													goto IL_177d;
																																												case 182:
																																												case 303:
																																													goto IL_1791;
																																												case 89:
																																													goto IL_17e3;
																																												case 214:
																																													goto IL_17f6;
																																												case 222:
																																													goto IL_1804;
																																												case 234:
																																												case 358:
																																													goto IL_1812;
																																												case 519:
																																													goto IL_1850;
																																												case 417:
																																													goto IL_1864;
																																												case 74:
																																													goto IL_1877;
																																												case 157:
																																													goto IL_1882;
																																												case 118:
																																												case 219:
																																													goto IL_1890;
																																												case 265:
																																													goto IL_18ce;
																																												case 354:
																																													goto IL_18e2;
																																												case 125:
																																													goto IL_18f5;
																																												case 297:
																																													goto IL_1903;
																																												case 141:
																																												case 147:
																																													goto IL_1911;
																																												case 165:
																																													goto IL_1949;
																																												case 130:
																																													goto IL_195d;
																																												case 520:
																																													goto IL_1970;
																																												case 29:
																																													goto IL_197e;
																																												case 59:
																																												case 341:
																																													goto IL_198c;
																																												case 443:
																																													goto IL_19a0;
																																												case 45:
																																													goto IL_19ec;
																																												case 271:
																																													goto IL_19fa;
																																												case 264:
																																													goto IL_1a0d;
																																												case 153:
																																													goto IL_1a1b;
																																												case 3:
																																													goto IL_1a29;
																																												case 46:
																																													goto IL_1a37;
																																												case 472:
																																													goto IL_1a42;
																																												case 270:
																																												case 336:
																																													goto IL_1a50;
																																												case 534:
																																													goto IL_1a65;
																																												case 365:
																																													goto IL_1a73;
																																												case 251:
																																													goto IL_1a86;
																																												case 282:
																																													goto IL_1a94;
																																												case 367:
																																												case 477:
																																													goto IL_1aa2;
																																												case 243:
																																													goto IL_1ab6;
																																												case 65:
																																													goto IL_1b03;
																																												case 44:
																																													goto IL_1b11;
																																												case 217:
																																													goto IL_1b2d;
																																												case 26:
																																													goto IL_1b3b;
																																												case 128:
																																													goto IL_1b49;
																																												case 10:
																																												case 102:
																																													goto IL_1b57;
																																												case 281:
																																													goto IL_1bab;
																																												case 106:
																																												case 353:
																																													goto IL_1bbe;
																																												case 418:
																																													goto IL_1bd5;
																																												case 203:
																																													goto IL_1bf3;
																																												case 322:
																																													goto IL_1c01;
																																												case 486:
																																													goto IL_1c14;
																																												case 48:
																																													goto IL_1c22;
																																												case 376:
																																													goto IL_1c30;
																																												case 68:
																																													goto IL_1c3e;
																																												case 311:
																																													goto IL_1c4c;
																																												case 34:
																																												case 218:
																																													goto IL_1c5a;
																																												case 481:
																																													goto IL_1c6e;
																																												case 20:
																																													goto IL_1cac;
																																												case 364:
																																												case 370:
																																													goto IL_1cbf;
																																												case 115:
																																													goto IL_1cd3;
																																												case 88:
																																													goto IL_1d20;
																																												case 296:
																																													goto IL_1d2e;
																																												case 79:
																																													goto IL_1d4a;
																																												case 273:
																																													goto IL_1d58;
																																												case 189:
																																												case 467:
																																													goto IL_1d66;
																																												case 187:
																																													goto IL_1d93;
																																												case 181:
																																												case 525:
																																													goto IL_1da6;
																																												case 499:
																																													goto IL_1dde;
																																												case 544:
																																													goto IL_1df2;
																																												case 318:
																																													goto IL_1e05;
																																												case 359:
																																												case 540:
																																													goto IL_1e10;
																																												case 119:
																																													goto IL_1e1e;
																																												case 206:
																																													goto IL_1e36;
																																												case 193:
																																													goto IL_1e44;
																																												case 134:
																																													goto IL_1e57;
																																												case 108:
																																													goto IL_1e65;
																																												case 161:
																																												case 428:
																																													goto IL_1e70;
																																												case 397:
																																													goto IL_1e8e;
																																												case 24:
																																													goto IL_1e9c;
																																												case 423:
																																													goto IL_1eaf;
																																												case 509:
																																													goto IL_1ebd;
																																												case 0:
																																												case 158:
																																													goto IL_1ec8;
																																												case 33:
																																													goto IL_1ee6;
																																												case 375:
																																													goto IL_1ef4;
																																												case 549:
																																													goto IL_1f10;
																																												case 63:
																																													goto IL_1f1e;
																																												case 235:
																																												case 293:
																																													goto IL_1f2c;
																																												case 321:
																																													goto IL_1f3a;
																																												case 167:
																																													goto IL_1f58;
																																												case 325:
																																													goto IL_1f66;
																																												case 326:
																																													goto IL_1f79;
																																												case 252:
																																													goto IL_1f87;
																																												case 139:
																																												case 384:
																																													goto IL_1f95;
																																												case 307:
																																													goto IL_1fa3;
																																												case 437:
																																													goto IL_1fc1;
																																												case 506:
																																													goto IL_1fcf;
																																												case 236:
																																													goto IL_1fe2;
																																												case 41:
																																													goto IL_1ff0;
																																												case 55:
																																												case 233:
																																													goto IL_1ffb;
																																												case 515:
																																													goto IL_2005;
																																												case 15:
																																													goto IL_2013;
																																												case 346:
																																													goto IL_2026;
																																												case 457:
																																													goto IL_2034;
																																												case 60:
																																												case 278:
																																													goto IL_2042;
																																												case 482:
																																													goto IL_2050;
																																												case 449:
																																													goto IL_2068;
																																												case 328:
																																													goto IL_2076;
																																												case 310:
																																													goto IL_2089;
																																												case 461:
																																													goto IL_2097;
																																												case 54:
																																												case 57:
																																													goto IL_20a5;
																																												case 488:
																																													goto IL_20b9;
																																												case 61:
																																													goto IL_2106;
																																												case 224:
																																													goto IL_2114;
																																												case 132:
																																													goto IL_2127;
																																												case 171:
																																													goto IL_2135;
																																												case 431:
																																												case 528:
																																													goto IL_2140;
																																												case 445:
																																													goto IL_2154;
																																												case 240:
																																													goto IL_219c;
																																												case 83:
																																													goto IL_21af;
																																												case 254:
																																													goto IL_21bd;
																																												case 257:
																																												case 546:
																																													goto IL_21c8;
																																												case 374:
																																													goto IL_21f2;
																																												case 316:
																																													goto IL_220b;
																																												case 75:
																																													goto IL_2216;
																																												case 420:
																																													goto IL_2224;
																																												case 137:
																																												case 361:
																																													goto IL_2232;
																																												case 25:
																																													goto IL_2240;
																																												case 527:
																																													goto IL_2258;
																																												case 487:
																																													goto IL_2266;
																																												case 427:
																																													goto IL_2279;
																																												case 152:
																																												case 327:
																																													goto IL_2284;
																																												case 107:
																																													goto IL_22a2;
																																												case 406:
																																													goto IL_22b0;
																																												case 458:
																																													goto IL_22c3;
																																												case 501:
																																													goto IL_22d1;
																																												case 262:
																																												case 451:
																																													goto IL_22df;
																																												case 317:
																																													goto IL_22f3;
																																												case 498:
																																													goto IL_232b;
																																												case 100:
																																													goto IL_233e;
																																												case 19:
																																													goto IL_2349;
																																												case 542:
																																													goto IL_2357;
																																												case 17:
																																												case 438:
																																													goto IL_2365;
																																												case 419:
																																													goto IL_237e;
																																												case 357:
																																													goto IL_238c;
																																												case 371:
																																													goto IL_239a;
																																												case 538:
																																													goto IL_23ad;
																																												case 258:
																																												case 422:
																																													goto IL_23b8;
																																												case 223:
																																													goto IL_23f1;
																																												case 324:
																																													goto IL_2405;
																																												case 308:
																																													goto IL_2418;
																																												case 205:
																																													goto IL_2426;
																																												case 173:
																																												case 192:
																																													goto IL_2434;
																																												case 550:
																																													goto IL_2487;
																																												case 456:
																																													goto IL_249a;
																																												case 201:
																																													goto IL_24a8;
																																												case 280:
																																												case 494:
																																													goto IL_24b3;
																																												case 21:
																																													goto IL_24eb;
																																												case 176:
																																													goto IL_24ff;
																																												case 263:
																																													goto IL_2512;
																																												case 476:
																																													goto IL_2520;
																																												case 339:
																																													goto IL_252e;
																																												case 429:
																																													goto IL_253c;
																																												case 47:
																																												case 434:
																																													goto IL_254a;
																																												case 344:
																																													goto IL_258a;
																																												case 530:
																																													goto IL_259e;
																																												case 101:
																																												case 306:
																																													goto IL_25c3;
																																												case 76:
																																													goto IL_25d7;
																																												case 409:
																																													goto IL_2616;
																																												case 200:
																																													goto IL_2629;
																																												case 215:
																																													goto IL_2637;
																																												case 104:
																																												case 349:
																																													goto IL_2645;
																																												case 366:
																																													goto IL_2698;
																																												case 145:
																																													goto IL_26a6;
																																												case 156:
																																													goto IL_26b9;
																																												case 386:
																																													goto IL_26c7;
																																												case 188:
																																												case 414:
																																													goto IL_26d2;
																																												case 49:
																																													goto IL_26fb;
																																												case 338:
																																													goto IL_2709;
																																												case 124:
																																													goto IL_271c;
																																												case 163:
																																													goto IL_272a;
																																												case 312:
																																												case 503:
																																													goto IL_2738;
																																												case 40:
																																													goto IL_2766;
																																												case 191:
																																													goto IL_2779;
																																												case 168:
																																													goto IL_2784;
																																												case 164:
																																												case 221:
																																													goto IL_2798;
																																												case 400:
																																													goto IL_27c3;
																																												case 372:
																																													goto IL_27d9;
																																												case 69:
																																													goto IL_27e4;
																																												case 8:
																																												case 22:
																																												case 23:
																																												case 30:
																																												case 35:
																																												case 38:
																																												case 51:
																																												case 53:
																																												case 62:
																																												case 71:
																																												case 82:
																																												case 96:
																																												case 113:
																																												case 120:
																																												case 126:
																																												case 131:
																																												case 148:
																																												case 154:
																																												case 169:
																																												case 172:
																																												case 174:
																																												case 184:
																																												case 190:
																																												case 202:
																																												case 209:
																																												case 213:
																																												case 244:
																																												case 249:
																																												case 261:
																																												case 266:
																																												case 272:
																																												case 274:
																																												case 275:
																																												case 283:
																																												case 292:
																																												case 298:
																																												case 301:
																																												case 302:
																																												case 313:
																																												case 315:
																																												case 331:
																																												case 332:
																																												case 345:
																																												case 347:
																																												case 348:
																																												case 350:
																																												case 391:
																																												case 395:
																																												case 404:
																																												case 433:
																																												case 435:
																																												case 439:
																																												case 440:
																																												case 444:
																																												case 450:
																																												case 463:
																																												case 465:
																																												case 470:
																																												case 474:
																																												case 478:
																																												case 496:
																																												case 505:
																																												case 510:
																																												case 511:
																																												case 513:
																																												case 516:
																																												case 524:
																																												case 539:
																																												case 547:
																																												case 551:
																																													goto end_IL_0939;
																																												case 1:
																																												case 7:
																																												case 9:
																																												case 13:
																																												case 16:
																																												case 27:
																																												case 28:
																																												case 39:
																																												case 43:
																																												case 52:
																																												case 58:
																																												case 70:
																																												case 78:
																																												case 85:
																																												case 92:
																																												case 109:
																																												case 149:
																																												case 155:
																																												case 159:
																																												case 162:
																																												case 170:
																																												case 177:
																																												case 178:
																																												case 179:
																																												case 180:
																																												case 195:
																																												case 197:
																																												case 211:
																																												case 216:
																																												case 220:
																																												case 227:
																																												case 230:
																																												case 241:
																																												case 242:
																																												case 245:
																																												case 253:
																																												case 259:
																																												case 276:
																																												case 284:
																																												case 288:
																																												case 290:
																																												case 299:
																																												case 305:
																																												case 320:
																																												case 329:
																																												case 340:
																																												case 342:
																																												case 351:
																																												case 368:
																																												case 379:
																																												case 383:
																																												case 412:
																																												case 413:
																																												case 415:
																																												case 421:
																																												case 426:
																																												case 430:
																																												case 442:
																																												case 464:
																																												case 469:
																																												case 471:
																																												case 500:
																																												case 512:
																																												case 523:
																																												case 526:
																																												case 531:
																																												case 532:
																																												case 533:
																																												case 535:
																																												case 556:
																																													goto end_IL_08db;
																																												case 42:
																																													goto IL_2815;
																																												case 247:
																																													goto IL_281f;
																																												case 199:
																																													goto IL_282a;
																																												case 394:
																																													goto IL_2840;
																																												case 473:
																																													goto IL_2850;
																																												case 175:
																																													goto IL_2860;
																																												case 378:
																																													goto IL_2870;
																																												case 411:
																																													goto IL_2880;
																																												case 229:
																																													goto IL_2890;
																																												case 502:
																																													goto IL_28a0;
																																												case 401:
																																													goto IL_28b0;
																																												case 93:
																																													goto IL_28c0;
																																												case 50:
																																												case 117:
																																													return;
																																												}
																																												goto end_IL_2802;
																																											}
																																											array2[num6 - 2] = 0;
																																											goto IL_0ce0;
																																											IL_0ce0:
																																											num6--;
																																											num = 70;
																																											break;
																																											continue;
																																											end_IL_08db:
																																											break;
																																										}
																																										break;
																																									}
																																									goto end_IL_09e9;
																																									continue;
																																									end_IL_0939:
																																									break;
																																									IL_0939:;
																																								}
																																								break;
																																								IL_0949:;
																																							}
																																							break;
																																						}
																																						goto IL_0cfc;
																																						IL_0de7:
																																						num6--;
																																						num = 500;
																																						goto end_IL_09e9;
																																						IL_0cfc:
																																						if (6 <= b)
																																						{
																																							goto IL_0d07;
																																						}
																																						goto IL_0d6e;
																																						IL_0d07:
																																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																						goto IL_0d47;
																																						IL_0d47:
																																						array2[num6 - 2] = 0;
																																						goto IL_0d5b;
																																						IL_0d5b:
																																						num6--;
																																						goto end_IL_09e9;
																																						IL_0d6e:
																																						if (5 < b)
																																						{
																																							break;
																																						}
																																						goto IL_0d7c;
																																						IL_0d7c:
																																						if (5 > b)
																																						{
																																							break;
																																						}
																																						goto IL_0d8a;
																																						IL_0d8a:
																																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																						num = 87;
																																						goto IL_0dd3;
																																						IL_0dd3:
																																						array2[num6 - 2] = 0;
																																						goto IL_0de7;
																																					}
																																					break;
																																				}
																																				goto IL_0a28;
																																				IL_0c98:
																																				array3[num6] = null;
																																				goto IL_0ca2;
																																				IL_0a28:
																																				if (4 > b)
																																				{
																																					goto IL_0a33;
																																				}
																																				goto IL_0a99;
																																				IL_0a33:
																																				if (2 < b)
																																				{
																																					goto IL_0b09;
																																				}
																																				goto IL_0b84;
																																				IL_0b84:
																																				if (2 <= b)
																																				{
																																					num = 377;
																																					goto IL_0b98;
																																				}
																																				goto IL_0c08;
																																				IL_0ca2:
																																				num6++;
																																				num = 138;
																																				goto IL_0cb9;
																																				IL_0b98:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																				goto IL_0bd8;
																																				IL_0bd8:
																																				array2[num6 - 2] = 0;
																																				num = 207;
																																				goto IL_0bf5;
																																				IL_0bf5:
																																				num6--;
																																				goto end_IL_09e9;
																																				IL_0c08:
																																				if (1 < b)
																																				{
																																					break;
																																				}
																																				goto IL_0c16;
																																				IL_0c16:
																																				if (1 > b)
																																				{
																																					break;
																																				}
																																				num = 459;
																																				goto IL_0c2d;
																																				IL_0cb9:
																																				ptr2 += 8;
																																				goto end_IL_09e9;
																																				IL_0c2d:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																																				goto IL_0c46;
																																				IL_0c46:
																																				array2[num6] = 0;
																																				goto IL_0c54;
																																				IL_0c54:
																																				num6++;
																																				goto IL_0c62;
																																				IL_0c62:
																																				ptr2 += 8;
																																				goto end_IL_09e9;
																																				IL_0b09:
																																				if (3 < b)
																																				{
																																					break;
																																				}
																																				goto IL_0b2c;
																																				IL_0b2c:
																																				if (3 > b)
																																				{
																																					break;
																																				}
																																				goto IL_0b3a;
																																				IL_0b3a:
																																				reference = ref array5[*(int*)(ptr2 + num3)];
																																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																				goto IL_0b63;
																																				IL_0b63:
																																				ptr2 += 8;
																																				goto IL_0b71;
																																				IL_0b71:
																																				num6--;
																																				goto end_IL_09e9;
																																				IL_0a99:
																																				array2[num6] = 0;
																																				goto IL_0c75;
																																				IL_0c75:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																				goto IL_0c98;
																																			}
																																			break;
																																		}
																																		goto IL_0a86;
																																		IL_0a86:
																																		num6--;
																																		goto end_IL_09e9;
																																	}
																																	break;
																																}
																																goto IL_0e03;
																																IL_119c:
																																array2[num6] = 5;
																																goto IL_11aa;
																																IL_0e03:
																																if (12 >= b)
																																{
																																	goto IL_0e11;
																																}
																																goto IL_1029;
																																IL_0e11:
																																if (12 <= b)
																																{
																																	goto IL_0e1f;
																																}
																																goto IL_0ef7;
																																IL_0e1f:
																																array8 = array3;
																																num7 = num6;
																																if (array == null)
																																{
																																	goto IL_0e2e;
																																}
																																num8 = ptr2;
																																byte b2 = *num8;
																																ptr2 = num8 + 4;
																																int num9 = *(int*)(ptr2 + num3);
																																ptr2 += 8;
																																byte* ptr3 = ptr2 + num9;
																																byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																																while (ptr2 != ptr3)
																																{
																																	*ptr4 = (byte)(*ptr2 ^ b2);
																																	ptr2++;
																																	ptr4++;
																																}
																																array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																																goto IL_0ed6;
																																IL_11aa:
																																array3[num6] = array7[*(int*)(ptr2 + num3)];
																																goto IL_11c2;
																																IL_11c2:
																																num6++;
																																goto IL_11d0;
																																IL_11d0:
																																ptr2 += 8;
																																goto end_IL_09e9;
																																IL_0ed6:
																																array2[num6] = 5;
																																goto IL_0ee4;
																																IL_0ee4:
																																num6++;
																																goto end_IL_09e9;
																																IL_0ef7:
																																if (10 >= b)
																																{
																																	goto IL_0f05;
																																}
																																goto IL_1008;
																																IL_0f05:
																																if (10 <= b)
																																{
																																	goto IL_0f10;
																																}
																																goto IL_0f85;
																																IL_0f10:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																goto IL_0f72;
																																IL_0f72:
																																num6 -= 2;
																																goto end_IL_09e9;
																																IL_0f85:
																																if (9 < b)
																																{
																																	break;
																																}
																																goto IL_0f93;
																																IL_0f93:
																																if (9 > b)
																																{
																																	break;
																																}
																																goto IL_0fa1;
																																IL_0fa1:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0fe1;
																																IL_0fe1:
																																array2[num6 - 2] = 0;
																																goto IL_0ff5;
																																IL_0ff5:
																																num6--;
																																goto end_IL_09e9;
																																IL_1008:
																																if (11 < b)
																																{
																																	break;
																																}
																																goto IL_1016;
																																IL_1016:
																																if (11 > b)
																																{
																																	break;
																																}
																																goto end_IL_09e9;
																																IL_1029:
																																if (14 >= b)
																																{
																																	goto IL_1037;
																																}
																																goto IL_10df;
																																IL_1037:
																																if (14 > b)
																																{
																																	goto IL_1042;
																																}
																																goto IL_109d;
																																IL_1042:
																																if (13 < b)
																																{
																																	break;
																																}
																																goto IL_1050;
																																IL_1050:
																																if (13 > b)
																																{
																																	break;
																																}
																																goto IL_105e;
																																IL_105e:
																																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																goto IL_107c;
																																IL_107c:
																																ptr2 += 8;
																																goto IL_108a;
																																IL_108a:
																																num6--;
																																goto end_IL_09e9;
																																IL_109d:
																																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																goto IL_10c6;
																																IL_10c6:
																																array2[num6 - 1] = 5;
																																goto end_IL_09e9;
																																IL_10df:
																																if (15 >= b)
																																{
																																	goto IL_10ed;
																																}
																																goto IL_1180;
																																IL_10ed:
																																if (15 > b)
																																{
																																	break;
																																}
																																goto IL_10fb;
																																IL_10fb:
																																array2[num6] = array2[num6 - 1];
																																goto IL_1113;
																																IL_1113:
																																array4[num6 - 0] = array4[num6 - 1];
																																goto IL_1131;
																																IL_1131:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_1155;
																																IL_1155:
																																array3[num6] = array3[num6 - 1];
																																goto IL_116d;
																																IL_116d:
																																num6++;
																																goto end_IL_09e9;
																																IL_1180:
																																if (16 < b)
																																{
																																	break;
																																}
																																goto IL_118e;
																																IL_118e:
																																if (16 > b)
																																{
																																	break;
																																}
																																goto IL_119c;
																															}
																															break;
																														}
																														goto IL_0a46;
																														IL_0af6:
																														num6 -= 3;
																														goto end_IL_09e9;
																														IL_0a46:
																														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																														goto IL_0af6;
																													}
																													break;
																												}
																												goto IL_11e3;
																												IL_18f5:
																												if (33 < b)
																												{
																													break;
																												}
																												goto IL_1903;
																												IL_11e3:
																												if (25 >= b)
																												{
																													goto IL_11f1;
																												}
																												goto IL_1534;
																												IL_11f1:
																												if (25 <= b)
																												{
																													goto IL_11fc;
																												}
																												goto IL_124e;
																												IL_11fc:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																												goto IL_1216;
																												IL_1216:
																												array2[num6] = 3;
																												goto IL_1224;
																												IL_1224:
																												num6++;
																												goto IL_1232;
																												IL_1232:
																												ptr2 += 8;
																												num = 464;
																												goto end_IL_09e9;
																												IL_124e:
																												if (21 >= b)
																												{
																													goto IL_125c;
																												}
																												goto IL_1400;
																												IL_125c:
																												if (21 <= b)
																												{
																													goto IL_1267;
																												}
																												goto IL_12d5;
																												IL_1267:
																												array2[num6] = 0;
																												num = 352;
																												goto IL_127e;
																												IL_127e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])() ? 1 : 0);
																												num = 508;
																												goto IL_12ab;
																												IL_12ab:
																												num6++;
																												num = 480;
																												goto IL_12c2;
																												IL_12c2:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_12d5:
																												if (19 >= b)
																												{
																													num = 545;
																													goto IL_12ec;
																												}
																												goto IL_13c3;
																												IL_1903:
																												if (33 > b)
																												{
																													break;
																												}
																												goto IL_1911;
																												IL_12ec:
																												if (19 <= b)
																												{
																													goto IL_12f7;
																												}
																												goto IL_1348;
																												IL_12f7:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																												goto IL_1310;
																												IL_1310:
																												array2[num6] = 1;
																												num = 73;
																												goto IL_1327;
																												IL_1327:
																												num6++;
																												goto IL_1335;
																												IL_1335:
																												ptr2 += 16;
																												goto end_IL_09e9;
																												IL_1348:
																												if (18 < b)
																												{
																													break;
																												}
																												goto IL_1356;
																												IL_1356:
																												if (18 > b)
																												{
																													break;
																												}
																												goto IL_1364;
																												IL_1364:
																												array2[num6 - 1] = 5;
																												goto IL_1378;
																												IL_1378:
																												array3[num6 - 1] = ((delegate*<string[], string>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																												goto IL_13b0;
																												IL_13b0:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_13c3:
																												if (20 < b)
																												{
																													break;
																												}
																												goto IL_13d1;
																												IL_13d1:
																												if (20 > b)
																												{
																													break;
																												}
																												num = 390;
																												goto IL_13e8;
																												IL_1911:
																												array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
																												goto IL_1949;
																												IL_13e8:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto end_IL_09e9;
																												IL_1400:
																												if (23 >= b)
																												{
																													goto IL_140e;
																												}
																												goto IL_14fc;
																												IL_140e:
																												if (23 > b)
																												{
																													goto IL_141c;
																												}
																												num = 166;
																												goto IL_14b2;
																												IL_141c:
																												if (22 < b)
																												{
																													break;
																												}
																												goto IL_142a;
																												IL_142a:
																												if (22 > b)
																												{
																													break;
																												}
																												goto IL_1438;
																												IL_1438:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_1496;
																												IL_1496:
																												num6--;
																												goto end_IL_09e9;
																												IL_1949:
																												array2[num6 - 1] = 5;
																												goto IL_195d;
																												IL_14b2:
																												((delegate*<string, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																												goto IL_14db;
																												IL_14db:
																												num6--;
																												goto IL_14e9;
																												IL_14e9:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_14fc:
																												if (24 < b)
																												{
																													break;
																												}
																												goto IL_150a;
																												IL_150a:
																												if (24 > b)
																												{
																													break;
																												}
																												goto IL_1518;
																												IL_1518:
																												num10 = ptr2;
																												num11 = -200;
																												num5 = 1;
																												ptr2 = num10 + num11;
																												goto end_IL_09e9;
																												IL_1534:
																												if (29 >= b)
																												{
																													goto IL_1542;
																												}
																												goto IL_176f;
																												IL_1542:
																												if (29 > b)
																												{
																													goto IL_1550;
																												}
																												goto IL_1701;
																												IL_1550:
																												if (27 >= b)
																												{
																													goto IL_155e;
																												}
																												goto IL_1694;
																												IL_155e:
																												if (27 <= b)
																												{
																													goto IL_1569;
																												}
																												goto IL_15b2;
																												IL_1569:
																												array7[*(int*)(ptr2 + num3)] = (Class8.GunResult)array3[num6 - 1];
																												goto IL_1591;
																												IL_1591:
																												ptr2 += 8;
																												goto IL_159f;
																												IL_159f:
																												num6--;
																												goto end_IL_09e9;
																												IL_15b2:
																												if (26 < b)
																												{
																													break;
																												}
																												goto IL_15c0;
																												IL_15c0:
																												if (26 > b)
																												{
																													break;
																												}
																												goto IL_15ce;
																												IL_15ce:
																												array2[num6 - 5] = 4;
																												goto IL_15e2;
																												IL_15e2:
																												array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																												goto IL_1673;
																												IL_1673:
																												num6 -= 4;
																												goto IL_1681;
																												IL_1681:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_1694:
																												if (28 < b)
																												{
																													break;
																												}
																												goto IL_16a2;
																												IL_16a2:
																												if (28 > b)
																												{
																													break;
																												}
																												goto IL_16b0;
																												IL_16b0:
																												array2[num6] = 4;
																												goto IL_16be;
																												IL_16be:
																												array3[num6] = (Class8.GunResult)array7[*(int*)(ptr2 + num3)];
																												goto IL_16e0;
																												IL_16e0:
																												num6++;
																												goto IL_16ee;
																												IL_16ee:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_1701:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																												num = 232;
																												goto IL_1748;
																												IL_1748:
																												array2[num6 - 1] = 0;
																												goto IL_175c;
																												IL_175c:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_176f:
																												if (31 >= b)
																												{
																													goto IL_177d;
																												}
																												goto IL_1877;
																												IL_177d:
																												if (31 <= b)
																												{
																													num = 182;
																													goto IL_1791;
																												}
																												goto IL_17f6;
																												IL_195d:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_1791:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_17e3;
																												IL_17e3:
																												num6--;
																												goto end_IL_09e9;
																												IL_17f6:
																												if (30 < b)
																												{
																													break;
																												}
																												goto IL_1804;
																												IL_1804:
																												if (30 > b)
																												{
																													break;
																												}
																												goto IL_1812;
																												IL_1812:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																												goto IL_1850;
																												IL_1850:
																												array2[num6 - 1] = 0;
																												goto IL_1864;
																												IL_1864:
																												ptr2 += 8;
																												goto end_IL_09e9;
																												IL_1877:
																												if (32 >= b)
																												{
																													goto IL_1882;
																												}
																												goto IL_18f5;
																												IL_1882:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_1890;
																												IL_1890:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																												goto IL_18ce;
																												IL_18ce:
																												array2[num6 - 1] = 0;
																												goto IL_18e2;
																												IL_18e2:
																												ptr2 += 8;
																												goto end_IL_09e9;
																											}
																											break;
																										}
																										goto IL_0aac;
																										IL_0b19:
																										num6--;
																										goto end_IL_09e9;
																										IL_0aac:
																										ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0b19;
																									}
																									break;
																								}
																								goto IL_1970;
																								IL_2798:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_27c3;
																								IL_1970:
																								if (51 >= b)
																								{
																									goto IL_197e;
																								}
																								goto IL_2127;
																								IL_197e:
																								if (51 <= b)
																								{
																									goto IL_198c;
																								}
																								goto IL_1a0d;
																								IL_198c:
																								array2[num6 - 2] = 5;
																								goto IL_19a0;
																								IL_19a0:
																								array3[num6 - 2] = ((delegate*<IEnumerable<GorillaPlayerScoreboardLine>, Func<GorillaPlayerScoreboardLine, bool>, IEnumerable<GorillaPlayerScoreboardLine>>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine[])array3[num6 - 2], (Func<GorillaPlayerScoreboardLine, bool>)array3[num6 - 1]);
																								goto IL_19ec;
																								IL_19ec:
																								num6--;
																								goto IL_19fa;
																								IL_19fa:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1a0d:
																								if (42 < b)
																								{
																									goto IL_1a1b;
																								}
																								goto IL_1e05;
																								IL_1a1b:
																								if (46 < b)
																								{
																									goto IL_1a29;
																								}
																								goto IL_1c14;
																								IL_1a29:
																								if (48 < b)
																								{
																									goto IL_1a37;
																								}
																								num = 217;
																								goto IL_1b2d;
																								IL_1a37:
																								if (49 >= b)
																								{
																									goto IL_1a42;
																								}
																								goto IL_1a86;
																								IL_1a42:
																								if (49 > b)
																								{
																									break;
																								}
																								goto IL_1a50;
																								IL_1a50:
																								*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (void*)0;
																								goto IL_1a65;
																								IL_1a65:
																								array2[num6] = 2;
																								goto IL_1a73;
																								IL_1a73:
																								num6++;
																								goto end_IL_09e9;
																								IL_1a86:
																								if (50 < b)
																								{
																									break;
																								}
																								goto IL_1a94;
																								IL_1a94:
																								if (50 > b)
																								{
																									break;
																								}
																								goto IL_1aa2;
																								IL_1aa2:
																								array2[num6 - 2] = 5;
																								goto IL_1ab6;
																								IL_1ab6:
																								array3[num6 - 2] = ((delegate*<object, IntPtr, Func<GorillaPlayerScoreboardLine, bool>>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num6 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1b03;
																								IL_1b03:
																								num6--;
																								goto IL_1b11;
																								IL_1b11:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_27c3:
																								array2[num6 - 1] = 0;
																								goto end_IL_09e9;
																								IL_1b2d:
																								if (48 > b)
																								{
																									goto IL_1b3b;
																								}
																								goto IL_1bbe;
																								IL_1b3b:
																								if (47 < b)
																								{
																									break;
																								}
																								goto IL_1b49;
																								IL_1b49:
																								if (47 > b)
																								{
																									break;
																								}
																								goto IL_1b57;
																								IL_1b57:
																								ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1bab;
																								IL_1bab:
																								num6--;
																								goto end_IL_09e9;
																								IL_1bbe:
																								array2[num6] = 5;
																								num = 418;
																								goto IL_1bd5;
																								IL_1bd5:
																								array3[num6] = ((delegate*<GorillaPlayerScoreboardLine[]>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
																								goto IL_1bf3;
																								IL_1bf3:
																								num6++;
																								goto IL_1c01;
																								IL_1c01:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1c14:
																								if (46 > b)
																								{
																									goto IL_1c22;
																								}
																								goto IL_1da6;
																								IL_1c22:
																								if (44 >= b)
																								{
																									goto IL_1c30;
																								}
																								goto IL_1d4a;
																								IL_1c30:
																								if (44 > b)
																								{
																									goto IL_1c3e;
																								}
																								goto IL_1cbf;
																								IL_1c3e:
																								if (43 < b)
																								{
																									break;
																								}
																								goto IL_1c4c;
																								IL_1c4c:
																								if (43 > b)
																								{
																									break;
																								}
																								goto IL_1c5a;
																								IL_1c5a:
																								array2[num6 - 1] = 0;
																								goto IL_1c6e;
																								IL_1c6e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
																								goto IL_1cac;
																								IL_1cac:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1cbf:
																								array2[num6 - 2] = 5;
																								goto IL_1cd3;
																								IL_1cd3:
																								array3[num6 - 2] = ((delegate*<NetworkSystem, int, NetPlayer>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1d20;
																								IL_1d20:
																								num6--;
																								goto IL_1d2e;
																								IL_1d2e:
																								ptr2 += 8;
																								num = 178;
																								goto end_IL_09e9;
																								IL_1d4a:
																								if (45 < b)
																								{
																									break;
																								}
																								goto IL_1d58;
																								IL_1d58:
																								if (45 > b)
																								{
																									break;
																								}
																								goto IL_1d66;
																								IL_1d66:
																								((_003C_003Ec__DisplayClass1_0)array3[num6 - 2]).netPlayer_0 = (NetPlayer)array3[num6 - 1];
																								goto IL_1d93;
																								IL_1d93:
																								num6 -= 2;
																								goto end_IL_09e9;
																								IL_1da6:
																								array3[num6 - 1] = ((delegate*<_003C_003Ec__DisplayClass1_0, NetPlayer>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num6 - 1]);
																								goto IL_1dde;
																								IL_1dde:
																								array2[num6 - 1] = 5;
																								goto IL_1df2;
																								IL_1df2:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1e05:
																								if (42 <= b)
																								{
																									goto IL_1e10;
																								}
																								goto IL_1e57;
																								IL_1e10:
																								array2[num6] = 5;
																								goto IL_1e1e;
																								IL_1e1e:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_1e36;
																								IL_1e36:
																								num6++;
																								goto IL_1e44;
																								IL_1e44:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1e57:
																								if (38 >= b)
																								{
																									goto IL_1e65;
																								}
																								goto IL_1fe2;
																								IL_1e65:
																								if (38 <= b)
																								{
																									goto IL_1e70;
																								}
																								goto IL_1eaf;
																								IL_1e70:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_1e8e;
																								IL_1e8e:
																								ptr2 += 8;
																								goto IL_1e9c;
																								IL_1e9c:
																								num6--;
																								goto end_IL_09e9;
																								IL_1eaf:
																								if (36 >= b)
																								{
																									goto IL_1ebd;
																								}
																								goto IL_1f79;
																								IL_1ebd:
																								if (36 <= b)
																								{
																									goto IL_1ec8;
																								}
																								goto IL_1f10;
																								IL_1ec8:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_1ee6;
																								IL_1ee6:
																								ptr2 += 8;
																								goto IL_1ef4;
																								IL_1ef4:
																								num6--;
																								num = 253;
																								goto end_IL_09e9;
																								IL_1f10:
																								if (35 < b)
																								{
																									break;
																								}
																								goto IL_1f1e;
																								IL_1f1e:
																								if (35 > b)
																								{
																									break;
																								}
																								goto IL_1f2c;
																								IL_1f2c:
																								array2[num6] = 5;
																								goto IL_1f3a;
																								IL_1f3a:
																								array3[num6] = ((delegate*<_003C_003Ec__DisplayClass1_0>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
																								goto IL_1f58;
																								IL_1f58:
																								num6++;
																								goto IL_1f66;
																								IL_1f66:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1f79:
																								if (37 < b)
																								{
																									break;
																								}
																								goto IL_1f87;
																								IL_1f87:
																								if (37 > b)
																								{
																									break;
																								}
																								goto IL_1f95;
																								IL_1f95:
																								array2[num6] = 5;
																								goto IL_1fa3;
																								IL_1fa3:
																								array3[num6] = ((delegate*<NetworkSystem>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
																								goto IL_1fc1;
																								IL_1fc1:
																								num6++;
																								goto IL_1fcf;
																								IL_1fcf:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_1fe2:
																								if (40 >= b)
																								{
																									goto IL_1ff0;
																								}
																								goto IL_2089;
																								IL_1ff0:
																								if (40 <= b)
																								{
																									goto IL_1ffb;
																								}
																								goto IL_2026;
																								IL_1ffb:
																								array3[num6] = null;
																								goto IL_2005;
																								IL_2005:
																								array2[num6] = 5;
																								goto IL_2013;
																								IL_2013:
																								num6++;
																								goto end_IL_09e9;
																								IL_2026:
																								if (39 < b)
																								{
																									break;
																								}
																								goto IL_2034;
																								IL_2034:
																								if (39 > b)
																								{
																									break;
																								}
																								goto IL_2042;
																								IL_2042:
																								array2[num6] = 5;
																								goto IL_2050;
																								IL_2050:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_2068;
																								IL_2068:
																								num6++;
																								goto IL_2076;
																								IL_2076:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_2089:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_2097;
																								IL_2097:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_20a5;
																								IL_20a5:
																								array2[num6 - 2] = 0;
																								goto IL_20b9;
																								IL_20b9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																								goto IL_2106;
																								IL_2106:
																								num6--;
																								goto IL_2114;
																								IL_2114:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_2127:
																								if (59 >= b)
																								{
																									goto IL_2135;
																								}
																								goto IL_249a;
																								IL_2135:
																								if (59 <= b)
																								{
																									goto IL_2140;
																								}
																								goto IL_21af;
																								IL_2140:
																								array2[num6 - 1] = 3;
																								goto IL_2154;
																								IL_2154:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 240;
																								goto IL_219c;
																								IL_219c:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_21af:
																								if (55 >= b)
																								{
																									goto IL_21bd;
																								}
																								goto IL_233e;
																								IL_21bd:
																								if (55 <= b)
																								{
																									goto IL_21c8;
																								}
																								goto IL_220b;
																								IL_21c8:
																								*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((GorillaPlayerScoreboardLine[])array3[num6 - 1]).LongLength;
																								goto IL_21f2;
																								IL_21f2:
																								array2[num6 - 1] = 2;
																								goto end_IL_09e9;
																								IL_220b:
																								if (53 < b)
																								{
																									goto IL_2216;
																								}
																								goto IL_2279;
																								IL_2216:
																								if (54 < b)
																								{
																									break;
																								}
																								goto IL_2224;
																								IL_2224:
																								if (54 > b)
																								{
																									break;
																								}
																								goto IL_2232;
																								IL_2232:
																								array2[num6] = 5;
																								goto IL_2240;
																								IL_2240:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_2258;
																								IL_2258:
																								num6++;
																								goto IL_2266;
																								IL_2266:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_2279:
																								if (53 <= b)
																								{
																									goto IL_2284;
																								}
																								goto IL_22c3;
																								IL_2284:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_22a2;
																								IL_22a2:
																								ptr2 += 8;
																								goto IL_22b0;
																								IL_22b0:
																								num6--;
																								goto end_IL_09e9;
																								IL_22c3:
																								if (52 < b)
																								{
																									break;
																								}
																								goto IL_22d1;
																								IL_22d1:
																								if (52 > b)
																								{
																									break;
																								}
																								goto IL_22df;
																								IL_22df:
																								array2[num6 - 1] = 5;
																								goto IL_22f3;
																								IL_22f3:
																								array3[num6 - 1] = ((delegate*<IEnumerable<GorillaPlayerScoreboardLine>, GorillaPlayerScoreboardLine[]>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((IEnumerable<GorillaPlayerScoreboardLine>)array3[num6 - 1]);
																								goto IL_232b;
																								IL_232b:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_233e:
																								if (57 < b)
																								{
																									goto IL_2349;
																								}
																								goto IL_23ad;
																								IL_2349:
																								if (58 < b)
																								{
																									break;
																								}
																								goto IL_2357;
																								IL_2357:
																								if (58 > b)
																								{
																									break;
																								}
																								goto IL_2365;
																								IL_2365:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																								goto IL_237e;
																								IL_237e:
																								array2[num6] = 3;
																								goto IL_238c;
																								IL_238c:
																								num6++;
																								goto IL_239a;
																								IL_239a:
																								ptr2 += 16;
																								goto end_IL_09e9;
																								IL_23ad:
																								if (57 <= b)
																								{
																									goto IL_23b8;
																								}
																								goto IL_2418;
																								IL_23b8:
																								array3[num6 - 2] = ((GorillaPlayerScoreboardLine[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_23f1;
																								IL_23f1:
																								array2[num6 - 2] = 5;
																								goto IL_2405;
																								IL_2405:
																								num6--;
																								goto end_IL_09e9;
																								IL_2418:
																								if (56 < b)
																								{
																									break;
																								}
																								goto IL_2426;
																								IL_2426:
																								if (56 > b)
																								{
																									break;
																								}
																								goto IL_2434;
																								IL_2434:
																								ptr2 = ((*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == (IntPtr)0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_2487;
																								IL_2487:
																								num6--;
																								goto end_IL_09e9;
																								IL_249a:
																								if (63 >= b)
																								{
																									goto IL_24a8;
																								}
																								goto IL_26b9;
																								IL_24a8:
																								if (63 <= b)
																								{
																									goto IL_24b3;
																								}
																								goto IL_2512;
																								IL_24b3:
																								array3[num6 - 1] = ((delegate*<GorillaPlayerScoreboardLine, GorillaPlayerLineButton>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine)array3[num6 - 1]);
																								goto IL_24eb;
																								IL_24eb:
																								array2[num6 - 1] = 5;
																								goto IL_24ff;
																								IL_24ff:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_2512:
																								if (61 >= b)
																								{
																									goto IL_2520;
																								}
																								goto IL_2629;
																								IL_2520:
																								if (61 > b)
																								{
																									goto IL_252e;
																								}
																								num = 306;
																								goto IL_25c3;
																								IL_252e:
																								if (60 < b)
																								{
																									break;
																								}
																								goto IL_253c;
																								IL_253c:
																								if (60 > b)
																								{
																									break;
																								}
																								goto IL_254a;
																								IL_254a:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_258a;
																								IL_258a:
																								array2[num6 - 2] = 3;
																								goto IL_259e;
																								IL_259e:
																								num6--;
																								num = 242;
																								goto end_IL_09e9;
																								IL_27d9:
																								if (67 < b)
																								{
																									break;
																								}
																								goto IL_27e4;
																								IL_25c3:
																								array2[num6 - 1] = 0;
																								goto IL_25d7;
																								IL_25d7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_2616;
																								IL_2616:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_2629:
																								if (62 < b)
																								{
																									break;
																								}
																								goto IL_2637;
																								IL_2637:
																								if (62 > b)
																								{
																									break;
																								}
																								goto IL_2645;
																								IL_2645:
																								((delegate*<GorillaPlayerScoreboardLine, bool, GorillaPlayerLineButton.ButtonType, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine)array3[num6 - 3], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, *(GorillaPlayerLineButton.ButtonType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_2698;
																								IL_2698:
																								num6 -= 3;
																								goto IL_26a6;
																								IL_26a6:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_26b9:
																								if (65 >= b)
																								{
																									goto IL_26c7;
																								}
																								goto IL_2779;
																								IL_26c7:
																								if (65 <= b)
																								{
																									goto IL_26d2;
																								}
																								goto IL_271c;
																								IL_26d2:
																								((delegate*<GorillaPlayerLineButton, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerLineButton)array3[num6 - 1]);
																								goto IL_26fb;
																								IL_26fb:
																								num6--;
																								goto IL_2709;
																								IL_2709:
																								ptr2 += 8;
																								goto end_IL_09e9;
																								IL_271c:
																								if (64 < b)
																								{
																									break;
																								}
																								goto IL_272a;
																								IL_272a:
																								if (64 > b)
																								{
																									break;
																								}
																								goto IL_2738;
																								IL_2738:
																								((GorillaPlayerLineButton)array3[num6 - 2]).isOn = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																								goto IL_2766;
																								IL_2766:
																								num6 -= 2;
																								goto end_IL_09e9;
																								IL_2779:
																								if (66 >= b)
																								{
																									goto IL_2784;
																								}
																								goto IL_27d9;
																								IL_2784:
																								if (66 > b)
																								{
																									break;
																								}
																								num = 221;
																								goto IL_2798;
																								IL_27e4:
																								if (67 <= b)
																								{
																								}
																								break;
																							}
																							break;
																							IL_09d9:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					continue;
																					end_IL_09e9:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_2802:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0e2e:
			while (true)
			{
				IL_0e2e_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0ed6_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0ee4_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_0a1d_2:
									num = 405;
									while (true)
									{
										IL_0a12_2:
										byte b = *ptr2;
										while (true)
										{
											IL_09f9_2:
											ptr2++;
											num = 67;
											while (true)
											{
												IL_09e9_2:
												if (b >= 1)
												{
													while (b <= 67)
													{
														while (true)
														{
															IL_09c9_2:
															if (34 >= b)
															{
																while (true)
																{
																	IL_09b9_2:
																	if (34 > b)
																	{
																		while (true)
																		{
																			IL_09a9_2:
																			if (17 >= b)
																			{
																				while (true)
																				{
																					IL_0999_2:
																					if (17 > b)
																					{
																						while (true)
																						{
																							IL_0989_2:
																							if (8 >= b)
																							{
																								while (true)
																								{
																									IL_0979_2:
																									if (8 > b)
																									{
																										while (true)
																										{
																											IL_0969_2:
																											if (4 < b)
																											{
																												while (true)
																												{
																													IL_0959_2:
																													if (6 < b)
																													{
																														while (7 >= b)
																														{
																															while (7 <= b)
																															{
																																while (true)
																																{
																																	IL_08ee_2:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	num = 563;
																																	while (true)
																																	{
																																		if (num != 563)
																																		{
																																			if (num != 1544)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 323:
																																			case 536:
																																				goto IL_08ee_2;
																																			case 490:
																																				goto IL_0939_2;
																																			case 466:
																																				goto IL_0949_2;
																																			case 151:
																																				goto IL_0959_2;
																																			case 72:
																																				goto IL_0969_2;
																																			case 11:
																																				goto IL_0979_2;
																																			case 479:
																																				goto IL_0989_2;
																																			case 491:
																																				goto IL_0999_2;
																																			case 111:
																																				goto IL_09a9_2;
																																			case 369:
																																				goto IL_09b9_2;
																																			case 143:
																																				goto IL_09c9_2;
																																			case 146:
																																				goto IL_09d9_2;
																																			case 67:
																																				goto IL_09e9_2;
																																			case 286:
																																				goto IL_09f9_2;
																																			case 405:
																																				goto IL_0a12_2;
																																			case 424:
																																				goto IL_0a1d_2;
																																			case 135:
																																				goto IL_0a28_2;
																																			case 18:
																																				goto IL_0a33_2;
																																			case 99:
																																			case 248:
																																				goto IL_0a46_2;
																																			case 304:
																																			case 355:
																																				goto IL_0a86_2;
																																			case 309:
																																			case 360:
																																				goto IL_0a99_2;
																																			case 103:
																																			case 363:
																																				goto IL_0aac_2;
																																			case 416:
																																				goto IL_0af6_2;
																																			case 460:
																																				goto IL_0b09_2;
																																			case 484:
																																				goto IL_0b19_2;
																																			case 493:
																																				goto IL_0b2c_2;
																																			case 228:
																																			case 436:
																																				goto IL_0b3a_2;
																																			case 212:
																																				goto IL_0b63_2;
																																			case 64:
																																				goto IL_0b71_2;
																																			case 504:
																																				goto IL_0b84_2;
																																			case 121:
																																			case 377:
																																				goto IL_0b98_2;
																																			case 489:
																																				goto IL_0bd8_2;
																																			case 207:
																																				goto IL_0bf5_2;
																																			case 548:
																																				goto IL_0c08_2;
																																			case 210:
																																				goto IL_0c16_2;
																																			case 441:
																																			case 459:
																																				goto IL_0c2d_2;
																																			case 185:
																																				goto IL_0c46_2;
																																			case 468:
																																				goto IL_0c54_2;
																																			case 518:
																																				goto IL_0c62_2;
																																			case 554:
																																				goto IL_0c75_2;
																																			case 497:
																																				goto IL_0c98_2;
																																			case 334:
																																				goto IL_0ca2_2;
																																			case 138:
																																				goto IL_0cb9_2;
																																			case 485:
																																				goto IL_0ce0_2;
																																			case 388:
																																				goto IL_0cfc_2;
																																			case 98:
																																			case 256:
																																				goto IL_0d07_2;
																																			case 105:
																																				goto IL_0d47_2;
																																			case 387:
																																				goto IL_0d5b_2;
																																			case 455:
																																				goto IL_0d6e_2;
																																			case 446:
																																				goto IL_0d7c_2;
																																			case 142:
																																			case 291:
																																				goto IL_0d8a_2;
																																			case 87:
																																				goto IL_0dd3_2;
																																			case 408:
																																				goto IL_0de7_2;
																																			case 432:
																																				goto IL_0e03_2;
																																			case 382:
																																				goto IL_0e11_2;
																																			case 239:
																																			case 483:
																																				goto end_IL_2802_2;
																																			case 150:
																																				goto IL_0ed6_2;
																																			case 555:
																																				goto IL_0ee4_2;
																																			case 84:
																																				goto IL_0ef7_2;
																																			case 294:
																																				goto IL_0f05_2;
																																			case 267:
																																			case 333:
																																				goto IL_0f10_2;
																																			case 454:
																																				goto IL_0f72_2;
																																			case 246:
																																				goto IL_0f85_2;
																																			case 553:
																																				goto IL_0f93_2;
																																			case 122:
																																			case 407:
																																				goto IL_0fa1_2;
																																			case 373:
																																				goto IL_0fe1_2;
																																			case 77:
																																				goto IL_0ff5_2;
																																			case 389:
																																				goto IL_1008_2;
																																			case 398:
																																				goto IL_1016_2;
																																			case 231:
																																				goto IL_1029_2;
																																			case 237:
																																				goto IL_1037_2;
																																			case 36:
																																				goto IL_1042_2;
																																			case 136:
																																				goto IL_1050_2;
																																			case 183:
																																			case 495:
																																				goto IL_105e_2;
																																			case 91:
																																				goto IL_107c_2;
																																			case 319:
																																				goto IL_108a_2;
																																			case 5:
																																			case 66:
																																				goto IL_109d_2;
																																			case 335:
																																				goto IL_10c6_2;
																																			case 517:
																																				goto IL_10df_2;
																																			case 396:
																																				goto IL_10ed_2;
																																			case 4:
																																			case 287:
																																				goto IL_10fb_2;
																																			case 116:
																																				goto IL_1113_2;
																																			case 80:
																																				goto IL_1131_2;
																																			case 537:
																																				goto IL_1155_2;
																																			case 356:
																																				goto IL_116d_2;
																																			case 392:
																																				goto IL_1180_2;
																																			case 204:
																																				goto IL_118e_2;
																																			case 133:
																																			case 453:
																																				goto IL_119c_2;
																																			case 448:
																																				goto IL_11aa_2;
																																			case 522:
																																				goto IL_11c2_2;
																																			case 198:
																																				goto IL_11d0_2;
																																			case 362:
																																				goto IL_11e3_2;
																																			case 279:
																																				goto IL_11f1_2;
																																			case 97:
																																			case 208:
																																				goto IL_11fc_2;
																																			case 194:
																																				goto IL_1216_2;
																																			case 114:
																																				goto IL_1224_2;
																																			case 12:
																																				goto IL_1232_2;
																																			case 14:
																																				goto IL_124e_2;
																																			case 260:
																																				goto IL_125c_2;
																																			case 196:
																																			case 475:
																																				goto IL_1267_2;
																																			case 352:
																																				goto IL_127e_2;
																																			case 508:
																																				goto IL_12ab_2;
																																			case 480:
																																				goto IL_12c2_2;
																																			case 403:
																																				goto IL_12d5_2;
																																			case 545:
																																				goto IL_12ec_2;
																																			case 110:
																																			case 381:
																																				goto IL_12f7_2;
																																			case 289:
																																				goto IL_1310_2;
																																			case 73:
																																				goto IL_1327_2;
																																			case 81:
																																				goto IL_1335_2;
																																			case 269:
																																				goto IL_1348_2;
																																			case 399:
																																				goto IL_1356_2;
																																			case 6:
																																			case 552:
																																				goto IL_1364_2;
																																			case 447:
																																				goto IL_1378_2;
																																			case 255:
																																				goto IL_13b0_2;
																																			case 507:
																																				goto IL_13c3_2;
																																			case 144:
																																				goto IL_13d1_2;
																																			case 390:
																																			case 410:
																																				goto IL_13e8_2;
																																			case 541:
																																				goto IL_1400_2;
																																			case 86:
																																				goto IL_140e_2;
																																			case 37:
																																				goto IL_141c_2;
																																			case 90:
																																				goto IL_142a_2;
																																			case 2:
																																			case 295:
																																				goto IL_1438_2;
																																			case 250:
																																				goto IL_1496_2;
																																			case 160:
																																			case 166:
																																				goto IL_14b2_2;
																																			case 238:
																																				goto IL_14db_2;
																																			case 393:
																																				goto IL_14e9_2;
																																			case 543:
																																				goto IL_14fc_2;
																																			case 314:
																																				goto IL_150a_2;
																																			case 186:
																																			case 380:
																																				goto IL_1518_2;
																																			case 521:
																																				goto IL_1534_2;
																																			case 402:
																																				goto IL_1542_2;
																																			case 285:
																																				goto IL_1550_2;
																																			case 112:
																																				goto IL_155e_2;
																																			case 268:
																																			case 462:
																																				goto IL_1569_2;
																																			case 277:
																																				goto IL_1591_2;
																																			case 123:
																																				goto IL_159f_2;
																																			case 129:
																																				goto IL_15b2_2;
																																			case 140:
																																				goto IL_15c0_2;
																																			case 56:
																																			case 226:
																																				goto IL_15ce_2;
																																			case 31:
																																				goto IL_15e2_2;
																																			case 127:
																																				goto IL_1673_2;
																																			case 452:
																																				goto IL_1681_2;
																																			case 95:
																																				goto IL_1694_2;
																																			case 330:
																																				goto IL_16a2_2;
																																			case 385:
																																			case 492:
																																				goto IL_16b0_2;
																																			case 337:
																																				goto IL_16be_2;
																																			case 32:
																																				goto IL_16e0_2;
																																			case 425:
																																				goto IL_16ee_2;
																																			case 300:
																																			case 529:
																																				goto IL_1701_2;
																																			case 232:
																																				goto IL_1748_2;
																																			case 225:
																																				goto IL_175c_2;
																																			case 343:
																																				goto IL_176f_2;
																																			case 514:
																																				goto IL_177d_2;
																																			case 182:
																																			case 303:
																																				goto IL_1791_2;
																																			case 89:
																																				goto IL_17e3_2;
																																			case 214:
																																				goto IL_17f6_2;
																																			case 222:
																																				goto IL_1804_2;
																																			case 234:
																																			case 358:
																																				goto IL_1812_2;
																																			case 519:
																																				goto IL_1850_2;
																																			case 417:
																																				goto IL_1864_2;
																																			case 74:
																																				goto IL_1877_2;
																																			case 157:
																																				goto IL_1882_2;
																																			case 118:
																																			case 219:
																																				goto IL_1890_2;
																																			case 265:
																																				goto IL_18ce_2;
																																			case 354:
																																				goto IL_18e2_2;
																																			case 125:
																																				goto IL_18f5_2;
																																			case 297:
																																				goto IL_1903_2;
																																			case 141:
																																			case 147:
																																				goto IL_1911_2;
																																			case 165:
																																				goto IL_1949_2;
																																			case 130:
																																				goto IL_195d_2;
																																			case 520:
																																				goto IL_1970_2;
																																			case 29:
																																				goto IL_197e_2;
																																			case 59:
																																			case 341:
																																				goto IL_198c_2;
																																			case 443:
																																				goto IL_19a0_2;
																																			case 45:
																																				goto IL_19ec_2;
																																			case 271:
																																				goto IL_19fa_2;
																																			case 264:
																																				goto IL_1a0d_2;
																																			case 153:
																																				goto IL_1a1b_2;
																																			case 3:
																																				goto IL_1a29_2;
																																			case 46:
																																				goto IL_1a37_2;
																																			case 472:
																																				goto IL_1a42_2;
																																			case 270:
																																			case 336:
																																				goto IL_1a50_2;
																																			case 534:
																																				goto IL_1a65_2;
																																			case 365:
																																				goto IL_1a73_2;
																																			case 251:
																																				goto IL_1a86_2;
																																			case 282:
																																				goto IL_1a94_2;
																																			case 367:
																																			case 477:
																																				goto IL_1aa2_2;
																																			case 243:
																																				goto IL_1ab6_2;
																																			case 65:
																																				goto IL_1b03_2;
																																			case 44:
																																				goto IL_1b11_2;
																																			case 217:
																																				goto IL_1b2d_2;
																																			case 26:
																																				goto IL_1b3b_2;
																																			case 128:
																																				goto IL_1b49_2;
																																			case 10:
																																			case 102:
																																				goto IL_1b57_2;
																																			case 281:
																																				goto IL_1bab_2;
																																			case 106:
																																			case 353:
																																				goto IL_1bbe_2;
																																			case 418:
																																				goto IL_1bd5_2;
																																			case 203:
																																				goto IL_1bf3_2;
																																			case 322:
																																				goto IL_1c01_2;
																																			case 486:
																																				goto IL_1c14_2;
																																			case 48:
																																				goto IL_1c22_2;
																																			case 376:
																																				goto IL_1c30_2;
																																			case 68:
																																				goto IL_1c3e_2;
																																			case 311:
																																				goto IL_1c4c_2;
																																			case 34:
																																			case 218:
																																				goto IL_1c5a_2;
																																			case 481:
																																				goto IL_1c6e_2;
																																			case 20:
																																				goto IL_1cac_2;
																																			case 364:
																																			case 370:
																																				goto IL_1cbf_2;
																																			case 115:
																																				goto IL_1cd3_2;
																																			case 88:
																																				goto IL_1d20_2;
																																			case 296:
																																				goto IL_1d2e_2;
																																			case 79:
																																				goto IL_1d4a_2;
																																			case 273:
																																				goto IL_1d58_2;
																																			case 189:
																																			case 467:
																																				goto IL_1d66_2;
																																			case 187:
																																				goto IL_1d93_2;
																																			case 181:
																																			case 525:
																																				goto IL_1da6_2;
																																			case 499:
																																				goto IL_1dde_2;
																																			case 544:
																																				goto IL_1df2_2;
																																			case 318:
																																				goto IL_1e05_2;
																																			case 359:
																																			case 540:
																																				goto IL_1e10_2;
																																			case 119:
																																				goto IL_1e1e_2;
																																			case 206:
																																				goto IL_1e36_2;
																																			case 193:
																																				goto IL_1e44_2;
																																			case 134:
																																				goto IL_1e57_2;
																																			case 108:
																																				goto IL_1e65_2;
																																			case 161:
																																			case 428:
																																				goto IL_1e70_2;
																																			case 397:
																																				goto IL_1e8e_2;
																																			case 24:
																																				goto IL_1e9c_2;
																																			case 423:
																																				goto IL_1eaf_2;
																																			case 509:
																																				goto IL_1ebd_2;
																																			case 0:
																																			case 158:
																																				goto IL_1ec8_2;
																																			case 33:
																																				goto IL_1ee6_2;
																																			case 375:
																																				goto IL_1ef4_2;
																																			case 549:
																																				goto IL_1f10_2;
																																			case 63:
																																				goto IL_1f1e_2;
																																			case 235:
																																			case 293:
																																				goto IL_1f2c_2;
																																			case 321:
																																				goto IL_1f3a_2;
																																			case 167:
																																				goto IL_1f58_2;
																																			case 325:
																																				goto IL_1f66_2;
																																			case 326:
																																				goto IL_1f79_2;
																																			case 252:
																																				goto IL_1f87_2;
																																			case 139:
																																			case 384:
																																				goto IL_1f95_2;
																																			case 307:
																																				goto IL_1fa3_2;
																																			case 437:
																																				goto IL_1fc1_2;
																																			case 506:
																																				goto IL_1fcf_2;
																																			case 236:
																																				goto IL_1fe2_2;
																																			case 41:
																																				goto IL_1ff0_2;
																																			case 55:
																																			case 233:
																																				goto IL_1ffb_2;
																																			case 515:
																																				goto IL_2005_2;
																																			case 15:
																																				goto IL_2013_2;
																																			case 346:
																																				goto IL_2026_2;
																																			case 457:
																																				goto IL_2034_2;
																																			case 60:
																																			case 278:
																																				goto IL_2042_2;
																																			case 482:
																																				goto IL_2050_2;
																																			case 449:
																																				goto IL_2068_2;
																																			case 328:
																																				goto IL_2076_2;
																																			case 310:
																																				goto IL_2089_2;
																																			case 461:
																																				goto IL_2097_2;
																																			case 54:
																																			case 57:
																																				goto IL_20a5_2;
																																			case 488:
																																				goto IL_20b9_2;
																																			case 61:
																																				goto IL_2106_2;
																																			case 224:
																																				goto IL_2114_2;
																																			case 132:
																																				goto IL_2127_2;
																																			case 171:
																																				goto IL_2135_2;
																																			case 431:
																																			case 528:
																																				goto IL_2140_2;
																																			case 445:
																																				goto IL_2154_2;
																																			case 240:
																																				goto IL_219c_2;
																																			case 83:
																																				goto IL_21af_2;
																																			case 254:
																																				goto IL_21bd_2;
																																			case 257:
																																			case 546:
																																				goto IL_21c8_2;
																																			case 374:
																																				goto IL_21f2_2;
																																			case 316:
																																				goto IL_220b_2;
																																			case 75:
																																				goto IL_2216_2;
																																			case 420:
																																				goto IL_2224_2;
																																			case 137:
																																			case 361:
																																				goto IL_2232_2;
																																			case 25:
																																				goto IL_2240_2;
																																			case 527:
																																				goto IL_2258_2;
																																			case 487:
																																				goto IL_2266_2;
																																			case 427:
																																				goto IL_2279_2;
																																			case 152:
																																			case 327:
																																				goto IL_2284_2;
																																			case 107:
																																				goto IL_22a2_2;
																																			case 406:
																																				goto IL_22b0_2;
																																			case 458:
																																				goto IL_22c3_2;
																																			case 501:
																																				goto IL_22d1_2;
																																			case 262:
																																			case 451:
																																				goto IL_22df_2;
																																			case 317:
																																				goto IL_22f3_2;
																																			case 498:
																																				goto IL_232b_2;
																																			case 100:
																																				goto IL_233e_2;
																																			case 19:
																																				goto IL_2349_2;
																																			case 542:
																																				goto IL_2357_2;
																																			case 17:
																																			case 438:
																																				goto IL_2365_2;
																																			case 419:
																																				goto IL_237e_2;
																																			case 357:
																																				goto IL_238c_2;
																																			case 371:
																																				goto IL_239a_2;
																																			case 538:
																																				goto IL_23ad_2;
																																			case 258:
																																			case 422:
																																				goto IL_23b8_2;
																																			case 223:
																																				goto IL_23f1_2;
																																			case 324:
																																				goto IL_2405_2;
																																			case 308:
																																				goto IL_2418_2;
																																			case 205:
																																				goto IL_2426_2;
																																			case 173:
																																			case 192:
																																				goto IL_2434_2;
																																			case 550:
																																				goto IL_2487_2;
																																			case 456:
																																				goto IL_249a_2;
																																			case 201:
																																				goto IL_24a8_2;
																																			case 280:
																																			case 494:
																																				goto IL_24b3_2;
																																			case 21:
																																				goto IL_24eb_2;
																																			case 176:
																																				goto IL_24ff_2;
																																			case 263:
																																				goto IL_2512_2;
																																			case 476:
																																				goto IL_2520_2;
																																			case 339:
																																				goto IL_252e_2;
																																			case 429:
																																				goto IL_253c_2;
																																			case 47:
																																			case 434:
																																				goto IL_254a_2;
																																			case 344:
																																				goto IL_258a_2;
																																			case 530:
																																				goto IL_259e_2;
																																			case 101:
																																			case 306:
																																				goto IL_25c3_2;
																																			case 76:
																																				goto IL_25d7_2;
																																			case 409:
																																				goto IL_2616_2;
																																			case 200:
																																				goto IL_2629_2;
																																			case 215:
																																				goto IL_2637_2;
																																			case 104:
																																			case 349:
																																				goto IL_2645_2;
																																			case 366:
																																				goto IL_2698_2;
																																			case 145:
																																				goto IL_26a6_2;
																																			case 156:
																																				goto IL_26b9_2;
																																			case 386:
																																				goto IL_26c7_2;
																																			case 188:
																																			case 414:
																																				goto IL_26d2_2;
																																			case 49:
																																				goto IL_26fb_2;
																																			case 338:
																																				goto IL_2709_2;
																																			case 124:
																																				goto IL_271c_2;
																																			case 163:
																																				goto IL_272a_2;
																																			case 312:
																																			case 503:
																																				goto IL_2738_2;
																																			case 40:
																																				goto IL_2766_2;
																																			case 191:
																																				goto IL_2779_2;
																																			case 168:
																																				goto IL_2784_2;
																																			case 164:
																																			case 221:
																																				goto IL_2798_2;
																																			case 400:
																																				goto IL_27c3_2;
																																			case 372:
																																				goto IL_27d9_2;
																																			case 69:
																																				goto IL_27e4_2;
																																			case 8:
																																			case 22:
																																			case 23:
																																			case 30:
																																			case 35:
																																			case 38:
																																			case 51:
																																			case 53:
																																			case 62:
																																			case 71:
																																			case 82:
																																			case 96:
																																			case 113:
																																			case 120:
																																			case 126:
																																			case 131:
																																			case 148:
																																			case 154:
																																			case 169:
																																			case 172:
																																			case 174:
																																			case 184:
																																			case 190:
																																			case 202:
																																			case 209:
																																			case 213:
																																			case 244:
																																			case 249:
																																			case 261:
																																			case 266:
																																			case 272:
																																			case 274:
																																			case 275:
																																			case 283:
																																			case 292:
																																			case 298:
																																			case 301:
																																			case 302:
																																			case 313:
																																			case 315:
																																			case 331:
																																			case 332:
																																			case 345:
																																			case 347:
																																			case 348:
																																			case 350:
																																			case 391:
																																			case 395:
																																			case 404:
																																			case 433:
																																			case 435:
																																			case 439:
																																			case 440:
																																			case 444:
																																			case 450:
																																			case 463:
																																			case 465:
																																			case 470:
																																			case 474:
																																			case 478:
																																			case 496:
																																			case 505:
																																			case 510:
																																			case 511:
																																			case 513:
																																			case 516:
																																			case 524:
																																			case 539:
																																			case 547:
																																			case 551:
																																				goto end_IL_0939_2;
																																			case 1:
																																			case 7:
																																			case 9:
																																			case 13:
																																			case 16:
																																			case 27:
																																			case 28:
																																			case 39:
																																			case 43:
																																			case 52:
																																			case 58:
																																			case 70:
																																			case 78:
																																			case 85:
																																			case 92:
																																			case 109:
																																			case 149:
																																			case 155:
																																			case 159:
																																			case 162:
																																			case 170:
																																			case 177:
																																			case 178:
																																			case 179:
																																			case 180:
																																			case 195:
																																			case 197:
																																			case 211:
																																			case 216:
																																			case 220:
																																			case 227:
																																			case 230:
																																			case 241:
																																			case 242:
																																			case 245:
																																			case 253:
																																			case 259:
																																			case 276:
																																			case 284:
																																			case 288:
																																			case 290:
																																			case 299:
																																			case 305:
																																			case 320:
																																			case 329:
																																			case 340:
																																			case 342:
																																			case 351:
																																			case 368:
																																			case 379:
																																			case 383:
																																			case 412:
																																			case 413:
																																			case 415:
																																			case 421:
																																			case 426:
																																			case 430:
																																			case 442:
																																			case 464:
																																			case 469:
																																			case 471:
																																			case 500:
																																			case 512:
																																			case 523:
																																			case 526:
																																			case 531:
																																			case 532:
																																			case 533:
																																			case 535:
																																			case 556:
																																				goto end_IL_08db_2;
																																			case 42:
																																				ptr2 = ptr;
																																				goto end_IL_08db_2;
																																			case 247:
																																				ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TrySetCanceledgetIsFullTypeNameSetExplicit.ProxyAttributewIDLFlags);
																																				goto case 42;
																																			case 199:
																																				array7[0] = MutexAccessRuleCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGVISIBLE;
																																				goto case 247;
																																			case 394:
																																				array7 = new object[14];
																																				goto case 199;
																																			case 473:
																																				array6 = new long[5];
																																				goto case 394;
																																			case 175:
																																				array5 = new int[7];
																																				goto case 473;
																																			case 378:
																																				array4 = new int[5];
																																				goto case 175;
																																			case 411:
																																				array3 = new object[5];
																																				goto case 378;
																																			case 229:
																																				array2 = new byte[5];
																																				goto case 411;
																																			case 502:
																																				num4 = num2 * 8;
																																				goto case 229;
																																			case 401:
																																				num3 = num2 * 4;
																																				goto case 502;
																																			case 93:
																																				num2 = 1;
																																				goto case 401;
																																			case 94:
																																				goto end_IL_0e3c;
																																			case 50:
																																			case 117:
																																				return;
																																			}
																																			continue;
																																		}
																																		array2[num6 - 2] = 0;
																																		goto IL_0ce0_2;
																																		IL_0ce0_2:
																																		num6--;
																																		num = 70;
																																		break;
																																		continue;
																																		end_IL_08db_2:
																																		break;
																																	}
																																	break;
																																}
																																goto end_IL_09e9_2;
																																continue;
																																end_IL_0939_2:
																																break;
																																IL_0939_2:;
																															}
																															break;
																															IL_0949_2:;
																														}
																														break;
																													}
																													goto IL_0cfc_2;
																													IL_0de7_2:
																													num6--;
																													num = 500;
																													goto end_IL_09e9_2;
																													IL_0cfc_2:
																													if (6 <= b)
																													{
																														goto IL_0d07_2;
																													}
																													goto IL_0d6e_2;
																													IL_0d07_2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0d47_2;
																													IL_0d47_2:
																													array2[num6 - 2] = 0;
																													goto IL_0d5b_2;
																													IL_0d5b_2:
																													num6--;
																													goto end_IL_09e9_2;
																													IL_0d6e_2:
																													if (5 < b)
																													{
																														break;
																													}
																													goto IL_0d7c_2;
																													IL_0d7c_2:
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_0d8a_2;
																													IL_0d8a_2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													num = 87;
																													goto IL_0dd3_2;
																													IL_0dd3_2:
																													array2[num6 - 2] = 0;
																													goto IL_0de7_2;
																												}
																												break;
																											}
																											goto IL_0a28_2;
																											IL_0c98_2:
																											array3[num6] = null;
																											goto IL_0ca2_2;
																											IL_0a28_2:
																											if (4 > b)
																											{
																												goto IL_0a33_2;
																											}
																											goto IL_0a99_2;
																											IL_0a33_2:
																											if (2 < b)
																											{
																												goto IL_0b09_2;
																											}
																											goto IL_0b84_2;
																											IL_0b84_2:
																											if (2 <= b)
																											{
																												num = 377;
																												goto IL_0b98_2;
																											}
																											goto IL_0c08_2;
																											IL_0ca2_2:
																											num6++;
																											num = 138;
																											goto IL_0cb9_2;
																											IL_0b98_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0bd8_2;
																											IL_0bd8_2:
																											array2[num6 - 2] = 0;
																											num = 207;
																											goto IL_0bf5_2;
																											IL_0bf5_2:
																											num6--;
																											goto end_IL_09e9_2;
																											IL_0c08_2:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0c16_2;
																											IL_0c16_2:
																											if (1 > b)
																											{
																												break;
																											}
																											num = 459;
																											goto IL_0c2d_2;
																											IL_0cb9_2:
																											ptr2 += 8;
																											goto end_IL_09e9_2;
																											IL_0c2d_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											goto IL_0c46_2;
																											IL_0c46_2:
																											array2[num6] = 0;
																											goto IL_0c54_2;
																											IL_0c54_2:
																											num6++;
																											goto IL_0c62_2;
																											IL_0c62_2:
																											ptr2 += 8;
																											goto end_IL_09e9_2;
																											IL_0b09_2:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0b2c_2;
																											IL_0b2c_2:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_0b3a_2;
																											IL_0b3a_2:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0b63_2;
																											IL_0b63_2:
																											ptr2 += 8;
																											goto IL_0b71_2;
																											IL_0b71_2:
																											num6--;
																											goto end_IL_09e9_2;
																											IL_0a99_2:
																											array2[num6] = 0;
																											goto IL_0c75_2;
																											IL_0c75_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_0c98_2;
																										}
																										break;
																									}
																									goto IL_0a86_2;
																									IL_0a86_2:
																									num6--;
																									goto end_IL_09e9_2;
																								}
																								break;
																							}
																							goto IL_0e03_2;
																							IL_11d0_2:
																							ptr2 += 8;
																							goto end_IL_09e9_2;
																							IL_0e03_2:
																							if (12 >= b)
																							{
																								goto IL_0e11_2;
																							}
																							goto IL_1029_2;
																							IL_0e11_2:
																							if (12 <= b)
																							{
																								goto end_IL_2802_2;
																							}
																							goto IL_0ef7_2;
																							IL_0ef7_2:
																							if (10 >= b)
																							{
																								goto IL_0f05_2;
																							}
																							goto IL_1008_2;
																							IL_0f05_2:
																							if (10 <= b)
																							{
																								goto IL_0f10_2;
																							}
																							goto IL_0f85_2;
																							IL_0f10_2:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0f72_2;
																							IL_0f72_2:
																							num6 -= 2;
																							goto end_IL_09e9_2;
																							IL_0f85_2:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_0f93_2;
																							IL_0f93_2:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0fa1_2;
																							IL_0fa1_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0fe1_2;
																							IL_0fe1_2:
																							array2[num6 - 2] = 0;
																							goto IL_0ff5_2;
																							IL_0ff5_2:
																							num6--;
																							goto end_IL_09e9_2;
																							IL_1008_2:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_1016_2;
																							IL_1016_2:
																							if (11 > b)
																							{
																								break;
																							}
																							goto end_IL_09e9_2;
																							IL_1029_2:
																							if (14 >= b)
																							{
																								goto IL_1037_2;
																							}
																							goto IL_10df_2;
																							IL_1037_2:
																							if (14 > b)
																							{
																								goto IL_1042_2;
																							}
																							goto IL_109d_2;
																							IL_1042_2:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_1050_2;
																							IL_1050_2:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_105e_2;
																							IL_105e_2:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_107c_2;
																							IL_107c_2:
																							ptr2 += 8;
																							goto IL_108a_2;
																							IL_108a_2:
																							num6--;
																							goto end_IL_09e9_2;
																							IL_109d_2:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_10c6_2;
																							IL_10c6_2:
																							array2[num6 - 1] = 5;
																							goto end_IL_09e9_2;
																							IL_10df_2:
																							if (15 >= b)
																							{
																								goto IL_10ed_2;
																							}
																							goto IL_1180_2;
																							IL_10ed_2:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_10fb_2;
																							IL_10fb_2:
																							array2[num6] = array2[num6 - 1];
																							goto IL_1113_2;
																							IL_1113_2:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_1131_2;
																							IL_1131_2:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1155_2;
																							IL_1155_2:
																							array3[num6] = array3[num6 - 1];
																							goto IL_116d_2;
																							IL_116d_2:
																							num6++;
																							goto end_IL_09e9_2;
																							IL_1180_2:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_118e_2;
																							IL_118e_2:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_119c_2;
																							IL_119c_2:
																							array2[num6] = 5;
																							goto IL_11aa_2;
																							IL_11aa_2:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_11c2_2;
																							IL_11c2_2:
																							num6++;
																							goto IL_11d0_2;
																						}
																						break;
																					}
																					goto IL_0a46_2;
																					IL_0af6_2:
																					num6 -= 3;
																					goto end_IL_09e9_2;
																					IL_0a46_2:
																					((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																					goto IL_0af6_2;
																				}
																				break;
																			}
																			goto IL_11e3_2;
																			IL_18f5_2:
																			if (33 < b)
																			{
																				break;
																			}
																			goto IL_1903_2;
																			IL_11e3_2:
																			if (25 >= b)
																			{
																				goto IL_11f1_2;
																			}
																			goto IL_1534_2;
																			IL_11f1_2:
																			if (25 <= b)
																			{
																				goto IL_11fc_2;
																			}
																			goto IL_124e_2;
																			IL_11fc_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																			goto IL_1216_2;
																			IL_1216_2:
																			array2[num6] = 3;
																			goto IL_1224_2;
																			IL_1224_2:
																			num6++;
																			goto IL_1232_2;
																			IL_1232_2:
																			ptr2 += 8;
																			num = 464;
																			goto end_IL_09e9_2;
																			IL_124e_2:
																			if (21 >= b)
																			{
																				goto IL_125c_2;
																			}
																			goto IL_1400_2;
																			IL_125c_2:
																			if (21 <= b)
																			{
																				goto IL_1267_2;
																			}
																			goto IL_12d5_2;
																			IL_1267_2:
																			array2[num6] = 0;
																			num = 352;
																			goto IL_127e_2;
																			IL_127e_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])() ? 1 : 0);
																			num = 508;
																			goto IL_12ab_2;
																			IL_12ab_2:
																			num6++;
																			num = 480;
																			goto IL_12c2_2;
																			IL_12c2_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_12d5_2:
																			if (19 >= b)
																			{
																				num = 545;
																				goto IL_12ec_2;
																			}
																			goto IL_13c3_2;
																			IL_1903_2:
																			if (33 > b)
																			{
																				break;
																			}
																			goto IL_1911_2;
																			IL_12ec_2:
																			if (19 <= b)
																			{
																				goto IL_12f7_2;
																			}
																			goto IL_1348_2;
																			IL_12f7_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																			goto IL_1310_2;
																			IL_1310_2:
																			array2[num6] = 1;
																			num = 73;
																			goto IL_1327_2;
																			IL_1327_2:
																			num6++;
																			goto IL_1335_2;
																			IL_1335_2:
																			ptr2 += 16;
																			goto end_IL_09e9_2;
																			IL_1348_2:
																			if (18 < b)
																			{
																				break;
																			}
																			goto IL_1356_2;
																			IL_1356_2:
																			if (18 > b)
																			{
																				break;
																			}
																			goto IL_1364_2;
																			IL_1364_2:
																			array2[num6 - 1] = 5;
																			goto IL_1378_2;
																			IL_1378_2:
																			array3[num6 - 1] = ((delegate*<string[], string>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																			goto IL_13b0_2;
																			IL_13b0_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_13c3_2:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_13d1_2;
																			IL_13d1_2:
																			if (20 > b)
																			{
																				break;
																			}
																			num = 390;
																			goto IL_13e8_2;
																			IL_1911_2:
																			array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
																			goto IL_1949_2;
																			IL_13e8_2:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_09e9_2;
																			IL_1400_2:
																			if (23 >= b)
																			{
																				goto IL_140e_2;
																			}
																			goto IL_14fc_2;
																			IL_140e_2:
																			if (23 > b)
																			{
																				goto IL_141c_2;
																			}
																			num = 166;
																			goto IL_14b2_2;
																			IL_141c_2:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_142a_2;
																			IL_142a_2:
																			if (22 > b)
																			{
																				break;
																			}
																			goto IL_1438_2;
																			IL_1438_2:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_1496_2;
																			IL_1496_2:
																			num6--;
																			goto end_IL_09e9_2;
																			IL_1949_2:
																			array2[num6 - 1] = 5;
																			goto IL_195d_2;
																			IL_14b2_2:
																			((delegate*<string, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																			goto IL_14db_2;
																			IL_14db_2:
																			num6--;
																			goto IL_14e9_2;
																			IL_14e9_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_14fc_2:
																			if (24 < b)
																			{
																				break;
																			}
																			goto IL_150a_2;
																			IL_150a_2:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_1518_2;
																			IL_1518_2:
																			num10 = ptr2;
																			num11 = -200;
																			num5 = 1;
																			ptr2 = num10 + num11;
																			goto end_IL_09e9_2;
																			IL_1534_2:
																			if (29 >= b)
																			{
																				goto IL_1542_2;
																			}
																			goto IL_176f_2;
																			IL_1542_2:
																			if (29 > b)
																			{
																				goto IL_1550_2;
																			}
																			goto IL_1701_2;
																			IL_1550_2:
																			if (27 >= b)
																			{
																				goto IL_155e_2;
																			}
																			goto IL_1694_2;
																			IL_155e_2:
																			if (27 <= b)
																			{
																				goto IL_1569_2;
																			}
																			goto IL_15b2_2;
																			IL_1569_2:
																			array7[*(int*)(ptr2 + num3)] = (Class8.GunResult)array3[num6 - 1];
																			goto IL_1591_2;
																			IL_1591_2:
																			ptr2 += 8;
																			goto IL_159f_2;
																			IL_159f_2:
																			num6--;
																			goto end_IL_09e9_2;
																			IL_15b2_2:
																			if (26 < b)
																			{
																				break;
																			}
																			goto IL_15c0_2;
																			IL_15c0_2:
																			if (26 > b)
																			{
																				break;
																			}
																			goto IL_15ce_2;
																			IL_15ce_2:
																			array2[num6 - 5] = 4;
																			goto IL_15e2_2;
																			IL_15e2_2:
																			array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																			goto IL_1673_2;
																			IL_1673_2:
																			num6 -= 4;
																			goto IL_1681_2;
																			IL_1681_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_1694_2:
																			if (28 < b)
																			{
																				break;
																			}
																			goto IL_16a2_2;
																			IL_16a2_2:
																			if (28 > b)
																			{
																				break;
																			}
																			goto IL_16b0_2;
																			IL_16b0_2:
																			array2[num6] = 4;
																			goto IL_16be_2;
																			IL_16be_2:
																			array3[num6] = (Class8.GunResult)array7[*(int*)(ptr2 + num3)];
																			goto IL_16e0_2;
																			IL_16e0_2:
																			num6++;
																			goto IL_16ee_2;
																			IL_16ee_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_1701_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																			num = 232;
																			goto IL_1748_2;
																			IL_1748_2:
																			array2[num6 - 1] = 0;
																			goto IL_175c_2;
																			IL_175c_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_176f_2:
																			if (31 >= b)
																			{
																				goto IL_177d_2;
																			}
																			goto IL_1877_2;
																			IL_177d_2:
																			if (31 <= b)
																			{
																				num = 182;
																				goto IL_1791_2;
																			}
																			goto IL_17f6_2;
																			IL_195d_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_1791_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_17e3_2;
																			IL_17e3_2:
																			num6--;
																			goto end_IL_09e9_2;
																			IL_17f6_2:
																			if (30 < b)
																			{
																				break;
																			}
																			goto IL_1804_2;
																			IL_1804_2:
																			if (30 > b)
																			{
																				break;
																			}
																			goto IL_1812_2;
																			IL_1812_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																			goto IL_1850_2;
																			IL_1850_2:
																			array2[num6 - 1] = 0;
																			goto IL_1864_2;
																			IL_1864_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																			IL_1877_2:
																			if (32 >= b)
																			{
																				goto IL_1882_2;
																			}
																			goto IL_18f5_2;
																			IL_1882_2:
																			if (32 > b)
																			{
																				break;
																			}
																			goto IL_1890_2;
																			IL_1890_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																			goto IL_18ce_2;
																			IL_18ce_2:
																			array2[num6 - 1] = 0;
																			goto IL_18e2_2;
																			IL_18e2_2:
																			ptr2 += 8;
																			goto end_IL_09e9_2;
																		}
																		break;
																	}
																	goto IL_0aac_2;
																	IL_0b19_2:
																	num6--;
																	goto end_IL_09e9_2;
																	IL_0aac_2:
																	ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0b19_2;
																}
																break;
															}
															goto IL_1970_2;
															IL_2798_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_27c3_2;
															IL_1970_2:
															if (51 >= b)
															{
																goto IL_197e_2;
															}
															goto IL_2127_2;
															IL_197e_2:
															if (51 <= b)
															{
																goto IL_198c_2;
															}
															goto IL_1a0d_2;
															IL_198c_2:
															array2[num6 - 2] = 5;
															goto IL_19a0_2;
															IL_19a0_2:
															array3[num6 - 2] = ((delegate*<IEnumerable<GorillaPlayerScoreboardLine>, Func<GorillaPlayerScoreboardLine, bool>, IEnumerable<GorillaPlayerScoreboardLine>>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine[])array3[num6 - 2], (Func<GorillaPlayerScoreboardLine, bool>)array3[num6 - 1]);
															goto IL_19ec_2;
															IL_19ec_2:
															num6--;
															goto IL_19fa_2;
															IL_19fa_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1a0d_2:
															if (42 < b)
															{
																goto IL_1a1b_2;
															}
															goto IL_1e05_2;
															IL_1a1b_2:
															if (46 < b)
															{
																goto IL_1a29_2;
															}
															goto IL_1c14_2;
															IL_1a29_2:
															if (48 < b)
															{
																goto IL_1a37_2;
															}
															num = 217;
															goto IL_1b2d_2;
															IL_1a37_2:
															if (49 >= b)
															{
																goto IL_1a42_2;
															}
															goto IL_1a86_2;
															IL_1a42_2:
															if (49 > b)
															{
																break;
															}
															goto IL_1a50_2;
															IL_1a50_2:
															*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (void*)0;
															goto IL_1a65_2;
															IL_1a65_2:
															array2[num6] = 2;
															goto IL_1a73_2;
															IL_1a73_2:
															num6++;
															goto end_IL_09e9_2;
															IL_1a86_2:
															if (50 < b)
															{
																break;
															}
															goto IL_1a94_2;
															IL_1a94_2:
															if (50 > b)
															{
																break;
															}
															goto IL_1aa2_2;
															IL_1aa2_2:
															array2[num6 - 2] = 5;
															goto IL_1ab6_2;
															IL_1ab6_2:
															array3[num6 - 2] = ((delegate*<object, IntPtr, Func<GorillaPlayerScoreboardLine, bool>>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num6 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1b03_2;
															IL_1b03_2:
															num6--;
															goto IL_1b11_2;
															IL_1b11_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_27c3_2:
															array2[num6 - 1] = 0;
															goto end_IL_09e9_2;
															IL_1b2d_2:
															if (48 > b)
															{
																goto IL_1b3b_2;
															}
															goto IL_1bbe_2;
															IL_1b3b_2:
															if (47 < b)
															{
																break;
															}
															goto IL_1b49_2;
															IL_1b49_2:
															if (47 > b)
															{
																break;
															}
															goto IL_1b57_2;
															IL_1b57_2:
															ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_1bab_2;
															IL_1bab_2:
															num6--;
															goto end_IL_09e9_2;
															IL_1bbe_2:
															array2[num6] = 5;
															num = 418;
															goto IL_1bd5_2;
															IL_1bd5_2:
															array3[num6] = ((delegate*<GorillaPlayerScoreboardLine[]>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
															goto IL_1bf3_2;
															IL_1bf3_2:
															num6++;
															goto IL_1c01_2;
															IL_1c01_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1c14_2:
															if (46 > b)
															{
																goto IL_1c22_2;
															}
															goto IL_1da6_2;
															IL_1c22_2:
															if (44 >= b)
															{
																goto IL_1c30_2;
															}
															goto IL_1d4a_2;
															IL_1c30_2:
															if (44 > b)
															{
																goto IL_1c3e_2;
															}
															goto IL_1cbf_2;
															IL_1c3e_2:
															if (43 < b)
															{
																break;
															}
															goto IL_1c4c_2;
															IL_1c4c_2:
															if (43 > b)
															{
																break;
															}
															goto IL_1c5a_2;
															IL_1c5a_2:
															array2[num6 - 1] = 0;
															goto IL_1c6e_2;
															IL_1c6e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Player, int>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
															goto IL_1cac_2;
															IL_1cac_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1cbf_2:
															array2[num6 - 2] = 5;
															goto IL_1cd3_2;
															IL_1cd3_2:
															array3[num6 - 2] = ((delegate*<NetworkSystem, int, NetPlayer>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1d20_2;
															IL_1d20_2:
															num6--;
															goto IL_1d2e_2;
															IL_1d2e_2:
															ptr2 += 8;
															num = 178;
															goto end_IL_09e9_2;
															IL_1d4a_2:
															if (45 < b)
															{
																break;
															}
															goto IL_1d58_2;
															IL_1d58_2:
															if (45 > b)
															{
																break;
															}
															goto IL_1d66_2;
															IL_1d66_2:
															((_003C_003Ec__DisplayClass1_0)array3[num6 - 2]).netPlayer_0 = (NetPlayer)array3[num6 - 1];
															goto IL_1d93_2;
															IL_1d93_2:
															num6 -= 2;
															goto end_IL_09e9_2;
															IL_1da6_2:
															array3[num6 - 1] = ((delegate*<_003C_003Ec__DisplayClass1_0, NetPlayer>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((_003C_003Ec__DisplayClass1_0)array3[num6 - 1]);
															goto IL_1dde_2;
															IL_1dde_2:
															array2[num6 - 1] = 5;
															goto IL_1df2_2;
															IL_1df2_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1e05_2:
															if (42 <= b)
															{
																goto IL_1e10_2;
															}
															goto IL_1e57_2;
															IL_1e10_2:
															array2[num6] = 5;
															goto IL_1e1e_2;
															IL_1e1e_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_1e36_2;
															IL_1e36_2:
															num6++;
															goto IL_1e44_2;
															IL_1e44_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1e57_2:
															if (38 >= b)
															{
																goto IL_1e65_2;
															}
															goto IL_1fe2_2;
															IL_1e65_2:
															if (38 <= b)
															{
																goto IL_1e70_2;
															}
															goto IL_1eaf_2;
															IL_1e70_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_1e8e_2;
															IL_1e8e_2:
															ptr2 += 8;
															goto IL_1e9c_2;
															IL_1e9c_2:
															num6--;
															goto end_IL_09e9_2;
															IL_1eaf_2:
															if (36 >= b)
															{
																goto IL_1ebd_2;
															}
															goto IL_1f79_2;
															IL_1ebd_2:
															if (36 <= b)
															{
																goto IL_1ec8_2;
															}
															goto IL_1f10_2;
															IL_1ec8_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_1ee6_2;
															IL_1ee6_2:
															ptr2 += 8;
															goto IL_1ef4_2;
															IL_1ef4_2:
															num6--;
															num = 253;
															goto end_IL_09e9_2;
															IL_1f10_2:
															if (35 < b)
															{
																break;
															}
															goto IL_1f1e_2;
															IL_1f1e_2:
															if (35 > b)
															{
																break;
															}
															goto IL_1f2c_2;
															IL_1f2c_2:
															array2[num6] = 5;
															goto IL_1f3a_2;
															IL_1f3a_2:
															array3[num6] = ((delegate*<_003C_003Ec__DisplayClass1_0>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
															goto IL_1f58_2;
															IL_1f58_2:
															num6++;
															goto IL_1f66_2;
															IL_1f66_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1f79_2:
															if (37 < b)
															{
																break;
															}
															goto IL_1f87_2;
															IL_1f87_2:
															if (37 > b)
															{
																break;
															}
															goto IL_1f95_2;
															IL_1f95_2:
															array2[num6] = 5;
															goto IL_1fa3_2;
															IL_1fa3_2:
															array3[num6] = ((delegate*<NetworkSystem>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])();
															goto IL_1fc1_2;
															IL_1fc1_2:
															num6++;
															goto IL_1fcf_2;
															IL_1fcf_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_1fe2_2:
															if (40 >= b)
															{
																goto IL_1ff0_2;
															}
															goto IL_2089_2;
															IL_1ff0_2:
															if (40 <= b)
															{
																goto IL_1ffb_2;
															}
															goto IL_2026_2;
															IL_1ffb_2:
															array3[num6] = null;
															goto IL_2005_2;
															IL_2005_2:
															array2[num6] = 5;
															goto IL_2013_2;
															IL_2013_2:
															num6++;
															goto end_IL_09e9_2;
															IL_2026_2:
															if (39 < b)
															{
																break;
															}
															goto IL_2034_2;
															IL_2034_2:
															if (39 > b)
															{
																break;
															}
															goto IL_2042_2;
															IL_2042_2:
															array2[num6] = 5;
															goto IL_2050_2;
															IL_2050_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_2068_2;
															IL_2068_2:
															num6++;
															goto IL_2076_2;
															IL_2076_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_2089_2:
															if (41 < b)
															{
																break;
															}
															goto IL_2097_2;
															IL_2097_2:
															if (41 > b)
															{
																break;
															}
															goto IL_20a5_2;
															IL_20a5_2:
															array2[num6 - 2] = 0;
															goto IL_20b9_2;
															IL_20b9_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
															goto IL_2106_2;
															IL_2106_2:
															num6--;
															goto IL_2114_2;
															IL_2114_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_2127_2:
															if (59 >= b)
															{
																goto IL_2135_2;
															}
															goto IL_249a_2;
															IL_2135_2:
															if (59 <= b)
															{
																goto IL_2140_2;
															}
															goto IL_21af_2;
															IL_2140_2:
															array2[num6 - 1] = 3;
															goto IL_2154_2;
															IL_2154_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 240;
															goto IL_219c_2;
															IL_219c_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_21af_2:
															if (55 >= b)
															{
																goto IL_21bd_2;
															}
															goto IL_233e_2;
															IL_21bd_2:
															if (55 <= b)
															{
																goto IL_21c8_2;
															}
															goto IL_220b_2;
															IL_21c8_2:
															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((GorillaPlayerScoreboardLine[])array3[num6 - 1]).LongLength;
															goto IL_21f2_2;
															IL_21f2_2:
															array2[num6 - 1] = 2;
															goto end_IL_09e9_2;
															IL_220b_2:
															if (53 < b)
															{
																goto IL_2216_2;
															}
															goto IL_2279_2;
															IL_2216_2:
															if (54 < b)
															{
																break;
															}
															goto IL_2224_2;
															IL_2224_2:
															if (54 > b)
															{
																break;
															}
															goto IL_2232_2;
															IL_2232_2:
															array2[num6] = 5;
															goto IL_2240_2;
															IL_2240_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_2258_2;
															IL_2258_2:
															num6++;
															goto IL_2266_2;
															IL_2266_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_2279_2:
															if (53 <= b)
															{
																goto IL_2284_2;
															}
															goto IL_22c3_2;
															IL_2284_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_22a2_2;
															IL_22a2_2:
															ptr2 += 8;
															goto IL_22b0_2;
															IL_22b0_2:
															num6--;
															goto end_IL_09e9_2;
															IL_22c3_2:
															if (52 < b)
															{
																break;
															}
															goto IL_22d1_2;
															IL_22d1_2:
															if (52 > b)
															{
																break;
															}
															goto IL_22df_2;
															IL_22df_2:
															array2[num6 - 1] = 5;
															goto IL_22f3_2;
															IL_22f3_2:
															array3[num6 - 1] = ((delegate*<IEnumerable<GorillaPlayerScoreboardLine>, GorillaPlayerScoreboardLine[]>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((IEnumerable<GorillaPlayerScoreboardLine>)array3[num6 - 1]);
															goto IL_232b_2;
															IL_232b_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_233e_2:
															if (57 < b)
															{
																goto IL_2349_2;
															}
															goto IL_23ad_2;
															IL_2349_2:
															if (58 < b)
															{
																break;
															}
															goto IL_2357_2;
															IL_2357_2:
															if (58 > b)
															{
																break;
															}
															goto IL_2365_2;
															IL_2365_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															goto IL_237e_2;
															IL_237e_2:
															array2[num6] = 3;
															goto IL_238c_2;
															IL_238c_2:
															num6++;
															goto IL_239a_2;
															IL_239a_2:
															ptr2 += 16;
															goto end_IL_09e9_2;
															IL_23ad_2:
															if (57 <= b)
															{
																goto IL_23b8_2;
															}
															goto IL_2418_2;
															IL_23b8_2:
															array3[num6 - 2] = ((GorillaPlayerScoreboardLine[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_23f1_2;
															IL_23f1_2:
															array2[num6 - 2] = 5;
															goto IL_2405_2;
															IL_2405_2:
															num6--;
															goto end_IL_09e9_2;
															IL_2418_2:
															if (56 < b)
															{
																break;
															}
															goto IL_2426_2;
															IL_2426_2:
															if (56 > b)
															{
																break;
															}
															goto IL_2434_2;
															IL_2434_2:
															ptr2 = ((*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == (IntPtr)0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_2487_2;
															IL_2487_2:
															num6--;
															goto end_IL_09e9_2;
															IL_249a_2:
															if (63 >= b)
															{
																goto IL_24a8_2;
															}
															goto IL_26b9_2;
															IL_24a8_2:
															if (63 <= b)
															{
																goto IL_24b3_2;
															}
															goto IL_2512_2;
															IL_24b3_2:
															array3[num6 - 1] = ((delegate*<GorillaPlayerScoreboardLine, GorillaPlayerLineButton>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine)array3[num6 - 1]);
															goto IL_24eb_2;
															IL_24eb_2:
															array2[num6 - 1] = 5;
															goto IL_24ff_2;
															IL_24ff_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_2512_2:
															if (61 >= b)
															{
																goto IL_2520_2;
															}
															goto IL_2629_2;
															IL_2520_2:
															if (61 > b)
															{
																goto IL_252e_2;
															}
															num = 306;
															goto IL_25c3_2;
															IL_252e_2:
															if (60 < b)
															{
																break;
															}
															goto IL_253c_2;
															IL_253c_2:
															if (60 > b)
															{
																break;
															}
															goto IL_254a_2;
															IL_254a_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_258a_2;
															IL_258a_2:
															array2[num6 - 2] = 3;
															goto IL_259e_2;
															IL_259e_2:
															num6--;
															num = 242;
															goto end_IL_09e9_2;
															IL_27d9_2:
															if (67 < b)
															{
																break;
															}
															goto IL_27e4_2;
															IL_25c3_2:
															array2[num6 - 1] = 0;
															goto IL_25d7_2;
															IL_25d7_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_2616_2;
															IL_2616_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_2629_2:
															if (62 < b)
															{
																break;
															}
															goto IL_2637_2;
															IL_2637_2:
															if (62 > b)
															{
																break;
															}
															goto IL_2645_2;
															IL_2645_2:
															((delegate*<GorillaPlayerScoreboardLine, bool, GorillaPlayerLineButton.ButtonType, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerScoreboardLine)array3[num6 - 3], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, *(GorillaPlayerLineButton.ButtonType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_2698_2;
															IL_2698_2:
															num6 -= 3;
															goto IL_26a6_2;
															IL_26a6_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_26b9_2:
															if (65 >= b)
															{
																goto IL_26c7_2;
															}
															goto IL_2779_2;
															IL_26c7_2:
															if (65 <= b)
															{
																goto IL_26d2_2;
															}
															goto IL_271c_2;
															IL_26d2_2:
															((delegate*<GorillaPlayerLineButton, void>)ILegacyEvidenceAdapterIEnumReferenceIdentity[*(int*)(ptr2 + num3)])((GorillaPlayerLineButton)array3[num6 - 1]);
															goto IL_26fb_2;
															IL_26fb_2:
															num6--;
															goto IL_2709_2;
															IL_2709_2:
															ptr2 += 8;
															goto end_IL_09e9_2;
															IL_271c_2:
															if (64 < b)
															{
																break;
															}
															goto IL_272a_2;
															IL_272a_2:
															if (64 > b)
															{
																break;
															}
															goto IL_2738_2;
															IL_2738_2:
															((GorillaPlayerLineButton)array3[num6 - 2]).isOn = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
															goto IL_2766_2;
															IL_2766_2:
															num6 -= 2;
															goto end_IL_09e9_2;
															IL_2779_2:
															if (66 >= b)
															{
																goto IL_2784_2;
															}
															goto IL_27d9_2;
															IL_2784_2:
															if (66 > b)
															{
																break;
															}
															num = 221;
															goto IL_2798_2;
															IL_27e4_2:
															if (67 <= b)
															{
															}
															break;
														}
														break;
														IL_09d9_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												break;
												continue;
												end_IL_09e9_2:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_2802_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0e2e_2;
					}
					continue;
					end_IL_0e3c:
					break;
				}
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0385, IL_0398, IL_03ab, IL_03bb, IL_03cb, IL_03d8, IL_03e8, IL_03f8, IL_0408, IL_0418, IL_0428, IL_0433, IL_0443, IL_045f, IL_046a, IL_0478, IL_0486, IL_049e, IL_04ac, IL_04bf, IL_04cd, IL_04db, IL_0519, IL_052c, IL_0540, IL_0581, IL_0594, IL_05a2, IL_05ab, IL_05d4, IL_05e2, IL_05f5, IL_0603, IL_061b, IL_0639, IL_065d, IL_0675, IL_0688, IL_0696, IL_06a1, IL_06af, IL_06c2, IL_06df, IL_072e, IL_0738, IL_0765, IL_0779, IL_0787, IL_079a, IL_07a5, IL_07b3, IL_07c1, IL_07ea, IL_0803, IL_0811, IL_082f, IL_083d, IL_0850, IL_085e, IL_086c, IL_087a, IL_0888, IL_0893, IL_08a1, IL_08b4, IL_08f4, IL_0908, IL_091b, IL_0926, IL_0934, IL_0942, IL_0950, IL_0973, IL_097d, IL_098b, IL_099e, IL_09a9, IL_09d2, IL_09e0, IL_09f3, IL_0a01, IL_0a41, IL_0a55, IL_0a71, IL_0a7f, IL_0a8d, IL_0a9b, IL_0aa9, IL_0b0b, IL_0b1e, IL_0b2c, IL_0b6c, IL_0b89, IL_0b9c, IL_0baa, IL_0bb5, IL_0bc3, IL_0c03, IL_0c17, IL_0c2a, IL_0c33, IL_0c41, IL_0c4f, IL_0c58, IL_0c98, IL_0cac, IL_0cbf, IL_0cd2, IL_0cdb, IL_0cef, IL_0d43, IL_0d51, IL_0d61, IL_0d7a, IL_0d88, IL_0d9f, IL_0dad, IL_0dc0, IL_0dcb, IL_0dd5, IL_0de0, IL_0df0, IL_0e00, IL_0e10, IL_0e29, IL_0e39, IL_0e49, IL_0e59 are reachable both inside and outside the pinned region starting at IL_0e6e. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 95;
		int num4 = default(int);
		int num7 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num5;
			int num6;
			object[] array8;
			int num8;
			byte* num9;
			int __rxRef89 = default(int);
			ref int reference = ref __rxRef89;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0e59:
					num2 = 1;
					while (true)
					{
						IL_0e49:
						num3 = num2 * 4;
						while (true)
						{
							IL_0e39:
							array2 = new byte[4];
							while (true)
							{
								IL_0e29:
								array3 = new object[4];
								while (true)
								{
									IL_0e10:
									array4 = new int[4];
									num = 168;
									while (true)
									{
										IL_0e00:
										array5 = new int[6];
										while (true)
										{
											IL_0df0:
											array6 = new long[4];
											while (true)
											{
												IL_0de0:
												array7 = new object[9];
												while (true)
												{
													IL_0dd5:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CspKeyContainerInfofilterList.UnionVar);
													while (true)
													{
														IL_0dcb:
														ptr2 = ptr;
														while (true)
														{
															IL_0dc0:
															num = 154;
															while (true)
															{
																IL_0dad:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0428:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0418:
																		ptr2++;
																		while (true)
																		{
																			IL_0408:
																			if (b >= 1)
																			{
																				while (b <= 21)
																				{
																					while (true)
																					{
																						IL_03e8:
																						if (11 < b)
																						{
																							while (true)
																							{
																								IL_03d8:
																								if (16 < b)
																								{
																									while (true)
																									{
																										IL_03cb:
																										if (19 < b)
																										{
																											while (true)
																											{
																												IL_03bb:
																												if (20 < b)
																												{
																													while (21 >= b)
																													{
																														while (true)
																														{
																															IL_0398:
																															if (21 > b)
																															{
																																num = 218;
																																while (num != 218)
																																{
																																	if (num != 1199)
																																	{
																																		goto IL_0811;
																																	}
																																	switch (num)
																																	{
																																	case 95:
																																		break;
																																	default:
																																		continue;
																																	case 29:
																																		goto IL_0398;
																																	case 1:
																																	case 205:
																																		goto IL_03ab;
																																	case 72:
																																		goto IL_03bb;
																																	case 38:
																																		goto IL_03cb;
																																	case 68:
																																	case 204:
																																		goto IL_03d8;
																																	case 138:
																																		goto IL_03e8;
																																	case 208:
																																		goto IL_03f8;
																																	case 108:
																																		goto IL_0408;
																																	case 170:
																																		goto IL_0418;
																																	case 85:
																																	case 155:
																																		goto IL_0428;
																																	case 152:
																																		goto IL_0433;
																																	case 107:
																																	case 176:
																																		goto IL_0443;
																																	case 177:
																																		goto IL_045f;
																																	case 36:
																																		goto IL_046a;
																																	case 37:
																																	case 171:
																																		goto IL_0478;
																																	case 118:
																																		goto IL_0486;
																																	case 144:
																																		goto IL_049e;
																																	case 175:
																																		goto IL_04ac;
																																	case 158:
																																		goto IL_04bf;
																																	case 54:
																																		goto IL_04cd;
																																	case 70:
																																	case 128:
																																		goto IL_04db;
																																	case 139:
																																		goto IL_0519;
																																	case 39:
																																	case 203:
																																		goto IL_052c;
																																	case 12:
																																		goto IL_0540;
																																	case 84:
																																		goto IL_0581;
																																	case 137:
																																		goto IL_0594;
																																	case 81:
																																	case 163:
																																		goto IL_05ab;
																																	case 27:
																																		goto IL_05d4;
																																	case 103:
																																		goto IL_05e2;
																																	case 34:
																																		goto IL_05f5;
																																	case 40:
																																	case 67:
																																		goto IL_0603;
																																	case 93:
																																		goto IL_061b;
																																	case 16:
																																		goto IL_0639;
																																	case 19:
																																		goto IL_065d;
																																	case 7:
																																		goto IL_0675;
																																	case 197:
																																		goto IL_0688;
																																	case 45:
																																		goto IL_0696;
																																	case 21:
																																	case 148:
																																		goto IL_06a1;
																																	case 82:
																																		goto IL_06af;
																																	case 24:
																																	case 156:
																																		goto IL_06c2;
																																	case 141:
																																		goto IL_0779;
																																	case 113:
																																		goto IL_0787;
																																	case 3:
																																		goto IL_079a;
																																	case 99:
																																	case 146:
																																		goto IL_07a5;
																																	case 75:
																																		goto IL_07b3;
																																	case 35:
																																	case 53:
																																		goto IL_07c1;
																																	case 17:
																																		goto IL_07ea;
																																	case 210:
																																		goto IL_0803;
																																	case 69:
																																	case 157:
																																		goto IL_0811;
																																	case 23:
																																		goto IL_082f;
																																	case 92:
																																		goto IL_083d;
																																	case 173:
																																		goto IL_0850;
																																	case 127:
																																		goto IL_085e;
																																	case 123:
																																		goto IL_086c;
																																	case 20:
																																	case 102:
																																		goto IL_087a;
																																	case 101:
																																		goto IL_0888;
																																	case 48:
																																	case 211:
																																		goto IL_0893;
																																	case 55:
																																		goto IL_08a1;
																																	case 61:
																																	case 129:
																																		goto IL_08b4;
																																	case 0:
																																		goto IL_08f4;
																																	case 120:
																																		goto IL_0908;
																																	case 22:
																																	case 201:
																																		goto IL_091b;
																																	case 145:
																																	case 186:
																																		goto IL_0926;
																																	case 165:
																																		goto IL_0934;
																																	case 15:
																																	case 64:
																																		goto IL_0942;
																																	case 73:
																																		goto IL_0950;
																																	case 2:
																																		goto IL_0973;
																																	case 80:
																																		goto IL_097d;
																																	case 121:
																																		goto IL_098b;
																																	case 78:
																																		goto IL_099e;
																																	case 181:
																																	case 183:
																																		goto IL_09a9;
																																	case 30:
																																		goto IL_09d2;
																																	case 131:
																																		goto IL_09e0;
																																	case 66:
																																	case 151:
																																		goto IL_0a01;
																																	case 62:
																																		goto IL_0a41;
																																	case 196:
																																		goto IL_0a55;
																																	case 60:
																																		goto IL_0a71;
																																	case 11:
																																	case 178:
																																		goto IL_0a7f;
																																	case 83:
																																		goto IL_0a8d;
																																	case 44:
																																		goto IL_0a9b;
																																	case 10:
																																	case 79:
																																		goto IL_0aa9;
																																	case 4:
																																		goto IL_0b0b;
																																	case 124:
																																		goto IL_0b1e;
																																	case 200:
																																	case 202:
																																		goto IL_0b2c;
																																	case 198:
																																		goto IL_0b6c;
																																	case 182:
																																		goto IL_0b89;
																																	case 160:
																																		goto IL_0b9c;
																																	case 51:
																																	case 147:
																																		goto IL_0baa;
																																	case 65:
																																		goto IL_0bb5;
																																	case 90:
																																	case 185:
																																		goto IL_0bc3;
																																	case 71:
																																		goto IL_0c03;
																																	case 167:
																																		goto IL_0c17;
																																	case 91:
																																	case 100:
																																		goto IL_0c33;
																																	case 86:
																																		goto IL_0c41;
																																	case 143:
																																	case 179:
																																		goto IL_0c58;
																																	case 76:
																																		goto IL_0c98;
																																	case 136:
																																		goto IL_0cac;
																																	case 58:
																																	case 150:
																																		goto IL_0cbf;
																																	case 116:
																																	case 130:
																																		goto IL_0cdb;
																																	case 153:
																																		goto IL_0cef;
																																	case 209:
																																		goto IL_0d43;
																																	case 161:
																																		goto IL_0d51;
																																	case 5:
																																	case 13:
																																	case 14:
																																	case 25:
																																	case 32:
																																	case 47:
																																	case 49:
																																	case 52:
																																	case 56:
																																	case 77:
																																	case 87:
																																	case 89:
																																	case 96:
																																	case 98:
																																	case 104:
																																	case 105:
																																	case 106:
																																	case 109:
																																	case 111:
																																	case 115:
																																	case 117:
																																	case 125:
																																	case 126:
																																	case 132:
																																	case 133:
																																	case 134:
																																	case 135:
																																	case 142:
																																	case 162:
																																	case 164:
																																	case 166:
																																	case 172:
																																	case 174:
																																	case 189:
																																	case 192:
																																	case 194:
																																	case 199:
																																	case 206:
																																		goto end_IL_0385;
																																	case 63:
																																		goto IL_0d7a;
																																	case 195:
																																		goto IL_0d88;
																																	case 184:
																																		goto IL_0d9f;
																																	case 8:
																																	case 26:
																																	case 31:
																																	case 33:
																																	case 41:
																																	case 50:
																																	case 57:
																																	case 74:
																																	case 88:
																																	case 97:
																																	case 110:
																																	case 112:
																																	case 114:
																																	case 119:
																																	case 140:
																																	case 149:
																																	case 154:
																																	case 159:
																																	case 169:
																																	case 180:
																																	case 190:
																																	case 191:
																																	case 207:
																																		goto IL_0dad;
																																	case 42:
																																		goto IL_0dc0;
																																	case 193:
																																		goto IL_0dcb;
																																	case 28:
																																		goto IL_0dd5;
																																	case 59:
																																		goto IL_0de0;
																																	case 187:
																																		goto IL_0df0;
																																	case 168:
																																		goto IL_0e00;
																																	case 188:
																																		goto IL_0e10;
																																	case 18:
																																		goto IL_0e29;
																																	case 6:
																																	case 122:
																																		goto IL_0e39;
																																	case 46:
																																		goto IL_0e49;
																																	case 94:
																																		goto IL_0e59;
																																	case 9:
																																	case 43:
																																		return;
																																	}
																																	goto end_IL_0408;
																																	continue;
																																	end_IL_0385:
																																	break;
																																}
																																break;
																															}
																															goto IL_0443;
																															IL_0443:
																															num5 = ptr2;
																															num6 = -200;
																															num4 = 1;
																															ptr2 = num5 + num6;
																															goto IL_0dad;
																														}
																														break;
																														IL_03ab:;
																													}
																													break;
																												}
																												goto IL_0594;
																												IL_05d4:
																												num7--;
																												goto IL_05e2;
																												IL_0594:
																												if (20 > b)
																												{
																													break;
																												}
																												num = 81;
																												goto IL_05ab;
																												IL_05e2:
																												ptr2 += 8;
																												goto IL_0dad;
																												IL_05ab:
																												((delegate*<string, void>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
																												goto IL_05d4;
																											}
																											break;
																										}
																										goto IL_0433;
																										IL_0519:
																										num7 -= 3;
																										goto IL_0dad;
																										IL_0433:
																										if (19 > b)
																										{
																											goto IL_045f;
																										}
																										goto IL_052c;
																										IL_052c:
																										array2[num7 - 1] = 5;
																										goto IL_0540;
																										IL_0540:
																										array3[num7 - 1] = ((delegate*<string[], string>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																										num = 84;
																										goto IL_0581;
																										IL_0581:
																										ptr2 += 8;
																										goto IL_0dad;
																										IL_045f:
																										if (17 >= b)
																										{
																											goto IL_046a;
																										}
																										goto IL_04bf;
																										IL_046a:
																										if (17 > b)
																										{
																											break;
																										}
																										goto IL_0478;
																										IL_0478:
																										array2[num7] = 5;
																										goto IL_0486;
																										IL_0486:
																										array3[num7] = array7[*(int*)(ptr2 + num3)];
																										goto IL_049e;
																										IL_049e:
																										num7++;
																										goto IL_04ac;
																										IL_04ac:
																										ptr2 += 8;
																										goto IL_0dad;
																										IL_04bf:
																										if (18 < b)
																										{
																											break;
																										}
																										goto IL_04cd;
																										IL_04cd:
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_04db;
																										IL_04db:
																										((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
																										goto IL_0519;
																									}
																									break;
																								}
																								goto IL_05f5;
																								IL_0803:
																								if (14 > b)
																								{
																									break;
																								}
																								goto IL_0811;
																								IL_05f5:
																								if (16 <= b)
																								{
																									goto IL_0603;
																								}
																								goto IL_0688;
																								IL_0603:
																								array2[num7] = array2[num7 - 1];
																								goto IL_061b;
																								IL_061b:
																								array4[num7 - 0] = array4[num7 - 1];
																								goto IL_0639;
																								IL_0639:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																								goto IL_065d;
																								IL_065d:
																								array3[num7] = array3[num7 - 1];
																								goto IL_0675;
																								IL_0675:
																								num7++;
																								goto IL_0dad;
																								IL_0688:
																								if (13 >= b)
																								{
																									goto IL_0696;
																								}
																								goto IL_079a;
																								IL_0696:
																								if (13 > b)
																								{
																									goto IL_06a1;
																								}
																								goto IL_06c2;
																								IL_06a1:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_06af;
																								IL_06af:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0dad;
																								IL_06c2:
																								array8 = array3;
																								num8 = num7;
																								if (array == null)
																								{
																									goto IL_06d1;
																								}
																								num9 = ptr2;
																								byte b2 = *num9;
																								ptr2 = num9 + 4;
																								int num10 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num10;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0779;
																								IL_0811:
																								array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																								goto IL_082f;
																								IL_082f:
																								ptr2 += 8;
																								goto IL_083d;
																								IL_083d:
																								num7--;
																								goto IL_0dad;
																								IL_0779:
																								array2[num7] = 5;
																								goto IL_0787;
																								IL_0787:
																								num7++;
																								goto IL_0dad;
																								IL_079a:
																								if (14 < b)
																								{
																									goto IL_07a5;
																								}
																								goto IL_0803;
																								IL_07a5:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_07b3;
																								IL_07b3:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_07c1;
																								IL_07c1:
																								array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
																								goto IL_07ea;
																								IL_07ea:
																								array2[num7 - 1] = 5;
																								goto IL_0dad;
																							}
																							break;
																						}
																						goto IL_0850;
																						IL_0cdb:
																						array2[num7 - 2] = 0;
																						goto IL_0cef;
																						IL_0850:
																						if (11 > b)
																						{
																							goto IL_085e;
																						}
																						num = 130;
																						goto IL_0cdb;
																						IL_085e:
																						if (5 >= b)
																						{
																							goto IL_086c;
																						}
																						goto IL_0a71;
																						IL_086c:
																						if (5 > b)
																						{
																							goto IL_087a;
																						}
																						goto IL_0a01;
																						IL_087a:
																						if (2 >= b)
																						{
																							goto IL_0888;
																						}
																						goto IL_091b;
																						IL_0888:
																						if (2 > b)
																						{
																							goto IL_0893;
																						}
																						goto IL_08b4;
																						IL_0893:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_08a1;
																						IL_08a1:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_08b4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_08f4;
																						IL_08f4:
																						array2[num7 - 2] = 0;
																						goto IL_0908;
																						IL_0908:
																						num7--;
																						goto IL_0dad;
																						IL_091b:
																						if (3 < b)
																						{
																							goto IL_0926;
																						}
																						goto IL_099e;
																						IL_0926:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0934;
																						IL_0934:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0942;
																						IL_0942:
																						array2[num7] = 0;
																						goto IL_0950;
																						IL_0950:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0973;
																						IL_0973:
																						array3[num7] = null;
																						goto IL_097d;
																						IL_097d:
																						num7++;
																						goto IL_098b;
																						IL_098b:
																						ptr2 += 8;
																						goto IL_0dad;
																						IL_099e:
																						if (3 > b)
																						{
																							num = 49;
																							break;
																						}
																						goto IL_09a9;
																						IL_09a9:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_09d2;
																						IL_09d2:
																						ptr2 += 8;
																						goto IL_09e0;
																						IL_09e0:
																						num7--;
																						goto IL_0dad;
																						IL_0cef:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = ((delegate*<int, int, int>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]));
																						goto IL_0d43;
																						IL_0a01:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_0a41;
																						IL_0a41:
																						array2[num7 - 2] = 0;
																						goto IL_0a55;
																						IL_0a55:
																						num7--;
																						num = 119;
																						goto IL_0dad;
																						IL_0a71:
																						if (8 < b)
																						{
																							goto IL_0a7f;
																						}
																						goto IL_0b9c;
																						IL_0a7f:
																						if (9 < b)
																						{
																							goto IL_0a8d;
																						}
																						goto IL_0b1e;
																						IL_0a8d:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0a9b;
																						IL_0a9b:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0aa9;
																						IL_0aa9:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0b0b;
																						IL_0b0b:
																						num7 -= 2;
																						goto IL_0dad;
																						IL_0b1e:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0b2c;
																						IL_0b2c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_0b6c;
																						IL_0b6c:
																						array2[num7 - 2] = 0;
																						num = 182;
																						goto IL_0b89;
																						IL_0b89:
																						num7--;
																						goto IL_0dad;
																						IL_0b9c:
																						if (8 > b)
																						{
																							goto IL_0baa;
																						}
																						goto IL_0cbf;
																						IL_0baa:
																						if (6 >= b)
																						{
																							goto IL_0bb5;
																						}
																						num = 100;
																						goto IL_0c33;
																						IL_0bb5:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0bc3;
																						IL_0bc3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_0c03;
																						IL_0c03:
																						array2[num7 - 2] = 0;
																						goto IL_0c17;
																						IL_0c17:
																						num7--;
																						goto IL_0dad;
																						IL_0d43:
																						num7--;
																						goto IL_0d51;
																						IL_0c33:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0c41;
																						IL_0c41:
																						if (7 > b)
																						{
																							break;
																						}
																						num = 143;
																						goto IL_0c58;
																						IL_0d51:
																						ptr2 += 8;
																						goto IL_0dad;
																						IL_0c58:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																						goto IL_0c98;
																						IL_0c98:
																						array2[num7 - 2] = 0;
																						goto IL_0cac;
																						IL_0cac:
																						num7--;
																						goto IL_0dad;
																						IL_0cbf:
																						num7--;
																						goto IL_0dad;
																					}
																					break;
																					IL_03f8:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
																			goto IL_0d7a;
																			IL_0d9f:
																			ptr2 += 8;
																			goto IL_0dad;
																			IL_0d88:
																			num7++;
																			num = 184;
																			goto IL_0d9f;
																			IL_0d7a:
																			array2[num7] = 0;
																			goto IL_0d88;
																			continue;
																			end_IL_0408:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_06d1:
			while (true)
			{
				IL_06d1_2:
				array = new byte[4];
				while (true)
				{
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0779_2:
						array2[num7] = 5;
						while (true)
						{
							IL_0787_2:
							num7++;
							while (true)
							{
								IL_0dad_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0408_2:
											if (b >= 1)
											{
												while (b <= 21)
												{
													while (true)
													{
														IL_03e8_2:
														if (11 < b)
														{
															while (true)
															{
																IL_03d8_2:
																if (16 < b)
																{
																	while (true)
																	{
																		IL_03cb_2:
																		if (19 < b)
																		{
																			while (true)
																			{
																				IL_03bb_2:
																				if (20 < b)
																				{
																					while (21 >= b)
																					{
																						while (true)
																						{
																							IL_0398_2:
																							if (21 > b)
																							{
																								num = 218;
																								while (num != 218)
																								{
																									if (num != 1199)
																									{
																										goto IL_0811_2;
																									}
																									switch (num)
																									{
																									case 29:
																										goto IL_0398_2;
																									case 1:
																									case 205:
																										goto IL_03ab_2;
																									case 72:
																										goto IL_03bb_2;
																									case 38:
																										goto IL_03cb_2;
																									case 68:
																									case 204:
																										goto IL_03d8_2;
																									case 138:
																										goto IL_03e8_2;
																									case 208:
																										goto IL_03f8_2;
																									case 108:
																										goto IL_0408_2;
																									case 170:
																										goto end_IL_0408_2;
																									case 85:
																									case 155:
																										goto end_IL_0418;
																									case 152:
																										goto IL_0433_2;
																									case 107:
																									case 176:
																										goto IL_0443_2;
																									case 177:
																										goto IL_045f_2;
																									case 36:
																										goto IL_046a_2;
																									case 37:
																									case 171:
																										goto IL_0478_2;
																									case 118:
																										goto IL_0486_2;
																									case 144:
																										goto IL_049e_2;
																									case 175:
																										goto IL_04ac_2;
																									case 158:
																										goto IL_04bf_2;
																									case 54:
																										goto IL_04cd_2;
																									case 70:
																									case 128:
																										goto IL_04db_2;
																									case 139:
																										goto IL_0519_2;
																									case 39:
																									case 203:
																										goto IL_052c_2;
																									case 12:
																										goto IL_0540_2;
																									case 84:
																										goto IL_0581_2;
																									case 137:
																										goto IL_0594_2;
																									case 81:
																									case 163:
																										goto IL_05ab_2;
																									case 27:
																										goto IL_05d4_2;
																									case 103:
																										goto IL_05e2_2;
																									case 34:
																										goto IL_05f5_2;
																									case 40:
																									case 67:
																										goto IL_0603_2;
																									case 93:
																										goto IL_061b_2;
																									case 16:
																										goto IL_0639_2;
																									case 19:
																										goto IL_065d_2;
																									case 7:
																										goto IL_0675_2;
																									case 197:
																										goto IL_0688_2;
																									case 45:
																										goto IL_0696_2;
																									case 21:
																									case 148:
																										goto IL_06a1_2;
																									case 82:
																										goto IL_06af_2;
																									case 24:
																									case 156:
																										goto end_IL_0428;
																									case 141:
																										goto IL_0779_2;
																									case 113:
																										goto IL_0787_2;
																									case 3:
																										goto IL_079a_2;
																									case 99:
																									case 146:
																										goto IL_07a5_2;
																									case 75:
																										goto IL_07b3_2;
																									case 35:
																									case 53:
																										goto IL_07c1_2;
																									case 17:
																										goto IL_07ea_2;
																									case 210:
																										goto IL_0803_2;
																									case 69:
																									case 157:
																										goto IL_0811_2;
																									case 23:
																										goto IL_082f_2;
																									case 92:
																										goto IL_083d_2;
																									case 173:
																										goto IL_0850_2;
																									case 127:
																										goto IL_085e_2;
																									case 123:
																										goto IL_086c_2;
																									case 20:
																									case 102:
																										goto IL_087a_2;
																									case 101:
																										goto IL_0888_2;
																									case 48:
																									case 211:
																										goto IL_0893_2;
																									case 55:
																										goto IL_08a1_2;
																									case 61:
																									case 129:
																										goto IL_08b4_2;
																									case 0:
																										goto IL_08f4_2;
																									case 120:
																										goto IL_0908_2;
																									case 22:
																									case 201:
																										goto IL_091b_2;
																									case 145:
																									case 186:
																										goto IL_0926_2;
																									case 165:
																										goto IL_0934_2;
																									case 15:
																									case 64:
																										goto IL_0942_2;
																									case 73:
																										goto IL_0950_2;
																									case 2:
																										goto IL_0973_2;
																									case 80:
																										goto IL_097d_2;
																									case 121:
																										goto IL_098b_2;
																									case 78:
																										goto IL_099e_2;
																									case 181:
																									case 183:
																										goto IL_09a9_2;
																									case 30:
																										goto IL_09d2_2;
																									case 131:
																										goto IL_09e0_2;
																									case 66:
																									case 151:
																										goto IL_0a01_2;
																									case 62:
																										goto IL_0a41_2;
																									case 196:
																										goto IL_0a55_2;
																									case 60:
																										goto IL_0a71_2;
																									case 11:
																									case 178:
																										goto IL_0a7f_2;
																									case 83:
																										goto IL_0a8d_2;
																									case 44:
																										goto IL_0a9b_2;
																									case 10:
																									case 79:
																										goto IL_0aa9_2;
																									case 4:
																										goto IL_0b0b_2;
																									case 124:
																										goto IL_0b1e_2;
																									case 200:
																									case 202:
																										goto IL_0b2c_2;
																									case 198:
																										goto IL_0b6c_2;
																									case 182:
																										goto IL_0b89_2;
																									case 160:
																										goto IL_0b9c_2;
																									case 51:
																									case 147:
																										goto IL_0baa_2;
																									case 65:
																										goto IL_0bb5_2;
																									case 90:
																									case 185:
																										goto IL_0bc3_2;
																									case 71:
																										goto IL_0c03_2;
																									case 167:
																										goto IL_0c17_2;
																									case 91:
																									case 100:
																										goto IL_0c33_2;
																									case 86:
																										goto IL_0c41_2;
																									case 143:
																									case 179:
																										goto IL_0c58_2;
																									case 76:
																										goto IL_0c98_2;
																									case 136:
																										goto IL_0cac_2;
																									case 58:
																									case 150:
																										goto IL_0cbf_2;
																									case 116:
																									case 130:
																										goto IL_0cdb_2;
																									case 153:
																										goto IL_0cef_2;
																									case 209:
																										goto IL_0d43_2;
																									case 161:
																										goto IL_0d51_2;
																									case 5:
																									case 13:
																									case 14:
																									case 25:
																									case 32:
																									case 47:
																									case 49:
																									case 52:
																									case 56:
																									case 77:
																									case 87:
																									case 89:
																									case 96:
																									case 98:
																									case 104:
																									case 105:
																									case 106:
																									case 109:
																									case 111:
																									case 115:
																									case 117:
																									case 125:
																									case 126:
																									case 132:
																									case 133:
																									case 134:
																									case 135:
																									case 142:
																									case 162:
																									case 164:
																									case 166:
																									case 172:
																									case 174:
																									case 189:
																									case 192:
																									case 194:
																									case 199:
																									case 206:
																										goto end_IL_0385_2;
																									case 63:
																										goto IL_0d7a_2;
																									case 195:
																										goto IL_0d88_2;
																									case 184:
																										goto IL_0d9f_2;
																									case 8:
																									case 26:
																									case 31:
																									case 33:
																									case 41:
																									case 50:
																									case 57:
																									case 74:
																									case 88:
																									case 97:
																									case 110:
																									case 112:
																									case 114:
																									case 119:
																									case 140:
																									case 149:
																									case 154:
																									case 159:
																									case 169:
																									case 180:
																									case 190:
																									case 191:
																									case 207:
																										goto IL_0dad_2;
																									case 42:
																										num = 154;
																										goto IL_0dad_2;
																									case 193:
																										ptr2 = ptr;
																										goto case 42;
																									case 28:
																										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CspKeyContainerInfofilterList.UnionVar);
																										goto case 193;
																									case 59:
																										array7 = new object[9];
																										goto case 28;
																									case 187:
																										array6 = new long[4];
																										goto case 59;
																									case 168:
																										array5 = new int[6];
																										goto case 187;
																									case 188:
																										array4 = new int[4];
																										num = 168;
																										goto case 168;
																									case 18:
																										array3 = new object[4];
																										goto case 188;
																									case 6:
																									case 122:
																										array2 = new byte[4];
																										goto case 18;
																									case 46:
																										num3 = num2 * 4;
																										goto case 6;
																									case 94:
																										num2 = 1;
																										goto case 46;
																									case 95:
																										goto end_IL_06df;
																									case 9:
																									case 43:
																										return;
																									}
																									continue;
																									end_IL_0385_2:
																									break;
																								}
																								break;
																							}
																							goto IL_0443_2;
																							IL_0443_2:
																							num5 = ptr2;
																							num6 = -200;
																							num4 = 1;
																							ptr2 = num5 + num6;
																							goto IL_0dad_2;
																						}
																						break;
																						IL_03ab_2:;
																					}
																					break;
																				}
																				goto IL_0594_2;
																				IL_05d4_2:
																				num7--;
																				goto IL_05e2_2;
																				IL_0594_2:
																				if (20 > b)
																				{
																					break;
																				}
																				num = 81;
																				goto IL_05ab_2;
																				IL_05e2_2:
																				ptr2 += 8;
																				goto IL_0dad_2;
																				IL_05ab_2:
																				((delegate*<string, void>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
																				goto IL_05d4_2;
																			}
																			break;
																		}
																		goto IL_0433_2;
																		IL_0519_2:
																		num7 -= 3;
																		goto IL_0dad_2;
																		IL_0433_2:
																		if (19 > b)
																		{
																			goto IL_045f_2;
																		}
																		goto IL_052c_2;
																		IL_052c_2:
																		array2[num7 - 1] = 5;
																		goto IL_0540_2;
																		IL_0540_2:
																		array3[num7 - 1] = ((delegate*<string[], string>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																		num = 84;
																		goto IL_0581_2;
																		IL_0581_2:
																		ptr2 += 8;
																		goto IL_0dad_2;
																		IL_045f_2:
																		if (17 >= b)
																		{
																			goto IL_046a_2;
																		}
																		goto IL_04bf_2;
																		IL_046a_2:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_0478_2;
																		IL_0478_2:
																		array2[num7] = 5;
																		goto IL_0486_2;
																		IL_0486_2:
																		array3[num7] = array7[*(int*)(ptr2 + num3)];
																		goto IL_049e_2;
																		IL_049e_2:
																		num7++;
																		goto IL_04ac_2;
																		IL_04ac_2:
																		ptr2 += 8;
																		goto IL_0dad_2;
																		IL_04bf_2:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_04cd_2;
																		IL_04cd_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_04db_2;
																		IL_04db_2:
																		((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
																		goto IL_0519_2;
																	}
																	break;
																}
																goto IL_05f5_2;
																IL_083d_2:
																num7--;
																goto IL_0dad_2;
																IL_05f5_2:
																if (16 <= b)
																{
																	goto IL_0603_2;
																}
																goto IL_0688_2;
																IL_0603_2:
																array2[num7] = array2[num7 - 1];
																goto IL_061b_2;
																IL_061b_2:
																array4[num7 - 0] = array4[num7 - 1];
																goto IL_0639_2;
																IL_0639_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_065d_2;
																IL_065d_2:
																array3[num7] = array3[num7 - 1];
																goto IL_0675_2;
																IL_0675_2:
																num7++;
																goto IL_0dad_2;
																IL_0688_2:
																if (13 >= b)
																{
																	goto IL_0696_2;
																}
																goto IL_079a_2;
																IL_0696_2:
																if (13 <= b)
																{
																	goto end_IL_0428;
																}
																goto IL_06a1_2;
																IL_06a1_2:
																if (12 < b)
																{
																	break;
																}
																goto IL_06af_2;
																IL_06af_2:
																if (12 > b)
																{
																	break;
																}
																goto IL_0dad_2;
																IL_079a_2:
																if (14 < b)
																{
																	goto IL_07a5_2;
																}
																goto IL_0803_2;
																IL_07a5_2:
																if (15 < b)
																{
																	break;
																}
																goto IL_07b3_2;
																IL_07b3_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_07c1_2;
																IL_07c1_2:
																array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
																goto IL_07ea_2;
																IL_07ea_2:
																array2[num7 - 1] = 5;
																goto IL_0dad_2;
																IL_0803_2:
																if (14 > b)
																{
																	break;
																}
																goto IL_0811_2;
																IL_0811_2:
																array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																goto IL_082f_2;
																IL_082f_2:
																ptr2 += 8;
																goto IL_083d_2;
															}
															break;
														}
														goto IL_0850_2;
														IL_0cdb_2:
														array2[num7 - 2] = 0;
														goto IL_0cef_2;
														IL_0850_2:
														if (11 > b)
														{
															goto IL_085e_2;
														}
														num = 130;
														goto IL_0cdb_2;
														IL_085e_2:
														if (5 >= b)
														{
															goto IL_086c_2;
														}
														goto IL_0a71_2;
														IL_086c_2:
														if (5 > b)
														{
															goto IL_087a_2;
														}
														goto IL_0a01_2;
														IL_087a_2:
														if (2 >= b)
														{
															goto IL_0888_2;
														}
														goto IL_091b_2;
														IL_0888_2:
														if (2 > b)
														{
															goto IL_0893_2;
														}
														goto IL_08b4_2;
														IL_0893_2:
														if (1 < b)
														{
															break;
														}
														goto IL_08a1_2;
														IL_08a1_2:
														if (1 > b)
														{
														}
														break;
														IL_08b4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_08f4_2;
														IL_08f4_2:
														array2[num7 - 2] = 0;
														goto IL_0908_2;
														IL_0908_2:
														num7--;
														goto IL_0dad_2;
														IL_091b_2:
														if (3 < b)
														{
															goto IL_0926_2;
														}
														goto IL_099e_2;
														IL_0926_2:
														if (4 < b)
														{
															break;
														}
														goto IL_0934_2;
														IL_0934_2:
														if (4 > b)
														{
															break;
														}
														goto IL_0942_2;
														IL_0942_2:
														array2[num7] = 0;
														goto IL_0950_2;
														IL_0950_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0973_2;
														IL_0973_2:
														array3[num7] = null;
														goto IL_097d_2;
														IL_097d_2:
														num7++;
														goto IL_098b_2;
														IL_098b_2:
														ptr2 += 8;
														goto IL_0dad_2;
														IL_099e_2:
														if (3 > b)
														{
															num = 49;
															break;
														}
														goto IL_09a9_2;
														IL_09a9_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_09d2_2;
														IL_09d2_2:
														ptr2 += 8;
														goto IL_09e0_2;
														IL_09e0_2:
														num7--;
														goto IL_0dad_2;
														IL_0cef_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = ((delegate*<int, int, int>)FindIndexUseUserOverride[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]));
														goto IL_0d43_2;
														IL_0a01_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_0a41_2;
														IL_0a41_2:
														array2[num7 - 2] = 0;
														goto IL_0a55_2;
														IL_0a55_2:
														num7--;
														num = 119;
														goto IL_0dad_2;
														IL_0a71_2:
														if (8 < b)
														{
															goto IL_0a7f_2;
														}
														goto IL_0b9c_2;
														IL_0a7f_2:
														if (9 < b)
														{
															goto IL_0a8d_2;
														}
														goto IL_0b1e_2;
														IL_0a8d_2:
														if (10 < b)
														{
															break;
														}
														goto IL_0a9b_2;
														IL_0a9b_2:
														if (10 > b)
														{
															break;
														}
														goto IL_0aa9_2;
														IL_0aa9_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0b0b_2;
														IL_0b0b_2:
														num7 -= 2;
														goto IL_0dad_2;
														IL_0b1e_2:
														if (9 > b)
														{
															break;
														}
														goto IL_0b2c_2;
														IL_0b2c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_0b6c_2;
														IL_0b6c_2:
														array2[num7 - 2] = 0;
														num = 182;
														goto IL_0b89_2;
														IL_0b89_2:
														num7--;
														goto IL_0dad_2;
														IL_0b9c_2:
														if (8 > b)
														{
															goto IL_0baa_2;
														}
														goto IL_0cbf_2;
														IL_0baa_2:
														if (6 >= b)
														{
															goto IL_0bb5_2;
														}
														num = 100;
														goto IL_0c33_2;
														IL_0bb5_2:
														if (6 > b)
														{
															break;
														}
														goto IL_0bc3_2;
														IL_0bc3_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_0c03_2;
														IL_0c03_2:
														array2[num7 - 2] = 0;
														goto IL_0c17_2;
														IL_0c17_2:
														num7--;
														goto IL_0dad_2;
														IL_0d43_2:
														num7--;
														goto IL_0d51_2;
														IL_0c33_2:
														if (7 < b)
														{
															break;
														}
														goto IL_0c41_2;
														IL_0c41_2:
														if (7 > b)
														{
															break;
														}
														num = 143;
														goto IL_0c58_2;
														IL_0d51_2:
														ptr2 += 8;
														goto IL_0dad_2;
														IL_0c58_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
														goto IL_0c98_2;
														IL_0c98_2:
														array2[num7 - 2] = 0;
														goto IL_0cac_2;
														IL_0cac_2:
														num7--;
														goto IL_0dad_2;
														IL_0cbf_2:
														num7--;
														goto IL_0dad_2;
													}
													break;
													IL_03f8_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
											goto IL_0d7a_2;
											IL_0d9f_2:
											ptr2 += 8;
											goto IL_0dad_2;
											IL_0d88_2:
											num7++;
											num = 184;
											goto IL_0d9f_2;
											IL_0d7a_2:
											array2[num7] = 0;
											goto IL_0d88_2;
											continue;
											end_IL_0408_2:
											break;
										}
										continue;
										end_IL_0418:
										break;
									}
									continue;
									end_IL_0428:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num8 = num7;
					if (array == null)
					{
						goto IL_06d1_2;
					}
					continue;
					end_IL_06df:
					break;
				}
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001e, IL_0403, IL_0416, IL_0435, IL_0478, IL_0488, IL_0498, IL_04a5, IL_04b5, IL_04c5, IL_04de, IL_04f2, IL_04fb, IL_0506, IL_0513, IL_053c, IL_0555, IL_0568, IL_0576, IL_0581, IL_058f, IL_059d, IL_05ab, IL_05b9, IL_05c4, IL_0609, IL_0617, IL_0627, IL_0635, IL_063e, IL_0651, IL_0693, IL_06a1, IL_06c4, IL_06ce, IL_06dc, IL_06ef, IL_0703, IL_0716, IL_0744, IL_0784, IL_0798, IL_07ab, IL_07b9, IL_07c7, IL_0807, IL_081b, IL_0837, IL_0845, IL_0861, IL_086f, IL_087d, IL_089a, IL_08e9, IL_08f3, IL_0920, IL_0934, IL_0942, IL_0955, IL_0963, IL_0976, IL_0984, IL_098d, IL_099b, IL_09b9, IL_09c7, IL_09da, IL_09ee, IL_0a01, IL_0a14, IL_0a22, IL_0a30, IL_0a3b, IL_0a84, IL_0a98, IL_0aab, IL_0ab9, IL_0ac7, IL_0ada, IL_0ae8, IL_0af6, IL_0b58, IL_0b6b, IL_0b74, IL_0b91, IL_0be5, IL_0bf3, IL_0c06, IL_0c1f, IL_0c2d, IL_0c3b, IL_0c4e, IL_0c61, IL_0c6f, IL_0c7a, IL_0cb8, IL_0ccb, IL_0cd9, IL_0ce7, IL_0cff, IL_0d1d, IL_0d41, IL_0d59, IL_0d6c, IL_0d7a, IL_0d88, IL_0d96, IL_0dae, IL_0dbc, IL_0dcf, IL_0ddd, IL_0de8, IL_0e01, IL_0e0f, IL_0e1d, IL_0e30, IL_0e3e, IL_0e47, IL_0e55, IL_0e69, IL_0ea1, IL_0eb4, IL_0ec2, IL_0ecb, IL_0ed9, IL_0ef1, IL_0eff, IL_0f0d, IL_0f1b, IL_0f26, IL_0f4f, IL_0f5d, IL_0f70, IL_0f7e, IL_0f87, IL_0f95, IL_0fe7, IL_0ffa, IL_1008, IL_1016, IL_102f, IL_103d, IL_104b, IL_105e, IL_109e, IL_10b2, IL_10c5, IL_10d3, IL_10de, IL_1103, IL_1111, IL_111c, IL_1130, IL_116f, IL_117f, IL_118a, IL_1195, IL_11a8, IL_11bb, IL_11c5, IL_11d9, IL_11e9, IL_11f9, IL_1209, IL_1219, IL_1229, IL_1239, IL_1249, IL_1259 are reachable both inside and outside the pinned region starting at IL_126e. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 81;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef90 = default(int);
			ref int reference = ref __rxRef90;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1259:
					num2 = 1;
					while (true)
					{
						IL_1249:
						num3 = num2 * 4;
						while (true)
						{
							IL_1239:
							num4 = num2 * 8;
							while (true)
							{
								IL_1229:
								array2 = new byte[4];
								while (true)
								{
									IL_1219:
									array3 = new object[4];
									while (true)
									{
										IL_1209:
										array4 = new int[4];
										while (true)
										{
											IL_11f9:
											array5 = new int[7];
											while (true)
											{
												IL_11e9:
												array6 = new long[4];
												while (true)
												{
													IL_11d9:
													array7 = new object[9];
													while (true)
													{
														IL_11c5:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WellKnownGroupWarning.wellKnownGroupWarning_0);
														num = 125;
														while (true)
														{
															IL_11bb:
															ptr2 = ptr;
															while (true)
															{
																IL_11a8:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_04de:
																	byte b = *ptr2;
																	num = 5;
																	while (true)
																	{
																		IL_04c5:
																		ptr2++;
																		num = 60;
																		while (true)
																		{
																			IL_04b5:
																			if (b >= 1)
																			{
																				while (b <= 29)
																				{
																					while (true)
																					{
																						IL_0498:
																						if (15 < b)
																						{
																							while (true)
																							{
																								IL_0488:
																								if (22 >= b)
																								{
																									while (true)
																									{
																										IL_0478:
																										if (22 <= b)
																										{
																											while (true)
																											{
																												IL_0435:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																												while (true)
																												{
																													IL_0416:
																													array2[num6 - 2] = 0;
																													num = 253;
																													while (true)
																													{
																														if (num != 253)
																														{
																															if (num != 1234)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 81:
																																break;
																															default:
																																continue;
																															case 221:
																																goto IL_0416;
																															case 1:
																															case 191:
																																goto IL_0435;
																															case 73:
																																goto IL_0478;
																															case 188:
																																goto IL_0488;
																															case 157:
																																goto IL_0498;
																															case 4:
																																goto IL_04a5;
																															case 60:
																																goto IL_04b5;
																															case 5:
																																goto IL_04c5;
																															case 26:
																															case 129:
																																goto IL_04de;
																															case 21:
																																goto IL_04fb;
																															case 22:
																																goto IL_0506;
																															case 41:
																															case 44:
																																goto IL_0513;
																															case 47:
																																goto IL_053c;
																															case 92:
																																goto IL_0555;
																															case 106:
																																goto IL_0568;
																															case 83:
																																goto IL_0576;
																															case 105:
																																goto IL_0581;
																															case 19:
																																goto IL_058f;
																															case 15:
																																goto IL_05ab;
																															case 27:
																																goto IL_05b9;
																															case 10:
																															case 85:
																																goto IL_05c4;
																															case 0:
																																goto IL_0609;
																															case 37:
																																goto IL_0617;
																															case 149:
																																goto IL_0627;
																															case 70:
																																goto IL_063e;
																															case 69:
																															case 160:
																																goto IL_0651;
																															case 152:
																															case 185:
																																goto IL_0693;
																															case 39:
																																goto IL_06a1;
																															case 154:
																																goto IL_06c4;
																															case 95:
																																goto IL_06ce;
																															case 143:
																																goto IL_06dc;
																															case 190:
																																goto IL_06ef;
																															case 131:
																																goto IL_0703;
																															case 187:
																															case 195:
																																goto IL_0716;
																															case 114:
																															case 196:
																																goto end_IL_0403;
																															case 88:
																																goto IL_0784;
																															case 170:
																																goto IL_0798;
																															case 208:
																																goto IL_07ab;
																															case 54:
																																goto IL_07b9;
																															case 3:
																															case 182:
																																goto IL_07c7;
																															case 49:
																																goto IL_0807;
																															case 136:
																																goto IL_081b;
																															case 213:
																																goto IL_0837;
																															case 139:
																																goto IL_0845;
																															case 225:
																																goto IL_0861;
																															case 52:
																																goto IL_086f;
																															case 138:
																															case 200:
																																goto IL_087d;
																															case 102:
																																goto IL_0934;
																															case 124:
																																goto IL_0942;
																															case 45:
																																goto IL_0955;
																															case 57:
																																goto IL_0963;
																															case 113:
																																goto IL_0976;
																															case 7:
																																goto IL_098d;
																															case 93:
																															case 130:
																																goto IL_099b;
																															case 24:
																																goto IL_09b9;
																															case 212:
																																goto IL_09c7;
																															case 227:
																																goto IL_09da;
																															case 174:
																																goto IL_09ee;
																															case 234:
																																goto IL_0a01;
																															case 236:
																																goto IL_0a14;
																															case 78:
																																goto IL_0a22;
																															case 17:
																																goto IL_0a30;
																															case 122:
																															case 173:
																																goto IL_0a3b;
																															case 198:
																																goto IL_0a84;
																															case 132:
																																goto IL_0a98;
																															case 176:
																																goto IL_0aab;
																															case 146:
																																goto IL_0ab9;
																															case 214:
																															case 232:
																																goto IL_0ac7;
																															case 201:
																																goto IL_0ada;
																															case 109:
																																goto IL_0ae8;
																															case 99:
																															case 194:
																																goto IL_0af6;
																															case 90:
																																goto IL_0b58;
																															case 43:
																															case 46:
																																goto IL_0b74;
																															case 123:
																																goto IL_0b91;
																															case 108:
																																goto IL_0be5;
																															case 89:
																																goto IL_0bf3;
																															case 244:
																															case 246:
																																goto IL_0c06;
																															case 204:
																																goto IL_0c1f;
																															case 71:
																																goto IL_0c2d;
																															case 20:
																																goto IL_0c3b;
																															case 30:
																																goto IL_0c61;
																															case 13:
																																goto IL_0c6f;
																															case 40:
																															case 158:
																																goto IL_0c7a;
																															case 218:
																																goto IL_0cb8;
																															case 151:
																																goto IL_0ccb;
																															case 238:
																																goto IL_0cd9;
																															case 61:
																															case 228:
																																goto IL_0ce7;
																															case 62:
																																goto IL_0cff;
																															case 116:
																																goto IL_0d1d;
																															case 6:
																																goto IL_0d41;
																															case 31:
																																goto IL_0d59;
																															case 231:
																																goto IL_0d6c;
																															case 55:
																																goto IL_0d7a;
																															case 59:
																															case 98:
																																goto IL_0d88;
																															case 121:
																																goto IL_0d96;
																															case 126:
																																goto IL_0dae;
																															case 32:
																																goto IL_0dbc;
																															case 65:
																																goto IL_0dcf;
																															case 11:
																																goto IL_0ddd;
																															case 51:
																															case 162:
																																goto IL_0de8;
																															case 103:
																																goto IL_0e01;
																															case 94:
																																goto IL_0e0f;
																															case 9:
																																goto IL_0e1d;
																															case 206:
																																goto IL_0e30;
																															case 245:
																																goto IL_0e47;
																															case 193:
																															case 239:
																																goto IL_0e55;
																															case 50:
																																goto IL_0e69;
																															case 242:
																																goto IL_0ea1;
																															case 117:
																																goto IL_0eb4;
																															case 82:
																																goto IL_0ecb;
																															case 29:
																															case 172:
																																goto IL_0ed9;
																															case 210:
																																goto IL_0ef1;
																															case 177:
																																goto IL_0eff;
																															case 156:
																																goto IL_0f0d;
																															case 127:
																																goto IL_0f1b;
																															case 74:
																															case 209:
																																goto IL_0f26;
																															case 142:
																																goto IL_0f4f;
																															case 53:
																																goto IL_0f5d;
																															case 219:
																																goto IL_0f70;
																															case 76:
																																goto IL_0f87;
																															case 163:
																															case 203:
																																goto IL_0f95;
																															case 215:
																																goto IL_0fe7;
																															case 107:
																																goto IL_0ffa;
																															case 224:
																																goto IL_1008;
																															case 12:
																															case 112:
																																goto IL_1016;
																															case 155:
																																goto IL_102f;
																															case 165:
																																goto IL_103d;
																															case 145:
																																goto IL_104b;
																															case 16:
																															case 118:
																																goto IL_105e;
																															case 178:
																																goto IL_109e;
																															case 168:
																																goto IL_10b2;
																															case 66:
																																goto IL_10c5;
																															case 84:
																																goto IL_10d3;
																															case 23:
																															case 36:
																																goto IL_10de;
																															case 100:
																																goto IL_1103;
																															case 91:
																																goto IL_1111;
																															case 104:
																															case 180:
																																goto IL_111c;
																															case 28:
																																goto IL_1130;
																															case 137:
																																goto IL_116f;
																															case 189:
																																goto IL_117f;
																															case 34:
																																goto IL_118a;
																															case 8:
																															case 14:
																															case 18:
																															case 33:
																															case 56:
																															case 58:
																															case 64:
																															case 77:
																															case 86:
																															case 87:
																															case 96:
																															case 110:
																															case 115:
																															case 133:
																															case 135:
																															case 161:
																															case 164:
																															case 169:
																															case 171:
																															case 183:
																															case 184:
																															case 186:
																															case 199:
																															case 211:
																															case 216:
																															case 217:
																															case 223:
																															case 226:
																															case 229:
																															case 233:
																															case 235:
																															case 241:
																																goto end_IL_04a5;
																															case 2:
																															case 25:
																															case 35:
																															case 42:
																															case 48:
																															case 63:
																															case 67:
																															case 68:
																															case 72:
																															case 75:
																															case 79:
																															case 101:
																															case 111:
																															case 120:
																															case 128:
																															case 140:
																															case 141:
																															case 148:
																															case 150:
																															case 153:
																															case 166:
																															case 167:
																															case 175:
																															case 192:
																															case 197:
																															case 202:
																															case 205:
																															case 220:
																															case 222:
																															case 237:
																															case 240:
																															case 243:
																																goto IL_11a8;
																															case 125:
																																goto IL_11bb;
																															case 144:
																																goto IL_11c5;
																															case 207:
																																goto IL_11d9;
																															case 181:
																																goto IL_11e9;
																															case 134:
																																goto IL_11f9;
																															case 97:
																																goto IL_1209;
																															case 230:
																																goto IL_1219;
																															case 38:
																																goto IL_1229;
																															case 159:
																																goto IL_1239;
																															case 179:
																																goto IL_1249;
																															case 80:
																																goto IL_1259;
																															case 119:
																															case 147:
																																return;
																															}
																															goto end_IL_0498;
																														}
																														num6--;
																														goto IL_11a8;
																														continue;
																														end_IL_0403:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0c61;
																										IL_0ed9:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto IL_11a8;
																										IL_0c61:
																										if (18 >= b)
																										{
																											goto IL_0c6f;
																										}
																										goto IL_0dcf;
																										IL_0c6f:
																										if (18 <= b)
																										{
																											goto IL_0c7a;
																										}
																										goto IL_0ccb;
																										IL_0c7a:
																										((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																										goto IL_0cb8;
																										IL_0cb8:
																										num6 -= 3;
																										goto IL_11a8;
																										IL_0ccb:
																										if (16 >= b)
																										{
																											goto IL_0cd9;
																										}
																										goto IL_0d6c;
																										IL_0cd9:
																										if (16 > b)
																										{
																											goto end_IL_04a5;
																										}
																										goto IL_0ce7;
																										IL_0ce7:
																										array2[num6] = array2[num6 - 1];
																										goto IL_0cff;
																										IL_0cff:
																										array4[num6 - 0] = array4[num6 - 1];
																										goto IL_0d1d;
																										IL_0d1d:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0d41;
																										IL_0d41:
																										array3[num6] = array3[num6 - 1];
																										goto IL_0d59;
																										IL_0d59:
																										num6++;
																										goto IL_11a8;
																										IL_0d6c:
																										if (17 < b)
																										{
																											goto end_IL_04a5;
																										}
																										goto IL_0d7a;
																										IL_0d7a:
																										if (17 > b)
																										{
																											goto end_IL_04a5;
																										}
																										goto IL_0d88;
																										IL_0d88:
																										array2[num6] = 5;
																										goto IL_0d96;
																										IL_0d96:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_0dae;
																										IL_0dae:
																										num6++;
																										goto IL_0dbc;
																										IL_0dbc:
																										ptr2 += 8;
																										goto IL_11a8;
																										IL_0dcf:
																										if (20 >= b)
																										{
																											goto IL_0ddd;
																										}
																										goto IL_0eb4;
																										IL_0ddd:
																										if (20 <= b)
																										{
																											goto IL_0de8;
																										}
																										goto IL_0e30;
																										IL_0de8:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0e01;
																										IL_0e01:
																										array2[num6] = 1;
																										goto IL_0e0f;
																										IL_0e0f:
																										num6++;
																										goto IL_0e1d;
																										IL_0e1d:
																										ptr2 += 16;
																										goto IL_11a8;
																										IL_0e30:
																										if (19 < b)
																										{
																											goto end_IL_04a5;
																										}
																										num = 245;
																										goto IL_0e47;
																										IL_0ecb:
																										if (21 > b)
																										{
																											goto end_IL_04a5;
																										}
																										goto IL_0ed9;
																										IL_0e47:
																										if (19 > b)
																										{
																											goto end_IL_04a5;
																										}
																										goto IL_0e55;
																										IL_0e55:
																										array2[num6 - 1] = 5;
																										goto IL_0e69;
																										IL_0e69:
																										array3[num6 - 1] = ((delegate*<string[], string>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																										goto IL_0ea1;
																										IL_0ea1:
																										ptr2 += 8;
																										goto IL_11a8;
																										IL_0eb4:
																										if (21 < b)
																										{
																											goto end_IL_04a5;
																										}
																										num = 82;
																										goto IL_0ecb;
																									}
																									break;
																								}
																								goto IL_0ef1;
																								IL_117f:
																								if (29 < b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_118a;
																								IL_0ef1:
																								if (26 >= b)
																								{
																									goto IL_0eff;
																								}
																								goto IL_10c5;
																								IL_0eff:
																								if (26 > b)
																								{
																									goto IL_0f0d;
																								}
																								goto IL_105e;
																								IL_0f0d:
																								if (24 >= b)
																								{
																									goto IL_0f1b;
																								}
																								goto IL_0ffa;
																								IL_0f1b:
																								if (24 <= b)
																								{
																									goto IL_0f26;
																								}
																								goto IL_0f70;
																								IL_0f26:
																								((delegate*<string, void>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_0f4f;
																								IL_0f4f:
																								num6--;
																								goto IL_0f5d;
																								IL_0f5d:
																								ptr2 += 8;
																								goto IL_11a8;
																								IL_0f70:
																								if (23 < b)
																								{
																									goto end_IL_04a5;
																								}
																								num = 76;
																								goto IL_0f87;
																								IL_118a:
																								if (29 <= b)
																								{
																								}
																								goto end_IL_04a5;
																								IL_0f87:
																								if (23 > b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_0f95;
																								IL_0f95:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0fe7;
																								IL_0fe7:
																								num6--;
																								goto IL_11a8;
																								IL_0ffa:
																								if (25 < b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_1008;
																								IL_1008:
																								if (25 > b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_1016;
																								IL_1016:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																								goto IL_102f;
																								IL_102f:
																								array2[num6] = 3;
																								goto IL_103d;
																								IL_103d:
																								num6++;
																								goto IL_104b;
																								IL_104b:
																								ptr2 += 16;
																								goto IL_11a8;
																								IL_105e:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_109e;
																								IL_109e:
																								array2[num6 - 2] = 3;
																								goto IL_10b2;
																								IL_10b2:
																								num6--;
																								goto IL_11a8;
																								IL_10c5:
																								if (28 >= b)
																								{
																									goto IL_10d3;
																								}
																								goto IL_117f;
																								IL_10d3:
																								if (28 <= b)
																								{
																									goto IL_10de;
																								}
																								goto IL_1103;
																								IL_10de:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								num = 101;
																								goto IL_11a8;
																								IL_1103:
																								if (27 < b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_1111;
																								IL_1111:
																								if (27 > b)
																								{
																									goto end_IL_04a5;
																								}
																								goto IL_111c;
																								IL_111c:
																								array2[num6 - 1] = 0;
																								goto IL_1130;
																								IL_1130:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_116f;
																								IL_116f:
																								ptr2 += 8;
																								goto IL_11a8;
																							}
																							goto IL_0744;
																						}
																						num = 21;
																						goto IL_04fb;
																						IL_07b9:
																						if (6 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_07c7;
																						IL_07c7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0807;
																						IL_04fb:
																						if (15 > b)
																						{
																							goto IL_0506;
																						}
																						goto IL_0513;
																						IL_0506:
																						if (7 < b)
																						{
																							goto IL_0555;
																						}
																						goto IL_0568;
																						IL_0555:
																						if (11 < b)
																						{
																							goto IL_0861;
																						}
																						goto IL_0a14;
																						IL_0a14:
																						if (11 > b)
																						{
																							goto IL_0a22;
																						}
																						num = 43;
																						goto IL_0b74;
																						IL_0a22:
																						if (9 >= b)
																						{
																							goto IL_0a30;
																						}
																						goto IL_0ada;
																						IL_0a30:
																						if (9 <= b)
																						{
																							goto IL_0a3b;
																						}
																						goto IL_0aab;
																						IL_0a3b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 198;
																						goto IL_0a84;
																						IL_0a84:
																						array2[num6 - 2] = 0;
																						goto IL_0a98;
																						IL_0a98:
																						num6--;
																						goto IL_11a8;
																						IL_0aab:
																						if (8 < b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0ab9;
																						IL_0ab9:
																						if (8 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0ac7;
																						IL_0ac7:
																						num6--;
																						goto IL_11a8;
																						IL_0ada:
																						if (10 < b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0ae8;
																						IL_0ae8:
																						if (10 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0af6;
																						IL_0af6:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0b58;
																						IL_0b58:
																						num6 -= 2;
																						goto IL_11a8;
																						IL_0807:
																						array2[num6 - 2] = 0;
																						goto IL_081b;
																						IL_0b74:
																						array2[num6 - 2] = 0;
																						num = 123;
																						goto IL_0b91;
																						IL_0b91:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_0be5;
																						IL_0be5:
																						num6--;
																						goto IL_0bf3;
																						IL_0bf3:
																						ptr2 += 8;
																						goto IL_11a8;
																						IL_0861:
																						if (13 >= b)
																						{
																							goto IL_086f;
																						}
																						goto IL_0976;
																						IL_086f:
																						if (13 <= b)
																						{
																							goto IL_087d;
																						}
																						goto IL_0955;
																						IL_087d:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_088c;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0934;
																						IL_081b:
																						num6--;
																						num = 72;
																						goto IL_11a8;
																						IL_0651:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_06ef;
																						IL_06ef:
																						array2[num6 - 2] = 0;
																						goto IL_0703;
																						IL_0934:
																						array2[num6] = 5;
																						goto IL_0942;
																						IL_0942:
																						num6++;
																						goto IL_11a8;
																						IL_0955:
																						if (12 < b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0963;
																						IL_0963:
																						if (12 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_11a8;
																						IL_0976:
																						if (14 < b)
																						{
																							goto end_IL_04a5;
																						}
																						num = 7;
																						goto IL_098d;
																						IL_0703:
																						num6--;
																						goto IL_11a8;
																						IL_098d:
																						if (14 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_099b;
																						IL_099b:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_09b9;
																						IL_09b9:
																						ptr2 += 8;
																						goto IL_09c7;
																						IL_09c7:
																						num6--;
																						goto IL_11a8;
																						IL_0568:
																						if (7 > b)
																						{
																							goto IL_0576;
																						}
																						goto IL_0651;
																						IL_0576:
																						if (3 >= b)
																						{
																							goto IL_0581;
																						}
																						goto IL_05ab;
																						IL_0581:
																						if (3 > b)
																						{
																							goto IL_058f;
																						}
																						goto IL_0716;
																						IL_058f:
																						if (1 < b)
																						{
																							goto IL_0627;
																						}
																						num = 234;
																						goto IL_0a01;
																						IL_0513:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_053c;
																						IL_0a01:
																						if (1 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0c06;
																						IL_0c06:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0c1f;
																						IL_0c1f:
																						array2[num6] = 0;
																						goto IL_0c2d;
																						IL_0c2d:
																						num6++;
																						goto IL_0c3b;
																						IL_0c3b:
																						ptr2 += 8;
																						goto IL_11a8;
																						IL_0627:
																						if (2 < b)
																						{
																							goto end_IL_04a5;
																						}
																						num = 70;
																						goto IL_063e;
																						IL_053c:
																						array2[num6 - 1] = 5;
																						goto IL_11a8;
																						IL_063e:
																						if (2 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0744;
																						IL_0744:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0784;
																						IL_0784:
																						array2[num6 - 2] = 0;
																						goto IL_0798;
																						IL_0798:
																						num6--;
																						goto IL_11a8;
																						IL_0716:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0837;
																						IL_0837:
																						ptr2 += 8;
																						goto IL_0845;
																						IL_0845:
																						num6--;
																						num = 240;
																						goto IL_11a8;
																						IL_05ab:
																						if (5 >= b)
																						{
																							goto IL_05b9;
																						}
																						goto IL_07ab;
																						IL_05b9:
																						if (5 <= b)
																						{
																							goto IL_05c4;
																						}
																						goto IL_0609;
																						IL_05c4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_09da;
																						IL_09da:
																						array2[num6 - 2] = 0;
																						goto IL_09ee;
																						IL_09ee:
																						num6--;
																						goto IL_11a8;
																						IL_0609:
																						if (4 < b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0617;
																						IL_0617:
																						if (4 > b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_0693;
																						IL_0693:
																						array2[num6] = 0;
																						goto IL_06a1;
																						IL_06a1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_06c4;
																						IL_06c4:
																						array3[num6] = null;
																						goto IL_06ce;
																						IL_06ce:
																						num6++;
																						goto IL_06dc;
																						IL_06dc:
																						ptr2 += 8;
																						goto IL_11a8;
																						IL_07ab:
																						if (6 < b)
																						{
																							goto end_IL_04a5;
																						}
																						goto IL_07b9;
																						continue;
																						end_IL_0498:
																						break;
																					}
																					goto end_IL_04b5;
																					continue;
																					end_IL_04a5:
																					break;
																					IL_04a5:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_11a8;
																			continue;
																			end_IL_04b5:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_088c:
			while (true)
			{
				IL_088c_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0934_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0942_2:
							num6++;
							while (true)
							{
								IL_11a8_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									num = 5;
									while (true)
									{
										ptr2++;
										num = 60;
										while (true)
										{
											IL_04b5_2:
											if (b >= 1)
											{
												while (b <= 29)
												{
													while (true)
													{
														IL_0498_2:
														if (15 < b)
														{
															while (true)
															{
																IL_0488_2:
																if (22 >= b)
																{
																	while (true)
																	{
																		IL_0478_2:
																		if (22 <= b)
																		{
																			while (true)
																			{
																				IL_0435_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																				while (true)
																				{
																					IL_0416_2:
																					array2[num6 - 2] = 0;
																					num = 253;
																					while (true)
																					{
																						if (num != 253)
																						{
																							if (num != 1234)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 221:
																								goto IL_0416_2;
																							case 1:
																							case 191:
																								goto IL_0435_2;
																							case 73:
																								goto IL_0478_2;
																							case 188:
																								goto IL_0488_2;
																							case 157:
																								goto IL_0498_2;
																							case 4:
																								goto end_IL_0498_2;
																							case 60:
																								goto IL_04b5_2;
																							case 5:
																								goto end_IL_04b5_2;
																							case 26:
																							case 129:
																								goto end_IL_04c5;
																							case 21:
																								goto IL_04fb_2;
																							case 22:
																								goto IL_0506_2;
																							case 41:
																							case 44:
																								goto IL_0513_2;
																							case 47:
																								goto IL_053c_2;
																							case 92:
																								goto IL_0555_2;
																							case 106:
																								goto IL_0568_2;
																							case 83:
																								goto IL_0576_2;
																							case 105:
																								goto IL_0581_2;
																							case 19:
																								goto IL_058f_2;
																							case 15:
																								goto IL_05ab_2;
																							case 27:
																								goto IL_05b9_2;
																							case 10:
																							case 85:
																								goto IL_05c4_2;
																							case 0:
																								goto IL_0609_2;
																							case 37:
																								goto IL_0617_2;
																							case 149:
																								goto IL_0627_2;
																							case 70:
																								goto IL_063e_2;
																							case 69:
																							case 160:
																								goto IL_0651_2;
																							case 152:
																							case 185:
																								goto IL_0693_2;
																							case 39:
																								goto IL_06a1_2;
																							case 154:
																								goto IL_06c4_2;
																							case 95:
																								goto IL_06ce_2;
																							case 143:
																								goto IL_06dc_2;
																							case 190:
																								goto IL_06ef_2;
																							case 131:
																								goto IL_0703_2;
																							case 187:
																							case 195:
																								goto IL_0716_2;
																							case 114:
																							case 196:
																								goto end_IL_0403_2;
																							case 88:
																								goto IL_0784_2;
																							case 170:
																								goto IL_0798_2;
																							case 208:
																								goto IL_07ab_2;
																							case 54:
																								goto IL_07b9_2;
																							case 3:
																							case 182:
																								goto IL_07c7_2;
																							case 49:
																								goto IL_0807_2;
																							case 136:
																								goto IL_081b_2;
																							case 213:
																								goto IL_0837_2;
																							case 139:
																								goto IL_0845_2;
																							case 225:
																								goto IL_0861_2;
																							case 52:
																								goto IL_086f_2;
																							case 138:
																							case 200:
																								goto end_IL_04de;
																							case 102:
																								goto IL_0934_2;
																							case 124:
																								goto IL_0942_2;
																							case 45:
																								goto IL_0955_2;
																							case 57:
																								goto IL_0963_2;
																							case 113:
																								goto IL_0976_2;
																							case 7:
																								goto IL_098d_2;
																							case 93:
																							case 130:
																								goto IL_099b_2;
																							case 24:
																								goto IL_09b9_2;
																							case 212:
																								goto IL_09c7_2;
																							case 227:
																								goto IL_09da_2;
																							case 174:
																								goto IL_09ee_2;
																							case 234:
																								goto IL_0a01_2;
																							case 236:
																								goto IL_0a14_2;
																							case 78:
																								goto IL_0a22_2;
																							case 17:
																								goto IL_0a30_2;
																							case 122:
																							case 173:
																								goto IL_0a3b_2;
																							case 198:
																								goto IL_0a84_2;
																							case 132:
																								goto IL_0a98_2;
																							case 176:
																								goto IL_0aab_2;
																							case 146:
																								goto IL_0ab9_2;
																							case 214:
																							case 232:
																								goto IL_0ac7_2;
																							case 201:
																								goto IL_0ada_2;
																							case 109:
																								goto IL_0ae8_2;
																							case 99:
																							case 194:
																								goto IL_0af6_2;
																							case 90:
																								goto IL_0b58_2;
																							case 43:
																							case 46:
																								goto IL_0b74_2;
																							case 123:
																								goto IL_0b91_2;
																							case 108:
																								goto IL_0be5_2;
																							case 89:
																								goto IL_0bf3_2;
																							case 244:
																							case 246:
																								goto IL_0c06_2;
																							case 204:
																								goto IL_0c1f_2;
																							case 71:
																								goto IL_0c2d_2;
																							case 20:
																								goto IL_0c3b_2;
																							case 30:
																								goto IL_0c61_2;
																							case 13:
																								goto IL_0c6f_2;
																							case 40:
																							case 158:
																								goto IL_0c7a_2;
																							case 218:
																								goto IL_0cb8_2;
																							case 151:
																								goto IL_0ccb_2;
																							case 238:
																								goto IL_0cd9_2;
																							case 61:
																							case 228:
																								goto IL_0ce7_2;
																							case 62:
																								goto IL_0cff_2;
																							case 116:
																								goto IL_0d1d_2;
																							case 6:
																								goto IL_0d41_2;
																							case 31:
																								goto IL_0d59_2;
																							case 231:
																								goto IL_0d6c_2;
																							case 55:
																								goto IL_0d7a_2;
																							case 59:
																							case 98:
																								goto IL_0d88_2;
																							case 121:
																								goto IL_0d96_2;
																							case 126:
																								goto IL_0dae_2;
																							case 32:
																								goto IL_0dbc_2;
																							case 65:
																								goto IL_0dcf_2;
																							case 11:
																								goto IL_0ddd_2;
																							case 51:
																							case 162:
																								goto IL_0de8_2;
																							case 103:
																								goto IL_0e01_2;
																							case 94:
																								goto IL_0e0f_2;
																							case 9:
																								goto IL_0e1d_2;
																							case 206:
																								goto IL_0e30_2;
																							case 245:
																								goto IL_0e47_2;
																							case 193:
																							case 239:
																								goto IL_0e55_2;
																							case 50:
																								goto IL_0e69_2;
																							case 242:
																								goto IL_0ea1_2;
																							case 117:
																								goto IL_0eb4_2;
																							case 82:
																								goto IL_0ecb_2;
																							case 29:
																							case 172:
																								goto IL_0ed9_2;
																							case 210:
																								goto IL_0ef1_2;
																							case 177:
																								goto IL_0eff_2;
																							case 156:
																								goto IL_0f0d_2;
																							case 127:
																								goto IL_0f1b_2;
																							case 74:
																							case 209:
																								goto IL_0f26_2;
																							case 142:
																								goto IL_0f4f_2;
																							case 53:
																								goto IL_0f5d_2;
																							case 219:
																								goto IL_0f70_2;
																							case 76:
																								goto IL_0f87_2;
																							case 163:
																							case 203:
																								goto IL_0f95_2;
																							case 215:
																								goto IL_0fe7_2;
																							case 107:
																								goto IL_0ffa_2;
																							case 224:
																								goto IL_1008_2;
																							case 12:
																							case 112:
																								goto IL_1016_2;
																							case 155:
																								goto IL_102f_2;
																							case 165:
																								goto IL_103d_2;
																							case 145:
																								goto IL_104b_2;
																							case 16:
																							case 118:
																								goto IL_105e_2;
																							case 178:
																								goto IL_109e_2;
																							case 168:
																								goto IL_10b2_2;
																							case 66:
																								goto IL_10c5_2;
																							case 84:
																								goto IL_10d3_2;
																							case 23:
																							case 36:
																								goto IL_10de_2;
																							case 100:
																								goto IL_1103_2;
																							case 91:
																								goto IL_1111_2;
																							case 104:
																							case 180:
																								goto IL_111c_2;
																							case 28:
																								goto IL_1130_2;
																							case 137:
																								goto IL_116f_2;
																							case 189:
																								goto IL_117f_2;
																							case 34:
																								goto IL_118a_2;
																							case 8:
																							case 14:
																							case 18:
																							case 33:
																							case 56:
																							case 58:
																							case 64:
																							case 77:
																							case 86:
																							case 87:
																							case 96:
																							case 110:
																							case 115:
																							case 133:
																							case 135:
																							case 161:
																							case 164:
																							case 169:
																							case 171:
																							case 183:
																							case 184:
																							case 186:
																							case 199:
																							case 211:
																							case 216:
																							case 217:
																							case 223:
																							case 226:
																							case 229:
																							case 233:
																							case 235:
																							case 241:
																								goto end_IL_04a5_2;
																							case 2:
																							case 25:
																							case 35:
																							case 42:
																							case 48:
																							case 63:
																							case 67:
																							case 68:
																							case 72:
																							case 75:
																							case 79:
																							case 101:
																							case 111:
																							case 120:
																							case 128:
																							case 140:
																							case 141:
																							case 148:
																							case 150:
																							case 153:
																							case 166:
																							case 167:
																							case 175:
																							case 192:
																							case 197:
																							case 202:
																							case 205:
																							case 220:
																							case 222:
																							case 237:
																							case 240:
																							case 243:
																								goto IL_11a8_2;
																							case 125:
																								ptr2 = ptr;
																								goto IL_11a8_2;
																							case 144:
																								ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WellKnownGroupWarning.wellKnownGroupWarning_0);
																								num = 125;
																								goto case 125;
																							case 207:
																								array7 = new object[9];
																								goto case 144;
																							case 181:
																								array6 = new long[4];
																								goto case 207;
																							case 134:
																								array5 = new int[7];
																								goto case 181;
																							case 97:
																								array4 = new int[4];
																								goto case 134;
																							case 230:
																								array3 = new object[4];
																								goto case 97;
																							case 38:
																								array2 = new byte[4];
																								goto case 230;
																							case 159:
																								num4 = num2 * 8;
																								goto case 38;
																							case 179:
																								num3 = num2 * 4;
																								goto case 159;
																							case 80:
																								num2 = 1;
																								goto case 179;
																							case 81:
																								goto end_IL_089a;
																							case 119:
																							case 147:
																								return;
																							}
																							continue;
																						}
																						num6--;
																						goto IL_11a8_2;
																						continue;
																						end_IL_0403_2:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		goto IL_0c61_2;
																		IL_0ed9_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_11a8_2;
																		IL_0c61_2:
																		if (18 >= b)
																		{
																			goto IL_0c6f_2;
																		}
																		goto IL_0dcf_2;
																		IL_0c6f_2:
																		if (18 <= b)
																		{
																			goto IL_0c7a_2;
																		}
																		goto IL_0ccb_2;
																		IL_0c7a_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0cb8_2;
																		IL_0cb8_2:
																		num6 -= 3;
																		goto IL_11a8_2;
																		IL_0ccb_2:
																		if (16 >= b)
																		{
																			goto IL_0cd9_2;
																		}
																		goto IL_0d6c_2;
																		IL_0cd9_2:
																		if (16 > b)
																		{
																			goto end_IL_04a5_2;
																		}
																		goto IL_0ce7_2;
																		IL_0ce7_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_0cff_2;
																		IL_0cff_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_0d1d_2;
																		IL_0d1d_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0d41_2;
																		IL_0d41_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_0d59_2;
																		IL_0d59_2:
																		num6++;
																		goto IL_11a8_2;
																		IL_0d6c_2:
																		if (17 < b)
																		{
																			goto end_IL_04a5_2;
																		}
																		goto IL_0d7a_2;
																		IL_0d7a_2:
																		if (17 > b)
																		{
																			goto end_IL_04a5_2;
																		}
																		goto IL_0d88_2;
																		IL_0d88_2:
																		array2[num6] = 5;
																		goto IL_0d96_2;
																		IL_0d96_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_0dae_2;
																		IL_0dae_2:
																		num6++;
																		goto IL_0dbc_2;
																		IL_0dbc_2:
																		ptr2 += 8;
																		goto IL_11a8_2;
																		IL_0dcf_2:
																		if (20 >= b)
																		{
																			goto IL_0ddd_2;
																		}
																		goto IL_0eb4_2;
																		IL_0ddd_2:
																		if (20 <= b)
																		{
																			goto IL_0de8_2;
																		}
																		goto IL_0e30_2;
																		IL_0de8_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0e01_2;
																		IL_0e01_2:
																		array2[num6] = 1;
																		goto IL_0e0f_2;
																		IL_0e0f_2:
																		num6++;
																		goto IL_0e1d_2;
																		IL_0e1d_2:
																		ptr2 += 16;
																		goto IL_11a8_2;
																		IL_0e30_2:
																		if (19 < b)
																		{
																			goto end_IL_04a5_2;
																		}
																		num = 245;
																		goto IL_0e47_2;
																		IL_0ecb_2:
																		if (21 > b)
																		{
																			goto end_IL_04a5_2;
																		}
																		goto IL_0ed9_2;
																		IL_0e47_2:
																		if (19 > b)
																		{
																			goto end_IL_04a5_2;
																		}
																		goto IL_0e55_2;
																		IL_0e55_2:
																		array2[num6 - 1] = 5;
																		goto IL_0e69_2;
																		IL_0e69_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_0ea1_2;
																		IL_0ea1_2:
																		ptr2 += 8;
																		goto IL_11a8_2;
																		IL_0eb4_2:
																		if (21 < b)
																		{
																			goto end_IL_04a5_2;
																		}
																		num = 82;
																		goto IL_0ecb_2;
																	}
																	break;
																}
																goto IL_0ef1_2;
																IL_117f_2:
																if (29 < b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_118a_2;
																IL_0ef1_2:
																if (26 >= b)
																{
																	goto IL_0eff_2;
																}
																goto IL_10c5_2;
																IL_0eff_2:
																if (26 > b)
																{
																	goto IL_0f0d_2;
																}
																goto IL_105e_2;
																IL_0f0d_2:
																if (24 >= b)
																{
																	goto IL_0f1b_2;
																}
																goto IL_0ffa_2;
																IL_0f1b_2:
																if (24 <= b)
																{
																	goto IL_0f26_2;
																}
																goto IL_0f70_2;
																IL_0f26_2:
																((delegate*<string, void>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_0f4f_2;
																IL_0f4f_2:
																num6--;
																goto IL_0f5d_2;
																IL_0f5d_2:
																ptr2 += 8;
																goto IL_11a8_2;
																IL_0f70_2:
																if (23 < b)
																{
																	goto end_IL_04a5_2;
																}
																num = 76;
																goto IL_0f87_2;
																IL_118a_2:
																if (29 <= b)
																{
																}
																goto end_IL_04a5_2;
																IL_0f87_2:
																if (23 > b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_0f95_2;
																IL_0f95_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0fe7_2;
																IL_0fe7_2:
																num6--;
																goto IL_11a8_2;
																IL_0ffa_2:
																if (25 < b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_1008_2;
																IL_1008_2:
																if (25 > b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_1016_2;
																IL_1016_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																goto IL_102f_2;
																IL_102f_2:
																array2[num6] = 3;
																goto IL_103d_2;
																IL_103d_2:
																num6++;
																goto IL_104b_2;
																IL_104b_2:
																ptr2 += 16;
																goto IL_11a8_2;
																IL_105e_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_109e_2;
																IL_109e_2:
																array2[num6 - 2] = 3;
																goto IL_10b2_2;
																IL_10b2_2:
																num6--;
																goto IL_11a8_2;
																IL_10c5_2:
																if (28 >= b)
																{
																	goto IL_10d3_2;
																}
																goto IL_117f_2;
																IL_10d3_2:
																if (28 <= b)
																{
																	goto IL_10de_2;
																}
																goto IL_1103_2;
																IL_10de_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																num = 101;
																goto IL_11a8_2;
																IL_1103_2:
																if (27 < b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_1111_2;
																IL_1111_2:
																if (27 > b)
																{
																	goto end_IL_04a5_2;
																}
																goto IL_111c_2;
																IL_111c_2:
																array2[num6 - 1] = 0;
																goto IL_1130_2;
																IL_1130_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_116f_2;
																IL_116f_2:
																ptr2 += 8;
																goto IL_11a8_2;
															}
															goto IL_0744_2;
														}
														num = 21;
														goto IL_04fb_2;
														IL_081b_2:
														num6--;
														num = 72;
														goto IL_11a8_2;
														IL_0651_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_06ef_2;
														IL_04fb_2:
														if (15 > b)
														{
															goto IL_0506_2;
														}
														goto IL_0513_2;
														IL_0506_2:
														if (7 < b)
														{
															goto IL_0555_2;
														}
														goto IL_0568_2;
														IL_0555_2:
														if (11 < b)
														{
															goto IL_0861_2;
														}
														goto IL_0a14_2;
														IL_0a14_2:
														if (11 > b)
														{
															goto IL_0a22_2;
														}
														num = 43;
														goto IL_0b74_2;
														IL_0a22_2:
														if (9 >= b)
														{
															goto IL_0a30_2;
														}
														goto IL_0ada_2;
														IL_0a30_2:
														if (9 <= b)
														{
															goto IL_0a3b_2;
														}
														goto IL_0aab_2;
														IL_0a3b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 198;
														goto IL_0a84_2;
														IL_0a84_2:
														array2[num6 - 2] = 0;
														goto IL_0a98_2;
														IL_0a98_2:
														num6--;
														goto IL_11a8_2;
														IL_0aab_2:
														if (8 < b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0ab9_2;
														IL_0ab9_2:
														if (8 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0ac7_2;
														IL_0ac7_2:
														num6--;
														goto IL_11a8_2;
														IL_0ada_2:
														if (10 < b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0ae8_2;
														IL_0ae8_2:
														if (10 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0af6_2;
														IL_0af6_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0b58_2;
														IL_0b58_2:
														num6 -= 2;
														goto IL_11a8_2;
														IL_06ef_2:
														array2[num6 - 2] = 0;
														goto IL_0703_2;
														IL_0b74_2:
														array2[num6 - 2] = 0;
														num = 123;
														goto IL_0b91_2;
														IL_0b91_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)CompressedStackRunDataFromBaseString[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0be5_2;
														IL_0be5_2:
														num6--;
														goto IL_0bf3_2;
														IL_0bf3_2:
														ptr2 += 8;
														goto IL_11a8_2;
														IL_0861_2:
														if (13 >= b)
														{
															goto IL_086f_2;
														}
														goto IL_0976_2;
														IL_086f_2:
														if (13 <= b)
														{
															goto end_IL_04de;
														}
														goto IL_0955_2;
														IL_0955_2:
														if (12 < b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0963_2;
														IL_0963_2:
														if (12 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_11a8_2;
														IL_0976_2:
														if (14 < b)
														{
															goto end_IL_04a5_2;
														}
														num = 7;
														goto IL_098d_2;
														IL_0703_2:
														num6--;
														goto IL_11a8_2;
														IL_098d_2:
														if (14 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_099b_2;
														IL_099b_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_09b9_2;
														IL_09b9_2:
														ptr2 += 8;
														goto IL_09c7_2;
														IL_09c7_2:
														num6--;
														goto IL_11a8_2;
														IL_0568_2:
														if (7 > b)
														{
															goto IL_0576_2;
														}
														goto IL_0651_2;
														IL_0576_2:
														if (3 >= b)
														{
															goto IL_0581_2;
														}
														goto IL_05ab_2;
														IL_0581_2:
														if (3 > b)
														{
															goto IL_058f_2;
														}
														goto IL_0716_2;
														IL_058f_2:
														if (1 < b)
														{
															goto IL_0627_2;
														}
														num = 234;
														goto IL_0a01_2;
														IL_0513_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_053c_2;
														IL_0a01_2:
														if (1 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0c06_2;
														IL_0c06_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_0c1f_2;
														IL_0c1f_2:
														array2[num6] = 0;
														goto IL_0c2d_2;
														IL_0c2d_2:
														num6++;
														goto IL_0c3b_2;
														IL_0c3b_2:
														ptr2 += 8;
														goto IL_11a8_2;
														IL_0627_2:
														if (2 < b)
														{
															goto end_IL_04a5_2;
														}
														num = 70;
														goto IL_063e_2;
														IL_053c_2:
														array2[num6 - 1] = 5;
														goto IL_11a8_2;
														IL_063e_2:
														if (2 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0744_2;
														IL_0744_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0784_2;
														IL_0784_2:
														array2[num6 - 2] = 0;
														goto IL_0798_2;
														IL_0798_2:
														num6--;
														goto IL_11a8_2;
														IL_0716_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0837_2;
														IL_0837_2:
														ptr2 += 8;
														goto IL_0845_2;
														IL_0845_2:
														num6--;
														num = 240;
														goto IL_11a8_2;
														IL_05ab_2:
														if (5 >= b)
														{
															goto IL_05b9_2;
														}
														goto IL_07ab_2;
														IL_05b9_2:
														if (5 <= b)
														{
															goto IL_05c4_2;
														}
														goto IL_0609_2;
														IL_05c4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_09da_2;
														IL_09da_2:
														array2[num6 - 2] = 0;
														goto IL_09ee_2;
														IL_09ee_2:
														num6--;
														goto IL_11a8_2;
														IL_0609_2:
														if (4 < b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0617_2;
														IL_0617_2:
														if (4 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_0693_2;
														IL_0693_2:
														array2[num6] = 0;
														goto IL_06a1_2;
														IL_06a1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_06c4_2;
														IL_06c4_2:
														array3[num6] = null;
														goto IL_06ce_2;
														IL_06ce_2:
														num6++;
														goto IL_06dc_2;
														IL_06dc_2:
														ptr2 += 8;
														goto IL_11a8_2;
														IL_07ab_2:
														if (6 < b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_07b9_2;
														IL_07b9_2:
														if (6 > b)
														{
															goto end_IL_04a5_2;
														}
														goto IL_07c7_2;
														IL_07c7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0807_2;
														IL_0807_2:
														array2[num6 - 2] = 0;
														goto IL_081b_2;
														continue;
														end_IL_0498_2:
														break;
													}
													continue;
													end_IL_04a5_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_11a8_2;
											continue;
											end_IL_04b5_2:
											break;
										}
										continue;
										end_IL_04c5:
										break;
									}
									continue;
									end_IL_04de:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_088c_2;
					}
					continue;
					end_IL_089a:
					break;
				}
				break;
			}
		}
	}

	public Class187()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 2;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										num = 39;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct98.setCursorTopFunctionPtr);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01fe:
																	if (b >= 1)
																	{
																		num = 18;
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01de:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01ce:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01be:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01ae:
																										if (3 < b)
																										{
																											num = 92;
																											while (num != 92)
																											{
																												if (num != 1073)
																												{
																													goto IL_0320;
																												}
																												switch (num)
																												{
																												case 13:
																												case 85:
																													goto IL_01ae;
																												case 23:
																													goto IL_01be;
																												case 51:
																													goto IL_01ce;
																												case 32:
																													goto IL_01de;
																												case 18:
																													goto IL_01ee;
																												case 76:
																													goto IL_01fe;
																												case 19:
																													goto end_IL_01fe;
																												case 17:
																												case 52:
																													goto end_IL_0211;
																												case 7:
																													goto IL_022c;
																												case 10:
																												case 72:
																													goto IL_0243;
																												case 5:
																													goto IL_0283;
																												case 54:
																													goto IL_0297;
																												case 25:
																												case 84:
																													goto IL_02aa;
																												case 56:
																													goto IL_02d3;
																												case 49:
																													goto IL_02e1;
																												case 75:
																													goto IL_02f4;
																												case 12:
																													goto IL_02ff;
																												case 29:
																													goto IL_030d;
																												case 57:
																												case 82:
																													goto IL_0320;
																												case 47:
																													goto IL_0397;
																												case 45:
																													goto IL_03aa;
																												case 16:
																													goto IL_03b5;
																												case 59:
																												case 69:
																													goto IL_03cc;
																												case 33:
																													goto IL_03da;
																												case 14:
																												case 73:
																													goto IL_03f1;
																												case 37:
																													goto IL_0412;
																												case 30:
																													goto IL_041d;
																												case 0:
																												case 44:
																													goto IL_042b;
																												case 35:
																													goto IL_0439;
																												case 24:
																													goto IL_045c;
																												case 22:
																													goto IL_0466;
																												case 81:
																													goto IL_0474;
																												case 41:
																													goto IL_0484;
																												case 83:
																													goto IL_048f;
																												case 31:
																												case 77:
																													goto IL_049a;
																												case 1:
																												case 15:
																												case 26:
																												case 28:
																												case 42:
																												case 46:
																												case 53:
																												case 62:
																												case 63:
																												case 67:
																												case 70:
																												case 74:
																												case 78:
																												case 80:
																													goto end_IL_019b;
																												case 4:
																													goto IL_04d6;
																												case 11:
																													goto IL_04e4;
																												case 38:
																													goto IL_04f2;
																												case 3:
																												case 6:
																												case 27:
																												case 34:
																												case 36:
																												case 40:
																												case 48:
																												case 55:
																												case 66:
																												case 68:
																												case 79:
																													goto end_IL_0221;
																												case 71:
																													goto end_IL_0500;
																												case 39:
																													goto end_IL_0513;
																												case 64:
																													goto end_IL_051d;
																												case 2:
																													goto end_IL_0528;
																												case 21:
																													goto end_IL_0546;
																												case 8:
																												case 20:
																													goto end_IL_055b;
																												case 43:
																													goto end_IL_0574;
																												case 9:
																												case 50:
																													goto end_IL_0584;
																												case 60:
																													goto end_IL_0594;
																												case 61:
																													goto end_IL_05a4;
																												case 58:
																												case 65:
																													goto IL_05bf;
																												}
																												continue;
																												end_IL_019b:
																												break;
																											}
																											break;
																										}
																										goto IL_022c;
																										IL_0243:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0283;
																										IL_0283:
																										array[num5 - 2] = 0;
																										goto IL_0297;
																										IL_022c:
																										if (3 > b)
																										{
																											break;
																										}
																										num = 10;
																										goto IL_0243;
																										IL_0297:
																										num5--;
																										goto end_IL_0221;
																									}
																									break;
																								}
																								goto IL_02f4;
																								IL_0397:
																								num5 -= 2;
																								goto end_IL_0221;
																								IL_02f4:
																								if (2 > b)
																								{
																									goto IL_02ff;
																								}
																								goto IL_0320;
																								IL_02ff:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_030d;
																								IL_030d:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0320:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 47;
																								goto IL_0397;
																							}
																							break;
																						}
																						goto IL_02aa;
																						IL_02e1:
																						num5--;
																						goto end_IL_0221;
																						IL_02aa:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02d3;
																						IL_02d3:
																						ptr2 += 8;
																						goto IL_02e1;
																					}
																					break;
																				}
																				goto IL_03aa;
																				IL_0484:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_048f;
																				IL_03aa:
																				if (6 >= b)
																				{
																					goto IL_03b5;
																				}
																				goto IL_0412;
																				IL_03b5:
																				if (6 <= b)
																				{
																					goto end_IL_0221;
																				}
																				num = 59;
																				goto IL_03cc;
																				IL_048f:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_049a;
																				IL_03cc:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_03da;
																				IL_03da:
																				if (5 > b)
																				{
																					break;
																				}
																				num = 73;
																				goto IL_03f1;
																				IL_049a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0221;
																				IL_03f1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 79;
																				goto end_IL_0221;
																				IL_0412:
																				if (7 >= b)
																				{
																					goto IL_041d;
																				}
																				goto IL_0484;
																				IL_041d:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_042b;
																				IL_042b:
																				array[num5] = 0;
																				goto IL_0439;
																				IL_0439:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_045c;
																				IL_045c:
																				array2[num5] = null;
																				goto IL_0466;
																				IL_0466:
																				num5++;
																				goto IL_0474;
																				IL_0474:
																				ptr2 += 8;
																				goto end_IL_0221;
																			}
																			break;
																			IL_01ee:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d6;
																	IL_04e4:
																	num5++;
																	goto IL_04f2;
																	IL_04f2:
																	ptr2 += 8;
																	goto end_IL_0221;
																	IL_04d6:
																	array[num5] = 0;
																	goto IL_04e4;
																	continue;
																	end_IL_01fe:
																	break;
																}
																continue;
																end_IL_0211:
																break;
															}
															continue;
															end_IL_0221:
															break;
														}
														continue;
													}
													goto IL_05bf;
													IL_05bf:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0500:
													break;
												}
												continue;
												end_IL_0513:
												break;
											}
											continue;
											end_IL_051d:
											break;
										}
										continue;
										end_IL_0528:
										break;
									}
									continue;
									end_IL_0546:
									break;
								}
								continue;
								end_IL_055b:
								break;
							}
							continue;
							end_IL_0574:
							break;
						}
						continue;
						end_IL_0584:
						break;
					}
					continue;
					end_IL_0594:
					break;
				}
				continue;
				end_IL_05a4:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 106;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeftAltPressedDTString.ExecuteWorkItemFlushWriteAsyncd);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 134;
													while (true)
													{
														if (num == 134)
														{
															goto IL_02e8;
														}
														if (num != 1115)
														{
															goto IL_04cd;
														}
														switch (num)
														{
														case 3:
															goto end_IL_0227;
														case 44:
															goto end_IL_023a;
														case 38:
															goto end_IL_0245;
														case 73:
															goto end_IL_024f;
														case 51:
															goto end_IL_025a;
														case 102:
															goto end_IL_026f;
														case 34:
														case 65:
															goto end_IL_0284;
														case 106:
															goto end_IL_0294;
														case 46:
														case 113:
															goto end_IL_02a4;
														case 61:
															goto end_IL_02b4;
														case 62:
															goto end_IL_02cd;
														case 7:
														case 23:
														case 37:
														case 40:
														case 43:
														case 57:
														case 68:
														case 74:
														case 77:
														case 86:
														case 97:
														case 119:
														case 122:
															goto IL_02e8;
														case 52:
														case 83:
															goto IL_02f8;
														case 60:
															goto IL_0301;
														case 17:
															goto IL_030f;
														case 36:
															goto IL_031d;
														case 78:
															goto IL_032b;
														case 15:
															goto IL_0339;
														case 41:
															goto IL_0344;
														case 42:
															goto IL_0352;
														case 12:
														case 114:
															goto IL_0360;
														case 13:
															goto IL_036b;
														case 99:
															goto IL_037e;
														case 50:
															goto IL_038c;
														case 87:
														case 109:
															goto IL_039a;
														case 56:
															goto IL_0408;
														case 30:
														case 111:
															goto IL_041b;
														case 123:
															goto IL_0464;
														case 108:
															goto IL_0478;
														case 91:
															goto IL_048b;
														case 95:
															goto IL_0496;
														case 26:
														case 29:
															goto IL_04a4;
														case 69:
															goto IL_04cd;
														case 70:
															goto IL_04db;
														case 53:
															goto IL_04ee;
														case 8:
															goto IL_04fc;
														case 98:
														case 121:
															goto IL_050a;
														case 90:
														case 117:
															goto IL_0522;
														case 19:
														case 94:
															goto IL_0530;
														case 47:
														case 125:
															goto IL_053b;
														case 80:
															goto IL_0549;
														case 9:
														case 63:
															goto IL_0557;
														case 107:
															goto IL_0573;
														case 35:
														case 100:
															goto IL_0581;
														case 32:
															goto IL_058f;
														case 21:
														case 66:
															goto IL_059d;
														case 79:
															goto IL_05b1;
														case 127:
															goto IL_05f0;
														case 67:
														case 112:
															goto IL_0603;
														case 81:
															goto IL_061f;
														case 72:
														case 84:
															goto IL_062a;
														case 93:
															goto IL_066a;
														case 71:
															goto IL_067e;
														case 124:
															goto IL_0691;
														case 104:
															goto IL_069c;
														case 64:
															goto IL_06aa;
														case 10:
														case 88:
															goto IL_06b8;
														case 58:
															goto IL_06d1;
														case 24:
															goto IL_06df;
														case 48:
															goto IL_06ed;
														case 1:
															goto IL_0700;
														case 105:
														case 115:
															goto IL_070e;
														case 120:
															goto IL_0725;
														case 59:
															goto IL_0748;
														case 2:
															goto IL_0752;
														case 27:
															goto IL_0769;
														case 55:
															goto IL_0787;
														case 33:
															goto IL_0795;
														case 118:
															goto IL_07a3;
														case 0:
														case 5:
														case 6:
														case 11:
														case 14:
														case 16:
														case 18:
														case 20:
														case 22:
														case 25:
														case 28:
														case 31:
														case 39:
														case 45:
														case 49:
														case 54:
														case 75:
														case 76:
														case 82:
														case 85:
														case 89:
														case 92:
														case 96:
														case 103:
														case 110:
														case 116:
														case 126:
															goto IL_07b6;
														case 4:
														case 101:
															goto IL_07db;
														}
														continue;
														IL_0787:
														array[num4] = 0;
														goto IL_0795;
														IL_0795:
														num4++;
														goto IL_07a3;
														IL_02e8:
														if (num5 != 1)
														{
															goto IL_02f8;
														}
														goto IL_07db;
														IL_07db:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														IL_02f8:
														b = *ptr2;
														goto IL_0301;
														IL_0301:
														ptr2++;
														goto IL_030f;
														IL_030f:
														if (b >= 1)
														{
															goto IL_031d;
														}
														goto IL_07b6;
														IL_031d:
														if (b <= 12)
														{
															goto IL_032b;
														}
														num = 14;
														goto IL_07b6;
														IL_032b:
														if (6 >= b)
														{
															goto IL_0339;
														}
														goto IL_0522;
														IL_0339:
														if (6 <= b)
														{
															goto IL_02e8;
														}
														goto IL_0344;
														IL_0344:
														if (3 >= b)
														{
															goto IL_0352;
														}
														goto IL_048b;
														IL_0352:
														if (3 > b)
														{
															goto IL_0360;
														}
														goto IL_041b;
														IL_0360:
														if (1 >= b)
														{
															goto IL_036b;
														}
														goto IL_037e;
														IL_036b:
														if (1 <= b)
														{
														}
														goto IL_07b6;
														IL_037e:
														if (2 >= b)
														{
															goto IL_038c;
														}
														goto IL_07b6;
														IL_038c:
														if (2 <= b)
														{
															goto IL_039a;
														}
														goto IL_07b6;
														IL_039a:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0408;
														IL_0408:
														num4 -= 2;
														goto IL_02e8;
														IL_041b:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														num = 123;
														goto IL_0464;
														IL_0464:
														array[num4 - 2] = 0;
														goto IL_0478;
														IL_0478:
														num4--;
														goto IL_02e8;
														IL_048b:
														if (4 >= b)
														{
															goto IL_0496;
														}
														goto IL_04ee;
														IL_0496:
														if (4 <= b)
														{
															goto IL_04a4;
														}
														goto IL_07b6;
														IL_04a4:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_04cd;
														IL_04cd:
														ptr2 += 8;
														goto IL_04db;
														IL_04db:
														num4--;
														goto IL_02e8;
														IL_04ee:
														if (5 >= b)
														{
															goto IL_04fc;
														}
														goto IL_07b6;
														IL_04fc:
														if (5 <= b)
														{
															goto IL_050a;
														}
														goto IL_07b6;
														IL_050a:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_02e8;
														IL_0522:
														if (9 < b)
														{
															goto IL_0530;
														}
														goto IL_061f;
														IL_0530:
														if (11 < b)
														{
															goto IL_053b;
														}
														goto IL_0573;
														IL_053b:
														if (12 >= b)
														{
															goto IL_0549;
														}
														goto IL_07b6;
														IL_0549:
														if (12 <= b)
														{
															goto IL_0557;
														}
														goto IL_07b6;
														IL_0557:
														byte* num6 = ptr2;
														num5 = 1;
														ptr2 = num6 + -200;
														goto IL_02e8;
														IL_0573:
														if (11 > b)
														{
															goto IL_0581;
														}
														goto IL_0603;
														IL_0581:
														if (10 >= b)
														{
															goto IL_058f;
														}
														goto IL_07b6;
														IL_058f:
														if (10 <= b)
														{
															goto IL_059d;
														}
														goto IL_07b6;
														IL_059d:
														array[num4 - 1] = 0;
														goto IL_05b1;
														IL_05b1:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]) = ((delegate*<int, int>)FormatProviderNameIdentifier[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
														goto IL_05f0;
														IL_05f0:
														ptr2 += 8;
														goto IL_02e8;
														IL_0603:
														num4--;
														num = 37;
														goto IL_02e8;
														IL_061f:
														if (9 <= b)
														{
															goto IL_062a;
														}
														goto IL_0691;
														IL_062a:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_066a;
														IL_066a:
														array[num4 - 2] = 0;
														goto IL_067e;
														IL_067e:
														num4--;
														goto IL_02e8;
														IL_0691:
														if (7 < b)
														{
															goto IL_069c;
														}
														goto IL_0700;
														IL_069c:
														if (8 >= b)
														{
															goto IL_06aa;
														}
														goto IL_07b6;
														IL_06aa:
														if (8 <= b)
														{
															goto IL_06b8;
														}
														goto IL_07b6;
														IL_06b8:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
														goto IL_06d1;
														IL_06d1:
														array[num4] = 0;
														goto IL_06df;
														IL_06df:
														num4++;
														goto IL_06ed;
														IL_06ed:
														ptr2 += 8;
														goto IL_02e8;
														IL_0700:
														if (7 <= b)
														{
															goto IL_070e;
														}
														goto IL_07b6;
														IL_070e:
														array[num4] = 0;
														num = 120;
														goto IL_0725;
														IL_0725:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0748;
														IL_0748:
														array2[num4] = null;
														goto IL_0752;
														IL_0752:
														num4++;
														num = 27;
														goto IL_0769;
														IL_0769:
														ptr2 += 8;
														goto IL_02e8;
														IL_07a3:
														ptr2 += 8;
														goto IL_02e8;
														IL_07b6:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0787;
														continue;
														end_IL_0227:
														break;
													}
													continue;
													end_IL_023a:
													break;
												}
												continue;
												end_IL_0245:
												break;
											}
											continue;
											end_IL_024f:
											break;
										}
										continue;
										end_IL_025a:
										break;
									}
									continue;
									end_IL_026f:
									break;
								}
								continue;
								end_IL_0284:
								break;
							}
							continue;
							end_IL_0294:
							break;
						}
						continue;
						end_IL_02a4:
						break;
					}
					continue;
					end_IL_02b4:
					break;
				}
				continue;
				end_IL_02cd:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPublisherExportable.MaxCharCountSkipVerification);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 126;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02cc:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02af:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_029c:
																						if (12 >= b)
																						{
																							num = 155;
																							while (true)
																							{
																								if (num != 155)
																								{
																									if (num != 1136)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 135:
																										goto IL_029c;
																									case 70:
																										goto IL_02af;
																									case 53:
																										goto end_IL_02af;
																									case 28:
																										goto IL_02cc;
																									case 76:
																										goto end_IL_02cc;
																									case 126:
																										goto end_IL_02dc;
																									case 62:
																										goto end_IL_02ec;
																									case 80:
																										goto IL_0302;
																									case 4:
																									case 68:
																										goto IL_0310;
																									case 85:
																									case 111:
																										goto IL_031e;
																									case 19:
																										goto IL_032c;
																									case 99:
																									case 102:
																										goto IL_0337;
																									case 59:
																										goto IL_0376;
																									case 22:
																										goto IL_0389;
																									case 131:
																										goto IL_03a5;
																									case 88:
																										goto IL_03b0;
																									case 66:
																									case 90:
																										goto IL_03c3;
																									case 40:
																										goto IL_03e1;
																									case 123:
																										goto IL_03ef;
																									case 30:
																									case 133:
																										goto IL_040b;
																									case 79:
																										goto IL_0419;
																									case 33:
																									case 45:
																										goto IL_0424;
																									case 54:
																										goto IL_044d;
																									case 9:
																										goto IL_045b;
																									case 134:
																										goto IL_047c;
																									case 21:
																									case 96:
																										goto end_IL_0289;
																									case 95:
																										goto IL_0495;
																									case 26:
																									case 97:
																										goto IL_04a3;
																									case 104:
																										goto IL_04bc;
																									case 49:
																										goto IL_04d3;
																									case 1:
																										goto IL_04e1;
																									case 24:
																									case 35:
																										goto IL_04f4;
																									case 113:
																										goto IL_0534;
																									case 73:
																										goto IL_0548;
																									case 16:
																									case 136:
																										goto IL_055b;
																									case 67:
																										goto IL_0569;
																									case 38:
																									case 52:
																										goto IL_0577;
																									case 74:
																										goto IL_05a0;
																									case 107:
																									case 138:
																										goto IL_05b9;
																									case 143:
																										goto IL_05d1;
																									case 12:
																									case 145:
																										goto IL_05e8;
																									case 18:
																										goto IL_05f6;
																									case 89:
																										goto IL_060e;
																									case 140:
																										goto IL_061c;
																									case 58:
																									case 91:
																										goto IL_063d;
																									case 114:
																										goto IL_064b;
																									case 71:
																									case 124:
																										goto IL_0656;
																									case 36:
																										goto IL_0664;
																									case 44:
																									case 55:
																										goto IL_0677;
																									case 13:
																										goto IL_068e;
																									case 129:
																										goto IL_06b1;
																									case 31:
																										goto IL_06bb;
																									case 25:
																										goto IL_06c9;
																									case 42:
																										goto IL_06dc;
																									case 94:
																										goto IL_06ea;
																									case 39:
																									case 46:
																										goto IL_06f8;
																									case 105:
																										goto IL_073c;
																									case 29:
																										goto IL_0759;
																									case 82:
																									case 119:
																										goto IL_076c;
																									case 5:
																										goto IL_07ac;
																									case 87:
																										goto IL_07c0;
																									case 142:
																										goto IL_07d3;
																									case 130:
																										goto IL_07de;
																									case 2:
																										goto IL_07ec;
																									case 51:
																										goto IL_0811;
																									case 8:
																									case 116:
																										goto IL_0825;
																									case 115:
																										goto IL_0841;
																									case 15:
																										goto IL_084f;
																									case 41:
																									case 118:
																										goto IL_085a;
																									case 86:
																										goto IL_08bc;
																									case 6:
																									case 7:
																									case 10:
																									case 14:
																									case 17:
																									case 23:
																									case 27:
																									case 34:
																									case 43:
																									case 48:
																									case 50:
																									case 56:
																									case 57:
																									case 60:
																									case 69:
																									case 72:
																									case 77:
																									case 84:
																									case 92:
																									case 100:
																									case 101:
																									case 110:
																									case 122:
																									case 125:
																									case 128:
																									case 132:
																									case 141:
																									case 146:
																										goto end_IL_02bc;
																									case 0:
																									case 11:
																									case 20:
																									case 37:
																									case 47:
																									case 65:
																									case 75:
																									case 78:
																									case 81:
																									case 93:
																									case 103:
																									case 109:
																									case 112:
																									case 117:
																									case 121:
																									case 127:
																									case 144:
																									case 147:
																										goto end_IL_02f7;
																									case 108:
																										goto end_IL_08e8;
																									case 139:
																										goto end_IL_08fb;
																									case 32:
																										goto end_IL_0905;
																									case 148:
																										goto end_IL_0910;
																									case 61:
																									case 98:
																										goto end_IL_0920;
																									case 137:
																										goto end_IL_0930;
																									case 3:
																									case 106:
																										goto end_IL_0940;
																									case 63:
																										goto end_IL_0950;
																									case 64:
																										goto end_IL_0960;
																									case 83:
																									case 120:
																										goto IL_097b;
																									}
																									continue;
																								}
																								if (12 > b)
																								{
																									goto IL_063d;
																								}
																								goto IL_076c;
																								IL_076c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07ac;
																								IL_07c0:
																								num5--;
																								goto end_IL_02f7;
																								IL_07ac:
																								array[num5 - 2] = 0;
																								goto IL_07c0;
																								IL_063d:
																								if (10 >= b)
																								{
																									goto IL_064b;
																								}
																								goto IL_06dc;
																								IL_064b:
																								if (10 > b)
																								{
																									goto IL_0656;
																								}
																								goto IL_0677;
																								IL_0656:
																								if (9 < b)
																								{
																									goto end_IL_02bc;
																								}
																								goto IL_0664;
																								IL_0664:
																								if (9 <= b)
																								{
																									goto end_IL_02f7;
																								}
																								goto end_IL_02bc;
																								IL_0677:
																								array[num5] = 0;
																								num = 13;
																								goto IL_068e;
																								IL_068e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_06b1;
																								IL_06b1:
																								array2[num5] = null;
																								goto IL_06bb;
																								IL_06bb:
																								num5++;
																								goto IL_06c9;
																								IL_06c9:
																								ptr2 += 8;
																								goto end_IL_02f7;
																								IL_06dc:
																								if (11 < b)
																								{
																									goto end_IL_02bc;
																								}
																								goto IL_06ea;
																								IL_06ea:
																								if (11 > b)
																								{
																									goto end_IL_02bc;
																								}
																								goto IL_06f8;
																								IL_06f8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_073c;
																								IL_073c:
																								array[num5 - 2] = 0;
																								num = 29;
																								goto IL_0759;
																								IL_0759:
																								num5--;
																								goto end_IL_02f7;
																								continue;
																								end_IL_0289:
																								break;
																							}
																							break;
																						}
																						goto IL_07d3;
																						IL_0825:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02f7;
																						IL_0841:
																						if (13 < b)
																						{
																							goto end_IL_02bc;
																						}
																						goto IL_084f;
																						IL_07d3:
																						if (14 < b)
																						{
																							goto IL_07de;
																						}
																						num = 51;
																						goto IL_0811;
																						IL_07de:
																						if (15 < b)
																						{
																							goto end_IL_02bc;
																						}
																						goto IL_07ec;
																						IL_07ec:
																						if (15 <= b)
																						{
																							num = 69;
																						}
																						goto end_IL_02bc;
																						IL_085a:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_08bc;
																						IL_084f:
																						if (13 > b)
																						{
																							goto end_IL_02bc;
																						}
																						goto IL_085a;
																						IL_0811:
																						if (14 <= b)
																						{
																							num = 8;
																							goto IL_0825;
																						}
																						goto IL_0841;
																						IL_08bc:
																						num5 -= 2;
																						num = 47;
																						goto end_IL_02f7;
																					}
																					goto IL_0487;
																				}
																				goto IL_0302;
																				IL_03c3:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_03e1;
																				IL_0302:
																				if (8 > b)
																				{
																					goto IL_0310;
																				}
																				goto IL_05b9;
																				IL_0310:
																				if (4 < b)
																				{
																					goto IL_031e;
																				}
																				goto IL_03a5;
																				IL_031e:
																				if (6 >= b)
																				{
																					goto IL_032c;
																				}
																				goto IL_040b;
																				IL_032c:
																				if (6 <= b)
																				{
																					goto IL_0337;
																				}
																				goto IL_0389;
																				IL_0337:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0376;
																				IL_0376:
																				num5 -= 3;
																				goto end_IL_02f7;
																				IL_0389:
																				if (5 < b)
																				{
																					num = 92;
																					goto end_IL_02bc;
																				}
																				goto IL_05d1;
																				IL_03e1:
																				ptr2 += 8;
																				goto IL_03ef;
																				IL_05d1:
																				if (5 > b)
																				{
																					goto end_IL_02bc;
																				}
																				num = 145;
																				goto IL_05e8;
																				IL_03ef:
																				num5--;
																				num = 109;
																				goto end_IL_02f7;
																				IL_05e8:
																				array[num5] = 5;
																				goto IL_05f6;
																				IL_05f6:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_060e;
																				IL_060e:
																				num5++;
																				goto IL_061c;
																				IL_061c:
																				ptr2 += 8;
																				goto end_IL_02f7;
																				IL_040b:
																				if (7 < b)
																				{
																					goto end_IL_02bc;
																				}
																				goto IL_0419;
																				IL_0419:
																				if (7 > b)
																				{
																					num = 84;
																					goto end_IL_02bc;
																				}
																				goto IL_0424;
																				IL_0424:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_044d;
																				IL_044d:
																				ptr2 += 8;
																				goto IL_045b;
																				IL_045b:
																				num5--;
																				goto end_IL_02f7;
																				IL_05b9:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02f7;
																				IL_03a5:
																				if (4 > b)
																				{
																					goto IL_03b0;
																				}
																				goto IL_03c3;
																				IL_03b0:
																				if (2 >= b)
																				{
																					goto IL_047c;
																				}
																				goto IL_055b;
																				IL_055b:
																				if (3 < b)
																				{
																					goto end_IL_02bc;
																				}
																				goto IL_0569;
																				IL_0569:
																				if (3 > b)
																				{
																					goto end_IL_02bc;
																				}
																				goto IL_0577;
																				IL_0577:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_05a0;
																				IL_05a0:
																				array[num5 - 1] = 5;
																				goto end_IL_02f7;
																				IL_047c:
																				if (2 > b)
																				{
																					goto IL_0487;
																				}
																				goto IL_04f4;
																				IL_0487:
																				if (1 < b)
																				{
																					goto end_IL_02bc;
																				}
																				goto IL_0495;
																				IL_0495:
																				if (1 > b)
																				{
																					goto end_IL_02bc;
																				}
																				goto IL_04a3;
																				IL_04a3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04bc;
																				IL_04bc:
																				array[num5] = 0;
																				num = 49;
																				goto IL_04d3;
																				IL_04d3:
																				num5++;
																				goto IL_04e1;
																				IL_04e1:
																				ptr2 += 8;
																				goto end_IL_02f7;
																				IL_04f4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0534;
																				IL_0534:
																				array[num5 - 2] = 0;
																				goto IL_0548;
																				IL_0548:
																				num5--;
																				goto end_IL_02f7;
																				continue;
																				end_IL_02af:
																				break;
																			}
																			continue;
																			end_IL_02bc:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f7;
																	continue;
																	end_IL_02cc:
																	break;
																}
																continue;
																end_IL_02dc:
																break;
															}
															continue;
															end_IL_02ec:
															break;
														}
														continue;
														end_IL_02f7:
														break;
													}
													continue;
												}
												goto IL_097b;
												IL_097b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08e8:
												break;
											}
											continue;
											end_IL_08fb:
											break;
										}
										continue;
										end_IL_0905:
										break;
									}
									continue;
									end_IL_0910:
									break;
								}
								continue;
								end_IL_0920:
								break;
							}
							continue;
							end_IL_0930:
							break;
						}
						continue;
						end_IL_0940:
						break;
					}
					continue;
					end_IL_0950:
					break;
				}
				continue;
				end_IL_0960:
				break;
			}
		}
	}

	private static int smethod_3()
	{
		int num = 8;
		int num2 = 2;
		num = 4;
		object obj = new int[4];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 147;
		num3 = 49;
		((int[])obj)[0] = 49;
		obj = obj2;
		num2 = 1;
		num3 = 52;
		num3 = 4;
		((int[])obj)[1] = 4;
		obj = obj2;
		num2 = 14;
		num3 = 7;
		num2 = 2;
		num3 = 215;
		num3 = 43;
		((int[])obj)[2] = 43;
		obj = obj2;
		num2 = 6;
		num3 = 2;
		num2 = 3;
		num3 = 18;
		num3 = 9;
		((int[])obj)[3] = 9;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 20;
			num3 = 5;
			num2 = 4;
			if (num >= 4)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgumentItemNotExistIdentifier.IListWrapperSourceFilePath);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_026d:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_024d:
																				if (6 >= b)
																				{
																					goto IL_047a;
																				}
																				while (true)
																				{
																					IL_0240:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0230:
																							if (10 >= b)
																							{
																								num = 128;
																								while (true)
																								{
																									if (num != 128)
																									{
																										if (num != 1109)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 75:
																											goto IL_0230;
																										case 38:
																										case 107:
																											goto IL_0240;
																										case 98:
																											goto IL_024d;
																										case 103:
																											goto end_IL_024d;
																										case 35:
																											goto IL_026d;
																										case 26:
																											goto end_IL_026d;
																										case 21:
																										case 49:
																											goto end_IL_027d;
																										case 44:
																											goto IL_0298;
																										case 0:
																											goto IL_02a6;
																										case 60:
																											goto IL_02b6;
																										case 20:
																										case 67:
																											goto IL_02c3;
																										case 19:
																										case 68:
																											goto IL_02df;
																										case 10:
																										case 82:
																											goto IL_02f2;
																										case 54:
																											goto IL_0306;
																										case 56:
																											goto IL_035a;
																										case 3:
																											goto IL_0368;
																										case 86:
																											goto IL_037b;
																										case 23:
																										case 32:
																											goto IL_0389;
																										case 5:
																											goto IL_03a2;
																										case 43:
																										case 87:
																											goto IL_03b5;
																										case 48:
																											goto IL_03c3;
																										case 52:
																										case 72:
																											goto IL_03d1;
																										case 24:
																											goto IL_0411;
																										case 83:
																											goto IL_0425;
																										case 95:
																											goto IL_0438;
																										case 105:
																											goto IL_0446;
																										case 50:
																										case 112:
																											goto IL_0467;
																										case 100:
																											goto IL_047a;
																										case 42:
																										case 59:
																											goto IL_0488;
																										case 25:
																										case 102:
																											goto IL_0496;
																										case 17:
																										case 29:
																											goto IL_04a1;
																										case 2:
																											goto IL_04af;
																										case 96:
																										case 108:
																											goto IL_04bd;
																										case 45:
																											goto IL_04cb;
																										case 79:
																											goto IL_04ee;
																										case 117:
																											goto IL_04f8;
																										case 63:
																											goto IL_0506;
																										case 118:
																											goto IL_0519;
																										case 16:
																										case 80:
																											goto IL_0527;
																										case 97:
																											goto end_IL_021d;
																										case 69:
																											goto IL_057b;
																										case 41:
																											goto IL_058e;
																										case 7:
																										case 34:
																											goto IL_059c;
																										case 46:
																											goto IL_05a7;
																										case 53:
																											goto IL_05ba;
																										case 28:
																											goto IL_05c8;
																										case 9:
																										case 13:
																											goto IL_05d6;
																										case 30:
																											goto IL_0616;
																										case 6:
																											goto IL_062a;
																										case 4:
																										case 121:
																											goto IL_0646;
																										case 55:
																											goto IL_066f;
																										case 111:
																											goto IL_067d;
																										case 31:
																										case 37:
																											goto IL_0690;
																										case 47:
																											goto IL_06d0;
																										case 33:
																											goto IL_06e4;
																										case 1:
																										case 15:
																										case 18:
																										case 27:
																										case 39:
																										case 62:
																										case 66:
																										case 70:
																										case 71:
																										case 73:
																										case 78:
																										case 89:
																										case 90:
																										case 92:
																										case 93:
																										case 114:
																										case 115:
																										case 116:
																										case 119:
																											goto end_IL_025d;
																										case 77:
																											goto IL_0717;
																										case 74:
																											goto IL_0725;
																										case 76:
																											goto IL_0733;
																										case 8:
																										case 11:
																										case 12:
																										case 14:
																										case 36:
																										case 61:
																										case 88:
																										case 91:
																										case 94:
																										case 99:
																										case 101:
																										case 106:
																										case 110:
																											goto end_IL_028d;
																										case 120:
																											goto end_IL_0741;
																										case 22:
																											goto end_IL_0754;
																										case 81:
																											goto end_IL_075e;
																										case 40:
																											goto end_IL_0769;
																										case 113:
																											goto end_IL_077e;
																										case 64:
																										case 104:
																											goto end_IL_0793;
																										case 109:
																											goto end_IL_07a3;
																										case 57:
																										case 65:
																											goto end_IL_07b3;
																										case 84:
																											goto end_IL_07c3;
																										case 85:
																											goto end_IL_07d3;
																										case 51:
																										case 58:
																											goto IL_07ee;
																										}
																										continue;
																									}
																									if (10 > b)
																									{
																										goto end_IL_025d;
																									}
																									goto IL_0467;
																									IL_0467:
																									num5--;
																									goto end_IL_028d;
																									continue;
																									end_IL_021d:
																									break;
																								}
																								break;
																							}
																							goto IL_0298;
																							IL_02a6:
																							if (11 > b)
																							{
																								goto end_IL_025d;
																							}
																							goto IL_02c3;
																							IL_02c3:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_028d;
																							IL_0298:
																							if (11 < b)
																							{
																								goto end_IL_025d;
																							}
																							goto IL_02a6;
																						}
																						break;
																					}
																					goto IL_02b6;
																					IL_0368:
																					ptr2 += 8;
																					goto end_IL_028d;
																					IL_02b6:
																					if (9 > b)
																					{
																						goto IL_02df;
																					}
																					goto IL_02f2;
																					IL_02df:
																					if (7 >= b)
																					{
																						goto IL_037b;
																					}
																					goto IL_03b5;
																					IL_03b5:
																					if (8 < b)
																					{
																						goto end_IL_025d;
																					}
																					goto IL_03c3;
																					IL_03c3:
																					if (8 > b)
																					{
																						goto end_IL_025d;
																					}
																					goto IL_03d1;
																					IL_03d1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0411;
																					IL_0411:
																					array[num5 - 2] = 0;
																					goto IL_0425;
																					IL_0425:
																					num5--;
																					goto end_IL_028d;
																					IL_037b:
																					if (7 > b)
																					{
																						goto end_IL_025d;
																					}
																					goto IL_0389;
																					IL_0389:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_03a2;
																					IL_03a2:
																					array[num5] = 0;
																					goto IL_0438;
																					IL_0438:
																					num5++;
																					goto IL_0446;
																					IL_0446:
																					ptr2 += 8;
																					goto end_IL_028d;
																					IL_02f2:
																					array[num5 - 2] = 0;
																					goto IL_0306;
																					IL_0306:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_035a;
																					IL_035a:
																					num5--;
																					goto IL_0368;
																				}
																				goto IL_0567;
																				IL_06e4:
																				num5--;
																				goto end_IL_028d;
																				IL_047a:
																				if (6 > b)
																				{
																					goto IL_0488;
																				}
																				goto IL_0690;
																				IL_0488:
																				if (3 < b)
																				{
																					goto IL_0496;
																				}
																				goto IL_058e;
																				IL_0496:
																				if (4 < b)
																				{
																					goto IL_04a1;
																				}
																				goto IL_0519;
																				IL_04a1:
																				if (5 < b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_04af;
																				IL_04af:
																				if (5 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_04bd;
																				IL_04bd:
																				array[num5] = 0;
																				goto IL_04cb;
																				IL_04cb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04ee;
																				IL_04ee:
																				array2[num5] = null;
																				goto IL_04f8;
																				IL_04f8:
																				num5++;
																				goto IL_0506;
																				IL_0506:
																				ptr2 += 8;
																				goto end_IL_028d;
																				IL_0519:
																				if (4 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_0527;
																				IL_0527:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0567;
																				IL_0567:
																				array[num5 - 2] = 0;
																				goto IL_057b;
																				IL_057b:
																				num5--;
																				goto end_IL_028d;
																				IL_058e:
																				if (3 > b)
																				{
																					goto IL_059c;
																				}
																				goto IL_0646;
																				IL_059c:
																				if (1 >= b)
																				{
																					goto IL_05a7;
																				}
																				goto IL_05ba;
																				IL_05a7:
																				if (1 > b)
																				{
																				}
																				goto end_IL_025d;
																				IL_05ba:
																				if (2 < b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_05c8;
																				IL_05c8:
																				if (2 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_05d6;
																				IL_05d6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0616;
																				IL_0616:
																				array[num5 - 2] = 0;
																				goto IL_062a;
																				IL_062a:
																				num5--;
																				num = 36;
																				goto end_IL_028d;
																				IL_0646:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_066f;
																				IL_066f:
																				ptr2 += 8;
																				goto IL_067d;
																				IL_067d:
																				num5--;
																				goto end_IL_028d;
																				IL_0690:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06d0;
																				IL_06d0:
																				array[num5 - 2] = 0;
																				goto IL_06e4;
																				continue;
																				end_IL_024d:
																				break;
																			}
																			continue;
																			end_IL_025d:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0717;
																	IL_0733:
																	ptr2 += 8;
																	goto end_IL_028d;
																	IL_0725:
																	num5++;
																	goto IL_0733;
																	IL_0717:
																	array[num5] = 0;
																	goto IL_0725;
																	continue;
																	end_IL_026d:
																	break;
																}
																continue;
																end_IL_027d:
																break;
															}
															continue;
															end_IL_028d:
															break;
														}
														continue;
													}
													goto IL_07ee;
													IL_07ee:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0741:
													break;
												}
												continue;
												end_IL_0754:
												break;
											}
											continue;
											end_IL_075e:
											break;
										}
										continue;
										end_IL_0769:
										break;
									}
									continue;
									end_IL_077e:
									break;
								}
								continue;
								end_IL_0793:
								break;
							}
							continue;
							end_IL_07a3:
							break;
						}
						continue;
						end_IL_07b3:
						break;
					}
					continue;
					end_IL_07c3:
					break;
				}
				continue;
				end_IL_07d3:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 25;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 64;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 59;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												IL_051a:
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PssgetIsConsoleEnabled.InheritedObjectTypeInvalidCall);
												while (true)
												{
													IL_0510:
													byte* ptr2 = ptr;
													while (true)
													{
														IL_04fd:
														if (num4 != 1)
														{
															while (true)
															{
																IL_0248:
																byte b = *ptr2;
																while (true)
																{
																	IL_0238:
																	ptr2++;
																	while (true)
																	{
																		IL_0228:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_0208:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01f8:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01e8:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01db:
																											if (2 > b)
																											{
																												while (1 >= b)
																												{
																													while (1 <= b)
																													{
																														num = 98;
																														while (num != 98)
																														{
																															if (num != 1079)
																															{
																																goto end_IL_0228;
																															}
																															switch (num)
																															{
																															case 75:
																																goto IL_01b8;
																															case 44:
																																goto IL_01cb;
																															case 72:
																																goto IL_01db;
																															case 54:
																															case 73:
																																goto IL_01e8;
																															case 5:
																																goto IL_01f8;
																															case 33:
																																goto IL_0208;
																															case 8:
																																goto IL_0218;
																															case 14:
																																goto IL_0228;
																															case 6:
																																goto IL_0238;
																															case 13:
																															case 37:
																																goto IL_0248;
																															case 7:
																															case 62:
																																goto IL_0253;
																															case 80:
																																goto IL_02c1;
																															case 2:
																															case 91:
																																goto IL_02d4;
																															case 56:
																																goto IL_02eb;
																															case 4:
																															case 90:
																																goto IL_02f9;
																															case 41:
																																goto IL_0339;
																															case 46:
																																goto IL_034d;
																															case 34:
																															case 55:
																																goto IL_0360;
																															case 53:
																																goto IL_0389;
																															case 74:
																																goto IL_0397;
																															case 36:
																															case 77:
																																goto IL_03aa;
																															case 23:
																																goto IL_03b5;
																															case 81:
																																goto IL_03c3;
																															case 51:
																																goto IL_03d1;
																															case 22:
																															case 43:
																																goto IL_03df;
																															case 31:
																															case 58:
																																goto IL_03f7;
																															case 47:
																															case 60:
																																goto IL_0402;
																															case 29:
																																goto IL_0410;
																															case 26:
																															case 45:
																																goto IL_041e;
																															case 83:
																																goto IL_043a;
																															case 0:
																															case 12:
																																goto IL_0445;
																															case 48:
																																goto IL_045c;
																															case 71:
																																goto IL_047f;
																															case 87:
																																goto IL_0489;
																															case 39:
																																goto IL_0497;
																															case 15:
																															case 20:
																															case 21:
																															case 27:
																															case 32:
																															case 35:
																															case 49:
																															case 50:
																															case 57:
																															case 61:
																															case 66:
																															case 68:
																															case 69:
																															case 79:
																															case 82:
																															case 86:
																															case 89:
																																goto end_IL_01a5;
																															case 38:
																																goto IL_04d3;
																															case 88:
																																goto IL_04e1;
																															case 63:
																																goto IL_04ef;
																															case 1:
																															case 3:
																															case 9:
																															case 11:
																															case 16:
																															case 19:
																															case 30:
																															case 52:
																															case 65:
																															case 67:
																															case 85:
																																goto IL_04fd;
																															case 28:
																																goto IL_0510;
																															case 70:
																																goto IL_051a;
																															case 84:
																																goto end_IL_0228;
																															case 10:
																																goto end_IL_0525;
																															case 76:
																																goto end_IL_053a;
																															case 59:
																																goto end_IL_054f;
																															case 18:
																																goto end_IL_055f;
																															case 40:
																																goto end_IL_056f;
																															case 42:
																															case 64:
																																goto end_IL_057a;
																															case 24:
																																goto end_IL_058a;
																															case 25:
																																goto end_IL_059a;
																															case 17:
																															case 78:
																																goto IL_05be;
																															}
																															continue;
																															end_IL_01a5:
																															break;
																														}
																														break;
																														IL_01b8:;
																													}
																													break;
																													IL_01cb:;
																												}
																												break;
																											}
																											goto IL_0253;
																											IL_02c1:
																											num5 -= 2;
																											goto IL_04fd;
																											IL_0253:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_02c1;
																										}
																										break;
																									}
																									goto IL_02d4;
																									IL_0339:
																									array[num5 - 2] = 0;
																									goto IL_034d;
																									IL_02d4:
																									if (3 < b)
																									{
																										break;
																									}
																									num = 56;
																									goto IL_02eb;
																									IL_034d:
																									num5--;
																									goto IL_04fd;
																									IL_02eb:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_02f9;
																									IL_02f9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0339;
																								}
																								break;
																							}
																							goto IL_0360;
																							IL_0397:
																							num5--;
																							goto IL_04fd;
																							IL_0360:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0389;
																							IL_0389:
																							ptr2 += 8;
																							goto IL_0397;
																						}
																						break;
																					}
																					goto IL_03aa;
																					IL_0497:
																					ptr2 += 8;
																					goto IL_04fd;
																					IL_03aa:
																					if (6 >= b)
																					{
																						goto IL_03b5;
																					}
																					goto IL_03f7;
																					IL_03b5:
																					if (6 <= b)
																					{
																						goto IL_04fd;
																					}
																					goto IL_03c3;
																					IL_03c3:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_03d1;
																					IL_03d1:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_03df;
																					IL_03df:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_04fd;
																					IL_03f7:
																					if (7 < b)
																					{
																						goto IL_0402;
																					}
																					goto IL_043a;
																					IL_0402:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0410;
																					IL_0410:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_041e;
																					IL_041e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_04fd;
																					IL_043a:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0445;
																					IL_0445:
																					array[num5] = 0;
																					num = 48;
																					goto IL_045c;
																					IL_045c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_047f;
																					IL_047f:
																					array2[num5] = null;
																					goto IL_0489;
																					IL_0489:
																					num5++;
																					goto IL_0497;
																				}
																				break;
																				IL_0218:;
																			}
																		}
																		else
																		{
																			num = 27;
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04d3;
																		IL_04e1:
																		num5++;
																		goto IL_04ef;
																		IL_04ef:
																		ptr2 += 8;
																		goto IL_04fd;
																		IL_04d3:
																		array[num5] = 0;
																		goto IL_04e1;
																		continue;
																		end_IL_0228:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_05be;
														IL_05be:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
													break;
												}
												break;
											}
											continue;
											end_IL_0525:
											break;
										}
										continue;
										end_IL_053a:
										break;
									}
									continue;
									end_IL_054f:
									break;
								}
								continue;
								end_IL_055f:
								break;
							}
							continue;
							end_IL_056f:
							break;
						}
						continue;
						end_IL_057a:
						break;
					}
					continue;
					end_IL_058a:
					break;
				}
				continue;
				end_IL_059a:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TOKENPRIVILEGEgetIsAutoLayout.SetLastWriteTimeAddMonths);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0276:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		num = 72;
																		while (true)
																		{
																			IL_0256:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0249:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0239:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0229:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (true)
																											{
																												IL_0206:
																												if (1 > b)
																												{
																													num = 114;
																													while (num != 114)
																													{
																														if (num != 1095)
																														{
																															goto IL_0413;
																														}
																														switch (num)
																														{
																														case 77:
																															goto IL_0206;
																														case 51:
																															goto IL_0219;
																														case 67:
																															goto IL_0229;
																														case 79:
																															goto IL_0239;
																														case 92:
																															goto IL_0249;
																														case 72:
																															goto IL_0256;
																														case 50:
																															goto IL_0263;
																														case 96:
																															goto IL_0276;
																														case 49:
																															goto end_IL_0276;
																														case 1:
																														case 52:
																															goto end_IL_0286;
																														case 19:
																														case 32:
																															goto IL_02ac;
																														case 0:
																															goto IL_02ba;
																														case 4:
																															goto IL_02dd;
																														case 26:
																															goto IL_02e7;
																														case 24:
																															goto IL_02f5;
																														case 29:
																														case 61:
																															goto IL_0308;
																														case 31:
																															goto IL_0313;
																														case 21:
																														case 22:
																															goto IL_031e;
																														case 17:
																															goto IL_032c;
																														case 25:
																															goto IL_033f;
																														case 62:
																															goto IL_0352;
																														case 38:
																														case 47:
																															goto IL_0360;
																														case 44:
																														case 57:
																															goto IL_036b;
																														case 66:
																															goto IL_0379;
																														case 69:
																															goto IL_0392;
																														case 63:
																														case 68:
																															goto IL_039d;
																														case 23:
																														case 73:
																															goto IL_03f0;
																														case 48:
																															goto IL_0413;
																														case 16:
																															goto IL_0421;
																														case 36:
																														case 76:
																															goto IL_0434;
																														case 54:
																														case 84:
																															goto IL_049b;
																														case 60:
																															goto IL_04c4;
																														case 9:
																															goto IL_04d2;
																														case 87:
																															goto IL_04e5;
																														case 14:
																															goto IL_04f9;
																														case 13:
																														case 98:
																															goto IL_0515;
																														case 33:
																															goto IL_052e;
																														case 59:
																															goto IL_053c;
																														case 30:
																															goto IL_054a;
																														case 100:
																															goto IL_055d;
																														case 104:
																															goto IL_0570;
																														case 46:
																														case 105:
																															goto IL_0583;
																														case 90:
																															goto IL_059c;
																														case 10:
																															goto IL_05a7;
																														case 55:
																														case 82:
																															goto IL_05b2;
																														case 18:
																														case 35:
																															goto IL_05d0;
																														case 88:
																															goto IL_05e6;
																														case 2:
																														case 3:
																														case 20:
																														case 28:
																														case 37:
																														case 42:
																														case 53:
																														case 64:
																														case 71:
																														case 78:
																														case 80:
																														case 81:
																														case 85:
																														case 86:
																														case 91:
																														case 94:
																														case 95:
																														case 97:
																														case 99:
																														case 102:
																														case 107:
																															goto end_IL_01f3;
																														case 5:
																														case 6:
																														case 12:
																														case 27:
																														case 34:
																														case 39:
																														case 43:
																														case 45:
																														case 56:
																														case 58:
																														case 65:
																														case 70:
																														case 89:
																															goto end_IL_0296;
																														case 74:
																															goto end_IL_0604;
																														case 11:
																															goto end_IL_0617;
																														case 106:
																															goto end_IL_0621;
																														case 103:
																															goto end_IL_062c;
																														case 15:
																														case 101:
																															goto end_IL_0641;
																														case 93:
																															goto end_IL_0651;
																														case 40:
																														case 41:
																															goto end_IL_0661;
																														case 7:
																															goto end_IL_0671;
																														case 8:
																															goto end_IL_0681;
																														case 75:
																														case 83:
																															goto IL_069c;
																														}
																														continue;
																														end_IL_01f3:
																														break;
																													}
																													break;
																												}
																												goto IL_0515;
																												IL_053c:
																												num5++;
																												goto IL_054a;
																												IL_054a:
																												ptr2 += 8;
																												goto end_IL_0296;
																												IL_0515:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_052e;
																												IL_052e:
																												array[num5] = 0;
																												goto IL_053c;
																											}
																											break;
																											IL_0219:;
																										}
																										break;
																									}
																									goto IL_049b;
																									IL_04d2:
																									num5--;
																									goto end_IL_0296;
																									IL_049b:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04c4;
																									IL_04c4:
																									ptr2 += 8;
																									goto IL_04d2;
																								}
																								break;
																							}
																							goto IL_059c;
																							IL_05d0:
																							if (4 < b)
																							{
																								num = 81;
																								break;
																							}
																							goto IL_05e6;
																							IL_059c:
																							if (3 >= b)
																							{
																								goto IL_05a7;
																							}
																							num = 35;
																							goto IL_05d0;
																							IL_05a7:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_05b2;
																							IL_05b2:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0296;
																							IL_05e6:
																							if (4 <= b)
																							{
																								goto end_IL_0296;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_02ac;
																					IL_02f5:
																					ptr2 += 8;
																					goto end_IL_0296;
																					IL_02ac:
																					array[num5] = 0;
																					goto IL_02ba;
																					IL_02ba:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02dd;
																					IL_02dd:
																					array2[num5] = null;
																					goto IL_02e7;
																					IL_02e7:
																					num5++;
																					goto IL_02f5;
																				}
																				break;
																			}
																			num = 29;
																			goto IL_0308;
																			IL_04f9:
																			num5--;
																			num = 70;
																			goto end_IL_0296;
																			IL_0570:
																			num5 -= 2;
																			goto end_IL_0296;
																			IL_0308:
																			if (8 < b)
																			{
																				goto IL_0313;
																			}
																			goto IL_0352;
																			IL_0313:
																			if (9 < b)
																			{
																				goto IL_031e;
																			}
																			goto IL_033f;
																			IL_031e:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_032c;
																			IL_032c:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_033f:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0583;
																			IL_0583:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0296;
																			IL_0352:
																			if (8 > b)
																			{
																				goto IL_0360;
																			}
																			goto IL_0434;
																			IL_0360:
																			if (6 < b)
																			{
																				goto IL_036b;
																			}
																			goto IL_0392;
																			IL_036b:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0379;
																			IL_0379:
																			if (7 > b)
																			{
																				num = 71;
																				break;
																			}
																			goto IL_03f0;
																			IL_0434:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0570;
																			IL_03f0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0413;
																			IL_0413:
																			array[num5] = 0;
																			goto IL_0421;
																			IL_0421:
																			num5++;
																			goto IL_055d;
																			IL_055d:
																			ptr2 += 8;
																			goto end_IL_0296;
																			IL_0392:
																			if (6 > b)
																			{
																				num = 3;
																				break;
																			}
																			goto IL_039d;
																			IL_039d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e5;
																			IL_04e5:
																			array[num5 - 2] = 0;
																			goto IL_04f9;
																		}
																		break;
																		IL_0263:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0296;
																continue;
																end_IL_0276:
																break;
															}
															continue;
															end_IL_0286:
															break;
														}
														continue;
														end_IL_0296:
														break;
													}
													continue;
												}
												goto IL_069c;
												IL_069c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0604:
												break;
											}
											continue;
											end_IL_0617:
											break;
										}
										continue;
										end_IL_0621:
										break;
									}
									continue;
									end_IL_062c:
									break;
								}
								continue;
								end_IL_0641:
								break;
							}
							continue;
							end_IL_0651:
							break;
						}
						continue;
						end_IL_0661:
						break;
					}
					continue;
					end_IL_0671:
					break;
				}
				continue;
				end_IL_0681:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TYPEFLAGFRESTRICTEDOpCodes.SEPEndgetMessage);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02e3:
															byte b = *ptr2;
															while (true)
															{
																IL_02ca:
																ptr2++;
																num = 45;
																while (true)
																{
																	IL_02ba:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_029d:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_028a:
																						if (7 < b)
																						{
																							num = 41;
																							while (true)
																							{
																								IL_027a:
																								if (8 >= b)
																								{
																									while (8 <= b)
																									{
																										while (true)
																										{
																											IL_021f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 84;
																											while (true)
																											{
																												IL_0209:
																												array[num5 - 2] = 0;
																												while (true)
																												{
																													IL_01f0:
																													num5--;
																													num = 112;
																													while (num != 112)
																													{
																														if (num != 1093)
																														{
																															goto IL_027a;
																														}
																														switch (num)
																														{
																														case 17:
																															goto IL_01f0;
																														case 84:
																															goto IL_0209;
																														case 12:
																														case 46:
																															goto IL_021f;
																														case 15:
																															goto IL_026a;
																														case 41:
																														case 69:
																															goto IL_027a;
																														case 44:
																															goto IL_028a;
																														case 63:
																															goto IL_029d;
																														case 101:
																															goto IL_02aa;
																														case 45:
																															goto IL_02ba;
																														case 61:
																															goto IL_02ca;
																														case 35:
																														case 56:
																															goto IL_02e3;
																														case 33:
																															goto IL_02ee;
																														case 42:
																															goto IL_02fc;
																														case 43:
																															goto IL_0312;
																														case 31:
																														case 57:
																															goto IL_0325;
																														case 49:
																															goto IL_0333;
																														case 59:
																															goto IL_0343;
																														case 19:
																														case 32:
																															goto IL_0351;
																														case 55:
																															goto IL_036a;
																														case 25:
																															goto IL_0378;
																														case 58:
																														case 70:
																															goto IL_0388;
																														case 21:
																															goto IL_03b1;
																														case 74:
																															goto IL_03c4;
																														case 76:
																															goto IL_03d7;
																														case 72:
																															goto IL_03e5;
																														case 16:
																														case 26:
																															goto IL_03f3;
																														case 77:
																															goto IL_0433;
																														case 81:
																															goto IL_044c;
																														case 50:
																															goto IL_045a;
																														case 28:
																														case 87:
																															goto IL_0476;
																														case 67:
																															goto IL_0484;
																														case 88:
																															goto IL_0497;
																														case 79:
																														case 92:
																															goto IL_04aa;
																														case 94:
																														case 95:
																															goto IL_04ba;
																														case 75:
																															goto IL_04fa;
																														case 51:
																															goto IL_050e;
																														case 97:
																															goto IL_0521;
																														case 36:
																															goto IL_0544;
																														case 3:
																															goto IL_054e;
																														case 5:
																															goto IL_055c;
																														case 20:
																														case 98:
																															goto IL_056f;
																														case 100:
																															goto IL_058b;
																														case 90:
																														case 102:
																															goto IL_059e;
																														case 89:
																															goto IL_05a9;
																														case 53:
																														case 91:
																															goto IL_05b4;
																														case 22:
																															goto IL_05f4;
																														case 7:
																															goto IL_0608;
																														case 0:
																														case 1:
																														case 4:
																														case 8:
																														case 10:
																														case 11:
																														case 13:
																														case 14:
																														case 18:
																														case 39:
																														case 47:
																														case 52:
																														case 65:
																														case 68:
																														case 80:
																														case 82:
																														case 93:
																														case 103:
																														case 105:
																															goto end_IL_026a;
																														case 23:
																															goto IL_063b;
																														case 54:
																															goto IL_0652;
																														case 96:
																															goto IL_0660;
																														case 6:
																														case 9:
																														case 24:
																														case 27:
																														case 34:
																														case 40:
																														case 48:
																														case 64:
																														case 99:
																														case 104:
																															goto end_IL_01dd;
																														case 38:
																															goto end_IL_066e;
																														case 37:
																															goto end_IL_0681;
																														case 66:
																															goto end_IL_068b;
																														case 60:
																															goto end_IL_0696;
																														case 73:
																															goto end_IL_06ab;
																														case 30:
																														case 83:
																															goto end_IL_06c0;
																														case 62:
																															goto end_IL_06d0;
																														case 2:
																														case 71:
																															goto end_IL_06e0;
																														case 85:
																															goto end_IL_06f0;
																														case 86:
																															goto end_IL_0700;
																														case 29:
																														case 78:
																															goto IL_071b;
																														}
																														continue;
																														end_IL_01dd:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_02ba;
																										continue;
																										end_IL_026a:
																										break;
																										IL_026a:;
																									}
																									break;
																								}
																								goto IL_0476;
																								IL_056f:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_02ba;
																								IL_0476:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0484;
																								IL_0484:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_056f;
																							}
																							break;
																						}
																						goto IL_0343;
																						IL_05f4:
																						array[num5 - 2] = 0;
																						goto IL_0608;
																						IL_0608:
																						num5--;
																						goto end_IL_02ba;
																						IL_0343:
																						if (7 <= b)
																						{
																							goto IL_0351;
																						}
																						goto IL_059e;
																						IL_0351:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_036a;
																						IL_036a:
																						array[num5] = 0;
																						goto IL_0378;
																						IL_0378:
																						num5++;
																						goto IL_03c4;
																						IL_03c4:
																						ptr2 += 8;
																						goto end_IL_02ba;
																						IL_059e:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_05a9;
																						IL_05a9:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_05b4;
																						IL_05b4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05f4;
																					}
																					break;
																				}
																				goto IL_02ee;
																				IL_0544:
																				array2[num5] = null;
																				goto IL_054e;
																				IL_02ee:
																				if (5 > b)
																				{
																					goto IL_02fc;
																				}
																				goto IL_04aa;
																				IL_02fc:
																				if (2 >= b)
																				{
																					goto IL_0312;
																				}
																				num = 57;
																				goto IL_0325;
																				IL_054e:
																				num5++;
																				goto IL_055c;
																				IL_0325:
																				if (3 >= b)
																				{
																					goto IL_0333;
																				}
																				goto IL_03d7;
																				IL_0333:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0388;
																				IL_0388:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03b1;
																				IL_03b1:
																				ptr2 += 8;
																				goto IL_0497;
																				IL_0497:
																				num5--;
																				goto end_IL_02ba;
																				IL_03d7:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_03e5;
																				IL_03e5:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_03f3;
																				IL_03f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0433;
																				IL_0433:
																				array[num5 - 2] = 0;
																				goto IL_058b;
																				IL_058b:
																				num5--;
																				goto end_IL_02ba;
																				IL_0312:
																				if (2 > b)
																				{
																					goto IL_044c;
																				}
																				goto IL_04ba;
																				IL_04ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04fa;
																				IL_04fa:
																				array[num5 - 2] = 0;
																				goto IL_050e;
																				IL_050e:
																				num5--;
																				goto end_IL_02ba;
																				IL_044c:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_045a;
																				IL_045a:
																				if (1 > b)
																				{
																					num = 4;
																				}
																				break;
																				IL_055c:
																				ptr2 += 8;
																				goto end_IL_02ba;
																				IL_04aa:
																				array[num5] = 0;
																				goto IL_0521;
																				IL_0521:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0544;
																			}
																			break;
																			IL_02aa:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_063b;
																	IL_0660:
																	ptr2 += 8;
																	break;
																	IL_0652:
																	num5++;
																	goto IL_0660;
																	IL_063b:
																	array[num5] = 0;
																	num = 54;
																	goto IL_0652;
																	continue;
																	end_IL_02ba:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_071b;
													IL_071b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_066e:
													break;
												}
												continue;
												end_IL_0681:
												break;
											}
											continue;
											end_IL_068b:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e0:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	static Class187()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 15;
			while (true)
			{
				if (num != 15)
				{
					if (num == 996)
					{
						switch (num)
						{
						case 1:
							goto end_IL_0045;
						case 0:
						case 2:
						case 4:
						case 5:
						case 6:
						case 7:
						case 8:
							goto IL_006d;
						case 3:
							return;
						}
						continue;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				goto IL_006d;
				IL_006d:
				string_0 = "MuteGunCS";
				return;
				continue;
				end_IL_0045:
				break;
			}
		}
	}
}
