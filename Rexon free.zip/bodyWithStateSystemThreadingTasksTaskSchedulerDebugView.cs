using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 181)]
internal struct bodyWithStateSystemThreadingTasksTaskSchedulerDebugView
{
	internal static bodyWithStateSystemThreadingTasksTaskSchedulerDebugView CharArraygetScheduledConcurrent/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 00 00 00 48 48 00 00 00 00 00 00 23 23 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 03 04 00 00 00 02 02 00 00 00 05 00 00 00 65 65 00 00 00 06 01 00 00 00 01 01 00 00 00 01 00 00 00 00 00 00 00 00 03 04 00 00 00 02 02 00 00 00 06 07 00 00 00 02 02 00 00 00 08 00 00 00 0A 0A 00 00 00 08 00 00 00 05 05 00 00 00 09 0A 00 00 00 00 00 00 00 00 0B 0C 06 07 00 00 00 02 02 00 00 00 08 00 00 00 0A 0A 00 00 00 08 00 00 00 05 05 00 00 00 09 0A 00 00 00 00 00 00 00 00 0B 0C) */;
}
