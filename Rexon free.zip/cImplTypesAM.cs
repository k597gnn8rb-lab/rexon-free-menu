using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 56)]
internal struct cImplTypesAM
{
	internal static cImplTypesAM encodingCompressedStack/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 01 01 00 00 00 03 00 00 00 02 02 00 00 00 04 00 00 00 03 03 00 00 00 05 00 00 00 04 04 00 00 00 06 00 00 00 05 05 00 00 00 07 08) */;
}
