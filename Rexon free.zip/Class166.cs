using System;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Join Random Ghost Code", "Room", "Cycles through ghost room codes.", false, 7, ModType.const_0, false)]
internal class Class166 : MonoBehaviour
{
	private static string[] string_0;

	private float float_0;

	private int int_0;

	private static int int_1;

	private static double double_0;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] ToSerializedStringCustomQueryInterfaceResult;

	private static IntPtr[] CommonAceWindowLeft;

	private static IntPtr[] ModeASCIIgetApplicationUrl;

	private static IntPtr[] DispIdAttributeNow;

	private static IntPtr[] CreatorGroupServerSidCMSFILEHASHALGORITHM;

	private static IntPtr[] EventKeywordsGreaterThan;

	private unsafe static int smethod_0(int int_2)
	{
		int num = 28;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetLatencyModeStatusProcessorArchitectureAMD.RemotingSurrogateSelectorgetRead);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_023d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_021d:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0210:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_0200:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_01f0:
																									if (9 > b)
																									{
																										num = 112;
																										while (num != 112)
																										{
																											if (num != 1093)
																											{
																												goto IL_0200;
																											}
																											switch (num)
																											{
																											case 76:
																												goto IL_01f0;
																											case 50:
																												goto IL_0200;
																											case 4:
																												goto IL_0210;
																											case 43:
																												goto IL_021d;
																											case 69:
																												goto IL_022d;
																											case 87:
																												goto IL_023d;
																											case 100:
																												goto end_IL_023d;
																											case 92:
																											case 93:
																												goto end_IL_024d;
																											case 14:
																											case 57:
																												goto IL_0268;
																											case 62:
																												goto IL_0284;
																											case 30:
																											case 35:
																												goto IL_028f;
																											case 0:
																												goto IL_029d;
																											case 6:
																											case 65:
																												goto IL_02ad;
																											case 67:
																												goto IL_030f;
																											case 60:
																											case 80:
																												goto IL_0322;
																											case 79:
																												goto IL_0362;
																											case 8:
																												goto IL_0376;
																											case 3:
																											case 85:
																												goto IL_0389;
																											case 78:
																												goto IL_0397;
																											case 17:
																											case 24:
																												goto IL_03a5;
																											case 96:
																												goto IL_03cd;
																											case 54:
																												goto IL_03db;
																											case 37:
																												goto IL_03e9;
																											case 52:
																											case 86:
																												goto IL_03f4;
																											case 88:
																												goto IL_041d;
																											case 9:
																												goto IL_042b;
																											case 12:
																											case 20:
																												goto IL_043e;
																											case 84:
																												goto IL_044c;
																											case 36:
																											case 45:
																												goto IL_0457;
																											case 31:
																												goto IL_0470;
																											case 40:
																												goto IL_047e;
																											case 61:
																												goto IL_048c;
																											case 32:
																											case 68:
																												goto IL_04ad;
																											case 42:
																												goto IL_04bb;
																											case 63:
																												goto IL_04e7;
																											case 21:
																												goto IL_04f1;
																											case 41:
																												goto IL_0508;
																											case 7:
																											case 97:
																												goto IL_051b;
																											case 39:
																											case 47:
																												goto IL_0526;
																											case 19:
																												goto IL_0531;
																											case 94:
																												goto IL_054c;
																											case 26:
																											case 73:
																												goto IL_0557;
																											case 91:
																											case 101:
																												goto IL_056c;
																											case 22:
																												goto IL_0577;
																											case 104:
																												goto IL_0584;
																											case 23:
																												goto IL_0592;
																											case 99:
																												goto IL_05a9;
																											case 5:
																											case 16:
																											case 18:
																											case 33:
																											case 34:
																											case 44:
																											case 46:
																											case 53:
																											case 58:
																											case 59:
																											case 64:
																											case 74:
																											case 75:
																											case 77:
																											case 95:
																											case 98:
																											case 102:
																											case 103:
																												goto end_IL_01dd;
																											case 2:
																											case 10:
																											case 11:
																											case 13:
																											case 38:
																											case 48:
																											case 49:
																											case 51:
																											case 56:
																											case 72:
																											case 81:
																											case 82:
																											case 105:
																												goto end_IL_025d;
																											case 1:
																												goto end_IL_05cc;
																											case 66:
																												goto end_IL_05df;
																											case 83:
																												goto end_IL_05e9;
																											case 29:
																												goto end_IL_05f4;
																											case 71:
																											case 89:
																												goto end_IL_0609;
																											case 15:
																												goto end_IL_0619;
																											case 55:
																											case 90:
																												goto end_IL_0629;
																											case 27:
																												goto end_IL_0639;
																											case 28:
																												goto end_IL_0649;
																											case 25:
																											case 70:
																												goto IL_0664;
																											}
																											continue;
																											end_IL_01dd:
																											break;
																										}
																										break;
																									}
																									goto IL_0268;
																									IL_0268:
																									byte* num5 = ptr2;
																									num4 = 1;
																									ptr2 = num5 + -200;
																									goto end_IL_025d;
																								}
																								break;
																							}
																							goto IL_056c;
																							IL_0577:
																							if (10 <= b)
																							{
																							}
																							break;
																							IL_056c:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0577;
																						}
																						break;
																					}
																					goto IL_0284;
																					IL_030f:
																					num6 -= 2;
																					goto end_IL_025d;
																					IL_0284:
																					if (8 > b)
																					{
																						goto IL_028f;
																					}
																					goto IL_02ad;
																					IL_028f:
																					if (6 >= b)
																					{
																						goto IL_029d;
																					}
																					goto IL_0389;
																					IL_029d:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0322;
																					IL_0322:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0362;
																					IL_0362:
																					array[num6 - 2] = 0;
																					goto IL_0376;
																					IL_0376:
																					num6--;
																					goto end_IL_025d;
																					IL_0389:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0397;
																					IL_0397:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03a5;
																					IL_03a5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0584;
																					IL_0584:
																					array[num6] = 0;
																					goto IL_0592;
																					IL_0592:
																					num6++;
																					num = 99;
																					goto IL_05a9;
																					IL_05a9:
																					ptr2 += 8;
																					goto end_IL_025d;
																					IL_02ad:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_030f;
																				}
																				break;
																			}
																			goto IL_03cd;
																			IL_04e7:
																			array2[num6] = null;
																			goto IL_04f1;
																			IL_03cd:
																			if (5 > b)
																			{
																				goto IL_03db;
																			}
																			goto IL_04ad;
																			IL_03db:
																			if (2 >= b)
																			{
																				goto IL_03e9;
																			}
																			goto IL_051b;
																			IL_03e9:
																			if (2 <= b)
																			{
																				goto IL_03f4;
																			}
																			goto IL_043e;
																			IL_03f4:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_041d;
																			IL_041d:
																			ptr2 += 8;
																			goto IL_042b;
																			IL_042b:
																			num6--;
																			goto end_IL_025d;
																			IL_043e:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_044c;
																			IL_044c:
																			if (1 > b)
																			{
																				num = 102;
																				break;
																			}
																			goto IL_0457;
																			IL_0457:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0470;
																			IL_0470:
																			array[num6] = 0;
																			goto IL_047e;
																			IL_047e:
																			num6++;
																			goto IL_048c;
																			IL_048c:
																			ptr2 += 8;
																			goto end_IL_025d;
																			IL_04f1:
																			num6++;
																			num = 41;
																			goto IL_0508;
																			IL_051b:
																			if (3 < b)
																			{
																				goto IL_0526;
																			}
																			goto IL_054c;
																			IL_0526:
																			if (4 < b)
																			{
																				num = 58;
																				break;
																			}
																			goto IL_0531;
																			IL_0531:
																			if (4 <= b)
																			{
																				goto end_IL_025d;
																			}
																			break;
																			IL_0508:
																			ptr2 += 8;
																			goto end_IL_025d;
																			IL_054c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0557;
																			IL_0557:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_025d;
																			IL_04ad:
																			array[num6] = 0;
																			goto IL_04bb;
																			IL_04bb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			num = 63;
																			goto IL_04e7;
																		}
																		break;
																		IL_022d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_025d;
																continue;
																end_IL_023d:
																break;
															}
															continue;
															end_IL_024d:
															break;
														}
														continue;
														end_IL_025d:
														break;
													}
													continue;
												}
												goto IL_0664;
												IL_0664:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05cc:
												break;
											}
											continue;
											end_IL_05df:
											break;
										}
										continue;
										end_IL_05e9:
										break;
									}
									continue;
									end_IL_05f4:
									break;
								}
								continue;
								end_IL_0609:
								break;
							}
							continue;
							end_IL_0619:
							break;
						}
						continue;
						end_IL_0629:
						break;
					}
					continue;
					end_IL_0639:
					break;
				}
				continue;
				end_IL_0649:
				break;
			}
		}
	}

	private static double getDriveTypeglobalQueueTail(double double_3)
	{
		return Math.Sqrt(double_3);
	}

	private static double NotImpersonatedApplicationManifestBytes(double double_3)
	{
		return Math.Tan(double_3);
	}

	private static int smethod_2(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetCanonicalizationContextEmptyArray.BeginBufferedTraceOperationCreation);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 108;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f5:
																if (b >= 1)
																{
																	num = 125;
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02d5:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_02c5:
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_02b5:
																							if (13 >= b)
																							{
																								while (true)
																								{
																									IL_02a5:
																									if (13 > b)
																									{
																										while (12 >= b)
																										{
																											while (true)
																											{
																												IL_0282:
																												if (12 > b)
																												{
																													num = 145;
																													while (num != 145)
																													{
																														if (num != 1126)
																														{
																															goto IL_02f5;
																														}
																														switch (num)
																														{
																														case 33:
																															goto IL_0282;
																														case 25:
																														case 119:
																															goto IL_0295;
																														case 52:
																															goto IL_02a5;
																														case 13:
																														case 124:
																															goto IL_02b5;
																														case 30:
																														case 75:
																															goto IL_02c5;
																														case 135:
																															goto IL_02d5;
																														case 125:
																															goto IL_02e5;
																														case 10:
																															goto IL_02f5;
																														case 41:
																															goto end_IL_02f5;
																														case 85:
																														case 123:
																															goto end_IL_0308;
																														case 73:
																														case 131:
																															goto IL_0323;
																														case 32:
																														case 57:
																															goto IL_0336;
																														case 129:
																															goto IL_035b;
																														case 66:
																															goto IL_0369;
																														case 137:
																															goto IL_037c;
																														case 62:
																														case 111:
																															goto IL_038a;
																														case 1:
																															goto IL_0398;
																														case 18:
																														case 20:
																															goto IL_03a6;
																														case 17:
																															goto IL_0411;
																														case 84:
																															goto IL_042d;
																														case 122:
																															goto IL_043b;
																														case 59:
																														case 106:
																															goto IL_0449;
																														case 49:
																															goto IL_046c;
																														case 55:
																															goto IL_047a;
																														case 118:
																															goto IL_0488;
																														case 12:
																															goto IL_049b;
																														case 100:
																															goto IL_04a9;
																														case 28:
																														case 56:
																															goto IL_04b7;
																														case 37:
																															goto IL_04f7;
																														case 98:
																															goto IL_050b;
																														case 44:
																														case 116:
																															goto IL_051e;
																														case 99:
																															goto IL_0532;
																														case 121:
																															goto IL_0571;
																														case 6:
																															goto IL_058d;
																														case 23:
																															goto IL_059b;
																														case 9:
																														case 46:
																															goto IL_05a9;
																														case 50:
																															goto IL_05b7;
																														case 29:
																														case 65:
																															goto IL_05c2;
																														case 82:
																															goto IL_05d0;
																														case 0:
																														case 120:
																															goto IL_05e3;
																														case 74:
																															goto IL_05fa;
																														case 47:
																															goto IL_061d;
																														case 5:
																															goto IL_0627;
																														case 64:
																															goto IL_0635;
																														case 71:
																															goto IL_0648;
																														case 58:
																															goto IL_0656;
																														case 42:
																														case 70:
																															goto IL_0664;
																														case 95:
																															goto IL_06a4;
																														case 61:
																															goto IL_06b8;
																														case 88:
																															goto IL_06cb;
																														case 2:
																														case 110:
																															goto IL_06d9;
																														case 3:
																															goto IL_06e4;
																														case 15:
																														case 94:
																															goto IL_06f2;
																														case 11:
																															goto IL_070b;
																														case 16:
																															goto IL_0719;
																														case 27:
																															goto IL_0727;
																														case 40:
																															goto IL_073a;
																														case 138:
																															goto IL_0748;
																														case 102:
																														case 103:
																															goto IL_0761;
																														case 21:
																															goto IL_078a;
																														case 109:
																															goto IL_0798;
																														case 72:
																														case 117:
																															goto IL_07ab;
																														case 69:
																														case 127:
																															goto IL_07c3;
																														case 87:
																															goto IL_0803;
																														case 130:
																															goto IL_0817;
																														case 8:
																														case 19:
																														case 24:
																														case 34:
																														case 38:
																														case 39:
																														case 43:
																														case 51:
																														case 54:
																														case 63:
																														case 68:
																														case 81:
																														case 90:
																														case 91:
																														case 93:
																														case 96:
																														case 104:
																														case 105:
																														case 114:
																														case 115:
																														case 126:
																														case 128:
																														case 134:
																														case 136:
																															goto end_IL_026f;
																														case 7:
																														case 14:
																														case 26:
																														case 31:
																														case 35:
																														case 45:
																														case 60:
																														case 67:
																														case 76:
																														case 79:
																														case 80:
																														case 83:
																														case 86:
																														case 89:
																														case 92:
																														case 108:
																														case 112:
																															goto end_IL_0318;
																														case 53:
																															goto end_IL_0843;
																														case 133:
																															goto end_IL_0856;
																														case 132:
																															goto end_IL_0869;
																														case 4:
																															goto end_IL_0874;
																														case 22:
																														case 48:
																															goto end_IL_0889;
																														case 107:
																															goto end_IL_0899;
																														case 97:
																														case 113:
																															goto end_IL_08a9;
																														case 77:
																															goto end_IL_08b9;
																														case 78:
																															goto end_IL_08c9;
																														case 36:
																														case 101:
																															goto IL_08e4;
																														}
																														continue;
																														end_IL_026f:
																														break;
																													}
																													break;
																												}
																												goto IL_0323;
																												IL_0323:
																												num5--;
																												goto end_IL_0318;
																											}
																											break;
																											IL_0295:;
																										}
																										break;
																									}
																									goto IL_0336;
																									IL_0336:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									num = 45;
																									goto end_IL_0318;
																								}
																								break;
																							}
																							goto IL_035b;
																							IL_0369:
																							if (14 > b)
																							{
																							}
																							break;
																							IL_035b:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_0369;
																						}
																						break;
																					}
																					goto IL_037c;
																					IL_0571:
																					ptr2 += 8;
																					num = 67;
																					goto end_IL_0318;
																					IL_037c:
																					if (11 > b)
																					{
																						goto IL_038a;
																					}
																					goto IL_051e;
																					IL_038a:
																					if (9 >= b)
																					{
																						goto IL_0398;
																					}
																					goto IL_049b;
																					IL_0398:
																					if (9 <= b)
																					{
																						goto IL_03a6;
																					}
																					goto IL_042d;
																					IL_03a6:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 17;
																					goto IL_0411;
																					IL_0411:
																					num5 -= 2;
																					num = 76;
																					goto end_IL_0318;
																					IL_042d:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_043b;
																					IL_043b:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0449;
																					IL_0449:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_046c;
																					IL_046c:
																					array[num5] = 0;
																					goto IL_047a;
																					IL_047a:
																					num5++;
																					goto IL_0488;
																					IL_0488:
																					ptr2 += 8;
																					goto end_IL_0318;
																					IL_049b:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_04a9;
																					IL_04a9:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_04b7;
																					IL_04b7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04f7;
																					IL_04f7:
																					array[num5 - 2] = 0;
																					goto IL_050b;
																					IL_050b:
																					num5--;
																					goto end_IL_0318;
																					IL_051e:
																					array[num5 - 1] = 0;
																					goto IL_0532;
																					IL_0532:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)EventKeywordsGreaterThan[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0571;
																				}
																				break;
																			}
																			goto IL_058d;
																			IL_0803:
																			array[num5 - 2] = 0;
																			goto IL_0817;
																			IL_058d:
																			if (7 > b)
																			{
																				goto IL_059b;
																			}
																			goto IL_07c3;
																			IL_059b:
																			if (3 < b)
																			{
																				goto IL_05a9;
																			}
																			goto IL_06cb;
																			IL_05a9:
																			if (5 >= b)
																			{
																				goto IL_05b7;
																			}
																			goto IL_0648;
																			IL_05b7:
																			if (5 > b)
																			{
																				goto IL_05c2;
																			}
																			goto IL_05e3;
																			IL_05c2:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_05d0;
																			IL_05d0:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0318;
																			IL_05e3:
																			array[num5] = 0;
																			num = 74;
																			goto IL_05fa;
																			IL_05fa:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_061d;
																			IL_061d:
																			array2[num5] = null;
																			goto IL_0627;
																			IL_0627:
																			num5++;
																			goto IL_0635;
																			IL_0635:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_0648:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_0656;
																			IL_0656:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0664;
																			IL_0664:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06a4;
																			IL_06a4:
																			array[num5 - 2] = 0;
																			goto IL_06b8;
																			IL_06b8:
																			num5--;
																			goto end_IL_0318;
																			IL_06cb:
																			if (3 > b)
																			{
																				goto IL_06d9;
																			}
																			goto IL_07ab;
																			IL_06d9:
																			if (1 >= b)
																			{
																				goto IL_06e4;
																			}
																			goto IL_073a;
																			IL_06e4:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_06f2;
																			IL_06f2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_070b;
																			IL_070b:
																			array[num5] = 0;
																			goto IL_0719;
																			IL_0719:
																			num5++;
																			goto IL_0727;
																			IL_0727:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_073a:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0748;
																			IL_0748:
																			if (2 > b)
																			{
																				num = 68;
																				break;
																			}
																			goto IL_0761;
																			IL_0817:
																			num5--;
																			goto end_IL_0318;
																			IL_0761:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_078a;
																			IL_078a:
																			ptr2 += 8;
																			goto IL_0798;
																			IL_0798:
																			num5--;
																			goto end_IL_0318;
																			IL_07ab:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0318;
																			IL_07c3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0803;
																		}
																		break;
																		IL_02e5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 83;
																goto end_IL_0318;
																continue;
																end_IL_02f5:
																break;
															}
															continue;
															end_IL_0308:
															break;
														}
														continue;
														end_IL_0318:
														break;
													}
													continue;
												}
												goto IL_08e4;
												IL_08e4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0843:
												break;
											}
											continue;
											end_IL_0856:
											break;
										}
										continue;
										end_IL_0869:
										break;
									}
									continue;
									end_IL_0874:
									break;
								}
								continue;
								end_IL_0889:
								break;
							}
							continue;
							end_IL_0899:
							break;
						}
						continue;
						end_IL_08a9:
						break;
					}
					continue;
					end_IL_08b9:
					break;
				}
				continue;
				end_IL_08c9:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ShldwTickCountDeadline.EnumCategoriesPOLICYAUDITLOGADMIN);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0230:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0210:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0200:
																					if (9 >= b)
																					{
																						num = 116;
																						while (true)
																						{
																							if (num != 116)
																							{
																								if (num != 1097)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 9:
																									goto IL_0200;
																								case 2:
																									goto IL_0210;
																								case 81:
																									goto IL_0220;
																								case 92:
																									goto IL_0230;
																								case 32:
																									goto end_IL_0230;
																								case 73:
																								case 91:
																									goto end_IL_0240;
																								case 1:
																									goto IL_025b;
																								case 42:
																									goto IL_0266;
																								case 31:
																								case 39:
																									goto IL_0274;
																								case 51:
																								case 55:
																									goto IL_0290;
																								case 57:
																									goto IL_02a3;
																								case 22:
																									goto IL_02ae;
																								case 10:
																								case 60:
																									goto IL_02b9;
																								case 40:
																									goto IL_02c4;
																								case 35:
																									goto IL_02d7;
																								case 38:
																								case 63:
																									goto IL_02ea;
																								case 67:
																									goto IL_032f;
																								case 77:
																									goto IL_033f;
																								case 70:
																								case 79:
																									goto IL_0352;
																								case 23:
																									goto IL_035d;
																								case 29:
																									goto IL_0376;
																								case 45:
																								case 83:
																									goto IL_0389;
																								case 48:
																									goto IL_03a2;
																								case 12:
																									goto IL_03b0;
																								case 43:
																									goto IL_03be;
																								case 87:
																									goto IL_03d1;
																								case 59:
																								case 93:
																									goto IL_03df;
																								case 19:
																									goto IL_03f6;
																								case 16:
																									goto IL_0419;
																								case 74:
																									goto IL_0423;
																								case 49:
																									goto IL_0431;
																								case 100:
																									goto IL_0444;
																								case 34:
																									goto IL_0458;
																								case 101:
																									goto IL_046b;
																								case 27:
																								case 64:
																									goto IL_0479;
																								case 85:
																									goto IL_04a2;
																								case 0:
																									goto IL_04b0;
																								case 97:
																								case 103:
																									goto IL_04c3;
																								case 18:
																								case 54:
																									goto IL_04e6;
																								case 105:
																									goto IL_0548;
																								case 17:
																									goto IL_055b;
																								case 76:
																									goto IL_0566;
																								case 75:
																								case 82:
																									goto IL_0574;
																								case 13:
																									goto IL_05b4;
																								case 109:
																									goto IL_05c8;
																								case 96:
																									goto IL_05d8;
																								case 44:
																									goto IL_05e3;
																								case 53:
																								case 84:
																									goto IL_05ee;
																								case 41:
																									goto IL_0611;
																								case 11:
																									goto IL_061f;
																								case 21:
																									goto IL_062d;
																								case 5:
																								case 6:
																								case 8:
																								case 15:
																								case 46:
																								case 47:
																								case 50:
																								case 58:
																								case 62:
																								case 69:
																								case 72:
																								case 80:
																								case 88:
																								case 90:
																								case 95:
																								case 98:
																								case 106:
																								case 107:
																								case 108:
																									goto end_IL_01ed;
																								case 3:
																								case 4:
																								case 7:
																								case 24:
																								case 25:
																								case 26:
																								case 28:
																								case 37:
																								case 61:
																								case 71:
																								case 78:
																								case 86:
																								case 94:
																								case 99:
																									goto end_IL_0250;
																								case 30:
																									goto end_IL_0650;
																								case 33:
																									goto end_IL_0663;
																								case 56:
																									goto end_IL_066d;
																								case 14:
																									goto end_IL_0678;
																								case 52:
																								case 102:
																									goto end_IL_068d;
																								case 104:
																									goto end_IL_069d;
																								case 20:
																								case 36:
																									goto end_IL_06ad;
																								case 65:
																									goto end_IL_06bd;
																								case 66:
																									goto end_IL_06cd;
																								case 68:
																								case 89:
																									goto IL_06e8;
																								}
																								continue;
																							}
																							if (9 <= b)
																							{
																								goto IL_04e6;
																							}
																							goto IL_055b;
																							IL_0611:
																							array[num5] = 0;
																							goto IL_061f;
																							IL_062d:
																							ptr2 += 8;
																							goto end_IL_0250;
																							IL_061f:
																							num5++;
																							goto IL_062d;
																							IL_04e6:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0548;
																							IL_0548:
																							num5 -= 2;
																							goto end_IL_0250;
																							IL_055b:
																							if (7 >= b)
																							{
																								goto IL_0566;
																							}
																							goto IL_05d8;
																							IL_0566:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0574;
																							IL_0574:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05b4;
																							IL_05b4:
																							array[num5 - 2] = 0;
																							goto IL_05c8;
																							IL_05c8:
																							num5--;
																							goto end_IL_0250;
																							IL_05d8:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_05e3;
																							IL_05e3:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_05ee;
																							IL_05ee:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0611;
																							continue;
																							end_IL_01ed:
																							break;
																						}
																						break;
																					}
																					goto IL_025b;
																					IL_0290:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_033f;
																					IL_033f:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_025b:
																					if (10 >= b)
																					{
																						goto IL_0266;
																					}
																					goto IL_0290;
																					IL_0266:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0274;
																					IL_0274:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0250;
																				}
																				break;
																			}
																			goto IL_02a3;
																			IL_0444:
																			array[num5 - 2] = 0;
																			goto IL_0458;
																			IL_02a3:
																			if (6 > b)
																			{
																				goto IL_02ae;
																			}
																			goto IL_02ea;
																			IL_02ae:
																			if (3 < b)
																			{
																				goto IL_02b9;
																			}
																			goto IL_032f;
																			IL_02b9:
																			if (4 >= b)
																			{
																				goto IL_02c4;
																			}
																			goto IL_02d7;
																			IL_02c4:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0250;
																			IL_02d7:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_03d1;
																			IL_03d1:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_03df;
																			IL_03df:
																			array[num5] = 0;
																			num = 19;
																			goto IL_03f6;
																			IL_03f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0419;
																			IL_0419:
																			array2[num5] = null;
																			goto IL_0423;
																			IL_0423:
																			num5++;
																			goto IL_0431;
																			IL_0431:
																			ptr2 += 8;
																			goto end_IL_0250;
																			IL_032f:
																			if (3 > b)
																			{
																				goto IL_0352;
																			}
																			goto IL_04c3;
																			IL_0352:
																			if (1 >= b)
																			{
																				goto IL_035d;
																			}
																			goto IL_0376;
																			IL_035d:
																			if (1 > b)
																			{
																				break;
																			}
																			num = 83;
																			goto IL_0389;
																			IL_0458:
																			num5--;
																			goto end_IL_0250;
																			IL_0389:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_03a2;
																			IL_03a2:
																			array[num5] = 0;
																			goto IL_03b0;
																			IL_03b0:
																			num5++;
																			goto IL_03be;
																			IL_03be:
																			ptr2 += 8;
																			goto end_IL_0250;
																			IL_0376:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_046b;
																			IL_046b:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0479;
																			IL_0479:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04a2;
																			IL_04a2:
																			ptr2 += 8;
																			goto IL_04b0;
																			IL_04b0:
																			num5--;
																			goto end_IL_0250;
																			IL_04c3:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0250;
																			IL_02ea:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0444;
																		}
																		break;
																		IL_0220:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0250;
																continue;
																end_IL_0230:
																break;
															}
															continue;
															end_IL_0240:
															break;
														}
														continue;
														end_IL_0250:
														break;
													}
													continue;
												}
												goto IL_06e8;
												IL_06e8:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0650:
												break;
											}
											continue;
											end_IL_0663:
											break;
										}
										continue;
										end_IL_066d:
										break;
									}
									continue;
									end_IL_0678:
									break;
								}
								continue;
								end_IL_068d:
								break;
							}
							continue;
							end_IL_069d:
							break;
						}
						continue;
						end_IL_06ad:
						break;
					}
					continue;
					end_IL_06bd:
					break;
				}
				continue;
				end_IL_06cd:
				break;
			}
		}
	}

	private static float getModuleHandleCreateNode()
	{
		return Time.time;
	}

	private unsafe void Update()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				IL_008b:
				int num3 = 0;
				while (true)
				{
					IL_0086:
					num3 = 0;
					while (true)
					{
						if (num3 != 31)
						{
							while (true)
							{
								IL_0051:
								((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class166, void>)ToSerializedStringCustomQueryInterfaceResult[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
								num = 14;
								while (num != 14)
								{
									if (num != 995)
									{
										goto end_IL_007e;
									}
									switch (num)
									{
									case 7:
										goto IL_0051;
									case 5:
										goto end_IL_0044;
									case 6:
										goto IL_0086;
									case 0:
										goto IL_008b;
									case 1:
										goto end_IL_007e;
									case 2:
										goto IL_0095;
									case 3:
									case 4:
										return;
									}
									continue;
									end_IL_0044:
									break;
								}
								break;
							}
							continue;
						}
						goto IL_0095;
						IL_0095:
						num3 = 0;
						return;
						continue;
						end_IL_007e:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class166()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static double setChannelDataNonSerializedAttribute(double double_3)
	{
		return Math.Truncate(double_3);
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 122;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ApplicationSecurityInfoTryPop.addAssemblyLoadNewPermissionElement);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f7:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02d7:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02c7:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_02b7:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_02aa:
																										if (11 > b)
																										{
																											while (10 >= b)
																											{
																												while (10 <= b)
																												{
																													while (true)
																													{
																														IL_0274:
																														array[num5 - 1] = 0;
																														while (true)
																														{
																															IL_022a:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)DispIdAttributeNow[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																															num = 130;
																															while (true)
																															{
																																if (num != 130)
																																{
																																	if (num != 1111)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 108:
																																		goto IL_022a;
																																	case 16:
																																	case 75:
																																		goto IL_0274;
																																	case 77:
																																		goto IL_028a;
																																	case 76:
																																		goto IL_029a;
																																	case 28:
																																		goto IL_02aa;
																																	case 41:
																																	case 97:
																																		goto IL_02b7;
																																	case 36:
																																	case 91:
																																		goto IL_02c7;
																																	case 38:
																																		goto IL_02d7;
																																	case 4:
																																		goto IL_02e7;
																																	case 48:
																																		goto IL_02f7;
																																	case 44:
																																		goto end_IL_02f7;
																																	case 22:
																																	case 84:
																																		goto end_IL_0307;
																																	case 90:
																																	case 112:
																																		goto IL_0322;
																																	case 100:
																																		goto IL_0348;
																																	case 93:
																																		goto IL_0356;
																																	case 54:
																																	case 105:
																																		goto IL_0364;
																																	case 109:
																																		goto IL_0380;
																																	case 82:
																																	case 106:
																																		goto end_IL_0217;
																																	case 107:
																																		goto IL_0399;
																																	case 5:
																																	case 111:
																																		goto IL_03a7;
																																	case 78:
																																		goto IL_03b5;
																																	case 23:
																																		goto IL_03d8;
																																	case 55:
																																		goto IL_03e2;
																																	case 29:
																																		goto IL_03f0;
																																	case 96:
																																		goto IL_0403;
																																	case 59:
																																		goto IL_041a;
																																	case 53:
																																	case 72:
																																		goto IL_0428;
																																	case 95:
																																		goto IL_0441;
																																	case 88:
																																		goto IL_044f;
																																	case 21:
																																		goto IL_045d;
																																	case 85:
																																	case 119:
																																		goto IL_0470;
																																	case 123:
																																		goto IL_04b0;
																																	case 27:
																																		goto IL_04c4;
																																	case 15:
																																		goto IL_04d7;
																																	case 65:
																																		goto IL_04e5;
																																	case 3:
																																	case 58:
																																		goto IL_04f3;
																																	case 7:
																																	case 83:
																																		goto IL_04fe;
																																	case 66:
																																		goto IL_050c;
																																	case 51:
																																	case 115:
																																		goto IL_051a;
																																	case 98:
																																		goto IL_0532;
																																	case 43:
																																	case 45:
																																		goto IL_0540;
																																	case 39:
																																		goto IL_0569;
																																	case 32:
																																		goto IL_0577;
																																	case 73:
																																		goto IL_058a;
																																	case 30:
																																	case 42:
																																		goto IL_0598;
																																	case 20:
																																		goto IL_05a6;
																																	case 62:
																																		goto IL_05bd;
																																	case 92:
																																	case 101:
																																		goto IL_05cb;
																																	case 79:
																																		goto IL_0639;
																																	case 89:
																																		goto IL_064c;
																																	case 37:
																																	case 86:
																																		goto IL_0659;
																																	case 12:
																																		goto IL_0699;
																																	case 80:
																																		goto IL_06ad;
																																	case 1:
																																	case 8:
																																	case 9:
																																	case 10:
																																	case 24:
																																	case 26:
																																	case 35:
																																	case 47:
																																	case 49:
																																	case 50:
																																	case 56:
																																	case 57:
																																	case 63:
																																	case 64:
																																	case 67:
																																	case 68:
																																	case 99:
																																	case 102:
																																	case 113:
																																	case 114:
																																	case 116:
																																	case 120:
																																		goto end_IL_028a;
																																	case 110:
																																		goto IL_06f2;
																																	case 87:
																																		goto IL_0700;
																																	case 6:
																																		goto IL_070e;
																																	case 0:
																																	case 2:
																																	case 11:
																																	case 17:
																																	case 18:
																																	case 19:
																																	case 25:
																																	case 33:
																																	case 40:
																																	case 52:
																																	case 69:
																																	case 70:
																																	case 94:
																																	case 118:
																																	case 121:
																																		goto end_IL_0317;
																																	case 61:
																																		goto end_IL_0725;
																																	case 34:
																																		goto end_IL_0738;
																																	case 46:
																																		goto end_IL_0742;
																																	case 74:
																																		goto end_IL_074d;
																																	case 71:
																																		goto end_IL_0762;
																																	case 13:
																																	case 81:
																																		goto end_IL_0777;
																																	case 122:
																																		goto end_IL_0787;
																																	case 31:
																																	case 60:
																																		goto end_IL_0797;
																																	case 103:
																																		goto end_IL_07a7;
																																	case 104:
																																		goto end_IL_07c0;
																																	case 14:
																																	case 117:
																																		goto IL_07db;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_0317;
																																continue;
																																end_IL_0217:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_038e;
																													continue;
																													end_IL_028a:
																													break;
																													IL_028a:;
																												}
																												break;
																												IL_029a:;
																											}
																											break;
																										}
																										goto IL_0322;
																										IL_0322:
																										num5--;
																										goto end_IL_0317;
																									}
																									break;
																								}
																								goto IL_0348;
																								IL_0364:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0317;
																								IL_0348:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_0356;
																								IL_0356:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0364;
																							}
																							break;
																						}
																						goto IL_0380;
																						IL_04b0:
																						array[num5 - 2] = 0;
																						goto IL_04c4;
																						IL_0380:
																						if (9 > b)
																						{
																							goto IL_038e;
																						}
																						goto IL_0470;
																						IL_038e:
																						if (7 >= b)
																						{
																							goto IL_0399;
																						}
																						goto IL_0403;
																						IL_0399:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03a7;
																						IL_03a7:
																						array[num5] = 0;
																						goto IL_03b5;
																						IL_03b5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03d8;
																						IL_03d8:
																						array2[num5] = null;
																						goto IL_03e2;
																						IL_03e2:
																						num5++;
																						goto IL_03f0;
																						IL_03f0:
																						ptr2 += 8;
																						goto end_IL_0317;
																						IL_0403:
																						if (8 < b)
																						{
																							break;
																						}
																						num = 59;
																						goto IL_041a;
																						IL_04c4:
																						num5--;
																						goto end_IL_0317;
																						IL_041a:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0428;
																						IL_0428:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0441;
																						IL_0441:
																						array[num5] = 0;
																						goto IL_044f;
																						IL_044f:
																						num5++;
																						goto IL_045d;
																						IL_045d:
																						ptr2 += 8;
																						goto end_IL_0317;
																						IL_0470:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04b0;
																					}
																					break;
																				}
																				goto IL_04d7;
																				IL_0699:
																				array[num5 - 2] = 0;
																				goto IL_06ad;
																				IL_04d7:
																				if (6 <= b)
																				{
																					goto end_IL_0317;
																				}
																				goto IL_04e5;
																				IL_04e5:
																				if (3 < b)
																				{
																					goto IL_04f3;
																				}
																				goto IL_058a;
																				IL_04f3:
																				if (4 < b)
																				{
																					goto IL_04fe;
																				}
																				goto IL_0532;
																				IL_04fe:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_050c;
																				IL_050c:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_051a;
																				IL_051a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0317;
																				IL_0532:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0540;
																				IL_0540:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0569;
																				IL_0569:
																				ptr2 += 8;
																				goto IL_0577;
																				IL_0577:
																				num5--;
																				goto end_IL_0317;
																				IL_058a:
																				if (3 > b)
																				{
																					goto IL_0598;
																				}
																				goto IL_0659;
																				IL_0598:
																				if (1 < b)
																				{
																					goto IL_05a6;
																				}
																				goto IL_064c;
																				IL_05a6:
																				if (2 < b)
																				{
																					break;
																				}
																				num = 62;
																				goto IL_05bd;
																				IL_06ad:
																				num5--;
																				num = 70;
																				goto end_IL_0317;
																				IL_05bd:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_05cb;
																				IL_05cb:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0639;
																				IL_0639:
																				num5 -= 2;
																				goto end_IL_0317;
																				IL_064c:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0659:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0699;
																			}
																			break;
																			IL_02e7:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 110;
																	goto IL_06f2;
																	IL_070e:
																	ptr2 += 8;
																	num = 25;
																	goto end_IL_0317;
																	IL_0700:
																	num5++;
																	goto IL_070e;
																	IL_06f2:
																	array[num5] = 0;
																	goto IL_0700;
																	continue;
																	end_IL_02f7:
																	break;
																}
																continue;
																end_IL_0307:
																break;
															}
															continue;
															end_IL_0317:
															break;
														}
														continue;
													}
													goto IL_07db;
													IL_07db:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0725:
													break;
												}
												continue;
												end_IL_0738:
												break;
											}
											continue;
											end_IL_0742:
											break;
										}
										continue;
										end_IL_074d:
										break;
									}
									continue;
									end_IL_0762:
									break;
								}
								continue;
								end_IL_0777:
								break;
							}
							continue;
							end_IL_0787:
							break;
						}
						continue;
						end_IL_0797:
						break;
					}
					continue;
					end_IL_07a7:
					break;
				}
				continue;
				end_IL_07c0:
				break;
			}
		}
	}

	private static double PiModuleBuilder(double double_3)
	{
		return Math.Tanh(double_3);
	}

	private static int getPropertyGetExecutingAssembly(double double_3)
	{
		return Convert.ToInt32(double_3);
	}

	private static double setValueAdmin(double double_3)
	{
		return Math.Round(double_3);
	}

	unsafe static Class166()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_026d, IL_0280, IL_0290, IL_02a0, IL_02b0, IL_02c0, IL_02d0, IL_02db, IL_02e6, IL_02f4, IL_0307, IL_0345, IL_0358, IL_0366, IL_0371, IL_037f, IL_038d, IL_039b, IL_03a9, IL_03c7, IL_03da, IL_03e8, IL_03f6, IL_0401, IL_0441, IL_0455, IL_0471, IL_047f, IL_04aa, IL_04bd, IL_04d0, IL_04e9, IL_0506, IL_0555, IL_055f, IL_058c, IL_05a0, IL_05ae, IL_05c1, IL_05d9, IL_05fc, IL_060a, IL_0613, IL_0621, IL_063f, IL_064d, IL_0660, IL_0682, IL_0690, IL_069e, IL_06b1, IL_06d5, IL_06f6, IL_0709, IL_0717, IL_0725, IL_0733, IL_074b, IL_0759, IL_076c, IL_0777, IL_0785, IL_0793, IL_07af, IL_07bd, IL_07cb, IL_07d9, IL_07ed, IL_0825, IL_083e, IL_0857, IL_0867, IL_087c, IL_088a, IL_089d, IL_08a7, IL_08b2, IL_08c2, IL_08d2, IL_08e2, IL_08f2, IL_0902, IL_0912, IL_093c, IL_0943 are reachable both inside and outside the pinned region starting at IL_0927. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2;
					int num3;
					byte[] array2;
					object[] array3;
					int[] array4;
					long[] array5;
					object[] array6;
					byte* ptr;
					byte* num6;
					int num7;
					object[] array7;
					int num8;
					byte* num9;
					byte* ptr2;
					byte[] array = new byte[4];
					if (true)
					{
						while (true)
						{
							IL_0912:
							num2 = 1;
							while (true)
							{
								IL_0902:
								num3 = num2 * 4;
								while (true)
								{
									IL_08f2:
									array2 = new byte[4];
									while (true)
									{
										IL_08e2:
										array3 = new object[4];
										while (true)
										{
											IL_08d2:
											array4 = new int[4];
											while (true)
											{
												IL_08c2:
												array5 = new long[4];
												while (true)
												{
													IL_08b2:
													array6 = new object[52];
													while (true)
													{
														IL_08a7:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SecurityRegistryPermissionCryptoAPITransform.VTIPrivilegeNotHeldException);
														while (true)
														{
															IL_089d:
															ptr2 = ptr;
															while (true)
															{
																IL_088a:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_02d0:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_02c0:
																		ptr2++;
																		while (true)
																		{
																			IL_02b0:
																			if (b >= 1)
																			{
																				while (b <= 13)
																				{
																					while (true)
																					{
																						IL_0290:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0280:
																								if (10 < b)
																								{
																									num = 148;
																									while (true)
																									{
																										if (num == 148)
																										{
																											goto IL_076c;
																										}
																										if (num != 1129)
																										{
																											goto IL_07af;
																										}
																										switch (num)
																										{
																										case 47:
																											break;
																										default:
																											continue;
																										case 115:
																											goto IL_0280;
																										case 116:
																											goto IL_0290;
																										case 111:
																											goto IL_02a0;
																										case 126:
																											goto IL_02b0;
																										case 114:
																											goto IL_02c0;
																										case 99:
																										case 133:
																											goto IL_02d0;
																										case 39:
																											goto IL_02db;
																										case 34:
																											goto IL_02e6;
																										case 41:
																											goto IL_02f4;
																										case 50:
																										case 68:
																											goto IL_0307;
																										case 18:
																											goto IL_0345;
																										case 91:
																											goto IL_0358;
																										case 11:
																										case 33:
																											goto IL_0366;
																										case 9:
																											goto IL_0371;
																										case 22:
																										case 69:
																											goto IL_037f;
																										case 8:
																										case 46:
																											goto IL_038d;
																										case 59:
																											goto IL_039b;
																										case 49:
																										case 51:
																											goto IL_03a9;
																										case 29:
																											goto IL_03c7;
																										case 64:
																											goto IL_03da;
																										case 37:
																											goto IL_03e8;
																										case 25:
																											goto IL_03f6;
																										case 2:
																										case 63:
																											goto IL_0401;
																										case 1:
																											goto IL_0441;
																										case 24:
																											goto IL_0455;
																										case 26:
																										case 89:
																											goto IL_047f;
																										case 92:
																											goto IL_04aa;
																										case 93:
																											goto IL_04bd;
																										case 96:
																											goto IL_04d0;
																										case 79:
																										case 113:
																											goto IL_04e9;
																										case 110:
																											goto IL_05a0;
																										case 85:
																											goto IL_05ae;
																										case 52:
																										case 119:
																											goto IL_05c1;
																										case 5:
																											goto IL_05d9;
																										case 17:
																										case 122:
																											goto IL_05fc;
																										case 84:
																											goto IL_0613;
																										case 3:
																										case 72:
																											goto IL_0621;
																										case 123:
																											goto IL_063f;
																										case 83:
																											goto IL_064d;
																										case 31:
																										case 131:
																											goto IL_0660;
																										case 87:
																											goto IL_0682;
																										case 129:
																											goto IL_0690;
																										case 117:
																											goto IL_069e;
																										case 132:
																											goto IL_06b1;
																										case 0:
																											goto IL_06d5;
																										case 90:
																											goto IL_06f6;
																										case 121:
																										case 135:
																											goto IL_0709;
																										case 134:
																											goto IL_0717;
																										case 14:
																										case 76:
																											goto IL_0725;
																										case 42:
																											goto IL_0733;
																										case 74:
																											goto IL_074b;
																										case 56:
																											goto IL_0759;
																										case 10:
																											goto IL_076c;
																										case 78:
																										case 101:
																											goto IL_0777;
																										case 80:
																											goto IL_0785;
																										case 19:
																										case 55:
																											goto IL_0793;
																										case 127:
																											goto IL_07af;
																										case 97:
																										case 124:
																											goto IL_07bd;
																										case 40:
																											goto IL_07cb;
																										case 13:
																										case 35:
																											goto IL_07d9;
																										case 70:
																											goto IL_07ed;
																										case 4:
																											goto IL_0825;
																										case 53:
																										case 81:
																											goto IL_083e;
																										case 27:
																											goto IL_0857;
																										case 6:
																										case 15:
																										case 23:
																										case 30:
																										case 32:
																										case 36:
																										case 44:
																										case 45:
																										case 48:
																										case 54:
																										case 57:
																										case 60:
																										case 73:
																										case 94:
																										case 95:
																										case 98:
																										case 102:
																										case 107:
																										case 109:
																										case 120:
																										case 130:
																										case 139:
																											goto end_IL_02a0;
																										case 67:
																											goto IL_087c;
																										case 20:
																										case 43:
																										case 62:
																										case 65:
																										case 66:
																										case 71:
																										case 77:
																										case 86:
																										case 88:
																										case 100:
																										case 105:
																										case 106:
																										case 108:
																										case 118:
																										case 140:
																											goto IL_088a;
																										case 58:
																											goto IL_089d;
																										case 38:
																											goto IL_08a7;
																										case 138:
																											goto IL_08b2;
																										case 82:
																											goto IL_08c2;
																										case 7:
																											goto IL_08d2;
																										case 136:
																											goto IL_08e2;
																										case 21:
																										case 112:
																											goto IL_08f2;
																										case 12:
																											goto IL_0902;
																										case 125:
																											goto IL_0912;
																										case 16:
																											break;
																										case 28:
																											break;
																										case 75:
																											break;
																										case 128:
																											break;
																										case 141:
																											break;
																										case 103:
																											Class300.smethod_0();
																											break;
																										case 104:
																											Class296.Aw4EYyy3h();
																											goto case 103;
																										case 61:
																										case 137:
																											return;
																										}
																										break;
																										IL_083e:
																										string_0 = (string[])array3[num5 - 1];
																										goto IL_0857;
																										IL_0857:
																										num5--;
																										goto IL_088a;
																										IL_076c:
																										if (12 < b)
																										{
																											goto IL_0777;
																										}
																										goto IL_07af;
																										IL_0777:
																										if (13 < b)
																										{
																											goto end_IL_02a0;
																										}
																										goto IL_0785;
																										IL_0785:
																										if (13 > b)
																										{
																											goto end_IL_02a0;
																										}
																										goto IL_0793;
																										IL_0793:
																										num6 = ptr2;
																										num7 = -200;
																										num4 = 1;
																										ptr2 = num6 + num7;
																										goto IL_088a;
																										IL_07af:
																										if (12 > b)
																										{
																											goto IL_07bd;
																										}
																										goto IL_083e;
																										IL_07bd:
																										if (11 < b)
																										{
																											goto end_IL_02a0;
																										}
																										goto IL_07cb;
																										IL_07cb:
																										if (11 > b)
																										{
																											goto end_IL_02a0;
																										}
																										goto IL_07d9;
																										IL_07d9:
																										array2[num5 - 1] = 5;
																										goto IL_07ed;
																										IL_07ed:
																										array3[num5 - 1] = ((delegate*<string[], string>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																										goto IL_0825;
																										IL_0825:
																										ptr2 += 8;
																										num = 108;
																										goto IL_088a;
																									}
																									break;
																								}
																								goto IL_02db;
																								IL_0307:
																								((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																								goto IL_0345;
																								IL_0345:
																								num5 -= 3;
																								goto IL_088a;
																								IL_02db:
																								if (10 > b)
																								{
																									goto IL_02e6;
																								}
																								goto IL_0307;
																								IL_02e6:
																								if (8 >= b)
																								{
																									goto IL_02f4;
																								}
																								goto IL_0709;
																								IL_02f4:
																								if (8 > b)
																								{
																									goto end_IL_02a0;
																								}
																								goto IL_05c1;
																								IL_05c1:
																								array2[num5] = array2[num5 - 1];
																								goto IL_05d9;
																								IL_05d9:
																								array4[num5 - 0] = array4[num5 - 1];
																								goto IL_06b1;
																								IL_06b1:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_06d5;
																								IL_06d5:
																								array3[num5] = array3[num5 - 1];
																								num = 90;
																								goto IL_06f6;
																								IL_06f6:
																								num5++;
																								goto IL_088a;
																								IL_0709:
																								if (9 < b)
																								{
																									goto end_IL_02a0;
																								}
																								goto IL_0717;
																								IL_0717:
																								if (9 > b)
																								{
																									goto end_IL_02a0;
																								}
																								goto IL_0725;
																								IL_0725:
																								array2[num5] = 5;
																								goto IL_0733;
																								IL_0733:
																								array3[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_074b;
																								IL_074b:
																								num5++;
																								goto IL_0759;
																								IL_0759:
																								ptr2 += 8;
																								goto IL_088a;
																							}
																							break;
																						}
																						goto IL_0358;
																						IL_0660:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																						num = 87;
																						goto IL_0682;
																						IL_0358:
																						if (7 > b)
																						{
																							goto IL_0366;
																						}
																						goto IL_047f;
																						IL_0366:
																						if (3 >= b)
																						{
																							goto IL_0371;
																						}
																						goto IL_03da;
																						IL_0371:
																						if (3 > b)
																						{
																							goto IL_037f;
																						}
																						goto IL_04e9;
																						IL_037f:
																						if (1 < b)
																						{
																							goto IL_038d;
																						}
																						goto IL_04aa;
																						IL_038d:
																						if (2 < b)
																						{
																							goto end_IL_02a0;
																						}
																						goto IL_039b;
																						IL_039b:
																						if (2 > b)
																						{
																							goto end_IL_02a0;
																						}
																						goto IL_03a9;
																						IL_03a9:
																						((delegate*<void>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])();
																						num = 29;
																						goto IL_03c7;
																						IL_03c7:
																						ptr2 += 8;
																						goto IL_088a;
																						IL_04aa:
																						if (1 > b)
																						{
																						}
																						goto end_IL_02a0;
																						IL_04e9:
																						array7 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_04f8;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_05a0;
																						IL_0682:
																						array2[num5] = 0;
																						goto IL_0690;
																						IL_0690:
																						num5++;
																						goto IL_069e;
																						IL_069e:
																						ptr2 += 8;
																						goto IL_088a;
																						IL_05a0:
																						array2[num5] = 5;
																						goto IL_05ae;
																						IL_05ae:
																						num5++;
																						goto IL_088a;
																						IL_03da:
																						if (5 < b)
																						{
																							goto IL_03e8;
																						}
																						goto IL_04bd;
																						IL_03e8:
																						if (6 < b)
																						{
																							goto end_IL_02a0;
																						}
																						goto IL_03f6;
																						IL_03f6:
																						if (6 > b)
																						{
																							num = 44;
																							goto end_IL_02a0;
																						}
																						goto IL_0401;
																						IL_0401:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																						goto IL_0441;
																						IL_0441:
																						array2[num5 - 2] = 0;
																						goto IL_0455;
																						IL_0455:
																						num5--;
																						num = 43;
																						goto IL_088a;
																						IL_047f:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																						goto IL_04d0;
																						IL_04bd:
																						if (5 > b)
																						{
																							goto IL_05fc;
																						}
																						goto IL_0660;
																						IL_05fc:
																						if (4 < b)
																						{
																							goto end_IL_02a0;
																						}
																						num = 84;
																						goto IL_0613;
																						IL_04d0:
																						array2[num5 - 1] = 5;
																						goto IL_088a;
																						IL_0613:
																						if (4 > b)
																						{
																							goto end_IL_02a0;
																						}
																						goto IL_0621;
																						IL_0621:
																						array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_063f;
																						IL_063f:
																						ptr2 += 8;
																						goto IL_064d;
																						IL_064d:
																						num5--;
																						goto IL_088a;
																					}
																					goto end_IL_02b0;
																					continue;
																					end_IL_02a0:
																					break;
																					IL_02a0:;
																				}
																			}
																			((delegate*<void>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])();
																			goto IL_087c;
																			IL_087c:
																			ptr2 += 8;
																			goto IL_088a;
																			continue;
																			end_IL_02b0:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
					}
					continue;
					IL_04f8:
					while (true)
					{
						IL_04f8_2:
						array = new byte[4];
						while (true)
						{
							num9 = ptr2;
							byte b2 = *num9;
							ptr2 = num9 + 4;
							int num10 = *(int*)(ptr2 + num3);
							ptr2 += 8;
							byte* ptr3 = ptr2 + num10;
							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
							while (ptr2 != ptr3)
							{
								*ptr4 = (byte)(*ptr2 ^ b2);
								ptr2++;
								ptr4++;
							}
							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
							while (true)
							{
								IL_05a0_2:
								array2[num5] = 5;
								while (true)
								{
									IL_05ae_2:
									num5++;
									while (true)
									{
										IL_088a_2:
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_02b0_2:
													if (b >= 1)
													{
														while (b <= 13)
														{
															while (true)
															{
																if (7 < b)
																{
																	while (true)
																	{
																		if (10 < b)
																		{
																			num = 148;
																			while (true)
																			{
																				if (num == 148)
																				{
																					goto IL_076c_2;
																				}
																				if (num != 1129)
																				{
																					goto IL_07af_2;
																				}
																				switch (num)
																				{
																				case 115:
																					goto end_IL_026d;
																				case 116:
																					goto end_IL_0280;
																				case 111:
																					goto end_IL_0290;
																				case 126:
																					goto IL_02b0_2;
																				case 114:
																					goto end_IL_02b0_2;
																				case 99:
																				case 133:
																					goto end_IL_02c0;
																				case 39:
																					goto IL_02db_2;
																				case 34:
																					goto IL_02e6_2;
																				case 41:
																					goto IL_02f4_2;
																				case 50:
																				case 68:
																					goto IL_0307_2;
																				case 18:
																					goto IL_0345_2;
																				case 91:
																					goto IL_0358_2;
																				case 11:
																				case 33:
																					goto IL_0366_2;
																				case 9:
																					goto IL_0371_2;
																				case 22:
																				case 69:
																					goto IL_037f_2;
																				case 8:
																				case 46:
																					goto IL_038d_2;
																				case 59:
																					goto IL_039b_2;
																				case 49:
																				case 51:
																					goto IL_03a9_2;
																				case 29:
																					goto IL_03c7_2;
																				case 64:
																					goto IL_03da_2;
																				case 37:
																					goto IL_03e8_2;
																				case 25:
																					goto IL_03f6_2;
																				case 2:
																				case 63:
																					goto IL_0401_2;
																				case 1:
																					goto IL_0441_2;
																				case 24:
																					goto IL_0455_2;
																				case 26:
																				case 89:
																					goto IL_047f_2;
																				case 92:
																					goto IL_04aa_2;
																				case 93:
																					goto IL_04bd_2;
																				case 96:
																					goto IL_04d0_2;
																				case 79:
																				case 113:
																					goto end_IL_02d0;
																				case 110:
																					goto IL_05a0_2;
																				case 85:
																					goto IL_05ae_2;
																				case 52:
																				case 119:
																					goto IL_05c1_2;
																				case 5:
																					goto IL_05d9_2;
																				case 17:
																				case 122:
																					goto IL_05fc_2;
																				case 84:
																					goto IL_0613_2;
																				case 3:
																				case 72:
																					goto IL_0621_2;
																				case 123:
																					goto IL_063f_2;
																				case 83:
																					goto IL_064d_2;
																				case 31:
																				case 131:
																					goto IL_0660_2;
																				case 87:
																					goto IL_0682_2;
																				case 129:
																					goto IL_0690_2;
																				case 117:
																					goto IL_069e_2;
																				case 132:
																					goto IL_06b1_2;
																				case 0:
																					goto IL_06d5_2;
																				case 90:
																					goto IL_06f6_2;
																				case 121:
																				case 135:
																					goto IL_0709_2;
																				case 134:
																					goto IL_0717_2;
																				case 14:
																				case 76:
																					goto IL_0725_2;
																				case 42:
																					goto IL_0733_2;
																				case 74:
																					goto IL_074b_2;
																				case 56:
																					goto IL_0759_2;
																				case 10:
																					goto IL_076c_2;
																				case 78:
																				case 101:
																					goto IL_0777_2;
																				case 80:
																					goto IL_0785_2;
																				case 19:
																				case 55:
																					goto IL_0793_2;
																				case 127:
																					goto IL_07af_2;
																				case 97:
																				case 124:
																					goto IL_07bd_2;
																				case 40:
																					goto IL_07cb_2;
																				case 13:
																				case 35:
																					goto IL_07d9_2;
																				case 70:
																					goto IL_07ed_2;
																				case 4:
																					goto IL_0825_2;
																				case 53:
																				case 81:
																					goto IL_083e_2;
																				case 27:
																					goto IL_0857_2;
																				case 6:
																				case 15:
																				case 23:
																				case 30:
																				case 32:
																				case 36:
																				case 44:
																				case 45:
																				case 48:
																				case 54:
																				case 57:
																				case 60:
																				case 73:
																				case 94:
																				case 95:
																				case 98:
																				case 102:
																				case 107:
																				case 109:
																				case 120:
																				case 130:
																				case 139:
																					goto end_IL_02a0_2;
																				case 67:
																					goto IL_087c_2;
																				case 20:
																				case 43:
																				case 62:
																				case 65:
																				case 66:
																				case 71:
																				case 77:
																				case 86:
																				case 88:
																				case 100:
																				case 105:
																				case 106:
																				case 108:
																				case 118:
																				case 140:
																					goto IL_088a_2;
																				case 58:
																					ptr2 = ptr;
																					goto IL_088a_2;
																				case 38:
																					ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SecurityRegistryPermissionCryptoAPITransform.VTIPrivilegeNotHeldException);
																					goto case 58;
																				case 138:
																					array6 = new object[52];
																					goto case 38;
																				case 82:
																					array5 = new long[4];
																					goto case 138;
																				case 7:
																					array4 = new int[4];
																					goto case 82;
																				case 136:
																					array3 = new object[4];
																					goto case 7;
																				case 21:
																				case 112:
																					array2 = new byte[4];
																					goto case 136;
																				case 12:
																					num3 = num2 * 4;
																					goto case 21;
																				case 125:
																					num2 = 1;
																					goto case 12;
																				case 16:
																				case 28:
																				case 47:
																				case 75:
																				case 128:
																				case 141:
																					goto end_IL_0506;
																				case 103:
																					goto end_IL_091d;
																				case 104:
																					goto end_IL_093c;
																				case 61:
																				case 137:
																					return;
																				}
																				continue;
																				IL_083e_2:
																				string_0 = (string[])array3[num5 - 1];
																				goto IL_0857_2;
																				IL_0857_2:
																				num5--;
																				goto IL_088a_2;
																				IL_076c_2:
																				if (12 < b)
																				{
																					goto IL_0777_2;
																				}
																				goto IL_07af_2;
																				IL_0777_2:
																				if (13 < b)
																				{
																					goto end_IL_02a0_2;
																				}
																				goto IL_0785_2;
																				IL_0785_2:
																				if (13 > b)
																				{
																					goto end_IL_02a0_2;
																				}
																				goto IL_0793_2;
																				IL_0793_2:
																				num6 = ptr2;
																				num7 = -200;
																				num4 = 1;
																				ptr2 = num6 + num7;
																				goto IL_088a_2;
																				IL_07af_2:
																				if (12 > b)
																				{
																					goto IL_07bd_2;
																				}
																				goto IL_083e_2;
																				IL_07bd_2:
																				if (11 < b)
																				{
																					goto end_IL_02a0_2;
																				}
																				goto IL_07cb_2;
																				IL_07cb_2:
																				if (11 > b)
																				{
																					goto end_IL_02a0_2;
																				}
																				goto IL_07d9_2;
																				IL_07d9_2:
																				array2[num5 - 1] = 5;
																				goto IL_07ed_2;
																				IL_07ed_2:
																				array3[num5 - 1] = ((delegate*<string[], string>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																				goto IL_0825_2;
																				IL_0825_2:
																				ptr2 += 8;
																				num = 108;
																				goto IL_088a_2;
																				continue;
																				end_IL_026d:
																				break;
																			}
																			continue;
																		}
																		goto IL_02db_2;
																		IL_0307_2:
																		((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																		goto IL_0345_2;
																		IL_0345_2:
																		num5 -= 3;
																		goto IL_088a_2;
																		IL_02db_2:
																		if (10 > b)
																		{
																			goto IL_02e6_2;
																		}
																		goto IL_0307_2;
																		IL_02e6_2:
																		if (8 >= b)
																		{
																			goto IL_02f4_2;
																		}
																		goto IL_0709_2;
																		IL_02f4_2:
																		if (8 > b)
																		{
																			goto end_IL_02a0_2;
																		}
																		goto IL_05c1_2;
																		IL_05c1_2:
																		array2[num5] = array2[num5 - 1];
																		goto IL_05d9_2;
																		IL_05d9_2:
																		array4[num5 - 0] = array4[num5 - 1];
																		goto IL_06b1_2;
																		IL_06b1_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																		goto IL_06d5_2;
																		IL_06d5_2:
																		array3[num5] = array3[num5 - 1];
																		num = 90;
																		goto IL_06f6_2;
																		IL_06f6_2:
																		num5++;
																		goto IL_088a_2;
																		IL_0709_2:
																		if (9 < b)
																		{
																			goto end_IL_02a0_2;
																		}
																		goto IL_0717_2;
																		IL_0717_2:
																		if (9 > b)
																		{
																			goto end_IL_02a0_2;
																		}
																		goto IL_0725_2;
																		IL_0725_2:
																		array2[num5] = 5;
																		goto IL_0733_2;
																		IL_0733_2:
																		array3[num5] = array6[*(int*)(ptr2 + num3)];
																		goto IL_074b_2;
																		IL_074b_2:
																		num5++;
																		goto IL_0759_2;
																		IL_0759_2:
																		ptr2 += 8;
																		goto IL_088a_2;
																		continue;
																		end_IL_0280:
																		break;
																	}
																	continue;
																}
																goto IL_0358_2;
																IL_069e_2:
																ptr2 += 8;
																goto IL_088a_2;
																IL_0358_2:
																if (7 > b)
																{
																	goto IL_0366_2;
																}
																goto IL_047f_2;
																IL_0366_2:
																if (3 >= b)
																{
																	goto IL_0371_2;
																}
																goto IL_03da_2;
																IL_0371_2:
																if (3 <= b)
																{
																	goto end_IL_02d0;
																}
																goto IL_037f_2;
																IL_037f_2:
																if (1 < b)
																{
																	goto IL_038d_2;
																}
																goto IL_04aa_2;
																IL_038d_2:
																if (2 < b)
																{
																	goto end_IL_02a0_2;
																}
																goto IL_039b_2;
																IL_039b_2:
																if (2 > b)
																{
																	goto end_IL_02a0_2;
																}
																goto IL_03a9_2;
																IL_03a9_2:
																((delegate*<void>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])();
																num = 29;
																goto IL_03c7_2;
																IL_03c7_2:
																ptr2 += 8;
																goto IL_088a_2;
																IL_04aa_2:
																if (1 > b)
																{
																}
																goto end_IL_02a0_2;
																IL_03da_2:
																if (5 < b)
																{
																	goto IL_03e8_2;
																}
																goto IL_04bd_2;
																IL_03e8_2:
																if (6 < b)
																{
																	goto end_IL_02a0_2;
																}
																goto IL_03f6_2;
																IL_03f6_2:
																if (6 > b)
																{
																	num = 44;
																	goto end_IL_02a0_2;
																}
																goto IL_0401_2;
																IL_0401_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																goto IL_0441_2;
																IL_0441_2:
																array2[num5 - 2] = 0;
																goto IL_0455_2;
																IL_0455_2:
																num5--;
																num = 43;
																goto IL_088a_2;
																IL_047f_2:
																array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																goto IL_04d0_2;
																IL_04bd_2:
																if (5 > b)
																{
																	goto IL_05fc_2;
																}
																goto IL_0660_2;
																IL_05fc_2:
																if (4 < b)
																{
																	goto end_IL_02a0_2;
																}
																num = 84;
																goto IL_0613_2;
																IL_04d0_2:
																array2[num5 - 1] = 5;
																goto IL_088a_2;
																IL_0613_2:
																if (4 > b)
																{
																	goto end_IL_02a0_2;
																}
																goto IL_0621_2;
																IL_0621_2:
																array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																goto IL_063f_2;
																IL_063f_2:
																ptr2 += 8;
																goto IL_064d_2;
																IL_064d_2:
																num5--;
																goto IL_088a_2;
																IL_0660_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																num = 87;
																goto IL_0682_2;
																IL_0682_2:
																array2[num5] = 0;
																goto IL_0690_2;
																IL_0690_2:
																num5++;
																goto IL_069e_2;
																continue;
																end_IL_0290:
																break;
															}
															continue;
															end_IL_02a0_2:
															break;
														}
													}
													((delegate*<void>)ModeASCIIgetApplicationUrl[*(int*)(ptr2 + num3)])();
													goto IL_087c_2;
													IL_087c_2:
													ptr2 += 8;
													goto IL_088a_2;
													continue;
													end_IL_02b0_2:
													break;
												}
												continue;
												end_IL_02c0:
												break;
											}
											continue;
											end_IL_02d0:
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							array7 = array3;
							num8 = num5;
							if (array == null)
							{
								goto IL_04f8_2;
							}
							continue;
							end_IL_0506:
							break;
						}
						break;
					}
					continue;
					end_IL_091d:
					break;
				}
				continue;
				end_IL_093c:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeftWindowsgetConfiguredGuid.SetSecurityDescriptorBinaryFormPermissionSetAttribute);
										num = 101;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 89;
												while (true)
												{
													IL_05d3:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0289:
															byte b = *ptr2;
															while (true)
															{
																IL_0279:
																ptr2++;
																while (true)
																{
																	IL_0269:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0249:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0239:
																						if (8 >= b)
																						{
																							num = 92;
																							while (true)
																							{
																								IL_0229:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_0219:
																										if (6 < b)
																										{
																											while (true)
																											{
																												IL_0206:
																												if (7 < b)
																												{
																													num = 114;
																													while (num != 114)
																													{
																														if (num != 1095)
																														{
																															goto end_IL_0269;
																														}
																														switch (num)
																														{
																														case 74:
																														case 102:
																															goto IL_0206;
																														case 58:
																														case 88:
																															goto IL_0219;
																														case 92:
																															goto IL_0229;
																														case 17:
																														case 63:
																															goto IL_0239;
																														case 65:
																															goto IL_0249;
																														case 48:
																															goto IL_0259;
																														case 32:
																															goto IL_0269;
																														case 39:
																															goto IL_0279;
																														case 14:
																														case 46:
																															goto IL_0289;
																														case 1:
																															goto IL_0294;
																														case 8:
																															goto IL_02a4;
																														case 11:
																														case 13:
																															goto IL_02b2;
																														case 54:
																															goto IL_02d7;
																														case 77:
																															goto IL_02e5;
																														case 82:
																															goto IL_02f8;
																														case 52:
																															goto IL_0306;
																														case 60:
																														case 87:
																															goto IL_0316;
																														case 79:
																															goto IL_0378;
																														case 90:
																															goto IL_038b;
																														case 103:
																															goto IL_039e;
																														case 25:
																														case 71:
																															goto IL_03ac;
																														case 85:
																															goto IL_03c8;
																														case 4:
																														case 97:
																															goto IL_03d6;
																														case 104:
																															goto IL_0416;
																														case 10:
																															goto IL_042a;
																														case 51:
																															goto IL_043d;
																														case 15:
																														case 42:
																															goto IL_044b;
																														case 24:
																														case 59:
																															goto IL_0456;
																														case 37:
																														case 62:
																															goto IL_0461;
																														case 45:
																															goto IL_046f;
																														case 80:
																															goto IL_0482;
																														case 34:
																														case 67:
																															goto IL_0499;
																														case 6:
																															goto IL_04b1;
																														case 19:
																														case 33:
																															goto IL_04bc;
																														case 75:
																															goto IL_04e5;
																														case 95:
																															goto IL_04f3;
																														case 100:
																															goto IL_0506;
																														case 3:
																															goto IL_0514;
																														case 57:
																														case 76:
																															goto IL_0522;
																														case 36:
																															goto IL_053b;
																														case 27:
																															goto IL_0549;
																														case 18:
																															goto IL_0557;
																														case 41:
																														case 96:
																															goto IL_0567;
																														case 5:
																															goto IL_0575;
																														case 21:
																															goto IL_0598;
																														case 61:
																															goto IL_05a2;
																														case 16:
																															goto IL_05b0;
																														case 22:
																														case 26:
																														case 28:
																														case 35:
																														case 38:
																														case 43:
																														case 47:
																														case 49:
																														case 53:
																														case 64:
																														case 66:
																														case 68:
																														case 70:
																														case 73:
																														case 78:
																														case 81:
																														case 83:
																														case 86:
																														case 91:
																														case 98:
																															goto end_IL_01f3;
																														case 9:
																														case 12:
																														case 23:
																														case 40:
																														case 44:
																														case 55:
																														case 56:
																														case 89:
																														case 93:
																														case 94:
																														case 99:
																														case 106:
																															goto IL_05d3;
																														case 50:
																															goto end_IL_05d3;
																														case 101:
																															goto end_IL_05e6;
																														case 7:
																															goto end_IL_05f1;
																														case 0:
																															goto end_IL_05fb;
																														case 20:
																															goto end_IL_060f;
																														case 72:
																														case 105:
																															goto end_IL_0624;
																														case 107:
																															goto end_IL_0634;
																														case 2:
																														case 84:
																															goto end_IL_0644;
																														case 30:
																															goto end_IL_0654;
																														case 31:
																															goto end_IL_0664;
																														case 29:
																														case 69:
																															goto end_IL_0269;
																														}
																														continue;
																														end_IL_01f3:
																														break;
																													}
																													break;
																												}
																												goto IL_02a4;
																												IL_0306:
																												num5++;
																												goto IL_038b;
																												IL_038b:
																												ptr2 += 8;
																												goto IL_05d3;
																												IL_02a4:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_02b2;
																												IL_02b2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_02f8;
																												IL_02f8:
																												array[num5] = 0;
																												goto IL_0306;
																											}
																											break;
																										}
																										goto IL_03c8;
																										IL_042a:
																										num5--;
																										goto IL_05d3;
																										IL_03c8:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_03d6;
																										IL_03d6:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0416;
																										IL_0416:
																										array[num5 - 2] = 0;
																										goto IL_042a;
																									}
																									break;
																								}
																								goto IL_0316;
																								IL_0378:
																								num5 -= 2;
																								goto IL_05d3;
																								IL_0316:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0378;
																							}
																							break;
																						}
																						goto IL_0294;
																						IL_02d7:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_02e5;
																						IL_02e5:
																						if (10 > b)
																						{
																						}
																						break;
																						IL_0294:
																						if (9 < b)
																						{
																							goto IL_02d7;
																						}
																						goto IL_039e;
																						IL_039e:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_03ac;
																						IL_03ac:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto IL_05d3;
																					}
																					break;
																				}
																				goto IL_043d;
																				IL_05a2:
																				num5++;
																				goto IL_05b0;
																				IL_043d:
																				if (5 > b)
																				{
																					goto IL_044b;
																				}
																				goto IL_0567;
																				IL_044b:
																				if (2 < b)
																				{
																					goto IL_0456;
																				}
																				goto IL_04b1;
																				IL_0456:
																				if (3 < b)
																				{
																					goto IL_0461;
																				}
																				goto IL_0482;
																				IL_0461:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_046f;
																				IL_046f:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05d3;
																				IL_0482:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 34;
																				goto IL_0499;
																				IL_05b0:
																				ptr2 += 8;
																				goto IL_05d3;
																				IL_0499:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05d3;
																				IL_04b1:
																				if (2 <= b)
																				{
																					goto IL_04bc;
																				}
																				goto IL_0506;
																				IL_04bc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e5;
																				IL_04e5:
																				ptr2 += 8;
																				goto IL_04f3;
																				IL_04f3:
																				num5--;
																				goto IL_05d3;
																				IL_0506:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0514;
																				IL_0514:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0522;
																				IL_0522:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_053b;
																				IL_053b:
																				array[num5] = 0;
																				goto IL_0549;
																				IL_0549:
																				num5++;
																				goto IL_0557;
																				IL_0557:
																				ptr2 += 8;
																				goto IL_05d3;
																				IL_0567:
																				array[num5] = 0;
																				goto IL_0575;
																				IL_0575:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0598;
																				IL_0598:
																				array2[num5] = null;
																				goto IL_05a2;
																			}
																			break;
																			IL_0259:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05d3;
																	continue;
																	end_IL_0269:
																	break;
																}
																break;
															}
															break;
														}
													}
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05d3:
													break;
												}
												continue;
												end_IL_05e6:
												break;
											}
											continue;
											end_IL_05f1:
											break;
										}
										continue;
										end_IL_05fb:
										break;
									}
									continue;
									end_IL_060f:
									break;
								}
								continue;
								end_IL_0624:
								break;
							}
							continue;
							end_IL_0634:
							break;
						}
						continue;
						end_IL_0644:
						break;
					}
					continue;
					end_IL_0654:
					break;
				}
				continue;
				end_IL_0664:
				break;
			}
		}
	}

	private static float PushiObjectReader()
	{
		return Time.time;
	}

	private static string[] setLocalizationResourcesGetAssemblyName()
	{
		return string_0;
	}

	private static PhotonNetworkController VariantBoolLockType()
	{
		return PhotonNetworkController.Instance;
	}

	private static Room DependencyAttributeBlock()
	{
		return PhotonNetwork.CurrentRoom;
	}

	private static void EncodedEnumTypeBuildNumber(PhotonNetworkController photonNetworkController_0, string string_1, JoinType joinType_0)
	{
		photonNetworkController_0.AttemptToJoinSpecificRoom(string_1, joinType_0);
	}

	private static int WriteAsyncDelaySign(Class166 class166_1)
	{
		return class166_1.int_0;
	}

	private static float ModulusCheckId(Class166 class166_1)
	{
		return class166_1.float_0;
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 2;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct91.CommonStartMenuHStringMarshaler);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_029c:
															byte b = *ptr2;
															while (true)
															{
																IL_028c:
																ptr2++;
																while (true)
																{
																	IL_027c:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_025f:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_024f:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_023f:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_022f:
																										if (4 >= b)
																										{
																											while (4 > b)
																											{
																												num = 123;
																												while (num != 123)
																												{
																													if (num != 1104)
																													{
																														goto IL_04af;
																													}
																													switch (num)
																													{
																													case 61:
																														goto IL_021c;
																													case 59:
																														goto IL_022f;
																													case 84:
																														goto IL_023f;
																													case 26:
																														goto IL_024f;
																													case 71:
																														goto IL_025f;
																													case 38:
																														goto IL_026c;
																													case 93:
																														goto IL_027c;
																													case 76:
																														goto IL_028c;
																													case 55:
																													case 109:
																														goto IL_029c;
																													case 72:
																													case 104:
																														goto IL_02a7;
																													case 9:
																													case 15:
																														goto IL_02b2;
																													case 27:
																														goto IL_02c6;
																													case 45:
																													case 102:
																														goto IL_02d4;
																													case 95:
																														goto IL_02f9;
																													case 62:
																														goto IL_0307;
																													case 20:
																														goto IL_031a;
																													case 46:
																													case 86:
																														goto IL_0325;
																													case 90:
																														goto IL_0387;
																													case 101:
																													case 105:
																														goto IL_039a;
																													case 3:
																													case 13:
																														goto IL_03a5;
																													case 75:
																														goto IL_03b5;
																													case 60:
																													case 79:
																														goto IL_03c3;
																													case 49:
																														goto IL_0403;
																													case 100:
																														goto IL_0417;
																													case 116:
																														goto IL_042a;
																													case 29:
																													case 111:
																														goto IL_0438;
																													case 87:
																														goto IL_045b;
																													case 64:
																														goto IL_0469;
																													case 8:
																														goto IL_0480;
																													case 94:
																													case 115:
																														goto IL_0493;
																													case 39:
																														goto IL_04a1;
																													case 78:
																													case 80:
																														goto IL_04af;
																													case 36:
																														goto IL_04bd;
																													case 47:
																														goto IL_04e0;
																													case 77:
																														goto IL_04ea;
																													case 5:
																														goto IL_04f8;
																													case 70:
																														goto IL_0514;
																													case 23:
																													case 58:
																														goto IL_051f;
																													case 19:
																													case 99:
																														goto IL_0537;
																													case 103:
																														goto IL_0542;
																													case 25:
																													case 42:
																														goto IL_0550;
																													case 31:
																														goto IL_0569;
																													case 91:
																														goto IL_0577;
																													case 37:
																														goto IL_0585;
																													case 28:
																														goto IL_0598;
																													case 74:
																														goto IL_05a6;
																													case 11:
																													case 107:
																														goto IL_05b4;
																													case 1:
																														goto IL_05dd;
																													case 34:
																														goto IL_05eb;
																													case 65:
																													case 110:
																														goto IL_05fb;
																													case 32:
																														goto IL_063b;
																													case 50:
																														goto IL_064f;
																													case 0:
																													case 10:
																													case 12:
																													case 17:
																													case 24:
																													case 30:
																													case 35:
																													case 40:
																													case 43:
																													case 44:
																													case 51:
																													case 52:
																													case 54:
																													case 57:
																													case 69:
																													case 81:
																													case 82:
																													case 83:
																													case 85:
																													case 106:
																													case 113:
																													case 114:
																														goto end_IL_0209;
																													case 6:
																													case 7:
																													case 16:
																													case 21:
																													case 22:
																													case 33:
																													case 63:
																													case 66:
																													case 67:
																													case 73:
																													case 89:
																													case 98:
																													case 108:
																													case 112:
																														goto end_IL_021c;
																													case 68:
																														goto end_IL_0672;
																													case 14:
																														goto end_IL_0685;
																													case 92:
																														goto end_IL_068f;
																													case 88:
																														goto end_IL_069a;
																													case 4:
																													case 48:
																														goto end_IL_06af;
																													case 53:
																														goto end_IL_06bf;
																													case 2:
																														goto end_IL_06cf;
																													case 18:
																														goto end_IL_06df;
																													case 96:
																														goto end_IL_06ef;
																													case 97:
																														goto end_IL_06fa;
																													case 41:
																													case 56:
																														goto IL_0715;
																													}
																													continue;
																													end_IL_0209:
																													break;
																												}
																												goto end_IL_026c;
																												continue;
																												end_IL_021c:
																												break;
																												IL_021c:;
																											}
																											break;
																										}
																										goto IL_0493;
																										IL_04f8:
																										ptr2 += 8;
																										break;
																										IL_0493:
																										if (5 < b)
																										{
																											goto end_IL_026c;
																										}
																										goto IL_04a1;
																										IL_04a1:
																										if (5 > b)
																										{
																											goto end_IL_026c;
																										}
																										goto IL_04af;
																										IL_04af:
																										array[num5] = 0;
																										goto IL_04bd;
																										IL_04bd:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_04e0;
																										IL_04e0:
																										array2[num5] = null;
																										goto IL_04ea;
																										IL_04ea:
																										num5++;
																										goto IL_04f8;
																									}
																									break;
																								}
																								num = 70;
																								goto IL_0514;
																								IL_05dd:
																								ptr2 += 8;
																								goto IL_05eb;
																								IL_05eb:
																								num5--;
																								break;
																								IL_0514:
																								if (3 <= b)
																								{
																									goto IL_051f;
																								}
																								goto IL_0537;
																								IL_051f:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0537:
																								if (1 >= b)
																								{
																									goto IL_0542;
																								}
																								goto IL_0598;
																								IL_0542:
																								if (1 > b)
																								{
																									goto end_IL_026c;
																								}
																								goto IL_0550;
																								IL_0550:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0569;
																								IL_0569:
																								array[num5] = 0;
																								goto IL_0577;
																								IL_0577:
																								num5++;
																								goto IL_0585;
																								IL_0585:
																								ptr2 += 8;
																								break;
																								IL_0598:
																								if (2 < b)
																								{
																									goto end_IL_026c;
																								}
																								goto IL_05a6;
																								IL_05a6:
																								if (2 > b)
																								{
																									goto end_IL_026c;
																								}
																								goto IL_05b4;
																								IL_05b4:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05dd;
																							}
																							break;
																						}
																						goto IL_05fb;
																						IL_064f:
																						num5--;
																						break;
																						IL_05fb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_063b;
																						IL_063b:
																						array[num5 - 2] = 0;
																						goto IL_064f;
																					}
																					break;
																				}
																				goto IL_02a7;
																				IL_0403:
																				array[num5 - 2] = 0;
																				goto IL_0417;
																				IL_02a7:
																				if (9 < b)
																				{
																					goto IL_02b2;
																				}
																				goto IL_031a;
																				IL_02b2:
																				if (10 >= b)
																				{
																					num = 27;
																					goto IL_02c6;
																				}
																				goto IL_02f9;
																				IL_0417:
																				num5--;
																				break;
																				IL_02c6:
																				if (10 > b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_02d4;
																				IL_02d4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 6;
																				break;
																				IL_02f9:
																				if (11 < b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_0307;
																				IL_0307:
																				if (11 <= b)
																				{
																				}
																				goto end_IL_026c;
																				IL_031a:
																				if (9 <= b)
																				{
																					goto IL_0325;
																				}
																				goto IL_039a;
																				IL_0325:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0387;
																				IL_0387:
																				num5 -= 2;
																				break;
																				IL_039a:
																				if (7 < b)
																				{
																					goto IL_03a5;
																				}
																				goto IL_03b5;
																				IL_03a5:
																				if (8 < b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_042a;
																				IL_042a:
																				if (8 > b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_0438;
																				IL_0438:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_045b;
																				IL_045b:
																				array[num5] = 0;
																				goto IL_0469;
																				IL_0469:
																				num5++;
																				num = 8;
																				goto IL_0480;
																				IL_0480:
																				ptr2 += 8;
																				break;
																				IL_03b5:
																				if (7 > b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_03c3;
																				IL_03c3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0403;
																			}
																			goto end_IL_027c;
																			continue;
																			end_IL_026c:
																			break;
																			IL_026c:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_027c:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0715;
													IL_0715:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0672:
													break;
												}
												continue;
												end_IL_0685:
												break;
											}
											continue;
											end_IL_068f:
											break;
										}
										continue;
										end_IL_069a:
										break;
									}
									continue;
									end_IL_06af:
									break;
								}
								continue;
								end_IL_06bf:
								break;
							}
							continue;
							end_IL_06cf:
							break;
						}
						continue;
						end_IL_06df:
						break;
					}
					continue;
					end_IL_06ef:
					break;
				}
				continue;
				end_IL_06fa:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_2)
	{
		int num = 27;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StrongNamePublicKeyBlobParallelLoopEnd.UrtUserNotImpersonated);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b5:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0298:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0288:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_027b:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_026b:
																									if (5 < b)
																									{
																										while (6 >= b)
																										{
																											while (6 <= b)
																											{
																												num = 134;
																												while (true)
																												{
																													if (num != 134)
																													{
																														if (num != 1115)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 107:
																															goto IL_0248;
																														case 105:
																															goto IL_025b;
																														case 60:
																															goto IL_026b;
																														case 51:
																														case 111:
																															goto IL_027b;
																														case 100:
																															goto IL_0288;
																														case 22:
																															goto IL_0298;
																														case 102:
																															goto IL_02a5;
																														case 70:
																															goto IL_02b5;
																														case 104:
																															goto end_IL_02b5;
																														case 13:
																														case 64:
																															goto end_IL_02c5;
																														case 39:
																															goto IL_02e0;
																														case 32:
																														case 55:
																															goto IL_02f3;
																														case 35:
																															goto IL_0301;
																														case 31:
																														case 62:
																															goto IL_030f;
																														case 6:
																															goto IL_031a;
																														case 49:
																														case 52:
																															goto IL_0328;
																														case 45:
																															goto IL_038f;
																														case 3:
																															goto IL_039d;
																														case 66:
																															goto IL_03b0;
																														case 41:
																															goto IL_03bb;
																														case 69:
																															goto IL_03ce;
																														case 59:
																															goto IL_03dc;
																														case 79:
																															goto IL_03ef;
																														case 63:
																															goto IL_03fa;
																														case 7:
																															goto IL_0408;
																														case 5:
																														case 83:
																															goto IL_041b;
																														case 21:
																															goto IL_0426;
																														case 11:
																															goto IL_0439;
																														case 80:
																															goto IL_0447;
																														case 23:
																														case 88:
																															goto IL_045a;
																														case 1:
																															goto IL_0468;
																														case 38:
																															goto IL_048b;
																														case 94:
																															goto end_IL_0235;
																														case 95:
																															goto IL_04ad;
																														case 97:
																															goto IL_04c9;
																														case 10:
																														case 42:
																															goto IL_04d7;
																														case 76:
																														case 110:
																															goto IL_04ea;
																														case 103:
																															goto IL_0513;
																														case 40:
																															goto IL_0521;
																														case 19:
																														case 114:
																															goto IL_0534;
																														case 93:
																															goto IL_054d;
																														case 109:
																															goto IL_055b;
																														case 54:
																															goto IL_0569;
																														case 71:
																														case 117:
																															goto IL_057c;
																														case 50:
																															goto IL_05bc;
																														case 118:
																															goto IL_05d0;
																														case 119:
																															goto IL_05e3;
																														case 68:
																															goto IL_05f1;
																														case 67:
																														case 121:
																															goto IL_0604;
																														case 115:
																														case 126:
																															goto IL_0620;
																														case 91:
																															goto IL_0634;
																														case 99:
																															goto IL_0673;
																														case 86:
																														case 127:
																															goto IL_0686;
																														case 89:
																															goto IL_06a7;
																														case 8:
																															goto IL_06e7;
																														case 65:
																															goto IL_06fb;
																														case 0:
																														case 9:
																														case 12:
																														case 15:
																														case 16:
																														case 17:
																														case 28:
																														case 36:
																														case 43:
																														case 46:
																														case 47:
																														case 48:
																														case 58:
																														case 78:
																														case 84:
																														case 85:
																														case 92:
																														case 101:
																														case 108:
																														case 112:
																														case 120:
																														case 122:
																														case 123:
																														case 124:
																															goto end_IL_0248;
																														case 2:
																														case 53:
																															goto IL_0720;
																														case 25:
																															goto IL_0743;
																														case 20:
																															goto IL_0751;
																														case 37:
																															goto IL_075f;
																														case 4:
																														case 14:
																														case 18:
																														case 29:
																														case 33:
																														case 56:
																														case 61:
																														case 81:
																														case 82:
																														case 87:
																														case 90:
																														case 98:
																														case 106:
																														case 113:
																														case 116:
																														case 125:
																															goto end_IL_02d5;
																														case 74:
																															goto end_IL_076d;
																														case 34:
																															goto end_IL_0780;
																														case 72:
																															goto end_IL_078a;
																														case 77:
																															goto end_IL_0795;
																														case 24:
																														case 57:
																															goto end_IL_07aa;
																														case 30:
																															goto end_IL_07ba;
																														case 44:
																														case 75:
																															goto end_IL_07ca;
																														case 26:
																															goto end_IL_07da;
																														case 27:
																															goto end_IL_07ea;
																														case 73:
																														case 96:
																															goto IL_080e;
																														}
																														continue;
																													}
																													goto IL_06a7;
																													IL_06e7:
																													array[num5 - 2] = 0;
																													goto IL_06fb;
																													IL_06fb:
																													num5--;
																													goto end_IL_02d5;
																													IL_06a7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_06e7;
																													continue;
																													end_IL_0235:
																													break;
																												}
																												goto IL_049a;
																												continue;
																												end_IL_0248:
																												break;
																												IL_0248:;
																											}
																											break;
																											IL_025b:;
																										}
																										break;
																									}
																									goto IL_03ef;
																									IL_05f1:
																									ptr2 += 8;
																									goto end_IL_02d5;
																									IL_03ef:
																									if (5 > b)
																									{
																										goto IL_03fa;
																									}
																									goto IL_045a;
																									IL_03fa:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_0408;
																									IL_0408:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02d5;
																									IL_045a:
																									array[num5] = 0;
																									goto IL_0468;
																									IL_0468:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_048b;
																									IL_048b:
																									array2[num5] = null;
																									goto IL_05e3;
																									IL_05e3:
																									num5++;
																									goto IL_05f1;
																								}
																								break;
																							}
																							goto IL_02e0;
																							IL_0686:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 82;
																							goto end_IL_02d5;
																							IL_02e0:
																							if (3 > b)
																							{
																								goto IL_041b;
																							}
																							goto IL_0686;
																							IL_041b:
																							if (1 >= b)
																							{
																								goto IL_0426;
																							}
																							goto IL_0439;
																							IL_0426:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0534;
																							IL_0534:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_054d;
																							IL_054d:
																							array[num5] = 0;
																							goto IL_055b;
																							IL_055b:
																							num5++;
																							goto IL_0569;
																							IL_0569:
																							ptr2 += 8;
																							goto end_IL_02d5;
																							IL_0439:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0447;
																							IL_0447:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_04ea;
																							IL_04ea:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0513;
																							IL_0513:
																							ptr2 += 8;
																							goto IL_0521;
																							IL_0521:
																							num5--;
																							goto end_IL_02d5;
																						}
																						break;
																					}
																					goto IL_0720;
																					IL_075f:
																					ptr2 += 8;
																					goto end_IL_02d5;
																					IL_0720:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0743;
																					IL_0743:
																					array[num5] = 0;
																					goto IL_0751;
																					IL_0751:
																					num5++;
																					goto IL_075f;
																				}
																				break;
																			}
																			goto IL_02f3;
																			IL_04d7:
																			num5--;
																			goto end_IL_02d5;
																			IL_02f3:
																			if (10 >= b)
																			{
																				goto IL_0301;
																			}
																			goto IL_03b0;
																			IL_0301:
																			if (10 > b)
																			{
																				goto IL_030f;
																			}
																			goto IL_0620;
																			IL_030f:
																			if (8 >= b)
																			{
																				goto IL_031a;
																			}
																			goto IL_038f;
																			IL_031a:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0328;
																			IL_0328:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_049a;
																			IL_049a:
																			num5 -= 2;
																			goto end_IL_02d5;
																			IL_038f:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_039d;
																			IL_039d:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_057c;
																			IL_057c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05bc;
																			IL_05bc:
																			array[num5 - 2] = 0;
																			goto IL_05d0;
																			IL_05d0:
																			num5--;
																			goto end_IL_02d5;
																			IL_0620:
																			array[num5 - 1] = 0;
																			goto IL_0634;
																			IL_0634:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CreatorGroupServerSidCMSFILEHASHALGORITHM[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0673;
																			IL_0673:
																			ptr2 += 8;
																			goto end_IL_02d5;
																			IL_03b0:
																			if (12 < b)
																			{
																				goto IL_03bb;
																			}
																			goto IL_03ce;
																			IL_03bb:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_04ad;
																			IL_04ad:
																			if (13 > b)
																			{
																				num = 16;
																			}
																			break;
																			IL_0604:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d5;
																			IL_03ce:
																			if (12 > b)
																			{
																				goto IL_03dc;
																			}
																			goto IL_0604;
																			IL_03dc:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04c9;
																			IL_04c9:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_04d7;
																		}
																		break;
																		IL_02a5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d5;
																continue;
																end_IL_02b5:
																break;
															}
															continue;
															end_IL_02c5:
															break;
														}
														continue;
														end_IL_02d5:
														break;
													}
													continue;
												}
												num = 73;
												goto IL_080e;
												IL_080e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_076d:
												break;
											}
											continue;
											end_IL_0780:
											break;
										}
										continue;
										end_IL_078a:
										break;
									}
									continue;
									end_IL_0795:
									break;
								}
								continue;
								end_IL_07aa:
								break;
							}
							continue;
							end_IL_07ba:
							break;
						}
						continue;
						end_IL_07ca:
						break;
					}
					continue;
					end_IL_07da:
					break;
				}
				continue;
				end_IL_07ea:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 131;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									num = 15;
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RangeWorkerBidiCategory.CategoryMembershipDataXmlStrongNameIdentityPermission);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d8:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_02b8:
																			if (9 < b)
																			{
																				goto IL_06ec;
																			}
																			while (true)
																			{
																				IL_02a8:
																				if (9 <= b)
																				{
																					num = 158;
																					while (true)
																					{
																						if (num != 158)
																						{
																							if (num != 1139)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 58:
																								goto IL_02a8;
																							case 148:
																								goto IL_02b8;
																							case 62:
																								goto end_IL_02b8;
																							case 48:
																								goto IL_02d8;
																							case 116:
																								goto end_IL_02d8;
																							case 16:
																							case 56:
																								goto end_IL_02e8;
																							case 121:
																								goto IL_0303;
																							case 83:
																								goto IL_0311;
																							case 66:
																								goto IL_031f;
																							case 25:
																								goto IL_032a;
																							case 53:
																							case 119:
																								goto IL_0338;
																							case 108:
																								goto IL_0386;
																							case 13:
																								goto IL_0394;
																							case 97:
																								goto IL_03b0;
																							case 94:
																								goto IL_03be;
																							case 12:
																								goto IL_03cc;
																							case 75:
																							case 95:
																								goto IL_03da;
																							case 51:
																								goto IL_041a;
																							case 32:
																								goto IL_042e;
																							case 57:
																							case 80:
																								goto IL_0441;
																							case 63:
																								goto IL_048a;
																							case 129:
																								goto IL_04a0;
																							case 79:
																								goto IL_04b4;
																							case 133:
																								goto IL_04d0;
																							case 39:
																							case 134:
																								goto IL_04e3;
																							case 142:
																								goto IL_04f6;
																							case 49:
																							case 110:
																								goto IL_0501;
																							case 72:
																								goto IL_050f;
																							case 50:
																								goto IL_0532;
																							case 24:
																								goto IL_053c;
																							case 88:
																								goto IL_054a;
																							case 41:
																								goto IL_055d;
																							case 11:
																								goto IL_0568;
																							case 19:
																								goto IL_0576;
																							case 82:
																							case 99:
																								goto IL_0584;
																							case 47:
																								goto IL_05ad;
																							case 122:
																								goto IL_05c4;
																							case 106:
																								goto IL_05e0;
																							case 59:
																							case 81:
																								goto IL_05eb;
																							case 141:
																								goto IL_062b;
																							case 105:
																								goto IL_063f;
																							case 1:
																								goto IL_0652;
																							case 55:
																								goto IL_0660;
																							case 150:
																								goto IL_0673;
																							case 98:
																								goto IL_06b3;
																							case 137:
																								goto IL_06d0;
																							case 70:
																								goto IL_06ec;
																							case 146:
																								goto IL_06fa;
																							case 85:
																							case 140:
																								goto IL_0705;
																							case 86:
																								goto IL_071d;
																							case 46:
																								goto end_IL_0295;
																							case 138:
																								goto IL_0739;
																							case 109:
																								goto IL_074c;
																							case 87:
																								goto IL_075a;
																							case 20:
																							case 93:
																								goto IL_0765;
																							case 18:
																								goto IL_0779;
																							case 60:
																								goto IL_07b8;
																							case 27:
																								goto IL_07cb;
																							case 64:
																								goto IL_07d9;
																							case 67:
																							case 91:
																								goto IL_07e7;
																							case 114:
																								goto IL_0849;
																							case 21:
																								goto IL_085c;
																							case 43:
																								goto IL_086a;
																							case 151:
																								goto IL_0886;
																							case 4:
																								goto IL_0894;
																							case 35:
																							case 40:
																								goto IL_089f;
																							case 84:
																								goto IL_08cd;
																							case 65:
																								goto IL_08e0;
																							case 149:
																								goto IL_08ee;
																							case 2:
																							case 125:
																								goto IL_08fc;
																							case 6:
																								goto IL_0916;
																							case 17:
																								goto IL_0924;
																							case 31:
																								goto IL_0932;
																							case 107:
																								goto IL_0945;
																							case 42:
																								goto IL_0950;
																							case 28:
																							case 34:
																								goto IL_095b;
																							case 132:
																								goto IL_0989;
																							case 126:
																								goto IL_0999;
																							case 74:
																								goto IL_09a4;
																							case 36:
																							case 139:
																								goto IL_09af;
																							case 9:
																							case 14:
																							case 29:
																							case 33:
																							case 37:
																							case 54:
																							case 68:
																							case 78:
																							case 89:
																							case 92:
																							case 96:
																							case 103:
																							case 112:
																							case 115:
																							case 120:
																							case 124:
																							case 127:
																							case 128:
																							case 136:
																							case 143:
																								goto end_IL_02c8;
																							case 52:
																								goto IL_09e1;
																							case 5:
																								goto IL_09ef;
																							case 69:
																								goto IL_09fd;
																							case 0:
																							case 3:
																							case 7:
																							case 8:
																							case 22:
																							case 26:
																							case 30:
																							case 44:
																							case 45:
																							case 76:
																							case 77:
																							case 90:
																							case 101:
																							case 104:
																							case 113:
																							case 118:
																							case 123:
																							case 135:
																							case 144:
																							case 147:
																								goto end_IL_02f8;
																							case 145:
																								goto end_IL_0a0b;
																							case 61:
																								goto end_IL_0a1e;
																							case 15:
																								goto end_IL_0a28;
																							case 38:
																								goto end_IL_0a33;
																							case 100:
																								goto end_IL_0a43;
																							case 102:
																							case 117:
																								goto end_IL_0a5c;
																							case 73:
																								goto end_IL_0a6c;
																							case 10:
																							case 23:
																								goto end_IL_0a7c;
																							case 130:
																								goto end_IL_0a8c;
																							case 131:
																								goto end_IL_0a9c;
																							case 71:
																							case 111:
																								return;
																							}
																							continue;
																						}
																						goto IL_0673;
																						IL_06b3:
																						array[num5 - 2] = 0;
																						num = 137;
																						goto IL_06d0;
																						IL_06d0:
																						num5--;
																						num = 101;
																						goto end_IL_02f8;
																						IL_0673:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_06b3;
																						continue;
																						end_IL_0295:
																						break;
																					}
																					break;
																				}
																				goto IL_0303;
																				IL_062b:
																				array[num5 - 2] = 0;
																				goto IL_063f;
																				IL_063f:
																				num5--;
																				goto end_IL_02f8;
																				IL_0303:
																				if (4 < b)
																				{
																					goto IL_0311;
																				}
																				goto IL_04f6;
																				IL_0311:
																				if (6 < b)
																				{
																					goto IL_031f;
																				}
																				num = 97;
																				goto IL_03b0;
																				IL_031f:
																				if (7 >= b)
																				{
																					goto IL_032a;
																				}
																				goto IL_0386;
																				IL_032a:
																				if (7 > b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_0338;
																				IL_0338:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 129;
																				goto IL_04a0;
																				IL_04a0:
																				array[num5 - 2] = 0;
																				goto IL_04b4;
																				IL_04b4:
																				num5--;
																				num = 77;
																				goto end_IL_02f8;
																				IL_0386:
																				if (8 < b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_0394;
																				IL_0394:
																				if (8 > b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_04e3;
																				IL_04e3:
																				num5--;
																				goto end_IL_02f8;
																				IL_0652:
																				if (1 < b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_0660;
																				IL_03b0:
																				if (6 > b)
																				{
																					goto IL_03be;
																				}
																				goto IL_0441;
																				IL_03be:
																				if (5 < b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_03cc;
																				IL_03cc:
																				if (5 > b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_03da;
																				IL_03da:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_041a;
																				IL_041a:
																				array[num5 - 2] = 0;
																				goto IL_042e;
																				IL_042e:
																				num5--;
																				goto end_IL_02f8;
																				IL_0441:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 63;
																				goto IL_048a;
																				IL_048a:
																				array[num5 - 2] = 0;
																				goto IL_04d0;
																				IL_04d0:
																				num5--;
																				goto end_IL_02f8;
																				IL_04f6:
																				if (4 <= b)
																				{
																					goto IL_0501;
																				}
																				goto IL_055d;
																				IL_0501:
																				array[num5] = 0;
																				goto IL_050f;
																				IL_050f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0532;
																				IL_0532:
																				array2[num5] = null;
																				goto IL_053c;
																				IL_053c:
																				num5++;
																				goto IL_054a;
																				IL_054a:
																				ptr2 += 8;
																				goto end_IL_02f8;
																				IL_055d:
																				if (2 < b)
																				{
																					goto IL_0568;
																				}
																				num = 106;
																				goto IL_05e0;
																				IL_0568:
																				if (3 < b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_0576;
																				IL_0576:
																				if (3 > b)
																				{
																					goto end_IL_02c8;
																				}
																				goto IL_0584;
																				IL_0584:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ad;
																				IL_05ad:
																				ptr2 += 8;
																				num = 122;
																				goto IL_05c4;
																				IL_05c4:
																				num5--;
																				goto end_IL_02f8;
																				IL_0660:
																				if (1 > b)
																				{
																				}
																				goto end_IL_02c8;
																				IL_05e0:
																				if (2 <= b)
																				{
																					goto IL_05eb;
																				}
																				goto IL_0652;
																				IL_05eb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062b;
																			}
																			goto IL_072b;
																			IL_09a4:
																			if (17 > b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_09af;
																			IL_06ec:
																			if (13 >= b)
																			{
																				goto IL_06fa;
																			}
																			goto IL_0886;
																			IL_06fa:
																			if (13 <= b)
																			{
																				goto IL_0705;
																			}
																			goto IL_074c;
																			IL_0705:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_071d;
																			IL_071d:
																			array[num5] = 5;
																			goto IL_072b;
																			IL_072b:
																			num5++;
																			goto IL_0739;
																			IL_0739:
																			ptr2 += 8;
																			goto end_IL_02f8;
																			IL_074c:
																			if (11 >= b)
																			{
																				goto IL_075a;
																			}
																			goto IL_085c;
																			IL_075a:
																			if (11 <= b)
																			{
																				goto IL_0765;
																			}
																			goto IL_07cb;
																			IL_0765:
																			array[num5 - 1] = 0;
																			goto IL_0779;
																			IL_0779:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CommonAceWindowLeft[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_07b8;
																			IL_07b8:
																			ptr2 += 8;
																			goto end_IL_02f8;
																			IL_07cb:
																			if (10 < b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_07d9;
																			IL_07d9:
																			if (10 > b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_07e7;
																			IL_07e7:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0849;
																			IL_0849:
																			num5 -= 2;
																			goto end_IL_02f8;
																			IL_085c:
																			if (12 < b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_086a;
																			IL_086a:
																			if (12 > b)
																			{
																				goto end_IL_02c8;
																			}
																			num = 147;
																			goto end_IL_02f8;
																			IL_09af:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02f8;
																			IL_0886:
																			if (15 >= b)
																			{
																				goto IL_0894;
																			}
																			goto IL_0945;
																			IL_0894:
																			if (15 <= b)
																			{
																				goto IL_089f;
																			}
																			goto IL_08e0;
																			IL_089f:
																			((Class166)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_08cd;
																			IL_08cd:
																			num5 -= 2;
																			goto end_IL_02f8;
																			IL_08e0:
																			if (14 < b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_08ee;
																			IL_08ee:
																			if (14 > b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_08fc;
																			IL_08fc:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																			goto IL_0916;
																			IL_0916:
																			array[num5] = 3;
																			goto IL_0924;
																			IL_0924:
																			num5++;
																			goto IL_0932;
																			IL_0932:
																			ptr2 += 8;
																			goto end_IL_02f8;
																			IL_0945:
																			if (16 >= b)
																			{
																				goto IL_0950;
																			}
																			goto IL_0999;
																			IL_0950:
																			if (16 > b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_095b;
																			IL_095b:
																			((Class166)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0989;
																			IL_0989:
																			num5 -= 2;
																			goto end_IL_02f8;
																			IL_0999:
																			if (17 < b)
																			{
																				goto end_IL_02c8;
																			}
																			goto IL_09a4;
																			continue;
																			end_IL_02b8:
																			break;
																		}
																		continue;
																		end_IL_02c8:
																		break;
																	}
																}
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_09e1;
																IL_09fd:
																ptr2 += 8;
																goto end_IL_02f8;
																IL_09ef:
																num5++;
																goto IL_09fd;
																IL_09e1:
																array[num5] = 0;
																goto IL_09ef;
																continue;
																end_IL_02d8:
																break;
															}
															continue;
															end_IL_02e8:
															break;
														}
														continue;
														end_IL_02f8:
														break;
													}
													continue;
													end_IL_0a0b:
													break;
												}
												continue;
												end_IL_0a1e:
												break;
											}
											continue;
											end_IL_0a28:
											break;
										}
										continue;
										end_IL_0a33:
										break;
									}
									continue;
									end_IL_0a43:
									break;
								}
								continue;
								end_IL_0a5c:
								break;
							}
							continue;
							end_IL_0a6c:
							break;
						}
						continue;
						end_IL_0a7c:
						break;
					}
					continue;
					end_IL_0a8c:
					break;
				}
				continue;
				end_IL_0a9c:
				break;
			}
		}
	}
}
