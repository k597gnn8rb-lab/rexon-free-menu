using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gun Tracer: Straight", "Settings", "Cycle tracer styles", false, 3, ModType.const_1, false)]
internal class Class131 : MonoBehaviour
{
	internal readonly struct TracerOption
	{
		public readonly string string_0;

		public readonly Class8.TracerStyle tracerStyle_0;

		private static IntPtr[] IsWeakKeyTrimCheck;

		internal static object object_0;

		public unsafe TracerOption(string name, Class8.TracerStyle style)
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
			int num = 0;
			int num2 = 0;
			num2 = 0;
			int num3 = default(int);
			while (num2 != 2)
			{
				((delegate*<ref int, ref int, ref int, ref TracerOption, string, Class8.TracerStyle, void>)IsWeakKeyTrimCheck[num])(ref num, ref num2, ref num3, ref this, name, style);
			}
			num2 = 0;
		}

		static TracerOption()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 9;
						while (true)
						{
							if (num != 9)
							{
								if (num != 990)
								{
									break;
								}
								switch (num)
								{
								case 2:
									goto end_IL_002d;
								case 0:
									goto end_IL_003a;
								case 1:
									goto end_IL_0046;
								}
								continue;
							}
							return;
							continue;
							end_IL_002d:
							break;
						}
						continue;
						end_IL_003a:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
			}
		}

		internal static bool smethod_0()
		{
			return object_0 == null;
		}

		internal static object smethod_1()
		{
			return object_0;
		}
	}

	private static int int_0;

	private static TracerOption[] tracerOption_0;

	private static int int_1;

	private static double double_0;

	private static double double_1;

	private static float float_0;

	private static IntPtr[] getFileAssociationSectionAssemblySize;

	private static IntPtr[] SymbolTypeCFB;

	private static IntPtr[] getAlgorithmIdContractAbbreviatorAttribute;

	private static IntPtr[] AppDomaintpQuantum;

	private static IntPtr[] IsolatedStorageScopeDataCollector;

	private static IntPtr[] RawAclCngAlgorithmID;

	private static IntPtr[] IManifestInformationSetURI;

	public unsafe static int CurrentIndex
	{
		get
		{
			int num = 52;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							num = 78;
							while (true)
							{
								object[] array2 = new object[3];
								num = 102;
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OidGroupSeed.SetRootObjectLegalKeySizes);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 49;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 53;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_035c:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_033f:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_032f:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_031f:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_030f:
																										if (4 > b)
																										{
																											while (true)
																											{
																												IL_02ff:
																												if (2 >= b)
																												{
																													while (true)
																													{
																														IL_02ef:
																														if (2 <= b)
																														{
																															while (true)
																															{
																																IL_02ad:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																while (true)
																																{
																																	IL_028e:
																																	array[num6 - 2] = 0;
																																	num = 155;
																																	while (true)
																																	{
																																		if (num != 155)
																																		{
																																			if (num != 1136)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 112:
																																				goto IL_028e;
																																			case 16:
																																			case 62:
																																				goto IL_02ad;
																																			case 37:
																																				goto IL_02ef;
																																			case 71:
																																				goto IL_02ff;
																																			case 30:
																																				goto IL_030f;
																																			case 44:
																																			case 86:
																																				goto IL_031f;
																																			case 134:
																																				goto IL_032f;
																																			case 8:
																																				goto IL_033f;
																																			case 139:
																																				goto IL_034c;
																																			case 48:
																																				goto IL_035c;
																																			case 53:
																																				goto end_IL_035c;
																																			case 88:
																																			case 124:
																																				goto end_IL_036c;
																																			case 55:
																																			case 67:
																																				goto IL_0390;
																																			case 40:
																																			case 108:
																																				goto IL_03a3;
																																			case 6:
																																			case 100:
																																				goto IL_03ae;
																																			case 0:
																																				goto IL_03b9;
																																			case 2:
																																			case 21:
																																				goto IL_03c4;
																																			case 1:
																																				goto IL_03e8;
																																			case 84:
																																				goto IL_03f6;
																																			case 74:
																																				goto IL_0406;
																																			case 5:
																																			case 91:
																																				goto IL_0411;
																																			case 19:
																																			case 111:
																																				goto IL_042f;
																																			case 20:
																																			case 114:
																																				goto IL_0442;
																																			case 117:
																																				goto IL_0452;
																																			case 118:
																																				goto IL_0465;
																																			case 33:
																																			case 90:
																																				goto IL_0473;
																																			case 122:
																																				goto IL_048b;
																																			case 4:
																																				goto IL_0496;
																																			case 63:
																																				goto IL_04a9;
																																			case 127:
																																				goto IL_04bc;
																																			case 50:
																																			case 56:
																																				goto IL_04ca;
																																			case 130:
																																				goto IL_04f3;
																																			case 25:
																																				goto IL_0501;
																																			case 132:
																																				goto IL_0514;
																																			case 103:
																																			case 110:
																																				goto IL_052b;
																																			case 137:
																																				goto IL_0550;
																																			case 29:
																																				goto IL_055e;
																																			case 7:
																																				goto IL_056c;
																																			case 54:
																																			case 138:
																																				goto IL_057f;
																																			case 94:
																																				goto IL_058d;
																																			case 57:
																																				goto IL_059b;
																																			case 14:
																																				goto IL_05a9;
																																			case 79:
																																			case 96:
																																				goto IL_05b7;
																																			case 13:
																																				goto IL_05f7;
																																			case 58:
																																				goto IL_060b;
																																			case 76:
																																			case 107:
																																				goto IL_0627;
																																			case 92:
																																				goto IL_0667;
																																			case 99:
																																				goto IL_067b;
																																			case 120:
																																				goto IL_068e;
																																			case 81:
																																				goto IL_069c;
																																			case 17:
																																			case 135:
																																				goto IL_06b5;
																																			case 121:
																																				goto IL_06f5;
																																			case 143:
																																				goto IL_0709;
																																			case 144:
																																				goto IL_071c;
																																			case 145:
																																				goto IL_072f;
																																			case 113:
																																				goto IL_073d;
																																			case 18:
																																			case 28:
																																				goto IL_074b;
																																			case 27:
																																			case 146:
																																				goto IL_078d;
																																			case 73:
																																				goto IL_07ef;
																																			case 148:
																																				goto IL_0802;
																																			case 87:
																																				goto IL_0816;
																																			case 38:
																																			case 85:
																																				goto IL_083c;
																																			case 115:
																																				goto IL_0847;
																																			case 47:
																																			case 98:
																																				goto IL_085d;
																																			case 141:
																																				goto IL_086b;
																																			case 140:
																																				goto IL_088e;
																																			case 39:
																																				goto IL_0898;
																																			case 34:
																																				goto IL_08a6;
																																			case 101:
																																			case 142:
																																				goto IL_08b6;
																																			case 3:
																																			case 9:
																																			case 10:
																																			case 12:
																																			case 15:
																																			case 22:
																																			case 23:
																																			case 24:
																																			case 26:
																																			case 36:
																																			case 41:
																																			case 42:
																																			case 68:
																																			case 69:
																																			case 70:
																																			case 82:
																																			case 83:
																																			case 89:
																																			case 97:
																																			case 104:
																																			case 109:
																																			case 119:
																																			case 126:
																																			case 128:
																																			case 129:
																																				goto end_IL_027b;
																																			case 46:
																																				goto IL_08df;
																																			case 64:
																																				goto IL_08ed;
																																			case 60:
																																				goto IL_08fb;
																																			case 11:
																																			case 31:
																																			case 32:
																																			case 35:
																																			case 43:
																																			case 45:
																																			case 49:
																																			case 66:
																																			case 77:
																																			case 80:
																																			case 95:
																																			case 105:
																																			case 106:
																																			case 116:
																																			case 123:
																																			case 125:
																																			case 133:
																																			case 147:
																																				goto end_IL_037c;
																																			case 93:
																																				goto end_IL_0909;
																																			case 59:
																																				goto end_IL_091c;
																																			case 131:
																																				goto end_IL_092f;
																																			case 102:
																																			case 136:
																																				goto end_IL_093a;
																																			case 78:
																																				goto end_IL_094a;
																																			case 61:
																																				goto end_IL_095a;
																																			case 65:
																																				goto end_IL_0973;
																																			case 51:
																																				goto end_IL_098c;
																																			case 52:
																																				goto end_IL_099c;
																																			case 72:
																																			case 75:
																																				goto IL_09b7;
																																			}
																																			continue;
																																		}
																																		num6--;
																																		goto end_IL_037c;
																																		continue;
																																		end_IL_027b:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_083c;
																														IL_0847:
																														if (1 <= b)
																														{
																														}
																														break;
																														IL_083c:
																														if (1 < b)
																														{
																															break;
																														}
																														goto IL_0847;
																													}
																													break;
																												}
																												goto IL_0390;
																												IL_0501:
																												num6--;
																												goto end_IL_037c;
																												IL_0390:
																												if (3 < b)
																												{
																													break;
																												}
																												goto IL_04bc;
																												IL_04bc:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_04ca;
																												IL_04ca:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_04f3;
																												IL_04f3:
																												ptr2 += 8;
																												goto IL_0501;
																											}
																											break;
																										}
																										num = 98;
																										goto IL_085d;
																										IL_0898:
																										num6++;
																										goto IL_08a6;
																										IL_08a6:
																										ptr2 += 8;
																										goto end_IL_037c;
																										IL_085d:
																										array[num6] = 0;
																										goto IL_086b;
																										IL_086b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_088e;
																										IL_088e:
																										array2[num6] = null;
																										goto IL_0898;
																									}
																									break;
																								}
																								goto IL_057f;
																								IL_06b5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_06f5;
																								IL_057f:
																								if (6 >= b)
																								{
																									goto IL_058d;
																								}
																								goto IL_068e;
																								IL_058d:
																								if (6 > b)
																								{
																									goto IL_059b;
																								}
																								num = 76;
																								goto IL_0627;
																								IL_059b:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_05a9;
																								IL_05a9:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_05b7;
																								IL_05b7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_05f7;
																								IL_05f7:
																								array[num6 - 2] = 0;
																								goto IL_060b;
																								IL_060b:
																								num6--;
																								goto end_IL_037c;
																								IL_06f5:
																								array[num6 - 2] = 0;
																								goto IL_0709;
																								IL_0627:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0667;
																								IL_0667:
																								array[num6 - 2] = 0;
																								goto IL_067b;
																								IL_067b:
																								num6--;
																								goto end_IL_037c;
																								IL_068e:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_069c;
																								IL_069c:
																								if (7 > b)
																								{
																									num = 104;
																									break;
																								}
																								goto IL_06b5;
																								IL_0709:
																								num6--;
																								goto end_IL_037c;
																							}
																							break;
																						}
																						goto IL_08b6;
																						IL_08b6:
																						num6--;
																						goto end_IL_037c;
																					}
																					break;
																				}
																				goto IL_03a3;
																				IL_04a9:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_071c;
																				IL_03a3:
																				if (12 < b)
																				{
																					goto IL_03ae;
																				}
																				goto IL_0406;
																				IL_03ae:
																				if (14 >= b)
																				{
																					goto IL_03b9;
																				}
																				goto IL_042f;
																				IL_03b9:
																				if (14 <= b)
																				{
																					goto IL_03c4;
																				}
																				goto IL_0442;
																				IL_03c4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getAlgorithmIdContractAbbreviatorAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_03e8;
																				IL_03e8:
																				array[num6] = 0;
																				goto IL_03f6;
																				IL_03f6:
																				num6++;
																				goto IL_0452;
																				IL_0452:
																				ptr2 += 8;
																				goto end_IL_037c;
																				IL_0442:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0465;
																				IL_0465:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0473;
																				IL_0473:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_037c;
																				IL_042f:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0514;
																				IL_0514:
																				if (15 > b)
																				{
																					break;
																				}
																				num = 110;
																				goto IL_052b;
																				IL_071c:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_037c;
																				IL_052b:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				num = 43;
																				goto end_IL_037c;
																				IL_0406:
																				if (12 <= b)
																				{
																					goto IL_0411;
																				}
																				goto IL_048b;
																				IL_0411:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0550;
																				IL_0550:
																				array[num6] = 1;
																				goto IL_055e;
																				IL_055e:
																				num6++;
																				goto IL_056c;
																				IL_056c:
																				ptr2 += 16;
																				goto end_IL_037c;
																				IL_048b:
																				if (10 >= b)
																				{
																					goto IL_0496;
																				}
																				goto IL_04a9;
																				IL_0496:
																				if (10 > b)
																				{
																					goto IL_072f;
																				}
																				goto IL_078d;
																				IL_078d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_07ef;
																				IL_07ef:
																				num6 -= 2;
																				goto end_IL_037c;
																				IL_072f:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_073d;
																				IL_073d:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_074b;
																				IL_074b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0802;
																				IL_0802:
																				array[num6 - 2] = 0;
																				goto IL_0816;
																				IL_0816:
																				num6--;
																				goto end_IL_037c;
																			}
																			break;
																			IL_034c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_08df;
																	IL_08fb:
																	ptr2 += 8;
																	goto end_IL_037c;
																	IL_08ed:
																	num6++;
																	goto IL_08fb;
																	IL_08df:
																	array[num6] = 0;
																	goto IL_08ed;
																	continue;
																	end_IL_035c:
																	break;
																}
																continue;
																end_IL_036c:
																break;
															}
															continue;
															end_IL_037c:
															break;
														}
														continue;
													}
													goto IL_09b7;
													IL_09b7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0909:
													break;
												}
												continue;
												end_IL_091c:
												break;
											}
											continue;
											end_IL_092f:
											break;
										}
										continue;
										end_IL_093a:
										break;
									}
									continue;
									end_IL_094a:
									break;
								}
								continue;
								end_IL_095a:
								break;
							}
							continue;
							end_IL_0973:
							break;
						}
						continue;
						end_IL_098c:
						break;
					}
					continue;
					end_IL_099c:
					break;
				}
			}
		}
		set
		{
			int num = 194;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[4];
							while (true)
							{
								object[] array2 = new object[4];
								num = 154;
								while (true)
								{
									num = 164;
									while (true)
									{
										int[] array3 = new int[7];
										while (true)
										{
											long[] array4 = new long[4];
											while (true)
											{
												array3[0] = value;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TopDirectoryOnlyPopipop.RuntimeEnvironmentSoapAttribute);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																IL_0481:
																byte b = *ptr2;
																while (true)
																{
																	IL_0471:
																	ptr2++;
																	while (true)
																	{
																		IL_0461:
																		if (b >= 1)
																		{
																			while (b <= 21)
																			{
																				while (true)
																				{
																					IL_0444:
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_0434:
																							if (16 < b)
																							{
																								while (true)
																								{
																									IL_0424:
																									if (19 >= b)
																									{
																										while (true)
																										{
																											IL_0417:
																											if (19 <= b)
																											{
																												while (true)
																												{
																													IL_03fe:
																													array[num6 - 3] = 0;
																													while (true)
																													{
																														IL_0393:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]) = ((delegate*<int, int, int, int>)AppDomaintpQuantum[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																														while (true)
																														{
																															IL_0383:
																															num6 -= 2;
																															while (true)
																															{
																																IL_036a:
																																ptr2 += 8;
																																num = 210;
																																while (num != 210 && num == 1191)
																																{
																																	switch (num)
																																	{
																																	case 116:
																																		goto IL_036a;
																																	case 27:
																																		goto IL_0383;
																																	case 187:
																																		goto IL_0393;
																																	case 45:
																																	case 125:
																																		goto IL_03fe;
																																	case 43:
																																		goto IL_0417;
																																	case 168:
																																	case 190:
																																		goto IL_0424;
																																	case 95:
																																	case 189:
																																		goto IL_0434;
																																	case 110:
																																		goto IL_0444;
																																	case 1:
																																		goto IL_0451;
																																	case 48:
																																		goto IL_0461;
																																	case 124:
																																		goto IL_0471;
																																	case 61:
																																	case 100:
																																		goto IL_0481;
																																	case 23:
																																	case 29:
																																		goto IL_048c;
																																	case 63:
																																		goto IL_0497;
																																	case 66:
																																		goto IL_04a7;
																																	case 96:
																																		goto IL_04ba;
																																	case 74:
																																	case 111:
																																		goto IL_04ca;
																																	case 18:
																																		goto IL_04f5;
																																	case 156:
																																		goto IL_050e;
																																	case 13:
																																		goto IL_051c;
																																	case 121:
																																	case 132:
																																		goto IL_0527;
																																	case 3:
																																		goto IL_0535;
																																	case 151:
																																		goto IL_0540;
																																	case 80:
																																		goto IL_054e;
																																	case 50:
																																	case 130:
																																		goto IL_056f;
																																	case 70:
																																		goto IL_05b4;
																																	case 41:
																																	case 114:
																																		goto IL_05c2;
																																	case 31:
																																	case 36:
																																		goto IL_05cd;
																																	case 20:
																																		goto IL_05db;
																																	case 118:
																																		goto IL_05ee;
																																	case 44:
																																	case 102:
																																		goto IL_05fc;
																																	case 144:
																																		goto IL_063c;
																																	case 57:
																																		goto IL_0655;
																																	case 6:
																																	case 79:
																																		goto IL_0660;
																																	case 17:
																																		goto IL_066b;
																																	case 22:
																																	case 157:
																																		goto IL_067b;
																																	case 32:
																																	case 158:
																																		goto IL_068e;
																																	case 127:
																																		goto IL_069c;
																																	case 139:
																																	case 143:
																																		goto IL_06aa;
																																	case 34:
																																		goto IL_06c4;
																																	case 163:
																																		goto IL_06d7;
																																	case 65:
																																	case 165:
																																		goto IL_06ea;
																																	case 87:
																																		goto IL_072a;
																																	case 147:
																																		goto IL_073e;
																																	case 169:
																																		goto IL_075a;
																																	case 81:
																																	case 174:
																																		goto IL_076d;
																																	case 173:
																																		goto IL_07cf;
																																	case 35:
																																	case 176:
																																		goto IL_07e2;
																																	case 105:
																																		goto IL_0822;
																																	case 103:
																																		goto IL_0836;
																																	case 180:
																																		goto IL_0849;
																																	case 60:
																																	case 109:
																																		goto IL_0857;
																																	case 135:
																																		goto IL_0897;
																																	case 58:
																																		goto IL_08ab;
																																	case 181:
																																		goto IL_08be;
																																	case 94:
																																		goto IL_08cc;
																																	case 97:
																																	case 150:
																																		goto IL_08da;
																																	case 159:
																																	case 186:
																																		goto IL_08f6;
																																	case 166:
																																		goto IL_0901;
																																	case 78:
																																	case 134:
																																		goto IL_090f;
																																	case 106:
																																		goto IL_0938;
																																	case 62:
																																		goto IL_0946;
																																	case 55:
																																		goto IL_0959;
																																	case 171:
																																		goto IL_0967;
																																	case 5:
																																	case 146:
																																		goto IL_0975;
																																	case 91:
																																		goto IL_0983;
																																	case 167:
																																		goto IL_09a6;
																																	case 14:
																																		goto IL_09b0;
																																	case 184:
																																		goto IL_09be;
																																	case 188:
																																		goto IL_09d1;
																																	case 196:
																																		goto IL_09e7;
																																	case 71:
																																	case 88:
																																		goto IL_09f5;
																																	case 40:
																																		goto IL_0a35;
																																	case 113:
																																		goto IL_0a49;
																																	case 199:
																																		goto IL_0a5c;
																																	case 202:
																																		goto IL_0a6f;
																																	case 16:
																																	case 28:
																																		goto IL_0a7a;
																																	case 25:
																																		goto IL_0aa4;
																																	case 46:
																																		goto IL_0abd;
																																	case 129:
																																		goto IL_0acb;
																																	case 52:
																																	case 185:
																																		goto IL_0ad6;
																																	case 21:
																																		goto IL_0aee;
																																	case 119:
																																		goto IL_0afc;
																																	case 123:
																																	case 161:
																																		goto IL_0b0a;
																																	case 30:
																																		goto IL_0b23;
																																	case 148:
																																		goto IL_0b31;
																																	case 77:
																																		goto IL_0b48;
																																	case 191:
																																		goto IL_0b5b;
																																	case 33:
																																		goto IL_0b66;
																																	case 54:
																																	case 149:
																																		goto IL_0b74;
																																	case 84:
																																		goto IL_0b97;
																																	case 183:
																																		goto IL_0ba5;
																																	case 182:
																																		goto IL_0bb3;
																																	case 73:
																																		goto IL_0bc6;
																																	case 9:
																																		goto IL_0bd1;
																																	case 4:
																																	case 175:
																																		goto IL_0bdc;
																																	case 99:
																																		goto IL_0bfa;
																																	case 107:
																																		goto IL_0c08;
																																	case 26:
																																		goto IL_0c16;
																																	case 0:
																																	case 8:
																																	case 15:
																																	case 19:
																																	case 37:
																																	case 39:
																																	case 42:
																																	case 49:
																																	case 51:
																																	case 53:
																																	case 59:
																																	case 64:
																																	case 68:
																																	case 72:
																																	case 76:
																																	case 82:
																																	case 83:
																																	case 85:
																																	case 86:
																																	case 89:
																																	case 90:
																																	case 92:
																																	case 98:
																																	case 115:
																																	case 120:
																																	case 128:
																																	case 133:
																																	case 137:
																																	case 140:
																																	case 153:
																																	case 155:
																																	case 172:
																																	case 179:
																																	case 195:
																																	case 197:
																																	case 198:
																																	case 201:
																																		goto end_IL_0451;
																																	case 67:
																																		goto IL_0c3f;
																																	case 69:
																																		goto IL_0c4d;
																																	case 178:
																																		goto IL_0c5b;
																																	case 2:
																																	case 7:
																																	case 10:
																																	case 12:
																																	case 24:
																																	case 38:
																																	case 47:
																																	case 56:
																																	case 75:
																																	case 93:
																																	case 104:
																																	case 108:
																																	case 112:
																																	case 117:
																																	case 122:
																																	case 126:
																																	case 141:
																																	case 152:
																																	case 162:
																																	case 170:
																																	case 177:
																																	case 192:
																																	case 200:
																																		goto end_IL_0357;
																																	case 101:
																																		goto end_IL_0c69;
																																	case 145:
																																		goto end_IL_0c7c;
																																	case 160:
																																		goto end_IL_0c86;
																																	case 142:
																																		goto end_IL_0c91;
																																	case 164:
																																		goto end_IL_0ca6;
																																	case 154:
																																		goto end_IL_0cb6;
																																	case 203:
																																		goto end_IL_0cc6;
																																	case 131:
																																		goto end_IL_0cd1;
																																	case 138:
																																		goto end_IL_0cea;
																																	case 193:
																																		goto end_IL_0cfa;
																																	case 194:
																																		goto end_IL_0d0a;
																																	case 11:
																																	case 136:
																																		return;
																																	}
																																	continue;
																																	end_IL_0357:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_048c;
																											IL_08ab:
																											num6--;
																											break;
																											IL_048c:
																											if (17 >= b)
																											{
																												goto IL_0497;
																											}
																											goto IL_04a7;
																											IL_0497:
																											if (17 > b)
																											{
																												goto end_IL_0451;
																											}
																											goto IL_04ca;
																											IL_04ca:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_04f5;
																											IL_04f5:
																											array[num6 - 1] = 0;
																											break;
																											IL_04a7:
																											if (18 < b)
																											{
																												goto end_IL_0451;
																											}
																											goto IL_0849;
																											IL_0849:
																											if (18 > b)
																											{
																												goto end_IL_0451;
																											}
																											goto IL_0857;
																											IL_0857:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0897;
																											IL_0897:
																											array[num6 - 2] = 0;
																											goto IL_08ab;
																										}
																										break;
																									}
																									goto IL_068e;
																									IL_08da:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									break;
																									IL_068e:
																									if (20 >= b)
																									{
																										goto IL_069c;
																									}
																									goto IL_08be;
																									IL_069c:
																									if (20 > b)
																									{
																										goto end_IL_0451;
																									}
																									goto IL_06aa;
																									IL_06aa:
																									int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_06c4;
																									IL_06c4:
																									num6--;
																									break;
																									IL_08be:
																									if (21 < b)
																									{
																										goto end_IL_0451;
																									}
																									goto IL_08cc;
																									IL_08cc:
																									if (21 > b)
																									{
																										goto end_IL_0451;
																									}
																									goto IL_08da;
																								}
																								break;
																							}
																							goto IL_0a6f;
																							IL_0c16:
																							ptr2 += 8;
																							break;
																							IL_0a6f:
																							if (16 <= b)
																							{
																								goto IL_0a7a;
																							}
																							goto IL_0abd;
																							IL_0a7a:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((TracerOption[])array2[num6 - 1]).LongLength;
																							goto IL_0aa4;
																							IL_0aa4:
																							array[num6 - 1] = 2;
																							break;
																							IL_0abd:
																							if (13 >= b)
																							{
																								goto IL_0acb;
																							}
																							goto IL_0b5b;
																							IL_0acb:
																							if (13 <= b)
																							{
																								goto IL_0ad6;
																							}
																							goto IL_0aee;
																							IL_0ad6:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_0aee:
																							if (12 < b)
																							{
																								goto end_IL_0451;
																							}
																							goto IL_0afc;
																							IL_0afc:
																							if (12 > b)
																							{
																								goto end_IL_0451;
																							}
																							goto IL_0b0a;
																							IL_0b0a:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0b23;
																							IL_0b23:
																							array[num6] = 1;
																							goto IL_0b31;
																							IL_0b31:
																							num6++;
																							num = 77;
																							goto IL_0b48;
																							IL_0b48:
																							ptr2 += 16;
																							break;
																							IL_0b5b:
																							if (14 >= b)
																							{
																								goto IL_0b66;
																							}
																							goto IL_0bc6;
																							IL_0b66:
																							if (14 > b)
																							{
																								goto end_IL_0451;
																							}
																							goto IL_0b74;
																							IL_0b74:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0b97;
																							IL_0b97:
																							array[num6] = 0;
																							goto IL_0ba5;
																							IL_0ba5:
																							num6++;
																							goto IL_0bb3;
																							IL_0bb3:
																							ptr2 += 8;
																							break;
																							IL_0bc6:
																							if (15 < b)
																							{
																								goto end_IL_0451;
																							}
																							goto IL_0bd1;
																							IL_0bd1:
																							if (15 > b)
																							{
																								goto end_IL_0451;
																							}
																							goto IL_0bdc;
																							IL_0bdc:
																							array2[num6] = ((delegate*<TracerOption[]>)AppDomaintpQuantum[*(int*)(ptr2 + num3)])();
																							goto IL_0bfa;
																							IL_0bfa:
																							array[num6] = 5;
																							goto IL_0c08;
																							IL_0c08:
																							num6++;
																							goto IL_0c16;
																						}
																						break;
																					}
																					goto IL_04ba;
																					IL_0a49:
																					num6--;
																					break;
																					IL_04ba:
																					if (11 <= b)
																					{
																						break;
																					}
																					goto IL_050e;
																					IL_050e:
																					if (5 >= b)
																					{
																						goto IL_051c;
																					}
																					goto IL_05b4;
																					IL_051c:
																					if (5 > b)
																					{
																						goto IL_0527;
																					}
																					goto IL_056f;
																					IL_0527:
																					if (2 >= b)
																					{
																						goto IL_0535;
																					}
																					goto IL_08f6;
																					IL_0535:
																					if (2 > b)
																					{
																						goto IL_0540;
																					}
																					num = 176;
																					goto IL_07e2;
																					IL_0540:
																					if (1 < b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_054e;
																					IL_054e:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_0451;
																					IL_067b:
																					num6--;
																					break;
																					IL_07e2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0822;
																					IL_0822:
																					array[num6 - 2] = 0;
																					goto IL_0836;
																					IL_0836:
																					num6--;
																					break;
																					IL_08f6:
																					if (3 >= b)
																					{
																						goto IL_0901;
																					}
																					goto IL_0959;
																					IL_0901:
																					if (3 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_090f;
																					IL_090f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0938;
																					IL_0938:
																					ptr2 += 8;
																					goto IL_0946;
																					IL_0946:
																					num6--;
																					break;
																					IL_0959:
																					if (4 < b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_0967;
																					IL_0967:
																					if (4 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_0975;
																					IL_0975:
																					array[num6] = 0;
																					goto IL_0983;
																					IL_0983:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_09a6;
																					IL_09a6:
																					array2[num6] = null;
																					goto IL_09b0;
																					IL_09b0:
																					num6++;
																					goto IL_09be;
																					IL_09be:
																					ptr2 += 8;
																					break;
																					IL_056f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_09d1;
																					IL_09d1:
																					array[num6 - 2] = 0;
																					goto IL_0a5c;
																					IL_0a5c:
																					num6--;
																					break;
																					IL_05b4:
																					if (8 < b)
																					{
																						goto IL_05c2;
																					}
																					goto IL_0655;
																					IL_05c2:
																					if (9 < b)
																					{
																						goto IL_05cd;
																					}
																					goto IL_05ee;
																					IL_05cd:
																					if (10 < b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_05db;
																					IL_05db:
																					if (10 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_076d;
																					IL_076d:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_07cf;
																					IL_07cf:
																					num6 -= 2;
																					break;
																					IL_05ee:
																					if (9 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_05fc;
																					IL_05fc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_063c;
																					IL_063c:
																					array[num6 - 2] = 0;
																					goto IL_075a;
																					IL_075a:
																					num6--;
																					break;
																					IL_0655:
																					if (8 > b)
																					{
																						goto IL_0660;
																					}
																					goto IL_067b;
																					IL_0660:
																					if (6 >= b)
																					{
																						goto IL_066b;
																					}
																					goto IL_06d7;
																					IL_066b:
																					if (6 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_06ea;
																					IL_06ea:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_072a;
																					IL_072a:
																					array[num6 - 2] = 0;
																					goto IL_073e;
																					IL_073e:
																					num6--;
																					num = 112;
																					break;
																					IL_06d7:
																					if (7 < b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_09e7;
																					IL_09e7:
																					if (7 > b)
																					{
																						goto end_IL_0451;
																					}
																					goto IL_09f5;
																					IL_09f5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0a35;
																					IL_0a35:
																					array[num6 - 2] = 0;
																					goto IL_0a49;
																				}
																				goto end_IL_0461;
																				continue;
																				end_IL_0451:
																				break;
																				IL_0451:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0c3f;
																		IL_0c5b:
																		ptr2 += 8;
																		break;
																		IL_0c4d:
																		num6++;
																		goto IL_0c5b;
																		IL_0c3f:
																		array[num6] = 0;
																		goto IL_0c4d;
																		continue;
																		end_IL_0461:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_0c69:
															break;
														}
														continue;
														end_IL_0c7c:
														break;
													}
													continue;
													end_IL_0c86:
													break;
												}
												continue;
												end_IL_0c91:
												break;
											}
											continue;
											end_IL_0ca6:
											break;
										}
										continue;
										end_IL_0cb6:
										break;
									}
									continue;
									end_IL_0cc6:
									break;
								}
								continue;
								end_IL_0cd1:
								break;
							}
							continue;
							end_IL_0cea:
							break;
						}
						continue;
						end_IL_0cfa:
						break;
					}
					continue;
					end_IL_0d0a:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 167;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 84;
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								num = 69;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetGuidArrayModuleHandle.mdataLongPathHelper);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 18;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0416:
																	if (b >= 1)
																	{
																		while (b <= 21)
																		{
																			while (true)
																			{
																				IL_03f9:
																				if (11 < b)
																				{
																					while (true)
																					{
																						IL_03e9:
																						if (16 >= b)
																						{
																							while (true)
																							{
																								IL_03d9:
																								if (16 > b)
																								{
																									while (true)
																									{
																										IL_03c9:
																										if (13 >= b)
																										{
																											while (true)
																											{
																												IL_03b9:
																												if (13 <= b)
																												{
																													while (true)
																													{
																														IL_0393:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getFileAssociationSectionAssemblySize[*(int*)(ptr2 + num3)])();
																														while (true)
																														{
																															IL_0383:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_036a:
																																num5++;
																																num = 210;
																																while (true)
																																{
																																	if (num != 210)
																																	{
																																		if (num != 1191)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 71:
																																			goto IL_036a;
																																		case 29:
																																			goto IL_0383;
																																		case 73:
																																		case 106:
																																			goto IL_0393;
																																		case 34:
																																			goto IL_03b9;
																																		case 192:
																																			goto IL_03c9;
																																		case 105:
																																			goto IL_03d9;
																																		case 180:
																																			goto IL_03e9;
																																		case 120:
																																			goto IL_03f9;
																																		case 193:
																																			goto end_IL_03f9;
																																		case 72:
																																			goto IL_0416;
																																		case 56:
																																			goto end_IL_0416;
																																		case 0:
																																		case 75:
																																			goto end_IL_0426;
																																		case 78:
																																			goto IL_0441;
																																		case 48:
																																		case 85:
																																			goto IL_044c;
																																		case 58:
																																			goto IL_045a;
																																		case 140:
																																		case 154:
																																			goto IL_0483;
																																		case 87:
																																			goto IL_0491;
																																		case 33:
																																			goto IL_049f;
																																		case 95:
																																			goto IL_04aa;
																																		case 31:
																																		case 115:
																																			goto IL_04b8;
																																		case 88:
																																			goto IL_04c6;
																																		case 123:
																																			goto IL_04e2;
																																		case 30:
																																		case 46:
																																			goto IL_04f0;
																																		case 137:
																																			goto IL_0530;
																																		case 15:
																																			goto IL_0544;
																																		case 86:
																																		case 126:
																																			goto end_IL_0357;
																																		case 59:
																																		case 64:
																																			goto IL_056e;
																																		case 39:
																																		case 104:
																																			goto IL_0579;
																																		case 55:
																																			goto IL_0587;
																																		case 81:
																																			goto IL_059a;
																																		case 24:
																																		case 103:
																																			goto IL_05a8;
																																		case 146:
																																			goto IL_05e8;
																																		case 20:
																																			goto IL_0601;
																																		case 7:
																																		case 110:
																																			goto IL_060f;
																																		case 153:
																																			goto IL_061d;
																																		case 83:
																																			goto IL_062b;
																																		case 22:
																																		case 32:
																																			goto IL_0639;
																																		case 53:
																																			goto IL_0679;
																																		case 57:
																																			goto IL_068d;
																																		case 76:
																																		case 118:
																																			goto IL_06a0;
																																		case 157:
																																			goto IL_06b3;
																																		case 21:
																																		case 35:
																																			goto IL_06c1;
																																		case 151:
																																			goto IL_06ea;
																																		case 70:
																																			goto IL_06f8;
																																		case 45:
																																		case 158:
																																			goto IL_070b;
																																		case 124:
																																			goto IL_074b;
																																		case 97:
																																			goto IL_075f;
																																		case 160:
																																			goto IL_0772;
																																		case 63:
																																		case 168:
																																			goto IL_0785;
																																		case 169:
																																			goto IL_07ec;
																																		case 129:
																																			goto IL_07fa;
																																		case 179:
																																			goto IL_080d;
																																		case 11:
																																			goto IL_081b;
																																		case 190:
																																			goto IL_082e;
																																		case 182:
																																		case 187:
																																			goto IL_083c;
																																		case 60:
																																			goto IL_087c;
																																		case 127:
																																			goto IL_0890;
																																		case 195:
																																			goto IL_08a3;
																																		case 165:
																																		case 199:
																																			goto IL_08b6;
																																		case 186:
																																			goto IL_08c4;
																																		case 40:
																																			goto IL_08e7;
																																		case 133:
																																			goto IL_08fa;
																																		case 19:
																																			goto IL_0908;
																																		case 200:
																																			goto IL_091b;
																																		case 109:
																																			goto IL_0929;
																																		case 170:
																																		case 173:
																																			goto IL_094f;
																																		case 9:
																																			goto IL_095a;
																																		case 116:
																																			goto IL_0968;
																																		case 47:
																																		case 121:
																																			goto IL_0976;
																																		case 89:
																																			goto IL_09a0;
																																		case 130:
																																			goto IL_09b9;
																																		case 164:
																																		case 174:
																																			goto IL_09c7;
																																		case 150:
																																			goto IL_09e5;
																																		case 65:
																																			goto IL_09f3;
																																		case 82:
																																			goto IL_0a01;
																																		case 2:
																																		case 25:
																																			goto IL_0a26;
																																		case 49:
																																			goto IL_0a5a;
																																		case 74:
																																			goto IL_0a73;
																																		case 141:
																																			goto IL_0a81;
																																		case 171:
																																			goto IL_0a8c;
																																		case 51:
																																		case 96:
																																			goto IL_0aa3;
																																		case 90:
																																			goto IL_0acc;
																																		case 172:
																																			goto IL_0ada;
																																		case 135:
																																			goto IL_0aed;
																																		case 139:
																																			goto IL_0afb;
																																		case 93:
																																		case 131:
																																			goto IL_0b09;
																																		case 98:
																																			goto IL_0b2e;
																																		case 181:
																																		case 197:
																																			goto IL_0b39;
																																		case 37:
																																			goto IL_0b51;
																																		case 14:
																																			goto IL_0b5f;
																																		case 175:
																																			goto IL_0b76;
																																		case 26:
																																			goto IL_0b89;
																																		case 41:
																																		case 61:
																																			goto IL_0b94;
																																		case 201:
																																			goto IL_0ba2;
																																		case 52:
																																		case 189:
																																			goto IL_0bb0;
																																		case 108:
																																			goto IL_0bca;
																																		case 143:
																																			goto IL_0bdd;
																																		case 111:
																																		case 117:
																																			goto IL_0be8;
																																		case 1:
																																			goto IL_0c28;
																																		case 203:
																																			goto IL_0c3c;
																																		case 4:
																																		case 6:
																																		case 10:
																																		case 23:
																																		case 28:
																																		case 36:
																																		case 38:
																																		case 42:
																																		case 44:
																																		case 62:
																																		case 66:
																																		case 77:
																																		case 80:
																																		case 91:
																																		case 101:
																																		case 102:
																																		case 125:
																																		case 136:
																																		case 138:
																																		case 144:
																																		case 145:
																																		case 148:
																																		case 152:
																																		case 155:
																																		case 156:
																																		case 159:
																																		case 161:
																																		case 163:
																																		case 176:
																																		case 183:
																																		case 184:
																																		case 185:
																																		case 191:
																																		case 196:
																																		case 202:
																																			goto end_IL_0406;
																																		case 177:
																																			goto IL_0c65;
																																		case 94:
																																			goto IL_0c73;
																																		case 198:
																																			goto IL_0c81;
																																		case 8:
																																		case 12:
																																		case 16:
																																		case 18:
																																		case 27:
																																		case 43:
																																		case 50:
																																		case 54:
																																		case 67:
																																		case 92:
																																		case 99:
																																		case 100:
																																		case 107:
																																		case 112:
																																		case 113:
																																		case 114:
																																		case 119:
																																		case 128:
																																		case 142:
																																		case 147:
																																		case 162:
																																		case 188:
																																		case 194:
																																			goto end_IL_0436;
																																		case 17:
																																			goto end_IL_0c8f;
																																		case 5:
																																			goto end_IL_0ca2;
																																		case 149:
																																			goto end_IL_0cad;
																																		case 134:
																																			goto end_IL_0cb7;
																																		case 69:
																																			goto end_IL_0cc2;
																																		case 122:
																																			goto end_IL_0cd2;
																																		case 79:
																																		case 84:
																																			goto end_IL_0ce2;
																																		case 13:
																																			goto end_IL_0cfb;
																																		case 132:
																																		case 178:
																																			goto end_IL_0d0b;
																																		case 166:
																																			goto end_IL_0d24;
																																		case 167:
																																			goto end_IL_0d34;
																																		case 3:
																																		case 68:
																																			return;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_0436;
																																	continue;
																																	end_IL_0357:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_080d;
																												IL_081b:
																												if (12 > b)
																												{
																													goto end_IL_0406;
																												}
																												goto end_IL_0436;
																												IL_080d:
																												if (12 < b)
																												{
																													goto end_IL_0406;
																												}
																												goto IL_081b;
																											}
																											break;
																										}
																										goto IL_094f;
																										IL_0a01:
																										ptr2 += 8;
																										num = 114;
																										goto end_IL_0436;
																										IL_094f:
																										if (14 < b)
																										{
																											goto IL_095a;
																										}
																										goto IL_09b9;
																										IL_095a:
																										if (15 < b)
																										{
																											goto end_IL_0406;
																										}
																										goto IL_0968;
																										IL_0968:
																										if (15 > b)
																										{
																											goto end_IL_0406;
																										}
																										goto IL_0976;
																										IL_0976:
																										*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((TracerOption[])array2[num5 - 1]).LongLength;
																										goto IL_09a0;
																										IL_09a0:
																										array[num5 - 1] = 2;
																										goto end_IL_0436;
																										IL_09b9:
																										if (14 > b)
																										{
																											goto end_IL_0406;
																										}
																										goto IL_09c7;
																										IL_09c7:
																										array2[num5] = ((delegate*<TracerOption[]>)getFileAssociationSectionAssemblySize[*(int*)(ptr2 + num3)])();
																										goto IL_09e5;
																										IL_09e5:
																										array[num5] = 5;
																										goto IL_09f3;
																										IL_09f3:
																										num5++;
																										goto IL_0a01;
																									}
																									break;
																								}
																								num = 25;
																								goto IL_0a26;
																								IL_0a26:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								num = 49;
																								goto IL_0a5a;
																								IL_0a5a:
																								array[num5 - 1] = 0;
																								goto end_IL_0436;
																							}
																							break;
																						}
																						goto IL_0a73;
																						IL_0be8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0c28;
																						IL_0a73:
																						if (19 < b)
																						{
																							goto IL_0a81;
																						}
																						num = 98;
																						goto IL_0b2e;
																						IL_0a81:
																						if (20 >= b)
																						{
																							goto IL_0a8c;
																						}
																						goto IL_0aed;
																						IL_0a8c:
																						if (20 > b)
																						{
																							goto end_IL_0406;
																						}
																						num = 51;
																						goto IL_0aa3;
																						IL_0c3c:
																						num5--;
																						goto end_IL_0436;
																						IL_0aa3:
																						((delegate*<Class131, void>)getFileAssociationSectionAssemblySize[*(int*)(ptr2 + num3)])((Class131)array2[num5 - 1]);
																						goto IL_0acc;
																						IL_0acc:
																						num5--;
																						goto IL_0ada;
																						IL_0ada:
																						ptr2 += 8;
																						goto end_IL_0436;
																						IL_0aed:
																						if (21 < b)
																						{
																							goto end_IL_0406;
																						}
																						goto IL_0afb;
																						IL_0afb:
																						if (21 > b)
																						{
																							goto end_IL_0406;
																						}
																						goto IL_0b09;
																						IL_0b09:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0436;
																						IL_0c28:
																						array[num5 - 2] = 0;
																						goto IL_0c3c;
																						IL_0b2e:
																						if (19 <= b)
																						{
																							goto IL_0b39;
																						}
																						goto IL_0b89;
																						IL_0b39:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0b51;
																						IL_0b51:
																						array[num5] = 5;
																						goto IL_0b5f;
																						IL_0b5f:
																						num5++;
																						num = 175;
																						goto IL_0b76;
																						IL_0b76:
																						ptr2 += 8;
																						goto end_IL_0436;
																						IL_0b89:
																						if (17 < b)
																						{
																							goto IL_0b94;
																						}
																						goto IL_0bdd;
																						IL_0b94:
																						if (18 < b)
																						{
																							goto end_IL_0406;
																						}
																						goto IL_0ba2;
																						IL_0ba2:
																						if (18 > b)
																						{
																							goto end_IL_0406;
																						}
																						goto IL_0bb0;
																						IL_0bb0:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0bca;
																						IL_0bca:
																						num5--;
																						goto end_IL_0436;
																						IL_0bdd:
																						if (17 > b)
																						{
																							goto end_IL_0406;
																						}
																						goto IL_0be8;
																					}
																					goto IL_0560;
																				}
																				goto IL_0441;
																				IL_087c:
																				array[num5 - 2] = 0;
																				goto IL_0890;
																				IL_0441:
																				if (11 <= b)
																				{
																					goto IL_044c;
																				}
																				goto IL_0483;
																				IL_044c:
																				array[num5] = 0;
																				goto IL_045a;
																				IL_045a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getFileAssociationSectionAssemblySize[*(int*)(ptr2 + num3)])();
																				goto IL_091b;
																				IL_091b:
																				num5++;
																				goto IL_0929;
																				IL_0929:
																				ptr2 += 8;
																				goto end_IL_0436;
																				IL_0483:
																				if (5 >= b)
																				{
																					goto IL_0491;
																				}
																				num = 126;
																				goto IL_0560;
																				IL_0491:
																				if (5 > b)
																				{
																					goto IL_049f;
																				}
																				goto IL_070b;
																				IL_049f:
																				if (2 < b)
																				{
																					goto IL_04aa;
																				}
																				num = 123;
																				goto IL_04e2;
																				IL_04aa:
																				if (3 < b)
																				{
																					goto IL_04b8;
																				}
																				goto IL_06b3;
																				IL_04b8:
																				if (4 < b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_04c6;
																				IL_04c6:
																				if (4 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_08b6;
																				IL_08b6:
																				array[num5] = 0;
																				goto IL_08c4;
																				IL_08c4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_08e7;
																				IL_08e7:
																				array2[num5] = null;
																				num = 133;
																				goto IL_08fa;
																				IL_08fa:
																				num5++;
																				goto IL_0908;
																				IL_0908:
																				ptr2 += 8;
																				goto end_IL_0436;
																				IL_06b3:
																				if (3 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_06c1;
																				IL_06c1:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06ea;
																				IL_06ea:
																				ptr2 += 8;
																				goto IL_06f8;
																				IL_06f8:
																				num5--;
																				goto end_IL_0436;
																				IL_06a0:
																				num5--;
																				goto end_IL_0436;
																				IL_04e2:
																				if (2 <= b)
																				{
																					goto IL_04f0;
																				}
																				goto IL_07ec;
																				IL_04f0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0530;
																				IL_0530:
																				array[num5 - 2] = 0;
																				goto IL_0544;
																				IL_0544:
																				num5--;
																				goto end_IL_0436;
																				IL_07ec:
																				if (1 < b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_07fa;
																				IL_07fa:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0406;
																				IL_070b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_074b;
																				IL_074b:
																				array[num5 - 2] = 0;
																				goto IL_075f;
																				IL_075f:
																				num5--;
																				goto end_IL_0436;
																				IL_0890:
																				num5--;
																				goto end_IL_0436;
																				IL_0560:
																				if (8 < b)
																				{
																					goto IL_056e;
																				}
																				goto IL_0601;
																				IL_056e:
																				if (9 < b)
																				{
																					goto IL_0579;
																				}
																				goto IL_059a;
																				IL_0579:
																				if (10 < b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_0587;
																				IL_0587:
																				if (10 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_0785;
																				IL_0785:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08a3;
																				IL_08a3:
																				num5 -= 2;
																				goto end_IL_0436;
																				IL_059a:
																				if (9 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_05a8;
																				IL_05a8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05e8;
																				IL_05e8:
																				array[num5 - 2] = 0;
																				goto IL_0772;
																				IL_0772:
																				num5--;
																				goto end_IL_0436;
																				IL_0601:
																				if (8 > b)
																				{
																					goto IL_060f;
																				}
																				goto IL_06a0;
																				IL_060f:
																				if (6 < b)
																				{
																					goto IL_061d;
																				}
																				goto IL_082e;
																				IL_061d:
																				if (7 < b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_062b;
																				IL_062b:
																				if (7 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_0639;
																				IL_0639:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0679;
																				IL_0679:
																				array[num5 - 2] = 0;
																				goto IL_068d;
																				IL_068d:
																				num5--;
																				goto end_IL_0436;
																				IL_082e:
																				if (6 > b)
																				{
																					goto end_IL_0406;
																				}
																				goto IL_083c;
																				IL_083c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_087c;
																				continue;
																				end_IL_03f9:
																				break;
																			}
																			continue;
																			end_IL_0406:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0c65;
																	IL_0c81:
																	ptr2 += 8;
																	goto end_IL_0436;
																	IL_0c73:
																	num5++;
																	goto IL_0c81;
																	IL_0c65:
																	array[num5] = 0;
																	goto IL_0c73;
																	continue;
																	end_IL_0416:
																	break;
																}
																continue;
																end_IL_0426:
																break;
															}
															continue;
															end_IL_0436:
															break;
														}
														continue;
														end_IL_0c8f:
														break;
													}
													continue;
													end_IL_0ca2:
													break;
												}
												continue;
												end_IL_0cad:
												break;
											}
											continue;
											end_IL_0cb7:
											break;
										}
										continue;
										end_IL_0cc2:
										break;
									}
									continue;
									end_IL_0cd2:
									break;
								}
								continue;
								end_IL_0ce2:
								break;
							}
							continue;
							end_IL_0cfb:
							break;
						}
						continue;
						end_IL_0d0b:
						break;
					}
					continue;
					end_IL_0d24:
					break;
				}
				continue;
				end_IL_0d34:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001e, IL_0567, IL_057a, IL_05c5, IL_05d5, IL_05e5, IL_05f2, IL_0602, IL_060f, IL_061f, IL_062f, IL_063f, IL_064f, IL_065f, IL_066a, IL_0677, IL_069c, IL_06aa, IL_06ba, IL_06c8, IL_06db, IL_06f4, IL_0702, IL_0710, IL_0723, IL_073c, IL_074f, IL_075d, IL_0768, IL_077b, IL_0789, IL_0792, IL_07a0, IL_07a9, IL_07d0, IL_07e7, IL_07fa, IL_0845, IL_0853, IL_0861, IL_08a2, IL_08b6, IL_08c9, IL_08dd, IL_08f0, IL_0903, IL_0955, IL_0968, IL_0976, IL_0984, IL_09a8, IL_09b6, IL_09c4, IL_09d7, IL_09ea, IL_0a07, IL_0a1a, IL_0a28, IL_0a36, IL_0a4a, IL_0a89, IL_0a9c, IL_0aaa, IL_0ab8, IL_0ac6, IL_0ad1, IL_0adf, IL_0aed, IL_0b25, IL_0b39, IL_0b4c, IL_0b60, IL_0bac, IL_0bba, IL_0bcd, IL_0bd8, IL_0be6, IL_0c18, IL_0c26, IL_0c39, IL_0c47, IL_0c55, IL_0c5e, IL_0c72, IL_0cb1, IL_0cc4, IL_0ccd, IL_0d0d, IL_0d21, IL_0d34, IL_0d42, IL_0d4d, IL_0d78, IL_0d91, IL_0d9c, IL_0daa, IL_0de8, IL_0dfc, IL_0e0f, IL_0e1d, IL_0e2b, IL_0e55, IL_0e63, IL_0e76, IL_0e81, IL_0e8f, IL_0eab, IL_0eb9, IL_0ecc, IL_0ed7, IL_0eef, IL_0efd, IL_0f08, IL_0f6a, IL_0f7d, IL_0f8b, IL_0f96, IL_0fd6, IL_0fea, IL_0ffd, IL_100b, IL_1016, IL_1056, IL_106a, IL_107d, IL_108b, IL_1099, IL_10b2, IL_10c0, IL_10ce, IL_10e1, IL_10ec, IL_10fa, IL_112c, IL_113a, IL_114d, IL_115b, IL_1169, IL_1172, IL_1180, IL_11a3, IL_11ad, IL_11bb, IL_11ce, IL_11dc, IL_11e7, IL_1227, IL_123b, IL_124e, IL_125c, IL_126a, IL_12aa, IL_12be, IL_12d1, IL_12dc, IL_12ea, IL_12fd, IL_130b, IL_1319, IL_1359, IL_136d, IL_1389, IL_1397, IL_13a5, IL_13bd, IL_13db, IL_13ff, IL_1417, IL_1433, IL_1441, IL_144f, IL_146c, IL_14bb, IL_14c5, IL_14f2, IL_1506, IL_1514, IL_1527, IL_1535, IL_1548, IL_1553, IL_1561, IL_157f, IL_158d, IL_15a0, IL_15ae, IL_15bc, IL_15e5, IL_15fe, IL_160c, IL_1617, IL_1655, IL_1668, IL_1676, IL_1684, IL_1692, IL_16aa, IL_16b8, IL_16cb, IL_16d6, IL_16e4, IL_16ed, IL_1701, IL_1739, IL_1749, IL_1754, IL_175f, IL_1778, IL_1786, IL_179d, IL_17ad, IL_17c0, IL_17d3, IL_17dd, IL_17e8, IL_17f8, IL_1808, IL_1818, IL_1828, IL_1841, IL_1851, IL_1861, IL_1871, IL_188c are reachable both inside and outside the pinned region starting at IL_1886. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 221;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef44 = default(int);
			ref int reference = ref __rxRef44;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1871:
					num2 = 1;
					while (true)
					{
						IL_1861:
						num3 = num2 * 4;
						while (true)
						{
							IL_1851:
							num4 = num2 * 8;
							while (true)
							{
								IL_1841:
								array2 = new byte[4];
								while (true)
								{
									IL_1828:
									array3 = new object[4];
									num = 304;
									while (true)
									{
										IL_1818:
										array4 = new int[4];
										while (true)
										{
											IL_1808:
											array5 = new int[7];
											while (true)
											{
												IL_17f8:
												array6 = new long[4];
												while (true)
												{
													IL_17e8:
													array7 = new object[11];
													while (true)
													{
														IL_17dd:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComposedOfNoPublicMembersAddEventHandler.IsWellKnownBeginRead);
														while (true)
														{
															IL_17d3:
															ptr2 = ptr;
															while (true)
															{
																IL_17c0:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_065f:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_064f:
																			ptr2++;
																			while (true)
																			{
																				IL_063f:
																				if (b >= 1)
																				{
																					while (b <= 40)
																					{
																						while (true)
																						{
																							IL_061f:
																							if (20 < b)
																							{
																								while (true)
																								{
																									IL_060f:
																									if (30 >= b)
																									{
																										while (true)
																										{
																											IL_0602:
																											if (30 > b)
																											{
																												while (true)
																												{
																													IL_05f2:
																													if (25 < b)
																													{
																														while (true)
																														{
																															IL_05e5:
																															if (27 < b)
																															{
																																while (true)
																																{
																																	IL_05d5:
																																	if (28 >= b)
																																	{
																																		while (28 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_057a:
																																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																				num = 342;
																																				while (true)
																																				{
																																					if (num != 342)
																																					{
																																						if (num != 1323)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 221:
																																							break;
																																						default:
																																							continue;
																																						case 218:
																																						case 256:
																																							goto IL_057a;
																																						case 84:
																																							goto IL_05c5;
																																						case 116:
																																							goto IL_05d5;
																																						case 8:
																																							goto IL_05e5;
																																						case 316:
																																							goto IL_05f2;
																																						case 313:
																																							goto IL_0602;
																																						case 149:
																																							goto IL_060f;
																																						case 20:
																																							goto IL_061f;
																																						case 111:
																																							goto IL_062f;
																																						case 35:
																																							goto IL_063f;
																																						case 1:
																																							goto IL_064f;
																																						case 215:
																																						case 272:
																																							goto IL_065f;
																																						case 5:
																																							goto IL_066a;
																																						case 11:
																																						case 80:
																																							goto IL_0677;
																																						case 90:
																																							goto IL_069c;
																																						case 192:
																																							goto IL_06aa;
																																						case 200:
																																							goto IL_06ba;
																																						case 103:
																																							goto IL_06c8;
																																						case 165:
																																						case 205:
																																							goto IL_06db;
																																						case 17:
																																							goto IL_06f4;
																																						case 19:
																																							goto IL_0702;
																																						case 181:
																																							goto IL_0710;
																																						case 162:
																																						case 253:
																																							goto IL_0723;
																																						case 135:
																																							goto IL_073c;
																																						case 265:
																																							goto IL_074f;
																																						case 166:
																																							goto IL_075d;
																																						case 193:
																																							goto IL_0768;
																																						case 76:
																																							goto IL_077b;
																																						case 152:
																																							goto IL_0792;
																																						case 98:
																																						case 214:
																																							goto IL_07a9;
																																						case 219:
																																							goto IL_07d0;
																																						case 105:
																																							goto IL_07e7;
																																						case 33:
																																						case 222:
																																							goto IL_07fa;
																																						case 281:
																																							goto IL_0845;
																																						case 199:
																																							goto IL_0853;
																																						case 2:
																																						case 284:
																																							goto IL_0861;
																																						case 91:
																																							goto IL_08a2;
																																						case 228:
																																							goto IL_08b6;
																																						case 286:
																																							goto IL_08c9;
																																						case 151:
																																							goto IL_08dd;
																																						case 294:
																																							goto IL_08f0;
																																						case 83:
																																						case 314:
																																							goto IL_0903;
																																						case 211:
																																							goto IL_0955;
																																						case 317:
																																							goto IL_0968;
																																						case 146:
																																							goto IL_0976;
																																						case 16:
																																						case 132:
																																							goto IL_0984;
																																						case 183:
																																							goto IL_09a8;
																																						case 202:
																																							goto IL_09b6;
																																						case 212:
																																							goto IL_09c4;
																																						case 328:
																																							goto IL_09d7;
																																						case 312:
																																							goto IL_0a07;
																																						case 327:
																																							goto IL_0a1a;
																																						case 278:
																																							goto IL_0a28;
																																						case 245:
																																						case 307:
																																							goto IL_0a36;
																																						case 291:
																																							goto IL_0a4a;
																																						case 0:
																																							goto IL_0a89;
																																						case 25:
																																							goto IL_0a9c;
																																						case 263:
																																							goto IL_0aaa;
																																						case 147:
																																							goto IL_0ab8;
																																						case 45:
																																							goto IL_0ac6;
																																						case 251:
																																							goto IL_0ad1;
																																						case 324:
																																							goto IL_0adf;
																																						case 138:
																																						case 267:
																																							goto IL_0aed;
																																						case 71:
																																							goto IL_0b25;
																																						case 161:
																																							goto IL_0b39;
																																						case 194:
																																						case 311:
																																							goto IL_0b4c;
																																						case 141:
																																							goto IL_0b60;
																																						case 198:
																																							goto IL_0bac;
																																						case 217:
																																							goto IL_0bba;
																																						case 150:
																																							goto IL_0bcd;
																																						case 175:
																																							goto IL_0bd8;
																																						case 160:
																																						case 170:
																																							goto IL_0be6;
																																						case 52:
																																							goto IL_0c18;
																																						case 30:
																																							goto IL_0c26;
																																						case 287:
																																							goto IL_0c39;
																																						case 273:
																																							goto IL_0c47;
																																						case 3:
																																						case 56:
																																							goto IL_0c5e;
																																						case 46:
																																							goto IL_0c72;
																																						case 121:
																																							goto IL_0cb1;
																																						case 280:
																																						case 320:
																																							goto IL_0ccd;
																																						case 143:
																																							goto IL_0d0d;
																																						case 101:
																																							goto IL_0d21;
																																						case 129:
																																							goto IL_0d34;
																																						case 223:
																																							goto IL_0d42;
																																						case 106:
																																						case 276:
																																							goto IL_0d4d;
																																						case 173:
																																							goto IL_0d78;
																																						case 264:
																																							goto IL_0d91;
																																						case 23:
																																							goto IL_0d9c;
																																						case 41:
																																						case 51:
																																							goto IL_0daa;
																																						case 282:
																																							goto IL_0de8;
																																						case 176:
																																							goto IL_0dfc;
																																						case 123:
																																							goto IL_0e0f;
																																						case 109:
																																							goto IL_0e1d;
																																						case 28:
																																						case 74:
																																							goto IL_0e2b;
																																						case 155:
																																							goto IL_0e55;
																																						case 82:
																																							goto IL_0e63;
																																						case 248:
																																							goto IL_0e76;
																																						case 86:
																																							goto IL_0e81;
																																						case 18:
																																						case 258:
																																							goto IL_0e8f;
																																						case 297:
																																							goto IL_0eab;
																																						case 57:
																																							goto IL_0eb9;
																																						case 54:
																																							goto IL_0ecc;
																																						case 65:
																																						case 244:
																																							goto IL_0ed7;
																																						case 259:
																																							goto IL_0eef;
																																						case 79:
																																							goto IL_0efd;
																																						case 10:
																																						case 154:
																																							goto IL_0f08;
																																						case 27:
																																							goto IL_0f6a;
																																						case 262:
																																							goto IL_0f7d;
																																						case 310:
																																							goto IL_0f8b;
																																						case 168:
																																						case 169:
																																							goto IL_0f96;
																																						case 139:
																																							goto IL_0fd6;
																																						case 201:
																																							goto IL_0fea;
																																						case 187:
																																							goto IL_0ffd;
																																						case 191:
																																							goto IL_100b;
																																						case 85:
																																						case 124:
																																							goto IL_1016;
																																						case 190:
																																							goto IL_1056;
																																						case 108:
																																							goto IL_106a;
																																						case 49:
																																							goto IL_107d;
																																						case 334:
																																							goto IL_108b;
																																						case 64:
																																						case 93:
																																							goto IL_1099;
																																						case 254:
																																							goto end_IL_0567;
																																						case 196:
																																							goto IL_10c0;
																																						case 134:
																																							goto IL_10ce;
																																						case 249:
																																							goto IL_10e1;
																																						case 15:
																																							goto IL_10ec;
																																						case 234:
																																						case 301:
																																							goto IL_10fa;
																																						case 67:
																																							goto IL_112c;
																																						case 323:
																																							goto IL_113a;
																																						case 115:
																																							goto IL_114d;
																																						case 179:
																																							goto IL_115b;
																																						case 167:
																																						case 283:
																																							goto IL_1172;
																																						case 22:
																																							goto IL_1180;
																																						case 125:
																																							goto IL_11a3;
																																						case 9:
																																							goto IL_11ad;
																																						case 164:
																																							goto IL_11bb;
																																						case 113:
																																							goto IL_11ce;
																																						case 185:
																																							goto IL_11dc;
																																						case 60:
																																						case 329:
																																							goto IL_11e7;
																																						case 118:
																																							goto IL_1227;
																																						case 114:
																																							goto IL_123b;
																																						case 34:
																																							goto IL_124e;
																																						case 188:
																																							goto IL_125c;
																																						case 55:
																																						case 184:
																																							goto IL_126a;
																																						case 32:
																																							goto IL_12aa;
																																						case 232:
																																							goto IL_12be;
																																						case 295:
																																							goto IL_12d1;
																																						case 6:
																																							goto IL_12dc;
																																						case 89:
																																						case 302:
																																							goto IL_12ea;
																																						case 243:
																																							goto IL_12fd;
																																						case 81:
																																							goto IL_130b;
																																						case 72:
																																						case 137:
																																							goto IL_1319;
																																						case 142:
																																							goto IL_1359;
																																						case 136:
																																							goto IL_136d;
																																						case 274:
																																							goto IL_1389;
																																						case 309:
																																							goto IL_1397;
																																						case 58:
																																						case 213:
																																							goto IL_13a5;
																																						case 178:
																																							goto IL_13bd;
																																						case 4:
																																							goto IL_13db;
																																						case 13:
																																							goto IL_13ff;
																																						case 180:
																																							goto IL_1417;
																																						case 246:
																																							goto IL_1433;
																																						case 47:
																																							goto IL_1441;
																																						case 233:
																																						case 300:
																																							goto IL_144f;
																																						case 53:
																																							goto IL_1506;
																																						case 171:
																																							goto IL_1514;
																																						case 94:
																																							goto IL_1527;
																																						case 12:
																																							goto IL_1535;
																																						case 299:
																																							goto IL_1548;
																																						case 92:
																																							goto IL_1553;
																																						case 305:
																																						case 332:
																																							goto IL_1561;
																																						case 225:
																																							goto IL_157f;
																																						case 296:
																																							goto IL_158d;
																																						case 319:
																																							goto IL_15a0;
																																						case 144:
																																							goto IL_15ae;
																																						case 216:
																																						case 252:
																																							goto IL_15bc;
																																						case 63:
																																							goto IL_15e5;
																																						case 156:
																																							goto IL_15fe;
																																						case 279:
																																							goto IL_160c;
																																						case 48:
																																						case 50:
																																							goto IL_1617;
																																						case 70:
																																							goto IL_1655;
																																						case 285:
																																							goto IL_1668;
																																						case 174:
																																							goto IL_1676;
																																						case 26:
																																						case 293:
																																							goto IL_1684;
																																						case 159:
																																							goto IL_1692;
																																						case 78:
																																							goto IL_16aa;
																																						case 14:
																																							goto IL_16b8;
																																						case 110:
																																							goto IL_16cb;
																																						case 61:
																																							goto IL_16d6;
																																						case 321:
																																						case 330:
																																							goto IL_16ed;
																																						case 128:
																																							goto IL_1701;
																																						case 88:
																																							goto IL_1739;
																																						case 250:
																																							goto IL_1749;
																																						case 241:
																																							goto IL_1754;
																																						case 42:
																																						case 186:
																																							goto IL_175f;
																																						case 242:
																																							goto IL_1778;
																																						case 235:
																																							goto IL_1786;
																																						case 203:
																																							goto IL_179d;
																																						case 24:
																																						case 29:
																																						case 38:
																																						case 40:
																																						case 43:
																																						case 44:
																																						case 59:
																																						case 66:
																																						case 68:
																																						case 69:
																																						case 73:
																																						case 75:
																																						case 87:
																																						case 96:
																																						case 102:
																																						case 107:
																																						case 117:
																																						case 120:
																																						case 122:
																																						case 127:
																																						case 145:
																																						case 153:
																																						case 207:
																																						case 224:
																																						case 226:
																																						case 231:
																																						case 236:
																																						case 238:
																																						case 240:
																																						case 247:
																																						case 255:
																																						case 257:
																																						case 261:
																																						case 266:
																																						case 268:
																																						case 271:
																																						case 289:
																																						case 290:
																																						case 303:
																																						case 315:
																																						case 318:
																																						case 325:
																																						case 335:
																																							goto end_IL_05c5;
																																						case 7:
																																						case 36:
																																						case 39:
																																						case 62:
																																						case 77:
																																						case 97:
																																						case 104:
																																						case 112:
																																						case 119:
																																						case 126:
																																						case 130:
																																						case 131:
																																						case 133:
																																						case 140:
																																						case 148:
																																						case 157:
																																						case 158:
																																						case 163:
																																						case 172:
																																						case 182:
																																						case 195:
																																						case 197:
																																						case 204:
																																						case 206:
																																						case 208:
																																						case 209:
																																						case 210:
																																						case 227:
																																						case 229:
																																						case 230:
																																						case 237:
																																						case 239:
																																						case 260:
																																						case 269:
																																						case 270:
																																						case 277:
																																						case 288:
																																						case 292:
																																						case 306:
																																						case 308:
																																						case 326:
																																						case 331:
																																						case 333:
																																							goto IL_17c0;
																																						case 322:
																																							goto IL_17d3;
																																						case 275:
																																							goto IL_17dd;
																																						case 189:
																																							goto IL_17e8;
																																						case 99:
																																							goto IL_17f8;
																																						case 298:
																																							goto IL_1808;
																																						case 304:
																																							goto IL_1818;
																																						case 100:
																																							goto IL_1828;
																																						case 37:
																																							goto IL_1841;
																																						case 95:
																																							goto IL_1851;
																																						case 21:
																																							goto IL_1861;
																																						case 220:
																																							goto IL_1871;
																																						case 31:
																																						case 177:
																																							return;
																																						}
																																						goto end_IL_063f;
																																					}
																																					array2[num6 - 2] = 3;
																																					num = 312;
																																					goto IL_0a07;
																																					IL_0a07:
																																					num6--;
																																					goto IL_17c0;
																																					continue;
																																					end_IL_0567:
																																					break;
																																				}
																																				break;
																																			}
																																			goto IL_10b2;
																																			continue;
																																			end_IL_05c5:
																																			break;
																																			IL_05c5:;
																																		}
																																		break;
																																	}
																																	goto IL_0a1a;
																																	IL_0a89:
																																	ptr2 += 8;
																																	goto IL_17c0;
																																	IL_0a1a:
																																	if (29 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0a28;
																																	IL_0a28:
																																	if (29 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0a36;
																																	IL_0a36:
																																	array2[num6 - 1] = 0;
																																	goto IL_0a4a;
																																	IL_0a4a:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	goto IL_0a89;
																																}
																																break;
																															}
																															goto IL_066a;
																															IL_073c:
																															num6--;
																															goto IL_17c0;
																															IL_066a:
																															if (27 > b)
																															{
																																goto IL_069c;
																															}
																															goto IL_06db;
																															IL_06db:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																															goto IL_06f4;
																															IL_06f4:
																															array2[num6] = 3;
																															goto IL_0702;
																															IL_0702:
																															num6++;
																															goto IL_0710;
																															IL_0710:
																															ptr2 += 16;
																															goto IL_17c0;
																															IL_069c:
																															if (26 < b)
																															{
																																break;
																															}
																															goto IL_06aa;
																															IL_06aa:
																															if (26 > b)
																															{
																																break;
																															}
																															goto IL_0723;
																															IL_0723:
																															global::_003CModule_003E.tracerOption_0 = (TracerOption)array3[num6 - 1];
																															goto IL_073c;
																														}
																														break;
																													}
																													goto IL_074f;
																													IL_07fa:
																													array3[num6 - 2] = ((TracerOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													num = 286;
																													goto IL_08c9;
																													IL_074f:
																													if (25 > b)
																													{
																														goto IL_075d;
																													}
																													goto IL_07fa;
																													IL_075d:
																													if (22 >= b)
																													{
																														goto IL_0768;
																													}
																													goto IL_077b;
																													IL_0768:
																													if (22 > b)
																													{
																														goto IL_0845;
																													}
																													goto IL_0903;
																													IL_0903:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0955;
																													IL_0955:
																													num6--;
																													goto IL_17c0;
																													IL_0845:
																													if (21 < b)
																													{
																														break;
																													}
																													goto IL_0853;
																													IL_0853:
																													if (21 > b)
																													{
																														break;
																													}
																													goto IL_0861;
																													IL_0861:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																													goto IL_08a2;
																													IL_08a2:
																													array2[num6 - 2] = 0;
																													goto IL_08b6;
																													IL_08b6:
																													num6--;
																													goto IL_17c0;
																													IL_077b:
																													if (23 >= b)
																													{
																														num = 152;
																														goto IL_0792;
																													}
																													goto IL_0968;
																													IL_08c9:
																													array2[num6 - 2] = 4;
																													goto IL_08dd;
																													IL_0792:
																													if (23 > b)
																													{
																														break;
																													}
																													num = 98;
																													goto IL_07a9;
																													IL_08dd:
																													num6--;
																													goto IL_17c0;
																													IL_07a9:
																													array3[num6] = ((delegate*<TracerOption[]>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																													num = 219;
																													goto IL_07d0;
																													IL_07d0:
																													array2[num6] = 5;
																													num = 105;
																													goto IL_07e7;
																													IL_07e7:
																													num6++;
																													goto IL_08f0;
																													IL_08f0:
																													ptr2 += 8;
																													goto IL_17c0;
																													IL_0968:
																													if (24 < b)
																													{
																														break;
																													}
																													goto IL_0976;
																													IL_0976:
																													if (24 > b)
																													{
																														break;
																													}
																													goto IL_0984;
																													IL_0984:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																													goto IL_09a8;
																													IL_09a8:
																													array2[num6] = 0;
																													goto IL_09b6;
																													IL_09b6:
																													num6++;
																													goto IL_09c4;
																													IL_09c4:
																													ptr2 += 8;
																													goto IL_17c0;
																												}
																												break;
																											}
																											goto IL_0677;
																											IL_09d7:
																											ptr2 += 8;
																											goto IL_17c0;
																											IL_0677:
																											array3[num6] = ((delegate*<TracerOption>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																											goto IL_06ba;
																											IL_06ba:
																											array2[num6] = 4;
																											goto IL_06c8;
																											IL_06c8:
																											num6++;
																											goto IL_09d7;
																										}
																										break;
																									}
																									goto IL_0a9c;
																									IL_0e8f:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto IL_17c0;
																									IL_0a9c:
																									if (35 >= b)
																									{
																										goto IL_0aaa;
																									}
																									goto IL_0d34;
																									IL_0aaa:
																									if (35 > b)
																									{
																										goto IL_0ab8;
																									}
																									num = 320;
																									goto IL_0ccd;
																									IL_0ab8:
																									if (32 >= b)
																									{
																										goto IL_0ac6;
																									}
																									goto IL_0bcd;
																									IL_0ac6:
																									if (32 > b)
																									{
																										goto IL_0ad1;
																									}
																									goto IL_0b4c;
																									IL_0ad1:
																									if (31 < b)
																									{
																										break;
																									}
																									goto IL_0adf;
																									IL_0adf:
																									if (31 > b)
																									{
																										break;
																									}
																									goto IL_0aed;
																									IL_0aed:
																									array3[num6 - 1] = ((delegate*<TracerOption, string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																									goto IL_0b25;
																									IL_0b25:
																									array2[num6 - 1] = 5;
																									goto IL_0b39;
																									IL_0b39:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0b4c:
																									array2[num6 - 2] = 5;
																									goto IL_0b60;
																									IL_0b60:
																									array3[num6 - 2] = ((delegate*<string, string, string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																									goto IL_0bac;
																									IL_0bac:
																									num6--;
																									goto IL_0bba;
																									IL_0bba:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0bcd:
																									if (33 >= b)
																									{
																										goto IL_0bd8;
																									}
																									goto IL_0c39;
																									IL_0bd8:
																									if (33 > b)
																									{
																										break;
																									}
																									goto IL_0be6;
																									IL_0be6:
																									((delegate*<string, void>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																									num = 52;
																									goto IL_0c18;
																									IL_0c18:
																									num6--;
																									goto IL_0c26;
																									IL_0c26:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0c39:
																									if (34 < b)
																									{
																										break;
																									}
																									goto IL_0c47;
																									IL_0c47:
																									if (34 > b)
																									{
																										break;
																									}
																									num = 3;
																									goto IL_0c5e;
																									IL_0eb9:
																									if (40 > b)
																									{
																									}
																									break;
																									IL_0c5e:
																									array2[num6 - 1] = 3;
																									goto IL_0c72;
																									IL_0c72:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0cb1;
																									IL_0cb1:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0eab:
																									if (40 < b)
																									{
																										break;
																									}
																									goto IL_0eb9;
																									IL_0ccd:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0d0d;
																									IL_0d0d:
																									array2[num6 - 2] = 3;
																									goto IL_0d21;
																									IL_0d21:
																									num6--;
																									goto IL_17c0;
																									IL_0d34:
																									if (38 >= b)
																									{
																										goto IL_0d42;
																									}
																									goto IL_0e76;
																									IL_0d42:
																									if (38 <= b)
																									{
																										goto IL_0d4d;
																									}
																									goto IL_0d91;
																									IL_0d4d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0d78;
																									IL_0d78:
																									array2[num6 - 1] = 0;
																									goto IL_17c0;
																									IL_0d91:
																									if (36 >= b)
																									{
																										goto IL_0d9c;
																									}
																									goto IL_0e0f;
																									IL_0d9c:
																									if (36 > b)
																									{
																										break;
																									}
																									goto IL_0daa;
																									IL_0daa:
																									*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<TracerOption, Class8.TracerStyle>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																									goto IL_0de8;
																									IL_0de8:
																									array2[num6 - 1] = 0;
																									goto IL_0dfc;
																									IL_0dfc:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0e0f:
																									if (37 < b)
																									{
																										break;
																									}
																									goto IL_0e1d;
																									IL_0e1d:
																									if (37 > b)
																									{
																										break;
																									}
																									goto IL_0e2b;
																									IL_0e2b:
																									((delegate*<Class8.TracerStyle, void>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0e55;
																									IL_0e55:
																									num6--;
																									goto IL_0e63;
																									IL_0e63:
																									ptr2 += 8;
																									goto IL_17c0;
																									IL_0e76:
																									if (39 >= b)
																									{
																										goto IL_0e81;
																									}
																									goto IL_0eab;
																									IL_0e81:
																									if (39 > b)
																									{
																										break;
																									}
																									goto IL_0e8f;
																								}
																								break;
																							}
																							goto IL_0ecc;
																							IL_1749:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_1754;
																							IL_0ecc:
																							if (20 <= b)
																							{
																								goto IL_0ed7;
																							}
																							goto IL_0eef;
																							IL_0ed7:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_17c0;
																							IL_0eef:
																							if (10 >= b)
																							{
																								goto IL_0efd;
																							}
																							goto IL_1389;
																							IL_0efd:
																							if (10 <= b)
																							{
																								goto IL_0f08;
																							}
																							goto IL_0f7d;
																							IL_0f08:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0f6a;
																							IL_0f6a:
																							num6 -= 2;
																							goto IL_17c0;
																							IL_0f7d:
																							if (5 >= b)
																							{
																								goto IL_0f8b;
																							}
																							goto IL_11ce;
																							IL_0f8b:
																							if (5 <= b)
																							{
																								goto IL_0f96;
																							}
																							goto IL_0ffd;
																							IL_0f96:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0fd6;
																							IL_0fd6:
																							array2[num6 - 2] = 0;
																							goto IL_0fea;
																							IL_0fea:
																							num6--;
																							goto IL_17c0;
																							IL_0ffd:
																							if (2 >= b)
																							{
																								goto IL_100b;
																							}
																							goto IL_10e1;
																							IL_100b:
																							if (2 <= b)
																							{
																								goto IL_1016;
																							}
																							goto IL_107d;
																							IL_1016:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1056;
																							IL_1056:
																							array2[num6 - 2] = 0;
																							goto IL_106a;
																							IL_106a:
																							num6--;
																							goto IL_17c0;
																							IL_107d:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_108b;
																							IL_108b:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_1099;
																							IL_1099:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_10b2;
																							IL_10b2:
																							array2[num6] = 0;
																							goto IL_10c0;
																							IL_10c0:
																							num6++;
																							goto IL_10ce;
																							IL_10ce:
																							ptr2 += 8;
																							goto IL_17c0;
																							IL_10e1:
																							if (3 >= b)
																							{
																								goto IL_10ec;
																							}
																							goto IL_114d;
																							IL_10ec:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_10fa;
																							IL_10fa:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 67;
																							goto IL_112c;
																							IL_112c:
																							ptr2 += 8;
																							goto IL_113a;
																							IL_113a:
																							num6--;
																							goto IL_17c0;
																							IL_114d:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_115b;
																							IL_115b:
																							if (4 > b)
																							{
																								break;
																							}
																							num = 283;
																							goto IL_1172;
																							IL_1754:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_175f;
																							IL_1172:
																							array2[num6] = 0;
																							goto IL_1180;
																							IL_1180:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_11a3;
																							IL_11a3:
																							array3[num6] = null;
																							goto IL_11ad;
																							IL_11ad:
																							num6++;
																							goto IL_11bb;
																							IL_11bb:
																							ptr2 += 8;
																							goto IL_17c0;
																							IL_11ce:
																							if (7 >= b)
																							{
																								goto IL_11dc;
																							}
																							goto IL_12d1;
																							IL_11dc:
																							if (7 <= b)
																							{
																								goto IL_11e7;
																							}
																							goto IL_124e;
																							IL_11e7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1227;
																							IL_1227:
																							array2[num6 - 2] = 0;
																							goto IL_123b;
																							IL_123b:
																							num6--;
																							goto IL_17c0;
																							IL_124e:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_125c;
																							IL_125c:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_126a;
																							IL_126a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_12aa;
																							IL_12aa:
																							array2[num6 - 2] = 0;
																							goto IL_12be;
																							IL_12be:
																							num6--;
																							goto IL_17c0;
																							IL_12d1:
																							if (8 >= b)
																							{
																								goto IL_12dc;
																							}
																							goto IL_12fd;
																							IL_12dc:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_12ea;
																							IL_12ea:
																							num6--;
																							goto IL_17c0;
																							IL_12fd:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_130b;
																							IL_130b:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_1319;
																							IL_1319:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1359;
																							IL_1359:
																							array2[num6 - 2] = 0;
																							goto IL_136d;
																							IL_136d:
																							num6--;
																							num = 269;
																							goto IL_17c0;
																							IL_1389:
																							if (15 >= b)
																							{
																								goto IL_1397;
																							}
																							goto IL_15fe;
																							IL_1397:
																							if (15 <= b)
																							{
																								goto IL_13a5;
																							}
																							goto IL_1433;
																							IL_13a5:
																							array2[num6] = array2[num6 - 1];
																							goto IL_13bd;
																							IL_13bd:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_13db;
																							IL_13db:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_13ff;
																							IL_13ff:
																							array3[num6] = array3[num6 - 1];
																							goto IL_1417;
																							IL_1417:
																							num6++;
																							num = 163;
																							goto IL_17c0;
																							IL_1433:
																							if (12 >= b)
																							{
																								goto IL_1441;
																							}
																							goto IL_1548;
																							IL_1441:
																							if (12 <= b)
																							{
																								goto IL_144f;
																							}
																							goto IL_1527;
																							IL_144f:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_145e;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_1506;
																							IL_175f:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_1778;
																							IL_1778:
																							array2[num6] = 1;
																							goto IL_1786;
																							IL_1786:
																							num6++;
																							num = 203;
																							goto IL_179d;
																							IL_1506:
																							array2[num6] = 5;
																							goto IL_1514;
																							IL_1514:
																							num6++;
																							goto IL_17c0;
																							IL_1527:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_1535;
																							IL_1535:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_17c0;
																							IL_1548:
																							if (13 >= b)
																							{
																								goto IL_1553;
																							}
																							goto IL_15a0;
																							IL_1553:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_1561;
																							IL_1561:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_157f;
																							IL_157f:
																							ptr2 += 8;
																							goto IL_158d;
																							IL_158d:
																							num6--;
																							goto IL_17c0;
																							IL_15a0:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_15ae;
																							IL_15ae:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_15bc;
																							IL_15bc:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_15e5;
																							IL_15e5:
																							array2[num6 - 1] = 5;
																							goto IL_17c0;
																							IL_15fe:
																							if (17 >= b)
																							{
																								goto IL_160c;
																							}
																							goto IL_16cb;
																							IL_160c:
																							if (17 <= b)
																							{
																								goto IL_1617;
																							}
																							goto IL_1668;
																							IL_1617:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_1655;
																							IL_1655:
																							num6 -= 3;
																							goto IL_17c0;
																							IL_1668:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_1676;
																							IL_1676:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_1684;
																							IL_1684:
																							array2[num6] = 5;
																							goto IL_1692;
																							IL_1692:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_16aa;
																							IL_16aa:
																							num6++;
																							goto IL_16b8;
																							IL_16b8:
																							ptr2 += 8;
																							goto IL_17c0;
																							IL_16cb:
																							if (18 >= b)
																							{
																								goto IL_16d6;
																							}
																							goto IL_1749;
																							IL_16d6:
																							if (18 > b)
																							{
																								break;
																							}
																							num = 321;
																							goto IL_16ed;
																							IL_179d:
																							ptr2 += 16;
																							goto IL_17c0;
																							IL_16ed:
																							array2[num6 - 1] = 5;
																							goto IL_1701;
																							IL_1701:
																							array3[num6 - 1] = ((delegate*<string[], string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_1739;
																							IL_1739:
																							ptr2 += 8;
																							goto IL_17c0;
																						}
																						break;
																						IL_062f:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_17c0;
																				continue;
																				end_IL_063f:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 31;
																return;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_145e:
			while (true)
			{
				IL_145e_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_1506_2:
						array2[num6] = 5;
						while (true)
						{
							IL_1514_2:
							num6++;
							while (true)
							{
								IL_17c0_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_063f_2:
												if (b >= 1)
												{
													while (b <= 40)
													{
														while (true)
														{
															IL_061f_2:
															if (20 < b)
															{
																while (true)
																{
																	IL_060f_2:
																	if (30 >= b)
																	{
																		while (true)
																		{
																			IL_0602_2:
																			if (30 > b)
																			{
																				while (true)
																				{
																					IL_05f2_2:
																					if (25 < b)
																					{
																						while (true)
																						{
																							IL_05e5_2:
																							if (27 < b)
																							{
																								while (true)
																								{
																									IL_05d5_2:
																									if (28 >= b)
																									{
																										while (28 <= b)
																										{
																											while (true)
																											{
																												IL_057a_2:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 342;
																												while (true)
																												{
																													if (num != 342)
																													{
																														if (num != 1323)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 218:
																														case 256:
																															goto IL_057a_2;
																														case 84:
																															goto IL_05c5_2;
																														case 116:
																															goto IL_05d5_2;
																														case 8:
																															goto IL_05e5_2;
																														case 316:
																															goto IL_05f2_2;
																														case 313:
																															goto IL_0602_2;
																														case 149:
																															goto IL_060f_2;
																														case 20:
																															goto IL_061f_2;
																														case 111:
																															goto IL_062f_2;
																														case 35:
																															goto IL_063f_2;
																														case 1:
																															goto end_IL_063f_2;
																														case 215:
																														case 272:
																															goto end_IL_064f;
																														case 5:
																															goto IL_066a_2;
																														case 11:
																														case 80:
																															goto IL_0677_2;
																														case 90:
																															goto IL_069c_2;
																														case 192:
																															goto IL_06aa_2;
																														case 200:
																															goto IL_06ba_2;
																														case 103:
																															goto IL_06c8_2;
																														case 165:
																														case 205:
																															goto IL_06db_2;
																														case 17:
																															goto IL_06f4_2;
																														case 19:
																															goto IL_0702_2;
																														case 181:
																															goto IL_0710_2;
																														case 162:
																														case 253:
																															goto IL_0723_2;
																														case 135:
																															goto IL_073c_2;
																														case 265:
																															goto IL_074f_2;
																														case 166:
																															goto IL_075d_2;
																														case 193:
																															goto IL_0768_2;
																														case 76:
																															goto IL_077b_2;
																														case 152:
																															goto IL_0792_2;
																														case 98:
																														case 214:
																															goto IL_07a9_2;
																														case 219:
																															goto IL_07d0_2;
																														case 105:
																															goto IL_07e7_2;
																														case 33:
																														case 222:
																															goto IL_07fa_2;
																														case 281:
																															goto IL_0845_2;
																														case 199:
																															goto IL_0853_2;
																														case 2:
																														case 284:
																															goto IL_0861_2;
																														case 91:
																															goto IL_08a2_2;
																														case 228:
																															goto IL_08b6_2;
																														case 286:
																															goto IL_08c9_2;
																														case 151:
																															goto IL_08dd_2;
																														case 294:
																															goto IL_08f0_2;
																														case 83:
																														case 314:
																															goto IL_0903_2;
																														case 211:
																															goto IL_0955_2;
																														case 317:
																															goto IL_0968_2;
																														case 146:
																															goto IL_0976_2;
																														case 16:
																														case 132:
																															goto IL_0984_2;
																														case 183:
																															goto IL_09a8_2;
																														case 202:
																															goto IL_09b6_2;
																														case 212:
																															goto IL_09c4_2;
																														case 328:
																															goto IL_09d7_2;
																														case 312:
																															goto IL_0a07_2;
																														case 327:
																															goto IL_0a1a_2;
																														case 278:
																															goto IL_0a28_2;
																														case 245:
																														case 307:
																															goto IL_0a36_2;
																														case 291:
																															goto IL_0a4a_2;
																														case 0:
																															goto IL_0a89_2;
																														case 25:
																															goto IL_0a9c_2;
																														case 263:
																															goto IL_0aaa_2;
																														case 147:
																															goto IL_0ab8_2;
																														case 45:
																															goto IL_0ac6_2;
																														case 251:
																															goto IL_0ad1_2;
																														case 324:
																															goto IL_0adf_2;
																														case 138:
																														case 267:
																															goto IL_0aed_2;
																														case 71:
																															goto IL_0b25_2;
																														case 161:
																															goto IL_0b39_2;
																														case 194:
																														case 311:
																															goto IL_0b4c_2;
																														case 141:
																															goto IL_0b60_2;
																														case 198:
																															goto IL_0bac_2;
																														case 217:
																															goto IL_0bba_2;
																														case 150:
																															goto IL_0bcd_2;
																														case 175:
																															goto IL_0bd8_2;
																														case 160:
																														case 170:
																															goto IL_0be6_2;
																														case 52:
																															goto IL_0c18_2;
																														case 30:
																															goto IL_0c26_2;
																														case 287:
																															goto IL_0c39_2;
																														case 273:
																															goto IL_0c47_2;
																														case 3:
																														case 56:
																															goto IL_0c5e_2;
																														case 46:
																															goto IL_0c72_2;
																														case 121:
																															goto IL_0cb1_2;
																														case 280:
																														case 320:
																															goto IL_0ccd_2;
																														case 143:
																															goto IL_0d0d_2;
																														case 101:
																															goto IL_0d21_2;
																														case 129:
																															goto IL_0d34_2;
																														case 223:
																															goto IL_0d42_2;
																														case 106:
																														case 276:
																															goto IL_0d4d_2;
																														case 173:
																															goto IL_0d78_2;
																														case 264:
																															goto IL_0d91_2;
																														case 23:
																															goto IL_0d9c_2;
																														case 41:
																														case 51:
																															goto IL_0daa_2;
																														case 282:
																															goto IL_0de8_2;
																														case 176:
																															goto IL_0dfc_2;
																														case 123:
																															goto IL_0e0f_2;
																														case 109:
																															goto IL_0e1d_2;
																														case 28:
																														case 74:
																															goto IL_0e2b_2;
																														case 155:
																															goto IL_0e55_2;
																														case 82:
																															goto IL_0e63_2;
																														case 248:
																															goto IL_0e76_2;
																														case 86:
																															goto IL_0e81_2;
																														case 18:
																														case 258:
																															goto IL_0e8f_2;
																														case 297:
																															goto IL_0eab_2;
																														case 57:
																															goto IL_0eb9_2;
																														case 54:
																															goto IL_0ecc_2;
																														case 65:
																														case 244:
																															goto IL_0ed7_2;
																														case 259:
																															goto IL_0eef_2;
																														case 79:
																															goto IL_0efd_2;
																														case 10:
																														case 154:
																															goto IL_0f08_2;
																														case 27:
																															goto IL_0f6a_2;
																														case 262:
																															goto IL_0f7d_2;
																														case 310:
																															goto IL_0f8b_2;
																														case 168:
																														case 169:
																															goto IL_0f96_2;
																														case 139:
																															goto IL_0fd6_2;
																														case 201:
																															goto IL_0fea_2;
																														case 187:
																															goto IL_0ffd_2;
																														case 191:
																															goto IL_100b_2;
																														case 85:
																														case 124:
																															goto IL_1016_2;
																														case 190:
																															goto IL_1056_2;
																														case 108:
																															goto IL_106a_2;
																														case 49:
																															goto IL_107d_2;
																														case 334:
																															goto IL_108b_2;
																														case 64:
																														case 93:
																															goto IL_1099_2;
																														case 254:
																															goto end_IL_0567_2;
																														case 196:
																															goto IL_10c0_2;
																														case 134:
																															goto IL_10ce_2;
																														case 249:
																															goto IL_10e1_2;
																														case 15:
																															goto IL_10ec_2;
																														case 234:
																														case 301:
																															goto IL_10fa_2;
																														case 67:
																															goto IL_112c_2;
																														case 323:
																															goto IL_113a_2;
																														case 115:
																															goto IL_114d_2;
																														case 179:
																															goto IL_115b_2;
																														case 167:
																														case 283:
																															goto IL_1172_2;
																														case 22:
																															goto IL_1180_2;
																														case 125:
																															goto IL_11a3_2;
																														case 9:
																															goto IL_11ad_2;
																														case 164:
																															goto IL_11bb_2;
																														case 113:
																															goto IL_11ce_2;
																														case 185:
																															goto IL_11dc_2;
																														case 60:
																														case 329:
																															goto IL_11e7_2;
																														case 118:
																															goto IL_1227_2;
																														case 114:
																															goto IL_123b_2;
																														case 34:
																															goto IL_124e_2;
																														case 188:
																															goto IL_125c_2;
																														case 55:
																														case 184:
																															goto IL_126a_2;
																														case 32:
																															goto IL_12aa_2;
																														case 232:
																															goto IL_12be_2;
																														case 295:
																															goto IL_12d1_2;
																														case 6:
																															goto IL_12dc_2;
																														case 89:
																														case 302:
																															goto IL_12ea_2;
																														case 243:
																															goto IL_12fd_2;
																														case 81:
																															goto IL_130b_2;
																														case 72:
																														case 137:
																															goto IL_1319_2;
																														case 142:
																															goto IL_1359_2;
																														case 136:
																															goto IL_136d_2;
																														case 274:
																															goto IL_1389_2;
																														case 309:
																															goto IL_1397_2;
																														case 58:
																														case 213:
																															goto IL_13a5_2;
																														case 178:
																															goto IL_13bd_2;
																														case 4:
																															goto IL_13db_2;
																														case 13:
																															goto IL_13ff_2;
																														case 180:
																															goto IL_1417_2;
																														case 246:
																															goto IL_1433_2;
																														case 47:
																															goto IL_1441_2;
																														case 233:
																														case 300:
																															goto end_IL_065f;
																														case 53:
																															goto IL_1506_2;
																														case 171:
																															goto IL_1514_2;
																														case 94:
																															goto IL_1527_2;
																														case 12:
																															goto IL_1535_2;
																														case 299:
																															goto IL_1548_2;
																														case 92:
																															goto IL_1553_2;
																														case 305:
																														case 332:
																															goto IL_1561_2;
																														case 225:
																															goto IL_157f_2;
																														case 296:
																															goto IL_158d_2;
																														case 319:
																															goto IL_15a0_2;
																														case 144:
																															goto IL_15ae_2;
																														case 216:
																														case 252:
																															goto IL_15bc_2;
																														case 63:
																															goto IL_15e5_2;
																														case 156:
																															goto IL_15fe_2;
																														case 279:
																															goto IL_160c_2;
																														case 48:
																														case 50:
																															goto IL_1617_2;
																														case 70:
																															goto IL_1655_2;
																														case 285:
																															goto IL_1668_2;
																														case 174:
																															goto IL_1676_2;
																														case 26:
																														case 293:
																															goto IL_1684_2;
																														case 159:
																															goto IL_1692_2;
																														case 78:
																															goto IL_16aa_2;
																														case 14:
																															goto IL_16b8_2;
																														case 110:
																															goto IL_16cb_2;
																														case 61:
																															goto IL_16d6_2;
																														case 321:
																														case 330:
																															goto IL_16ed_2;
																														case 128:
																															goto IL_1701_2;
																														case 88:
																															goto IL_1739_2;
																														case 250:
																															goto IL_1749_2;
																														case 241:
																															goto IL_1754_2;
																														case 42:
																														case 186:
																															goto IL_175f_2;
																														case 242:
																															goto IL_1778_2;
																														case 235:
																															goto IL_1786_2;
																														case 203:
																															goto IL_179d_2;
																														case 24:
																														case 29:
																														case 38:
																														case 40:
																														case 43:
																														case 44:
																														case 59:
																														case 66:
																														case 68:
																														case 69:
																														case 73:
																														case 75:
																														case 87:
																														case 96:
																														case 102:
																														case 107:
																														case 117:
																														case 120:
																														case 122:
																														case 127:
																														case 145:
																														case 153:
																														case 207:
																														case 224:
																														case 226:
																														case 231:
																														case 236:
																														case 238:
																														case 240:
																														case 247:
																														case 255:
																														case 257:
																														case 261:
																														case 266:
																														case 268:
																														case 271:
																														case 289:
																														case 290:
																														case 303:
																														case 315:
																														case 318:
																														case 325:
																														case 335:
																															goto end_IL_05c5_2;
																														case 7:
																														case 36:
																														case 39:
																														case 62:
																														case 77:
																														case 97:
																														case 104:
																														case 112:
																														case 119:
																														case 126:
																														case 130:
																														case 131:
																														case 133:
																														case 140:
																														case 148:
																														case 157:
																														case 158:
																														case 163:
																														case 172:
																														case 182:
																														case 195:
																														case 197:
																														case 204:
																														case 206:
																														case 208:
																														case 209:
																														case 210:
																														case 227:
																														case 229:
																														case 230:
																														case 237:
																														case 239:
																														case 260:
																														case 269:
																														case 270:
																														case 277:
																														case 288:
																														case 292:
																														case 306:
																														case 308:
																														case 326:
																														case 331:
																														case 333:
																															goto IL_17c0_2;
																														case 322:
																															ptr2 = ptr;
																															goto IL_17c0_2;
																														case 275:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComposedOfNoPublicMembersAddEventHandler.IsWellKnownBeginRead);
																															goto case 322;
																														case 189:
																															array7 = new object[11];
																															goto case 275;
																														case 99:
																															array6 = new long[4];
																															goto case 189;
																														case 298:
																															array5 = new int[7];
																															goto case 99;
																														case 304:
																															array4 = new int[4];
																															goto case 298;
																														case 100:
																															array3 = new object[4];
																															num = 304;
																															goto case 304;
																														case 37:
																															array2 = new byte[4];
																															goto case 100;
																														case 95:
																															num4 = num2 * 8;
																															goto case 37;
																														case 21:
																															num3 = num2 * 4;
																															goto case 95;
																														case 220:
																															num2 = 1;
																															goto case 21;
																														case 221:
																															goto end_IL_146c;
																														case 31:
																														case 177:
																															return;
																														}
																														continue;
																													}
																													array2[num6 - 2] = 3;
																													num = 312;
																													goto IL_0a07_2;
																													IL_0a07_2:
																													num6--;
																													goto IL_17c0_2;
																													continue;
																													end_IL_0567_2:
																													break;
																												}
																												break;
																											}
																											goto IL_10b2_2;
																											continue;
																											end_IL_05c5_2:
																											break;
																											IL_05c5_2:;
																										}
																										break;
																									}
																									goto IL_0a1a_2;
																									IL_0a89_2:
																									ptr2 += 8;
																									goto IL_17c0_2;
																									IL_0a1a_2:
																									if (29 < b)
																									{
																										break;
																									}
																									goto IL_0a28_2;
																									IL_0a28_2:
																									if (29 > b)
																									{
																										break;
																									}
																									goto IL_0a36_2;
																									IL_0a36_2:
																									array2[num6 - 1] = 0;
																									goto IL_0a4a_2;
																									IL_0a4a_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0a89_2;
																								}
																								break;
																							}
																							goto IL_066a_2;
																							IL_073c_2:
																							num6--;
																							goto IL_17c0_2;
																							IL_066a_2:
																							if (27 > b)
																							{
																								goto IL_069c_2;
																							}
																							goto IL_06db_2;
																							IL_06db_2:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_06f4_2;
																							IL_06f4_2:
																							array2[num6] = 3;
																							goto IL_0702_2;
																							IL_0702_2:
																							num6++;
																							goto IL_0710_2;
																							IL_0710_2:
																							ptr2 += 16;
																							goto IL_17c0_2;
																							IL_069c_2:
																							if (26 < b)
																							{
																								break;
																							}
																							goto IL_06aa_2;
																							IL_06aa_2:
																							if (26 > b)
																							{
																								break;
																							}
																							goto IL_0723_2;
																							IL_0723_2:
																							global::_003CModule_003E.tracerOption_0 = (TracerOption)array3[num6 - 1];
																							goto IL_073c_2;
																						}
																						break;
																					}
																					goto IL_074f_2;
																					IL_07fa_2:
																					array3[num6 - 2] = ((TracerOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					num = 286;
																					goto IL_08c9_2;
																					IL_074f_2:
																					if (25 > b)
																					{
																						goto IL_075d_2;
																					}
																					goto IL_07fa_2;
																					IL_075d_2:
																					if (22 >= b)
																					{
																						goto IL_0768_2;
																					}
																					goto IL_077b_2;
																					IL_0768_2:
																					if (22 > b)
																					{
																						goto IL_0845_2;
																					}
																					goto IL_0903_2;
																					IL_0903_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0955_2;
																					IL_0955_2:
																					num6--;
																					goto IL_17c0_2;
																					IL_0845_2:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_0853_2;
																					IL_0853_2:
																					if (21 > b)
																					{
																						break;
																					}
																					goto IL_0861_2;
																					IL_0861_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																					goto IL_08a2_2;
																					IL_08a2_2:
																					array2[num6 - 2] = 0;
																					goto IL_08b6_2;
																					IL_08b6_2:
																					num6--;
																					goto IL_17c0_2;
																					IL_077b_2:
																					if (23 >= b)
																					{
																						num = 152;
																						goto IL_0792_2;
																					}
																					goto IL_0968_2;
																					IL_08c9_2:
																					array2[num6 - 2] = 4;
																					goto IL_08dd_2;
																					IL_0792_2:
																					if (23 > b)
																					{
																						break;
																					}
																					num = 98;
																					goto IL_07a9_2;
																					IL_08dd_2:
																					num6--;
																					goto IL_17c0_2;
																					IL_07a9_2:
																					array3[num6] = ((delegate*<TracerOption[]>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																					num = 219;
																					goto IL_07d0_2;
																					IL_07d0_2:
																					array2[num6] = 5;
																					num = 105;
																					goto IL_07e7_2;
																					IL_07e7_2:
																					num6++;
																					goto IL_08f0_2;
																					IL_08f0_2:
																					ptr2 += 8;
																					goto IL_17c0_2;
																					IL_0968_2:
																					if (24 < b)
																					{
																						break;
																					}
																					goto IL_0976_2;
																					IL_0976_2:
																					if (24 > b)
																					{
																						break;
																					}
																					goto IL_0984_2;
																					IL_0984_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																					goto IL_09a8_2;
																					IL_09a8_2:
																					array2[num6] = 0;
																					goto IL_09b6_2;
																					IL_09b6_2:
																					num6++;
																					goto IL_09c4_2;
																					IL_09c4_2:
																					ptr2 += 8;
																					goto IL_17c0_2;
																				}
																				break;
																			}
																			goto IL_0677_2;
																			IL_09d7_2:
																			ptr2 += 8;
																			goto IL_17c0_2;
																			IL_0677_2:
																			array3[num6] = ((delegate*<TracerOption>)SymbolTypeCFB[*(int*)(ptr2 + num3)])();
																			goto IL_06ba_2;
																			IL_06ba_2:
																			array2[num6] = 4;
																			goto IL_06c8_2;
																			IL_06c8_2:
																			num6++;
																			goto IL_09d7_2;
																		}
																		break;
																	}
																	goto IL_0a9c_2;
																	IL_0e8f_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto IL_17c0_2;
																	IL_0a9c_2:
																	if (35 >= b)
																	{
																		goto IL_0aaa_2;
																	}
																	goto IL_0d34_2;
																	IL_0aaa_2:
																	if (35 > b)
																	{
																		goto IL_0ab8_2;
																	}
																	num = 320;
																	goto IL_0ccd_2;
																	IL_0ab8_2:
																	if (32 >= b)
																	{
																		goto IL_0ac6_2;
																	}
																	goto IL_0bcd_2;
																	IL_0ac6_2:
																	if (32 > b)
																	{
																		goto IL_0ad1_2;
																	}
																	goto IL_0b4c_2;
																	IL_0ad1_2:
																	if (31 < b)
																	{
																		break;
																	}
																	goto IL_0adf_2;
																	IL_0adf_2:
																	if (31 > b)
																	{
																		break;
																	}
																	goto IL_0aed_2;
																	IL_0aed_2:
																	array3[num6 - 1] = ((delegate*<TracerOption, string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																	goto IL_0b25_2;
																	IL_0b25_2:
																	array2[num6 - 1] = 5;
																	goto IL_0b39_2;
																	IL_0b39_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0b4c_2:
																	array2[num6 - 2] = 5;
																	goto IL_0b60_2;
																	IL_0b60_2:
																	array3[num6 - 2] = ((delegate*<string, string, string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																	goto IL_0bac_2;
																	IL_0bac_2:
																	num6--;
																	goto IL_0bba_2;
																	IL_0bba_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0bcd_2:
																	if (33 >= b)
																	{
																		goto IL_0bd8_2;
																	}
																	goto IL_0c39_2;
																	IL_0bd8_2:
																	if (33 > b)
																	{
																		break;
																	}
																	goto IL_0be6_2;
																	IL_0be6_2:
																	((delegate*<string, void>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																	num = 52;
																	goto IL_0c18_2;
																	IL_0c18_2:
																	num6--;
																	goto IL_0c26_2;
																	IL_0c26_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0c39_2:
																	if (34 < b)
																	{
																		break;
																	}
																	goto IL_0c47_2;
																	IL_0c47_2:
																	if (34 > b)
																	{
																		break;
																	}
																	num = 3;
																	goto IL_0c5e_2;
																	IL_0eb9_2:
																	if (40 > b)
																	{
																	}
																	break;
																	IL_0c5e_2:
																	array2[num6 - 1] = 3;
																	goto IL_0c72_2;
																	IL_0c72_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0cb1_2;
																	IL_0cb1_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0eab_2:
																	if (40 < b)
																	{
																		break;
																	}
																	goto IL_0eb9_2;
																	IL_0ccd_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0d0d_2;
																	IL_0d0d_2:
																	array2[num6 - 2] = 3;
																	goto IL_0d21_2;
																	IL_0d21_2:
																	num6--;
																	goto IL_17c0_2;
																	IL_0d34_2:
																	if (38 >= b)
																	{
																		goto IL_0d42_2;
																	}
																	goto IL_0e76_2;
																	IL_0d42_2:
																	if (38 <= b)
																	{
																		goto IL_0d4d_2;
																	}
																	goto IL_0d91_2;
																	IL_0d4d_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0d78_2;
																	IL_0d78_2:
																	array2[num6 - 1] = 0;
																	goto IL_17c0_2;
																	IL_0d91_2:
																	if (36 >= b)
																	{
																		goto IL_0d9c_2;
																	}
																	goto IL_0e0f_2;
																	IL_0d9c_2:
																	if (36 > b)
																	{
																		break;
																	}
																	goto IL_0daa_2;
																	IL_0daa_2:
																	*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<TracerOption, Class8.TracerStyle>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																	goto IL_0de8_2;
																	IL_0de8_2:
																	array2[num6 - 1] = 0;
																	goto IL_0dfc_2;
																	IL_0dfc_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0e0f_2:
																	if (37 < b)
																	{
																		break;
																	}
																	goto IL_0e1d_2;
																	IL_0e1d_2:
																	if (37 > b)
																	{
																		break;
																	}
																	goto IL_0e2b_2;
																	IL_0e2b_2:
																	((delegate*<Class8.TracerStyle, void>)SymbolTypeCFB[*(int*)(ptr2 + num3)])(*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0e55_2;
																	IL_0e55_2:
																	num6--;
																	goto IL_0e63_2;
																	IL_0e63_2:
																	ptr2 += 8;
																	goto IL_17c0_2;
																	IL_0e76_2:
																	if (39 >= b)
																	{
																		goto IL_0e81_2;
																	}
																	goto IL_0eab_2;
																	IL_0e81_2:
																	if (39 > b)
																	{
																		break;
																	}
																	goto IL_0e8f_2;
																}
																break;
															}
															goto IL_0ecc_2;
															IL_1778_2:
															array2[num6] = 1;
															goto IL_1786_2;
															IL_0ecc_2:
															if (20 <= b)
															{
																goto IL_0ed7_2;
															}
															goto IL_0eef_2;
															IL_0ed7_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_17c0_2;
															IL_0eef_2:
															if (10 >= b)
															{
																goto IL_0efd_2;
															}
															goto IL_1389_2;
															IL_0efd_2:
															if (10 <= b)
															{
																goto IL_0f08_2;
															}
															goto IL_0f7d_2;
															IL_0f08_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0f6a_2;
															IL_0f6a_2:
															num6 -= 2;
															goto IL_17c0_2;
															IL_0f7d_2:
															if (5 >= b)
															{
																goto IL_0f8b_2;
															}
															goto IL_11ce_2;
															IL_0f8b_2:
															if (5 <= b)
															{
																goto IL_0f96_2;
															}
															goto IL_0ffd_2;
															IL_0f96_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0fd6_2;
															IL_0fd6_2:
															array2[num6 - 2] = 0;
															goto IL_0fea_2;
															IL_0fea_2:
															num6--;
															goto IL_17c0_2;
															IL_0ffd_2:
															if (2 >= b)
															{
																goto IL_100b_2;
															}
															goto IL_10e1_2;
															IL_100b_2:
															if (2 <= b)
															{
																goto IL_1016_2;
															}
															goto IL_107d_2;
															IL_1016_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1056_2;
															IL_1056_2:
															array2[num6 - 2] = 0;
															goto IL_106a_2;
															IL_106a_2:
															num6--;
															goto IL_17c0_2;
															IL_107d_2:
															if (1 < b)
															{
																break;
															}
															goto IL_108b_2;
															IL_108b_2:
															if (1 > b)
															{
																break;
															}
															goto IL_1099_2;
															IL_1099_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_10b2_2;
															IL_10b2_2:
															array2[num6] = 0;
															goto IL_10c0_2;
															IL_10c0_2:
															num6++;
															goto IL_10ce_2;
															IL_10ce_2:
															ptr2 += 8;
															goto IL_17c0_2;
															IL_10e1_2:
															if (3 >= b)
															{
																goto IL_10ec_2;
															}
															goto IL_114d_2;
															IL_10ec_2:
															if (3 > b)
															{
																break;
															}
															goto IL_10fa_2;
															IL_10fa_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 67;
															goto IL_112c_2;
															IL_112c_2:
															ptr2 += 8;
															goto IL_113a_2;
															IL_113a_2:
															num6--;
															goto IL_17c0_2;
															IL_114d_2:
															if (4 < b)
															{
																break;
															}
															goto IL_115b_2;
															IL_115b_2:
															if (4 > b)
															{
																break;
															}
															num = 283;
															goto IL_1172_2;
															IL_1786_2:
															num6++;
															num = 203;
															goto IL_179d_2;
															IL_1172_2:
															array2[num6] = 0;
															goto IL_1180_2;
															IL_1180_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_11a3_2;
															IL_11a3_2:
															array3[num6] = null;
															goto IL_11ad_2;
															IL_11ad_2:
															num6++;
															goto IL_11bb_2;
															IL_11bb_2:
															ptr2 += 8;
															goto IL_17c0_2;
															IL_11ce_2:
															if (7 >= b)
															{
																goto IL_11dc_2;
															}
															goto IL_12d1_2;
															IL_11dc_2:
															if (7 <= b)
															{
																goto IL_11e7_2;
															}
															goto IL_124e_2;
															IL_11e7_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1227_2;
															IL_1227_2:
															array2[num6 - 2] = 0;
															goto IL_123b_2;
															IL_123b_2:
															num6--;
															goto IL_17c0_2;
															IL_124e_2:
															if (6 < b)
															{
																break;
															}
															goto IL_125c_2;
															IL_125c_2:
															if (6 > b)
															{
																break;
															}
															goto IL_126a_2;
															IL_126a_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_12aa_2;
															IL_12aa_2:
															array2[num6 - 2] = 0;
															goto IL_12be_2;
															IL_12be_2:
															num6--;
															goto IL_17c0_2;
															IL_12d1_2:
															if (8 >= b)
															{
																goto IL_12dc_2;
															}
															goto IL_12fd_2;
															IL_12dc_2:
															if (8 > b)
															{
																break;
															}
															goto IL_12ea_2;
															IL_12ea_2:
															num6--;
															goto IL_17c0_2;
															IL_12fd_2:
															if (9 < b)
															{
																break;
															}
															goto IL_130b_2;
															IL_130b_2:
															if (9 > b)
															{
																break;
															}
															goto IL_1319_2;
															IL_1319_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1359_2;
															IL_1359_2:
															array2[num6 - 2] = 0;
															goto IL_136d_2;
															IL_136d_2:
															num6--;
															num = 269;
															goto IL_17c0_2;
															IL_1389_2:
															if (15 >= b)
															{
																goto IL_1397_2;
															}
															goto IL_15fe_2;
															IL_1397_2:
															if (15 <= b)
															{
																goto IL_13a5_2;
															}
															goto IL_1433_2;
															IL_13a5_2:
															array2[num6] = array2[num6 - 1];
															goto IL_13bd_2;
															IL_13bd_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_13db_2;
															IL_13db_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_13ff_2;
															IL_13ff_2:
															array3[num6] = array3[num6 - 1];
															goto IL_1417_2;
															IL_1417_2:
															num6++;
															num = 163;
															goto IL_17c0_2;
															IL_1433_2:
															if (12 >= b)
															{
																goto IL_1441_2;
															}
															goto IL_1548_2;
															IL_1441_2:
															if (12 <= b)
															{
																goto end_IL_065f;
															}
															goto IL_1527_2;
															IL_1527_2:
															if (11 < b)
															{
																break;
															}
															goto IL_1535_2;
															IL_1535_2:
															if (11 > b)
															{
																break;
															}
															goto IL_17c0_2;
															IL_1548_2:
															if (13 >= b)
															{
																goto IL_1553_2;
															}
															goto IL_15a0_2;
															IL_1553_2:
															if (13 > b)
															{
																break;
															}
															goto IL_1561_2;
															IL_1561_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_157f_2;
															IL_157f_2:
															ptr2 += 8;
															goto IL_158d_2;
															IL_158d_2:
															num6--;
															goto IL_17c0_2;
															IL_15a0_2:
															if (14 < b)
															{
																break;
															}
															goto IL_15ae_2;
															IL_15ae_2:
															if (14 > b)
															{
																break;
															}
															goto IL_15bc_2;
															IL_15bc_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_15e5_2;
															IL_15e5_2:
															array2[num6 - 1] = 5;
															goto IL_17c0_2;
															IL_15fe_2:
															if (17 >= b)
															{
																goto IL_160c_2;
															}
															goto IL_16cb_2;
															IL_160c_2:
															if (17 <= b)
															{
																goto IL_1617_2;
															}
															goto IL_1668_2;
															IL_1617_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_1655_2;
															IL_1655_2:
															num6 -= 3;
															goto IL_17c0_2;
															IL_1668_2:
															if (16 < b)
															{
																break;
															}
															goto IL_1676_2;
															IL_1676_2:
															if (16 > b)
															{
																break;
															}
															goto IL_1684_2;
															IL_1684_2:
															array2[num6] = 5;
															goto IL_1692_2;
															IL_1692_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_16aa_2;
															IL_16aa_2:
															num6++;
															goto IL_16b8_2;
															IL_16b8_2:
															ptr2 += 8;
															goto IL_17c0_2;
															IL_16cb_2:
															if (18 >= b)
															{
																goto IL_16d6_2;
															}
															goto IL_1749_2;
															IL_16d6_2:
															if (18 > b)
															{
																break;
															}
															num = 321;
															goto IL_16ed_2;
															IL_179d_2:
															ptr2 += 16;
															goto IL_17c0_2;
															IL_16ed_2:
															array2[num6 - 1] = 5;
															goto IL_1701_2;
															IL_1701_2:
															array3[num6 - 1] = ((delegate*<string[], string>)SymbolTypeCFB[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															goto IL_1739_2;
															IL_1739_2:
															ptr2 += 8;
															goto IL_17c0_2;
															IL_1749_2:
															if (19 < b)
															{
																break;
															}
															goto IL_1754_2;
															IL_1754_2:
															if (19 > b)
															{
																break;
															}
															goto IL_175f_2;
															IL_175f_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_1778_2;
														}
														break;
														IL_062f_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_17c0_2;
												continue;
												end_IL_063f_2:
												break;
											}
											continue;
											end_IL_064f:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									break;
								}
								num = 31;
								return;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_145e_2;
					}
					continue;
					end_IL_146c:
					break;
				}
				break;
			}
		}
	}

	public unsafe static void smethod_0()
	{
		//The blocks IL_000e, IL_001e, IL_058b, IL_059e, IL_05c1, IL_05e7, IL_0607, IL_0621, IL_0631, IL_0641, IL_064e, IL_065e, IL_066e, IL_067e, IL_068e, IL_069e, IL_06a9, IL_06b4, IL_06c2, IL_06cd, IL_06e0, IL_06ee, IL_0701, IL_0763, IL_0776, IL_07bb, IL_07c9, IL_07d2, IL_0812, IL_0826, IL_0839, IL_0844, IL_084f, IL_085d, IL_0870, IL_087e, IL_089c, IL_08aa, IL_08bd, IL_08c8, IL_08db, IL_08f8, IL_0947, IL_0951, IL_097e, IL_0997, IL_09a5, IL_09b0, IL_09be, IL_09f5, IL_0a03, IL_0a11, IL_0a1f, IL_0a42, IL_0a4c, IL_0a5a, IL_0a6d, IL_0a7d, IL_0a8b, IL_0a9e, IL_0ab1, IL_0abf, IL_0ad2, IL_0ae5, IL_0af3, IL_0b01, IL_0b41, IL_0b55, IL_0b68, IL_0b91, IL_0baa, IL_0bbe, IL_0bda, IL_0be8, IL_0c28, IL_0c3c, IL_0c4f, IL_0c5a, IL_0c9a, IL_0cae, IL_0cc1, IL_0ccf, IL_0cdd, IL_0ce6, IL_0cff, IL_0d0d, IL_0d1b, IL_0d2e, IL_0d41, IL_0d4f, IL_0d5a, IL_0d68, IL_0d76, IL_0d8e, IL_0d97, IL_0da5, IL_0dbe, IL_0dcc, IL_0de3, IL_0df6, IL_0e04, IL_0e0f, IL_0e1d, IL_0e2b, IL_0e43, IL_0e51, IL_0e64, IL_0e72, IL_0e80, IL_0ebe, IL_0ed1, IL_0eda, IL_0eee, IL_0f2f, IL_0f42, IL_0f83, IL_0f97, IL_0faa, IL_0fb8, IL_0fc3, IL_0fcc, IL_0fef, IL_0ffd, IL_100b, IL_101e, IL_102c, IL_1037, IL_1050, IL_1063, IL_1071, IL_107f, IL_108d, IL_109b, IL_10a4, IL_10e1, IL_10f5, IL_1108, IL_1116, IL_1143, IL_1151, IL_115f, IL_1172, IL_117d, IL_119b, IL_11b2, IL_11c0, IL_11d3, IL_11e1, IL_11ef, IL_1241, IL_1254, IL_1262, IL_126d, IL_1281, IL_12c0, IL_12d3, IL_12e1, IL_12ef, IL_1308, IL_1316, IL_1324, IL_1340, IL_134b, IL_1359, IL_1399, IL_13ad, IL_13c0, IL_13ce, IL_13dc, IL_13f0, IL_142f, IL_144b, IL_1459, IL_1467, IL_147b, IL_14d0, IL_14de, IL_14f1, IL_14ff, IL_150a, IL_1534, IL_1542, IL_155e, IL_156c, IL_157a, IL_15b8, IL_15cc, IL_15e8, IL_15f3, IL_1601, IL_160f, IL_1647, IL_165b, IL_166e, IL_167c, IL_1690, IL_16d8, IL_16eb, IL_16f9, IL_1704, IL_1744, IL_1758, IL_176b, IL_1776, IL_1784, IL_17ad, IL_17bb, IL_17ce, IL_17dc, IL_17ea, IL_17fe, IL_1846, IL_1856, IL_1861, IL_186c, IL_1885, IL_1890, IL_1899, IL_18a4, IL_18b7, IL_18ca, IL_18d4, IL_18df, IL_18ef, IL_18ff, IL_190f, IL_191f, IL_192f, IL_193f, IL_194f, IL_195f are reachable both inside and outside the pinned region starting at IL_1974. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 123;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef45 = default(int);
			ref int reference = ref __rxRef45;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_195f:
					num2 = 1;
					while (true)
					{
						IL_194f:
						num3 = num2 * 4;
						while (true)
						{
							IL_193f:
							num4 = num2 * 8;
							while (true)
							{
								IL_192f:
								array2 = new byte[4];
								while (true)
								{
									IL_191f:
									array3 = new object[4];
									while (true)
									{
										IL_190f:
										array4 = new int[4];
										while (true)
										{
											IL_18ff:
											array5 = new int[7];
											while (true)
											{
												IL_18ef:
												array6 = new long[4];
												while (true)
												{
													IL_18df:
													array7 = new object[11];
													while (true)
													{
														IL_18d4:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenizerStringBlockgetExceptionMessage.MatchAllVersionsISTOREBINDREFERENCETOASSEMBLYFLAGS);
														while (true)
														{
															IL_18ca:
															ptr2 = ptr;
															while (true)
															{
																IL_18b7:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_069e:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_068e:
																		ptr2++;
																		while (true)
																		{
																			IL_067e:
																			if (b >= 1)
																			{
																				while (b <= 41)
																				{
																					while (true)
																					{
																						IL_065e:
																						if (21 >= b)
																						{
																							while (true)
																							{
																								IL_064e:
																								if (21 > b)
																								{
																									while (true)
																									{
																										IL_0641:
																										if (10 < b)
																										{
																											while (true)
																											{
																												IL_0631:
																												if (15 >= b)
																												{
																													while (true)
																													{
																														IL_0621:
																														if (15 <= b)
																														{
																															while (true)
																															{
																																IL_0607:
																																array2[num6] = array2[num6 - 1];
																																while (true)
																																{
																																	IL_05e7:
																																	array4[num6 - 0] = array4[num6 - 1];
																																	while (true)
																																	{
																																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		while (true)
																																		{
																																			IL_059e:
																																			array3[num6] = array3[num6 - 1];
																																			num = 351;
																																			while (true)
																																			{
																																				if (num != 351)
																																				{
																																					if (num != 1332)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 123:
																																						break;
																																					default:
																																						continue;
																																					case 198:
																																						goto IL_059e;
																																					case 2:
																																						goto end_IL_058b;
																																					case 258:
																																						goto IL_05e7;
																																					case 105:
																																					case 214:
																																						goto IL_0607;
																																					case 110:
																																						goto IL_0621;
																																					case 286:
																																						goto IL_0631;
																																					case 191:
																																						goto IL_0641;
																																					case 79:
																																						goto IL_064e;
																																					case 66:
																																						goto IL_065e;
																																					case 263:
																																						goto IL_066e;
																																					case 193:
																																						goto IL_067e;
																																					case 241:
																																						goto IL_068e;
																																					case 227:
																																					case 260:
																																						goto IL_069e;
																																					case 166:
																																						goto IL_06a9;
																																					case 20:
																																						goto IL_06b4;
																																					case 52:
																																						goto IL_06c2;
																																					case 158:
																																						goto IL_06cd;
																																					case 143:
																																						goto IL_06e0;
																																					case 51:
																																						goto IL_06ee;
																																					case 13:
																																					case 155:
																																						goto IL_0701;
																																					case 26:
																																						goto IL_0763;
																																					case 87:
																																					case 180:
																																						goto IL_0776;
																																					case 204:
																																						goto IL_07bb;
																																					case 100:
																																					case 138:
																																						goto IL_07d2;
																																					case 246:
																																						goto IL_0812;
																																					case 150:
																																						goto IL_0826;
																																					case 262:
																																						goto IL_0839;
																																					case 47:
																																						goto IL_0844;
																																					case 127:
																																						goto IL_084f;
																																					case 113:
																																						goto IL_085d;
																																					case 199:
																																						goto IL_0870;
																																					case 50:
																																					case 101:
																																						goto IL_087e;
																																					case 104:
																																						goto IL_089c;
																																					case 69:
																																						goto IL_08aa;
																																					case 273:
																																						goto IL_08bd;
																																					case 170:
																																						goto IL_08c8;
																																					case 135:
																																					case 253:
																																						goto IL_08db;
																																					case 295:
																																						goto IL_0997;
																																					case 238:
																																						goto IL_09a5;
																																					case 244:
																																						goto IL_09b0;
																																					case 133:
																																					case 144:
																																						goto IL_09be;
																																					case 73:
																																						goto IL_09f5;
																																					case 196:
																																						goto IL_0a03;
																																					case 61:
																																					case 134:
																																						goto IL_0a11;
																																					case 189:
																																						goto IL_0a1f;
																																					case 84:
																																						goto IL_0a42;
																																					case 211:
																																						goto IL_0a4c;
																																					case 30:
																																						goto IL_0a5a;
																																					case 302:
																																						goto IL_0a6d;
																																					case 307:
																																						goto IL_0a7d;
																																					case 197:
																																						goto IL_0a8b;
																																					case 99:
																																					case 311:
																																						goto IL_0a9e;
																																					case 313:
																																						goto IL_0ab1;
																																					case 128:
																																						goto IL_0abf;
																																					case 321:
																																						goto IL_0ad2;
																																					case 330:
																																						goto IL_0ae5;
																																					case 9:
																																						goto IL_0af3;
																																					case 77:
																																					case 264:
																																						goto IL_0b01;
																																					case 25:
																																						goto IL_0b41;
																																					case 322:
																																						goto IL_0b55;
																																					case 16:
																																					case 332:
																																						goto IL_0b68;
																																					case 82:
																																						goto IL_0b91;
																																					case 334:
																																						goto IL_0baa;
																																					case 251:
																																						goto IL_0bbe;
																																					case 335:
																																						goto IL_0bda;
																																					case 27:
																																					case 269:
																																						goto IL_0be8;
																																					case 216:
																																						goto IL_0c28;
																																					case 276:
																																						goto IL_0c3c;
																																					case 339:
																																						goto IL_0c4f;
																																					case 93:
																																					case 304:
																																						goto IL_0c5a;
																																					case 60:
																																						goto IL_0c9a;
																																					case 296:
																																						goto IL_0cae;
																																					case 233:
																																						goto IL_0cc1;
																																					case 90:
																																						goto IL_0ccf;
																																					case 147:
																																					case 160:
																																						goto IL_0ce6;
																																					case 86:
																																						goto IL_0cff;
																																					case 109:
																																						goto IL_0d0d;
																																					case 248:
																																						goto IL_0d1b;
																																					case 5:
																																						goto IL_0d41;
																																					case 80:
																																						goto IL_0d4f;
																																					case 136:
																																						goto IL_0d5a;
																																					case 72:
																																						goto IL_0d68;
																																					case 242:
																																					case 328:
																																						goto IL_0d76;
																																					case 343:
																																						goto IL_0d97;
																																					case 18:
																																					case 208:
																																						goto IL_0da5;
																																					case 10:
																																						goto IL_0dbe;
																																					case 17:
																																						goto IL_0dcc;
																																					case 237:
																																						goto IL_0de3;
																																					case 270:
																																						goto IL_0df6;
																																					case 188:
																																						goto IL_0e04;
																																					case 81:
																																						goto IL_0e0f;
																																					case 67:
																																					case 126:
																																						goto IL_0e1d;
																																					case 165:
																																						goto IL_0e2b;
																																					case 288:
																																						goto IL_0e43;
																																					case 218:
																																						goto IL_0e51;
																																					case 327:
																																						goto IL_0e64;
																																					case 259:
																																						goto IL_0e72;
																																					case 129:
																																					case 294:
																																						goto IL_0e80;
																																					case 239:
																																						goto IL_0ebe;
																																					case 124:
																																					case 326:
																																						goto IL_0eda;
																																					case 300:
																																						goto IL_0eee;
																																					case 12:
																																						goto IL_0f2f;
																																					case 108:
																																					case 220:
																																						goto IL_0f42;
																																					case 92:
																																						goto IL_0f83;
																																					case 229:
																																						goto IL_0f97;
																																					case 120:
																																						goto IL_0faa;
																																					case 54:
																																						goto IL_0fb8;
																																					case 42:
																																					case 219:
																																						goto IL_0fcc;
																																					case 257:
																																						goto IL_0fef;
																																					case 324:
																																						goto IL_0ffd;
																																					case 149:
																																						goto IL_100b;
																																					case 19:
																																						goto IL_101e;
																																					case 88:
																																						goto IL_102c;
																																					case 223:
																																					case 256:
																																						goto IL_1037;
																																					case 225:
																																						goto IL_1050;
																																					case 283:
																																						goto IL_1063;
																																					case 1:
																																						goto IL_1071;
																																					case 172:
																																						goto IL_107f;
																																					case 272:
																																						goto IL_108d;
																																					case 74:
																																					case 119:
																																						goto IL_10a4;
																																					case 102:
																																						goto IL_10e1;
																																					case 32:
																																						goto IL_10f5;
																																					case 38:
																																						goto IL_1108;
																																					case 56:
																																					case 115:
																																						goto IL_1116;
																																					case 314:
																																						goto IL_1143;
																																					case 121:
																																						goto IL_1151;
																																					case 252:
																																						goto IL_115f;
																																					case 331:
																																						goto IL_1172;
																																					case 4:
																																					case 278:
																																						goto IL_117d;
																																					case 325:
																																						goto IL_119b;
																																					case 309:
																																						goto IL_11b2;
																																					case 284:
																																						goto IL_11c0;
																																					case 190:
																																						goto IL_11d3;
																																					case 64:
																																						goto IL_11e1;
																																					case 48:
																																					case 106:
																																						goto IL_11ef;
																																					case 125:
																																						goto IL_1241;
																																					case 7:
																																						goto IL_1254;
																																					case 236:
																																						goto IL_1262;
																																					case 62:
																																					case 222:
																																						goto IL_126d;
																																					case 210:
																																						goto IL_1281;
																																					case 202:
																																						goto IL_12c0;
																																					case 139:
																																						goto IL_12d3;
																																					case 167:
																																						goto IL_12e1;
																																					case 96:
																																					case 185:
																																						goto IL_12ef;
																																					case 145:
																																						goto IL_1308;
																																					case 271:
																																						goto IL_1316;
																																					case 76:
																																						goto IL_1324;
																																					case 168:
																																						goto IL_1340;
																																					case 338:
																																						goto IL_134b;
																																					case 31:
																																					case 65:
																																						goto IL_1359;
																																					case 117:
																																						goto IL_1399;
																																					case 0:
																																						goto IL_13ad;
																																					case 230:
																																						goto IL_13c0;
																																					case 85:
																																						goto IL_13ce;
																																					case 164:
																																					case 231:
																																						goto IL_13dc;
																																					case 279:
																																						goto IL_13f0;
																																					case 70:
																																						goto IL_142f;
																																					case 186:
																																						goto IL_144b;
																																					case 55:
																																						goto IL_1459;
																																					case 63:
																																					case 161:
																																						goto IL_1467;
																																					case 45:
																																						goto IL_147b;
																																					case 34:
																																						goto IL_14d0;
																																					case 94:
																																						goto IL_14de;
																																					case 275:
																																						goto IL_14f1;
																																					case 35:
																																						goto IL_14ff;
																																					case 266:
																																					case 342:
																																						goto IL_150a;
																																					case 36:
																																						goto IL_1534;
																																					case 118:
																																						goto IL_1542;
																																					case 316:
																																						goto IL_155e;
																																					case 306:
																																						goto IL_156c;
																																					case 41:
																																					case 312:
																																						goto IL_157a;
																																					case 178:
																																						goto IL_15b8;
																																					case 181:
																																						goto IL_15cc;
																																					case 46:
																																						goto IL_15e8;
																																					case 290:
																																						goto IL_15f3;
																																					case 107:
																																						goto IL_1601;
																																					case 14:
																																					case 213:
																																						goto IL_160f;
																																					case 247:
																																						goto IL_1647;
																																					case 175:
																																						goto IL_165b;
																																					case 153:
																																						goto IL_166e;
																																					case 15:
																																					case 333:
																																						goto IL_167c;
																																					case 336:
																																						goto IL_1690;
																																					case 291:
																																						goto IL_16d8;
																																					case 310:
																																						goto IL_16eb;
																																					case 217:
																																						goto IL_16f9;
																																					case 305:
																																					case 320:
																																						goto IL_1704;
																																					case 249:
																																						goto IL_1744;
																																					case 232:
																																						goto IL_1758;
																																					case 344:
																																						goto IL_176b;
																																					case 49:
																																						goto IL_1776;
																																					case 169:
																																					case 226:
																																						goto IL_1784;
																																					case 24:
																																						goto IL_17ad;
																																					case 254:
																																						goto IL_17bb;
																																					case 268:
																																						goto IL_17ce;
																																					case 293:
																																						goto IL_17dc;
																																					case 53:
																																					case 159:
																																						goto IL_17ea;
																																					case 111:
																																						goto IL_17fe;
																																					case 116:
																																						goto IL_1846;
																																					case 315:
																																						goto IL_1856;
																																					case 301:
																																						goto IL_1861;
																																					case 215:
																																					case 282:
																																						goto IL_186c;
																																					case 298:
																																						goto IL_1885;
																																					case 57:
																																						goto IL_1899;
																																					case 6:
																																					case 8:
																																					case 11:
																																					case 21:
																																					case 22:
																																					case 29:
																																					case 37:
																																					case 39:
																																					case 43:
																																					case 44:
																																					case 68:
																																					case 71:
																																					case 75:
																																					case 83:
																																					case 95:
																																					case 142:
																																					case 146:
																																					case 152:
																																					case 154:
																																					case 157:
																																					case 162:
																																					case 163:
																																					case 176:
																																					case 179:
																																					case 183:
																																					case 192:
																																					case 194:
																																					case 195:
																																					case 200:
																																					case 221:
																																					case 234:
																																					case 235:
																																					case 240:
																																					case 245:
																																					case 250:
																																					case 267:
																																					case 274:
																																					case 277:
																																					case 289:
																																					case 292:
																																					case 319:
																																					case 329:
																																					case 340:
																																					case 341:
																																						goto end_IL_066e;
																																					case 3:
																																					case 23:
																																					case 28:
																																					case 33:
																																					case 40:
																																					case 78:
																																					case 89:
																																					case 97:
																																					case 98:
																																					case 103:
																																					case 112:
																																					case 130:
																																					case 131:
																																					case 132:
																																					case 137:
																																					case 140:
																																					case 141:
																																					case 148:
																																					case 151:
																																					case 156:
																																					case 171:
																																					case 174:
																																					case 177:
																																					case 182:
																																					case 184:
																																					case 187:
																																					case 201:
																																					case 203:
																																					case 206:
																																					case 209:
																																					case 212:
																																					case 224:
																																					case 228:
																																					case 243:
																																					case 255:
																																					case 261:
																																					case 287:
																																					case 297:
																																					case 299:
																																					case 303:
																																					case 308:
																																					case 317:
																																					case 318:
																																					case 323:
																																						goto IL_18b7;
																																					case 280:
																																						goto IL_18ca;
																																					case 58:
																																						goto IL_18d4;
																																					case 281:
																																						goto IL_18df;
																																					case 91:
																																						goto IL_18ef;
																																					case 205:
																																						goto IL_18ff;
																																					case 337:
																																						goto IL_190f;
																																					case 285:
																																						goto IL_191f;
																																					case 173:
																																						goto IL_192f;
																																					case 59:
																																						goto IL_193f;
																																					case 114:
																																						goto IL_194f;
																																					case 122:
																																						goto IL_195f;
																																					case 207:
																																					case 265:
																																						return;
																																					}
																																					goto end_IL_05c1;
																																				}
																																				num6++;
																																				goto IL_18b7;
																																				continue;
																																				end_IL_058b:
																																				break;
																																			}
																																			break;
																																		}
																																		continue;
																																		end_IL_05c1:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0839;
																														IL_0a7d:
																														array2[num6] = 5;
																														goto IL_0a8b;
																														IL_0839:
																														if (12 < b)
																														{
																															goto IL_0844;
																														}
																														goto IL_08bd;
																														IL_0844:
																														if (13 < b)
																														{
																															goto IL_084f;
																														}
																														goto IL_0870;
																														IL_084f:
																														if (14 < b)
																														{
																															goto end_IL_066e;
																														}
																														goto IL_085d;
																														IL_085d:
																														if (14 > b)
																														{
																															goto end_IL_066e;
																														}
																														goto IL_0b68;
																														IL_0b68:
																														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														goto IL_0b91;
																														IL_0b91:
																														array2[num6 - 1] = 5;
																														goto IL_18b7;
																														IL_0870:
																														if (13 > b)
																														{
																															goto end_IL_066e;
																														}
																														goto IL_087e;
																														IL_087e:
																														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																														goto IL_089c;
																														IL_089c:
																														ptr2 += 8;
																														goto IL_08aa;
																														IL_08aa:
																														num6--;
																														goto IL_18b7;
																														IL_08bd:
																														if (12 > b)
																														{
																															goto IL_08c8;
																														}
																														goto IL_08db;
																														IL_08c8:
																														if (11 < b)
																														{
																															goto end_IL_066e;
																														}
																														goto IL_0ad2;
																														IL_0ad2:
																														if (11 > b)
																														{
																															goto end_IL_066e;
																														}
																														goto IL_18b7;
																														IL_08db:
																														array8 = array3;
																														num7 = num6;
																														if (array == null)
																														{
																															goto IL_08ea;
																														}
																														num8 = ptr2;
																														byte b2 = *num8;
																														ptr2 = num8 + 4;
																														int num9 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num9;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_0a7d;
																														IL_0a8b:
																														num6++;
																														goto IL_18b7;
																													}
																													break;
																												}
																												goto IL_0d41;
																												IL_0eda:
																												array2[num6 - 1] = 5;
																												goto IL_0eee;
																												IL_0d41:
																												if (18 < b)
																												{
																													goto IL_0d4f;
																												}
																												goto IL_0df6;
																												IL_0d4f:
																												if (19 < b)
																												{
																													goto IL_0d5a;
																												}
																												num = 343;
																												goto IL_0d97;
																												IL_0d5a:
																												if (20 < b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0d68;
																												IL_0d68:
																												if (20 > b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0d76;
																												IL_0d76:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_18b7;
																												IL_0eee:
																												array3[num6 - 1] = ((delegate*<string[], string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																												num = 12;
																												goto IL_0f2f;
																												IL_0d97:
																												if (19 > b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0da5;
																												IL_0da5:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																												goto IL_0dbe;
																												IL_0dbe:
																												array2[num6] = 1;
																												goto IL_0dcc;
																												IL_0dcc:
																												num6++;
																												num = 237;
																												goto IL_0de3;
																												IL_0de3:
																												ptr2 += 16;
																												goto IL_18b7;
																												IL_0df6:
																												if (18 > b)
																												{
																													goto IL_0e04;
																												}
																												num = 326;
																												goto IL_0eda;
																												IL_0e04:
																												if (16 >= b)
																												{
																													goto IL_0e0f;
																												}
																												goto IL_0e64;
																												IL_0e0f:
																												if (16 > b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0e1d;
																												IL_0e1d:
																												array2[num6] = 5;
																												goto IL_0e2b;
																												IL_0e2b:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0e43;
																												IL_0e43:
																												num6++;
																												goto IL_0e51;
																												IL_0e51:
																												ptr2 += 8;
																												goto IL_18b7;
																												IL_0e64:
																												if (17 < b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0e72;
																												IL_0e72:
																												if (17 > b)
																												{
																													goto end_IL_066e;
																												}
																												goto IL_0e80;
																												IL_0e80:
																												((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																												goto IL_0ebe;
																												IL_0ebe:
																												num6 -= 3;
																												goto IL_18b7;
																												IL_0f2f:
																												ptr2 += 8;
																												goto IL_18b7;
																											}
																											break;
																										}
																										goto IL_06a9;
																										IL_0d1b:
																										ptr2 += 8;
																										goto IL_18b7;
																										IL_06a9:
																										if (10 > b)
																										{
																											goto IL_06b4;
																										}
																										goto IL_0701;
																										IL_06b4:
																										if (5 < b)
																										{
																											goto IL_06c2;
																										}
																										goto IL_07bb;
																										IL_06c2:
																										if (7 >= b)
																										{
																											goto IL_06cd;
																										}
																										goto IL_06e0;
																										IL_06cd:
																										if (7 <= b)
																										{
																											goto IL_0776;
																										}
																										goto IL_0ae5;
																										IL_0ae5:
																										if (6 < b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0af3;
																										IL_0af3:
																										if (6 > b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0b01;
																										IL_0b01:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0b41;
																										IL_0b41:
																										array2[num6 - 2] = 0;
																										goto IL_0b55;
																										IL_0b55:
																										num6--;
																										goto IL_18b7;
																										IL_0776:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0baa;
																										IL_0baa:
																										array2[num6 - 2] = 0;
																										goto IL_0bbe;
																										IL_0bbe:
																										num6--;
																										num = 141;
																										goto IL_18b7;
																										IL_06e0:
																										if (8 < b)
																										{
																											goto IL_06ee;
																										}
																										goto IL_0a6d;
																										IL_06ee:
																										if (9 < b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0bda;
																										IL_0bda:
																										if (9 > b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0be8;
																										IL_0be8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0c28;
																										IL_0c28:
																										array2[num6 - 2] = 0;
																										goto IL_0c3c;
																										IL_0c3c:
																										num6--;
																										goto IL_18b7;
																										IL_0a6d:
																										if (8 > b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0a9e;
																										IL_0a9e:
																										num6--;
																										goto IL_18b7;
																										IL_07bb:
																										if (5 <= b)
																										{
																											num = 138;
																											goto IL_07d2;
																										}
																										goto IL_0997;
																										IL_0701:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0763;
																										IL_07d2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0812;
																										IL_0812:
																										array2[num6 - 2] = 0;
																										goto IL_0826;
																										IL_0826:
																										num6--;
																										goto IL_18b7;
																										IL_0997:
																										if (2 < b)
																										{
																											goto IL_09a5;
																										}
																										goto IL_0c4f;
																										IL_09a5:
																										if (3 >= b)
																										{
																											goto IL_09b0;
																										}
																										goto IL_09f5;
																										IL_09b0:
																										if (3 > b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_09be;
																										IL_09be:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										num = 313;
																										goto IL_0ab1;
																										IL_0ab1:
																										ptr2 += 8;
																										goto IL_0abf;
																										IL_0abf:
																										num6--;
																										goto IL_18b7;
																										IL_09f5:
																										if (4 < b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0a03;
																										IL_0a03:
																										if (4 > b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0a11;
																										IL_0a11:
																										array2[num6] = 0;
																										goto IL_0a1f;
																										IL_0a1f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_0a42;
																										IL_0a42:
																										array3[num6] = null;
																										goto IL_0a4c;
																										IL_0a4c:
																										num6++;
																										goto IL_0a5a;
																										IL_0a5a:
																										ptr2 += 8;
																										goto IL_18b7;
																										IL_0c4f:
																										if (2 <= b)
																										{
																											goto IL_0c5a;
																										}
																										goto IL_0cc1;
																										IL_0c5a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0c9a;
																										IL_0c9a:
																										array2[num6 - 2] = 0;
																										goto IL_0cae;
																										IL_0cae:
																										num6--;
																										goto IL_18b7;
																										IL_0cc1:
																										if (1 < b)
																										{
																											goto end_IL_066e;
																										}
																										goto IL_0ccf;
																										IL_0ccf:
																										if (1 > b)
																										{
																											goto end_IL_066e;
																										}
																										num = 160;
																										goto IL_0ce6;
																										IL_0763:
																										num6 -= 2;
																										goto IL_18b7;
																										IL_0ce6:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																										goto IL_0cff;
																										IL_0cff:
																										array2[num6] = 0;
																										goto IL_0d0d;
																										IL_0d0d:
																										num6++;
																										goto IL_0d1b;
																									}
																									break;
																								}
																								goto IL_0f42;
																								IL_0f97:
																								num6--;
																								goto IL_18b7;
																								IL_0f42:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																								goto IL_0f83;
																								IL_0f83:
																								array2[num6 - 2] = 0;
																								goto IL_0f97;
																							}
																							break;
																						}
																						goto IL_0faa;
																						IL_186c:
																						num10 = ptr2;
																						num11 = -200;
																						num5 = 1;
																						ptr2 = num10 + num11;
																						goto IL_18b7;
																						IL_0faa:
																						if (31 >= b)
																						{
																							goto IL_0fb8;
																						}
																						goto IL_144b;
																						IL_0fb8:
																						if (31 <= b)
																						{
																							num = 42;
																							goto IL_0fcc;
																						}
																						goto IL_101e;
																						IL_1885:
																						if (41 < b)
																						{
																							goto end_IL_066e;
																						}
																						num = 57;
																						goto IL_1899;
																						IL_0fcc:
																						array3[num6] = ((delegate*<TracerOption>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
																						goto IL_0fef;
																						IL_0fef:
																						array2[num6] = 4;
																						goto IL_0ffd;
																						IL_0ffd:
																						num6++;
																						goto IL_100b;
																						IL_100b:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_101e:
																						if (26 >= b)
																						{
																							goto IL_102c;
																						}
																						goto IL_1254;
																						IL_102c:
																						if (26 <= b)
																						{
																							goto IL_1037;
																						}
																						goto IL_1063;
																						IL_1037:
																						global::_003CModule_003E.tracerOption_1 = (TracerOption)array3[num6 - 1];
																						goto IL_1050;
																						IL_1050:
																						num6--;
																						goto IL_18b7;
																						IL_1063:
																						if (23 < b)
																						{
																							goto IL_1071;
																						}
																						goto IL_1172;
																						IL_1071:
																						if (24 < b)
																						{
																							goto IL_107f;
																						}
																						goto IL_1108;
																						IL_107f:
																						if (25 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_108d;
																						IL_108d:
																						if (25 > b)
																						{
																							goto end_IL_066e;
																						}
																						num = 119;
																						goto IL_10a4;
																						IL_1899:
																						if (41 <= b)
																						{
																						}
																						goto end_IL_066e;
																						IL_10a4:
																						array3[num6 - 2] = ((TracerOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_10e1;
																						IL_10e1:
																						array2[num6 - 2] = 4;
																						goto IL_10f5;
																						IL_10f5:
																						num6--;
																						goto IL_18b7;
																						IL_1108:
																						if (24 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_1116;
																						IL_1116:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
																						num = 314;
																						goto IL_1143;
																						IL_1143:
																						array2[num6] = 0;
																						goto IL_1151;
																						IL_1151:
																						num6++;
																						goto IL_115f;
																						IL_115f:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_1172:
																						if (23 <= b)
																						{
																							goto IL_117d;
																						}
																						goto IL_11d3;
																						IL_117d:
																						array3[num6] = ((delegate*<TracerOption[]>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
																						goto IL_119b;
																						IL_119b:
																						array2[num6] = 5;
																						num = 309;
																						goto IL_11b2;
																						IL_11b2:
																						num6++;
																						goto IL_11c0;
																						IL_11c0:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_11d3:
																						if (22 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_11e1;
																						IL_11e1:
																						if (22 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_11ef;
																						IL_11ef:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1241;
																						IL_1241:
																						num6--;
																						goto IL_18b7;
																						IL_1254:
																						if (28 >= b)
																						{
																							goto IL_1262;
																						}
																						goto IL_1340;
																						IL_1262:
																						if (28 <= b)
																						{
																							goto IL_126d;
																						}
																						goto IL_12d3;
																						IL_126d:
																						array2[num6 - 1] = 3;
																						goto IL_1281;
																						IL_1281:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_12c0;
																						IL_12c0:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_12d3:
																						if (27 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_12e1;
																						IL_12e1:
																						if (27 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_12ef;
																						IL_12ef:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_1308;
																						IL_1308:
																						array2[num6] = 3;
																						goto IL_1316;
																						IL_1316:
																						num6++;
																						goto IL_1324;
																						IL_1324:
																						ptr2 += 16;
																						num = 209;
																						goto IL_18b7;
																						IL_1340:
																						if (29 >= b)
																						{
																							goto IL_134b;
																						}
																						goto IL_13c0;
																						IL_134b:
																						if (29 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_1359;
																						IL_1359:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1399;
																						IL_1399:
																						array2[num6 - 2] = 3;
																						goto IL_13ad;
																						IL_13ad:
																						num6--;
																						goto IL_18b7;
																						IL_13c0:
																						if (30 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_13ce;
																						IL_13ce:
																						if (30 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_13dc;
																						IL_13dc:
																						array2[num6 - 1] = 0;
																						goto IL_13f0;
																						IL_13f0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_142f;
																						IL_142f:
																						ptr2 += 8;
																						num = 97;
																						goto IL_18b7;
																						IL_144b:
																						if (36 >= b)
																						{
																							goto IL_1459;
																						}
																						goto IL_16eb;
																						IL_1459:
																						if (36 <= b)
																						{
																							goto IL_1467;
																						}
																						goto IL_14f1;
																						IL_1467:
																						array2[num6 - 2] = 5;
																						goto IL_147b;
																						IL_147b:
																						array3[num6 - 2] = ((delegate*<string, string, string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																						num = 34;
																						goto IL_14d0;
																						IL_14d0:
																						num6--;
																						goto IL_14de;
																						IL_14de:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_14f1:
																						if (33 >= b)
																						{
																							goto IL_14ff;
																						}
																						goto IL_15e8;
																						IL_14ff:
																						if (33 <= b)
																						{
																							goto IL_150a;
																						}
																						goto IL_155e;
																						IL_150a:
																						((delegate*<Class8.TracerStyle, void>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1534;
																						IL_1534:
																						num6--;
																						goto IL_1542;
																						IL_1542:
																						ptr2 += 8;
																						num = 40;
																						goto IL_18b7;
																						IL_155e:
																						if (32 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_156c;
																						IL_156c:
																						if (32 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_157a;
																						IL_157a:
																						*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<TracerOption, Class8.TracerStyle>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																						goto IL_15b8;
																						IL_15b8:
																						array2[num6 - 1] = 0;
																						goto IL_15cc;
																						IL_15cc:
																						ptr2 += 8;
																						num = 299;
																						goto IL_18b7;
																						IL_15e8:
																						if (34 < b)
																						{
																							goto IL_15f3;
																						}
																						goto IL_166e;
																						IL_15f3:
																						if (35 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_1601;
																						IL_1601:
																						if (35 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_160f;
																						IL_160f:
																						array3[num6 - 1] = ((delegate*<TracerOption, string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
																						goto IL_1647;
																						IL_1647:
																						array2[num6 - 1] = 5;
																						goto IL_165b;
																						IL_165b:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_166e:
																						if (34 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_167c;
																						IL_167c:
																						array2[num6 - 1] = 3;
																						goto IL_1690;
																						IL_1690:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						num = 291;
																						goto IL_16d8;
																						IL_16d8:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_16eb:
																						if (39 >= b)
																						{
																							goto IL_16f9;
																						}
																						goto IL_1856;
																						IL_16f9:
																						if (39 <= b)
																						{
																							goto IL_1704;
																						}
																						goto IL_176b;
																						IL_1704:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1744;
																						IL_1744:
																						array2[num6 - 2] = 3;
																						goto IL_1758;
																						IL_1758:
																						num6--;
																						goto IL_18b7;
																						IL_176b:
																						if (37 >= b)
																						{
																							goto IL_1776;
																						}
																						goto IL_17ce;
																						IL_1776:
																						if (37 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_1784;
																						IL_1784:
																						((delegate*<string, void>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_17ad;
																						IL_17ad:
																						num6--;
																						goto IL_17bb;
																						IL_17bb:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_17ce:
																						if (38 < b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_17dc;
																						IL_17dc:
																						if (38 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_17ea;
																						IL_17ea:
																						array2[num6 - 1] = 3;
																						goto IL_17fe;
																						IL_17fe:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						num = 116;
																						goto IL_1846;
																						IL_1846:
																						ptr2 += 8;
																						goto IL_18b7;
																						IL_1856:
																						if (40 >= b)
																						{
																							goto IL_1861;
																						}
																						goto IL_1885;
																						IL_1861:
																						if (40 > b)
																						{
																							goto end_IL_066e;
																						}
																						goto IL_186c;
																					}
																					goto end_IL_067e;
																					continue;
																					end_IL_066e:
																					break;
																					IL_066e:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_18b7;
																			continue;
																			end_IL_067e:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_08ea:
			while (true)
			{
				IL_08ea_2:
				array = new byte[4];
				while (true)
				{
					IL_08f8:
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0a8b_2:
							num6++;
							while (true)
							{
								IL_18b7_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_067e_2:
											if (b >= 1)
											{
												while (b <= 41)
												{
													while (true)
													{
														if (21 >= b)
														{
															while (true)
															{
																if (21 > b)
																{
																	while (true)
																	{
																		if (10 < b)
																		{
																			while (true)
																			{
																				if (15 >= b)
																				{
																					while (true)
																					{
																						if (15 <= b)
																						{
																							while (true)
																							{
																								array2[num6] = array2[num6 - 1];
																								while (true)
																								{
																									array4[num6 - 0] = array4[num6 - 1];
																									while (true)
																									{
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										while (true)
																										{
																											IL_059e_2:
																											array3[num6] = array3[num6 - 1];
																											num = 351;
																											while (true)
																											{
																												if (num != 351)
																												{
																													if (num != 1332)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 198:
																														goto IL_059e_2;
																													case 2:
																														goto end_IL_058b_2;
																													case 258:
																														goto end_IL_05c1_2;
																													case 105:
																													case 214:
																														goto end_IL_05e7;
																													case 110:
																														goto end_IL_0607;
																													case 286:
																														goto end_IL_0621;
																													case 191:
																														goto end_IL_0631;
																													case 79:
																														goto end_IL_0641;
																													case 66:
																														goto end_IL_064e;
																													case 263:
																														goto end_IL_065e;
																													case 193:
																														goto IL_067e_2;
																													case 241:
																														goto end_IL_067e_2;
																													case 227:
																													case 260:
																														goto end_IL_068e;
																													case 166:
																														goto IL_06a9_2;
																													case 20:
																														goto IL_06b4_2;
																													case 52:
																														goto IL_06c2_2;
																													case 158:
																														goto IL_06cd_2;
																													case 143:
																														goto IL_06e0_2;
																													case 51:
																														goto IL_06ee_2;
																													case 13:
																													case 155:
																														goto IL_0701_2;
																													case 26:
																														goto IL_0763_2;
																													case 87:
																													case 180:
																														goto IL_0776_2;
																													case 204:
																														goto IL_07bb_2;
																													case 100:
																													case 138:
																														goto IL_07d2_2;
																													case 246:
																														goto IL_0812_2;
																													case 150:
																														goto IL_0826_2;
																													case 262:
																														goto IL_0839_2;
																													case 47:
																														goto IL_0844_2;
																													case 127:
																														goto IL_084f_2;
																													case 113:
																														goto IL_085d_2;
																													case 199:
																														goto IL_0870_2;
																													case 50:
																													case 101:
																														goto IL_087e_2;
																													case 104:
																														goto IL_089c_2;
																													case 69:
																														goto IL_08aa_2;
																													case 273:
																														goto IL_08bd_2;
																													case 170:
																														goto IL_08c8_2;
																													case 135:
																													case 253:
																														goto IL_08db_2;
																													case 295:
																														goto IL_0997_2;
																													case 238:
																														goto IL_09a5_2;
																													case 244:
																														goto IL_09b0_2;
																													case 133:
																													case 144:
																														goto IL_09be_2;
																													case 73:
																														goto IL_09f5_2;
																													case 196:
																														goto IL_0a03_2;
																													case 61:
																													case 134:
																														goto IL_0a11_2;
																													case 189:
																														goto IL_0a1f_2;
																													case 84:
																														goto IL_0a42_2;
																													case 211:
																														goto IL_0a4c_2;
																													case 30:
																														goto IL_0a5a_2;
																													case 302:
																														goto IL_0a6d_2;
																													case 307:
																														goto end_IL_069e;
																													case 197:
																														goto IL_0a8b_2;
																													case 99:
																													case 311:
																														goto IL_0a9e_2;
																													case 313:
																														goto IL_0ab1_2;
																													case 128:
																														goto IL_0abf_2;
																													case 321:
																														goto IL_0ad2_2;
																													case 330:
																														goto IL_0ae5_2;
																													case 9:
																														goto IL_0af3_2;
																													case 77:
																													case 264:
																														goto IL_0b01_2;
																													case 25:
																														goto IL_0b41_2;
																													case 322:
																														goto IL_0b55_2;
																													case 16:
																													case 332:
																														goto IL_0b68_2;
																													case 82:
																														goto IL_0b91_2;
																													case 334:
																														goto IL_0baa_2;
																													case 251:
																														goto IL_0bbe_2;
																													case 335:
																														goto IL_0bda_2;
																													case 27:
																													case 269:
																														goto IL_0be8_2;
																													case 216:
																														goto IL_0c28_2;
																													case 276:
																														goto IL_0c3c_2;
																													case 339:
																														goto IL_0c4f_2;
																													case 93:
																													case 304:
																														goto IL_0c5a_2;
																													case 60:
																														goto IL_0c9a_2;
																													case 296:
																														goto IL_0cae_2;
																													case 233:
																														goto IL_0cc1_2;
																													case 90:
																														goto IL_0ccf_2;
																													case 147:
																													case 160:
																														goto IL_0ce6_2;
																													case 86:
																														goto IL_0cff_2;
																													case 109:
																														goto IL_0d0d_2;
																													case 248:
																														goto IL_0d1b_2;
																													case 5:
																														goto IL_0d41_2;
																													case 80:
																														goto IL_0d4f_2;
																													case 136:
																														goto IL_0d5a_2;
																													case 72:
																														goto IL_0d68_2;
																													case 242:
																													case 328:
																														goto IL_0d76_2;
																													case 343:
																														goto IL_0d97_2;
																													case 18:
																													case 208:
																														goto IL_0da5_2;
																													case 10:
																														goto IL_0dbe_2;
																													case 17:
																														goto IL_0dcc_2;
																													case 237:
																														goto IL_0de3_2;
																													case 270:
																														goto IL_0df6_2;
																													case 188:
																														goto IL_0e04_2;
																													case 81:
																														goto IL_0e0f_2;
																													case 67:
																													case 126:
																														goto IL_0e1d_2;
																													case 165:
																														goto IL_0e2b_2;
																													case 288:
																														goto IL_0e43_2;
																													case 218:
																														goto IL_0e51_2;
																													case 327:
																														goto IL_0e64_2;
																													case 259:
																														goto IL_0e72_2;
																													case 129:
																													case 294:
																														goto IL_0e80_2;
																													case 239:
																														goto IL_0ebe_2;
																													case 124:
																													case 326:
																														goto IL_0eda_2;
																													case 300:
																														goto IL_0eee_2;
																													case 12:
																														goto IL_0f2f_2;
																													case 108:
																													case 220:
																														goto IL_0f42_2;
																													case 92:
																														goto IL_0f83_2;
																													case 229:
																														goto IL_0f97_2;
																													case 120:
																														goto IL_0faa_2;
																													case 54:
																														goto IL_0fb8_2;
																													case 42:
																													case 219:
																														goto IL_0fcc_2;
																													case 257:
																														goto IL_0fef_2;
																													case 324:
																														goto IL_0ffd_2;
																													case 149:
																														goto IL_100b_2;
																													case 19:
																														goto IL_101e_2;
																													case 88:
																														goto IL_102c_2;
																													case 223:
																													case 256:
																														goto IL_1037_2;
																													case 225:
																														goto IL_1050_2;
																													case 283:
																														goto IL_1063_2;
																													case 1:
																														goto IL_1071_2;
																													case 172:
																														goto IL_107f_2;
																													case 272:
																														goto IL_108d_2;
																													case 74:
																													case 119:
																														goto IL_10a4_2;
																													case 102:
																														goto IL_10e1_2;
																													case 32:
																														goto IL_10f5_2;
																													case 38:
																														goto IL_1108_2;
																													case 56:
																													case 115:
																														goto IL_1116_2;
																													case 314:
																														goto IL_1143_2;
																													case 121:
																														goto IL_1151_2;
																													case 252:
																														goto IL_115f_2;
																													case 331:
																														goto IL_1172_2;
																													case 4:
																													case 278:
																														goto IL_117d_2;
																													case 325:
																														goto IL_119b_2;
																													case 309:
																														goto IL_11b2_2;
																													case 284:
																														goto IL_11c0_2;
																													case 190:
																														goto IL_11d3_2;
																													case 64:
																														goto IL_11e1_2;
																													case 48:
																													case 106:
																														goto IL_11ef_2;
																													case 125:
																														goto IL_1241_2;
																													case 7:
																														goto IL_1254_2;
																													case 236:
																														goto IL_1262_2;
																													case 62:
																													case 222:
																														goto IL_126d_2;
																													case 210:
																														goto IL_1281_2;
																													case 202:
																														goto IL_12c0_2;
																													case 139:
																														goto IL_12d3_2;
																													case 167:
																														goto IL_12e1_2;
																													case 96:
																													case 185:
																														goto IL_12ef_2;
																													case 145:
																														goto IL_1308_2;
																													case 271:
																														goto IL_1316_2;
																													case 76:
																														goto IL_1324_2;
																													case 168:
																														goto IL_1340_2;
																													case 338:
																														goto IL_134b_2;
																													case 31:
																													case 65:
																														goto IL_1359_2;
																													case 117:
																														goto IL_1399_2;
																													case 0:
																														goto IL_13ad_2;
																													case 230:
																														goto IL_13c0_2;
																													case 85:
																														goto IL_13ce_2;
																													case 164:
																													case 231:
																														goto IL_13dc_2;
																													case 279:
																														goto IL_13f0_2;
																													case 70:
																														goto IL_142f_2;
																													case 186:
																														goto IL_144b_2;
																													case 55:
																														goto IL_1459_2;
																													case 63:
																													case 161:
																														goto IL_1467_2;
																													case 45:
																														goto IL_147b_2;
																													case 34:
																														goto IL_14d0_2;
																													case 94:
																														goto IL_14de_2;
																													case 275:
																														goto IL_14f1_2;
																													case 35:
																														goto IL_14ff_2;
																													case 266:
																													case 342:
																														goto IL_150a_2;
																													case 36:
																														goto IL_1534_2;
																													case 118:
																														goto IL_1542_2;
																													case 316:
																														goto IL_155e_2;
																													case 306:
																														goto IL_156c_2;
																													case 41:
																													case 312:
																														goto IL_157a_2;
																													case 178:
																														goto IL_15b8_2;
																													case 181:
																														goto IL_15cc_2;
																													case 46:
																														goto IL_15e8_2;
																													case 290:
																														goto IL_15f3_2;
																													case 107:
																														goto IL_1601_2;
																													case 14:
																													case 213:
																														goto IL_160f_2;
																													case 247:
																														goto IL_1647_2;
																													case 175:
																														goto IL_165b_2;
																													case 153:
																														goto IL_166e_2;
																													case 15:
																													case 333:
																														goto IL_167c_2;
																													case 336:
																														goto IL_1690_2;
																													case 291:
																														goto IL_16d8_2;
																													case 310:
																														goto IL_16eb_2;
																													case 217:
																														goto IL_16f9_2;
																													case 305:
																													case 320:
																														goto IL_1704_2;
																													case 249:
																														goto IL_1744_2;
																													case 232:
																														goto IL_1758_2;
																													case 344:
																														goto IL_176b_2;
																													case 49:
																														goto IL_1776_2;
																													case 169:
																													case 226:
																														goto IL_1784_2;
																													case 24:
																														goto IL_17ad_2;
																													case 254:
																														goto IL_17bb_2;
																													case 268:
																														goto IL_17ce_2;
																													case 293:
																														goto IL_17dc_2;
																													case 53:
																													case 159:
																														goto IL_17ea_2;
																													case 111:
																														goto IL_17fe_2;
																													case 116:
																														goto IL_1846_2;
																													case 315:
																														goto IL_1856_2;
																													case 301:
																														goto IL_1861_2;
																													case 215:
																													case 282:
																														goto IL_186c_2;
																													case 298:
																														goto IL_1885_2;
																													case 57:
																														goto IL_1899_2;
																													case 6:
																													case 8:
																													case 11:
																													case 21:
																													case 22:
																													case 29:
																													case 37:
																													case 39:
																													case 43:
																													case 44:
																													case 68:
																													case 71:
																													case 75:
																													case 83:
																													case 95:
																													case 142:
																													case 146:
																													case 152:
																													case 154:
																													case 157:
																													case 162:
																													case 163:
																													case 176:
																													case 179:
																													case 183:
																													case 192:
																													case 194:
																													case 195:
																													case 200:
																													case 221:
																													case 234:
																													case 235:
																													case 240:
																													case 245:
																													case 250:
																													case 267:
																													case 274:
																													case 277:
																													case 289:
																													case 292:
																													case 319:
																													case 329:
																													case 340:
																													case 341:
																														goto end_IL_066e_2;
																													case 3:
																													case 23:
																													case 28:
																													case 33:
																													case 40:
																													case 78:
																													case 89:
																													case 97:
																													case 98:
																													case 103:
																													case 112:
																													case 130:
																													case 131:
																													case 132:
																													case 137:
																													case 140:
																													case 141:
																													case 148:
																													case 151:
																													case 156:
																													case 171:
																													case 174:
																													case 177:
																													case 182:
																													case 184:
																													case 187:
																													case 201:
																													case 203:
																													case 206:
																													case 209:
																													case 212:
																													case 224:
																													case 228:
																													case 243:
																													case 255:
																													case 261:
																													case 287:
																													case 297:
																													case 299:
																													case 303:
																													case 308:
																													case 317:
																													case 318:
																													case 323:
																														goto IL_18b7_2;
																													case 280:
																														ptr2 = ptr;
																														goto IL_18b7_2;
																													case 58:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenizerStringBlockgetExceptionMessage.MatchAllVersionsISTOREBINDREFERENCETOASSEMBLYFLAGS);
																														goto case 280;
																													case 281:
																														array7 = new object[11];
																														goto case 58;
																													case 91:
																														array6 = new long[4];
																														goto case 281;
																													case 205:
																														array5 = new int[7];
																														goto case 91;
																													case 337:
																														array4 = new int[4];
																														goto case 205;
																													case 285:
																														array3 = new object[4];
																														goto case 337;
																													case 173:
																														array2 = new byte[4];
																														goto case 285;
																													case 59:
																														num4 = num2 * 8;
																														goto case 173;
																													case 114:
																														num3 = num2 * 4;
																														goto case 59;
																													case 122:
																														num2 = 1;
																														goto case 114;
																													case 123:
																														goto end_IL_0a7d;
																													case 207:
																													case 265:
																														return;
																													}
																													continue;
																												}
																												num6++;
																												goto IL_18b7_2;
																												continue;
																												end_IL_058b_2:
																												break;
																											}
																											break;
																										}
																										continue;
																										end_IL_05c1_2:
																										break;
																									}
																									continue;
																									end_IL_05e7:
																									break;
																								}
																								continue;
																								end_IL_0607:
																								break;
																							}
																							continue;
																						}
																						goto IL_0839_2;
																						IL_08db_2:
																						array8 = array3;
																						num7 = num6;
																						if (array == null)
																						{
																							goto IL_08ea_2;
																						}
																						goto IL_08f8;
																						IL_0839_2:
																						if (12 < b)
																						{
																							goto IL_0844_2;
																						}
																						goto IL_08bd_2;
																						IL_0844_2:
																						if (13 < b)
																						{
																							goto IL_084f_2;
																						}
																						goto IL_0870_2;
																						IL_084f_2:
																						if (14 < b)
																						{
																							goto end_IL_066e_2;
																						}
																						goto IL_085d_2;
																						IL_085d_2:
																						if (14 > b)
																						{
																							goto end_IL_066e_2;
																						}
																						goto IL_0b68_2;
																						IL_0b68_2:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_0b91_2;
																						IL_0b91_2:
																						array2[num6 - 1] = 5;
																						goto IL_18b7_2;
																						IL_0870_2:
																						if (13 > b)
																						{
																							goto end_IL_066e_2;
																						}
																						goto IL_087e_2;
																						IL_087e_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_089c_2;
																						IL_089c_2:
																						ptr2 += 8;
																						goto IL_08aa_2;
																						IL_08aa_2:
																						num6--;
																						goto IL_18b7_2;
																						IL_08bd_2:
																						if (12 > b)
																						{
																							goto IL_08c8_2;
																						}
																						goto IL_08db_2;
																						IL_08c8_2:
																						if (11 < b)
																						{
																							goto end_IL_066e_2;
																						}
																						goto IL_0ad2_2;
																						IL_0ad2_2:
																						if (11 > b)
																						{
																							goto end_IL_066e_2;
																						}
																						goto IL_18b7_2;
																						continue;
																						end_IL_0621:
																						break;
																					}
																					continue;
																				}
																				goto IL_0d41_2;
																				IL_0eda_2:
																				array2[num6 - 1] = 5;
																				goto IL_0eee_2;
																				IL_0d41_2:
																				if (18 < b)
																				{
																					goto IL_0d4f_2;
																				}
																				goto IL_0df6_2;
																				IL_0d4f_2:
																				if (19 < b)
																				{
																					goto IL_0d5a_2;
																				}
																				num = 343;
																				goto IL_0d97_2;
																				IL_0d5a_2:
																				if (20 < b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0d68_2;
																				IL_0d68_2:
																				if (20 > b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0d76_2;
																				IL_0d76_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_18b7_2;
																				IL_0eee_2:
																				array3[num6 - 1] = ((delegate*<string[], string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																				num = 12;
																				goto IL_0f2f_2;
																				IL_0d97_2:
																				if (19 > b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0da5_2;
																				IL_0da5_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0dbe_2;
																				IL_0dbe_2:
																				array2[num6] = 1;
																				goto IL_0dcc_2;
																				IL_0dcc_2:
																				num6++;
																				num = 237;
																				goto IL_0de3_2;
																				IL_0de3_2:
																				ptr2 += 16;
																				goto IL_18b7_2;
																				IL_0df6_2:
																				if (18 > b)
																				{
																					goto IL_0e04_2;
																				}
																				num = 326;
																				goto IL_0eda_2;
																				IL_0e04_2:
																				if (16 >= b)
																				{
																					goto IL_0e0f_2;
																				}
																				goto IL_0e64_2;
																				IL_0e0f_2:
																				if (16 > b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0e1d_2;
																				IL_0e1d_2:
																				array2[num6] = 5;
																				goto IL_0e2b_2;
																				IL_0e2b_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0e43_2;
																				IL_0e43_2:
																				num6++;
																				goto IL_0e51_2;
																				IL_0e51_2:
																				ptr2 += 8;
																				goto IL_18b7_2;
																				IL_0e64_2:
																				if (17 < b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0e72_2;
																				IL_0e72_2:
																				if (17 > b)
																				{
																					goto end_IL_066e_2;
																				}
																				goto IL_0e80_2;
																				IL_0e80_2:
																				((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																				goto IL_0ebe_2;
																				IL_0ebe_2:
																				num6 -= 3;
																				goto IL_18b7_2;
																				IL_0f2f_2:
																				ptr2 += 8;
																				goto IL_18b7_2;
																				continue;
																				end_IL_0631:
																				break;
																			}
																			continue;
																		}
																		goto IL_06a9_2;
																		IL_0d1b_2:
																		ptr2 += 8;
																		goto IL_18b7_2;
																		IL_06a9_2:
																		if (10 > b)
																		{
																			goto IL_06b4_2;
																		}
																		goto IL_0701_2;
																		IL_06b4_2:
																		if (5 < b)
																		{
																			goto IL_06c2_2;
																		}
																		goto IL_07bb_2;
																		IL_06c2_2:
																		if (7 >= b)
																		{
																			goto IL_06cd_2;
																		}
																		goto IL_06e0_2;
																		IL_06cd_2:
																		if (7 <= b)
																		{
																			goto IL_0776_2;
																		}
																		goto IL_0ae5_2;
																		IL_0ae5_2:
																		if (6 < b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0af3_2;
																		IL_0af3_2:
																		if (6 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0b01_2;
																		IL_0b01_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b41_2;
																		IL_0b41_2:
																		array2[num6 - 2] = 0;
																		goto IL_0b55_2;
																		IL_0b55_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_0776_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0baa_2;
																		IL_0baa_2:
																		array2[num6 - 2] = 0;
																		goto IL_0bbe_2;
																		IL_0bbe_2:
																		num6--;
																		num = 141;
																		goto IL_18b7_2;
																		IL_06e0_2:
																		if (8 < b)
																		{
																			goto IL_06ee_2;
																		}
																		goto IL_0a6d_2;
																		IL_06ee_2:
																		if (9 < b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0bda_2;
																		IL_0bda_2:
																		if (9 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0be8_2;
																		IL_0be8_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0c28_2;
																		IL_0c28_2:
																		array2[num6 - 2] = 0;
																		goto IL_0c3c_2;
																		IL_0c3c_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_0a6d_2:
																		if (8 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0a9e_2;
																		IL_0a9e_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_07bb_2:
																		if (5 <= b)
																		{
																			num = 138;
																			goto IL_07d2_2;
																		}
																		goto IL_0997_2;
																		IL_0701_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0763_2;
																		IL_07d2_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0812_2;
																		IL_0812_2:
																		array2[num6 - 2] = 0;
																		goto IL_0826_2;
																		IL_0826_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_0997_2:
																		if (2 < b)
																		{
																			goto IL_09a5_2;
																		}
																		goto IL_0c4f_2;
																		IL_09a5_2:
																		if (3 >= b)
																		{
																			goto IL_09b0_2;
																		}
																		goto IL_09f5_2;
																		IL_09b0_2:
																		if (3 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_09be_2;
																		IL_09be_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 313;
																		goto IL_0ab1_2;
																		IL_0ab1_2:
																		ptr2 += 8;
																		goto IL_0abf_2;
																		IL_0abf_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_09f5_2:
																		if (4 < b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0a03_2;
																		IL_0a03_2:
																		if (4 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0a11_2;
																		IL_0a11_2:
																		array2[num6] = 0;
																		goto IL_0a1f_2;
																		IL_0a1f_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_0a42_2;
																		IL_0a42_2:
																		array3[num6] = null;
																		goto IL_0a4c_2;
																		IL_0a4c_2:
																		num6++;
																		goto IL_0a5a_2;
																		IL_0a5a_2:
																		ptr2 += 8;
																		goto IL_18b7_2;
																		IL_0c4f_2:
																		if (2 <= b)
																		{
																			goto IL_0c5a_2;
																		}
																		goto IL_0cc1_2;
																		IL_0c5a_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0c9a_2;
																		IL_0c9a_2:
																		array2[num6 - 2] = 0;
																		goto IL_0cae_2;
																		IL_0cae_2:
																		num6--;
																		goto IL_18b7_2;
																		IL_0cc1_2:
																		if (1 < b)
																		{
																			goto end_IL_066e_2;
																		}
																		goto IL_0ccf_2;
																		IL_0ccf_2:
																		if (1 > b)
																		{
																			goto end_IL_066e_2;
																		}
																		num = 160;
																		goto IL_0ce6_2;
																		IL_0763_2:
																		num6 -= 2;
																		goto IL_18b7_2;
																		IL_0ce6_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0cff_2;
																		IL_0cff_2:
																		array2[num6] = 0;
																		goto IL_0d0d_2;
																		IL_0d0d_2:
																		num6++;
																		goto IL_0d1b_2;
																		continue;
																		end_IL_0641:
																		break;
																	}
																	continue;
																}
																goto IL_0f42_2;
																IL_0f97_2:
																num6--;
																goto IL_18b7_2;
																IL_0f42_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																goto IL_0f83_2;
																IL_0f83_2:
																array2[num6 - 2] = 0;
																goto IL_0f97_2;
																continue;
																end_IL_064e:
																break;
															}
															continue;
														}
														goto IL_0faa_2;
														IL_186c_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_18b7_2;
														IL_0faa_2:
														if (31 >= b)
														{
															goto IL_0fb8_2;
														}
														goto IL_144b_2;
														IL_0fb8_2:
														if (31 <= b)
														{
															num = 42;
															goto IL_0fcc_2;
														}
														goto IL_101e_2;
														IL_1885_2:
														if (41 < b)
														{
															goto end_IL_066e_2;
														}
														num = 57;
														goto IL_1899_2;
														IL_0fcc_2:
														array3[num6] = ((delegate*<TracerOption>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
														goto IL_0fef_2;
														IL_0fef_2:
														array2[num6] = 4;
														goto IL_0ffd_2;
														IL_0ffd_2:
														num6++;
														goto IL_100b_2;
														IL_100b_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_101e_2:
														if (26 >= b)
														{
															goto IL_102c_2;
														}
														goto IL_1254_2;
														IL_102c_2:
														if (26 <= b)
														{
															goto IL_1037_2;
														}
														goto IL_1063_2;
														IL_1037_2:
														global::_003CModule_003E.tracerOption_1 = (TracerOption)array3[num6 - 1];
														goto IL_1050_2;
														IL_1050_2:
														num6--;
														goto IL_18b7_2;
														IL_1063_2:
														if (23 < b)
														{
															goto IL_1071_2;
														}
														goto IL_1172_2;
														IL_1071_2:
														if (24 < b)
														{
															goto IL_107f_2;
														}
														goto IL_1108_2;
														IL_107f_2:
														if (25 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_108d_2;
														IL_108d_2:
														if (25 > b)
														{
															goto end_IL_066e_2;
														}
														num = 119;
														goto IL_10a4_2;
														IL_1899_2:
														if (41 <= b)
														{
														}
														goto end_IL_066e_2;
														IL_10a4_2:
														array3[num6 - 2] = ((TracerOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_10e1_2;
														IL_10e1_2:
														array2[num6 - 2] = 4;
														goto IL_10f5_2;
														IL_10f5_2:
														num6--;
														goto IL_18b7_2;
														IL_1108_2:
														if (24 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_1116_2;
														IL_1116_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
														num = 314;
														goto IL_1143_2;
														IL_1143_2:
														array2[num6] = 0;
														goto IL_1151_2;
														IL_1151_2:
														num6++;
														goto IL_115f_2;
														IL_115f_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_1172_2:
														if (23 <= b)
														{
															goto IL_117d_2;
														}
														goto IL_11d3_2;
														IL_117d_2:
														array3[num6] = ((delegate*<TracerOption[]>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])();
														goto IL_119b_2;
														IL_119b_2:
														array2[num6] = 5;
														num = 309;
														goto IL_11b2_2;
														IL_11b2_2:
														num6++;
														goto IL_11c0_2;
														IL_11c0_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_11d3_2:
														if (22 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_11e1_2;
														IL_11e1_2:
														if (22 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_11ef_2;
														IL_11ef_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1241_2;
														IL_1241_2:
														num6--;
														goto IL_18b7_2;
														IL_1254_2:
														if (28 >= b)
														{
															goto IL_1262_2;
														}
														goto IL_1340_2;
														IL_1262_2:
														if (28 <= b)
														{
															goto IL_126d_2;
														}
														goto IL_12d3_2;
														IL_126d_2:
														array2[num6 - 1] = 3;
														goto IL_1281_2;
														IL_1281_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_12c0_2;
														IL_12c0_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_12d3_2:
														if (27 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_12e1_2;
														IL_12e1_2:
														if (27 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_12ef_2;
														IL_12ef_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_1308_2;
														IL_1308_2:
														array2[num6] = 3;
														goto IL_1316_2;
														IL_1316_2:
														num6++;
														goto IL_1324_2;
														IL_1324_2:
														ptr2 += 16;
														num = 209;
														goto IL_18b7_2;
														IL_1340_2:
														if (29 >= b)
														{
															goto IL_134b_2;
														}
														goto IL_13c0_2;
														IL_134b_2:
														if (29 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_1359_2;
														IL_1359_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1399_2;
														IL_1399_2:
														array2[num6 - 2] = 3;
														goto IL_13ad_2;
														IL_13ad_2:
														num6--;
														goto IL_18b7_2;
														IL_13c0_2:
														if (30 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_13ce_2;
														IL_13ce_2:
														if (30 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_13dc_2;
														IL_13dc_2:
														array2[num6 - 1] = 0;
														goto IL_13f0_2;
														IL_13f0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_142f_2;
														IL_142f_2:
														ptr2 += 8;
														num = 97;
														goto IL_18b7_2;
														IL_144b_2:
														if (36 >= b)
														{
															goto IL_1459_2;
														}
														goto IL_16eb_2;
														IL_1459_2:
														if (36 <= b)
														{
															goto IL_1467_2;
														}
														goto IL_14f1_2;
														IL_1467_2:
														array2[num6 - 2] = 5;
														goto IL_147b_2;
														IL_147b_2:
														array3[num6 - 2] = ((delegate*<string, string, string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
														num = 34;
														goto IL_14d0_2;
														IL_14d0_2:
														num6--;
														goto IL_14de_2;
														IL_14de_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_14f1_2:
														if (33 >= b)
														{
															goto IL_14ff_2;
														}
														goto IL_15e8_2;
														IL_14ff_2:
														if (33 <= b)
														{
															goto IL_150a_2;
														}
														goto IL_155e_2;
														IL_150a_2:
														((delegate*<Class8.TracerStyle, void>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1534_2;
														IL_1534_2:
														num6--;
														goto IL_1542_2;
														IL_1542_2:
														ptr2 += 8;
														num = 40;
														goto IL_18b7_2;
														IL_155e_2:
														if (32 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_156c_2;
														IL_156c_2:
														if (32 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_157a_2;
														IL_157a_2:
														*(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<TracerOption, Class8.TracerStyle>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
														goto IL_15b8_2;
														IL_15b8_2:
														array2[num6 - 1] = 0;
														goto IL_15cc_2;
														IL_15cc_2:
														ptr2 += 8;
														num = 299;
														goto IL_18b7_2;
														IL_15e8_2:
														if (34 < b)
														{
															goto IL_15f3_2;
														}
														goto IL_166e_2;
														IL_15f3_2:
														if (35 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_1601_2;
														IL_1601_2:
														if (35 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_160f_2;
														IL_160f_2:
														array3[num6 - 1] = ((delegate*<TracerOption, string>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((TracerOption)array3[num6 - 1]);
														goto IL_1647_2;
														IL_1647_2:
														array2[num6 - 1] = 5;
														goto IL_165b_2;
														IL_165b_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_166e_2:
														if (34 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_167c_2;
														IL_167c_2:
														array2[num6 - 1] = 3;
														goto IL_1690_2;
														IL_1690_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 291;
														goto IL_16d8_2;
														IL_16d8_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_16eb_2:
														if (39 >= b)
														{
															goto IL_16f9_2;
														}
														goto IL_1856_2;
														IL_16f9_2:
														if (39 <= b)
														{
															goto IL_1704_2;
														}
														goto IL_176b_2;
														IL_1704_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1744_2;
														IL_1744_2:
														array2[num6 - 2] = 3;
														goto IL_1758_2;
														IL_1758_2:
														num6--;
														goto IL_18b7_2;
														IL_176b_2:
														if (37 >= b)
														{
															goto IL_1776_2;
														}
														goto IL_17ce_2;
														IL_1776_2:
														if (37 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_1784_2;
														IL_1784_2:
														((delegate*<string, void>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_17ad_2;
														IL_17ad_2:
														num6--;
														goto IL_17bb_2;
														IL_17bb_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_17ce_2:
														if (38 < b)
														{
															goto end_IL_066e_2;
														}
														goto IL_17dc_2;
														IL_17dc_2:
														if (38 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_17ea_2;
														IL_17ea_2:
														array2[num6 - 1] = 3;
														goto IL_17fe_2;
														IL_17fe_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IsolatedStorageScopeDataCollector[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 116;
														goto IL_1846_2;
														IL_1846_2:
														ptr2 += 8;
														goto IL_18b7_2;
														IL_1856_2:
														if (40 >= b)
														{
															goto IL_1861_2;
														}
														goto IL_1885_2;
														IL_1861_2:
														if (40 > b)
														{
															goto end_IL_066e_2;
														}
														goto IL_186c_2;
														continue;
														end_IL_065e:
														break;
													}
													continue;
													end_IL_066e_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_18b7_2;
											continue;
											end_IL_067e_2:
											break;
										}
										continue;
										end_IL_068e:
										break;
									}
									continue;
									end_IL_069e:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0a7d:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class131()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class131()
	{
		//The blocks IL_000e, IL_001e, IL_034f, IL_0362, IL_0381, IL_0391, IL_03a1, IL_03ae, IL_03be, IL_03ce, IL_03de, IL_03ee, IL_03fe, IL_040e, IL_041e, IL_0429, IL_0437, IL_0460, IL_0479, IL_04c6, IL_04d4, IL_04e7, IL_0532, IL_054e, IL_0559, IL_0567, IL_0580, IL_0593, IL_05a1, IL_05af, IL_05cb, IL_05d9, IL_05e7, IL_05f2, IL_05fd, IL_063b, IL_064e, IL_065c, IL_066a, IL_0678, IL_068c, IL_06c4, IL_06d7, IL_06e2, IL_06f0, IL_0708, IL_0716, IL_0729, IL_0737, IL_0745, IL_075d, IL_0784, IL_07a8, IL_07c0, IL_07d3, IL_07ed, IL_0800, IL_080b, IL_0834, IL_084d, IL_085b, IL_0866, IL_087b, IL_088e, IL_0899, IL_08a4, IL_08b9, IL_08d5, IL_08de, IL_08ec, IL_08ff, IL_0908, IL_0913, IL_0921, IL_092f, IL_0944, IL_0957, IL_0965, IL_096e, IL_0983, IL_0996, IL_09a4, IL_09b2, IL_09c0, IL_09ce, IL_0a0e, IL_0a22, IL_0a35, IL_0a43, IL_0a5c, IL_0a6a, IL_0a78, IL_0a8b, IL_0a94, IL_0a9f, IL_0abd, IL_0acb, IL_0ade, IL_0ae9, IL_0af7, IL_0b0c, IL_0b1f, IL_0b2d, IL_0b3b, IL_0b44, IL_0b61, IL_0bb0, IL_0bba, IL_0be7, IL_0bfb, IL_0c09, IL_0c19, IL_0c37, IL_0c45, IL_0c58, IL_0c62, IL_0c6d, IL_0c7d, IL_0c8d, IL_0c9d, IL_0cad, IL_0cbd, IL_0ccd, IL_0cee, IL_0cf5, IL_0cfc are reachable both inside and outside the pinned region starting at IL_0ce2. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2;
					int num3;
					byte[] array2;
					object[] array3;
					int[] array4;
					long[] array5;
					object[] array6;
					byte* ptr;
					byte* num6;
					int num7;
					object[] array7;
					int num8;
					byte* num9;
					byte* ptr2;
					byte[] array = new byte[4];
					if (true)
					{
						while (true)
						{
							IL_0ccd:
							num2 = 1;
							while (true)
							{
								IL_0cbd:
								num3 = num2 * 4;
								while (true)
								{
									IL_0cad:
									array2 = new byte[6];
									while (true)
									{
										IL_0c9d:
										array3 = new object[6];
										while (true)
										{
											IL_0c8d:
											array4 = new int[6];
											while (true)
											{
												IL_0c7d:
												array5 = new long[6];
												while (true)
												{
													IL_0c6d:
													array6 = new object[23];
													while (true)
													{
														IL_0c62:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DictionaryEntryArraySortHelper.IsNaNCompute);
														while (true)
														{
															IL_0c58:
															ptr2 = ptr;
															while (true)
															{
																IL_0c45:
																if (num4 != 1)
																{
																	while (true)
																	{
																		IL_041e:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_040e:
																			ptr2++;
																			while (true)
																			{
																				IL_03fe:
																				if (b >= 1)
																				{
																					while (b <= 21)
																					{
																						while (true)
																						{
																							IL_03de:
																							if (11 < b)
																							{
																								while (true)
																								{
																									IL_03ce:
																									if (16 < b)
																									{
																										while (true)
																										{
																											IL_03be:
																											if (19 >= b)
																											{
																												while (true)
																												{
																													IL_03ae:
																													if (19 > b)
																													{
																														while (true)
																														{
																															IL_03a1:
																															if (17 < b)
																															{
																																while (18 >= b)
																																{
																																	while (18 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_0362:
																																			array2[num5 - 2] = 5;
																																			num = 208;
																																			while (true)
																																			{
																																				if (num != 208)
																																				{
																																					if (num != 1189)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 107:
																																						break;
																																					default:
																																						continue;
																																					case 26:
																																					case 137:
																																						goto IL_0362;
																																					case 37:
																																						goto IL_0381;
																																					case 15:
																																						goto IL_0391;
																																					case 21:
																																					case 111:
																																						goto IL_03a1;
																																					case 108:
																																						goto IL_03ae;
																																					case 25:
																																						goto IL_03be;
																																					case 135:
																																					case 171:
																																						goto IL_03ce;
																																					case 7:
																																						goto IL_03de;
																																					case 99:
																																						goto IL_03ee;
																																					case 179:
																																						goto IL_03fe;
																																					case 145:
																																						goto IL_040e;
																																					case 69:
																																					case 112:
																																						goto IL_041e;
																																					case 40:
																																						goto IL_0429;
																																					case 4:
																																					case 64:
																																						goto IL_0437;
																																					case 162:
																																						goto IL_0460;
																																					case 68:
																																						goto IL_04c6;
																																					case 63:
																																						goto IL_04d4;
																																					case 56:
																																					case 140:
																																						goto IL_04e7;
																																					case 17:
																																						goto IL_0532;
																																					case 120:
																																						goto IL_054e;
																																					case 61:
																																						goto IL_0559;
																																					case 117:
																																					case 139:
																																						goto IL_0567;
																																					case 75:
																																						goto IL_0580;
																																					case 90:
																																					case 178:
																																						goto IL_0593;
																																					case 103:
																																						goto IL_05a1;
																																					case 129:
																																					case 164:
																																						goto IL_05af;
																																					case 189:
																																						goto IL_05cb;
																																					case 76:
																																					case 130:
																																						goto IL_05d9;
																																					case 155:
																																						goto IL_05e7;
																																					case 163:
																																						goto IL_05f2;
																																					case 20:
																																					case 156:
																																						goto IL_05fd;
																																					case 176:
																																						goto IL_063b;
																																					case 14:
																																						goto end_IL_034f;
																																					case 138:
																																						goto IL_066a;
																																					case 48:
																																					case 127:
																																						goto IL_0678;
																																					case 27:
																																						goto IL_068c;
																																					case 173:
																																						goto IL_06c4;
																																					case 190:
																																						goto IL_06d7;
																																					case 13:
																																					case 54:
																																						goto IL_06e2;
																																					case 38:
																																						goto IL_06f0;
																																					case 113:
																																						goto IL_0708;
																																					case 195:
																																						goto IL_0716;
																																					case 53:
																																						goto IL_0729;
																																					case 132:
																																						goto IL_0737;
																																					case 47:
																																					case 184:
																																						goto IL_0745;
																																					case 91:
																																						goto IL_075d;
																																					case 89:
																																						goto IL_0784;
																																					case 78:
																																						goto IL_07a8;
																																					case 10:
																																						goto IL_07c0;
																																					case 185:
																																					case 186:
																																						goto IL_07d3;
																																					case 55:
																																						goto IL_07ed;
																																					case 143:
																																						goto IL_0800;
																																					case 82:
																																					case 100:
																																						goto IL_080b;
																																					case 102:
																																						goto IL_0834;
																																					case 133:
																																						goto IL_084d;
																																					case 124:
																																						goto IL_085b;
																																					case 62:
																																					case 149:
																																						goto IL_0866;
																																					case 136:
																																						goto IL_087b;
																																					case 51:
																																					case 147:
																																						goto IL_088e;
																																					case 116:
																																						goto IL_0899;
																																					case 33:
																																					case 71:
																																						goto IL_08a4;
																																					case 174:
																																						goto IL_08b9;
																																					case 58:
																																					case 80:
																																						goto IL_08de;
																																					case 9:
																																						goto IL_08ec;
																																					case 6:
																																					case 74:
																																						goto IL_0908;
																																					case 94:
																																					case 101:
																																						goto IL_0913;
																																					case 84:
																																						goto IL_0921;
																																					case 44:
																																					case 59:
																																						goto IL_092f;
																																					case 46:
																																						goto IL_0944;
																																					case 50:
																																						goto IL_0957;
																																					case 153:
																																					case 201:
																																						goto IL_096e;
																																					case 3:
																																						goto IL_0983;
																																					case 131:
																																						goto IL_0996;
																																					case 110:
																																						goto IL_09a4;
																																					case 142:
																																					case 172:
																																						goto IL_09b2;
																																					case 160:
																																						goto IL_09c0;
																																					case 115:
																																					case 194:
																																						goto IL_09ce;
																																					case 157:
																																						goto IL_0a0e;
																																					case 95:
																																						goto IL_0a22;
																																					case 70:
																																						goto IL_0a35;
																																					case 23:
																																					case 148:
																																						goto IL_0a43;
																																					case 16:
																																						goto IL_0a5c;
																																					case 73:
																																						goto IL_0a6a;
																																					case 8:
																																						goto IL_0a78;
																																					case 83:
																																						goto IL_0a94;
																																					case 19:
																																					case 123:
																																						goto IL_0a9f;
																																					case 2:
																																						goto IL_0abd;
																																					case 49:
																																						goto IL_0acb;
																																					case 188:
																																						goto IL_0ade;
																																					case 119:
																																						goto IL_0ae9;
																																					case 0:
																																					case 121:
																																						goto IL_0af7;
																																					case 166:
																																						goto IL_0b0c;
																																					case 92:
																																					case 191:
																																						goto IL_0b1f;
																																					case 141:
																																						goto IL_0b2d;
																																					case 41:
																																					case 126:
																																						goto IL_0b44;
																																					case 65:
																																						goto IL_0bfb;
																																					case 5:
																																						goto IL_0c09;
																																					case 1:
																																					case 11:
																																					case 18:
																																					case 24:
																																					case 32:
																																					case 42:
																																					case 43:
																																					case 45:
																																					case 66:
																																					case 67:
																																					case 72:
																																					case 77:
																																					case 79:
																																					case 85:
																																					case 88:
																																					case 98:
																																					case 104:
																																					case 105:
																																					case 114:
																																					case 118:
																																					case 128:
																																					case 146:
																																					case 150:
																																					case 152:
																																					case 159:
																																					case 168:
																																					case 169:
																																					case 170:
																																					case 175:
																																					case 183:
																																					case 193:
																																					case 196:
																																					case 197:
																																						goto end_IL_0381;
																																					case 39:
																																						goto IL_0c37;
																																					case 12:
																																					case 22:
																																					case 28:
																																					case 52:
																																					case 57:
																																					case 60:
																																					case 81:
																																					case 86:
																																					case 87:
																																					case 93:
																																					case 96:
																																					case 97:
																																					case 109:
																																					case 125:
																																					case 134:
																																					case 151:
																																					case 158:
																																					case 161:
																																					case 177:
																																					case 180:
																																					case 181:
																																					case 187:
																																					case 198:
																																						goto IL_0c45;
																																					case 154:
																																						goto IL_0c58;
																																					case 182:
																																						goto IL_0c62;
																																					case 35:
																																						goto IL_0c6d;
																																					case 192:
																																						goto IL_0c7d;
																																					case 31:
																																						goto IL_0c8d;
																																					case 36:
																																						goto IL_0c9d;
																																					case 199:
																																					case 200:
																																						goto IL_0cad;
																																					case 34:
																																						goto IL_0cbd;
																																					case 144:
																																						goto IL_0ccd;
																																					case 106:
																																						break;
																																					case 122:
																																						break;
																																					case 29:
																																						Class300.smethod_0();
																																						break;
																																					case 30:
																																						Class296.Aw4EYyy3h();
																																						goto case 29;
																																					case 165:
																																					case 167:
																																						return;
																																					}
																																					goto end_IL_03fe;
																																				}
																																				array3[num5 - 2] = ((delegate*<string, Class8.TracerStyle, object>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], *(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																																				goto IL_04c6;
																																				IL_04c6:
																																				num5--;
																																				goto IL_04d4;
																																				IL_04d4:
																																				ptr2 += 8;
																																				goto IL_0c45;
																																				continue;
																																				end_IL_034f:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_065c;
																																		continue;
																																		end_IL_0381:
																																		break;
																																		IL_0381:;
																																	}
																																	break;
																																	IL_0391:;
																																}
																																break;
																															}
																															goto IL_0429;
																															IL_0460:
																															array2[num5 - 1] = 5;
																															goto IL_0c45;
																															IL_0429:
																															if (17 > b)
																															{
																																break;
																															}
																															goto IL_0437;
																															IL_0437:
																															array3[num5 - 1] = new TracerOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																															goto IL_0460;
																														}
																														break;
																													}
																													goto IL_04e7;
																													IL_0532:
																													num5 -= 3;
																													num = 187;
																													goto IL_0c45;
																													IL_04e7:
																													((TracerOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (TracerOption)array3[num5 - 1];
																													num = 17;
																													goto IL_0532;
																												}
																												break;
																											}
																											goto IL_054e;
																											IL_05af:
																											num6 = ptr2;
																											num7 = -200;
																											num4 = 1;
																											ptr2 = num6 + num7;
																											goto IL_0c45;
																											IL_054e:
																											if (20 >= b)
																											{
																												goto IL_0559;
																											}
																											goto IL_0593;
																											IL_0559:
																											if (20 > b)
																											{
																												break;
																											}
																											goto IL_0567;
																											IL_0567:
																											tracerOption_0 = (TracerOption[])array3[num5 - 1];
																											goto IL_0580;
																											IL_0580:
																											num5--;
																											goto IL_0c45;
																											IL_0593:
																											if (21 < b)
																											{
																												break;
																											}
																											goto IL_05a1;
																											IL_05a1:
																											if (21 > b)
																											{
																												break;
																											}
																											goto IL_05af;
																										}
																										break;
																									}
																									goto IL_05cb;
																									IL_07d3:
																									int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_07ed;
																									IL_05cb:
																									if (16 > b)
																									{
																										goto IL_05d9;
																									}
																									goto IL_07d3;
																									IL_05d9:
																									if (13 < b)
																									{
																										goto IL_05e7;
																									}
																									goto IL_06d7;
																									IL_05e7:
																									if (14 >= b)
																									{
																										goto IL_05f2;
																									}
																									goto IL_065c;
																									IL_05f2:
																									if (14 > b)
																									{
																										num = 67;
																										break;
																									}
																									goto IL_05fd;
																									IL_05fd:
																									((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																									goto IL_063b;
																									IL_063b:
																									num5 -= 3;
																									goto IL_0c45;
																									IL_07ed:
																									num5--;
																									goto IL_0c45;
																									IL_065c:
																									if (15 < b)
																									{
																										break;
																									}
																									goto IL_066a;
																									IL_066a:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_0678;
																									IL_0678:
																									array2[num5 - 1] = 5;
																									goto IL_068c;
																									IL_068c:
																									array3[num5 - 1] = ((delegate*<string[], string>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																									goto IL_06c4;
																									IL_06c4:
																									ptr2 += 8;
																									goto IL_0c45;
																									IL_06d7:
																									if (13 <= b)
																									{
																										goto IL_06e2;
																									}
																									goto IL_0729;
																									IL_06e2:
																									array2[num5] = 5;
																									goto IL_06f0;
																									IL_06f0:
																									array3[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_0708;
																									IL_0708:
																									num5++;
																									goto IL_0716;
																									IL_0716:
																									ptr2 += 8;
																									goto IL_0c45;
																									IL_0729:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0737;
																									IL_0737:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_0745;
																									IL_0745:
																									array2[num5] = array2[num5 - 1];
																									goto IL_075d;
																									IL_075d:
																									array4[num5 - 0] = array4[num5 - 1];
																									num = 89;
																									goto IL_0784;
																									IL_0784:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_07a8;
																									IL_07a8:
																									array3[num5] = array3[num5 - 1];
																									goto IL_07c0;
																									IL_07c0:
																									num5++;
																									goto IL_0c45;
																								}
																								break;
																							}
																							goto IL_0800;
																							IL_0b1f:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0b2d;
																							IL_0800:
																							if (11 <= b)
																							{
																								goto IL_080b;
																							}
																							goto IL_084d;
																							IL_080b:
																							array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																							goto IL_0834;
																							IL_0834:
																							array2[num5 - 1] = 5;
																							goto IL_0c45;
																							IL_084d:
																							if (5 >= b)
																							{
																								goto IL_085b;
																							}
																							goto IL_0996;
																							IL_085b:
																							if (5 <= b)
																							{
																								goto IL_0866;
																							}
																							goto IL_088e;
																							IL_0866:
																							((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																							goto IL_087b;
																							IL_087b:
																							ptr2 += 8;
																							goto IL_0c45;
																							IL_088e:
																							if (2 >= b)
																							{
																								goto IL_0899;
																							}
																							num = 74;
																							goto IL_0908;
																							IL_0899:
																							if (2 <= b)
																							{
																								goto IL_08a4;
																							}
																							num = 58;
																							goto IL_08de;
																							IL_08a4:
																							((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																							goto IL_08b9;
																							IL_08b9:
																							ptr2 += 8;
																							num = 198;
																							goto IL_0c45;
																							IL_0bfb:
																							array2[num5] = 5;
																							goto IL_0c09;
																							IL_08de:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_08ec;
																							IL_08ec:
																							if (1 > b)
																							{
																							}
																							break;
																							IL_0b2d:
																							if (7 > b)
																							{
																								break;
																							}
																							num = 126;
																							goto IL_0b44;
																							IL_0908:
																							if (3 < b)
																							{
																								goto IL_0913;
																							}
																							goto IL_0957;
																							IL_0913:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0921;
																							IL_0921:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_092f;
																							IL_092f:
																							((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																							goto IL_0944;
																							IL_0944:
																							ptr2 += 8;
																							goto IL_0c45;
																							IL_0957:
																							if (3 > b)
																							{
																								break;
																							}
																							num = 201;
																							goto IL_096e;
																							IL_0b44:
																							array7 = array3;
																							num8 = num5;
																							if (array == null)
																							{
																								goto IL_0b53;
																							}
																							num9 = ptr2;
																							byte b2 = *num9;
																							ptr2 = num9 + 4;
																							int num10 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num10;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0bfb;
																							IL_096e:
																							((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																							goto IL_0983;
																							IL_0983:
																							ptr2 += 8;
																							goto IL_0c45;
																							IL_0996:
																							if (8 < b)
																							{
																								goto IL_09a4;
																							}
																							num = 83;
																							goto IL_0a94;
																							IL_09a4:
																							if (9 < b)
																							{
																								goto IL_09b2;
																							}
																							goto IL_0a35;
																							IL_09b2:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_09c0;
																							IL_09c0:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_09ce;
																							IL_09ce:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																							goto IL_0a0e;
																							IL_0a0e:
																							array2[num5 - 2] = 0;
																							goto IL_0a22;
																							IL_0a22:
																							num5--;
																							goto IL_0c45;
																							IL_0a35:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0a43;
																							IL_0a43:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0a5c;
																							IL_0a5c:
																							array2[num5] = 0;
																							goto IL_0a6a;
																							IL_0a6a:
																							num5++;
																							goto IL_0a78;
																							IL_0a78:
																							ptr2 += 8;
																							goto IL_0c45;
																							IL_0c09:
																							num5++;
																							goto IL_0c45;
																							IL_0a94:
																							if (8 <= b)
																							{
																								goto IL_0a9f;
																							}
																							goto IL_0ade;
																							IL_0a9f:
																							array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																							goto IL_0abd;
																							IL_0abd:
																							ptr2 += 8;
																							goto IL_0acb;
																							IL_0acb:
																							num5--;
																							goto IL_0c45;
																							IL_0ade:
																							if (6 >= b)
																							{
																								goto IL_0ae9;
																							}
																							goto IL_0b1f;
																							IL_0ae9:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0af7;
																							IL_0af7:
																							((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																							goto IL_0b0c;
																							IL_0b0c:
																							ptr2 += 8;
																							goto IL_0c45;
																						}
																						break;
																						IL_03ee:;
																					}
																				}
																				((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																				num = 39;
																				goto IL_0c37;
																				IL_0c37:
																				ptr2 += 8;
																				goto IL_0c45;
																				continue;
																				end_IL_03fe:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 165;
																return;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
					}
					continue;
					IL_0b53:
					while (true)
					{
						IL_0b53_2:
						array = new byte[4];
						while (true)
						{
							IL_0b61:
							num9 = ptr2;
							byte b2 = *num9;
							ptr2 = num9 + 4;
							int num10 = *(int*)(ptr2 + num3);
							ptr2 += 8;
							byte* ptr3 = ptr2 + num10;
							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
							while (ptr2 != ptr3)
							{
								*ptr4 = (byte)(*ptr2 ^ b2);
								ptr2++;
								ptr4++;
							}
							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
							while (true)
							{
								array2[num5] = 5;
								while (true)
								{
									IL_0c09_2:
									num5++;
									while (true)
									{
										IL_0c45_2:
										if (num4 != 1)
										{
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_03fe_2:
														if (b >= 1)
														{
															while (b <= 21)
															{
																while (true)
																{
																	IL_03de_2:
																	if (11 < b)
																	{
																		while (true)
																		{
																			IL_03ce_2:
																			if (16 < b)
																			{
																				while (true)
																				{
																					IL_03be_2:
																					if (19 >= b)
																					{
																						while (true)
																						{
																							IL_03ae_2:
																							if (19 > b)
																							{
																								while (true)
																								{
																									IL_03a1_2:
																									if (17 < b)
																									{
																										while (18 >= b)
																										{
																											while (18 <= b)
																											{
																												while (true)
																												{
																													IL_0362_2:
																													array2[num5 - 2] = 5;
																													num = 208;
																													while (true)
																													{
																														if (num != 208)
																														{
																															if (num != 1189)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 26:
																															case 137:
																																goto IL_0362_2;
																															case 37:
																																goto IL_0381_2;
																															case 15:
																																goto IL_0391_2;
																															case 21:
																															case 111:
																																goto IL_03a1_2;
																															case 108:
																																goto IL_03ae_2;
																															case 25:
																																goto IL_03be_2;
																															case 135:
																															case 171:
																																goto IL_03ce_2;
																															case 7:
																																goto IL_03de_2;
																															case 99:
																																goto IL_03ee_2;
																															case 179:
																																goto IL_03fe_2;
																															case 145:
																																goto end_IL_03fe_2;
																															case 69:
																															case 112:
																																goto end_IL_040e;
																															case 40:
																																goto IL_0429_2;
																															case 4:
																															case 64:
																																goto IL_0437_2;
																															case 162:
																																goto IL_0460_2;
																															case 68:
																																goto IL_04c6_2;
																															case 63:
																																goto IL_04d4_2;
																															case 56:
																															case 140:
																																goto IL_04e7_2;
																															case 17:
																																goto IL_0532_2;
																															case 120:
																																goto IL_054e_2;
																															case 61:
																																goto IL_0559_2;
																															case 117:
																															case 139:
																																goto IL_0567_2;
																															case 75:
																																goto IL_0580_2;
																															case 90:
																															case 178:
																																goto IL_0593_2;
																															case 103:
																																goto IL_05a1_2;
																															case 129:
																															case 164:
																																goto IL_05af_2;
																															case 189:
																																goto IL_05cb_2;
																															case 76:
																															case 130:
																																goto IL_05d9_2;
																															case 155:
																																goto IL_05e7_2;
																															case 163:
																																goto IL_05f2_2;
																															case 20:
																															case 156:
																																goto IL_05fd_2;
																															case 176:
																																goto IL_063b_2;
																															case 14:
																																goto end_IL_034f_2;
																															case 138:
																																goto IL_066a_2;
																															case 48:
																															case 127:
																																goto IL_0678_2;
																															case 27:
																																goto IL_068c_2;
																															case 173:
																																goto IL_06c4_2;
																															case 190:
																																goto IL_06d7_2;
																															case 13:
																															case 54:
																																goto IL_06e2_2;
																															case 38:
																																goto IL_06f0_2;
																															case 113:
																																goto IL_0708_2;
																															case 195:
																																goto IL_0716_2;
																															case 53:
																																goto IL_0729_2;
																															case 132:
																																goto IL_0737_2;
																															case 47:
																															case 184:
																																goto IL_0745_2;
																															case 91:
																																goto IL_075d_2;
																															case 89:
																																goto IL_0784_2;
																															case 78:
																																goto IL_07a8_2;
																															case 10:
																																goto IL_07c0_2;
																															case 185:
																															case 186:
																																goto IL_07d3_2;
																															case 55:
																																goto IL_07ed_2;
																															case 143:
																																goto IL_0800_2;
																															case 82:
																															case 100:
																																goto IL_080b_2;
																															case 102:
																																goto IL_0834_2;
																															case 133:
																																goto IL_084d_2;
																															case 124:
																																goto IL_085b_2;
																															case 62:
																															case 149:
																																goto IL_0866_2;
																															case 136:
																																goto IL_087b_2;
																															case 51:
																															case 147:
																																goto IL_088e_2;
																															case 116:
																																goto IL_0899_2;
																															case 33:
																															case 71:
																																goto IL_08a4_2;
																															case 174:
																																goto IL_08b9_2;
																															case 58:
																															case 80:
																																goto IL_08de_2;
																															case 9:
																																goto IL_08ec_2;
																															case 6:
																															case 74:
																																goto IL_0908_2;
																															case 94:
																															case 101:
																																goto IL_0913_2;
																															case 84:
																																goto IL_0921_2;
																															case 44:
																															case 59:
																																goto IL_092f_2;
																															case 46:
																																goto IL_0944_2;
																															case 50:
																																goto IL_0957_2;
																															case 153:
																															case 201:
																																goto IL_096e_2;
																															case 3:
																																goto IL_0983_2;
																															case 131:
																																goto IL_0996_2;
																															case 110:
																																goto IL_09a4_2;
																															case 142:
																															case 172:
																																goto IL_09b2_2;
																															case 160:
																																goto IL_09c0_2;
																															case 115:
																															case 194:
																																goto IL_09ce_2;
																															case 157:
																																goto IL_0a0e_2;
																															case 95:
																																goto IL_0a22_2;
																															case 70:
																																goto IL_0a35_2;
																															case 23:
																															case 148:
																																goto IL_0a43_2;
																															case 16:
																																goto IL_0a5c_2;
																															case 73:
																																goto IL_0a6a_2;
																															case 8:
																																goto IL_0a78_2;
																															case 83:
																																goto IL_0a94_2;
																															case 19:
																															case 123:
																																goto IL_0a9f_2;
																															case 2:
																																goto IL_0abd_2;
																															case 49:
																																goto IL_0acb_2;
																															case 188:
																																goto IL_0ade_2;
																															case 119:
																																goto IL_0ae9_2;
																															case 0:
																															case 121:
																																goto IL_0af7_2;
																															case 166:
																																goto IL_0b0c_2;
																															case 92:
																															case 191:
																																goto IL_0b1f_2;
																															case 141:
																																goto IL_0b2d_2;
																															case 41:
																															case 126:
																																goto IL_0b44_2;
																															case 65:
																																goto end_IL_041e;
																															case 5:
																																goto IL_0c09_2;
																															case 1:
																															case 11:
																															case 18:
																															case 24:
																															case 32:
																															case 42:
																															case 43:
																															case 45:
																															case 66:
																															case 67:
																															case 72:
																															case 77:
																															case 79:
																															case 85:
																															case 88:
																															case 98:
																															case 104:
																															case 105:
																															case 114:
																															case 118:
																															case 128:
																															case 146:
																															case 150:
																															case 152:
																															case 159:
																															case 168:
																															case 169:
																															case 170:
																															case 175:
																															case 183:
																															case 193:
																															case 196:
																															case 197:
																																goto end_IL_0381_2;
																															case 39:
																																goto IL_0c37_2;
																															case 12:
																															case 22:
																															case 28:
																															case 52:
																															case 57:
																															case 60:
																															case 81:
																															case 86:
																															case 87:
																															case 93:
																															case 96:
																															case 97:
																															case 109:
																															case 125:
																															case 134:
																															case 151:
																															case 158:
																															case 161:
																															case 177:
																															case 180:
																															case 181:
																															case 187:
																															case 198:
																																goto IL_0c45_2;
																															case 154:
																																ptr2 = ptr;
																																goto IL_0c45_2;
																															case 182:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DictionaryEntryArraySortHelper.IsNaNCompute);
																																goto case 154;
																															case 35:
																																array6 = new object[23];
																																goto case 182;
																															case 192:
																																array5 = new long[6];
																																goto case 35;
																															case 31:
																																array4 = new int[6];
																																goto case 192;
																															case 36:
																																array3 = new object[6];
																																goto case 31;
																															case 199:
																															case 200:
																																array2 = new byte[6];
																																goto case 36;
																															case 34:
																																num3 = num2 * 4;
																																goto case 199;
																															case 144:
																																num2 = 1;
																																goto case 34;
																															case 106:
																															case 107:
																															case 122:
																																goto end_IL_0bfb;
																															case 29:
																																goto end_IL_0cd8;
																															case 30:
																																goto end_IL_0cee;
																															case 165:
																															case 167:
																																return;
																															}
																															continue;
																														}
																														array3[num5 - 2] = ((delegate*<string, Class8.TracerStyle, object>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], *(Class8.TracerStyle*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																														goto IL_04c6_2;
																														IL_04c6_2:
																														num5--;
																														goto IL_04d4_2;
																														IL_04d4_2:
																														ptr2 += 8;
																														goto IL_0c45_2;
																														continue;
																														end_IL_034f_2:
																														break;
																													}
																													break;
																												}
																												goto IL_065c_2;
																												continue;
																												end_IL_0381_2:
																												break;
																												IL_0381_2:;
																											}
																											break;
																											IL_0391_2:;
																										}
																										break;
																									}
																									goto IL_0429_2;
																									IL_0460_2:
																									array2[num5 - 1] = 5;
																									goto IL_0c45_2;
																									IL_0429_2:
																									if (17 > b)
																									{
																										break;
																									}
																									goto IL_0437_2;
																									IL_0437_2:
																									array3[num5 - 1] = new TracerOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																									goto IL_0460_2;
																								}
																								break;
																							}
																							goto IL_04e7_2;
																							IL_0532_2:
																							num5 -= 3;
																							num = 187;
																							goto IL_0c45_2;
																							IL_04e7_2:
																							((TracerOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (TracerOption)array3[num5 - 1];
																							num = 17;
																							goto IL_0532_2;
																						}
																						break;
																					}
																					goto IL_054e_2;
																					IL_05af_2:
																					num6 = ptr2;
																					num7 = -200;
																					num4 = 1;
																					ptr2 = num6 + num7;
																					goto IL_0c45_2;
																					IL_054e_2:
																					if (20 >= b)
																					{
																						goto IL_0559_2;
																					}
																					goto IL_0593_2;
																					IL_0559_2:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0567_2;
																					IL_0567_2:
																					tracerOption_0 = (TracerOption[])array3[num5 - 1];
																					goto IL_0580_2;
																					IL_0580_2:
																					num5--;
																					goto IL_0c45_2;
																					IL_0593_2:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_05a1_2;
																					IL_05a1_2:
																					if (21 > b)
																					{
																						break;
																					}
																					goto IL_05af_2;
																				}
																				break;
																			}
																			goto IL_05cb_2;
																			IL_07d3_2:
																			int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																			goto IL_07ed_2;
																			IL_05cb_2:
																			if (16 > b)
																			{
																				goto IL_05d9_2;
																			}
																			goto IL_07d3_2;
																			IL_05d9_2:
																			if (13 < b)
																			{
																				goto IL_05e7_2;
																			}
																			goto IL_06d7_2;
																			IL_05e7_2:
																			if (14 >= b)
																			{
																				goto IL_05f2_2;
																			}
																			goto IL_065c_2;
																			IL_05f2_2:
																			if (14 > b)
																			{
																				num = 67;
																				break;
																			}
																			goto IL_05fd_2;
																			IL_05fd_2:
																			((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																			goto IL_063b_2;
																			IL_063b_2:
																			num5 -= 3;
																			goto IL_0c45_2;
																			IL_07ed_2:
																			num5--;
																			goto IL_0c45_2;
																			IL_065c_2:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_066a_2;
																			IL_066a_2:
																			if (15 > b)
																			{
																				break;
																			}
																			goto IL_0678_2;
																			IL_0678_2:
																			array2[num5 - 1] = 5;
																			goto IL_068c_2;
																			IL_068c_2:
																			array3[num5 - 1] = ((delegate*<string[], string>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																			goto IL_06c4_2;
																			IL_06c4_2:
																			ptr2 += 8;
																			goto IL_0c45_2;
																			IL_06d7_2:
																			if (13 <= b)
																			{
																				goto IL_06e2_2;
																			}
																			goto IL_0729_2;
																			IL_06e2_2:
																			array2[num5] = 5;
																			goto IL_06f0_2;
																			IL_06f0_2:
																			array3[num5] = array6[*(int*)(ptr2 + num3)];
																			goto IL_0708_2;
																			IL_0708_2:
																			num5++;
																			goto IL_0716_2;
																			IL_0716_2:
																			ptr2 += 8;
																			goto IL_0c45_2;
																			IL_0729_2:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_0737_2;
																			IL_0737_2:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_0745_2;
																			IL_0745_2:
																			array2[num5] = array2[num5 - 1];
																			goto IL_075d_2;
																			IL_075d_2:
																			array4[num5 - 0] = array4[num5 - 1];
																			num = 89;
																			goto IL_0784_2;
																			IL_0784_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																			goto IL_07a8_2;
																			IL_07a8_2:
																			array3[num5] = array3[num5 - 1];
																			goto IL_07c0_2;
																			IL_07c0_2:
																			num5++;
																			goto IL_0c45_2;
																		}
																		break;
																	}
																	goto IL_0800_2;
																	IL_0af7_2:
																	((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																	goto IL_0b0c_2;
																	IL_0800_2:
																	if (11 <= b)
																	{
																		goto IL_080b_2;
																	}
																	goto IL_084d_2;
																	IL_080b_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																	goto IL_0834_2;
																	IL_0834_2:
																	array2[num5 - 1] = 5;
																	goto IL_0c45_2;
																	IL_084d_2:
																	if (5 >= b)
																	{
																		goto IL_085b_2;
																	}
																	goto IL_0996_2;
																	IL_085b_2:
																	if (5 <= b)
																	{
																		goto IL_0866_2;
																	}
																	goto IL_088e_2;
																	IL_0866_2:
																	((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																	goto IL_087b_2;
																	IL_087b_2:
																	ptr2 += 8;
																	goto IL_0c45_2;
																	IL_088e_2:
																	if (2 >= b)
																	{
																		goto IL_0899_2;
																	}
																	num = 74;
																	goto IL_0908_2;
																	IL_0899_2:
																	if (2 <= b)
																	{
																		goto IL_08a4_2;
																	}
																	num = 58;
																	goto IL_08de_2;
																	IL_08a4_2:
																	((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																	goto IL_08b9_2;
																	IL_08b9_2:
																	ptr2 += 8;
																	num = 198;
																	goto IL_0c45_2;
																	IL_0b1f_2:
																	if (7 < b)
																	{
																		break;
																	}
																	goto IL_0b2d_2;
																	IL_08de_2:
																	if (1 < b)
																	{
																		break;
																	}
																	goto IL_08ec_2;
																	IL_08ec_2:
																	if (1 > b)
																	{
																	}
																	break;
																	IL_0b0c_2:
																	ptr2 += 8;
																	goto IL_0c45_2;
																	IL_0908_2:
																	if (3 < b)
																	{
																		goto IL_0913_2;
																	}
																	goto IL_0957_2;
																	IL_0913_2:
																	if (4 < b)
																	{
																		break;
																	}
																	goto IL_0921_2;
																	IL_0921_2:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_092f_2;
																	IL_092f_2:
																	((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																	goto IL_0944_2;
																	IL_0944_2:
																	ptr2 += 8;
																	goto IL_0c45_2;
																	IL_0957_2:
																	if (3 > b)
																	{
																		break;
																	}
																	num = 201;
																	goto IL_096e_2;
																	IL_0b2d_2:
																	if (7 > b)
																	{
																		break;
																	}
																	num = 126;
																	goto IL_0b44_2;
																	IL_096e_2:
																	((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
																	goto IL_0983_2;
																	IL_0983_2:
																	ptr2 += 8;
																	goto IL_0c45_2;
																	IL_0996_2:
																	if (8 < b)
																	{
																		goto IL_09a4_2;
																	}
																	num = 83;
																	goto IL_0a94_2;
																	IL_09a4_2:
																	if (9 < b)
																	{
																		goto IL_09b2_2;
																	}
																	goto IL_0a35_2;
																	IL_09b2_2:
																	if (10 < b)
																	{
																		break;
																	}
																	goto IL_09c0_2;
																	IL_09c0_2:
																	if (10 > b)
																	{
																		break;
																	}
																	goto IL_09ce_2;
																	IL_09ce_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_0a0e_2;
																	IL_0a0e_2:
																	array2[num5 - 2] = 0;
																	goto IL_0a22_2;
																	IL_0a22_2:
																	num5--;
																	goto IL_0c45_2;
																	IL_0a35_2:
																	if (9 > b)
																	{
																		break;
																	}
																	goto IL_0a43_2;
																	IL_0a43_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0a5c_2;
																	IL_0a5c_2:
																	array2[num5] = 0;
																	goto IL_0a6a_2;
																	IL_0a6a_2:
																	num5++;
																	goto IL_0a78_2;
																	IL_0a78_2:
																	ptr2 += 8;
																	goto IL_0c45_2;
																	IL_0b44_2:
																	array7 = array3;
																	num8 = num5;
																	if (array == null)
																	{
																		goto IL_0b53_2;
																	}
																	goto IL_0b61;
																	IL_0a94_2:
																	if (8 <= b)
																	{
																		goto IL_0a9f_2;
																	}
																	goto IL_0ade_2;
																	IL_0a9f_2:
																	array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_0abd_2;
																	IL_0abd_2:
																	ptr2 += 8;
																	goto IL_0acb_2;
																	IL_0acb_2:
																	num5--;
																	goto IL_0c45_2;
																	IL_0ade_2:
																	if (6 >= b)
																	{
																		goto IL_0ae9_2;
																	}
																	goto IL_0b1f_2;
																	IL_0ae9_2:
																	if (6 > b)
																	{
																		break;
																	}
																	goto IL_0af7_2;
																}
																break;
																IL_03ee_2:;
															}
														}
														((delegate*<void>)RawAclCngAlgorithmID[*(int*)(ptr2 + num3)])();
														num = 39;
														goto IL_0c37_2;
														IL_0c37_2:
														ptr2 += 8;
														goto IL_0c45_2;
														continue;
														end_IL_03fe_2:
														break;
													}
													continue;
													end_IL_040e:
													break;
												}
												continue;
												end_IL_041e:
												break;
											}
											break;
										}
										num = 165;
										return;
									}
									break;
								}
								continue;
								end_IL_0bfb:
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_0cd8:
					break;
				}
				continue;
				end_IL_0cee:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 138;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 61;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetManagedCategoryGuidCapiNative.CurrencyEnglishNameKERBSULOGON);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 37;
															while (true)
															{
																IL_0340:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0320:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_0310:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_0300:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02f0:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02e0:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02d0:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_02ab:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_0296:
																															array2[num5] = null;
																															num = 157;
																															while (true)
																															{
																																if (num != 157)
																																{
																																	if (num != 1138)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 29:
																																		goto IL_0296;
																																	case 44:
																																		goto IL_02ab;
																																	case 107:
																																	case 143:
																																		goto IL_02d0;
																																	case 120:
																																		goto IL_02e0;
																																	case 47:
																																	case 86:
																																		goto IL_02f0;
																																	case 92:
																																		goto IL_0300;
																																	case 28:
																																	case 128:
																																		goto IL_0310;
																																	case 139:
																																		goto IL_0320;
																																	case 109:
																																		goto IL_0330;
																																	case 37:
																																		goto IL_0340;
																																	case 19:
																																		goto end_IL_0340;
																																	case 41:
																																	case 126:
																																		goto end_IL_0350;
																																	case 75:
																																	case 117:
																																		goto IL_0374;
																																	case 22:
																																		goto IL_0382;
																																	case 20:
																																		goto IL_03a3;
																																	case 1:
																																		goto IL_03bf;
																																	case 64:
																																		goto IL_03cd;
																																	case 46:
																																	case 82:
																																		goto IL_03db;
																																	case 52:
																																		goto IL_041f;
																																	case 36:
																																		goto IL_0433;
																																	case 31:
																																	case 39:
																																		goto IL_044f;
																																	case 130:
																																		goto IL_048f;
																																	case 122:
																																		goto IL_04ac;
																																	case 89:
																																		goto IL_04bf;
																																	case 32:
																																		goto IL_04cd;
																																	case 40:
																																	case 87:
																																		goto IL_04d8;
																																	case 67:
																																		goto IL_04fd;
																																	case 43:
																																		goto IL_050b;
																																	case 97:
																																	case 144:
																																		goto IL_0519;
																																	case 116:
																																		goto IL_057b;
																																	case 114:
																																		goto IL_058e;
																																	case 59:
																																		goto IL_059c;
																																	case 98:
																																		goto IL_05af;
																																	case 12:
																																	case 146:
																																		goto IL_05bd;
																																	case 133:
																																		goto IL_05cb;
																																	case 91:
																																	case 111:
																																		goto IL_05d9;
																																	case 42:
																																		goto IL_05e4;
																																	case 33:
																																		goto IL_05f2;
																																	case 54:
																																	case 104:
																																		goto IL_0600;
																																	case 101:
																																		goto IL_0629;
																																	case 148:
																																		goto IL_0642;
																																	case 79:
																																	case 121:
																																		goto IL_064d;
																																	case 113:
																																		goto IL_065b;
																																	case 93:
																																	case 135:
																																		goto IL_0669;
																																	case 112:
																																		goto IL_0682;
																																	case 90:
																																		goto IL_0690;
																																	case 25:
																																		goto IL_069e;
																																	case 10:
																																	case 149:
																																		goto IL_06b1;
																																	case 34:
																																		goto IL_06f1;
																																	case 65:
																																		goto IL_0705;
																																	case 81:
																																	case 85:
																																		goto IL_0718;
																																	case 73:
																																		goto IL_0736;
																																	case 83:
																																		goto IL_0744;
																																	case 119:
																																		goto IL_0757;
																																	case 23:
																																	case 95:
																																		goto IL_0762;
																																	case 118:
																																		goto IL_0770;
																																	case 127:
																																	case 141:
																																		goto IL_077e;
																																	case 68:
																																		goto IL_07a7;
																																	case 48:
																																		goto IL_07b5;
																																	case 131:
																																		goto IL_07c8;
																																	case 4:
																																	case 57:
																																		goto IL_07d3;
																																	case 96:
																																		goto IL_0812;
																																	case 125:
																																	case 147:
																																		goto IL_0825;
																																	case 50:
																																		goto IL_0830;
																																	case 71:
																																	case 84:
																																		goto IL_083b;
																																	case 27:
																																		goto IL_0849;
																																	case 2:
																																		goto IL_0861;
																																	case 72:
																																		goto IL_086f;
																																	case 0:
																																	case 5:
																																	case 6:
																																	case 7:
																																	case 9:
																																	case 13:
																																	case 17:
																																	case 21:
																																	case 24:
																																	case 35:
																																	case 45:
																																	case 62:
																																	case 69:
																																	case 76:
																																	case 77:
																																	case 88:
																																	case 94:
																																	case 102:
																																	case 105:
																																	case 106:
																																	case 110:
																																	case 115:
																																	case 124:
																																	case 129:
																																	case 134:
																																	case 136:
																																	case 140:
																																	case 145:
																																	case 150:
																																		goto end_IL_0283;
																																	case 70:
																																	case 100:
																																		goto IL_0894;
																																	case 11:
																																	case 14:
																																	case 15:
																																	case 16:
																																	case 18:
																																	case 26:
																																	case 38:
																																	case 49:
																																	case 51:
																																	case 53:
																																	case 55:
																																	case 56:
																																	case 74:
																																	case 78:
																																	case 80:
																																	case 103:
																																	case 108:
																																	case 132:
																																		goto end_IL_0369;
																																	case 123:
																																		goto end_IL_08a7;
																																	case 8:
																																		goto end_IL_08ba;
																																	case 3:
																																		goto end_IL_08c4;
																																	case 61:
																																		goto end_IL_08cf;
																																	case 60:
																																	case 99:
																																		goto end_IL_08df;
																																	case 30:
																																		goto end_IL_08ef;
																																	case 63:
																																	case 142:
																																		goto end_IL_0908;
																																	case 137:
																																		goto end_IL_0918;
																																	case 138:
																																		goto end_IL_0928;
																																	case 58:
																																	case 66:
																																		goto IL_0943;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_03a3;
																																IL_03a3:
																																ptr2 += 8;
																																num = 56;
																																goto end_IL_0369;
																																continue;
																																end_IL_0283:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0374;
																											IL_0382:
																											if (9 > b)
																											{
																												break;
																											}
																											goto end_IL_0369;
																											IL_0374:
																											if (9 < b)
																											{
																												break;
																											}
																											goto IL_0382;
																										}
																										break;
																									}
																									goto IL_03bf;
																									IL_0433:
																									num5--;
																									num = 16;
																									goto end_IL_0369;
																									IL_03bf:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_03cd;
																									IL_03cd:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_03db;
																									IL_03db:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_041f;
																									IL_041f:
																									array[num5 - 2] = 0;
																									goto IL_0433;
																								}
																								break;
																							}
																							goto IL_044f;
																							IL_04ac:
																							num5--;
																							goto end_IL_0369;
																							IL_044f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_048f;
																							IL_048f:
																							array[num5 - 2] = 0;
																							num = 122;
																							goto IL_04ac;
																						}
																						break;
																					}
																					goto IL_04bf;
																					IL_059c:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_04bf:
																					if (14 >= b)
																					{
																						goto IL_04cd;
																					}
																					goto IL_058e;
																					IL_04cd:
																					if (14 <= b)
																					{
																						goto IL_04d8;
																					}
																					goto IL_04fd;
																					IL_04d8:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 38;
																					goto end_IL_0369;
																					IL_04fd:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_050b;
																					IL_050b:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0519;
																					IL_0519:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_057b;
																					IL_057b:
																					num5 -= 2;
																					goto end_IL_0369;
																					IL_058e:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_059c;
																				}
																				break;
																			}
																			goto IL_05af;
																			IL_0894:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0369;
																			IL_05af:
																			if (8 > b)
																			{
																				goto IL_05bd;
																			}
																			goto IL_0894;
																			IL_05bd:
																			if (4 >= b)
																			{
																				goto IL_05cb;
																			}
																			goto IL_0757;
																			IL_05cb:
																			if (4 > b)
																			{
																				goto IL_05d9;
																			}
																			goto IL_0718;
																			IL_05d9:
																			if (2 < b)
																			{
																				goto IL_05e4;
																			}
																			goto IL_0642;
																			IL_05e4:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_05f2;
																			IL_05f2:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0600;
																			IL_0600:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0629;
																			IL_0629:
																			array[num5 - 1] = 5;
																			goto end_IL_0369;
																			IL_0642:
																			if (2 > b)
																			{
																				goto IL_064d;
																			}
																			goto IL_06b1;
																			IL_064d:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_065b;
																			IL_065b:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0669;
																			IL_0669:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0682;
																			IL_0682:
																			array[num5] = 0;
																			goto IL_0690;
																			IL_0690:
																			num5++;
																			goto IL_069e;
																			IL_069e:
																			ptr2 += 8;
																			goto end_IL_0369;
																			IL_06b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06f1;
																			IL_06f1:
																			array[num5 - 2] = 0;
																			goto IL_0705;
																			IL_0705:
																			num5--;
																			goto end_IL_0369;
																			IL_0718:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0736;
																			IL_0736:
																			ptr2 += 8;
																			goto IL_0744;
																			IL_0744:
																			num5--;
																			goto end_IL_0369;
																			IL_0757:
																			if (6 < b)
																			{
																				goto IL_0762;
																			}
																			goto IL_07c8;
																			IL_0762:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0770;
																			IL_0770:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_077e;
																			IL_077e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07a7;
																			IL_07a7:
																			ptr2 += 8;
																			goto IL_07b5;
																			IL_07b5:
																			num5--;
																			goto end_IL_0369;
																			IL_07c8:
																			if (6 <= b)
																			{
																				goto IL_07d3;
																			}
																			goto IL_0825;
																			IL_07d3:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0812;
																			IL_0812:
																			num5 -= 3;
																			goto end_IL_0369;
																			IL_0825:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0830;
																			IL_0830:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_083b;
																			IL_083b:
																			array[num5] = 5;
																			goto IL_0849;
																			IL_0849:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0861;
																			IL_0861:
																			num5++;
																			goto IL_086f;
																			IL_086f:
																			ptr2 += 8;
																			goto end_IL_0369;
																		}
																		break;
																		IL_0330:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0369;
																continue;
																end_IL_0340:
																break;
															}
															continue;
															end_IL_0350:
															break;
														}
														continue;
														end_IL_0369:
														break;
													}
													continue;
												}
												goto IL_0943;
												IL_0943:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a7:
												break;
											}
											continue;
											end_IL_08ba:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08cf:
									break;
								}
								continue;
								end_IL_08df:
								break;
							}
							continue;
							end_IL_08ef:
							break;
						}
						continue;
						end_IL_0908:
						break;
					}
					continue;
					end_IL_0918:
					break;
				}
				continue;
				end_IL_0928:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 13;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 2;
									while (true)
									{
										IL_053d:
										array3[1] = int_3;
										while (true)
										{
											IL_0532:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResourceManagerStreamNotFoundName.LinuxgetCapacity);
											while (true)
											{
												IL_0528:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0515:
													if (num4 != 1)
													{
														while (true)
														{
															IL_027a:
															byte b = *ptr2;
															while (true)
															{
																IL_026a:
																ptr2++;
																while (true)
																{
																	IL_025a:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_023d:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_022d:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_021d:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										while (true)
																										{
																											IL_01f4:
																											array[num5] = 0;
																											num = 46;
																											while (true)
																											{
																												IL_01cf:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												while (true)
																												{
																													IL_01c3:
																													array2[num5] = null;
																													while (true)
																													{
																														IL_01aa:
																														num5++;
																														num = 98;
																														while (true)
																														{
																															if (num != 98)
																															{
																																if (num != 1079)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 86:
																																	goto IL_01aa;
																																case 90:
																																	goto IL_01c3;
																																case 46:
																																	goto IL_01cf;
																																case 42:
																																case 50:
																																	goto IL_01f4;
																																case 35:
																																	goto IL_020d;
																																case 63:
																																case 88:
																																	goto IL_021d;
																																case 9:
																																case 87:
																																	goto IL_022d;
																																case 78:
																																	goto IL_023d;
																																case 14:
																																	goto IL_024a;
																																case 31:
																																	goto IL_025a;
																																case 68:
																																	goto IL_026a;
																																case 11:
																																case 73:
																																	goto IL_027a;
																																case 51:
																																	goto IL_0285;
																																case 65:
																																	goto IL_0293;
																																case 16:
																																case 18:
																																	goto IL_02a1;
																																case 47:
																																	goto IL_02ac;
																																case 32:
																																case 40:
																																	goto IL_02ba;
																																case 37:
																																	goto IL_02fa;
																																case 4:
																																	goto IL_030e;
																																case 41:
																																	goto IL_032f;
																																case 36:
																																	goto IL_033d;
																																case 66:
																																	goto IL_034b;
																																case 43:
																																case 72:
																																	goto IL_035e;
																																case 34:
																																	goto IL_0390;
																																case 54:
																																case 74:
																																	goto IL_03a0;
																																case 75:
																																	goto IL_03b0;
																																case 80:
																																	goto IL_03c0;
																																case 82:
																																	goto IL_03d3;
																																case 38:
																																case 61:
																																	goto IL_03e1;
																																case 83:
																																	goto IL_03fd;
																																case 19:
																																	goto IL_040b;
																																case 0:
																																case 58:
																																	goto IL_0419;
																																case 76:
																																case 89:
																																	goto IL_0431;
																																case 25:
																																	goto IL_049f;
																																case 8:
																																case 15:
																																case 17:
																																case 22:
																																case 26:
																																case 28:
																																case 33:
																																case 44:
																																case 52:
																																case 55:
																																case 56:
																																case 57:
																																case 59:
																																case 62:
																																case 69:
																																case 71:
																																case 79:
																																case 84:
																																case 85:
																																	goto end_IL_020d;
																																case 48:
																																	goto IL_04eb;
																																case 29:
																																	goto IL_04f9;
																																case 5:
																																	goto IL_0507;
																																case 7:
																																case 10:
																																case 20:
																																case 23:
																																case 24:
																																case 27:
																																case 45:
																																case 60:
																																case 64:
																																case 67:
																																case 77:
																																	goto IL_0515;
																																case 6:
																																	goto IL_0528;
																																case 30:
																																	goto IL_0532;
																																case 2:
																																	goto IL_053d;
																																case 1:
																																	goto end_IL_0197;
																																case 70:
																																	goto end_IL_0552;
																																case 3:
																																case 91:
																																	goto end_IL_0570;
																																case 21:
																																	goto end_IL_0580;
																																case 49:
																																case 81:
																																	goto end_IL_0590;
																																case 12:
																																	goto end_IL_05a0;
																																case 13:
																																	goto end_IL_05b0;
																																case 39:
																																case 53:
																																	goto IL_05cb;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto IL_0515;
																															continue;
																															end_IL_0197:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_025a;
																										continue;
																										end_IL_020d:
																										break;
																										IL_020d:;
																									}
																									break;
																								}
																								goto IL_03a0;
																								IL_03e1:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto IL_0515;
																								IL_03a0:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_03d3;
																								IL_03d3:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_03e1;
																							}
																							break;
																						}
																						goto IL_03b0;
																						IL_0419:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_0515;
																						IL_03b0:
																						if (6 <= b)
																						{
																							goto IL_0515;
																						}
																						goto IL_03fd;
																						IL_03fd:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_040b;
																						IL_040b:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0419;
																					}
																					break;
																				}
																				goto IL_0285;
																				IL_0390:
																				ptr2 += 8;
																				goto IL_03c0;
																				IL_0285:
																				if (4 > b)
																				{
																					goto IL_0293;
																				}
																				goto IL_035e;
																				IL_0293:
																				if (2 < b)
																				{
																					goto IL_02a1;
																				}
																				goto IL_032f;
																				IL_02a1:
																				if (3 < b)
																				{
																					num = 62;
																					break;
																				}
																				goto IL_02ac;
																				IL_02ac:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_02ba;
																				IL_02ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02fa;
																				IL_02fa:
																				array[num5 - 2] = 0;
																				goto IL_030e;
																				IL_030e:
																				num5--;
																				goto IL_0515;
																				IL_03c0:
																				num5--;
																				goto IL_0515;
																				IL_032f:
																				if (2 > b)
																				{
																					goto IL_033d;
																				}
																				goto IL_0431;
																				IL_033d:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_034b;
																				IL_034b:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0431:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_049f;
																				IL_049f:
																				num5 -= 2;
																				num = 77;
																				goto IL_0515;
																				IL_035e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 34;
																				goto IL_0390;
																			}
																			break;
																			IL_024a:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04eb;
																	IL_0507:
																	ptr2 += 8;
																	goto IL_0515;
																	IL_04f9:
																	num5++;
																	goto IL_0507;
																	IL_04eb:
																	array[num5] = 0;
																	goto IL_04f9;
																	continue;
																	end_IL_025a:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_05cb;
													IL_05cb:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0552:
									break;
								}
								continue;
								end_IL_0570:
								break;
							}
							continue;
							end_IL_0580:
							break;
						}
						continue;
						end_IL_0590:
						break;
					}
					continue;
					end_IL_05a0:
					break;
				}
				continue;
				end_IL_05b0:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 98;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VectorToListAdapterMarkUsed.StackBasedReturnMessageSTOREASSEMBLYSTATUSMANIFESTONLY);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0368:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_034b:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_033b:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_032b:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_031b:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (true)
																											{
																												IL_02fb:
																												if (13 <= b)
																												{
																													while (true)
																													{
																														IL_028e:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														num = 155;
																														while (true)
																														{
																															if (num != 155)
																															{
																																if (num != 1136)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 14:
																																case 63:
																																	goto IL_028e;
																																case 143:
																																	goto IL_02fb;
																																case 26:
																																case 72:
																																	goto IL_030b;
																																case 35:
																																	goto IL_031b;
																																case 12:
																																case 117:
																																	goto IL_032b;
																																case 7:
																																case 80:
																																	goto IL_033b;
																																case 62:
																																	goto IL_034b;
																																case 48:
																																	goto IL_0358;
																																case 73:
																																	goto IL_0368;
																																case 9:
																																	goto end_IL_0368;
																																case 3:
																																case 106:
																																	goto end_IL_0378;
																																case 8:
																																	goto IL_03a1;
																																case 24:
																																case 61:
																																	goto IL_03ac;
																																case 16:
																																	goto IL_03b7;
																																case 28:
																																case 81:
																																	goto IL_03ca;
																																case 103:
																																	goto IL_03e2;
																																case 51:
																																	goto IL_03f0;
																																case 34:
																																case 41:
																																	goto IL_03fb;
																																case 79:
																																	goto IL_043a;
																																case 94:
																																case 116:
																																	goto IL_044d;
																																case 0:
																																	goto IL_045b;
																																case 45:
																																case 121:
																																	goto IL_0469;
																																case 115:
																																	goto IL_0477;
																																case 22:
																																	goto IL_048f;
																																case 84:
																																	goto IL_049d;
																																case 110:
																																case 122:
																																	goto IL_04b0;
																																case 83:
																																case 132:
																																	goto IL_04d3;
																																case 107:
																																	goto IL_04e1;
																																case 95:
																																case 129:
																																	goto IL_04ec;
																																case 88:
																																	goto IL_052c;
																																case 6:
																																	goto IL_0540;
																																case 68:
																																case 78:
																																	goto IL_055c;
																																case 17:
																																	goto IL_056a;
																																case 32:
																																case 135:
																																	goto IL_0581;
																																case 42:
																																	goto IL_059a;
																																case 27:
																																	goto IL_05a8;
																																case 138:
																																	goto IL_05b6;
																																case 139:
																																	goto IL_05c9;
																																case 109:
																																	goto IL_05d7;
																																case 76:
																																case 140:
																																	goto IL_05ea;
																																case 19:
																																	goto IL_05f8;
																																case 144:
																																	goto IL_060b;
																																case 130:
																																	goto IL_0619;
																																case 113:
																																case 118:
																																	goto IL_0627;
																																case 119:
																																	goto IL_0650;
																																case 148:
																																	goto IL_0669;
																																case 126:
																																	goto IL_0677;
																																case 55:
																																case 75:
																																	goto IL_0685;
																																case 38:
																																	goto IL_06ae;
																																case 142:
																																	goto IL_06bc;
																																case 20:
																																case 54:
																																	goto IL_06e2;
																																case 67:
																																	goto IL_06fe;
																																case 33:
																																case 46:
																																	goto IL_0709;
																																case 2:
																																	goto IL_0749;
																																case 59:
																																	goto IL_075d;
																																case 124:
																																	goto IL_0770;
																																case 23:
																																case 25:
																																	goto IL_077e;
																																case 31:
																																	goto IL_078c;
																																case 44:
																																case 82:
																																	goto IL_079a;
																																case 147:
																																	goto IL_07e7;
																																case 108:
																																	goto IL_07fb;
																																case 85:
																																	goto IL_080e;
																																case 43:
																																case 125:
																																	goto IL_0819;
																																case 21:
																																	goto IL_0827;
																																case 11:
																																	goto IL_0853;
																																case 111:
																																	goto IL_085d;
																																case 134:
																																	goto IL_0874;
																																case 18:
																																case 65:
																																	goto end_IL_027b;
																																case 123:
																																	goto IL_0898;
																																case 4:
																																case 10:
																																case 13:
																																case 29:
																																case 36:
																																case 39:
																																case 47:
																																case 49:
																																case 52:
																																case 53:
																																case 60:
																																case 69:
																																case 74:
																																case 77:
																																case 87:
																																case 91:
																																case 92:
																																case 93:
																																case 100:
																																case 102:
																																case 127:
																																case 128:
																																case 133:
																																case 136:
																																case 141:
																																	goto end_IL_02fb;
																																case 1:
																																case 5:
																																case 15:
																																case 30:
																																case 40:
																																case 50:
																																case 56:
																																case 71:
																																case 86:
																																case 90:
																																case 101:
																																case 104:
																																case 105:
																																case 112:
																																case 120:
																																case 137:
																																case 145:
																																case 146:
																																	goto end_IL_0388;
																																case 57:
																																	goto end_IL_08b6;
																																case 58:
																																	goto end_IL_08c9;
																																case 89:
																																	goto end_IL_08d3;
																																case 114:
																																	goto end_IL_08de;
																																case 70:
																																case 99:
																																	goto end_IL_08ee;
																																case 37:
																																	goto end_IL_08fe;
																																case 64:
																																case 131:
																																	goto end_IL_090e;
																																case 97:
																																	goto end_IL_091e;
																																case 98:
																																	goto end_IL_092e;
																																case 66:
																																case 96:
																																	goto IL_0949;
																																}
																																continue;
																															}
																															num5 -= 2;
																															goto end_IL_0388;
																															continue;
																															end_IL_027b:
																															break;
																														}
																														break;
																													}
																													goto IL_088d;
																												}
																												num = 47;
																												break;
																												continue;
																												end_IL_02fb:
																												break;
																											}
																											break;
																											IL_030b:;
																										}
																										break;
																									}
																									goto IL_06e2;
																									IL_06e2:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0388;
																								}
																								break;
																							}
																							goto IL_05ea;
																							IL_05f8:
																							if (15 <= b)
																							{
																							}
																							break;
																							IL_05ea:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_05f8;
																						}
																						break;
																					}
																					goto IL_06fe;
																					IL_088d:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0898;
																					IL_06fe:
																					if (12 <= b)
																					{
																						goto IL_0709;
																					}
																					goto IL_0770;
																					IL_0709:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0749;
																					IL_0749:
																					array[num5 - 2] = 0;
																					goto IL_075d;
																					IL_075d:
																					num5--;
																					goto end_IL_0388;
																					IL_0770:
																					if (10 < b)
																					{
																						goto IL_077e;
																					}
																					goto IL_080e;
																					IL_077e:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_078c;
																					IL_078c:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_079a;
																					IL_079a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					num = 147;
																					goto IL_07e7;
																					IL_07e7:
																					array[num5 - 2] = 0;
																					goto IL_07fb;
																					IL_07fb:
																					num5--;
																					goto end_IL_0388;
																					IL_080e:
																					if (10 <= b)
																					{
																						goto IL_0819;
																					}
																					num = 18;
																					goto IL_088d;
																					IL_0819:
																					array[num5] = 0;
																					goto IL_0827;
																					IL_0827:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 11;
																					goto IL_0853;
																					IL_0853:
																					array2[num5] = null;
																					goto IL_085d;
																					IL_085d:
																					num5++;
																					num = 134;
																					goto IL_0874;
																					IL_0874:
																					ptr2 += 8;
																					goto end_IL_0388;
																					IL_0898:
																					if (9 <= b)
																					{
																						goto end_IL_0388;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_03a1;
																			IL_06ae:
																			ptr2 += 8;
																			goto IL_06bc;
																			IL_03a1:
																			if (8 > b)
																			{
																				goto IL_03ac;
																			}
																			goto IL_03ca;
																			IL_03ac:
																			if (4 >= b)
																			{
																				goto IL_03b7;
																			}
																			goto IL_03e2;
																			IL_03b7:
																			if (4 <= b)
																			{
																				goto IL_04b0;
																			}
																			goto IL_04d3;
																			IL_04d3:
																			if (2 >= b)
																			{
																				goto IL_04e1;
																			}
																			goto IL_060b;
																			IL_04e1:
																			if (2 <= b)
																			{
																				goto IL_04ec;
																			}
																			num = 78;
																			goto IL_055c;
																			IL_04ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_052c;
																			IL_052c:
																			array[num5 - 2] = 0;
																			goto IL_0540;
																			IL_0540:
																			num5--;
																			goto end_IL_0388;
																			IL_06bc:
																			num5--;
																			goto end_IL_0388;
																			IL_055c:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_056a;
																			IL_056a:
																			if (1 > b)
																			{
																				break;
																			}
																			num = 135;
																			goto IL_0581;
																			IL_03ca:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0388;
																			IL_0581:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_059a;
																			IL_059a:
																			array[num5] = 0;
																			goto IL_05a8;
																			IL_05a8:
																			num5++;
																			goto IL_05b6;
																			IL_05b6:
																			ptr2 += 8;
																			goto end_IL_0388;
																			IL_060b:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0619;
																			IL_0619:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0627;
																			IL_0627:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0650;
																			IL_0650:
																			array[num5 - 1] = 5;
																			goto end_IL_0388;
																			IL_04b0:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_05c9;
																			IL_05c9:
																			ptr2 += 8;
																			goto IL_05d7;
																			IL_05d7:
																			num5--;
																			goto end_IL_0388;
																			IL_03e2:
																			if (6 >= b)
																			{
																				goto IL_03f0;
																			}
																			goto IL_0669;
																			IL_03f0:
																			if (6 <= b)
																			{
																				goto IL_03fb;
																			}
																			goto IL_044d;
																			IL_03fb:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_043a;
																			IL_043a:
																			num5 -= 3;
																			goto end_IL_0388;
																			IL_044d:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_045b;
																			IL_045b:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0469;
																			IL_0469:
																			array[num5] = 5;
																			goto IL_0477;
																			IL_0477:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_048f;
																			IL_048f:
																			num5++;
																			goto IL_049d;
																			IL_049d:
																			ptr2 += 8;
																			goto end_IL_0388;
																			IL_0669:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0677;
																			IL_0677:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0685;
																			IL_0685:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06ae;
																		}
																		break;
																		IL_0358:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0388;
																continue;
																end_IL_0368:
																break;
															}
															continue;
															end_IL_0378:
															break;
														}
														continue;
														end_IL_0388:
														break;
													}
													continue;
												}
												goto IL_0949;
												IL_0949:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b6:
												break;
											}
											continue;
											end_IL_08c9:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08de:
									break;
								}
								continue;
								end_IL_08ee:
								break;
							}
							continue;
							end_IL_08fe:
							break;
						}
						continue;
						end_IL_090e:
						break;
					}
					continue;
					end_IL_091e:
					break;
				}
				continue;
				end_IL_092e:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 133;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref descLargestWindowHeight.PermissionRequestEvidenceEventMetadata);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0319:
														byte b = *ptr2;
														while (true)
														{
															IL_0309:
															ptr2++;
															while (true)
															{
																IL_02f9:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02dc:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02cc:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02bf:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02af:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_029c:
																											if (2 >= b)
																											{
																												num = 155;
																												while (true)
																												{
																													if (num != 155)
																													{
																														if (num != 1136)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 65:
																														case 121:
																															goto IL_029c;
																														case 45:
																															goto IL_02af;
																														case 50:
																															goto IL_02bf;
																														case 143:
																															goto IL_02cc;
																														case 66:
																															goto IL_02dc;
																														case 114:
																															goto IL_02e9;
																														case 70:
																															goto IL_02f9;
																														case 139:
																															goto IL_0309;
																														case 128:
																														case 130:
																															goto IL_0319;
																														case 29:
																														case 36:
																															goto IL_0324;
																														case 1:
																															goto IL_0332;
																														case 82:
																															goto IL_0340;
																														case 22:
																														case 84:
																															goto IL_0353;
																														case 47:
																															goto IL_0361;
																														case 4:
																														case 57:
																															goto IL_036f;
																														case 81:
																															goto IL_037a;
																														case 44:
																															goto IL_0385;
																														case 68:
																															goto IL_0393;
																														case 32:
																														case 83:
																															goto IL_03a6;
																														case 62:
																															goto IL_03b4;
																														case 94:
																															goto IL_03f3;
																														case 23:
																															goto IL_0401;
																														case 106:
																															goto IL_0411;
																														case 95:
																														case 111:
																															goto IL_0421;
																														case 90:
																															goto IL_044a;
																														case 71:
																															goto IL_0458;
																														case 69:
																														case 117:
																															goto IL_046b;
																														case 118:
																															goto IL_0483;
																														case 54:
																														case 67:
																															goto IL_0491;
																														case 99:
																															goto IL_04ba;
																														case 87:
																														case 120:
																															goto IL_04d3;
																														case 17:
																															goto IL_0513;
																														case 77:
																															goto IL_0527;
																														case 75:
																														case 123:
																															goto IL_053a;
																														case 34:
																															goto IL_0545;
																														case 88:
																															goto IL_0555;
																														case 56:
																															goto IL_0563;
																														case 127:
																															goto IL_0576;
																														case 0:
																														case 129:
																															goto IL_0589;
																														case 41:
																															goto IL_0597;
																														case 74:
																														case 126:
																															goto IL_05a5;
																														case 93:
																															goto IL_0610;
																														case 80:
																														case 131:
																															goto IL_0623;
																														case 16:
																															goto IL_0662;
																														case 59:
																														case 137:
																															goto IL_0675;
																														case 125:
																															goto IL_0680;
																														case 31:
																														case 92:
																															goto IL_068e;
																														case 6:
																															goto IL_06d2;
																														case 58:
																															goto IL_06e6;
																														case 142:
																														case 145:
																															goto IL_0707;
																														case 116:
																															goto IL_0715;
																														case 85:
																															goto IL_072d;
																														case 76:
																															goto IL_073b;
																														case 146:
																															goto IL_074e;
																														case 43:
																															goto IL_0758;
																														case 102:
																															goto IL_0766;
																														case 97:
																														case 147:
																															goto IL_0782;
																														case 86:
																														case 138:
																															goto IL_07b2;
																														case 140:
																															goto IL_07f2;
																														case 40:
																															goto IL_0806;
																														case 119:
																															goto IL_0819;
																														case 141:
																															goto IL_0827;
																														case 14:
																														case 35:
																															goto IL_0835;
																														case 53:
																															goto IL_084e;
																														case 110:
																															goto IL_085c;
																														case 2:
																															goto IL_0873;
																														case 136:
																														case 148:
																															goto IL_0883;
																														case 49:
																															goto IL_08a1;
																														case 25:
																															goto IL_08af;
																														case 5:
																														case 7:
																														case 8:
																														case 12:
																														case 13:
																														case 18:
																														case 19:
																														case 20:
																														case 24:
																														case 26:
																														case 30:
																														case 33:
																														case 39:
																														case 42:
																														case 52:
																														case 55:
																														case 61:
																														case 73:
																														case 96:
																														case 101:
																														case 103:
																														case 104:
																														case 109:
																														case 112:
																														case 122:
																														case 134:
																														case 135:
																														case 144:
																															goto end_IL_02e9;
																														case 9:
																														case 11:
																														case 15:
																														case 27:
																														case 28:
																														case 37:
																														case 46:
																														case 48:
																														case 60:
																														case 63:
																														case 72:
																														case 78:
																														case 89:
																														case 98:
																														case 100:
																														case 105:
																														case 113:
																														case 115:
																															goto end_IL_0289;
																														case 3:
																															goto end_IL_08d2;
																														case 10:
																															goto end_IL_08e5;
																														case 38:
																															goto end_IL_08ef;
																														case 51:
																															goto end_IL_08fa;
																														case 91:
																														case 107:
																															goto end_IL_090a;
																														case 21:
																															goto end_IL_091a;
																														case 64:
																														case 79:
																															goto end_IL_092a;
																														case 132:
																															goto end_IL_093a;
																														case 133:
																															goto end_IL_094a;
																														case 108:
																														case 124:
																															goto IL_0965;
																														}
																														continue;
																													}
																													if (2 <= b)
																													{
																														goto IL_07b2;
																													}
																													goto IL_0819;
																													IL_084e:
																													array[num5] = 0;
																													goto IL_085c;
																													IL_0873:
																													ptr2 += 8;
																													break;
																													IL_085c:
																													num5++;
																													num = 2;
																													goto IL_0873;
																													IL_07b2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_07f2;
																													IL_07f2:
																													array[num5 - 2] = 0;
																													goto IL_0806;
																													IL_0806:
																													num5--;
																													break;
																													IL_0819:
																													if (1 < b)
																													{
																														goto end_IL_02e9;
																													}
																													goto IL_0827;
																													IL_0827:
																													if (1 > b)
																													{
																														goto end_IL_02e9;
																													}
																													goto IL_0835;
																													IL_0835:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_084e;
																													continue;
																													end_IL_0289:
																													break;
																												}
																												break;
																											}
																											goto IL_0411;
																											IL_0491:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_04ba;
																											IL_04ba:
																											array[num5 - 1] = 5;
																											break;
																											IL_0411:
																											if (3 < b)
																											{
																												goto end_IL_02e9;
																											}
																											goto IL_0483;
																											IL_0483:
																											if (3 > b)
																											{
																												goto end_IL_02e9;
																											}
																											goto IL_0491;
																										}
																										break;
																									}
																									goto IL_0883;
																									IL_08af:
																									num5--;
																									break;
																									IL_0883:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_08a1;
																									IL_08a1:
																									ptr2 += 8;
																									goto IL_08af;
																								}
																								break;
																							}
																							goto IL_0324;
																							IL_0458:
																							num5--;
																							break;
																							IL_0324:
																							if (6 >= b)
																							{
																								goto IL_0332;
																							}
																							goto IL_03f3;
																							IL_0332:
																							if (6 > b)
																							{
																								goto IL_0340;
																							}
																							goto IL_0623;
																							IL_0340:
																							if (5 < b)
																							{
																								goto end_IL_02e9;
																							}
																							goto IL_0576;
																							IL_0576:
																							if (5 > b)
																							{
																								goto end_IL_02e9;
																							}
																							goto IL_0707;
																							IL_0707:
																							array[num5] = 5;
																							goto IL_0715;
																							IL_0715:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_072d;
																							IL_072d:
																							num5++;
																							goto IL_073b;
																							IL_073b:
																							ptr2 += 8;
																							break;
																							IL_0623:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0662;
																							IL_0662:
																							num5 -= 3;
																							break;
																							IL_03f3:
																							if (7 < b)
																							{
																								goto end_IL_02e9;
																							}
																							goto IL_0401;
																							IL_0401:
																							if (7 > b)
																							{
																								goto end_IL_02e9;
																							}
																							goto IL_0421;
																							IL_0421:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_044a;
																							IL_044a:
																							ptr2 += 8;
																							goto IL_0458;
																						}
																						break;
																					}
																					goto IL_046b;
																					IL_046b:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																				}
																				break;
																			}
																			goto IL_0353;
																			IL_0782:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 100;
																			break;
																			IL_0353:
																			if (12 >= b)
																			{
																				goto IL_0361;
																			}
																			goto IL_053a;
																			IL_0361:
																			if (12 > b)
																			{
																				goto IL_036f;
																			}
																			goto IL_04d3;
																			IL_036f:
																			if (10 >= b)
																			{
																				goto IL_037a;
																			}
																			num = 137;
																			goto IL_0675;
																			IL_037a:
																			if (10 > b)
																			{
																				goto IL_0385;
																			}
																			goto IL_03a6;
																			IL_0385:
																			if (9 < b)
																			{
																				goto end_IL_02e9;
																			}
																			goto IL_0393;
																			IL_0393:
																			if (9 > b)
																			{
																				goto end_IL_02e9;
																			}
																			break;
																			IL_03a6:
																			array[num5] = 0;
																			goto IL_03b4;
																			IL_03b4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 146;
																			goto IL_074e;
																			IL_074e:
																			array2[num5] = null;
																			goto IL_0758;
																			IL_0758:
																			num5++;
																			goto IL_0766;
																			IL_0766:
																			ptr2 += 8;
																			num = 37;
																			break;
																			IL_0555:
																			if (15 < b)
																			{
																				goto end_IL_02e9;
																			}
																			goto IL_0563;
																			IL_0675:
																			if (11 < b)
																			{
																				num = 20;
																				goto end_IL_02e9;
																			}
																			goto IL_0680;
																			IL_0680:
																			if (11 > b)
																			{
																				goto end_IL_02e9;
																			}
																			goto IL_068e;
																			IL_068e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06d2;
																			IL_06d2:
																			array[num5 - 2] = 0;
																			goto IL_06e6;
																			IL_06e6:
																			num5--;
																			break;
																			IL_0563:
																			if (15 > b)
																			{
																			}
																			goto end_IL_02e9;
																			IL_04d3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0513;
																			IL_0513:
																			array[num5 - 2] = 0;
																			goto IL_0527;
																			IL_0527:
																			num5--;
																			break;
																			IL_053a:
																			if (14 >= b)
																			{
																				goto IL_0545;
																			}
																			goto IL_0555;
																			IL_0545:
																			if (14 > b)
																			{
																				goto IL_0589;
																			}
																			goto IL_0782;
																			IL_0589:
																			if (13 < b)
																			{
																				goto end_IL_02e9;
																			}
																			goto IL_0597;
																			IL_0597:
																			if (13 > b)
																			{
																				goto end_IL_02e9;
																			}
																			goto IL_05a5;
																			IL_05a5:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 93;
																			goto IL_0610;
																			IL_0610:
																			num5 -= 2;
																			break;
																		}
																		goto end_IL_02f9;
																		continue;
																		end_IL_02e9:
																		break;
																		IL_02e9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02f9:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0965;
												IL_0965:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d2:
												break;
											}
											continue;
											end_IL_08e5:
											break;
										}
										continue;
										end_IL_08ef:
										break;
									}
									continue;
									end_IL_08fa:
									break;
								}
								continue;
								end_IL_090a:
								break;
							}
							continue;
							end_IL_091a:
							break;
						}
						continue;
						end_IL_092a:
						break;
					}
					continue;
					end_IL_093a:
					break;
				}
				continue;
				end_IL_094a:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 35;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 32;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetConnectionInterfaceCreateDelegate.ProviderDefinedToBaseString);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 53;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0245:
																byte b = *ptr2;
																while (true)
																{
																	IL_0235:
																	ptr2++;
																	while (true)
																	{
																		IL_0225:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_0205:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01f8:
																							if (6 >= b)
																							{
																								while (6 > b)
																								{
																									while (5 >= b)
																									{
																										while (5 <= b)
																										{
																											while (true)
																											{
																												IL_01aa:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												num = 98;
																												while (num != 98)
																												{
																													if (num != 1079)
																													{
																														goto end_IL_01c8;
																													}
																													switch (num)
																													{
																													case 59:
																													case 83:
																														goto IL_01aa;
																													case 42:
																														goto IL_01c8;
																													case 45:
																													case 82:
																														goto IL_01d8;
																													case 73:
																														goto IL_01e8;
																													case 72:
																													case 88:
																														goto IL_01f8;
																													case 20:
																														goto IL_0205;
																													case 78:
																														goto IL_0215;
																													case 27:
																														goto IL_0225;
																													case 71:
																														goto IL_0235;
																													case 54:
																													case 77:
																														goto IL_0245;
																													case 38:
																													case 40:
																														goto IL_0250;
																													case 2:
																													case 11:
																														goto IL_025b;
																													case 84:
																														goto IL_026b;
																													case 46:
																													case 64:
																														goto IL_0279;
																													case 65:
																														goto IL_0287;
																													case 16:
																														goto IL_02aa;
																													case 85:
																														goto IL_02b4;
																													case 86:
																														goto IL_02c4;
																													case 21:
																													case 44:
																														goto IL_02d2;
																													case 90:
																														goto IL_02ee;
																													case 9:
																														goto IL_030a;
																													case 14:
																													case 55:
																														goto IL_0315;
																													case 28:
																														goto IL_033e;
																													case 43:
																														goto IL_034c;
																													case 70:
																														goto IL_035f;
																													case 19:
																													case 25:
																														goto IL_036d;
																													case 49:
																														goto IL_037b;
																													case 24:
																													case 60:
																														goto IL_0392;
																													case 74:
																														goto IL_03d2;
																													case 6:
																														goto IL_03e6;
																													case 47:
																														goto IL_03f9;
																													case 13:
																													case 62:
																														goto IL_0404;
																													case 56:
																														goto IL_040f;
																													case 3:
																													case 4:
																													case 7:
																													case 17:
																													case 22:
																													case 29:
																													case 30:
																													case 31:
																													case 33:
																													case 37:
																													case 48:
																													case 52:
																													case 68:
																													case 76:
																													case 81:
																													case 87:
																													case 89:
																														goto end_IL_01c8;
																													case 12:
																														goto IL_043d;
																													case 10:
																														goto IL_044b;
																													case 67:
																														goto IL_0459;
																													case 0:
																													case 66:
																														goto IL_0469;
																													case 79:
																														goto IL_04d7;
																													case 8:
																													case 23:
																													case 26:
																													case 36:
																													case 39:
																													case 53:
																													case 58:
																													case 61:
																													case 63:
																													case 75:
																														goto end_IL_0197;
																													case 51:
																														goto end_IL_04e5;
																													case 57:
																														goto end_IL_04f8;
																													case 80:
																														goto end_IL_050b;
																													case 41:
																														goto end_IL_0516;
																													case 91:
																														goto end_IL_052b;
																													case 32:
																														goto end_IL_0540;
																													case 50:
																														goto end_IL_0550;
																													case 69:
																														goto end_IL_0560;
																													case 5:
																													case 18:
																														goto end_IL_056b;
																													case 34:
																														goto end_IL_057b;
																													case 35:
																														goto end_IL_058b;
																													case 1:
																													case 15:
																														goto IL_05a6;
																													}
																													continue;
																													end_IL_0197:
																													break;
																												}
																												break;
																											}
																											goto end_IL_01e8;
																											continue;
																											end_IL_01c8:
																											break;
																											IL_01c8:;
																										}
																										break;
																										IL_01d8:;
																									}
																									goto end_IL_0215;
																									continue;
																									end_IL_01e8:
																									break;
																									IL_01e8:;
																								}
																								break;
																							}
																							goto IL_0250;
																							IL_02ee:
																							ptr2 += 8;
																							num = 8;
																							break;
																							IL_0250:
																							if (7 < b)
																							{
																								goto IL_025b;
																							}
																							goto IL_026b;
																							IL_025b:
																							if (8 < b)
																							{
																								goto end_IL_0215;
																							}
																							goto IL_02c4;
																							IL_02c4:
																							if (8 > b)
																							{
																								goto end_IL_0215;
																							}
																							goto IL_02d2;
																							IL_02d2:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							break;
																							IL_026b:
																							if (7 > b)
																							{
																								goto end_IL_0215;
																							}
																							goto IL_0279;
																							IL_0279:
																							array[num6] = 0;
																							goto IL_0287;
																							IL_0287:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_02aa;
																							IL_02aa:
																							array2[num6] = null;
																							goto IL_02b4;
																							IL_02b4:
																							num6++;
																							goto IL_02ee;
																						}
																						break;
																					}
																					goto IL_030a;
																					IL_0469:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_04d7;
																					IL_030a:
																					if (4 <= b)
																					{
																						goto IL_0315;
																					}
																					goto IL_035f;
																					IL_0315:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_033e;
																					IL_033e:
																					ptr2 += 8;
																					goto IL_034c;
																					IL_034c:
																					num6--;
																					break;
																					IL_035f:
																					if (2 < b)
																					{
																						goto IL_036d;
																					}
																					goto IL_03f9;
																					IL_036d:
																					if (3 < b)
																					{
																						goto end_IL_0215;
																					}
																					goto IL_037b;
																					IL_037b:
																					if (3 > b)
																					{
																						goto end_IL_0215;
																					}
																					num = 24;
																					goto IL_0392;
																					IL_04d7:
																					num6 -= 2;
																					break;
																					IL_0392:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_03d2;
																					IL_03d2:
																					array[num6 - 2] = 0;
																					goto IL_03e6;
																					IL_03e6:
																					num6--;
																					break;
																					IL_03f9:
																					if (2 > b)
																					{
																						goto IL_0404;
																					}
																					goto IL_0469;
																					IL_0404:
																					if (1 < b)
																					{
																						goto end_IL_0215;
																					}
																					goto IL_040f;
																					IL_040f:
																					if (1 > b)
																					{
																					}
																					goto end_IL_0215;
																				}
																				goto end_IL_0225;
																				continue;
																				end_IL_0215:
																				break;
																				IL_0215:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_043d;
																		IL_0459:
																		ptr2 += 8;
																		break;
																		IL_044b:
																		num6++;
																		goto IL_0459;
																		IL_043d:
																		array[num6] = 0;
																		goto IL_044b;
																		continue;
																		end_IL_0225:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05a6;
														IL_05a6:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_04e5:
														break;
													}
													continue;
													end_IL_04f8:
													break;
												}
												continue;
												end_IL_050b:
												break;
											}
											continue;
											end_IL_0516:
											break;
										}
										continue;
										end_IL_052b:
										break;
									}
									continue;
									end_IL_0540:
									break;
								}
								continue;
								end_IL_0550:
								break;
							}
							continue;
							end_IL_0560:
							break;
						}
						continue;
						end_IL_056b:
						break;
					}
					continue;
					end_IL_057b:
					break;
				}
				continue;
				end_IL_058b:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 7;
		byte[] array = default(byte[]);
		byte b = default(byte);
		int num4 = default(int);
		long[] array2 = default(long[]);
		object[] array3 = default(object[]);
		int[] array4 = default(int[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 129;
					while (true)
					{
						if (num != 129)
						{
							if (num != 1110)
							{
								goto IL_0377;
							}
							switch (num)
							{
							case 112:
								goto end_IL_0213;
							case 6:
								goto end_IL_0223;
							case 7:
								goto end_IL_022e;
							case 67:
								goto IL_0257;
							case 26:
							case 77:
								goto IL_0265;
							case 19:
								goto IL_0273;
							case 80:
								goto IL_0281;
							case 72:
								goto IL_0294;
							case 60:
								goto IL_02a7;
							case 119:
								goto IL_02b9;
							case 8:
							case 23:
							case 25:
							case 36:
							case 41:
							case 49:
							case 54:
							case 63:
							case 65:
							case 103:
							case 104:
							case 117:
							case 122:
								goto IL_02c1;
							case 51:
								goto IL_02d1;
							case 71:
								goto IL_02da;
							case 29:
								goto IL_02e3;
							case 107:
								goto IL_02fa;
							case 9:
								goto IL_0308;
							case 44:
								goto IL_0316;
							case 37:
							case 86:
								goto IL_0324;
							case 16:
								goto IL_032f;
							case 84:
								goto IL_033a;
							case 79:
							case 83:
								goto IL_0348;
							case 61:
								goto IL_035b;
							case 89:
								goto IL_0369;
							case 58:
							case 62:
								goto IL_0377;
							case 121:
								goto IL_0393;
							case 33:
							case 100:
								goto IL_039e;
							case 40:
								goto IL_03ac;
							case 76:
								goto IL_03d0;
							case 98:
								goto IL_03de;
							case 105:
								goto IL_03f1;
							case 0:
							case 78:
								goto IL_0408;
							case 85:
								goto IL_041f;
							case 15:
							case 108:
								goto IL_042d;
							case 45:
								goto IL_046d;
							case 12:
								goto IL_0481;
							case 39:
								goto IL_0494;
							case 30:
							case 94:
								goto IL_04ad;
							case 35:
								goto IL_04c6;
							case 109:
								goto IL_04d4;
							case 111:
								goto IL_04eb;
							case 68:
								goto IL_04fe;
							case 2:
								goto IL_050c;
							case 1:
							case 50:
								goto IL_051a;
							case 43:
								goto IL_0525;
							case 47:
							case 69:
								goto IL_0533;
							case 31:
								goto IL_0573;
							case 91:
								goto IL_0587;
							case 102:
								goto IL_059a;
							case 115:
								goto IL_05a8;
							case 55:
							case 81:
								goto IL_05b6;
							case 48:
								goto IL_05c4;
							case 13:
								goto IL_05f0;
							case 110:
								goto IL_05fa;
							case 21:
								goto IL_0611;
							case 32:
								goto IL_062d;
							case 87:
							case 93:
								goto IL_0638;
							case 73:
								goto IL_0661;
							case 14:
								goto IL_066f;
							case 17:
							case 70:
								goto IL_068b;
							case 10:
								goto IL_0699;
							case 82:
								goto IL_06a7;
							case 11:
							case 96:
								goto IL_06b5;
							case 57:
								goto IL_06f5;
							case 59:
								goto IL_0709;
							case 20:
								goto IL_071c;
							case 18:
							case 106:
								goto IL_072f;
							case 101:
								goto IL_0778;
							case 90:
								goto IL_078c;
							case 113:
								goto IL_079f;
							case 34:
								goto IL_07ad;
							case 92:
								goto IL_07bb;
							case 3:
							case 4:
							case 5:
							case 22:
							case 24:
							case 27:
							case 28:
							case 38:
							case 46:
							case 52:
							case 53:
							case 56:
							case 66:
							case 74:
							case 75:
							case 88:
							case 95:
							case 97:
							case 99:
							case 114:
							case 116:
							case 118:
							case 120:
								goto IL_07ce;
							case 42:
							case 64:
								goto IL_07fc;
							}
							continue;
						}
						array = new byte[3];
						goto IL_0257;
						IL_071c:
						if (1 <= b)
						{
						}
						goto IL_07ce;
						IL_0778:
						array[num4 - 2] = 0;
						goto IL_078c;
						IL_072f:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						num = 101;
						goto IL_0778;
						IL_0257:
						array3 = new object[3];
						goto IL_0265;
						IL_0265:
						array4 = new int[5];
						goto IL_0273;
						IL_0273:
						array2 = new long[3];
						goto IL_0281;
						IL_0281:
						array4[0] = int_2;
						goto IL_0294;
						IL_0294:
						array4[1] = int_3;
						goto IL_02a7;
						IL_02a7:
						ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsBitProcessgetZone.AtIdrefssetPartialTrustVisibilityLevel);
						num = 119;
						goto IL_02b9;
						IL_02b9:
						ptr2 = ptr;
						goto IL_02c1;
						IL_02c1:
						if (num5 != 1)
						{
							goto IL_02d1;
						}
						num = 42;
						goto IL_07fc;
						IL_078c:
						num4--;
						goto IL_02c1;
						IL_07fc:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						IL_02d1:
						num = 71;
						goto IL_02da;
						IL_02da:
						b = *ptr2;
						goto IL_02e3;
						IL_02e3:
						ptr2++;
						num = 107;
						goto IL_02fa;
						IL_02fa:
						if (b >= 1)
						{
							goto IL_0308;
						}
						goto IL_07ce;
						IL_0308:
						if (b <= 11)
						{
							goto IL_0316;
						}
						goto IL_07ce;
						IL_0316:
						if (6 < b)
						{
							goto IL_0324;
						}
						goto IL_04fe;
						IL_0324:
						if (9 < b)
						{
							goto IL_032f;
						}
						goto IL_0393;
						IL_032f:
						if (10 >= b)
						{
							goto IL_033a;
						}
						goto IL_035b;
						IL_033a:
						if (10 <= b)
						{
							goto IL_0348;
						}
						goto IL_07ce;
						IL_0348:
						num4--;
						goto IL_02c1;
						IL_035b:
						if (11 >= b)
						{
							goto IL_0369;
						}
						goto IL_07ce;
						IL_0369:
						if (11 <= b)
						{
							goto IL_0377;
						}
						goto IL_07ce;
						IL_0377:
						byte* num6 = ptr2;
						num5 = 1;
						ptr2 = num6 + -200;
						goto IL_02c1;
						IL_0393:
						if (9 <= b)
						{
							goto IL_039e;
						}
						goto IL_03f1;
						IL_039e:
						array[num4] = 0;
						goto IL_03ac;
						IL_03ac:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = ((delegate*<int>)IManifestInformationSetURI[*(int*)(ptr2 + num3)])();
						goto IL_03d0;
						IL_03d0:
						num4++;
						goto IL_03de;
						IL_03de:
						ptr2 += 8;
						goto IL_02c1;
						IL_03f1:
						if (7 < b)
						{
							num = 78;
							goto IL_0408;
						}
						goto IL_0494;
						IL_07ce:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array4[*(int*)(ptr2 + num3)];
						goto IL_079f;
						IL_0408:
						if (8 >= b)
						{
							num = 85;
							goto IL_041f;
						}
						goto IL_07ce;
						IL_079f:
						array[num4] = 0;
						goto IL_07ad;
						IL_041f:
						if (8 <= b)
						{
							goto IL_042d;
						}
						goto IL_07ce;
						IL_042d:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_046d;
						IL_046d:
						array[num4 - 2] = 0;
						goto IL_0481;
						IL_0481:
						num4--;
						goto IL_02c1;
						IL_0494:
						if (7 <= b)
						{
							goto IL_04ad;
						}
						num = 95;
						goto IL_07ce;
						IL_07ad:
						num4++;
						goto IL_07bb;
						IL_04ad:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = *(int*)(ptr2 + num3);
						goto IL_04c6;
						IL_04c6:
						array[num4] = 0;
						goto IL_04d4;
						IL_04d4:
						num4++;
						num = 111;
						goto IL_04eb;
						IL_04eb:
						ptr2 += 8;
						goto IL_02c1;
						IL_04fe:
						if (6 > b)
						{
							goto IL_050c;
						}
						goto IL_072f;
						IL_050c:
						if (3 < b)
						{
							goto IL_051a;
						}
						goto IL_062d;
						IL_051a:
						if (4 >= b)
						{
							goto IL_0525;
						}
						goto IL_059a;
						IL_0525:
						if (4 <= b)
						{
							goto IL_0533;
						}
						goto IL_07ce;
						IL_0533:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_0573;
						IL_0573:
						array[num4 - 2] = 0;
						goto IL_0587;
						IL_0587:
						num4--;
						goto IL_02c1;
						IL_059a:
						if (5 >= b)
						{
							goto IL_05a8;
						}
						goto IL_07ce;
						IL_05a8:
						if (5 <= b)
						{
							goto IL_05b6;
						}
						goto IL_07ce;
						IL_05b6:
						array[num4] = 0;
						goto IL_05c4;
						IL_05c4:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array4[*(int*)(ptr2 + num3)];
						num = 13;
						goto IL_05f0;
						IL_05f0:
						array3[num4] = null;
						goto IL_05fa;
						IL_05fa:
						num4++;
						num = 21;
						goto IL_0611;
						IL_0611:
						ptr2 += 8;
						num = 25;
						goto IL_02c1;
						IL_062d:
						if (3 <= b)
						{
							goto IL_0638;
						}
						num = 70;
						goto IL_068b;
						IL_0638:
						ref int reference = ref array4[*(int*)(ptr2 + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_0661;
						IL_0661:
						ptr2 += 8;
						goto IL_066f;
						IL_066f:
						num4--;
						goto IL_02c1;
						IL_07bb:
						ptr2 += 8;
						goto IL_02c1;
						IL_068b:
						if (1 < b)
						{
							goto IL_0699;
						}
						goto IL_071c;
						IL_0699:
						if (2 >= b)
						{
							goto IL_06a7;
						}
						goto IL_07ce;
						IL_06a7:
						if (2 <= b)
						{
							goto IL_06b5;
						}
						goto IL_07ce;
						IL_06b5:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_06f5;
						IL_06f5:
						array[num4 - 2] = 0;
						goto IL_0709;
						IL_0709:
						num4--;
						goto IL_02c1;
						continue;
						end_IL_0213:
						break;
					}
					continue;
					end_IL_0223:
					break;
				}
				continue;
				end_IL_022e:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnsuresgetUI.ensuresgetUI_0);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02a2:
															num = 17;
															while (true)
															{
																IL_0297:
																byte b = *ptr2;
																while (true)
																{
																	IL_0287:
																	ptr2++;
																	while (true)
																	{
																		IL_0277:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_025a:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_024d:
																							if (5 <= b)
																							{
																								while (true)
																								{
																									IL_0234:
																									array[num5] = 0;
																									num = 50;
																									while (true)
																									{
																										IL_020f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										while (true)
																										{
																											IL_0203:
																											array2[num5] = null;
																											while (true)
																											{
																												IL_01f3:
																												num5++;
																												while (true)
																												{
																													IL_01da:
																													ptr2 += 8;
																													num = 110;
																													while (num != 110)
																													{
																														if (num != 1091)
																														{
																															goto IL_03ef;
																														}
																														switch (num)
																														{
																														case 18:
																															goto IL_01da;
																														case 66:
																															goto IL_01f3;
																														case 83:
																															goto IL_0203;
																														case 50:
																															goto IL_020f;
																														case 15:
																														case 34:
																															goto IL_0234;
																														case 38:
																															goto IL_024d;
																														case 71:
																															goto IL_025a;
																														case 0:
																															goto IL_0267;
																														case 46:
																															goto IL_0277;
																														case 95:
																															goto IL_0287;
																														case 17:
																															goto IL_0297;
																														case 73:
																															goto IL_02a2;
																														case 33:
																															goto IL_02ad;
																														case 9:
																															goto IL_02bb;
																														case 3:
																														case 43:
																															goto IL_02c8;
																														case 55:
																														case 56:
																															goto IL_02d8;
																														case 26:
																															goto IL_02e6;
																														case 57:
																															goto IL_02f6;
																														case 24:
																														case 59:
																															goto IL_0304;
																														case 78:
																															goto IL_032f;
																														case 11:
																														case 82:
																															goto IL_0342;
																														case 1:
																															goto IL_0382;
																														case 90:
																															goto IL_039b;
																														case 7:
																															goto IL_03a9;
																														case 93:
																															goto IL_03c5;
																														case 21:
																														case 88:
																															goto IL_03d3;
																														case 44:
																															goto IL_03e1;
																														case 25:
																														case 77:
																															goto IL_03ef;
																														case 8:
																															goto IL_042f;
																														case 68:
																															goto IL_0443;
																														case 45:
																														case 70:
																															goto IL_0456;
																														case 61:
																															goto IL_046f;
																														case 12:
																															goto IL_047d;
																														case 72:
																															goto IL_048b;
																														case 94:
																															goto IL_049e;
																														case 54:
																														case 91:
																															goto IL_04a9;
																														case 81:
																															goto IL_04e9;
																														case 47:
																															goto IL_04fd;
																														case 29:
																															goto IL_0510;
																														case 39:
																															goto IL_051e;
																														case 99:
																															goto IL_0531;
																														case 49:
																														case 98:
																															goto IL_053f;
																														case 32:
																															goto IL_0588;
																														case 58:
																															goto IL_059c;
																														case 102:
																															goto IL_05af;
																														case 5:
																														case 103:
																															goto IL_05c2;
																														case 74:
																															goto IL_05cd;
																														case 79:
																														case 96:
																															goto IL_05d8;
																														case 10:
																														case 19:
																														case 23:
																														case 28:
																														case 30:
																														case 31:
																														case 35:
																														case 41:
																														case 51:
																														case 63:
																														case 64:
																														case 67:
																														case 69:
																														case 75:
																														case 76:
																														case 80:
																														case 92:
																															goto end_IL_0267;
																														case 85:
																															goto IL_061d;
																														case 62:
																															goto IL_0634;
																														case 42:
																															goto IL_0642;
																														case 2:
																														case 13:
																														case 20:
																														case 22:
																														case 27:
																														case 36:
																														case 52:
																														case 53:
																														case 65:
																														case 84:
																															goto end_IL_01c7;
																														case 89:
																															goto end_IL_0650;
																														case 87:
																															goto end_IL_0663;
																														case 97:
																															goto end_IL_066d;
																														case 37:
																															goto end_IL_0678;
																														case 6:
																															goto end_IL_068d;
																														case 48:
																														case 86:
																															goto end_IL_06a2;
																														case 40:
																															goto end_IL_06b2;
																														case 4:
																														case 60:
																															goto end_IL_06c2;
																														case 100:
																															goto end_IL_06d2;
																														case 101:
																															goto end_IL_06e2;
																														case 14:
																														case 16:
																															goto IL_06fd;
																														}
																														continue;
																														end_IL_01c7:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02ad;
																							IL_051e:
																							if (1 > b)
																							{
																							}
																							goto end_IL_0267;
																							IL_02ad:
																							if (2 < b)
																							{
																								goto IL_02bb;
																							}
																							goto IL_049e;
																							IL_02bb:
																							if (3 < b)
																							{
																								goto IL_02d8;
																							}
																							goto IL_02f6;
																							IL_02d8:
																							if (4 < b)
																							{
																								goto end_IL_0267;
																							}
																							goto IL_02e6;
																							IL_02e6:
																							if (4 > b)
																							{
																								goto end_IL_0267;
																							}
																							goto IL_0342;
																							IL_0342:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0382;
																							IL_0382:
																							array[num5 - 2] = 0;
																							goto IL_05af;
																							IL_05af:
																							num5--;
																							break;
																							IL_02f6:
																							if (3 > b)
																							{
																								goto end_IL_0267;
																							}
																							goto IL_0304;
																							IL_0304:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_039b;
																							IL_039b:
																							ptr2 += 8;
																							goto IL_03a9;
																							IL_03a9:
																							num5--;
																							num = 84;
																							break;
																							IL_049e:
																							if (2 <= b)
																							{
																								goto IL_04a9;
																							}
																							goto IL_0510;
																							IL_04a9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04e9;
																							IL_04e9:
																							array[num5 - 2] = 0;
																							goto IL_04fd;
																							IL_04fd:
																							num5--;
																							break;
																							IL_0510:
																							if (1 < b)
																							{
																								goto end_IL_0267;
																							}
																							goto IL_051e;
																						}
																						break;
																					}
																					goto IL_02c8;
																					IL_059c:
																					num5--;
																					break;
																					IL_02c8:
																					if (7 < b)
																					{
																						goto IL_032f;
																					}
																					goto IL_03c5;
																					IL_03c5:
																					if (7 > b)
																					{
																						goto IL_03d3;
																					}
																					goto IL_0456;
																					IL_03d3:
																					if (6 < b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_03e1;
																					IL_03e1:
																					if (6 > b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_03ef;
																					IL_03ef:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_042f;
																					IL_042f:
																					array[num5 - 2] = 0;
																					goto IL_0443;
																					IL_0443:
																					num5--;
																					break;
																					IL_0456:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_046f;
																					IL_046f:
																					array[num5] = 0;
																					goto IL_047d;
																					IL_047d:
																					num5++;
																					goto IL_048b;
																					IL_048b:
																					ptr2 += 8;
																					break;
																					IL_032f:
																					if (8 >= b)
																					{
																						goto IL_0531;
																					}
																					goto IL_05c2;
																					IL_05c2:
																					if (9 < b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_05cd;
																					IL_05cd:
																					if (9 > b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_05d8;
																					IL_05d8:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 20;
																					break;
																					IL_0531:
																					if (8 > b)
																					{
																						goto end_IL_0267;
																					}
																					goto IL_053f;
																					IL_053f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 32;
																					goto IL_0588;
																					IL_0588:
																					array[num5 - 2] = 0;
																					goto IL_059c;
																				}
																				goto end_IL_0277;
																				continue;
																				end_IL_0267:
																				break;
																				IL_0267:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_061d;
																		IL_0642:
																		ptr2 += 8;
																		break;
																		IL_0634:
																		num5++;
																		goto IL_0642;
																		IL_061d:
																		array[num5] = 0;
																		num = 62;
																		goto IL_0634;
																		continue;
																		end_IL_0277:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06fd;
													IL_06fd:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0650:
													break;
												}
												continue;
												end_IL_0663:
												break;
											}
											continue;
											end_IL_066d:
											break;
										}
										continue;
										end_IL_0678:
										break;
									}
									continue;
									end_IL_068d:
									break;
								}
								continue;
								end_IL_06a2:
								break;
							}
							continue;
							end_IL_06b2:
							break;
						}
						continue;
						end_IL_06c2:
						break;
					}
					continue;
					end_IL_06d2:
					break;
				}
				continue;
				end_IL_06e2:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2, int int_3)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_06af:
						object[] array2 = new object[3];
						while (true)
						{
							IL_069f:
							int[] array3 = new int[5];
							while (true)
							{
								IL_068f:
								long[] array4 = new long[3];
								while (true)
								{
									IL_067a:
									array3[0] = int_2;
									while (true)
									{
										IL_0665:
										array3[1] = int_3;
										while (true)
										{
											IL_065a:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AsymmetricKeyExchangeFormatterBINDOPTS.FusionTaskTransfer);
											while (true)
											{
												IL_0650:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0645:
													num = 28;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_029c:
																byte b = *ptr2;
																while (true)
																{
																	IL_028c:
																	ptr2++;
																	while (true)
																	{
																		IL_027c:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_025f:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_024f:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_0242:
																									if (7 <= b)
																									{
																										while (true)
																										{
																											IL_0227:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											while (true)
																											{
																												IL_0217:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_0207:
																													num5++;
																													while (true)
																													{
																														IL_01ee:
																														ptr2 += 8;
																														num = 115;
																														while (num != 115)
																														{
																															if (num != 1096)
																															{
																																goto end_IL_0632;
																															}
																															switch (num)
																															{
																															case 52:
																																goto IL_01ee;
																															case 72:
																																goto IL_0207;
																															case 45:
																																goto IL_0217;
																															case 40:
																															case 73:
																																goto IL_0227;
																															case 55:
																																goto IL_0242;
																															case 31:
																																goto IL_024f;
																															case 58:
																																goto IL_025f;
																															case 2:
																																goto IL_026c;
																															case 96:
																																goto IL_027c;
																															case 74:
																																goto IL_028c;
																															case 53:
																															case 77:
																																goto IL_029c;
																															case 18:
																															case 78:
																																goto IL_02a7;
																															case 98:
																																goto IL_02ba;
																															case 8:
																															case 97:
																																goto IL_02c5;
																															case 51:
																																goto IL_02d3;
																															case 41:
																															case 65:
																																goto IL_02de;
																															case 62:
																																goto IL_02ec;
																															case 12:
																															case 79:
																																goto IL_02ff;
																															case 9:
																															case 90:
																																goto IL_0344;
																															case 60:
																																goto IL_0352;
																															case 63:
																																goto IL_0375;
																															case 56:
																																goto IL_037f;
																															case 87:
																																goto IL_038d;
																															case 37:
																															case 99:
																																goto IL_03a0;
																															case 14:
																															case 92:
																																goto IL_03ae;
																															case 86:
																																goto IL_03bc;
																															case 23:
																															case 35:
																																goto IL_03c7;
																															case 42:
																																goto IL_0407;
																															case 33:
																																goto IL_041b;
																															case 1:
																																goto IL_043c;
																															case 4:
																															case 6:
																																goto IL_044a;
																															case 11:
																																goto IL_0473;
																															case 93:
																																goto IL_0481;
																															case 105:
																																goto IL_0494;
																															case 21:
																																goto IL_04a8;
																															case 106:
																																goto IL_04bb;
																															case 64:
																															case 94:
																																goto IL_04c9;
																															case 85:
																																goto IL_0509;
																															case 10:
																																goto IL_051d;
																															case 57:
																																goto IL_0539;
																															case 102:
																																goto IL_0544;
																															case 36:
																															case 82:
																																goto IL_0552;
																															case 16:
																																goto IL_0592;
																															case 88:
																																goto IL_05a6;
																															case 80:
																																goto IL_05b6;
																															case 0:
																																goto IL_05c1;
																															case 48:
																															case 89:
																																goto IL_05cc;
																															case 3:
																															case 7:
																															case 15:
																															case 17:
																															case 19:
																															case 27:
																															case 29:
																															case 30:
																															case 43:
																															case 44:
																															case 46:
																															case 47:
																															case 61:
																															case 67:
																															case 70:
																															case 83:
																															case 91:
																															case 100:
																															case 103:
																															case 107:
																															case 108:
																																goto end_IL_026c;
																															case 68:
																																goto IL_0608;
																															case 66:
																																goto IL_0616;
																															case 101:
																																goto IL_0624;
																															case 5:
																															case 24:
																															case 25:
																															case 28:
																															case 34:
																															case 39:
																															case 49:
																															case 71:
																															case 95:
																																goto end_IL_01db;
																															case 26:
																																goto IL_0645;
																															case 69:
																																goto IL_0650;
																															case 50:
																																goto IL_065a;
																															case 104:
																																goto IL_0665;
																															case 54:
																																goto IL_067a;
																															case 13:
																																goto IL_068f;
																															case 20:
																															case 59:
																																goto IL_069f;
																															case 32:
																																goto IL_06af;
																															case 38:
																															case 84:
																																goto end_IL_0632;
																															case 75:
																																goto end_IL_06bf;
																															case 76:
																																goto end_IL_06cf;
																															case 22:
																															case 81:
																																goto IL_06ea;
																															}
																															continue;
																															end_IL_01db:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02a7;
																									IL_051d:
																									num5--;
																									num = 71;
																									break;
																									IL_02a7:
																									if (6 < b)
																									{
																										goto end_IL_026c;
																									}
																									goto IL_04bb;
																									IL_04bb:
																									if (6 > b)
																									{
																										goto end_IL_026c;
																									}
																									goto IL_04c9;
																									IL_04c9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0509;
																									IL_0509:
																									array[num5 - 2] = 0;
																									goto IL_051d;
																								}
																								break;
																							}
																							goto IL_0539;
																							IL_05cc:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_0539:
																							if (8 >= b)
																							{
																								goto IL_0544;
																							}
																							goto IL_05b6;
																							IL_0544:
																							if (8 > b)
																							{
																								goto end_IL_026c;
																							}
																							goto IL_0552;
																							IL_0552:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0592;
																							IL_0592:
																							array[num5 - 2] = 0;
																							goto IL_05a6;
																							IL_05a6:
																							num5--;
																							break;
																							IL_05b6:
																							if (9 < b)
																							{
																								goto end_IL_026c;
																							}
																							goto IL_05c1;
																							IL_05c1:
																							if (9 > b)
																							{
																								goto end_IL_026c;
																							}
																							goto IL_05cc;
																						}
																						break;
																					}
																					goto IL_02ba;
																					IL_037f:
																					num5++;
																					goto IL_038d;
																					IL_02ba:
																					if (5 > b)
																					{
																						goto IL_02c5;
																					}
																					goto IL_0344;
																					IL_02c5:
																					if (2 >= b)
																					{
																						goto IL_02d3;
																					}
																					goto IL_03a0;
																					IL_02d3:
																					if (2 > b)
																					{
																						goto IL_02de;
																					}
																					goto IL_02ff;
																					IL_02de:
																					if (1 < b)
																					{
																						goto end_IL_026c;
																					}
																					goto IL_02ec;
																					IL_02ec:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_026c;
																					IL_02ff:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0494;
																					IL_0494:
																					array[num5 - 2] = 0;
																					goto IL_04a8;
																					IL_04a8:
																					num5--;
																					break;
																					IL_03a0:
																					if (3 < b)
																					{
																						goto IL_03ae;
																					}
																					goto IL_043c;
																					IL_03ae:
																					if (4 < b)
																					{
																						goto end_IL_026c;
																					}
																					goto IL_03bc;
																					IL_03bc:
																					if (4 > b)
																					{
																						num = 17;
																						goto end_IL_026c;
																					}
																					goto IL_03c7;
																					IL_03c7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0407;
																					IL_0407:
																					array[num5 - 2] = 0;
																					goto IL_041b;
																					IL_041b:
																					num5--;
																					break;
																					IL_038d:
																					ptr2 += 8;
																					break;
																					IL_043c:
																					if (3 > b)
																					{
																						goto end_IL_026c;
																					}
																					goto IL_044a;
																					IL_044a:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0473;
																					IL_0473:
																					ptr2 += 8;
																					goto IL_0481;
																					IL_0481:
																					num5--;
																					break;
																					IL_0344:
																					array[num5] = 0;
																					goto IL_0352;
																					IL_0352:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0375;
																					IL_0375:
																					array2[num5] = null;
																					goto IL_037f;
																				}
																				goto end_IL_027c;
																				continue;
																				end_IL_026c:
																				break;
																				IL_026c:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0608;
																		IL_0624:
																		ptr2 += 8;
																		break;
																		IL_0616:
																		num5++;
																		goto IL_0624;
																		IL_0608:
																		array[num5] = 0;
																		goto IL_0616;
																		continue;
																		end_IL_027c:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_06ea;
														IL_06ea:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0632:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_06bf:
					break;
				}
				continue;
				end_IL_06cf:
				break;
			}
		}
	}
}
