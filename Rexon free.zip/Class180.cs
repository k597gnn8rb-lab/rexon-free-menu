using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Grapple Hook", "Rig", "Right grip + trigger to grapple.", false, 24, ModType.const_0, false)]
internal class Class180 : MonoBehaviour
{
	private LineRenderer lineRenderer_0;

	private Vector3 vector3_0;

	private bool bool_0;

	private Rigidbody rigidbody_0;

	private static bool bool_1;

	private static float float_0;

	private static bool bool_2;

	private static int int_0;

	private static double double_0;

	private static IntPtr[] HebrewEraBindToStorage;

	private static IntPtr[] GetObjectIsCallback;

	private static IntPtr[] AsyncProcessMessageBestFitDisabled;

	private static IntPtr[] ProcessorValidLPArray;

	private static IntPtr[] intptr_0;

	private static IntPtr[] getAlgorithmTypeReAllocHGlobal;

	private static IntPtr[] TotalFreeSpaceRSAPKCSSignatureDeformatter;

	private static Vector3 getByteCapacityAuditRuleFactory(ref Vector3 vector3_1)
	{
		return vector3_1.normalized;
	}

	private static Vector3 getPrivateBinPathProbePrincipalPermission()
	{
		return global::_003CModule_003E.vector3_129;
	}

	private unsafe void Update()
	{
		int num = 2;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				IL_009c:
				int num3 = 0;
				while (true)
				{
					IL_0097:
					num3 = 0;
					while (true)
					{
						IL_008c:
						if (num3 == 56)
						{
							while (true)
							{
								IL_007e:
								num3 = 0;
								num = 14;
								while (true)
								{
									if (num != 14)
									{
										if (num != 995)
										{
											break;
										}
										switch (num)
										{
										case 0:
											break;
										default:
											continue;
										case 7:
											goto IL_007e;
										case 3:
										case 5:
											goto IL_008c;
										case 4:
											goto IL_0097;
										case 1:
											goto IL_009c;
										case 2:
											goto end_IL_0071;
										case 6:
											return;
										}
										goto IL_000e;
									}
									return;
									continue;
									end_IL_0071:
									break;
								}
								break;
							}
							break;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class180, void>)GetObjectIsCallback[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
						num = 5;
					}
					break;
				}
				break;
			}
		}
	}

	private static Vector3 smethod_0(Transform transform_0)
	{
		return transform_0.position;
	}

	private static float HebrewNumberParsingContextRestore(float float_1, float float_2, float float_3)
	{
		return Mathf.Clamp(float_1, float_2, float_3);
	}

	private static double getDefaultRequestSetEndOfString(double double_1)
	{
		return Math.Log10(double_1);
	}

	private unsafe void method_0()
	{
		int num = 200;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SoapNameDuplicateIdentityOption.ExceptionMessageKindSTORECATEGORY);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_05dc:
															num = 159;
															while (true)
															{
																IL_05d1:
																byte b = *ptr2;
																while (true)
																{
																	IL_05c1:
																	ptr2++;
																	while (true)
																	{
																		IL_05b1:
																		if (b >= 1)
																		{
																			while (b <= 34)
																			{
																				while (true)
																				{
																					IL_0594:
																					if (17 < b)
																					{
																						while (true)
																						{
																							IL_0581:
																							if (26 >= b)
																							{
																								num = 65;
																								while (true)
																								{
																									IL_0571:
																									if (26 > b)
																									{
																										while (true)
																										{
																											IL_0561:
																											if (21 >= b)
																											{
																												while (true)
																												{
																													IL_0551:
																													if (21 > b)
																													{
																														while (true)
																														{
																															IL_0541:
																															if (19 < b)
																															{
																																while (20 >= b)
																																{
																																	while (20 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_0506:
																																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																																			while (true)
																																			{
																																				IL_04f6:
																																				array[num6] = 3;
																																				while (true)
																																				{
																																					IL_04dd:
																																					num6++;
																																					num = 170;
																																					while (true)
																																					{
																																						IL_04c4:
																																						ptr2 += 16;
																																						num = 293;
																																						while (num != 293)
																																						{
																																							if (num != 1274)
																																							{
																																								goto IL_0cea;
																																							}
																																							switch (num)
																																							{
																																							case 170:
																																								goto IL_04c4;
																																							case 38:
																																								goto IL_04dd;
																																							case 56:
																																								goto IL_04f6;
																																							case 114:
																																							case 194:
																																								goto IL_0506;
																																							case 26:
																																								goto IL_0521;
																																							case 71:
																																								goto IL_0531;
																																							case 53:
																																								goto IL_0541;
																																							case 106:
																																								goto IL_0551;
																																							case 2:
																																								goto IL_0561;
																																							case 65:
																																								goto IL_0571;
																																							case 175:
																																								goto IL_0581;
																																							case 111:
																																								goto IL_0594;
																																							case 15:
																																								goto IL_05a1;
																																							case 255:
																																								goto IL_05b1;
																																							case 132:
																																								goto IL_05c1;
																																							case 159:
																																								goto IL_05d1;
																																							case 96:
																																								goto IL_05dc;
																																							case 55:
																																								goto IL_05e7;
																																							case 35:
																																							case 68:
																																								goto IL_05f5;
																																							case 50:
																																								goto IL_062d;
																																							case 5:
																																								goto IL_0641;
																																							case 134:
																																								goto IL_0654;
																																							case 54:
																																								goto IL_065f;
																																							case 81:
																																							case 85:
																																								goto IL_066d;
																																							case 72:
																																								goto IL_0683;
																																							case 130:
																																								goto IL_0691;
																																							case 24:
																																								goto IL_069c;
																																							case 42:
																																								goto IL_06aa;
																																							case 165:
																																								goto IL_06c6;
																																							case 211:
																																								goto IL_06d9;
																																							case 73:
																																								goto IL_0718;
																																							case 256:
																																								goto IL_072b;
																																							case 174:
																																								goto IL_0736;
																																							case 112:
																																							case 152:
																																								goto IL_0741;
																																							case 64:
																																								goto IL_076f;
																																							case 59:
																																								goto IL_0782;
																																							case 254:
																																								goto IL_0795;
																																							case 75:
																																								goto IL_07a3;
																																							case 260:
																																								goto IL_07b6;
																																							case 43:
																																								goto IL_07c4;
																																							case 201:
																																								goto IL_07d2;
																																							case 79:
																																							case 210:
																																								goto IL_07dd;
																																							case 36:
																																								goto IL_07f6;
																																							case 88:
																																								goto IL_0804;
																																							case 93:
																																								goto IL_0812;
																																							case 214:
																																								goto IL_0825;
																																							case 187:
																																								goto IL_0833;
																																							case 51:
																																							case 213:
																																								goto IL_083e;
																																							case 224:
																																								goto IL_08a0;
																																							case 151:
																																								goto IL_08b3;
																																							case 258:
																																								goto IL_08c1;
																																							case 4:
																																								goto IL_08dd;
																																							case 21:
																																								goto IL_08eb;
																																							case 163:
																																								goto IL_08fe;
																																							case 12:
																																								goto IL_090c;
																																							case 141:
																																								goto IL_0917;
																																							case 44:
																																								goto IL_0925;
																																							case 34:
																																							case 157:
																																								goto IL_0933;
																																							case 181:
																																							case 226:
																																								goto IL_094b;
																																							case 153:
																																								goto IL_098c;
																																							case 228:
																																								goto IL_09a0;
																																							case 62:
																																								goto IL_09b3;
																																							case 196:
																																								goto IL_09be;
																																							case 123:
																																							case 193:
																																								goto IL_09cc;
																																							case 150:
																																								goto IL_0a23;
																																							case 202:
																																								goto IL_0a31;
																																							case 9:
																																							case 119:
																																								goto IL_0a3f;
																																							case 32:
																																								goto IL_0a5c;
																																							case 60:
																																							case 249:
																																								goto IL_0a67;
																																							case 179:
																																								goto IL_0a7a;
																																							case 128:
																																								goto IL_0a88;
																																							case 127:
																																								goto IL_0a96;
																																							case 171:
																																								goto IL_0aa4;
																																							case 47:
																																								goto IL_0aaf;
																																							case 146:
																																								goto IL_0abd;
																																							case 33:
																																							case 208:
																																								goto IL_0acb;
																																							case 242:
																																								goto IL_0ae4;
																																							case 216:
																																								goto IL_0af2;
																																							case 209:
																																								goto IL_0b00;
																																							case 28:
																																							case 240:
																																								goto IL_0b1c;
																																							case 13:
																																								goto IL_0b5c;
																																							case 11:
																																								goto IL_0b70;
																																							case 120:
																																								goto IL_0b83;
																																							case 167:
																																								goto IL_0b91;
																																							case 0:
																																							case 92:
																																								goto IL_0b9f;
																																							case 183:
																																								goto IL_0bc8;
																																							case 188:
																																								goto IL_0bd6;
																																							case 195:
																																							case 207:
																																								goto IL_0be9;
																																							case 109:
																																								goto IL_0bf7;
																																							case 98:
																																								goto IL_0c23;
																																							case 197:
																																								goto IL_0c2d;
																																							case 172:
																																								goto IL_0c3b;
																																							case 184:
																																								goto IL_0c4e;
																																							case 192:
																																								goto IL_0c5c;
																																							case 45:
																																								goto IL_0c6a;
																																							case 99:
																																							case 251:
																																								goto IL_0c78;
																																							case 22:
																																								goto IL_0cb8;
																																							case 122:
																																								goto IL_0ccc;
																																							case 261:
																																								goto IL_0cdf;
																																							case 137:
																																							case 218:
																																								goto IL_0cea;
																																							case 219:
																																								goto IL_0cfe;
																																							case 136:
																																								goto IL_0d3d;
																																							case 90:
																																								goto IL_0d50;
																																							case 191:
																																								goto IL_0d5e;
																																							case 262:
																																								goto IL_0d71;
																																							case 263:
																																								goto IL_0d84;
																																							case 80:
																																							case 101:
																																								goto IL_0d9b;
																																							case 124:
																																								goto IL_0ddb;
																																							case 241:
																																								goto IL_0def;
																																							case 133:
																																							case 264:
																																								goto IL_0e02;
																																							case 230:
																																								goto IL_0e40;
																																							case 225:
																																								goto IL_0e4e;
																																							case 267:
																																								goto IL_0e61;
																																							case 147:
																																								goto IL_0e6f;
																																							case 86:
																																								goto IL_0e7d;
																																							case 156:
																																							case 276:
																																								goto IL_0e99;
																																							case 118:
																																								goto IL_0ed9;
																																							case 46:
																																								goto IL_0eed;
																																							case 277:
																																								goto IL_0f00;
																																							case 205:
																																								goto IL_0f0b;
																																							case 108:
																																								goto IL_0f19;
																																							case 52:
																																							case 83:
																																								goto IL_0f27;
																																							case 78:
																																								goto IL_0f31;
																																							case 30:
																																								goto IL_0f3f;
																																							case 27:
																																							case 139:
																																								goto IL_0f5b;
																																							case 185:
																																								goto IL_0f6f;
																																							case 180:
																																								goto IL_0fbc;
																																							case 233:
																																								goto IL_0fca;
																																							case 245:
																																							case 278:
																																								goto IL_0fdd;
																																							case 270:
																																								goto IL_101b;
																																							case 145:
																																								goto IL_1029;
																																							case 131:
																																							case 281:
																																								goto IL_103c;
																																							case 282:
																																								goto IL_1058;
																																							case 125:
																																							case 155:
																																								goto IL_1066;
																																							case 212:
																																								goto IL_10a6;
																																							case 67:
																																								goto IL_10ba;
																																							case 285:
																																								goto IL_10cd;
																																							case 113:
																																								goto IL_10db;
																																							case 97:
																																							case 247:
																																								goto IL_10e9;
																																							case 69:
																																								goto IL_1129;
																																							case 176:
																																								goto IL_113d;
																																							case 116:
																																							case 129:
																																								goto IL_1150;
																																							case 84:
																																								goto IL_1164;
																																							case 275:
																																								goto IL_11a3;
																																							case 252:
																																								goto IL_11b6;
																																							case 189:
																																								goto IL_11c4;
																																							case 232:
																																								goto IL_11d2;
																																							case 266:
																																								goto IL_11e0;
																																							case 7:
																																							case 29:
																																								goto IL_11ee;
																																							case 144:
																																								goto IL_122e;
																																							case 74:
																																								goto IL_1242;
																																							case 223:
																																							case 283:
																																								goto IL_1255;
																																							case 41:
																																								goto IL_1269;
																																							case 20:
																																								goto IL_12a8;
																																							case 91:
																																								goto IL_12bb;
																																							case 77:
																																								goto IL_12c9;
																																							case 135:
																																								goto IL_12e0;
																																							case 23:
																																							case 234:
																																								goto IL_12ee;
																																							case 66:
																																								goto IL_1302;
																																							case 253:
																																								goto IL_134f;
																																							case 265:
																																								goto IL_135d;
																																							case 273:
																																								goto IL_1379;
																																							case 3:
																																							case 154:
																																								goto IL_1387;
																																							case 162:
																																								goto IL_13c8;
																																							case 158:
																																								goto IL_13dc;
																																							case 143:
																																							case 203:
																																								goto IL_13f5;
																																							case 204:
																																								goto IL_1409;
																																							case 279:
																																								goto IL_1448;
																																							case 8:
																																							case 16:
																																							case 17:
																																							case 18:
																																							case 19:
																																							case 31:
																																							case 39:
																																							case 48:
																																							case 70:
																																							case 76:
																																							case 94:
																																							case 102:
																																							case 105:
																																							case 115:
																																							case 117:
																																							case 121:
																																							case 138:
																																							case 140:
																																							case 148:
																																							case 161:
																																							case 173:
																																							case 178:
																																							case 190:
																																							case 198:
																																							case 215:
																																							case 220:
																																							case 221:
																																							case 235:
																																							case 238:
																																							case 244:
																																							case 257:
																																							case 268:
																																							case 272:
																																							case 274:
																																							case 280:
																																							case 284:
																																							case 286:
																																								goto end_IL_0521;
																																							case 1:
																																							case 6:
																																							case 10:
																																							case 14:
																																							case 40:
																																							case 57:
																																							case 58:
																																							case 61:
																																							case 82:
																																							case 89:
																																							case 95:
																																							case 103:
																																							case 104:
																																							case 107:
																																							case 110:
																																							case 142:
																																							case 149:
																																							case 160:
																																							case 164:
																																							case 168:
																																							case 169:
																																							case 177:
																																							case 186:
																																							case 206:
																																							case 217:
																																							case 231:
																																							case 236:
																																							case 237:
																																							case 239:
																																							case 243:
																																							case 246:
																																							case 248:
																																							case 250:
																																							case 259:
																																							case 269:
																																							case 271:
																																								goto end_IL_04b1;
																																							case 222:
																																								goto end_IL_146b;
																																							case 182:
																																								goto end_IL_147e;
																																							case 63:
																																								goto end_IL_1488;
																																							case 87:
																																								goto end_IL_1493;
																																							case 227:
																																								goto end_IL_14a3;
																																							case 166:
																																							case 229:
																																								goto end_IL_14b3;
																																							case 100:
																																								goto end_IL_14c3;
																																							case 37:
																																								goto end_IL_14d3;
																																							case 126:
																																								goto end_IL_14e3;
																																							case 199:
																																								goto end_IL_14f3;
																																							case 200:
																																								goto end_IL_1503;
																																							case 25:
																																							case 49:
																																								return;
																																							}
																																							continue;
																																							end_IL_04b1:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_05b1;
																																		continue;
																																		end_IL_0521:
																																		break;
																																		IL_0521:;
																																	}
																																	break;
																																	IL_0531:;
																																}
																																break;
																															}
																															goto IL_0f00;
																															IL_0fbc:
																															num6--;
																															goto IL_0fca;
																															IL_0f00:
																															if (19 > b)
																															{
																																goto IL_0f0b;
																															}
																															num = 27;
																															goto IL_0f5b;
																															IL_0f0b:
																															if (18 < b)
																															{
																																break;
																															}
																															goto IL_0f19;
																															IL_0f19:
																															if (18 > b)
																															{
																																break;
																															}
																															goto IL_0f27;
																															IL_0f27:
																															array2[num6] = null;
																															goto IL_0f31;
																															IL_0f31:
																															array[num6] = 5;
																															goto IL_0f3f;
																															IL_0f3f:
																															num6++;
																															goto end_IL_05b1;
																															IL_0fca:
																															ptr2 += 8;
																															goto end_IL_05b1;
																															IL_0f5b:
																															array[num6 - 2] = 0;
																															goto IL_0f6f;
																															IL_0f6f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((LineRenderer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																															goto IL_0fbc;
																														}
																														break;
																													}
																													goto IL_1150;
																													IL_11a3:
																													ptr2 += 8;
																													goto end_IL_05b1;
																													IL_1150:
																													array[num6 - 1] = 3;
																													goto IL_1164;
																													IL_1164:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_11a3;
																												}
																												break;
																											}
																											goto IL_11b6;
																											IL_1387:
																											array2[num6 - 1] = ((delegate*<Class180, Rigidbody>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((Class180)array2[num6 - 1]);
																											num = 162;
																											goto IL_13c8;
																											IL_11b6:
																											if (23 >= b)
																											{
																												goto IL_11c4;
																											}
																											goto IL_12bb;
																											IL_11c4:
																											if (23 > b)
																											{
																												goto IL_11d2;
																											}
																											goto IL_1255;
																											IL_11d2:
																											if (22 < b)
																											{
																												break;
																											}
																											goto IL_11e0;
																											IL_11e0:
																											if (22 > b)
																											{
																												break;
																											}
																											goto IL_11ee;
																											IL_11ee:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_122e;
																											IL_122e:
																											array[num6 - 2] = 3;
																											goto IL_1242;
																											IL_1242:
																											num6--;
																											goto end_IL_05b1;
																											IL_1255:
																											array[num6 - 1] = 0;
																											goto IL_1269;
																											IL_1269:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_12a8;
																											IL_12a8:
																											ptr2 += 8;
																											goto end_IL_05b1;
																											IL_12bb:
																											if (24 < b)
																											{
																												goto IL_12c9;
																											}
																											num = 273;
																											goto IL_1379;
																											IL_12c9:
																											if (25 < b)
																											{
																												break;
																											}
																											num = 135;
																											goto IL_12e0;
																											IL_13dc:
																											ptr2 += 8;
																											goto end_IL_05b1;
																											IL_12e0:
																											if (25 > b)
																											{
																												break;
																											}
																											goto IL_12ee;
																											IL_12ee:
																											array[num6 - 2] = 0;
																											goto IL_1302;
																											IL_1302:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																											goto IL_134f;
																											IL_134f:
																											num6--;
																											goto IL_135d;
																											IL_135d:
																											ptr2 += 8;
																											goto end_IL_05b1;
																											IL_13c8:
																											array[num6 - 1] = 5;
																											goto IL_13dc;
																											IL_1379:
																											if (24 > b)
																											{
																												break;
																											}
																											goto IL_1387;
																										}
																										break;
																									}
																									num = 143;
																									goto IL_13f5;
																									IL_1409:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_1448;
																									IL_1448:
																									ptr2 += 8;
																									goto end_IL_05b1;
																									IL_13f5:
																									array[num6 - 1] = 3;
																									goto IL_1409;
																								}
																								break;
																							}
																							goto IL_0654;
																							IL_0fdd:
																							((delegate*<Renderer, bool, void>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((LineRenderer)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																							goto IL_101b;
																							IL_101b:
																							num6 -= 2;
																							goto IL_1029;
																							IL_0654:
																							if (30 >= b)
																							{
																								goto IL_065f;
																							}
																							goto IL_0683;
																							IL_065f:
																							if (30 <= b)
																							{
																								goto IL_066d;
																							}
																							goto IL_072b;
																							IL_066d:
																							array[num6 - 1] = 3;
																							goto IL_06d9;
																							IL_06d9:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0718;
																							IL_0718:
																							ptr2 += 8;
																							goto end_IL_05b1;
																							IL_072b:
																							if (28 >= b)
																							{
																								goto IL_0736;
																							}
																							goto IL_0795;
																							IL_0736:
																							if (28 <= b)
																							{
																								goto IL_0741;
																							}
																							goto IL_0782;
																							IL_0741:
																							((Class180)array2[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																							goto IL_076f;
																							IL_076f:
																							num6 -= 2;
																							goto end_IL_05b1;
																							IL_0782:
																							if (27 < b)
																							{
																								break;
																							}
																							goto IL_1058;
																							IL_1058:
																							if (27 > b)
																							{
																								break;
																							}
																							goto IL_1066;
																							IL_1066:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_10a6;
																							IL_10a6:
																							array[num6 - 2] = 3;
																							goto IL_10ba;
																							IL_10ba:
																							num6--;
																							goto end_IL_05b1;
																							IL_0795:
																							if (29 < b)
																							{
																								break;
																							}
																							goto IL_07a3;
																							IL_07a3:
																							if (29 > b)
																							{
																								break;
																							}
																							goto IL_0e02;
																							IL_0e02:
																							((delegate*<Rigidbody, bool, void>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																							goto IL_0e40;
																							IL_0e40:
																							num6 -= 2;
																							goto IL_0e4e;
																							IL_0e4e:
																							ptr2 += 8;
																							goto end_IL_05b1;
																							IL_0683:
																							if (32 < b)
																							{
																								goto IL_0691;
																							}
																							goto IL_0cdf;
																							IL_0691:
																							if (33 < b)
																							{
																								goto IL_069c;
																							}
																							goto IL_06c6;
																							IL_069c:
																							if (34 < b)
																							{
																								break;
																							}
																							goto IL_06aa;
																							IL_06aa:
																							if (34 <= b)
																							{
																								num = 257;
																							}
																							break;
																							IL_1029:
																							ptr2 += 8;
																							goto end_IL_05b1;
																							IL_06c6:
																							if (33 > b)
																							{
																								break;
																							}
																							goto IL_103c;
																							IL_103c:
																							byte* num7 = ptr2;
																							num5 = 1;
																							ptr2 = num7 + -200;
																							goto end_IL_05b1;
																							IL_0cdf:
																							if (32 <= b)
																							{
																								goto IL_0cea;
																							}
																							goto IL_0d50;
																							IL_0cea:
																							array[num6 - 1] = 3;
																							goto IL_0cfe;
																							IL_0cfe:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0d3d;
																							IL_0d3d:
																							ptr2 += 8;
																							goto end_IL_05b1;
																							IL_0d50:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_0d5e;
																							IL_0d5e:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_0fdd;
																						}
																						break;
																					}
																					goto IL_05e7;
																					IL_10db:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_10e9;
																					IL_05e7:
																					if (17 <= b)
																					{
																						goto IL_05f5;
																					}
																					goto IL_07b6;
																					IL_05f5:
																					array2[num6 - 1] = ((delegate*<Class180, LineRenderer>)ProcessorValidLPArray[*(int*)(ptr2 + num3)])((Class180)array2[num6 - 1]);
																					goto IL_062d;
																					IL_062d:
																					array[num6 - 1] = 5;
																					goto IL_0641;
																					IL_0641:
																					ptr2 += 8;
																					goto end_IL_05b1;
																					IL_07b6:
																					if (8 < b)
																					{
																						goto IL_07c4;
																					}
																					goto IL_0a5c;
																					IL_07c4:
																					if (12 >= b)
																					{
																						goto IL_07d2;
																					}
																					goto IL_08fe;
																					IL_07d2:
																					if (12 <= b)
																					{
																						goto IL_07dd;
																					}
																					goto IL_0825;
																					IL_07dd:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																					goto IL_07f6;
																					IL_07f6:
																					array[num6] = 1;
																					goto IL_0804;
																					IL_0804:
																					num6++;
																					goto IL_0812;
																					IL_0812:
																					ptr2 += 16;
																					goto end_IL_05b1;
																					IL_0825:
																					if (10 >= b)
																					{
																						goto IL_0833;
																					}
																					goto IL_08dd;
																					IL_0833:
																					if (10 <= b)
																					{
																						goto IL_083e;
																					}
																					goto IL_08b3;
																					IL_083e:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_08a0;
																					IL_08a0:
																					num6 -= 2;
																					goto end_IL_05b1;
																					IL_08b3:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_08c1;
																					IL_08c1:
																					if (9 > b)
																					{
																						break;
																					}
																					num = 156;
																					goto IL_0e99;
																					IL_10e9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1129;
																					IL_0e99:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0ed9;
																					IL_0ed9:
																					array[num6 - 2] = 0;
																					goto IL_0eed;
																					IL_0eed:
																					num6--;
																					goto end_IL_05b1;
																					IL_08dd:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_08eb;
																					IL_08eb:
																					if (11 > b)
																					{
																						break;
																					}
																					goto end_IL_05b1;
																					IL_08fe:
																					if (14 >= b)
																					{
																						goto IL_090c;
																					}
																					goto IL_09b3;
																					IL_090c:
																					if (14 > b)
																					{
																						goto IL_0917;
																					}
																					goto IL_094b;
																					IL_0917:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0925;
																					IL_0925:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0933;
																					IL_0933:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_05b1;
																					IL_094b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																					goto IL_098c;
																					IL_098c:
																					array[num6 - 2] = 0;
																					goto IL_09a0;
																					IL_09a0:
																					num6--;
																					goto end_IL_05b1;
																					IL_09b3:
																					if (15 >= b)
																					{
																						goto IL_09be;
																					}
																					goto IL_0a23;
																					IL_09be:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_09cc;
																					IL_09cc:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0d71;
																					IL_0d71:
																					num6--;
																					goto end_IL_05b1;
																					IL_0a23:
																					if (16 < b)
																					{
																						break;
																					}
																					goto IL_0a31;
																					IL_0a31:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0a3f;
																					IL_0a3f:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0e61;
																					IL_0e61:
																					array[num6] = 5;
																					goto IL_0e6f;
																					IL_0e6f:
																					num6++;
																					goto IL_0e7d;
																					IL_0e7d:
																					ptr2 += 8;
																					num = 6;
																					goto end_IL_05b1;
																					IL_0a5c:
																					if (8 <= b)
																					{
																						goto IL_0a67;
																					}
																					goto IL_0a7a;
																					IL_0a67:
																					num6--;
																					goto end_IL_05b1;
																					IL_0a7a:
																					if (4 >= b)
																					{
																						goto IL_0a88;
																					}
																					goto IL_0c4e;
																					IL_0a88:
																					if (4 > b)
																					{
																						goto IL_0a96;
																					}
																					goto IL_0be9;
																					IL_0a96:
																					if (2 >= b)
																					{
																						goto IL_0aa4;
																					}
																					goto IL_0b83;
																					IL_0aa4:
																					if (2 > b)
																					{
																						goto IL_0aaf;
																					}
																					num = 28;
																					goto IL_0b1c;
																					IL_0aaf:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0abd;
																					IL_0abd:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_0acb;
																					IL_0acb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0ae4;
																					IL_0ae4:
																					array[num6] = 0;
																					goto IL_0af2;
																					IL_0af2:
																					num6++;
																					goto IL_0b00;
																					IL_0b00:
																					ptr2 += 8;
																					goto end_IL_05b1;
																					IL_1129:
																					array[num6 - 2] = 0;
																					goto IL_113d;
																					IL_0b1c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0b5c;
																					IL_0b5c:
																					array[num6 - 2] = 0;
																					goto IL_0b70;
																					IL_0b70:
																					num6--;
																					goto end_IL_05b1;
																					IL_0b83:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0b91;
																					IL_0b91:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0b9f;
																					IL_0b9f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0bc8;
																					IL_0bc8:
																					ptr2 += 8;
																					goto IL_0bd6;
																					IL_0bd6:
																					num6--;
																					goto end_IL_05b1;
																					IL_0be9:
																					array[num6] = 0;
																					goto IL_0bf7;
																					IL_0bf7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					num = 98;
																					goto IL_0c23;
																					IL_0c23:
																					array2[num6] = null;
																					goto IL_0c2d;
																					IL_0c2d:
																					num6++;
																					goto IL_0c3b;
																					IL_0c3b:
																					ptr2 += 8;
																					goto end_IL_05b1;
																					IL_0c4e:
																					if (6 < b)
																					{
																						goto IL_0c5c;
																					}
																					goto IL_0d84;
																					IL_0c5c:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0c6a;
																					IL_0c6a:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0c78;
																					IL_0c78:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0cb8;
																					IL_0cb8:
																					array[num6 - 2] = 0;
																					goto IL_0ccc;
																					IL_0ccc:
																					num6--;
																					goto end_IL_05b1;
																					IL_0d84:
																					if (6 <= b)
																					{
																						num = 101;
																						goto IL_0d9b;
																					}
																					goto IL_10cd;
																					IL_113d:
																					num6--;
																					goto end_IL_05b1;
																					IL_0d9b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0ddb;
																					IL_0ddb:
																					array[num6 - 2] = 0;
																					goto IL_0def;
																					IL_0def:
																					num6--;
																					goto end_IL_05b1;
																					IL_10cd:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_10db;
																				}
																				break;
																				IL_05a1:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_05b1:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_146b:
														break;
													}
													continue;
													end_IL_147e:
													break;
												}
												continue;
												end_IL_1488:
												break;
											}
											continue;
											end_IL_1493:
											break;
										}
										continue;
										end_IL_14a3:
										break;
									}
									continue;
									end_IL_14b3:
									break;
								}
								continue;
								end_IL_14c3:
								break;
							}
							continue;
							end_IL_14d3:
							break;
						}
						continue;
						end_IL_14e3:
						break;
					}
					continue;
					end_IL_14f3:
					break;
				}
				continue;
				end_IL_1503:
				break;
			}
		}
	}

	private static bool SafeArrayoce(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private static float FieldAttributesAccountEnterpriseAdminsSid()
	{
		return global::_003CModule_003E.float_112;
	}

	private static float ConstantsIsLong(XRNode xrnode_0)
	{
		return ControllerInputPoller.TriggerFloat(xrnode_0);
	}

	private static Vector3 MethodBaseEncoderExceptionFallback()
	{
		return global::_003CModule_003E.vector3_126;
	}

	private static int smethod_1(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		int num3;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_1;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		num = num3;
		int num4 = smethod_3();
		num2 = num4;
		return num;
	}

	private void OnDisable()
	{
		DirectoryStringOpenDelegateOnly(this);
	}

	public Class180()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static double ApplicationManifestBytesgetDefaultGrantSet(double double_1)
	{
		return Math.Sin(double_1);
	}

	private static void IsGenericMatchConstructorArguments(Renderer renderer_0, bool bool_3)
	{
		renderer_0.enabled = bool_3;
	}

	private static Rigidbody TraceOperationCompletionScheme(Class180 class180_1)
	{
		return class180_1.rigidbody_0;
	}

	private unsafe static int smethod_3()
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 111;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 70;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NotSupportedInComparableTypegetProperty.NullReferenceExceptionsetApplicationEvidence);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03c8:
														byte b = *ptr2;
														while (true)
														{
															IL_03b8:
															ptr2++;
															while (true)
															{
																IL_03a8:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_038b:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_036b:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_035e:
																								if (4 > b)
																								{
																									while (true)
																									{
																										IL_034e:
																										if (2 >= b)
																										{
																											while (true)
																											{
																												IL_033e:
																												if (2 > b)
																												{
																													while (1 >= b)
																													{
																														while (1 <= b)
																														{
																															while (true)
																															{
																																IL_0303:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																while (true)
																																{
																																	IL_02f3:
																																	array[num5] = 0;
																																	while (true)
																																	{
																																		IL_02da:
																																		num5++;
																																		num = 174;
																																		while (true)
																																		{
																																			if (num != 174)
																																			{
																																				if (num != 1155)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 109:
																																					goto IL_02da;
																																				case 39:
																																					goto IL_02f3;
																																				case 76:
																																				case 143:
																																					goto IL_0303;
																																				case 8:
																																					goto IL_031e;
																																				case 128:
																																				case 131:
																																					goto IL_032e;
																																				case 60:
																																					goto IL_033e;
																																				case 21:
																																					goto IL_034e;
																																				case 66:
																																					goto IL_035e;
																																				case 29:
																																					goto IL_036b;
																																				case 69:
																																					goto IL_037b;
																																				case 57:
																																					goto IL_038b;
																																				case 144:
																																					goto IL_0398;
																																				case 84:
																																					goto IL_03a8;
																																				case 1:
																																					goto IL_03b8;
																																				case 51:
																																				case 73:
																																					goto IL_03c8;
																																				case 28:
																																				case 58:
																																					goto IL_03d3;
																																				case 38:
																																					goto IL_03f1;
																																				case 54:
																																					goto IL_03ff;
																																				case 27:
																																				case 110:
																																					goto IL_0412;
																																				case 72:
																																					goto IL_0420;
																																				case 23:
																																				case 71:
																																					goto IL_042e;
																																				case 74:
																																				case 86:
																																					goto IL_0439;
																																				case 77:
																																					goto IL_0447;
																																				case 79:
																																					goto IL_045a;
																																				case 55:
																																				case 87:
																																					goto IL_0468;
																																				case 99:
																																				case 112:
																																					goto IL_0484;
																																				case 16:
																																					goto IL_048f;
																																				case 52:
																																					goto IL_049a;
																																				case 53:
																																					goto IL_04ad;
																																				case 24:
																																				case 44:
																																					goto IL_04bb;
																																				case 35:
																																				case 124:
																																					goto IL_04ce;
																																				case 9:
																																					goto IL_050d;
																																				case 7:
																																				case 136:
																																					goto IL_0520;
																																				case 133:
																																					goto IL_0537;
																																				case 117:
																																				case 125:
																																					goto IL_0545;
																																				case 45:
																																					goto IL_056e;
																																				case 146:
																																					goto IL_0587;
																																				case 22:
																																				case 59:
																																					goto IL_0595;
																																				case 151:
																																					goto IL_05ad;
																																				case 98:
																																				case 113:
																																					goto IL_05bb;
																																				case 158:
																																					goto IL_05e4;
																																				case 142:
																																					goto IL_05f2;
																																				case 159:
																																					goto IL_0605;
																																				case 49:
																																				case 92:
																																					goto IL_0613;
																																				case 37:
																																					goto IL_0621;
																																				case 130:
																																				case 156:
																																					goto IL_062f;
																																				case 4:
																																					goto IL_064c;
																																				case 47:
																																					goto IL_068b;
																																				case 65:
																																				case 162:
																																					goto IL_069e;
																																				case 163:
																																					goto IL_06b1;
																																				case 78:
																																				case 106:
																																					goto IL_06bf;
																																				case 148:
																																					goto IL_06cd;
																																				case 15:
																																				case 126:
																																					goto IL_06d8;
																																				case 19:
																																					goto IL_071c;
																																				case 94:
																																					goto IL_0730;
																																				case 134:
																																					goto IL_0743;
																																				case 105:
																																					goto IL_0751;
																																				case 96:
																																				case 161:
																																					goto IL_075f;
																																				case 80:
																																					goto IL_0776;
																																				case 123:
																																					goto IL_0799;
																																				case 31:
																																					goto IL_07a3;
																																				case 153:
																																					goto IL_07b1;
																																				case 121:
																																					goto IL_07c4;
																																				case 93:
																																					goto IL_07d2;
																																				case 6:
																																				case 61:
																																					goto IL_07e0;
																																				case 2:
																																					goto IL_0820;
																																				case 137:
																																					goto IL_0834;
																																				case 25:
																																				case 127:
																																					goto IL_0847;
																																				case 56:
																																					goto IL_08a9;
																																				case 167:
																																					goto IL_08bc;
																																				case 118:
																																				case 120:
																																					goto IL_08c7;
																																				case 40:
																																					goto IL_08d5;
																																				case 154:
																																					goto IL_08ed;
																																				case 5:
																																					goto IL_08fb;
																																				case 10:
																																				case 141:
																																					goto IL_0929;
																																				case 132:
																																					goto IL_0969;
																																				case 3:
																																					goto IL_097d;
																																				case 11:
																																				case 14:
																																				case 17:
																																				case 18:
																																				case 30:
																																				case 32:
																																				case 33:
																																				case 34:
																																				case 46:
																																				case 48:
																																				case 50:
																																				case 62:
																																				case 63:
																																				case 67:
																																				case 81:
																																				case 85:
																																				case 88:
																																				case 91:
																																				case 95:
																																				case 97:
																																				case 101:
																																				case 104:
																																				case 108:
																																				case 114:
																																				case 129:
																																				case 135:
																																				case 139:
																																				case 145:
																																				case 150:
																																				case 152:
																																				case 155:
																																				case 157:
																																				case 160:
																																					goto end_IL_02c7;
																																				case 0:
																																				case 12:
																																				case 13:
																																				case 36:
																																				case 43:
																																				case 64:
																																				case 75:
																																				case 83:
																																				case 103:
																																				case 115:
																																				case 116:
																																				case 119:
																																				case 122:
																																				case 138:
																																				case 140:
																																				case 147:
																																				case 149:
																																				case 164:
																																				case 165:
																																				case 166:
																																					goto end_IL_037b;
																																				case 82:
																																					goto end_IL_09a0;
																																				case 70:
																																					goto end_IL_09b3;
																																				case 100:
																																					goto end_IL_09bd;
																																				case 111:
																																					goto end_IL_09c8;
																																				case 89:
																																				case 90:
																																					goto end_IL_09e1;
																																				case 102:
																																					goto end_IL_09f1;
																																				case 26:
																																				case 68:
																																					goto end_IL_0a0a;
																																				case 41:
																																					goto end_IL_0a1a;
																																				case 42:
																																					goto end_IL_0a2a;
																																				case 20:
																																				case 107:
																																					goto IL_0a45;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			goto end_IL_037b;
																																			continue;
																																			end_IL_02c7:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																															IL_031e:;
																														}
																														break;
																														IL_032e:;
																													}
																													break;
																												}
																												goto IL_0929;
																												IL_097d:
																												num5--;
																												goto end_IL_037b;
																												IL_0929:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0969;
																												IL_0969:
																												array[num5 - 2] = 0;
																												goto IL_097d;
																											}
																											break;
																										}
																										goto IL_0520;
																										IL_0545:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_056e;
																										IL_0520:
																										if (3 < b)
																										{
																											break;
																										}
																										num = 133;
																										goto IL_0537;
																										IL_056e:
																										array[num5 - 1] = 5;
																										goto end_IL_037b;
																										IL_0537:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0545;
																									}
																									break;
																								}
																								goto IL_03d3;
																								IL_03ff:
																								num5--;
																								goto end_IL_037b;
																								IL_03d3:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_03f1;
																								IL_03f1:
																								ptr2 += 8;
																								goto IL_03ff;
																							}
																							break;
																						}
																						goto IL_0484;
																						IL_05e4:
																						ptr2 += 8;
																						goto IL_05f2;
																						IL_0484:
																						if (6 >= b)
																						{
																							goto IL_048f;
																						}
																						goto IL_04ad;
																						IL_048f:
																						if (6 > b)
																						{
																							goto IL_049a;
																						}
																						goto IL_04ce;
																						IL_049a:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_08bc;
																						IL_08bc:
																						if (5 > b)
																						{
																							num = 155;
																							break;
																						}
																						goto IL_08c7;
																						IL_08c7:
																						array[num5] = 5;
																						goto IL_08d5;
																						IL_08d5:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_08ed;
																						IL_08ed:
																						num5++;
																						goto IL_08fb;
																						IL_08fb:
																						ptr2 += 8;
																						goto end_IL_037b;
																						IL_05f2:
																						num5--;
																						goto end_IL_037b;
																						IL_04ce:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_050d;
																						IL_050d:
																						num5 -= 3;
																						goto end_IL_037b;
																						IL_04ad:
																						if (7 < b)
																						{
																							goto IL_04bb;
																						}
																						goto IL_05ad;
																						IL_04bb:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0587;
																						IL_0587:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0595;
																						IL_0595:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_037b;
																						IL_05ad:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_05bb;
																						IL_05bb:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05e4;
																					}
																					goto end_IL_0398;
																					continue;
																					end_IL_037b:
																					break;
																					IL_037b:;
																				}
																				break;
																			}
																			goto IL_0412;
																			IL_08a9:
																			num5 -= 2;
																			break;
																			IL_0412:
																			if (13 < b)
																			{
																				goto IL_0420;
																			}
																			goto IL_06b1;
																			IL_0420:
																			if (15 < b)
																			{
																				goto IL_042e;
																			}
																			goto IL_0605;
																			IL_042e:
																			if (16 < b)
																			{
																				goto IL_0439;
																			}
																			goto IL_045a;
																			IL_0439:
																			if (17 < b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_0447;
																			IL_0447:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_0398;
																			IL_045a:
																			if (16 > b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_0468;
																			IL_0468:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0605:
																			if (15 > b)
																			{
																				goto IL_0613;
																			}
																			goto IL_069e;
																			IL_0613:
																			if (14 < b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_0621;
																			IL_0621:
																			if (14 > b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_062f;
																			IL_062f:
																			array[num5 - 1] = 0;
																			num = 4;
																			goto IL_064c;
																			IL_064c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getAlgorithmTypeReAllocHGlobal[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_068b;
																			IL_068b:
																			ptr2 += 8;
																			break;
																			IL_069e:
																			num5--;
																			break;
																			IL_06b1:
																			if (13 > b)
																			{
																				goto IL_06bf;
																			}
																			goto IL_0847;
																			IL_06bf:
																			if (11 >= b)
																			{
																				goto IL_06cd;
																			}
																			goto IL_07c4;
																			IL_06cd:
																			if (11 <= b)
																			{
																				goto IL_06d8;
																			}
																			goto IL_0743;
																			IL_06d8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_071c;
																			IL_071c:
																			array[num5 - 2] = 0;
																			goto IL_0730;
																			IL_0730:
																			num5--;
																			break;
																			IL_0743:
																			if (10 < b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_0751;
																			IL_0751:
																			if (10 > b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_075f;
																			IL_075f:
																			array[num5] = 0;
																			num = 80;
																			goto IL_0776;
																			IL_0776:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0799;
																			IL_0799:
																			array2[num5] = null;
																			goto IL_07a3;
																			IL_07a3:
																			num5++;
																			goto IL_07b1;
																			IL_07b1:
																			ptr2 += 8;
																			break;
																			IL_07c4:
																			if (12 < b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_07d2;
																			IL_07d2:
																			if (12 > b)
																			{
																				goto end_IL_0398;
																			}
																			goto IL_07e0;
																			IL_07e0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0820;
																			IL_0820:
																			array[num5 - 2] = 0;
																			goto IL_0834;
																			IL_0834:
																			num5--;
																			break;
																			IL_0847:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_08a9;
																		}
																		goto end_IL_03a8;
																		continue;
																		end_IL_0398:
																		break;
																		IL_0398:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03a8:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a45;
												IL_0a45:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09a0:
												break;
											}
											continue;
											end_IL_09b3:
											break;
										}
										continue;
										end_IL_09bd:
										break;
									}
									continue;
									end_IL_09c8:
									break;
								}
								continue;
								end_IL_09e1:
								break;
							}
							continue;
							end_IL_09f1:
							break;
						}
						continue;
						end_IL_0a0a:
						break;
					}
					continue;
					end_IL_0a1a:
					break;
				}
				continue;
				end_IL_0a2a:
				break;
			}
		}
	}

	private static double ChannelServicesIClientFormatterSinkProvider(double double_1)
	{
		return Math.Cos(double_1);
	}

	private unsafe void Start()
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 47;
							while (true)
							{
								int[] array3 = new int[6];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CounterSetSectionIStream.SecurityBindingRedirectsNewobj);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															num = 173;
															while (true)
															{
																if (num != 173)
																{
																	if (num != 1154)
																	{
																		goto IL_08f8;
																	}
																	switch (num)
																	{
																	case 3:
																	case 17:
																		goto end_IL_02c3;
																	case 24:
																		goto IL_02f5;
																	case 131:
																		goto IL_0303;
																	case 125:
																		goto IL_0311;
																	case 23:
																		goto IL_031f;
																	case 13:
																	case 121:
																		goto IL_032d;
																	case 155:
																		goto IL_033b;
																	case 49:
																	case 84:
																		goto IL_0346;
																	case 148:
																		goto IL_0354;
																	case 7:
																		goto IL_0377;
																	case 154:
																		goto IL_0381;
																	case 145:
																		goto IL_038f;
																	case 0:
																		goto IL_03a2;
																	case 61:
																		goto IL_03b0;
																	case 43:
																	case 152:
																		goto IL_03bb;
																	case 133:
																		goto IL_03c9;
																	case 109:
																	case 141:
																		goto IL_03dc;
																	case 146:
																		goto IL_041c;
																	case 94:
																		goto IL_0430;
																	case 50:
																		goto IL_0443;
																	case 51:
																		goto IL_0451;
																	case 21:
																	case 38:
																		goto IL_045f;
																	case 22:
																		goto IL_0488;
																	case 149:
																		goto IL_0496;
																	case 96:
																		goto IL_04a9;
																	case 19:
																		goto IL_04b7;
																	case 36:
																	case 88:
																		goto IL_04c5;
																	case 119:
																		goto IL_04d3;
																	case 68:
																	case 93:
																		goto IL_04e1;
																	case 157:
																		goto IL_0521;
																	case 52:
																		goto IL_053e;
																	case 70:
																	case 75:
																		goto IL_0551;
																	case 2:
																		goto IL_0591;
																	case 25:
																		goto IL_05a5;
																	case 158:
																		goto IL_05b8;
																	case 18:
																		goto IL_05c3;
																	case 60:
																		goto IL_05d1;
																	case 128:
																	case 163:
																		goto IL_05df;
																	case 106:
																		goto IL_05f2;
																	case 39:
																	case 124:
																		goto IL_0600;
																	case 103:
																		goto IL_0640;
																	case 82:
																		goto IL_0654;
																	case 69:
																	case 150:
																		goto IL_0667;
																	case 95:
																		goto IL_06a7;
																	case 111:
																		goto IL_06bb;
																	case 99:
																		goto IL_06ce;
																	case 126:
																		goto IL_06dc;
																	case 37:
																	case 104:
																		goto IL_06ea;
																	case 159:
																		goto IL_06f8;
																	case 55:
																	case 100:
																		goto IL_0706;
																	case 107:
																		goto IL_0714;
																	case 135:
																	case 137:
																		goto IL_0722;
																	case 48:
																		goto IL_078d;
																	case 53:
																		goto IL_07a9;
																	case 91:
																		goto IL_07b7;
																	case 71:
																	case 151:
																		goto IL_07c5;
																	case 85:
																		goto IL_07dd;
																	case 117:
																		goto IL_07eb;
																	case 161:
																		goto IL_07f9;
																	case 64:
																	case 156:
																		goto IL_080c;
																	case 127:
																		goto IL_081a;
																	case 123:
																		goto IL_0838;
																	case 57:
																		goto IL_0846;
																	case 79:
																		goto IL_0859;
																	case 114:
																		goto IL_0867;
																	case 28:
																	case 72:
																		goto IL_0872;
																	case 30:
																		goto IL_0886;
																	case 113:
																		goto IL_08be;
																	case 122:
																		goto IL_08d1;
																	case 142:
																		goto IL_08ea;
																	case 45:
																	case 78:
																		goto IL_08f8;
																	case 120:
																		goto IL_0930;
																	case 115:
																		goto IL_0944;
																	case 54:
																		goto IL_0957;
																	case 12:
																	case 76:
																		goto IL_0962;
																	case 67:
																		goto IL_096d;
																	case 9:
																	case 92:
																		goto IL_0978;
																	case 164:
																		goto IL_0994;
																	case 16:
																	case 83:
																		goto IL_099f;
																	case 1:
																		goto IL_09cc;
																	case 11:
																	case 27:
																	case 31:
																	case 32:
																	case 33:
																	case 35:
																	case 40:
																	case 42:
																	case 56:
																	case 58:
																	case 62:
																	case 63:
																	case 86:
																	case 87:
																	case 89:
																	case 101:
																	case 102:
																	case 108:
																	case 110:
																	case 116:
																	case 130:
																	case 136:
																	case 138:
																	case 139:
																	case 140:
																	case 160:
																	case 162:
																	case 165:
																		goto IL_09e5;
																	case 14:
																		goto IL_09fe;
																	case 90:
																		goto IL_0a0c;
																	case 29:
																		goto IL_0a1a;
																	case 6:
																	case 8:
																	case 15:
																	case 20:
																	case 26:
																	case 34:
																	case 41:
																	case 44:
																	case 46:
																	case 59:
																	case 98:
																	case 105:
																	case 112:
																	case 118:
																	case 129:
																	case 132:
																	case 134:
																	case 143:
																	case 144:
																	case 166:
																		goto end_IL_02d3;
																	case 65:
																		goto end_IL_0a28;
																	case 80:
																		goto end_IL_0a3b;
																	case 10:
																		goto end_IL_0a45;
																	case 97:
																		goto end_IL_0a50;
																	case 4:
																		goto end_IL_0a60;
																	case 47:
																		goto end_IL_0a70;
																	case 147:
																		goto end_IL_0a80;
																	case 81:
																		goto end_IL_0a90;
																	case 77:
																	case 153:
																		goto end_IL_0a9b;
																	case 73:
																		goto end_IL_0aab;
																	case 74:
																		goto end_IL_0abb;
																	case 5:
																	case 66:
																		return;
																	}
																	continue;
																}
																ptr2++;
																goto IL_02f5;
																IL_09e5:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_09fe;
																IL_0a0c:
																num5++;
																goto IL_0a1a;
																IL_09fe:
																array[num5] = 0;
																goto IL_0a0c;
																IL_02f5:
																if (b >= 1)
																{
																	goto IL_0303;
																}
																goto IL_09e5;
																IL_0303:
																if (b <= 17)
																{
																	goto IL_0311;
																}
																goto IL_09e5;
																IL_0311:
																if (9 >= b)
																{
																	goto IL_031f;
																}
																goto IL_06ce;
																IL_031f:
																if (9 > b)
																{
																	goto IL_032d;
																}
																goto IL_0667;
																IL_032d:
																if (4 >= b)
																{
																	goto IL_033b;
																}
																goto IL_04a9;
																IL_033b:
																if (4 <= b)
																{
																	goto IL_0346;
																}
																goto IL_03a2;
																IL_0346:
																array[num5] = 0;
																goto IL_0354;
																IL_0354:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0377;
																IL_0377:
																array2[num5] = null;
																goto IL_0381;
																IL_0381:
																num5++;
																goto IL_038f;
																IL_038f:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_03a2:
																if (2 >= b)
																{
																	goto IL_03b0;
																}
																goto IL_0443;
																IL_03b0:
																if (2 > b)
																{
																	goto IL_03bb;
																}
																goto IL_03dc;
																IL_03bb:
																if (1 >= b)
																{
																	goto IL_03c9;
																}
																goto IL_09e5;
																IL_03c9:
																if (1 > b)
																{
																}
																goto IL_09e5;
																IL_03dc:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_041c;
																IL_041c:
																array[num5 - 2] = 0;
																goto IL_0430;
																IL_0430:
																num5--;
																goto end_IL_02d3;
																IL_0443:
																if (3 >= b)
																{
																	goto IL_0451;
																}
																goto IL_09e5;
																IL_0451:
																if (3 <= b)
																{
																	goto IL_045f;
																}
																goto IL_09e5;
																IL_045f:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0488;
																IL_0488:
																ptr2 += 8;
																goto IL_0496;
																IL_0496:
																num5--;
																goto end_IL_02d3;
																IL_04a9:
																if (6 >= b)
																{
																	goto IL_04b7;
																}
																goto IL_05b8;
																IL_04b7:
																if (6 > b)
																{
																	goto IL_04c5;
																}
																goto IL_0551;
																IL_04c5:
																if (5 >= b)
																{
																	goto IL_04d3;
																}
																goto IL_09e5;
																IL_04d3:
																if (5 <= b)
																{
																	goto IL_04e1;
																}
																goto IL_09e5;
																IL_04e1:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0521;
																IL_0521:
																array[num5 - 2] = 0;
																num = 52;
																goto IL_053e;
																IL_053e:
																num5--;
																goto end_IL_02d3;
																IL_0551:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0591;
																IL_0591:
																array[num5 - 2] = 0;
																goto IL_05a5;
																IL_05a5:
																num5--;
																goto end_IL_02d3;
																IL_05b8:
																if (7 < b)
																{
																	goto IL_05c3;
																}
																goto IL_05f2;
																IL_05c3:
																if (8 >= b)
																{
																	goto IL_05d1;
																}
																goto IL_09e5;
																IL_05d1:
																if (8 <= b)
																{
																	goto IL_05df;
																}
																goto IL_09e5;
																IL_05df:
																num5--;
																goto end_IL_02d3;
																IL_05f2:
																if (7 <= b)
																{
																	goto IL_0600;
																}
																goto IL_09e5;
																IL_0600:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0640;
																IL_0640:
																array[num5 - 2] = 0;
																goto IL_0654;
																IL_0654:
																num5--;
																goto end_IL_02d3;
																IL_0667:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_06a7;
																IL_06a7:
																array[num5 - 2] = 0;
																goto IL_06bb;
																IL_06bb:
																num5--;
																goto end_IL_02d3;
																IL_06ce:
																if (13 >= b)
																{
																	goto IL_06dc;
																}
																goto IL_0859;
																IL_06dc:
																if (13 > b)
																{
																	goto IL_06ea;
																}
																goto IL_080c;
																IL_06ea:
																if (11 >= b)
																{
																	goto IL_06f8;
																}
																goto IL_07a9;
																IL_06f8:
																if (11 <= b)
																{
																	goto end_IL_02d3;
																}
																goto IL_0706;
																IL_0706:
																if (10 >= b)
																{
																	goto IL_0714;
																}
																goto IL_09e5;
																IL_0714:
																if (10 <= b)
																{
																	goto IL_0722;
																}
																goto IL_09e5;
																IL_0722:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 48;
																goto IL_078d;
																IL_078d:
																num5 -= 2;
																num = 112;
																goto end_IL_02d3;
																IL_07a9:
																if (12 >= b)
																{
																	goto IL_07b7;
																}
																goto IL_09e5;
																IL_07b7:
																if (12 <= b)
																{
																	goto IL_07c5;
																}
																goto IL_09e5;
																IL_07c5:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_07dd;
																IL_07dd:
																array[num5] = 5;
																goto IL_07eb;
																IL_07eb:
																num5++;
																goto IL_07f9;
																IL_07f9:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_080c:
																array[num5] = 5;
																goto IL_081a;
																IL_081a:
																array2[num5] = ((delegate*<GTPlayer>)HebrewEraBindToStorage[*(int*)(ptr2 + num3)])();
																goto IL_0838;
																IL_0838:
																num5++;
																goto IL_0846;
																IL_0846:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_0859:
																if (15 >= b)
																{
																	goto IL_0867;
																}
																goto IL_0957;
																IL_0867:
																if (15 <= b)
																{
																	goto IL_0872;
																}
																goto IL_08d1;
																IL_0872:
																array[num5 - 1] = 5;
																goto IL_0886;
																IL_0886:
																array2[num5 - 1] = ((delegate*<Collider, Rigidbody>)HebrewEraBindToStorage[*(int*)(ptr2 + num3)])((CapsuleCollider)array2[num5 - 1]);
																goto IL_08be;
																IL_08be:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_08d1:
																if (14 >= b)
																{
																	goto IL_08ea;
																}
																num = 31;
																goto IL_09e5;
																IL_0a1a:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_08ea:
																if (14 <= b)
																{
																	goto IL_08f8;
																}
																goto IL_09e5;
																IL_08f8:
																array2[num5 - 1] = ((delegate*<GTPlayer, CapsuleCollider>)HebrewEraBindToStorage[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																goto IL_0930;
																IL_0930:
																array[num5 - 1] = 5;
																goto IL_0944;
																IL_0944:
																ptr2 += 8;
																goto end_IL_02d3;
																IL_0957:
																if (16 < b)
																{
																	goto IL_0962;
																}
																goto IL_0994;
																IL_0962:
																if (17 >= b)
																{
																	goto IL_096d;
																}
																goto IL_09e5;
																IL_096d:
																if (17 <= b)
																{
																	goto IL_0978;
																}
																goto IL_09e5;
																IL_0978:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_02d3;
																IL_0994:
																if (16 <= b)
																{
																	goto IL_099f;
																}
																goto IL_09e5;
																IL_099f:
																((Class180)array2[num5 - 2]).rigidbody_0 = (Rigidbody)array2[num5 - 1];
																goto IL_09cc;
																IL_09cc:
																num5 -= 2;
																num = 166;
																goto end_IL_02d3;
																continue;
																end_IL_02c3:
																break;
															}
															continue;
															end_IL_02d3:
															break;
														}
														continue;
														end_IL_0a28:
														break;
													}
													continue;
													end_IL_0a3b:
													break;
												}
												continue;
												end_IL_0a45:
												break;
											}
											continue;
											end_IL_0a50:
											break;
										}
										continue;
										end_IL_0a60:
										break;
									}
									continue;
									end_IL_0a70:
									break;
								}
								continue;
								end_IL_0a80:
								break;
							}
							continue;
							end_IL_0a90:
							break;
						}
						continue;
						end_IL_0a9b:
						break;
					}
					continue;
					end_IL_0aab:
					break;
				}
				continue;
				end_IL_0abb:
				break;
			}
		}
	}

	private static bool AssemblyKeyNameAttributegetIsGenericTypeDefinition(Vector3 vector3_1, Vector3 vector3_2, ref RaycastHit raycastHit_0, float float_1)
	{
		return Physics.Raycast(vector3_1, vector3_2, out raycastHit_0, float_1);
	}

	private static bool getAsBstrcNamedArgs(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static ControllerInputPoller NoSetFirstChanceExceptionEventArgs()
	{
		return ControllerInputPoller.instance;
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 41;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								IL_067b:
								long[] array4 = new long[3];
								while (true)
								{
									IL_0666:
									array3[0] = int_1;
									while (true)
									{
										IL_065b:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ParseCombiningCharactersUNICODESTRING.GetImplTypeCustDataFindLastIndex);
										while (true)
										{
											IL_0651:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_063e:
												if (num4 != 1)
												{
													while (true)
													{
														IL_01fb:
														num = 119;
														while (true)
														{
															if (num != 119)
															{
																if (num != 1100)
																{
																	break;
																}
																switch (num)
																{
																case 100:
																	goto IL_01fb;
																case 1:
																	goto IL_020f;
																case 16:
																	goto IL_021d;
																case 14:
																	goto IL_022b;
																case 36:
																	goto IL_0239;
																case 69:
																	goto IL_0247;
																case 43:
																	goto IL_0255;
																case 34:
																	goto IL_0263;
																case 91:
																case 101:
																	goto IL_0271;
																case 98:
																	goto IL_027c;
																case 89:
																case 106:
																	goto IL_028a;
																case 38:
																	goto IL_02a3;
																case 24:
																	goto IL_02b1;
																case 20:
																	goto IL_02bf;
																case 105:
																	goto IL_02d2;
																case 4:
																	goto IL_02e0;
																case 33:
																case 35:
																	goto IL_02ee;
																case 76:
																	goto IL_0317;
																case 61:
																	goto IL_0325;
																case 39:
																case 104:
																	goto IL_0338;
																case 86:
																	goto IL_0350;
																case 42:
																	goto IL_035b;
																case 19:
																case 107:
																	goto IL_036e;
																case 23:
																	goto IL_0385;
																case 3:
																case 74:
																	goto IL_0393;
																case 15:
																	goto IL_03a1;
																case 58:
																	goto IL_03c4;
																case 44:
																	goto IL_03ce;
																case 93:
																	goto IL_03dc;
																case 31:
																case 94:
																	goto IL_03ef;
																case 46:
																	goto IL_042f;
																case 77:
																	goto IL_044c;
																case 21:
																	goto IL_045f;
																case 56:
																	goto IL_046a;
																case 12:
																	goto IL_0475;
																case 78:
																case 112:
																	goto IL_0483;
																case 17:
																	goto IL_049f;
																case 65:
																	goto IL_04ad;
																case 49:
																	goto IL_04c9;
																case 27:
																case 29:
																	goto IL_04d4;
																case 95:
																	goto IL_0536;
																case 7:
																case 92:
																	goto IL_0549;
																case 68:
																	goto IL_0554;
																case 57:
																case 110:
																	goto IL_0562;
																case 60:
																	goto IL_05a2;
																case 79:
																	goto IL_05b6;
																case 99:
																case 111:
																	goto IL_05c6;
																case 72:
																	goto IL_05d1;
																case 8:
																case 30:
																	goto IL_05dc;
																case 25:
																	goto IL_05ff;
																case 108:
																	goto IL_060d;
																case 6:
																	goto IL_061b;
																case 2:
																case 5:
																case 9:
																case 18:
																case 32:
																case 37:
																case 45:
																case 50:
																case 51:
																case 53:
																case 59:
																case 63:
																case 82:
																case 83:
																case 85:
																case 87:
																case 88:
																case 90:
																case 97:
																case 103:
																case 109:
																	goto IL_062b;
																case 11:
																case 13:
																case 28:
																case 47:
																case 54:
																case 55:
																case 66:
																case 67:
																case 71:
																case 73:
																case 81:
																case 84:
																case 96:
																case 102:
																	goto IL_063e;
																case 26:
																	goto IL_0651;
																case 0:
																	goto IL_065b;
																case 48:
																	goto IL_0666;
																case 62:
																	goto IL_067b;
																case 10:
																case 75:
																	goto end_IL_01eb;
																case 64:
																	goto end_IL_068b;
																case 52:
																case 70:
																	goto end_IL_069b;
																case 40:
																	goto end_IL_06ab;
																case 41:
																	goto end_IL_06bb;
																case 22:
																case 80:
																	goto IL_06d6;
																}
																continue;
															}
															b = *ptr2;
															goto IL_020f;
															IL_05dc:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_05ff;
															IL_060d:
															num5++;
															goto IL_061b;
															IL_05ff:
															array[num5] = 0;
															goto IL_060d;
															IL_020f:
															ptr2++;
															goto IL_021d;
															IL_021d:
															if (b >= 1)
															{
																goto IL_022b;
															}
															goto IL_062b;
															IL_022b:
															if (b <= 11)
															{
																goto IL_0239;
															}
															goto IL_062b;
															IL_0239:
															if (6 >= b)
															{
																goto IL_0247;
															}
															goto IL_045f;
															IL_0247:
															if (6 > b)
															{
																goto IL_0255;
															}
															goto IL_03ef;
															IL_0255:
															if (3 >= b)
															{
																goto IL_0263;
															}
															goto IL_0350;
															IL_0263:
															if (3 > b)
															{
																goto IL_0271;
															}
															goto IL_0338;
															IL_0271:
															if (1 >= b)
															{
																goto IL_027c;
															}
															goto IL_02d2;
															IL_027c:
															if (1 <= b)
															{
																goto IL_028a;
															}
															goto IL_062b;
															IL_028a:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_02a3;
															IL_02a3:
															array[num5] = 0;
															goto IL_02b1;
															IL_02b1:
															num5++;
															goto IL_02bf;
															IL_02bf:
															ptr2 += 8;
															goto IL_063e;
															IL_02d2:
															if (2 >= b)
															{
																goto IL_02e0;
															}
															goto IL_062b;
															IL_02e0:
															if (2 <= b)
															{
																goto IL_02ee;
															}
															goto IL_062b;
															IL_02ee:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0317;
															IL_0317:
															ptr2 += 8;
															goto IL_0325;
															IL_0325:
															num5--;
															goto IL_063e;
															IL_0338:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_063e;
															IL_0350:
															if (4 >= b)
															{
																goto IL_035b;
															}
															goto IL_036e;
															IL_035b:
															if (4 <= b)
															{
																goto IL_063e;
															}
															goto IL_062b;
															IL_036e:
															if (5 >= b)
															{
																num = 23;
																goto IL_0385;
															}
															goto IL_062b;
															IL_061b:
															ptr2 += 8;
															goto IL_063e;
															IL_0385:
															if (5 <= b)
															{
																goto IL_0393;
															}
															goto IL_062b;
															IL_0393:
															array[num5] = 0;
															goto IL_03a1;
															IL_03a1:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_03c4;
															IL_03c4:
															array2[num5] = null;
															goto IL_03ce;
															IL_03ce:
															num5++;
															goto IL_03dc;
															IL_03dc:
															ptr2 += 8;
															goto IL_063e;
															IL_03ef:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_042f;
															IL_042f:
															array[num5 - 2] = 0;
															num = 77;
															goto IL_044c;
															IL_044c:
															num5--;
															goto IL_063e;
															IL_045f:
															if (9 < b)
															{
																goto IL_046a;
															}
															num = 49;
															goto IL_04c9;
															IL_046a:
															if (10 >= b)
															{
																goto IL_0475;
															}
															goto IL_049f;
															IL_0475:
															if (10 <= b)
															{
																goto IL_0483;
															}
															goto IL_062b;
															IL_0483:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto IL_063e;
															IL_049f:
															if (11 >= b)
															{
																goto IL_04ad;
															}
															goto IL_062b;
															IL_04ad:
															if (11 > b)
															{
															}
															goto IL_062b;
															IL_062b:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_063e;
															IL_04c9:
															if (9 <= b)
															{
																goto IL_04d4;
															}
															goto IL_0549;
															IL_04d4:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0536;
															IL_0536:
															num5 -= 2;
															goto IL_063e;
															IL_0549:
															if (7 >= b)
															{
																goto IL_0554;
															}
															goto IL_05c6;
															IL_0554:
															if (7 <= b)
															{
																goto IL_0562;
															}
															goto IL_062b;
															IL_0562:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_05a2;
															IL_05a2:
															array[num5 - 2] = 0;
															goto IL_05b6;
															IL_05b6:
															num5--;
															goto IL_063e;
															IL_05c6:
															if (8 >= b)
															{
																goto IL_05d1;
															}
															goto IL_062b;
															IL_05d1:
															if (8 <= b)
															{
																goto IL_05dc;
															}
															goto IL_062b;
															continue;
															end_IL_01eb:
															break;
														}
														break;
													}
													break;
												}
												goto IL_06d6;
												IL_06d6:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_068b:
							break;
						}
						continue;
						end_IL_069b:
						break;
					}
					continue;
					end_IL_06ab:
					break;
				}
				continue;
				end_IL_06bb:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 22;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 21;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IContributeObjectSinkautoFlush.SingleTypeInfobstrDescription);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 58;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_025c:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_023c:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_022f:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_021f:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (true)
																										{
																											IL_01fc:
																											if (9 > b)
																											{
																												num = 115;
																												while (num != 115 && num == 1096)
																												{
																													switch (num)
																													{
																													case 3:
																														goto IL_01fc;
																													case 15:
																													case 66:
																														goto IL_020f;
																													case 93:
																														goto IL_021f;
																													case 86:
																													case 87:
																														goto IL_022f;
																													case 80:
																														goto IL_023c;
																													case 79:
																														goto IL_024c;
																													case 26:
																														goto IL_025c;
																													case 44:
																														goto end_IL_025c;
																													case 42:
																													case 91:
																														goto end_IL_026c;
																													case 69:
																														goto IL_0287;
																													case 70:
																														goto IL_02a0;
																													case 51:
																														goto IL_02ae;
																													case 5:
																													case 73:
																														goto IL_02bc;
																													case 48:
																														goto IL_02fc;
																													case 85:
																														goto IL_0310;
																													case 61:
																													case 88:
																														goto IL_0323;
																													case 96:
																														goto IL_033c;
																													case 103:
																														goto IL_034a;
																													case 102:
																														goto IL_0358;
																													case 40:
																													case 82:
																														goto IL_036b;
																													case 72:
																														goto IL_0390;
																													case 33:
																													case 98:
																														goto IL_039e;
																													case 92:
																														goto IL_03de;
																													case 46:
																														goto IL_03f2;
																													case 63:
																														goto IL_0405;
																													case 49:
																													case 76:
																														goto IL_0413;
																													case 89:
																														goto IL_0421;
																													case 29:
																														goto IL_042c;
																													case 6:
																													case 30:
																														goto IL_0437;
																													case 12:
																														goto IL_0460;
																													case 19:
																														goto IL_046e;
																													case 4:
																													case 104:
																														goto IL_048f;
																													case 90:
																														goto IL_049d;
																													case 28:
																													case 74:
																														goto IL_04a8;
																													case 54:
																														goto IL_04e8;
																													case 17:
																														goto IL_04fc;
																													case 27:
																														goto IL_0526;
																													case 11:
																													case 55:
																														goto IL_0531;
																													case 100:
																														goto IL_0571;
																													case 67:
																														goto IL_058e;
																													case 81:
																													case 94:
																														goto IL_05a1;
																													case 16:
																														goto IL_05ac;
																													case 25:
																													case 60:
																														goto IL_05c2;
																													case 105:
																														goto IL_05d0;
																													case 8:
																														goto IL_05f3;
																													case 75:
																														goto IL_05fd;
																													case 95:
																														goto IL_060b;
																													case 1:
																													case 2:
																													case 7:
																													case 13:
																													case 18:
																													case 20:
																													case 23:
																													case 24:
																													case 34:
																													case 36:
																													case 37:
																													case 50:
																													case 56:
																													case 64:
																													case 65:
																													case 78:
																													case 84:
																													case 99:
																													case 107:
																													case 108:
																														goto end_IL_01e9;
																													case 62:
																														goto IL_063e;
																													case 57:
																														goto IL_0655;
																													case 31:
																														goto IL_0663;
																													case 10:
																													case 38:
																													case 39:
																													case 45:
																													case 47:
																													case 52:
																													case 53:
																													case 58:
																													case 68:
																													case 83:
																													case 97:
																														goto end_IL_027c;
																													case 32:
																														goto end_IL_0671;
																													case 9:
																														goto end_IL_0684;
																													case 14:
																														goto end_IL_0697;
																													case 41:
																														goto end_IL_06a2;
																													case 77:
																														goto end_IL_06b7;
																													case 71:
																													case 106:
																														goto end_IL_06cc;
																													case 35:
																														goto end_IL_06dc;
																													case 0:
																													case 101:
																														goto end_IL_06ec;
																													case 21:
																														goto end_IL_06fc;
																													case 22:
																														goto end_IL_070c;
																													case 43:
																													case 59:
																														goto IL_0730;
																													}
																													continue;
																													end_IL_01e9:
																													break;
																												}
																												break;
																											}
																											goto IL_036b;
																											IL_036b:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											num = 68;
																											goto end_IL_027c;
																										}
																										break;
																										IL_020f:;
																									}
																									break;
																								}
																								goto IL_0390;
																								IL_03f2:
																								num6--;
																								goto end_IL_027c;
																								IL_0390:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_039e;
																								IL_039e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_03de;
																								IL_03de:
																								array[num6 - 2] = 0;
																								goto IL_03f2;
																							}
																							break;
																						}
																						goto IL_0287;
																						IL_02fc:
																						array[num6 - 2] = 0;
																						goto IL_0310;
																						IL_0287:
																						if (7 > b)
																						{
																							goto IL_02a0;
																						}
																						num = 88;
																						goto IL_0323;
																						IL_0310:
																						num6--;
																						goto end_IL_027c;
																						IL_0323:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_033c;
																						IL_033c:
																						array[num6] = 0;
																						goto IL_034a;
																						IL_034a:
																						num6++;
																						goto IL_0358;
																						IL_0358:
																						ptr2 += 8;
																						goto end_IL_027c;
																						IL_02a0:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_02ae;
																						IL_02ae:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_02bc;
																						IL_02bc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_02fc;
																					}
																					break;
																				}
																				goto IL_0405;
																				IL_05c2:
																				array[num6] = 0;
																				goto IL_05d0;
																				IL_0405:
																				if (5 > b)
																				{
																					goto IL_0413;
																				}
																				goto IL_05c2;
																				IL_0413:
																				if (2 < b)
																				{
																					goto IL_0421;
																				}
																				num = 27;
																				goto IL_0526;
																				IL_0421:
																				if (3 >= b)
																				{
																					goto IL_042c;
																				}
																				goto IL_048f;
																				IL_042c:
																				if (3 > b)
																				{
																					num = 50;
																					break;
																				}
																				goto IL_0437;
																				IL_0437:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0460;
																				IL_0460:
																				ptr2 += 8;
																				goto IL_046e;
																				IL_046e:
																				num6--;
																				goto end_IL_027c;
																				IL_05f3:
																				array2[num6] = null;
																				goto IL_05fd;
																				IL_048f:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_049d;
																				IL_049d:
																				if (4 > b)
																				{
																					num = 37;
																					break;
																				}
																				goto IL_04a8;
																				IL_04a8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04e8;
																				IL_04e8:
																				array[num6 - 2] = 0;
																				goto IL_04fc;
																				IL_04fc:
																				num6--;
																				goto end_IL_027c;
																				IL_05fd:
																				num6++;
																				goto IL_060b;
																				IL_05d0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05f3;
																				IL_0526:
																				if (2 <= b)
																				{
																					goto IL_0531;
																				}
																				goto IL_05a1;
																				IL_0531:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0571;
																				IL_0571:
																				array[num6 - 2] = 0;
																				num = 67;
																				goto IL_058e;
																				IL_058e:
																				num6--;
																				goto end_IL_027c;
																				IL_05a1:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_05ac;
																				IL_05ac:
																				if (1 <= b)
																				{
																					num = 56;
																				}
																				break;
																				IL_060b:
																				ptr2 += 8;
																				goto end_IL_027c;
																			}
																			break;
																			IL_024c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_063e;
																	IL_0663:
																	ptr2 += 8;
																	goto end_IL_027c;
																	IL_0655:
																	num6++;
																	goto IL_0663;
																	IL_063e:
																	array[num6] = 0;
																	num = 57;
																	goto IL_0655;
																	continue;
																	end_IL_025c:
																	break;
																}
																continue;
																end_IL_026c:
																break;
															}
															continue;
															end_IL_027c:
															break;
														}
														continue;
													}
													goto IL_0730;
													IL_0730:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0671:
													break;
												}
												continue;
												end_IL_0684:
												break;
											}
											continue;
											end_IL_0697:
											break;
										}
										continue;
										end_IL_06a2:
										break;
									}
									continue;
									end_IL_06b7:
									break;
								}
								continue;
								end_IL_06cc:
								break;
							}
							continue;
							end_IL_06dc:
							break;
						}
						continue;
						end_IL_06ec:
						break;
					}
					continue;
					end_IL_06fc:
					break;
				}
				continue;
				end_IL_070c:
				break;
			}
		}
	}

	private static LineRenderer IsWellKnownaddResourceResolve(Class180 class180_1)
	{
		return class180_1.lineRenderer_0;
	}

	private static GorillaTagger RuntimeInformationReply()
	{
		return GorillaTagger.Instance;
	}

	private static Transform getIsNumericScalarsetHashValue(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static double GetSourceStartEndInternetSiteAuthority(double double_1)
	{
		return Math.Tan(double_1);
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 4;
		byte b = default(byte);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte[] array = default(byte[]);
		object[] array2 = default(object[]);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 123;
				while (true)
				{
					if (num != 123)
					{
						if (num != 1104)
						{
							goto IL_0371;
						}
						switch (num)
						{
						case 3:
							goto end_IL_01fb;
						case 4:
							goto end_IL_020b;
						case 59:
							goto IL_0238;
						case 97:
							goto IL_0246;
						case 42:
						case 94:
							goto IL_0254;
						case 112:
							goto IL_026b;
						case 68:
							goto IL_0282;
						case 73:
							goto IL_0295;
						case 50:
							goto IL_02a7;
						case 9:
						case 15:
						case 16:
						case 23:
						case 32:
						case 45:
						case 48:
						case 55:
						case 60:
						case 75:
						case 79:
						case 85:
						case 107:
						case 108:
							goto IL_02af;
						case 20:
						case 36:
							goto IL_02bf;
						case 62:
							goto IL_02c8;
						case 53:
							goto IL_02d6;
						case 31:
							goto IL_02e4;
						case 2:
							goto IL_02f2;
						case 115:
							goto IL_0300;
						case 34:
						case 72:
							goto IL_030e;
						case 80:
							goto IL_031c;
						case 24:
						case 51:
							goto IL_0327;
						case 6:
						case 100:
							goto IL_033f;
						case 35:
							goto IL_034a;
						case 1:
						case 104:
							goto IL_0358;
						case 89:
							goto IL_0371;
						case 13:
							goto IL_0388;
						case 81:
							goto IL_0396;
						case 27:
							goto IL_03a9;
						case 43:
							goto IL_03b7;
						case 44:
						case 58:
							goto IL_03c5;
						case 70:
							goto IL_03ee;
						case 8:
							goto IL_0405;
						case 11:
							goto IL_0418;
						case 99:
							goto IL_0423;
						case 56:
						case 103:
							goto IL_0436;
						case 52:
							goto IL_0444;
						case 63:
						case 96:
							goto IL_0452;
						case 21:
							goto IL_0469;
						case 10:
							goto IL_048c;
						case 41:
							goto IL_0496;
						case 18:
							goto IL_04a4;
						case 71:
						case 88:
							goto IL_04b7;
						case 49:
							goto IL_04f7;
						case 39:
							goto IL_050b;
						case 0:
							goto IL_051e;
						case 83:
							goto IL_052c;
						case 76:
						case 95:
							goto IL_053a;
						case 91:
							goto IL_0545;
						case 12:
							goto IL_0553;
						case 19:
						case 78:
							goto IL_0561;
						case 82:
							goto IL_0584;
						case 98:
							goto IL_0592;
						case 28:
							goto IL_05a0;
						case 116:
							goto IL_05bc;
						case 47:
						case 74:
							goto IL_05ca;
						case 109:
							goto IL_060a;
						case 105:
							goto IL_061e;
						case 66:
						case 67:
							goto IL_0631;
						case 101:
							goto IL_0693;
						case 84:
						case 102:
							goto IL_06a6;
						case 61:
							goto IL_06b1;
						case 106:
							goto IL_06bc;
						case 7:
							goto IL_06c9;
						case 22:
						case 37:
							goto IL_06d4;
						case 5:
						case 14:
						case 17:
						case 25:
						case 29:
						case 30:
						case 33:
						case 38:
						case 40:
						case 46:
						case 54:
						case 57:
						case 64:
						case 65:
						case 69:
						case 77:
						case 86:
						case 87:
						case 90:
						case 92:
						case 93:
						case 111:
						case 113:
						case 114:
							goto IL_06f0;
						case 26:
						case 110:
							goto IL_0708;
						}
						continue;
					}
					num = 59;
					goto IL_0238;
					IL_06c9:
					if (10 <= b)
					{
						goto IL_06d4;
					}
					goto IL_06f0;
					IL_06f0:
					ptr = ptr2 + *(int*)(ptr + num3);
					goto IL_02af;
					IL_06d4:
					byte* num4 = ptr;
					num5 = 1;
					ptr = num4 + -200;
					goto IL_02af;
					IL_0238:
					array = new byte[3];
					goto IL_0246;
					IL_0246:
					array2 = new object[3];
					goto IL_0254;
					IL_0254:
					array3 = new int[4];
					num = 112;
					goto IL_026b;
					IL_026b:
					array4 = new long[3];
					num = 68;
					goto IL_0282;
					IL_0282:
					array3[0] = int_1;
					goto IL_0295;
					IL_0295:
					ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref charPosgetDefaultBinder.MarshalDirectiveExceptionTargetSite);
					num = 50;
					goto IL_02a7;
					IL_02a7:
					ptr = ptr2;
					goto IL_02af;
					IL_02af:
					if (num5 != 1)
					{
						goto IL_02bf;
					}
					goto IL_0708;
					IL_0708:
					return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
					IL_02bf:
					b = *ptr;
					goto IL_02c8;
					IL_02c8:
					ptr++;
					goto IL_02d6;
					IL_02d6:
					if (b >= 1)
					{
						goto IL_02e4;
					}
					goto IL_06f0;
					IL_02e4:
					if (b <= 11)
					{
						goto IL_02f2;
					}
					goto IL_06f0;
					IL_02f2:
					if (6 >= b)
					{
						goto IL_0300;
					}
					goto IL_051e;
					IL_0300:
					if (6 > b)
					{
						goto IL_030e;
					}
					goto IL_04b7;
					IL_030e:
					if (3 >= b)
					{
						goto IL_031c;
					}
					goto IL_0418;
					IL_031c:
					if (3 <= b)
					{
						goto IL_0327;
					}
					goto IL_033f;
					IL_0327:
					ptr = ptr2 + *(int*)(ptr + num3);
					goto IL_02af;
					IL_033f:
					if (1 >= b)
					{
						goto IL_034a;
					}
					goto IL_03a9;
					IL_034a:
					if (1 <= b)
					{
						goto IL_0358;
					}
					goto IL_06f0;
					IL_0358:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr + num3);
					goto IL_0371;
					IL_0371:
					array[num6] = 0;
					num = 13;
					goto IL_0388;
					IL_0388:
					num6++;
					goto IL_0396;
					IL_0396:
					ptr += 8;
					goto IL_02af;
					IL_03a9:
					if (2 >= b)
					{
						goto IL_03b7;
					}
					goto IL_06f0;
					IL_03b7:
					if (2 <= b)
					{
						goto IL_03c5;
					}
					goto IL_06f0;
					IL_03c5:
					ref int reference = ref array3[*(int*)(ptr + num3)];
					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
					goto IL_03ee;
					IL_03ee:
					ptr += 8;
					num = 8;
					goto IL_0405;
					IL_0405:
					num6--;
					goto IL_02af;
					IL_0418:
					if (4 >= b)
					{
						goto IL_0423;
					}
					goto IL_0436;
					IL_0423:
					if (4 <= b)
					{
						goto IL_02af;
					}
					goto IL_06f0;
					IL_0436:
					if (5 >= b)
					{
						goto IL_0444;
					}
					goto IL_06f0;
					IL_0444:
					if (5 <= b)
					{
						goto IL_0452;
					}
					goto IL_06f0;
					IL_0452:
					array[num6] = 0;
					num = 21;
					goto IL_0469;
					IL_0469:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
					goto IL_048c;
					IL_048c:
					array2[num6] = null;
					goto IL_0496;
					IL_0496:
					num6++;
					goto IL_04a4;
					IL_04a4:
					ptr += 8;
					goto IL_02af;
					IL_04b7:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
					goto IL_04f7;
					IL_04f7:
					array[num6 - 2] = 0;
					goto IL_050b;
					IL_050b:
					num6--;
					goto IL_02af;
					IL_051e:
					if (9 >= b)
					{
						goto IL_052c;
					}
					goto IL_06a6;
					IL_052c:
					if (9 > b)
					{
						goto IL_053a;
					}
					goto IL_0631;
					IL_053a:
					if (7 < b)
					{
						goto IL_0545;
					}
					goto IL_05bc;
					IL_0545:
					if (8 >= b)
					{
						goto IL_0553;
					}
					goto IL_06f0;
					IL_0553:
					if (8 <= b)
					{
						goto IL_0561;
					}
					goto IL_06f0;
					IL_0561:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr + num3)];
					goto IL_0584;
					IL_0584:
					array[num6] = 0;
					goto IL_0592;
					IL_0592:
					num6++;
					goto IL_05a0;
					IL_05a0:
					ptr += 8;
					num = 108;
					goto IL_02af;
					IL_05bc:
					if (7 <= b)
					{
						goto IL_05ca;
					}
					goto IL_06f0;
					IL_05ca:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
					goto IL_060a;
					IL_060a:
					array[num6 - 2] = 0;
					goto IL_061e;
					IL_061e:
					num6--;
					goto IL_02af;
					IL_0631:
					ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
					goto IL_0693;
					IL_0693:
					num6 -= 2;
					goto IL_02af;
					IL_06a6:
					if (10 < b)
					{
						goto IL_06b1;
					}
					goto IL_06c9;
					IL_06b1:
					if (11 >= b)
					{
						goto IL_06bc;
					}
					goto IL_06f0;
					IL_06bc:
					if (11 <= b)
					{
					}
					goto IL_06f0;
					continue;
					end_IL_01fb:
					break;
				}
				continue;
				end_IL_020b:
				break;
			}
		}
	}

	private static int getRootoce(int int_1, int int_2)
	{
		return smethod_1(int_1, int_2);
	}

	private static void DelegateWrapperUNKNOWN(Rigidbody rigidbody_1, bool bool_3)
	{
		rigidbody_1.useGravity = bool_3;
	}

	private unsafe void method_1()
	{
		//The blocks IL_000e, IL_001e, IL_0797, IL_07aa, IL_07ed, IL_0803, IL_0810, IL_0820, IL_0830, IL_0840, IL_0850, IL_0860, IL_086b, IL_0876, IL_0884, IL_088f, IL_089d, IL_08ab, IL_08ce, IL_08e1, IL_08ea, IL_08f8, IL_0903, IL_0911, IL_0925, IL_095d, IL_0970, IL_097e, IL_098c, IL_0995, IL_09cb, IL_09de, IL_09ec, IL_09fa, IL_0a38, IL_0a46, IL_0a59, IL_0a67, IL_0a75, IL_0ab5, IL_0ac9, IL_0adc, IL_0aea, IL_0af8, IL_0b03, IL_0b17, IL_0b64, IL_0b77, IL_0b82, IL_0b90, IL_0ba4, IL_0be3, IL_0bf6, IL_0c04, IL_0c12, IL_0c1c, IL_0c2a, IL_0c3d, IL_0c4d, IL_0c61, IL_0ca0, IL_0cb3, IL_0cc1, IL_0ccf, IL_0ceb, IL_0cf9, IL_0d07, IL_0d15, IL_0d23, IL_0d2e, IL_0d6e, IL_0d82, IL_0d95, IL_0da3, IL_0dae, IL_0dd7, IL_0de5, IL_0df8, IL_0e06, IL_0e14, IL_0e22, IL_0e62, IL_0e76, IL_0e89, IL_0e92, IL_0ea5, IL_0eb3, IL_0ebe, IL_0f20, IL_0f33, IL_0f41, IL_0f4f, IL_0f62, IL_0f70, IL_0f7e, IL_0f8c, IL_0f9a, IL_0fae, IL_1002, IL_1010, IL_1023, IL_1036, IL_1054, IL_106b, IL_1087, IL_1095, IL_10a0, IL_10b8, IL_10c6, IL_10d4, IL_10df, IL_10ed, IL_1116, IL_1138, IL_1146, IL_1154, IL_1175, IL_1193, IL_11b7, IL_11cf, IL_11e2, IL_11f0, IL_11fb, IL_120f, IL_1247, IL_125a, IL_1268, IL_1276, IL_12b4, IL_12d0, IL_12de, IL_12ec, IL_1313, IL_1321, IL_132c, IL_1364, IL_1378, IL_138b, IL_1396, IL_13a4, IL_13f6, IL_1409, IL_1417, IL_142a, IL_1438, IL_1443, IL_1451, IL_145f, IL_146d, IL_1490, IL_149e, IL_14b1, IL_14ee, IL_1501, IL_150f, IL_151d, IL_1536, IL_1544, IL_1552, IL_1565, IL_156e, IL_15ae, IL_15c2, IL_15d5, IL_15e8, IL_1600, IL_160e, IL_1625, IL_1638, IL_1646, IL_1651, IL_1691, IL_16a5, IL_16c1, IL_16cf, IL_16dd, IL_16eb, IL_170e, IL_1718, IL_1734, IL_1742, IL_174b, IL_1759, IL_1799, IL_17ad, IL_17c0, IL_17ce, IL_17e6, IL_17f4, IL_1807, IL_181a, IL_182d, IL_183b, IL_1849, IL_185c, IL_1875, IL_1883, IL_1891, IL_18ad, IL_18c0, IL_18cb, IL_190b, IL_191f, IL_1932, IL_1940, IL_194e, IL_1962, IL_19a1, IL_19b4, IL_19d2, IL_19e0, IL_19ee, IL_1a01, IL_1a0f, IL_1a1d, IL_1a5d, IL_1a71, IL_1a84, IL_1a92, IL_1a9b, IL_1ab8, IL_1b07, IL_1b11, IL_1b3e, IL_1b52, IL_1b69, IL_1b7c, IL_1b8a, IL_1b98, IL_1bd9, IL_1bed, IL_1c00, IL_1c13, IL_1c26, IL_1c34, IL_1c42, IL_1c50, IL_1c5b, IL_1c6f, IL_1cae, IL_1cc1, IL_1ccf, IL_1cdd, IL_1d24, IL_1d32, IL_1d45, IL_1d53, IL_1d66, IL_1d74, IL_1d82, IL_1d90, IL_1d9e, IL_1dac, IL_1df3, IL_1e01, IL_1e1d, IL_1e26, IL_1e64, IL_1e72, IL_1e85, IL_1e93, IL_1ea1, IL_1eb5, IL_1ef4, IL_1f07, IL_1f10, IL_1f24, IL_1f63, IL_1f76, IL_1f81, IL_1f95, IL_1fd4, IL_1fe7, IL_1ff5, IL_2003, IL_200e, IL_201c, IL_2025, IL_203e, IL_2051, IL_205f, IL_206d, IL_207b, IL_20a7, IL_20b5, IL_20c8, IL_20dc, IL_2114, IL_2127, IL_2135, IL_2140, IL_215d, IL_219c, IL_21af, IL_21bd, IL_21cb, IL_2208, IL_2216, IL_2229, IL_2234, IL_223f, IL_227c, IL_228a, IL_229a, IL_22ad, IL_22c0, IL_22ca, IL_22d5, IL_22e5, IL_22fe, IL_230e, IL_231e, IL_232e, IL_233e, IL_234e, IL_2367, IL_2377 are reachable both inside and outside the pinned region starting at IL_238c. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 257;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef83 = default(int);
			ref int reference = ref __rxRef83;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2377:
					num2 = 1;
					while (true)
					{
						IL_2367:
						num3 = num2 * 4;
						while (true)
						{
							IL_234e:
							num4 = num2 * 8;
							num = 440;
							while (true)
							{
								IL_233e:
								array2 = new byte[4];
								while (true)
								{
									IL_232e:
									array3 = new object[4];
									while (true)
									{
										IL_231e:
										array4 = new int[4];
										while (true)
										{
											IL_230e:
											array5 = new int[7];
											while (true)
											{
												IL_22fe:
												array6 = new long[4];
												while (true)
												{
													IL_22e5:
													array7 = new object[14];
													num = 29;
													while (true)
													{
														IL_22d5:
														array7[0] = this;
														while (true)
														{
															IL_22ca:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InTypeFixedCountFlagSuspendRequested.ManifestEnvelopeSetOut);
															while (true)
															{
																IL_22c0:
																ptr2 = ptr;
																while (true)
																{
																	IL_22ad:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0860:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0850:
																			ptr2++;
																			while (true)
																			{
																				IL_0840:
																				if (b >= 1)
																				{
																					while (b <= 57)
																					{
																						while (true)
																						{
																							IL_0820:
																							if (29 < b)
																							{
																								while (true)
																								{
																									IL_0810:
																									if (43 >= b)
																									{
																										while (true)
																										{
																											IL_0803:
																											if (43 <= b)
																											{
																												while (true)
																												{
																													IL_07ed:
																													array2[num6 - 1] = 5;
																													while (true)
																													{
																														IL_07aa:
																														array3[num6 - 1] = ((delegate*<string, GameObject>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																														num = 482;
																														while (true)
																														{
																															if (num != 482)
																															{
																																if (num != 1463)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 257:
																																	break;
																																default:
																																	continue;
																																case 310:
																																	goto IL_07aa;
																																case 58:
																																case 354:
																																	goto IL_07ed;
																																case 109:
																																	goto IL_0803;
																																case 139:
																																	goto IL_0810;
																																case 6:
																																	goto IL_0820;
																																case 207:
																																	goto IL_0830;
																																case 180:
																																	goto IL_0840;
																																case 366:
																																	goto IL_0850;
																																case 371:
																																case 443:
																																	goto IL_0860;
																																case 101:
																																	goto IL_086b;
																																case 412:
																																	goto IL_0884;
																																case 233:
																																	goto IL_088f;
																																case 105:
																																	goto IL_089d;
																																case 282:
																																case 359:
																																	goto end_IL_0797;
																																case 129:
																																	goto IL_08ce;
																																case 84:
																																	goto IL_08ea;
																																case 313:
																																	goto IL_08f8;
																																case 321:
																																	goto IL_0903;
																																case 12:
																																case 70:
																																	goto IL_0911;
																																case 230:
																																	goto IL_0925;
																																case 1:
																																	goto IL_095d;
																																case 347:
																																	goto IL_0970;
																																case 167:
																																	goto IL_097e;
																																case 5:
																																case 199:
																																	goto IL_0995;
																																case 254:
																																	goto IL_09cb;
																																case 417:
																																	goto IL_09de;
																																case 158:
																																	goto IL_09ec;
																																case 208:
																																case 260:
																																	goto IL_09fa;
																																case 410:
																																	goto IL_0a38;
																																case 140:
																																	goto IL_0a46;
																																case 426:
																																	goto IL_0a59;
																																case 227:
																																	goto IL_0a67;
																																case 308:
																																case 397:
																																	goto IL_0a75;
																																case 191:
																																	goto IL_0ab5;
																																case 20:
																																	goto IL_0ac9;
																																case 435:
																																	goto IL_0adc;
																																case 384:
																																	goto IL_0aea;
																																case 380:
																																	goto IL_0af8;
																																case 286:
																																case 415:
																																	goto IL_0b03;
																																case 7:
																																	goto IL_0b17;
																																case 379:
																																	goto IL_0b64;
																																case 178:
																																	goto IL_0b77;
																																case 326:
																																	goto IL_0b82;
																																case 177:
																																case 190:
																																	goto IL_0b90;
																																case 132:
																																	goto IL_0ba4;
																																case 2:
																																	goto IL_0be3;
																																case 433:
																																	goto IL_0bf6;
																																case 297:
																																	goto IL_0c04;
																																case 169:
																																case 294:
																																	goto IL_0c12;
																																case 76:
																																	goto IL_0c1c;
																																case 103:
																																	goto IL_0c2a;
																																case 314:
																																	goto IL_0c3d;
																																case 51:
																																case 436:
																																	goto IL_0c4d;
																																case 93:
																																	goto IL_0c61;
																																case 289:
																																	goto IL_0ca0;
																																case 439:
																																	goto IL_0cb3;
																																case 88:
																																	goto IL_0cc1;
																																case 96:
																																case 424:
																																	goto IL_0ccf;
																																case 452:
																																	goto IL_0ceb;
																																case 155:
																																	goto IL_0cf9;
																																case 332:
																																	goto IL_0d07;
																																case 258:
																																	goto IL_0d15;
																																case 358:
																																	goto IL_0d23;
																																case 271:
																																case 356:
																																	goto IL_0d2e;
																																case 451:
																																	goto IL_0d6e;
																																case 278:
																																	goto IL_0d82;
																																case 9:
																																	goto IL_0d95;
																																case 344:
																																	goto IL_0da3;
																																case 292:
																																case 333:
																																	goto IL_0dae;
																																case 23:
																																	goto IL_0dd7;
																																case 320:
																																	goto IL_0de5;
																																case 131:
																																	goto IL_0df8;
																																case 441:
																																	goto IL_0e06;
																																case 262:
																																	goto IL_0e14;
																																case 3:
																																case 259:
																																	goto IL_0e22;
																																case 39:
																																	goto IL_0e62;
																																case 183:
																																	goto IL_0e76;
																																case 205:
																																	goto IL_0e92;
																																case 414:
																																	goto IL_0ea5;
																																case 224:
																																	goto IL_0eb3;
																																case 267:
																																case 429:
																																	goto IL_0ebe;
																																case 219:
																																	goto IL_0f20;
																																case 423:
																																	goto IL_0f33;
																																case 53:
																																	goto IL_0f41;
																																case 63:
																																case 446:
																																	goto IL_0f4f;
																																case 74:
																																	goto IL_0f62;
																																case 274:
																																	goto IL_0f70;
																																case 89:
																																	goto IL_0f7e;
																																case 402:
																																	goto IL_0f8c;
																																case 113:
																																case 442:
																																	goto IL_0f9a;
																																case 409:
																																	goto IL_0fae;
																																case 206:
																																	goto IL_1002;
																																case 4:
																																	goto IL_1010;
																																case 124:
																																	goto IL_1023;
																																case 114:
																																case 422:
																																	goto IL_1036;
																																case 57:
																																	goto IL_1054;
																																case 126:
																																	goto IL_106b;
																																case 374:
																																	goto IL_1087;
																																case 335:
																																	goto IL_1095;
																																case 123:
																																case 367:
																																	goto IL_10a0;
																																case 82:
																																	goto IL_10b8;
																																case 185:
																																	goto IL_10c6;
																																case 8:
																																	goto IL_10d4;
																																case 217:
																																	goto IL_10df;
																																case 176:
																																case 307:
																																	goto IL_10ed;
																																case 240:
																																	goto IL_1116;
																																case 189:
																																	goto IL_1138;
																																case 339:
																																	goto IL_1146;
																																case 223:
																																case 381:
																																	goto IL_1154;
																																case 355:
																																	goto IL_1175;
																																case 407:
																																	goto IL_1193;
																																case 77:
																																	goto IL_11b7;
																																case 264:
																																	goto IL_11cf;
																																case 418:
																																	goto IL_11e2;
																																case 340:
																																	goto IL_11f0;
																																case 349:
																																case 388:
																																	goto IL_11fb;
																																case 363:
																																	goto IL_120f;
																																case 97:
																																	goto IL_1247;
																																case 60:
																																	goto IL_125a;
																																case 195:
																																	goto IL_1268;
																																case 148:
																																case 434:
																																	goto IL_1276;
																																case 316:
																																	goto IL_12b4;
																																case 159:
																																	goto IL_12d0;
																																case 152:
																																	goto IL_12de;
																																case 165:
																																case 210:
																																	goto IL_12ec;
																																case 268:
																																	goto IL_1313;
																																case 369:
																																	goto IL_1321;
																																case 116:
																																case 150:
																																	goto IL_132c;
																																case 275:
																																	goto IL_1364;
																																case 411:
																																	goto IL_1378;
																																case 377:
																																	goto IL_138b;
																																case 251:
																																	goto IL_1396;
																																case 162:
																																case 447:
																																	goto IL_13a4;
																																case 241:
																																	goto IL_13f6;
																																case 336:
																																	goto IL_1409;
																																case 211:
																																	goto IL_1417;
																																case 296:
																																	goto IL_142a;
																																case 295:
																																	goto IL_1438;
																																case 202:
																																	goto IL_1443;
																																case 401:
																																	goto IL_1451;
																																case 187:
																																case 421:
																																	goto IL_145f;
																																case 42:
																																	goto IL_146d;
																																case 54:
																																	goto IL_1490;
																																case 448:
																																	goto IL_149e;
																																case 69:
																																case 323:
																																	goto IL_14b1;
																																case 378:
																																	goto IL_14ee;
																																case 171:
																																	goto IL_1501;
																																case 75:
																																	goto IL_150f;
																																case 281:
																																case 291:
																																	goto IL_151d;
																																case 34:
																																	goto IL_1536;
																																case 312:
																																	goto IL_1544;
																																case 193:
																																	goto IL_1552;
																																case 55:
																																case 428:
																																	goto IL_156e;
																																case 329:
																																	goto IL_15ae;
																																case 130:
																																	goto IL_15c2;
																																case 455:
																																	goto IL_15d5;
																																case 91:
																																case 456:
																																	goto IL_15e8;
																																case 293:
																																	goto IL_1600;
																																case 438:
																																	goto IL_160e;
																																case 110:
																																	goto IL_1625;
																																case 458:
																																	goto IL_1638;
																																case 453:
																																	goto IL_1646;
																																case 327:
																																case 330:
																																	goto IL_1651;
																																case 174:
																																	goto IL_1691;
																																case 385:
																																	goto IL_16a5;
																																case 209:
																																	goto IL_16c1;
																																case 27:
																																	goto IL_16cf;
																																case 67:
																																case 454:
																																	goto IL_16dd;
																																case 393:
																																	goto IL_16eb;
																																case 142:
																																	goto IL_170e;
																																case 317:
																																	goto IL_1718;
																																case 19:
																																	goto IL_1734;
																																case 263:
																																	goto IL_174b;
																																case 17:
																																case 203:
																																	goto IL_1759;
																																case 290:
																																	goto IL_1799;
																																case 376:
																																	goto IL_17ad;
																																case 394:
																																case 462:
																																	goto IL_17c0;
																																case 160:
																																	goto IL_17ce;
																																case 111:
																																	goto IL_17e6;
																																case 269:
																																	goto IL_17f4;
																																case 463:
																																	goto IL_1807;
																																case 464:
																																	goto IL_181a;
																																case 465:
																																	goto IL_182d;
																																case 368:
																																	goto IL_183b;
																																case 261:
																																	goto IL_1849;
																																case 360:
																																case 466:
																																	goto IL_185c;
																																case 214:
																																	goto IL_1875;
																																case 243:
																																	goto IL_1883;
																																case 318:
																																	goto IL_1891;
																																case 467:
																																	goto IL_18ad;
																																case 468:
																																	goto IL_18c0;
																																case 65:
																																case 220:
																																	goto IL_18cb;
																																case 391:
																																	goto IL_190b;
																																case 201:
																																	goto IL_191f;
																																case 427:
																																	goto IL_1932;
																																case 92:
																																	goto IL_1940;
																																case 315:
																																case 457:
																																	goto IL_194e;
																																case 272:
																																	goto IL_1962;
																																case 134:
																																	goto IL_19a1;
																																case 122:
																																case 469:
																																	goto IL_19b4;
																																case 420:
																																	goto IL_19d2;
																																case 238:
																																	goto IL_19e0;
																																case 24:
																																	goto IL_19ee;
																																case 470:
																																	goto IL_1a01;
																																case 16:
																																	goto IL_1a0f;
																																case 11:
																																case 108:
																																	goto IL_1a1d;
																																case 365:
																																	goto IL_1a5d;
																																case 21:
																																	goto IL_1a71;
																																case 472:
																																	goto IL_1a84;
																																case 95:
																																case 311:
																																	goto IL_1a9b;
																																case 449:
																																	goto IL_1b52;
																																case 328:
																																	goto IL_1b69;
																																case 473:
																																	goto IL_1b7c;
																																case 204:
																																	goto IL_1b8a;
																																case 334:
																																case 386:
																																	goto IL_1b98;
																																case 26:
																																	goto IL_1bd9;
																																case 460:
																																	goto IL_1bed;
																																case 475:
																																	goto IL_1c00;
																																case 324:
																																	goto IL_1c26;
																																case 284:
																																	goto IL_1c34;
																																case 36:
																																	goto IL_1c42;
																																case 396:
																																	goto IL_1c50;
																																case 125:
																																case 151:
																																	goto IL_1c5b;
																																case 168:
																																	goto IL_1c6f;
																																case 163:
																																	goto IL_1cae;
																																case 31:
																																	goto IL_1cc1;
																																case 218:
																																	goto IL_1ccf;
																																case 306:
																																case 437:
																																	goto IL_1cdd;
																																case 232:
																																	goto IL_1d24;
																																case 390:
																																	goto IL_1d32;
																																case 117:
																																	goto IL_1d45;
																																case 300:
																																	goto IL_1d53;
																																case 226:
																																	goto IL_1d66;
																																case 52:
																																	goto IL_1d74;
																																case 403:
																																	goto IL_1d82;
																																case 175:
																																	goto IL_1d90;
																																case 14:
																																	goto IL_1d9e;
																																case 127:
																																case 197:
																																	goto IL_1dac;
																																case 357:
																																	goto IL_1df3;
																																case 348:
																																	goto IL_1e01;
																																case 47:
																																case 450:
																																	goto IL_1e26;
																																case 135:
																																	goto IL_1e64;
																																case 353:
																																	goto IL_1e72;
																																case 444:
																																	goto IL_1e85;
																																case 265:
																																	goto IL_1e93;
																																case 382:
																																case 425:
																																	goto IL_1ea1;
																																case 331:
																																	goto IL_1eb5;
																																case 237:
																																	goto IL_1ef4;
																																case 25:
																																case 406:
																																	goto IL_1f10;
																																case 283:
																																	goto IL_1f24;
																																case 430:
																																	goto IL_1f63;
																																case 445:
																																	goto IL_1f76;
																																case 279:
																																case 372:
																																	goto IL_1f81;
																																case 81:
																																	goto IL_1f95;
																																case 270:
																																	goto IL_1fd4;
																																case 28:
																																	goto IL_1fe7;
																																case 343:
																																	goto IL_1ff5;
																																case 319:
																																	goto IL_2003;
																																case 212:
																																	goto IL_200e;
																																case 45:
																																case 156:
																																	goto IL_2025;
																																case 15:
																																	goto IL_203e;
																																case 285:
																																	goto IL_2051;
																																case 102:
																																	goto IL_205f;
																																case 303:
																																case 398:
																																	goto IL_206d;
																																case 302:
																																	goto IL_207b;
																																case 301:
																																	goto IL_20a7;
																																case 147:
																																	goto IL_20b5;
																																case 213:
																																case 239:
																																	goto IL_20c8;
																																case 41:
																																	goto IL_20dc;
																																case 144:
																																	goto IL_2114;
																																case 44:
																																	goto IL_2127;
																																case 287:
																																	goto IL_2135;
																																case 80:
																																case 408:
																																	goto IL_2140;
																																case 405:
																																	goto IL_215d;
																																case 373:
																																	goto IL_219c;
																																case 35:
																																	goto IL_21af;
																																case 250:
																																	goto IL_21bd;
																																case 346:
																																case 459:
																																	goto IL_21cb;
																																case 137:
																																	goto IL_2208;
																																case 146:
																																	goto IL_2216;
																																case 194:
																																	goto IL_2229;
																																case 273:
																																	goto IL_2234;
																																case 100:
																																case 361:
																																	goto IL_223f;
																																case 161:
																																	goto IL_227c;
																																case 128:
																																	goto IL_228a;
																																case 18:
																																case 32:
																																case 33:
																																case 37:
																																case 38:
																																case 40:
																																case 49:
																																case 61:
																																case 62:
																																case 71:
																																case 72:
																																case 78:
																																case 85:
																																case 87:
																																case 104:
																																case 107:
																																case 112:
																																case 115:
																																case 121:
																																case 138:
																																case 153:
																																case 166:
																																case 170:
																																case 172:
																																case 173:
																																case 181:
																																case 186:
																																case 196:
																																case 198:
																																case 200:
																																case 216:
																																case 221:
																																case 229:
																																case 231:
																																case 235:
																																case 244:
																																case 245:
																																case 247:
																																case 249:
																																case 252:
																																case 253:
																																case 255:
																																case 266:
																																case 276:
																																case 277:
																																case 298:
																																case 309:
																																case 338:
																																case 341:
																																case 342:
																																case 352:
																																case 364:
																																case 375:
																																case 383:
																																case 400:
																																case 416:
																																case 419:
																																case 461:
																																case 471:
																																case 474:
																																	goto end_IL_0830;
																																case 0:
																																case 10:
																																case 13:
																																case 30:
																																case 48:
																																case 50:
																																case 56:
																																case 59:
																																case 64:
																																case 66:
																																case 68:
																																case 73:
																																case 79:
																																case 83:
																																case 86:
																																case 90:
																																case 94:
																																case 98:
																																case 118:
																																case 119:
																																case 120:
																																case 133:
																																case 136:
																																case 141:
																																case 143:
																																case 149:
																																case 154:
																																case 179:
																																case 182:
																																case 184:
																																case 188:
																																case 192:
																																case 215:
																																case 222:
																																case 225:
																																case 228:
																																case 234:
																																case 236:
																																case 242:
																																case 246:
																																case 248:
																																case 280:
																																case 288:
																																case 299:
																																case 304:
																																case 305:
																																case 322:
																																case 325:
																																case 337:
																																case 345:
																																case 350:
																																case 362:
																																case 370:
																																case 387:
																																case 389:
																																case 395:
																																case 399:
																																case 404:
																																case 431:
																																case 432:
																																	goto IL_22ad;
																																case 351:
																																	goto IL_22c0;
																																case 413:
																																	goto IL_22ca;
																																case 29:
																																	goto IL_22d5;
																																case 106:
																																	goto IL_22e5;
																																case 99:
																																	goto IL_22fe;
																																case 392:
																																	goto IL_230e;
																																case 157:
																																	goto IL_231e;
																																case 22:
																																	goto IL_232e;
																																case 440:
																																	goto IL_233e;
																																case 164:
																																	goto IL_234e;
																																case 145:
																																	goto IL_2367;
																																case 256:
																																	goto IL_2377;
																																case 43:
																																case 46:
																																	return;
																																}
																																goto end_IL_0803;
																															}
																															ptr2 += 8;
																															goto IL_22ad;
																															continue;
																															end_IL_0797:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_08ab;
																											}
																											goto IL_086b;
																											IL_09cb:
																											num6 -= 2;
																											goto IL_22ad;
																											IL_086b:
																											if (36 < b)
																											{
																												goto IL_0884;
																											}
																											num = 435;
																											goto IL_0adc;
																											IL_0c4d:
																											array2[num6 - 1] = 3;
																											goto IL_0c61;
																											IL_0adc:
																											if (36 > b)
																											{
																												goto IL_0aea;
																											}
																											goto IL_19b4;
																											IL_0aea:
																											if (32 >= b)
																											{
																												goto IL_0af8;
																											}
																											goto IL_0c3d;
																											IL_0af8:
																											if (32 <= b)
																											{
																												goto IL_0b03;
																											}
																											goto IL_0b77;
																											IL_0b03:
																											array2[num6 - 2] = 0;
																											goto IL_0b17;
																											IL_0b17:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																											goto IL_0b64;
																											IL_0b64:
																											num6--;
																											goto IL_15d5;
																											IL_15d5:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0b77:
																											if (30 >= b)
																											{
																												goto IL_0b82;
																											}
																											goto IL_0bf6;
																											IL_0b82:
																											if (30 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0b90;
																											IL_0b90:
																											array2[num6 - 1] = 0;
																											goto IL_0ba4;
																											IL_0ba4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0be3;
																											IL_0be3:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0bf6:
																											if (31 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0c04;
																											IL_0c04:
																											if (31 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0c12;
																											IL_0c12:
																											array3[num6] = null;
																											goto IL_0c1c;
																											IL_0c1c:
																											array2[num6] = 5;
																											goto IL_0c2a;
																											IL_0c2a:
																											num6++;
																											goto IL_22ad;
																											IL_0c3d:
																											if (34 < b)
																											{
																												goto IL_0cb3;
																											}
																											goto IL_18c0;
																											IL_18c0:
																											if (34 <= b)
																											{
																												goto IL_18cb;
																											}
																											goto IL_1932;
																											IL_18cb:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_190b;
																											IL_190b:
																											array2[num6 - 2] = 3;
																											goto IL_191f;
																											IL_191f:
																											num6--;
																											goto IL_22ad;
																											IL_1932:
																											if (33 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_1940;
																											IL_1940:
																											if (33 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_194e;
																											IL_194e:
																											array2[num6 - 1] = 3;
																											goto IL_1962;
																											IL_1962:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_19a1;
																											IL_19a1:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0cb3:
																											if (35 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0cc1;
																											IL_0cc1:
																											if (35 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0ccf;
																											IL_0ccf:
																											num7 = ptr2;
																											num8 = -200;
																											num5 = 1;
																											ptr2 = num7 + num8;
																											goto IL_22ad;
																											IL_19b4:
																											array3[num6] = ((delegate*<GameObject>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
																											goto IL_19d2;
																											IL_19d2:
																											array2[num6] = 5;
																											goto IL_19e0;
																											IL_19e0:
																											num6++;
																											goto IL_19ee;
																											IL_19ee:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0884:
																											if (39 < b)
																											{
																												goto IL_088f;
																											}
																											num = 84;
																											goto IL_08ea;
																											IL_088f:
																											if (41 >= b)
																											{
																												goto IL_089d;
																											}
																											goto IL_09de;
																											IL_089d:
																											if (41 <= b)
																											{
																												goto IL_08ab;
																											}
																											goto IL_0a59;
																											IL_08ab:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																											num = 129;
																											goto IL_08ce;
																											IL_08ce:
																											array2[num6] = 3;
																											goto IL_1807;
																											IL_1807:
																											num6++;
																											goto IL_18ad;
																											IL_18ad:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0a59:
																											if (40 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0a67;
																											IL_0a67:
																											if (40 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0a75;
																											IL_0a75:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0ab5;
																											IL_0ab5:
																											array2[num6 - 2] = 3;
																											goto IL_0ac9;
																											IL_0ac9:
																											num6--;
																											goto IL_22ad;
																											IL_09de:
																											if (42 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_09ec;
																											IL_09ec:
																											if (42 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_09fa;
																											IL_09fa:
																											((delegate*<LineRenderer, float, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																											goto IL_0a38;
																											IL_0a38:
																											num6 -= 2;
																											goto IL_0a46;
																											IL_0a46:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0c61:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0ca0;
																											IL_08ea:
																											if (39 > b)
																											{
																												goto IL_08f8;
																											}
																											goto IL_0c4d;
																											IL_08f8:
																											if (37 >= b)
																											{
																												goto IL_0903;
																											}
																											goto IL_0970;
																											IL_0903:
																											if (37 > b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_0911;
																											IL_0911:
																											array2[num6 - 1] = 5;
																											goto IL_0925;
																											IL_0925:
																											array3[num6 - 1] = ((delegate*<GameObject, LineRenderer>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																											goto IL_095d;
																											IL_095d:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0970:
																											if (38 < b)
																											{
																												goto end_IL_0830;
																											}
																											goto IL_097e;
																											IL_097e:
																											if (38 > b)
																											{
																												goto end_IL_0830;
																											}
																											num = 5;
																											goto IL_0995;
																											IL_0ca0:
																											ptr2 += 8;
																											goto IL_22ad;
																											IL_0995:
																											((Class180)array3[num6 - 2]).lineRenderer_0 = (LineRenderer)array3[num6 - 1];
																											num = 254;
																											goto IL_09cb;
																											continue;
																											end_IL_0803:
																											break;
																										}
																										break;
																									}
																									goto IL_1c26;
																									IL_2234:
																									if (49 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_223f;
																									IL_1c26:
																									if (50 < b)
																									{
																										goto IL_1c34;
																									}
																									goto IL_1f76;
																									IL_1c34:
																									if (54 < b)
																									{
																										goto IL_1c42;
																									}
																									goto IL_1d66;
																									IL_1c42:
																									if (56 >= b)
																									{
																										goto IL_1c50;
																									}
																									goto IL_1d45;
																									IL_1c50:
																									if (56 <= b)
																									{
																										goto IL_1c5b;
																									}
																									goto IL_1cc1;
																									IL_1c5b:
																									array2[num6 - 1] = 3;
																									goto IL_1c6f;
																									IL_1c6f:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1cae;
																									IL_1cae:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_1cc1:
																									if (55 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1ccf;
																									IL_1ccf:
																									if (55 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1cdd;
																									IL_1cdd:
																									((delegate*<LineRenderer, int, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									num = 232;
																									goto IL_1d24;
																									IL_1d24:
																									num6 -= 2;
																									goto IL_1d32;
																									IL_1d32:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_1d45:
																									if (57 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1d53;
																									IL_1d53:
																									if (57 > b)
																									{
																									}
																									goto end_IL_0830;
																									IL_1d66:
																									if (54 > b)
																									{
																										goto IL_1d74;
																									}
																									num = 406;
																									goto IL_1f10;
																									IL_1d74:
																									if (52 >= b)
																									{
																										goto IL_1d82;
																									}
																									goto IL_1e85;
																									IL_1d82:
																									if (52 > b)
																									{
																										goto IL_1d90;
																									}
																									num = 450;
																									goto IL_1e26;
																									IL_1d90:
																									if (51 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1d9e;
																									IL_1d9e:
																									if (51 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1dac;
																									IL_1dac:
																									((delegate*<LineRenderer, bool, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																									num = 357;
																									goto IL_1df3;
																									IL_1df3:
																									num6 -= 2;
																									goto IL_1e01;
																									IL_1e01:
																									ptr2 += 8;
																									num = 337;
																									goto IL_22ad;
																									IL_227c:
																									num6 -= 2;
																									goto IL_228a;
																									IL_1e26:
																									((delegate*<LineRenderer, float, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																									goto IL_1e64;
																									IL_1e64:
																									num6 -= 2;
																									goto IL_1e72;
																									IL_1e72:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_1e85:
																									if (53 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1e93;
																									IL_1e93:
																									if (53 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_1ea1;
																									IL_1ea1:
																									array2[num6 - 1] = 3;
																									goto IL_1eb5;
																									IL_1eb5:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1ef4;
																									IL_1ef4:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_223f:
																									((delegate*<LineRenderer, Color, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
																									goto IL_227c;
																									IL_1f10:
																									array2[num6 - 1] = 0;
																									goto IL_1f24;
																									IL_1f24:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1f63;
																									IL_1f63:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_1f76:
																									if (50 <= b)
																									{
																										goto IL_1f81;
																									}
																									goto IL_1fe7;
																									IL_1f81:
																									array2[num6 - 1] = 3;
																									goto IL_1f95;
																									IL_1f95:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1fd4;
																									IL_1fd4:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_1fe7:
																									if (46 >= b)
																									{
																										goto IL_1ff5;
																									}
																									goto IL_2127;
																									IL_1ff5:
																									if (46 > b)
																									{
																										goto IL_2003;
																									}
																									goto IL_20c8;
																									IL_2003:
																									if (44 >= b)
																									{
																										goto IL_200e;
																									}
																									goto IL_2051;
																									IL_200e:
																									if (44 > b)
																									{
																										goto end_IL_0830;
																									}
																									num = 156;
																									goto IL_2025;
																									IL_228a:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_2025:
																									global::_003CModule_003E.gameObject_27 = (GameObject)array3[num6 - 1];
																									goto IL_203e;
																									IL_203e:
																									num6--;
																									goto IL_22ad;
																									IL_2051:
																									if (45 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_205f;
																									IL_205f:
																									if (45 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_206d;
																									IL_206d:
																									array2[num6] = 4;
																									goto IL_207b;
																									IL_207b:
																									array3[num6] = ((delegate*<Color>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
																									num = 301;
																									goto IL_20a7;
																									IL_20a7:
																									num6++;
																									goto IL_20b5;
																									IL_20b5:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_20c8:
																									array2[num6 - 1] = 5;
																									goto IL_20dc;
																									IL_20dc:
																									array3[num6 - 1] = ((delegate*<Color, Material>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																									goto IL_2114;
																									IL_2114:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_2127:
																									if (48 >= b)
																									{
																										goto IL_2135;
																									}
																									goto IL_2229;
																									IL_2135:
																									if (48 <= b)
																									{
																										goto IL_2140;
																									}
																									goto IL_21af;
																									IL_2140:
																									array2[num6 - 1] = 3;
																									num = 405;
																									goto IL_215d;
																									IL_215d:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_219c;
																									IL_219c:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_21af:
																									if (47 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_21bd;
																									IL_21bd:
																									if (47 > b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_21cb;
																									IL_21cb:
																									((delegate*<Renderer, Material, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Material)array3[num6 - 1]);
																									goto IL_2208;
																									IL_2208:
																									num6 -= 2;
																									goto IL_2216;
																									IL_2216:
																									ptr2 += 8;
																									goto IL_22ad;
																									IL_2229:
																									if (49 < b)
																									{
																										goto end_IL_0830;
																									}
																									goto IL_2234;
																								}
																								break;
																							}
																							goto IL_0ceb;
																							IL_151d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_1536;
																							IL_0ceb:
																							if (29 > b)
																							{
																								goto IL_0cf9;
																							}
																							num = 55;
																							goto IL_156e;
																							IL_0cf9:
																							if (14 >= b)
																							{
																								goto IL_0d07;
																							}
																							goto IL_1087;
																							IL_0d07:
																							if (14 > b)
																							{
																								goto IL_0d15;
																							}
																							goto IL_1036;
																							IL_0d15:
																							if (7 >= b)
																							{
																								goto IL_0d23;
																							}
																							goto IL_0ea5;
																							IL_0d23:
																							if (7 <= b)
																							{
																								goto IL_0d2e;
																							}
																							goto IL_0d95;
																							IL_0d2e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d6e;
																							IL_0d6e:
																							array2[num6 - 2] = 0;
																							goto IL_0d82;
																							IL_0d82:
																							num6--;
																							goto IL_22ad;
																							IL_0d95:
																							if (3 >= b)
																							{
																								goto IL_0da3;
																							}
																							goto IL_1638;
																							IL_0da3:
																							if (3 <= b)
																							{
																								goto IL_0dae;
																							}
																							goto IL_0df8;
																							IL_0dae:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0dd7;
																							IL_0dd7:
																							ptr2 += 8;
																							goto IL_0de5;
																							IL_0de5:
																							num6--;
																							goto IL_22ad;
																							IL_0df8:
																							if (1 < b)
																							{
																								goto IL_0e06;
																							}
																							num = 205;
																							goto IL_0e92;
																							IL_0e06:
																							if (2 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_0e14;
																							IL_0e14:
																							if (2 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_0e22;
																							IL_0e22:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0e62;
																							IL_0e62:
																							array2[num6 - 2] = 0;
																							goto IL_0e76;
																							IL_0e76:
																							num6--;
																							goto IL_22ad;
																							IL_1544:
																							num6++;
																							goto IL_1552;
																							IL_0e92:
																							if (1 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_185c;
																							IL_185c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_1875;
																							IL_1875:
																							array2[num6] = 0;
																							goto IL_1883;
																							IL_1883:
																							num6++;
																							goto IL_1891;
																							IL_1891:
																							ptr2 += 8;
																							num = 98;
																							goto IL_22ad;
																							IL_1638:
																							if (5 >= b)
																							{
																								goto IL_1646;
																							}
																							goto IL_1734;
																							IL_1646:
																							if (5 <= b)
																							{
																								goto IL_1651;
																							}
																							goto IL_16c1;
																							IL_1651:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1691;
																							IL_1691:
																							array2[num6 - 2] = 0;
																							goto IL_16a5;
																							IL_16a5:
																							num6--;
																							num = 48;
																							goto IL_22ad;
																							IL_16c1:
																							if (4 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_16cf;
																							IL_16cf:
																							if (4 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_16dd;
																							IL_16dd:
																							array2[num6] = 0;
																							goto IL_16eb;
																							IL_16eb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_170e;
																							IL_170e:
																							array3[num6] = null;
																							goto IL_1718;
																							IL_1718:
																							num6++;
																							num = 464;
																							goto IL_181a;
																							IL_181a:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_1734:
																							if (6 < b)
																							{
																								goto end_IL_0830;
																							}
																							num = 263;
																							goto IL_174b;
																							IL_1552:
																							ptr2 += 16;
																							goto IL_22ad;
																							IL_174b:
																							if (6 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1759;
																							IL_1759:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1799;
																							IL_1799:
																							array2[num6 - 2] = 0;
																							goto IL_17ad;
																							IL_17ad:
																							num6--;
																							goto IL_22ad;
																							IL_0ea5:
																							if (10 >= b)
																							{
																								goto IL_0eb3;
																							}
																							goto IL_0f62;
																							IL_0eb3:
																							if (10 <= b)
																							{
																								goto IL_0ebe;
																							}
																							goto IL_0f33;
																							IL_0ebe:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0f20;
																							IL_0f20:
																							num6 -= 2;
																							goto IL_22ad;
																							IL_0f33:
																							if (8 >= b)
																							{
																								goto IL_0f41;
																							}
																							goto IL_1a01;
																							IL_0f41:
																							if (8 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_0f4f;
																							IL_0f4f:
																							num6--;
																							goto IL_22ad;
																							IL_1a01:
																							if (9 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1a0f;
																							IL_1a0f:
																							if (9 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1a1d;
																							IL_1a1d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1a5d;
																							IL_1a5d:
																							array2[num6 - 2] = 0;
																							goto IL_1a71;
																							IL_1a71:
																							num6--;
																							goto IL_22ad;
																							IL_0f62:
																							if (12 >= b)
																							{
																								goto IL_0f70;
																							}
																							goto IL_1023;
																							IL_0f70:
																							if (12 <= b)
																							{
																								goto IL_22ad;
																							}
																							goto IL_0f7e;
																							IL_0f7e:
																							if (11 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_0f8c;
																							IL_0f8c:
																							if (11 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_0f9a;
																							IL_0f9a:
																							array2[num6 - 2] = 0;
																							goto IL_0fae;
																							IL_0fae:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1002;
																							IL_1002:
																							num6--;
																							goto IL_1010;
																							IL_1010:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_1023:
																							if (13 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1a84;
																							IL_1a84:
																							if (13 > b)
																							{
																								goto end_IL_0830;
																							}
																							num = 311;
																							goto IL_1a9b;
																							IL_1536:
																							array2[num6] = 3;
																							goto IL_1544;
																							IL_1a9b:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_1aaa;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_1b52;
																							IL_156e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_15ae;
																							IL_15ae:
																							array2[num6 - 2] = 3;
																							goto IL_15c2;
																							IL_15c2:
																							num6--;
																							goto IL_22ad;
																							IL_1b52:
																							array2[num6] = 5;
																							num = 328;
																							goto IL_1b69;
																							IL_1b69:
																							num6++;
																							goto IL_22ad;
																							IL_1036:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_1054;
																							IL_1054:
																							ptr2 += 8;
																							num = 126;
																							goto IL_106b;
																							IL_106b:
																							num6--;
																							num = 325;
																							goto IL_22ad;
																							IL_1087:
																							if (21 >= b)
																							{
																								goto IL_1095;
																							}
																							goto IL_1313;
																							IL_1095:
																							if (21 <= b)
																							{
																								goto IL_10a0;
																							}
																							goto IL_10b8;
																							IL_10a0:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_22ad;
																							IL_10b8:
																							if (17 >= b)
																							{
																								goto IL_10c6;
																							}
																							goto IL_11e2;
																							IL_10c6:
																							if (17 > b)
																							{
																								goto IL_10d4;
																							}
																							goto IL_17c0;
																							IL_10d4:
																							if (15 >= b)
																							{
																								goto IL_10df;
																							}
																							goto IL_1138;
																							IL_10df:
																							if (15 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_10ed;
																							IL_10ed:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1116;
																							IL_1116:
																							array2[num6 - 1] = 5;
																							num = 136;
																							goto IL_22ad;
																							IL_1138:
																							if (16 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1146;
																							IL_1146:
																							if (16 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1154;
																							IL_1154:
																							array2[num6] = array2[num6 - 1];
																							num = 355;
																							goto IL_1175;
																							IL_1175:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_1193;
																							IL_1193:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_11b7;
																							IL_11b7:
																							array3[num6] = array3[num6 - 1];
																							goto IL_11cf;
																							IL_11cf:
																							num6++;
																							goto IL_22ad;
																							IL_17c0:
																							array2[num6] = 5;
																							goto IL_17ce;
																							IL_17ce:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_17e6;
																							IL_17e6:
																							num6++;
																							goto IL_17f4;
																							IL_17f4:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_11e2:
																							if (19 >= b)
																							{
																								goto IL_11f0;
																							}
																							goto IL_12d0;
																							IL_11f0:
																							if (19 <= b)
																							{
																								goto IL_11fb;
																							}
																							goto IL_125a;
																							IL_11fb:
																							array2[num6 - 1] = 5;
																							goto IL_120f;
																							IL_120f:
																							array3[num6 - 1] = ((delegate*<string[], string>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_1247;
																							IL_1247:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_125a:
																							if (18 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1268;
																							IL_1268:
																							if (18 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1276;
																							IL_1276:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_12b4;
																							IL_12b4:
																							num6 -= 3;
																							num = 192;
																							goto IL_22ad;
																							IL_12d0:
																							if (20 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_12de;
																							IL_12de:
																							if (20 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_12ec;
																							IL_12ec:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							num = 465;
																							goto IL_182d;
																							IL_182d:
																							array2[num6] = 1;
																							goto IL_183b;
																							IL_183b:
																							num6++;
																							goto IL_1849;
																							IL_1849:
																							ptr2 += 16;
																							goto IL_22ad;
																							IL_1313:
																							if (25 >= b)
																							{
																								goto IL_1321;
																							}
																							goto IL_142a;
																							IL_1321:
																							if (25 <= b)
																							{
																								goto IL_132c;
																							}
																							goto IL_138b;
																							IL_132c:
																							array3[num6 - 1] = ((delegate*<Class180, LineRenderer>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((Class180)array3[num6 - 1]);
																							goto IL_1364;
																							IL_1364:
																							array2[num6 - 1] = 5;
																							goto IL_1378;
																							IL_1378:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_138b:
																							if (23 >= b)
																							{
																								goto IL_1396;
																							}
																							goto IL_1409;
																							IL_1396:
																							if (23 <= b)
																							{
																								goto IL_13a4;
																							}
																							goto IL_1b7c;
																							IL_13a4:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_13f6;
																							IL_13f6:
																							num6--;
																							goto IL_22ad;
																							IL_1b7c:
																							if (22 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1b8a;
																							IL_1b8a:
																							if (22 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1b98;
																							IL_1b98:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_1bd9;
																							IL_1bd9:
																							array2[num6 - 2] = 0;
																							goto IL_1bed;
																							IL_1bed:
																							num6--;
																							goto IL_22ad;
																							IL_1409:
																							if (24 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1417;
																							IL_1417:
																							if (24 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_15e8;
																							IL_15e8:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_1600;
																							IL_1600:
																							array2[num6] = 5;
																							goto IL_160e;
																							IL_160e:
																							num6++;
																							num = 110;
																							goto IL_1625;
																							IL_1625:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_142a:
																							if (27 >= b)
																							{
																								goto IL_1438;
																							}
																							goto IL_1501;
																							IL_1438:
																							if (27 > b)
																							{
																								goto IL_1443;
																							}
																							goto IL_14b1;
																							IL_1443:
																							if (26 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_1451;
																							IL_1451:
																							if (26 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_145f;
																							IL_145f:
																							array2[num6] = 4;
																							goto IL_146d;
																							IL_146d:
																							array3[num6] = ((delegate*<Color>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
																							goto IL_1490;
																							IL_1490:
																							num6++;
																							goto IL_149e;
																							IL_149e:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_14b1:
																							((delegate*<LineRenderer, Color, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
																							goto IL_14ee;
																							IL_14ee:
																							num6 -= 2;
																							goto IL_1c00;
																							IL_1c00:
																							ptr2 += 8;
																							goto IL_22ad;
																							IL_1501:
																							if (28 < b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_150f;
																							IL_150f:
																							if (28 > b)
																							{
																								goto end_IL_0830;
																							}
																							goto IL_151d;
																						}
																						goto end_IL_0840;
																						continue;
																						end_IL_0830:
																						break;
																						IL_0830:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_22ad;
																				continue;
																				end_IL_0840:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1aaa:
			while (true)
			{
				IL_1aaa_2:
				array = new byte[4];
				while (true)
				{
					IL_1ab8:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						num = 328;
						while (true)
						{
							IL_1b69_2:
							num6++;
							while (true)
							{
								IL_22ad_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0840_2:
											if (b >= 1)
											{
												while (b <= 57)
												{
													while (true)
													{
														if (29 < b)
														{
															while (true)
															{
																if (43 >= b)
																{
																	while (true)
																	{
																		IL_0803_2:
																		if (43 <= b)
																		{
																			while (true)
																			{
																				IL_07ed_2:
																				array2[num6 - 1] = 5;
																				while (true)
																				{
																					IL_07aa_2:
																					array3[num6 - 1] = ((delegate*<string, GameObject>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																					num = 482;
																					while (true)
																					{
																						if (num != 482)
																						{
																							if (num != 1463)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 310:
																								goto IL_07aa_2;
																							case 58:
																							case 354:
																								goto IL_07ed_2;
																							case 109:
																								goto IL_0803_2;
																							case 139:
																								goto end_IL_0803_2;
																							case 6:
																								goto end_IL_0810;
																							case 207:
																								goto end_IL_0820;
																							case 180:
																								goto IL_0840_2;
																							case 366:
																								goto end_IL_0840_2;
																							case 371:
																							case 443:
																								goto end_IL_0850;
																							case 101:
																								goto IL_086b_2;
																							case 412:
																								goto IL_0884_2;
																							case 233:
																								goto IL_088f_2;
																							case 105:
																								goto IL_089d_2;
																							case 282:
																							case 359:
																								goto end_IL_0797_2;
																							case 129:
																								goto IL_08ce_2;
																							case 84:
																								goto IL_08ea_2;
																							case 313:
																								goto IL_08f8_2;
																							case 321:
																								goto IL_0903_2;
																							case 12:
																							case 70:
																								goto IL_0911_2;
																							case 230:
																								goto IL_0925_2;
																							case 1:
																								goto IL_095d_2;
																							case 347:
																								goto IL_0970_2;
																							case 167:
																								goto IL_097e_2;
																							case 5:
																							case 199:
																								goto IL_0995_2;
																							case 254:
																								goto IL_09cb_2;
																							case 417:
																								goto IL_09de_2;
																							case 158:
																								goto IL_09ec_2;
																							case 208:
																							case 260:
																								goto IL_09fa_2;
																							case 410:
																								goto IL_0a38_2;
																							case 140:
																								goto IL_0a46_2;
																							case 426:
																								goto IL_0a59_2;
																							case 227:
																								goto IL_0a67_2;
																							case 308:
																							case 397:
																								goto IL_0a75_2;
																							case 191:
																								goto IL_0ab5_2;
																							case 20:
																								goto IL_0ac9_2;
																							case 435:
																								goto IL_0adc_2;
																							case 384:
																								goto IL_0aea_2;
																							case 380:
																								goto IL_0af8_2;
																							case 286:
																							case 415:
																								goto IL_0b03_2;
																							case 7:
																								goto IL_0b17_2;
																							case 379:
																								goto IL_0b64_2;
																							case 178:
																								goto IL_0b77_2;
																							case 326:
																								goto IL_0b82_2;
																							case 177:
																							case 190:
																								goto IL_0b90_2;
																							case 132:
																								goto IL_0ba4_2;
																							case 2:
																								goto IL_0be3_2;
																							case 433:
																								goto IL_0bf6_2;
																							case 297:
																								goto IL_0c04_2;
																							case 169:
																							case 294:
																								goto IL_0c12_2;
																							case 76:
																								goto IL_0c1c_2;
																							case 103:
																								goto IL_0c2a_2;
																							case 314:
																								goto IL_0c3d_2;
																							case 51:
																							case 436:
																								goto IL_0c4d_2;
																							case 93:
																								goto IL_0c61_2;
																							case 289:
																								goto IL_0ca0_2;
																							case 439:
																								goto IL_0cb3_2;
																							case 88:
																								goto IL_0cc1_2;
																							case 96:
																							case 424:
																								goto IL_0ccf_2;
																							case 452:
																								goto IL_0ceb_2;
																							case 155:
																								goto IL_0cf9_2;
																							case 332:
																								goto IL_0d07_2;
																							case 258:
																								goto IL_0d15_2;
																							case 358:
																								goto IL_0d23_2;
																							case 271:
																							case 356:
																								goto IL_0d2e_2;
																							case 451:
																								goto IL_0d6e_2;
																							case 278:
																								goto IL_0d82_2;
																							case 9:
																								goto IL_0d95_2;
																							case 344:
																								goto IL_0da3_2;
																							case 292:
																							case 333:
																								goto IL_0dae_2;
																							case 23:
																								goto IL_0dd7_2;
																							case 320:
																								goto IL_0de5_2;
																							case 131:
																								goto IL_0df8_2;
																							case 441:
																								goto IL_0e06_2;
																							case 262:
																								goto IL_0e14_2;
																							case 3:
																							case 259:
																								goto IL_0e22_2;
																							case 39:
																								goto IL_0e62_2;
																							case 183:
																								goto IL_0e76_2;
																							case 205:
																								goto IL_0e92_2;
																							case 414:
																								goto IL_0ea5_2;
																							case 224:
																								goto IL_0eb3_2;
																							case 267:
																							case 429:
																								goto IL_0ebe_2;
																							case 219:
																								goto IL_0f20_2;
																							case 423:
																								goto IL_0f33_2;
																							case 53:
																								goto IL_0f41_2;
																							case 63:
																							case 446:
																								goto IL_0f4f_2;
																							case 74:
																								goto IL_0f62_2;
																							case 274:
																								goto IL_0f70_2;
																							case 89:
																								goto IL_0f7e_2;
																							case 402:
																								goto IL_0f8c_2;
																							case 113:
																							case 442:
																								goto IL_0f9a_2;
																							case 409:
																								goto IL_0fae_2;
																							case 206:
																								goto IL_1002_2;
																							case 4:
																								goto IL_1010_2;
																							case 124:
																								goto IL_1023_2;
																							case 114:
																							case 422:
																								goto IL_1036_2;
																							case 57:
																								goto IL_1054_2;
																							case 126:
																								goto IL_106b_2;
																							case 374:
																								goto IL_1087_2;
																							case 335:
																								goto IL_1095_2;
																							case 123:
																							case 367:
																								goto IL_10a0_2;
																							case 82:
																								goto IL_10b8_2;
																							case 185:
																								goto IL_10c6_2;
																							case 8:
																								goto IL_10d4_2;
																							case 217:
																								goto IL_10df_2;
																							case 176:
																							case 307:
																								goto IL_10ed_2;
																							case 240:
																								goto IL_1116_2;
																							case 189:
																								goto IL_1138_2;
																							case 339:
																								goto IL_1146_2;
																							case 223:
																							case 381:
																								goto IL_1154_2;
																							case 355:
																								goto IL_1175_2;
																							case 407:
																								goto IL_1193_2;
																							case 77:
																								goto IL_11b7_2;
																							case 264:
																								goto IL_11cf_2;
																							case 418:
																								goto IL_11e2_2;
																							case 340:
																								goto IL_11f0_2;
																							case 349:
																							case 388:
																								goto IL_11fb_2;
																							case 363:
																								goto IL_120f_2;
																							case 97:
																								goto IL_1247_2;
																							case 60:
																								goto IL_125a_2;
																							case 195:
																								goto IL_1268_2;
																							case 148:
																							case 434:
																								goto IL_1276_2;
																							case 316:
																								goto IL_12b4_2;
																							case 159:
																								goto IL_12d0_2;
																							case 152:
																								goto IL_12de_2;
																							case 165:
																							case 210:
																								goto IL_12ec_2;
																							case 268:
																								goto IL_1313_2;
																							case 369:
																								goto IL_1321_2;
																							case 116:
																							case 150:
																								goto IL_132c_2;
																							case 275:
																								goto IL_1364_2;
																							case 411:
																								goto IL_1378_2;
																							case 377:
																								goto IL_138b_2;
																							case 251:
																								goto IL_1396_2;
																							case 162:
																							case 447:
																								goto IL_13a4_2;
																							case 241:
																								goto IL_13f6_2;
																							case 336:
																								goto IL_1409_2;
																							case 211:
																								goto IL_1417_2;
																							case 296:
																								goto IL_142a_2;
																							case 295:
																								goto IL_1438_2;
																							case 202:
																								goto IL_1443_2;
																							case 401:
																								goto IL_1451_2;
																							case 187:
																							case 421:
																								goto IL_145f_2;
																							case 42:
																								goto IL_146d_2;
																							case 54:
																								goto IL_1490_2;
																							case 448:
																								goto IL_149e_2;
																							case 69:
																							case 323:
																								goto IL_14b1_2;
																							case 378:
																								goto IL_14ee_2;
																							case 171:
																								goto IL_1501_2;
																							case 75:
																								goto IL_150f_2;
																							case 281:
																							case 291:
																								goto IL_151d_2;
																							case 34:
																								goto IL_1536_2;
																							case 312:
																								goto IL_1544_2;
																							case 193:
																								goto IL_1552_2;
																							case 55:
																							case 428:
																								goto IL_156e_2;
																							case 329:
																								goto IL_15ae_2;
																							case 130:
																								goto IL_15c2_2;
																							case 455:
																								goto IL_15d5_2;
																							case 91:
																							case 456:
																								goto IL_15e8_2;
																							case 293:
																								goto IL_1600_2;
																							case 438:
																								goto IL_160e_2;
																							case 110:
																								goto IL_1625_2;
																							case 458:
																								goto IL_1638_2;
																							case 453:
																								goto IL_1646_2;
																							case 327:
																							case 330:
																								goto IL_1651_2;
																							case 174:
																								goto IL_1691_2;
																							case 385:
																								goto IL_16a5_2;
																							case 209:
																								goto IL_16c1_2;
																							case 27:
																								goto IL_16cf_2;
																							case 67:
																							case 454:
																								goto IL_16dd_2;
																							case 393:
																								goto IL_16eb_2;
																							case 142:
																								goto IL_170e_2;
																							case 317:
																								goto IL_1718_2;
																							case 19:
																								goto IL_1734_2;
																							case 263:
																								goto IL_174b_2;
																							case 17:
																							case 203:
																								goto IL_1759_2;
																							case 290:
																								goto IL_1799_2;
																							case 376:
																								goto IL_17ad_2;
																							case 394:
																							case 462:
																								goto IL_17c0_2;
																							case 160:
																								goto IL_17ce_2;
																							case 111:
																								goto IL_17e6_2;
																							case 269:
																								goto IL_17f4_2;
																							case 463:
																								goto IL_1807_2;
																							case 464:
																								goto IL_181a_2;
																							case 465:
																								goto IL_182d_2;
																							case 368:
																								goto IL_183b_2;
																							case 261:
																								goto IL_1849_2;
																							case 360:
																							case 466:
																								goto IL_185c_2;
																							case 214:
																								goto IL_1875_2;
																							case 243:
																								goto IL_1883_2;
																							case 318:
																								goto IL_1891_2;
																							case 467:
																								goto IL_18ad_2;
																							case 468:
																								goto IL_18c0_2;
																							case 65:
																							case 220:
																								goto IL_18cb_2;
																							case 391:
																								goto IL_190b_2;
																							case 201:
																								goto IL_191f_2;
																							case 427:
																								goto IL_1932_2;
																							case 92:
																								goto IL_1940_2;
																							case 315:
																							case 457:
																								goto IL_194e_2;
																							case 272:
																								goto IL_1962_2;
																							case 134:
																								goto IL_19a1_2;
																							case 122:
																							case 469:
																								goto IL_19b4_2;
																							case 420:
																								goto IL_19d2_2;
																							case 238:
																								goto IL_19e0_2;
																							case 24:
																								goto IL_19ee_2;
																							case 470:
																								goto IL_1a01_2;
																							case 16:
																								goto IL_1a0f_2;
																							case 11:
																							case 108:
																								goto IL_1a1d_2;
																							case 365:
																								goto IL_1a5d_2;
																							case 21:
																								goto IL_1a71_2;
																							case 472:
																								goto IL_1a84_2;
																							case 95:
																							case 311:
																								goto IL_1a9b_2;
																							case 449:
																								goto end_IL_0860;
																							case 328:
																								goto IL_1b69_2;
																							case 473:
																								goto IL_1b7c_2;
																							case 204:
																								goto IL_1b8a_2;
																							case 334:
																							case 386:
																								goto IL_1b98_2;
																							case 26:
																								goto IL_1bd9_2;
																							case 460:
																								goto IL_1bed_2;
																							case 475:
																								goto IL_1c00_2;
																							case 324:
																								goto IL_1c26_2;
																							case 284:
																								goto IL_1c34_2;
																							case 36:
																								goto IL_1c42_2;
																							case 396:
																								goto IL_1c50_2;
																							case 125:
																							case 151:
																								goto IL_1c5b_2;
																							case 168:
																								goto IL_1c6f_2;
																							case 163:
																								goto IL_1cae_2;
																							case 31:
																								goto IL_1cc1_2;
																							case 218:
																								goto IL_1ccf_2;
																							case 306:
																							case 437:
																								goto IL_1cdd_2;
																							case 232:
																								goto IL_1d24_2;
																							case 390:
																								goto IL_1d32_2;
																							case 117:
																								goto IL_1d45_2;
																							case 300:
																								goto IL_1d53_2;
																							case 226:
																								goto IL_1d66_2;
																							case 52:
																								goto IL_1d74_2;
																							case 403:
																								goto IL_1d82_2;
																							case 175:
																								goto IL_1d90_2;
																							case 14:
																								goto IL_1d9e_2;
																							case 127:
																							case 197:
																								goto IL_1dac_2;
																							case 357:
																								goto IL_1df3_2;
																							case 348:
																								goto IL_1e01_2;
																							case 47:
																							case 450:
																								goto IL_1e26_2;
																							case 135:
																								goto IL_1e64_2;
																							case 353:
																								goto IL_1e72_2;
																							case 444:
																								goto IL_1e85_2;
																							case 265:
																								goto IL_1e93_2;
																							case 382:
																							case 425:
																								goto IL_1ea1_2;
																							case 331:
																								goto IL_1eb5_2;
																							case 237:
																								goto IL_1ef4_2;
																							case 25:
																							case 406:
																								goto IL_1f10_2;
																							case 283:
																								goto IL_1f24_2;
																							case 430:
																								goto IL_1f63_2;
																							case 445:
																								goto IL_1f76_2;
																							case 279:
																							case 372:
																								goto IL_1f81_2;
																							case 81:
																								goto IL_1f95_2;
																							case 270:
																								goto IL_1fd4_2;
																							case 28:
																								goto IL_1fe7_2;
																							case 343:
																								goto IL_1ff5_2;
																							case 319:
																								goto IL_2003_2;
																							case 212:
																								goto IL_200e_2;
																							case 45:
																							case 156:
																								goto IL_2025_2;
																							case 15:
																								goto IL_203e_2;
																							case 285:
																								goto IL_2051_2;
																							case 102:
																								goto IL_205f_2;
																							case 303:
																							case 398:
																								goto IL_206d_2;
																							case 302:
																								goto IL_207b_2;
																							case 301:
																								goto IL_20a7_2;
																							case 147:
																								goto IL_20b5_2;
																							case 213:
																							case 239:
																								goto IL_20c8_2;
																							case 41:
																								goto IL_20dc_2;
																							case 144:
																								goto IL_2114_2;
																							case 44:
																								goto IL_2127_2;
																							case 287:
																								goto IL_2135_2;
																							case 80:
																							case 408:
																								goto IL_2140_2;
																							case 405:
																								goto IL_215d_2;
																							case 373:
																								goto IL_219c_2;
																							case 35:
																								goto IL_21af_2;
																							case 250:
																								goto IL_21bd_2;
																							case 346:
																							case 459:
																								goto IL_21cb_2;
																							case 137:
																								goto IL_2208_2;
																							case 146:
																								goto IL_2216_2;
																							case 194:
																								goto IL_2229_2;
																							case 273:
																								goto IL_2234_2;
																							case 100:
																							case 361:
																								goto IL_223f_2;
																							case 161:
																								goto IL_227c_2;
																							case 128:
																								goto IL_228a_2;
																							case 18:
																							case 32:
																							case 33:
																							case 37:
																							case 38:
																							case 40:
																							case 49:
																							case 61:
																							case 62:
																							case 71:
																							case 72:
																							case 78:
																							case 85:
																							case 87:
																							case 104:
																							case 107:
																							case 112:
																							case 115:
																							case 121:
																							case 138:
																							case 153:
																							case 166:
																							case 170:
																							case 172:
																							case 173:
																							case 181:
																							case 186:
																							case 196:
																							case 198:
																							case 200:
																							case 216:
																							case 221:
																							case 229:
																							case 231:
																							case 235:
																							case 244:
																							case 245:
																							case 247:
																							case 249:
																							case 252:
																							case 253:
																							case 255:
																							case 266:
																							case 276:
																							case 277:
																							case 298:
																							case 309:
																							case 338:
																							case 341:
																							case 342:
																							case 352:
																							case 364:
																							case 375:
																							case 383:
																							case 400:
																							case 416:
																							case 419:
																							case 461:
																							case 471:
																							case 474:
																								goto end_IL_0830_2;
																							case 0:
																							case 10:
																							case 13:
																							case 30:
																							case 48:
																							case 50:
																							case 56:
																							case 59:
																							case 64:
																							case 66:
																							case 68:
																							case 73:
																							case 79:
																							case 83:
																							case 86:
																							case 90:
																							case 94:
																							case 98:
																							case 118:
																							case 119:
																							case 120:
																							case 133:
																							case 136:
																							case 141:
																							case 143:
																							case 149:
																							case 154:
																							case 179:
																							case 182:
																							case 184:
																							case 188:
																							case 192:
																							case 215:
																							case 222:
																							case 225:
																							case 228:
																							case 234:
																							case 236:
																							case 242:
																							case 246:
																							case 248:
																							case 280:
																							case 288:
																							case 299:
																							case 304:
																							case 305:
																							case 322:
																							case 325:
																							case 337:
																							case 345:
																							case 350:
																							case 362:
																							case 370:
																							case 387:
																							case 389:
																							case 395:
																							case 399:
																							case 404:
																							case 431:
																							case 432:
																								goto IL_22ad_2;
																							case 351:
																								ptr2 = ptr;
																								goto IL_22ad_2;
																							case 413:
																								ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InTypeFixedCountFlagSuspendRequested.ManifestEnvelopeSetOut);
																								goto case 351;
																							case 29:
																								array7[0] = this;
																								goto case 413;
																							case 106:
																								array7 = new object[14];
																								num = 29;
																								goto case 29;
																							case 99:
																								array6 = new long[4];
																								goto case 106;
																							case 392:
																								array5 = new int[7];
																								goto case 99;
																							case 157:
																								array4 = new int[4];
																								goto case 392;
																							case 22:
																								array3 = new object[4];
																								goto case 157;
																							case 440:
																								array2 = new byte[4];
																								goto case 22;
																							case 164:
																								num4 = num2 * 8;
																								num = 440;
																								goto case 440;
																							case 145:
																								num3 = num2 * 4;
																								goto case 164;
																							case 256:
																								num2 = 1;
																								goto case 145;
																							case 257:
																								goto end_IL_1b52;
																							case 43:
																							case 46:
																								return;
																							}
																							continue;
																						}
																						ptr2 += 8;
																						goto IL_22ad_2;
																						continue;
																						end_IL_0797_2:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_08ab_2;
																		}
																		goto IL_086b_2;
																		IL_09cb_2:
																		num6 -= 2;
																		goto IL_22ad_2;
																		IL_086b_2:
																		if (36 < b)
																		{
																			goto IL_0884_2;
																		}
																		num = 435;
																		goto IL_0adc_2;
																		IL_0c4d_2:
																		array2[num6 - 1] = 3;
																		goto IL_0c61_2;
																		IL_0adc_2:
																		if (36 > b)
																		{
																			goto IL_0aea_2;
																		}
																		goto IL_19b4_2;
																		IL_0aea_2:
																		if (32 >= b)
																		{
																			goto IL_0af8_2;
																		}
																		goto IL_0c3d_2;
																		IL_0af8_2:
																		if (32 <= b)
																		{
																			goto IL_0b03_2;
																		}
																		goto IL_0b77_2;
																		IL_0b03_2:
																		array2[num6 - 2] = 0;
																		goto IL_0b17_2;
																		IL_0b17_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																		goto IL_0b64_2;
																		IL_0b64_2:
																		num6--;
																		goto IL_15d5_2;
																		IL_15d5_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0b77_2:
																		if (30 >= b)
																		{
																			goto IL_0b82_2;
																		}
																		goto IL_0bf6_2;
																		IL_0b82_2:
																		if (30 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0b90_2;
																		IL_0b90_2:
																		array2[num6 - 1] = 0;
																		goto IL_0ba4_2;
																		IL_0ba4_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0be3_2;
																		IL_0be3_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0bf6_2:
																		if (31 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0c04_2;
																		IL_0c04_2:
																		if (31 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0c12_2;
																		IL_0c12_2:
																		array3[num6] = null;
																		goto IL_0c1c_2;
																		IL_0c1c_2:
																		array2[num6] = 5;
																		goto IL_0c2a_2;
																		IL_0c2a_2:
																		num6++;
																		goto IL_22ad_2;
																		IL_0c3d_2:
																		if (34 < b)
																		{
																			goto IL_0cb3_2;
																		}
																		goto IL_18c0_2;
																		IL_18c0_2:
																		if (34 <= b)
																		{
																			goto IL_18cb_2;
																		}
																		goto IL_1932_2;
																		IL_18cb_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_190b_2;
																		IL_190b_2:
																		array2[num6 - 2] = 3;
																		goto IL_191f_2;
																		IL_191f_2:
																		num6--;
																		goto IL_22ad_2;
																		IL_1932_2:
																		if (33 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_1940_2;
																		IL_1940_2:
																		if (33 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_194e_2;
																		IL_194e_2:
																		array2[num6 - 1] = 3;
																		goto IL_1962_2;
																		IL_1962_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_19a1_2;
																		IL_19a1_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0cb3_2:
																		if (35 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0cc1_2;
																		IL_0cc1_2:
																		if (35 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0ccf_2;
																		IL_0ccf_2:
																		num7 = ptr2;
																		num8 = -200;
																		num5 = 1;
																		ptr2 = num7 + num8;
																		goto IL_22ad_2;
																		IL_19b4_2:
																		array3[num6] = ((delegate*<GameObject>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
																		goto IL_19d2_2;
																		IL_19d2_2:
																		array2[num6] = 5;
																		goto IL_19e0_2;
																		IL_19e0_2:
																		num6++;
																		goto IL_19ee_2;
																		IL_19ee_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0884_2:
																		if (39 < b)
																		{
																			goto IL_088f_2;
																		}
																		num = 84;
																		goto IL_08ea_2;
																		IL_088f_2:
																		if (41 >= b)
																		{
																			goto IL_089d_2;
																		}
																		goto IL_09de_2;
																		IL_089d_2:
																		if (41 <= b)
																		{
																			goto IL_08ab_2;
																		}
																		goto IL_0a59_2;
																		IL_08ab_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																		num = 129;
																		goto IL_08ce_2;
																		IL_08ce_2:
																		array2[num6] = 3;
																		goto IL_1807_2;
																		IL_1807_2:
																		num6++;
																		goto IL_18ad_2;
																		IL_18ad_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0a59_2:
																		if (40 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0a67_2;
																		IL_0a67_2:
																		if (40 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0a75_2;
																		IL_0a75_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0ab5_2;
																		IL_0ab5_2:
																		array2[num6 - 2] = 3;
																		goto IL_0ac9_2;
																		IL_0ac9_2:
																		num6--;
																		goto IL_22ad_2;
																		IL_09de_2:
																		if (42 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_09ec_2;
																		IL_09ec_2:
																		if (42 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_09fa_2;
																		IL_09fa_2:
																		((delegate*<LineRenderer, float, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																		goto IL_0a38_2;
																		IL_0a38_2:
																		num6 -= 2;
																		goto IL_0a46_2;
																		IL_0a46_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0c61_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0ca0_2;
																		IL_08ea_2:
																		if (39 > b)
																		{
																			goto IL_08f8_2;
																		}
																		goto IL_0c4d_2;
																		IL_08f8_2:
																		if (37 >= b)
																		{
																			goto IL_0903_2;
																		}
																		goto IL_0970_2;
																		IL_0903_2:
																		if (37 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_0911_2;
																		IL_0911_2:
																		array2[num6 - 1] = 5;
																		goto IL_0925_2;
																		IL_0925_2:
																		array3[num6 - 1] = ((delegate*<GameObject, LineRenderer>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																		goto IL_095d_2;
																		IL_095d_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0970_2:
																		if (38 < b)
																		{
																			goto end_IL_0830_2;
																		}
																		goto IL_097e_2;
																		IL_097e_2:
																		if (38 > b)
																		{
																			goto end_IL_0830_2;
																		}
																		num = 5;
																		goto IL_0995_2;
																		IL_0ca0_2:
																		ptr2 += 8;
																		goto IL_22ad_2;
																		IL_0995_2:
																		((Class180)array3[num6 - 2]).lineRenderer_0 = (LineRenderer)array3[num6 - 1];
																		num = 254;
																		goto IL_09cb_2;
																		continue;
																		end_IL_0803_2:
																		break;
																	}
																	continue;
																}
																goto IL_1c26_2;
																IL_2234_2:
																if (49 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_223f_2;
																IL_1c26_2:
																if (50 < b)
																{
																	goto IL_1c34_2;
																}
																goto IL_1f76_2;
																IL_1c34_2:
																if (54 < b)
																{
																	goto IL_1c42_2;
																}
																goto IL_1d66_2;
																IL_1c42_2:
																if (56 >= b)
																{
																	goto IL_1c50_2;
																}
																goto IL_1d45_2;
																IL_1c50_2:
																if (56 <= b)
																{
																	goto IL_1c5b_2;
																}
																goto IL_1cc1_2;
																IL_1c5b_2:
																array2[num6 - 1] = 3;
																goto IL_1c6f_2;
																IL_1c6f_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1cae_2;
																IL_1cae_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_1cc1_2:
																if (55 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1ccf_2;
																IL_1ccf_2:
																if (55 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1cdd_2;
																IL_1cdd_2:
																((delegate*<LineRenderer, int, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																num = 232;
																goto IL_1d24_2;
																IL_1d24_2:
																num6 -= 2;
																goto IL_1d32_2;
																IL_1d32_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_1d45_2:
																if (57 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1d53_2;
																IL_1d53_2:
																if (57 > b)
																{
																}
																goto end_IL_0830_2;
																IL_1d66_2:
																if (54 > b)
																{
																	goto IL_1d74_2;
																}
																num = 406;
																goto IL_1f10_2;
																IL_1d74_2:
																if (52 >= b)
																{
																	goto IL_1d82_2;
																}
																goto IL_1e85_2;
																IL_1d82_2:
																if (52 > b)
																{
																	goto IL_1d90_2;
																}
																num = 450;
																goto IL_1e26_2;
																IL_1d90_2:
																if (51 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1d9e_2;
																IL_1d9e_2:
																if (51 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1dac_2;
																IL_1dac_2:
																((delegate*<LineRenderer, bool, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																num = 357;
																goto IL_1df3_2;
																IL_1df3_2:
																num6 -= 2;
																goto IL_1e01_2;
																IL_1e01_2:
																ptr2 += 8;
																num = 337;
																goto IL_22ad_2;
																IL_227c_2:
																num6 -= 2;
																goto IL_228a_2;
																IL_1e26_2:
																((delegate*<LineRenderer, float, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																goto IL_1e64_2;
																IL_1e64_2:
																num6 -= 2;
																goto IL_1e72_2;
																IL_1e72_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_1e85_2:
																if (53 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1e93_2;
																IL_1e93_2:
																if (53 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_1ea1_2;
																IL_1ea1_2:
																array2[num6 - 1] = 3;
																goto IL_1eb5_2;
																IL_1eb5_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1ef4_2;
																IL_1ef4_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_223f_2:
																((delegate*<LineRenderer, Color, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
																goto IL_227c_2;
																IL_1f10_2:
																array2[num6 - 1] = 0;
																goto IL_1f24_2;
																IL_1f24_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1f63_2;
																IL_1f63_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_1f76_2:
																if (50 <= b)
																{
																	goto IL_1f81_2;
																}
																goto IL_1fe7_2;
																IL_1f81_2:
																array2[num6 - 1] = 3;
																goto IL_1f95_2;
																IL_1f95_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1fd4_2;
																IL_1fd4_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_1fe7_2:
																if (46 >= b)
																{
																	goto IL_1ff5_2;
																}
																goto IL_2127_2;
																IL_1ff5_2:
																if (46 > b)
																{
																	goto IL_2003_2;
																}
																goto IL_20c8_2;
																IL_2003_2:
																if (44 >= b)
																{
																	goto IL_200e_2;
																}
																goto IL_2051_2;
																IL_200e_2:
																if (44 > b)
																{
																	goto end_IL_0830_2;
																}
																num = 156;
																goto IL_2025_2;
																IL_228a_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_2025_2:
																global::_003CModule_003E.gameObject_27 = (GameObject)array3[num6 - 1];
																goto IL_203e_2;
																IL_203e_2:
																num6--;
																goto IL_22ad_2;
																IL_2051_2:
																if (45 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_205f_2;
																IL_205f_2:
																if (45 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_206d_2;
																IL_206d_2:
																array2[num6] = 4;
																goto IL_207b_2;
																IL_207b_2:
																array3[num6] = ((delegate*<Color>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
																num = 301;
																goto IL_20a7_2;
																IL_20a7_2:
																num6++;
																goto IL_20b5_2;
																IL_20b5_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_20c8_2:
																array2[num6 - 1] = 5;
																goto IL_20dc_2;
																IL_20dc_2:
																array3[num6 - 1] = ((delegate*<Color, Material>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																goto IL_2114_2;
																IL_2114_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_2127_2:
																if (48 >= b)
																{
																	goto IL_2135_2;
																}
																goto IL_2229_2;
																IL_2135_2:
																if (48 <= b)
																{
																	goto IL_2140_2;
																}
																goto IL_21af_2;
																IL_2140_2:
																array2[num6 - 1] = 3;
																num = 405;
																goto IL_215d_2;
																IL_215d_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_219c_2;
																IL_219c_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_21af_2:
																if (47 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_21bd_2;
																IL_21bd_2:
																if (47 > b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_21cb_2;
																IL_21cb_2:
																((delegate*<Renderer, Material, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Material)array3[num6 - 1]);
																goto IL_2208_2;
																IL_2208_2:
																num6 -= 2;
																goto IL_2216_2;
																IL_2216_2:
																ptr2 += 8;
																goto IL_22ad_2;
																IL_2229_2:
																if (49 < b)
																{
																	goto end_IL_0830_2;
																}
																goto IL_2234_2;
																continue;
																end_IL_0810:
																break;
															}
															continue;
														}
														goto IL_0ceb_2;
														IL_1552_2:
														ptr2 += 16;
														goto IL_22ad_2;
														IL_0ceb_2:
														if (29 > b)
														{
															goto IL_0cf9_2;
														}
														num = 55;
														goto IL_156e_2;
														IL_0cf9_2:
														if (14 >= b)
														{
															goto IL_0d07_2;
														}
														goto IL_1087_2;
														IL_0d07_2:
														if (14 > b)
														{
															goto IL_0d15_2;
														}
														goto IL_1036_2;
														IL_0d15_2:
														if (7 >= b)
														{
															goto IL_0d23_2;
														}
														goto IL_0ea5_2;
														IL_0d23_2:
														if (7 <= b)
														{
															goto IL_0d2e_2;
														}
														goto IL_0d95_2;
														IL_0d2e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0d6e_2;
														IL_0d6e_2:
														array2[num6 - 2] = 0;
														goto IL_0d82_2;
														IL_0d82_2:
														num6--;
														goto IL_22ad_2;
														IL_0d95_2:
														if (3 >= b)
														{
															goto IL_0da3_2;
														}
														goto IL_1638_2;
														IL_0da3_2:
														if (3 <= b)
														{
															goto IL_0dae_2;
														}
														goto IL_0df8_2;
														IL_0dae_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0dd7_2;
														IL_0dd7_2:
														ptr2 += 8;
														goto IL_0de5_2;
														IL_0de5_2:
														num6--;
														goto IL_22ad_2;
														IL_0df8_2:
														if (1 < b)
														{
															goto IL_0e06_2;
														}
														num = 205;
														goto IL_0e92_2;
														IL_0e06_2:
														if (2 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_0e14_2;
														IL_0e14_2:
														if (2 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_0e22_2;
														IL_0e22_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0e62_2;
														IL_0e62_2:
														array2[num6 - 2] = 0;
														goto IL_0e76_2;
														IL_0e76_2:
														num6--;
														goto IL_22ad_2;
														IL_156e_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_15ae_2;
														IL_0e92_2:
														if (1 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_185c_2;
														IL_185c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_1875_2;
														IL_1875_2:
														array2[num6] = 0;
														goto IL_1883_2;
														IL_1883_2:
														num6++;
														goto IL_1891_2;
														IL_1891_2:
														ptr2 += 8;
														num = 98;
														goto IL_22ad_2;
														IL_1638_2:
														if (5 >= b)
														{
															goto IL_1646_2;
														}
														goto IL_1734_2;
														IL_1646_2:
														if (5 <= b)
														{
															goto IL_1651_2;
														}
														goto IL_16c1_2;
														IL_1651_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1691_2;
														IL_1691_2:
														array2[num6 - 2] = 0;
														goto IL_16a5_2;
														IL_16a5_2:
														num6--;
														num = 48;
														goto IL_22ad_2;
														IL_16c1_2:
														if (4 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_16cf_2;
														IL_16cf_2:
														if (4 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_16dd_2;
														IL_16dd_2:
														array2[num6] = 0;
														goto IL_16eb_2;
														IL_16eb_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_170e_2;
														IL_170e_2:
														array3[num6] = null;
														goto IL_1718_2;
														IL_1718_2:
														num6++;
														num = 464;
														goto IL_181a_2;
														IL_181a_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_1734_2:
														if (6 < b)
														{
															goto end_IL_0830_2;
														}
														num = 263;
														goto IL_174b_2;
														IL_15ae_2:
														array2[num6 - 2] = 3;
														goto IL_15c2_2;
														IL_174b_2:
														if (6 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1759_2;
														IL_1759_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1799_2;
														IL_1799_2:
														array2[num6 - 2] = 0;
														goto IL_17ad_2;
														IL_17ad_2:
														num6--;
														goto IL_22ad_2;
														IL_0ea5_2:
														if (10 >= b)
														{
															goto IL_0eb3_2;
														}
														goto IL_0f62_2;
														IL_0eb3_2:
														if (10 <= b)
														{
															goto IL_0ebe_2;
														}
														goto IL_0f33_2;
														IL_0ebe_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0f20_2;
														IL_0f20_2:
														num6 -= 2;
														goto IL_22ad_2;
														IL_0f33_2:
														if (8 >= b)
														{
															goto IL_0f41_2;
														}
														goto IL_1a01_2;
														IL_0f41_2:
														if (8 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_0f4f_2;
														IL_0f4f_2:
														num6--;
														goto IL_22ad_2;
														IL_1a01_2:
														if (9 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1a0f_2;
														IL_1a0f_2:
														if (9 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1a1d_2;
														IL_1a1d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1a5d_2;
														IL_1a5d_2:
														array2[num6 - 2] = 0;
														goto IL_1a71_2;
														IL_1a71_2:
														num6--;
														goto IL_22ad_2;
														IL_0f62_2:
														if (12 >= b)
														{
															goto IL_0f70_2;
														}
														goto IL_1023_2;
														IL_0f70_2:
														if (12 <= b)
														{
															goto IL_22ad_2;
														}
														goto IL_0f7e_2;
														IL_0f7e_2:
														if (11 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_0f8c_2;
														IL_0f8c_2:
														if (11 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_0f9a_2;
														IL_0f9a_2:
														array2[num6 - 2] = 0;
														goto IL_0fae_2;
														IL_0fae_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1002_2;
														IL_1002_2:
														num6--;
														goto IL_1010_2;
														IL_1010_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_1023_2:
														if (13 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1a84_2;
														IL_1a84_2:
														if (13 > b)
														{
															goto end_IL_0830_2;
														}
														num = 311;
														goto IL_1a9b_2;
														IL_15c2_2:
														num6--;
														goto IL_22ad_2;
														IL_1a9b_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_1aaa_2;
														}
														goto IL_1ab8;
														IL_1036_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_1054_2;
														IL_1054_2:
														ptr2 += 8;
														num = 126;
														goto IL_106b_2;
														IL_106b_2:
														num6--;
														num = 325;
														goto IL_22ad_2;
														IL_1087_2:
														if (21 >= b)
														{
															goto IL_1095_2;
														}
														goto IL_1313_2;
														IL_1095_2:
														if (21 <= b)
														{
															goto IL_10a0_2;
														}
														goto IL_10b8_2;
														IL_10a0_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_22ad_2;
														IL_10b8_2:
														if (17 >= b)
														{
															goto IL_10c6_2;
														}
														goto IL_11e2_2;
														IL_10c6_2:
														if (17 > b)
														{
															goto IL_10d4_2;
														}
														goto IL_17c0_2;
														IL_10d4_2:
														if (15 >= b)
														{
															goto IL_10df_2;
														}
														goto IL_1138_2;
														IL_10df_2:
														if (15 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_10ed_2;
														IL_10ed_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1116_2;
														IL_1116_2:
														array2[num6 - 1] = 5;
														num = 136;
														goto IL_22ad_2;
														IL_1138_2:
														if (16 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1146_2;
														IL_1146_2:
														if (16 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1154_2;
														IL_1154_2:
														array2[num6] = array2[num6 - 1];
														num = 355;
														goto IL_1175_2;
														IL_1175_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_1193_2;
														IL_1193_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_11b7_2;
														IL_11b7_2:
														array3[num6] = array3[num6 - 1];
														goto IL_11cf_2;
														IL_11cf_2:
														num6++;
														goto IL_22ad_2;
														IL_17c0_2:
														array2[num6] = 5;
														goto IL_17ce_2;
														IL_17ce_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_17e6_2;
														IL_17e6_2:
														num6++;
														goto IL_17f4_2;
														IL_17f4_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_11e2_2:
														if (19 >= b)
														{
															goto IL_11f0_2;
														}
														goto IL_12d0_2;
														IL_11f0_2:
														if (19 <= b)
														{
															goto IL_11fb_2;
														}
														goto IL_125a_2;
														IL_11fb_2:
														array2[num6 - 1] = 5;
														goto IL_120f_2;
														IL_120f_2:
														array3[num6 - 1] = ((delegate*<string[], string>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_1247_2;
														IL_1247_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_125a_2:
														if (18 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1268_2;
														IL_1268_2:
														if (18 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1276_2;
														IL_1276_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_12b4_2;
														IL_12b4_2:
														num6 -= 3;
														num = 192;
														goto IL_22ad_2;
														IL_12d0_2:
														if (20 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_12de_2;
														IL_12de_2:
														if (20 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_12ec_2;
														IL_12ec_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														num = 465;
														goto IL_182d_2;
														IL_182d_2:
														array2[num6] = 1;
														goto IL_183b_2;
														IL_183b_2:
														num6++;
														goto IL_1849_2;
														IL_1849_2:
														ptr2 += 16;
														goto IL_22ad_2;
														IL_1313_2:
														if (25 >= b)
														{
															goto IL_1321_2;
														}
														goto IL_142a_2;
														IL_1321_2:
														if (25 <= b)
														{
															goto IL_132c_2;
														}
														goto IL_138b_2;
														IL_132c_2:
														array3[num6 - 1] = ((delegate*<Class180, LineRenderer>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((Class180)array3[num6 - 1]);
														goto IL_1364_2;
														IL_1364_2:
														array2[num6 - 1] = 5;
														goto IL_1378_2;
														IL_1378_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_138b_2:
														if (23 >= b)
														{
															goto IL_1396_2;
														}
														goto IL_1409_2;
														IL_1396_2:
														if (23 <= b)
														{
															goto IL_13a4_2;
														}
														goto IL_1b7c_2;
														IL_13a4_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_13f6_2;
														IL_13f6_2:
														num6--;
														goto IL_22ad_2;
														IL_1b7c_2:
														if (22 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1b8a_2;
														IL_1b8a_2:
														if (22 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1b98_2;
														IL_1b98_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1bd9_2;
														IL_1bd9_2:
														array2[num6 - 2] = 0;
														goto IL_1bed_2;
														IL_1bed_2:
														num6--;
														goto IL_22ad_2;
														IL_1409_2:
														if (24 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1417_2;
														IL_1417_2:
														if (24 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_15e8_2;
														IL_15e8_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_1600_2;
														IL_1600_2:
														array2[num6] = 5;
														goto IL_160e_2;
														IL_160e_2:
														num6++;
														num = 110;
														goto IL_1625_2;
														IL_1625_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_142a_2:
														if (27 >= b)
														{
															goto IL_1438_2;
														}
														goto IL_1501_2;
														IL_1438_2:
														if (27 > b)
														{
															goto IL_1443_2;
														}
														goto IL_14b1_2;
														IL_1443_2:
														if (26 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_1451_2;
														IL_1451_2:
														if (26 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_145f_2;
														IL_145f_2:
														array2[num6] = 4;
														goto IL_146d_2;
														IL_146d_2:
														array3[num6] = ((delegate*<Color>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])();
														goto IL_1490_2;
														IL_1490_2:
														num6++;
														goto IL_149e_2;
														IL_149e_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_14b1_2:
														((delegate*<LineRenderer, Color, void>)AsyncProcessMessageBestFitDisabled[*(int*)(ptr2 + num3)])((LineRenderer)array3[num6 - 2], (Color)array3[num6 - 1]);
														goto IL_14ee_2;
														IL_14ee_2:
														num6 -= 2;
														goto IL_1c00_2;
														IL_1c00_2:
														ptr2 += 8;
														goto IL_22ad_2;
														IL_1501_2:
														if (28 < b)
														{
															goto end_IL_0830_2;
														}
														goto IL_150f_2;
														IL_150f_2:
														if (28 > b)
														{
															goto end_IL_0830_2;
														}
														goto IL_151d_2;
														IL_151d_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_1536_2;
														IL_1536_2:
														array2[num6] = 3;
														goto IL_1544_2;
														IL_1544_2:
														num6++;
														goto IL_1552_2;
														continue;
														end_IL_0820:
														break;
													}
													continue;
													end_IL_0830_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_22ad_2;
											continue;
											end_IL_0840_2:
											break;
										}
										continue;
										end_IL_0850:
										break;
									}
									continue;
									end_IL_0860:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_1b52:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static Vector3 RuntimeFeatureBidiCategory(Vector3 vector3_1)
	{
		return -vector3_1;
	}

	private static void TOKENPRIMARYGROUPgetDriveType(Class180 class180_1)
	{
		class180_1.method_1();
	}

	private static Transform ReasongetCurrentManagedThreadId(Component component_0)
	{
		return component_0.transform;
	}

	private static float GetValueOrDefaultGetMaxThreads(Vector3 vector3_1, Vector3 vector3_2)
	{
		return Vector3.Distance(vector3_1, vector3_2);
	}

	private static GorillaTagger TokenSessionReferencegetKeySpec()
	{
		return GorillaTagger.Instance;
	}

	private static Vector3 getPrivateBinPathProbeSyncStack(Transform transform_0)
	{
		return transform_0.up;
	}

	private static float getParameterTypeIsNetFxLegacyManagedDeflateStream()
	{
		return global::_003CModule_003E.float_111;
	}

	private static bool IsExplicitlyDereferencedsetDateSeparator(Class180 class180_1)
	{
		return class180_1.bool_0;
	}

	private unsafe static int smethod_7()
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 58;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DestroyChildReplica.FromXmlGetDisplayName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 45;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0300:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02f3:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02e3:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02d3:
																										if (4 > b)
																										{
																											while (true)
																											{
																												IL_02c3:
																												if (2 >= b)
																												{
																													while (true)
																													{
																														IL_02b3:
																														if (2 > b)
																														{
																															while (1 >= b)
																															{
																																while (1 <= b)
																																{
																																	num = 152;
																																	while (true)
																																	{
																																		if (num != 152)
																																		{
																																			if (num != 1133)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 85:
																																				goto IL_0290;
																																			case 2:
																																			case 124:
																																				goto IL_02a3;
																																			case 67:
																																				goto IL_02b3;
																																			case 15:
																																				goto IL_02c3;
																																			case 136:
																																				goto IL_02d3;
																																			case 142:
																																				goto IL_02e3;
																																			case 102:
																																				goto end_IL_027d;
																																			case 125:
																																				goto IL_0300;
																																			case 32:
																																				goto IL_0310;
																																			case 76:
																																				goto IL_0320;
																																			case 90:
																																				goto end_IL_0320;
																																			case 45:
																																				goto end_IL_0330;
																																			case 5:
																																				goto end_IL_0340;
																																			case 62:
																																			case 74:
																																				goto IL_0356;
																																			case 72:
																																			case 86:
																																				goto IL_036e;
																																			case 71:
																																				goto IL_038c;
																																			case 105:
																																				goto IL_039a;
																																			case 66:
																																			case 122:
																																				goto IL_03ad;
																																			case 104:
																																				goto IL_03bb;
																																			case 34:
																																			case 39:
																																				goto IL_03c9;
																																			case 23:
																																				goto IL_03f2;
																																			case 21:
																																				goto IL_040b;
																																			case 47:
																																				goto IL_0424;
																																			case 131:
																																				goto IL_0432;
																																			case 75:
																																				goto IL_0440;
																																			case 31:
																																			case 120:
																																				goto IL_0453;
																																			case 12:
																																				goto IL_0493;
																																			case 73:
																																				goto IL_04a7;
																																			case 35:
																																			case 77:
																																				goto IL_04c3;
																																			case 59:
																																				goto IL_04d1;
																																			case 50:
																																			case 134:
																																				goto IL_04dc;
																																			case 69:
																																				goto IL_051b;
																																			case 107:
																																				goto IL_052e;
																																			case 108:
																																				goto IL_053c;
																																			case 4:
																																			case 44:
																																				goto IL_054a;
																																			case 22:
																																				goto IL_0558;
																																			case 137:
																																				goto IL_0570;
																																			case 103:
																																				goto IL_057e;
																																			case 140:
																																				goto IL_0591;
																																			case 61:
																																				goto IL_059f;
																																			case 24:
																																			case 83:
																																				goto IL_05ad;
																																			case 99:
																																				goto IL_05d6;
																																			case 81:
																																				goto IL_05e4;
																																			case 119:
																																			case 145:
																																				goto IL_05f7;
																																			case 132:
																																				goto IL_0605;
																																			case 7:
																																			case 82:
																																				goto IL_0610;
																																			case 17:
																																				goto IL_0650;
																																			case 33:
																																				goto IL_0664;
																																			case 14:
																																				goto IL_0677;
																																			case 10:
																																				goto IL_0685;
																																			case 89:
																																			case 110:
																																				goto IL_0690;
																																			case 38:
																																				goto IL_069e;
																																			case 52:
																																			case 127:
																																				goto IL_06b1;
																																			case 109:
																																				goto IL_06bf;
																																			case 64:
																																				goto IL_06e2;
																																			case 84:
																																				goto IL_06f5;
																																			case 106:
																																				goto IL_0703;
																																			case 91:
																																				goto IL_0716;
																																			case 114:
																																				goto IL_0724;
																																			case 18:
																																			case 143:
																																				goto IL_0732;
																																			case 144:
																																				goto IL_0776;
																																			case 56:
																																				goto IL_078a;
																																			case 117:
																																				goto IL_07a6;
																																			case 3:
																																			case 46:
																																				goto IL_07b1;
																																			case 88:
																																				goto IL_07bc;
																																			case 113:
																																				goto IL_07dd;
																																			case 55:
																																			case 63:
																																				goto IL_07eb;
																																			case 139:
																																				goto IL_07f9;
																																			case 37:
																																			case 70:
																																				goto IL_0807;
																																			case 9:
																																				goto IL_0869;
																																			case 28:
																																			case 43:
																																				goto IL_0879;
																																			case 0:
																																			case 8:
																																			case 11:
																																			case 13:
																																			case 16:
																																			case 19:
																																			case 26:
																																			case 29:
																																			case 36:
																																			case 49:
																																			case 51:
																																			case 53:
																																			case 54:
																																			case 57:
																																			case 60:
																																			case 68:
																																			case 97:
																																			case 98:
																																			case 116:
																																			case 118:
																																			case 128:
																																			case 130:
																																			case 133:
																																			case 135:
																																			case 138:
																																				goto end_IL_0290;
																																			case 6:
																																			case 20:
																																			case 27:
																																			case 40:
																																			case 48:
																																			case 79:
																																			case 80:
																																			case 87:
																																			case 92:
																																			case 94:
																																			case 95:
																																			case 100:
																																			case 111:
																																			case 112:
																																			case 121:
																																			case 123:
																																			case 129:
																																			case 141:
																																				goto end_IL_034b;
																																			case 93:
																																				goto end_IL_08a5;
																																			case 115:
																																				goto end_IL_08b8;
																																			case 101:
																																				goto end_IL_08c2;
																																			case 78:
																																				goto end_IL_08cd;
																																			case 30:
																																			case 58:
																																				goto end_IL_08dd;
																																			case 25:
																																				goto end_IL_08ed;
																																			case 1:
																																			case 96:
																																				goto end_IL_08fd;
																																			case 41:
																																				goto end_IL_0916;
																																			case 42:
																																				goto end_IL_0926;
																																			case 65:
																																			case 126:
																																				goto IL_0941;
																																			}
																																			continue;
																																		}
																																		goto IL_040b;
																																		IL_0432:
																																		num5++;
																																		goto IL_0440;
																																		IL_0440:
																																		ptr2 += 8;
																																		goto end_IL_034b;
																																		IL_040b:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																		goto IL_0424;
																																		IL_0424:
																																		array[num5] = 0;
																																		goto IL_0432;
																																		continue;
																																		end_IL_027d:
																																		break;
																																	}
																																	goto IL_02f3;
																																	continue;
																																	end_IL_0290:
																																	break;
																																	IL_0290:;
																																}
																																break;
																																IL_02a3:;
																															}
																															break;
																														}
																														goto IL_0453;
																														IL_04a7:
																														num5--;
																														goto end_IL_034b;
																														IL_0453:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_0493;
																														IL_0493:
																														array[num5 - 2] = 0;
																														goto IL_04a7;
																													}
																													break;
																												}
																												goto IL_03ad;
																												IL_03f2:
																												array[num5 - 1] = 5;
																												goto end_IL_034b;
																												IL_03ad:
																												if (3 < b)
																												{
																													break;
																												}
																												goto IL_03bb;
																												IL_03bb:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_03c9;
																												IL_03c9:
																												array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																												goto IL_03f2;
																											}
																											break;
																										}
																										goto IL_036e;
																										IL_039a:
																										num5--;
																										goto end_IL_034b;
																										IL_036e:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_038c;
																										IL_038c:
																										ptr2 += 8;
																										goto IL_039a;
																									}
																									break;
																								}
																								num = 35;
																								goto IL_04c3;
																								IL_05d6:
																								ptr2 += 8;
																								goto IL_05e4;
																								IL_05e4:
																								num5--;
																								goto end_IL_034b;
																								IL_04c3:
																								if (6 >= b)
																								{
																									goto IL_04d1;
																								}
																								goto IL_0591;
																								IL_04d1:
																								if (6 <= b)
																								{
																									goto IL_04dc;
																								}
																								goto IL_052e;
																								IL_04dc:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_051b;
																								IL_051b:
																								num5 -= 3;
																								goto end_IL_034b;
																								IL_052e:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_053c;
																								IL_053c:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_054a;
																								IL_054a:
																								array[num5] = 5;
																								goto IL_0558;
																								IL_0558:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0570;
																								IL_0570:
																								num5++;
																								goto IL_057e;
																								IL_057e:
																								ptr2 += 8;
																								goto end_IL_034b;
																								IL_0591:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_059f;
																								IL_059f:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_05ad;
																								IL_05ad:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05d6;
																							}
																							break;
																						}
																						goto IL_0356;
																						IL_0356:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_034b;
																					}
																					break;
																				}
																				goto IL_05f7;
																				IL_0869:
																				num5 -= 2;
																				goto end_IL_034b;
																				IL_05f7:
																				if (12 >= b)
																				{
																					goto IL_0605;
																				}
																				goto IL_07a6;
																				IL_0605:
																				if (12 <= b)
																				{
																					goto IL_0610;
																				}
																				goto IL_0677;
																				IL_0610:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0650;
																				IL_0650:
																				array[num5 - 2] = 0;
																				goto IL_0664;
																				IL_0664:
																				num5--;
																				goto end_IL_034b;
																				IL_0677:
																				if (10 >= b)
																				{
																					goto IL_0685;
																				}
																				goto IL_0716;
																				IL_0685:
																				if (10 > b)
																				{
																					goto IL_0690;
																				}
																				goto IL_06b1;
																				IL_0690:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_069e;
																				IL_069e:
																				if (9 > b)
																				{
																					break;
																				}
																				goto end_IL_034b;
																				IL_06b1:
																				array[num5] = 0;
																				goto IL_06bf;
																				IL_06bf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06e2;
																				IL_06e2:
																				array2[num5] = null;
																				num = 84;
																				goto IL_06f5;
																				IL_06f5:
																				num5++;
																				goto IL_0703;
																				IL_0703:
																				ptr2 += 8;
																				goto end_IL_034b;
																				IL_0716:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0724;
																				IL_0724:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0732;
																				IL_0732:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0776;
																				IL_0776:
																				array[num5 - 2] = 0;
																				goto IL_078a;
																				IL_078a:
																				num5--;
																				num = 6;
																				goto end_IL_034b;
																				IL_07a6:
																				if (14 < b)
																				{
																					goto IL_07b1;
																				}
																				goto IL_07dd;
																				IL_07b1:
																				if (15 < b)
																				{
																					num = 8;
																					break;
																				}
																				goto IL_07bc;
																				IL_07bc:
																				if (15 <= b)
																				{
																				}
																				break;
																				IL_0879:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_034b;
																				IL_07dd:
																				if (14 > b)
																				{
																					goto IL_07eb;
																				}
																				goto IL_0879;
																				IL_07eb:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_07f9;
																				IL_07f9:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0807;
																				IL_0807:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0869;
																			}
																			break;
																			IL_0310:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_034b;
																	continue;
																	end_IL_0320:
																	break;
																}
																continue;
																end_IL_0330:
																break;
															}
															continue;
															end_IL_0340:
															break;
														}
														continue;
														end_IL_034b:
														break;
													}
													continue;
												}
												goto IL_0941;
												IL_0941:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a5:
												break;
											}
											continue;
											end_IL_08b8:
											break;
										}
										continue;
										end_IL_08c2:
										break;
									}
									continue;
									end_IL_08cd:
									break;
								}
								continue;
								end_IL_08dd:
								break;
							}
							continue;
							end_IL_08ed:
							break;
						}
						continue;
						end_IL_08fd:
						break;
					}
					continue;
					end_IL_0916:
					break;
				}
				continue;
				end_IL_0926:
				break;
			}
		}
	}

	private static Vector3 HandlerOffsetsetUseMachineKeyStore(Vector3 vector3_1, float float_1)
	{
		return vector3_1 * float_1;
	}

	private static Vector3 NoArgssetMonthNames()
	{
		return global::_003CModule_003E.vector3_127;
	}

	private static double getIsInvalidNumberNegativePattern(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static double FindDebuggableAttribute(double double_1)
	{
		return Math.Floor(double_1);
	}

	private static Vector3 CreateActContextParametersSourceIsValidTargetType(ref RaycastHit raycastHit_0)
	{
		return raycastHit_0.point;
	}

	private void method_2()
	{
		int num = 91;
		num = 13;
		num = 132;
		num = 44;
		num = 13;
		num = 33;
		num = 45;
		num = 45;
		num = 106;
		num = 53;
		num = 245;
		num = 35;
		num = 53;
		num = 88;
		num = 1895;
		num = 1895;
		num = 1940;
		num = 560;
		num = 140;
		num = 0;
		int num2 = 0;
		do
		{
			num = num2;
			if (num == 1)
			{
				method_3();
				double num3 = 3.0;
				double a = 1.0;
				double num4 = Math.Ceiling(a);
				a = num4;
				num3 -= a;
				int num5 = Convert.ToInt32(num3);
				num = num5;
				num2 = num;
			}
			if (num2 == 0)
			{
				num = 1;
				num2 = 1;
			}
			num = num2;
		}
		while (num != 2);
	}

	private static int CdsSyncEtwBCLProviderTypeLoadException(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static void getAppDomainInitializerResize(Rigidbody rigidbody_1, Vector3 vector3_1)
	{
		rigidbody_1.velocity = vector3_1;
	}

	static Class180()
	{
		int num = 10;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 19;
					while (true)
					{
						if (num != 19)
						{
							if (num != 1000)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 3:
							case 4:
							case 5:
							case 6:
							case 7:
							case 8:
							case 11:
							case 12:
								goto end_IL_0058;
							case 9:
								goto end_IL_0065;
							case 10:
								goto end_IL_008f;
							}
							continue;
						}
						return;
						continue;
						end_IL_0058:
						break;
					}
					continue;
					end_IL_0065:
					break;
				}
				continue;
				end_IL_008f:
				break;
			}
		}
	}

	private static double getFilterOffsetNonCanonicalData(double double_1)
	{
		return Math.Round(double_1);
	}

	private static Transform GUIDAssemblyCompanyAttribute(Component component_0)
	{
		return component_0.transform;
	}

	private static bool MdConstantEndInvokeCalled(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static double getAccessListToBindableVectorAdapter(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static double getReadTimeoutgetHostCanGenerate(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static int smethod_8(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe void method_3()
	{
		int num = 120;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 184;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getArrayValueTraceSynchronousWork.UpnReturnXmlElementName);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_05fd:
																	if (b >= 1)
																	{
																		while (b <= 38)
																		{
																			while (true)
																			{
																				IL_05dd:
																				if (19 < b)
																				{
																					goto IL_0e15;
																				}
																				while (true)
																				{
																					IL_05cd:
																					if (19 > b)
																					{
																						while (true)
																						{
																							IL_05bd:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_05ad:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_059d:
																											if (4 < b)
																											{
																												while (true)
																												{
																													IL_058d:
																													if (6 >= b)
																													{
																														while (true)
																														{
																															IL_057d:
																															if (6 <= b)
																															{
																																while (true)
																																{
																																	IL_0532:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	num = 324;
																																	while (true)
																																	{
																																		if (num != 324)
																																		{
																																			if (num != 1305)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 163:
																																			case 224:
																																				goto IL_0532;
																																			case 194:
																																				goto IL_057d;
																																			case 195:
																																				goto IL_058d;
																																			case 279:
																																				goto IL_059d;
																																			case 136:
																																				goto IL_05ad;
																																			case 175:
																																				goto IL_05bd;
																																			case 129:
																																				goto IL_05cd;
																																			case 38:
																																				goto IL_05dd;
																																			case 179:
																																				goto end_IL_05dd;
																																			case 152:
																																				goto IL_05fd;
																																			case 209:
																																				goto end_IL_05fd;
																																			case 256:
																																			case 272:
																																				goto end_IL_060d;
																																			case 82:
																																				goto IL_0628;
																																			case 118:
																																				goto IL_063b;
																																			case 19:
																																				goto IL_0646;
																																			case 150:
																																				goto IL_0654;
																																			case 43:
																																			case 161:
																																				goto IL_0667;
																																			case 48:
																																				goto IL_0675;
																																			case 135:
																																				goto IL_0698;
																																			case 65:
																																				goto IL_06a2;
																																			case 156:
																																				goto IL_06b9;
																																			case 202:
																																				goto IL_06cc;
																																			case 201:
																																				goto IL_06da;
																																			case 196:
																																				goto IL_06e5;
																																			case 100:
																																				goto IL_06f3;
																																			case 59:
																																				goto IL_0701;
																																			case 96:
																																				goto IL_0714;
																																			case 7:
																																				goto IL_0722;
																																			case 91:
																																				goto IL_0730;
																																			case 211:
																																				goto IL_0743;
																																			case 81:
																																			case 185:
																																				goto IL_0751;
																																			case 193:
																																				goto IL_079a;
																																			case 50:
																																			case 216:
																																				goto IL_07b3;
																																			case 67:
																																				goto IL_0805;
																																			case 9:
																																			case 218:
																																				goto IL_0818;
																																			case 177:
																																				goto IL_0859;
																																			case 139:
																																				goto IL_086d;
																																			case 258:
																																				goto IL_0889;
																																			case 36:
																																				goto IL_0897;
																																			case 190:
																																				goto IL_08a2;
																																			case 4:
																																			case 10:
																																				goto IL_08b0;
																																			case 72:
																																				goto IL_08c4;
																																			case 76:
																																				goto IL_0903;
																																			case 14:
																																				goto IL_0916;
																																			case 205:
																																				goto IL_0921;
																																			case 160:
																																				goto IL_093d;
																																			case 71:
																																				goto IL_094b;
																																			case 259:
																																				goto IL_095e;
																																			case 115:
																																			case 273:
																																				goto IL_0971;
																																			case 28:
																																				goto IL_09b2;
																																			case 85:
																																				goto IL_09c6;
																																			case 261:
																																			case 282:
																																				goto IL_09d9;
																																			case 242:
																																				goto IL_0a19;
																																			case 191:
																																				goto IL_0a2d;
																																			case 287:
																																				goto IL_0a40;
																																			case 51:
																																				goto IL_0a57;
																																			case 8:
																																			case 54:
																																				goto IL_0a65;
																																			case 234:
																																				goto IL_0a8e;
																																			case 294:
																																				goto IL_0aa1;
																																			case 77:
																																				goto IL_0ab8;
																																			case 246:
																																			case 286:
																																				goto IL_0ac6;
																																			case 83:
																																				goto IL_0b28;
																																			case 107:
																																			case 299:
																																				goto IL_0b3b;
																																			case 151:
																																				goto IL_0b54;
																																			case 262:
																																				goto IL_0b62;
																																			case 104:
																																				goto IL_0b79;
																																			case 143:
																																			case 303:
																																				goto IL_0b8c;
																																			case 206:
																																				goto IL_0bcc;
																																			case 37:
																																				goto IL_0be0;
																																			case 309:
																																				goto IL_0bf3;
																																			case 284:
																																			case 310:
																																				goto IL_0c06;
																																			case 314:
																																				goto IL_0c1e;
																																			case 238:
																																				goto IL_0c2c;
																																			case 203:
																																			case 221:
																																				goto IL_0c3a;
																																			case 229:
																																				goto IL_0c53;
																																			case 155:
																																				goto IL_0c61;
																																			case 13:
																																				goto IL_0c6f;
																																			case 317:
																																				goto IL_0c82;
																																			case 230:
																																			case 276:
																																				goto IL_0c90;
																																			case 199:
																																				goto IL_0ca8;
																																			case 283:
																																				goto IL_0cb6;
																																			case 244:
																																				goto IL_0cc4;
																																			case 0:
																																				goto IL_0cf4;
																																			case 208:
																																				goto IL_0d07;
																																			case 16:
																																				goto IL_0d12;
																																			case 46:
																																			case 207:
																																				goto IL_0d20;
																																			case 181:
																																				goto IL_0d60;
																																			case 270:
																																				goto IL_0d74;
																																			case 302:
																																				goto IL_0d87;
																																			case 60:
																																				goto IL_0d95;
																																			case 5:
																																			case 73:
																																				goto IL_0da3;
																																			case 122:
																																			case 183:
																																				goto IL_0db6;
																																			case 264:
																																				goto IL_0dca;
																																			case 164:
																																				goto IL_0e02;
																																			case 236:
																																				goto IL_0e15;
																																			case 99:
																																				goto IL_0e23;
																																			case 117:
																																			case 243:
																																				goto IL_0e2e;
																																			case 293:
																																				goto IL_0e42;
																																			case 98:
																																				goto IL_0e8a;
																																			case 212:
																																				goto IL_0e9d;
																																			case 237:
																																				goto IL_0eab;
																																			case 251:
																																			case 292:
																																				goto IL_0eb6;
																																			case 134:
																																				goto IL_0eca;
																																			case 226:
																																				goto IL_0f09;
																																			case 204:
																																				goto IL_0f1c;
																																			case 92:
																																				goto IL_0f2a;
																																			case 55:
																																				goto end_IL_051f;
																																			case 79:
																																			case 169:
																																				goto IL_0f43;
																																			case 250:
																																				goto IL_0f57;
																																			case 112:
																																				goto IL_0f96;
																																			case 102:
																																				goto IL_0fa9;
																																			case 307:
																																				goto IL_0fb7;
																																			case 142:
																																			case 239:
																																				goto IL_0fc5;
																																			case 311:
																																				goto IL_1005;
																																			case 267:
																																				goto IL_1019;
																																			case 126:
																																				goto IL_1035;
																																			case 11:
																																			case 301:
																																				goto IL_1040;
																																			case 56:
																																				goto IL_1059;
																																			case 103:
																																				goto IL_1067;
																																			case 47:
																																				goto IL_1075;
																																			case 295:
																																				goto IL_1088;
																																			case 232:
																																				goto IL_1096;
																																			case 22:
																																			case 252:
																																				goto IL_10a4;
																																			case 41:
																																				goto IL_10cd;
																																			case 1:
																																				goto IL_10db;
																																			case 297:
																																				goto IL_10ee;
																																			case 58:
																																				goto IL_10fc;
																																			case 247:
																																			case 313:
																																				goto IL_1107;
																																			case 227:
																																				goto IL_1138;
																																			case 34:
																																				goto IL_114b;
																																			case 240:
																																				goto IL_1159;
																																			case 171:
																																			case 305:
																																				goto IL_1167;
																																			case 170:
																																				goto IL_117a;
																																			case 138:
																																				goto IL_1188;
																																			case 304:
																																				goto IL_119b;
																																			case 121:
																																				goto IL_11a6;
																																			case 61:
																																			case 188:
																																				goto IL_11b4;
																																			case 30:
																																				goto IL_11c8;
																																			case 141:
																																				goto IL_1207;
																																			case 158:
																																				goto IL_121a;
																																			case 280:
																																				goto IL_1228;
																																			case 265:
																																			case 288:
																																				goto IL_1236;
																																			case 124:
																																				goto IL_124a;
																																			case 88:
																																				goto IL_12a0;
																																			case 130:
																																				goto IL_12ae;
																																			case 145:
																																				goto IL_12c1;
																																			case 44:
																																				goto IL_12cf;
																																			case 113:
																																				goto IL_12dd;
																																			case 198:
																																				goto IL_12eb;
																																			case 166:
																																			case 278:
																																				goto IL_12f9;
																																			case 53:
																																				goto IL_130d;
																																			case 172:
																																				goto IL_135a;
																																			case 248:
																																				goto IL_1368;
																																			case 95:
																																				goto IL_137b;
																																			case 64:
																																				goto IL_1389;
																																			case 78:
																																			case 214:
																																				goto IL_1397;
																																			case 235:
																																				goto IL_13cf;
																																			case 84:
																																				goto IL_13e3;
																																			case 291:
																																				goto IL_13f6;
																																			case 17:
																																				goto IL_1401;
																																			case 223:
																																			case 253:
																																				goto IL_140f;
																																			case 87:
																																				goto IL_144f;
																																			case 308:
																																				goto IL_1463;
																																			case 200:
																																				goto IL_1476;
																																			case 127:
																																				goto IL_1484;
																																			case 116:
																																			case 165:
																																				goto IL_1492;
																																			case 74:
																																				goto IL_14c0;
																																			case 159:
																																			case 231:
																																				goto IL_14d3;
																																			case 89:
																																				goto IL_14e7;
																																			case 260:
																																				goto IL_1526;
																																			case 66:
																																				goto IL_1539;
																																			case 111:
																																				goto IL_1547;
																																			case 18:
																																			case 39:
																																				goto IL_1552;
																																			case 233:
																																				goto IL_1566;
																																			case 26:
																																				goto IL_15a5;
																																			case 105:
																																				goto IL_15b8;
																																			case 300:
																																				goto IL_15c6;
																																			case 70:
																																			case 131:
																																				goto IL_15d4;
																																			case 255:
																																				goto IL_1612;
																																			case 285:
																																				goto IL_1620;
																																			case 277:
																																				goto IL_1630;
																																			case 228:
																																				goto IL_163b;
																																			case 148:
																																				goto IL_1646;
																																			case 263:
																																				goto IL_165c;
																																			case 174:
																																			case 176:
																																				goto IL_1667;
																																			case 2:
																																			case 3:
																																			case 15:
																																			case 20:
																																			case 27:
																																			case 32:
																																			case 33:
																																			case 35:
																																			case 40:
																																			case 42:
																																			case 45:
																																			case 52:
																																			case 80:
																																			case 86:
																																			case 90:
																																			case 94:
																																			case 125:
																																			case 133:
																																			case 137:
																																			case 140:
																																			case 147:
																																			case 154:
																																			case 157:
																																			case 162:
																																			case 167:
																																			case 168:
																																			case 173:
																																			case 178:
																																			case 180:
																																			case 189:
																																			case 192:
																																			case 215:
																																			case 220:
																																			case 222:
																																			case 268:
																																			case 274:
																																			case 281:
																																			case 289:
																																			case 296:
																																			case 312:
																																			case 316:
																																				goto end_IL_05ed;
																																			case 6:
																																			case 12:
																																			case 23:
																																			case 24:
																																			case 25:
																																			case 29:
																																			case 31:
																																			case 49:
																																			case 57:
																																			case 62:
																																			case 63:
																																			case 68:
																																			case 69:
																																			case 75:
																																			case 97:
																																			case 101:
																																			case 106:
																																			case 108:
																																			case 109:
																																			case 110:
																																			case 114:
																																			case 123:
																																			case 128:
																																			case 144:
																																			case 146:
																																			case 149:
																																			case 153:
																																			case 186:
																																			case 187:
																																			case 197:
																																			case 217:
																																			case 219:
																																			case 245:
																																			case 254:
																																			case 257:
																																			case 269:
																																			case 271:
																																			case 275:
																																			case 290:
																																			case 298:
																																			case 315:
																																				goto end_IL_061d;
																																			case 306:
																																				goto end_IL_1693;
																																			case 225:
																																				goto end_IL_16a6;
																																			case 210:
																																				goto end_IL_16b0;
																																			case 266:
																																				goto end_IL_16bb;
																																			case 132:
																																				goto end_IL_16cb;
																																			case 182:
																																			case 241:
																																				goto end_IL_16db;
																																			case 249:
																																				goto end_IL_16eb;
																																			case 93:
																																				goto end_IL_16fb;
																																			case 184:
																																				goto end_IL_170b;
																																			case 119:
																																				goto end_IL_171b;
																																			case 120:
																																				goto end_IL_172b;
																																			case 21:
																																			case 213:
																																				return;
																																			}
																																			continue;
																																		}
																																		array[num6 - 2] = 0;
																																		goto IL_0cf4;
																																		IL_0cf4:
																																		num6--;
																																		goto end_IL_061d;
																																		continue;
																																		end_IL_051f:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_0628;
																															IL_095e:
																															num6--;
																															goto end_IL_061d;
																															IL_0628:
																															if (5 < b)
																															{
																																goto end_IL_05ed;
																															}
																															goto IL_0743;
																															IL_0743:
																															if (5 > b)
																															{
																																goto end_IL_05ed;
																															}
																															goto IL_0751;
																															IL_0751:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															num = 193;
																															goto IL_079a;
																															IL_079a:
																															array[num6 - 2] = 0;
																															goto IL_095e;
																														}
																														break;
																													}
																													goto IL_0d07;
																													IL_0da3:
																													num6--;
																													goto end_IL_061d;
																													IL_0d07:
																													if (7 >= b)
																													{
																														goto IL_0d12;
																													}
																													goto IL_0d87;
																													IL_0d12:
																													if (7 > b)
																													{
																														goto end_IL_05ed;
																													}
																													goto IL_0d20;
																													IL_0d20:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_0d60;
																													IL_0d60:
																													array[num6 - 2] = 0;
																													goto IL_0d74;
																													IL_0d74:
																													num6--;
																													goto end_IL_061d;
																													IL_0d87:
																													if (8 < b)
																													{
																														goto end_IL_05ed;
																													}
																													goto IL_0d95;
																													IL_0d95:
																													if (8 > b)
																													{
																														goto end_IL_05ed;
																													}
																													goto IL_0da3;
																												}
																												break;
																											}
																											goto IL_063b;
																											IL_06a2:
																											num6++;
																											num = 156;
																											goto IL_06b9;
																											IL_063b:
																											if (4 > b)
																											{
																												goto IL_0646;
																											}
																											goto IL_0667;
																											IL_0646:
																											if (2 >= b)
																											{
																												goto IL_0654;
																											}
																											goto IL_0a40;
																											IL_0654:
																											if (2 <= b)
																											{
																												goto IL_09d9;
																											}
																											goto IL_0c1e;
																											IL_09d9:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0a19;
																											IL_0a19:
																											array[num6 - 2] = 0;
																											goto IL_0a2d;
																											IL_0a2d:
																											num6--;
																											goto end_IL_061d;
																											IL_0c1e:
																											if (1 < b)
																											{
																												goto end_IL_05ed;
																											}
																											goto IL_0c2c;
																											IL_0c2c:
																											if (1 > b)
																											{
																												goto end_IL_05ed;
																											}
																											goto IL_0c3a;
																											IL_0c3a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																											goto IL_0c53;
																											IL_0c53:
																											array[num6] = 0;
																											goto IL_0c61;
																											IL_0c61:
																											num6++;
																											goto IL_0c6f;
																											IL_0c6f:
																											ptr2 += 8;
																											goto end_IL_061d;
																											IL_0a40:
																											if (3 < b)
																											{
																												goto end_IL_05ed;
																											}
																											num = 51;
																											goto IL_0a57;
																											IL_06b9:
																											ptr2 += 8;
																											goto end_IL_061d;
																											IL_0a57:
																											if (3 > b)
																											{
																												goto end_IL_05ed;
																											}
																											goto IL_0a65;
																											IL_0a65:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0a8e;
																											IL_0a8e:
																											ptr2 += 8;
																											goto IL_0bf3;
																											IL_0bf3:
																											num6--;
																											goto end_IL_061d;
																											IL_0667:
																											array[num6] = 0;
																											goto IL_0675;
																											IL_0675:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0698;
																											IL_0698:
																											array2[num6] = null;
																											goto IL_06a2;
																										}
																										break;
																									}
																									goto IL_0b8c;
																									IL_0be0:
																									num6--;
																									goto end_IL_061d;
																									IL_0b8c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0bcc;
																									IL_0bcc:
																									array[num6 - 2] = 0;
																									goto IL_0be0;
																								}
																								break;
																							}
																							goto IL_06cc;
																							IL_0b62:
																							num6++;
																							num = 104;
																							goto IL_0b79;
																							IL_06cc:
																							if (14 < b)
																							{
																								goto IL_06da;
																							}
																							goto IL_0889;
																							IL_06da:
																							if (16 >= b)
																							{
																								goto IL_06e5;
																							}
																							goto IL_0714;
																							IL_06e5:
																							if (16 > b)
																							{
																								goto IL_06f3;
																							}
																							goto IL_07b3;
																							IL_06f3:
																							if (15 < b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0701;
																							IL_0701:
																							if (15 > b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0971;
																							IL_0971:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																							goto IL_09b2;
																							IL_09b2:
																							array[num6 - 2] = 0;
																							goto IL_09c6;
																							IL_09c6:
																							num6--;
																							goto end_IL_061d;
																							IL_07b3:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0805;
																							IL_0805:
																							num6--;
																							goto end_IL_061d;
																							IL_0714:
																							if (17 < b)
																							{
																								goto IL_0722;
																							}
																							goto IL_0c82;
																							IL_0722:
																							if (18 < b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0730;
																							IL_0730:
																							if (18 > b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0818;
																							IL_0818:
																							array2[num6 - 1] = ((delegate*<Class180, LineRenderer>)intptr_0[*(int*)(ptr2 + num3)])((Class180)array2[num6 - 1]);
																							num = 177;
																							goto IL_0859;
																							IL_0859:
																							array[num6 - 1] = 5;
																							goto IL_086d;
																							IL_086d:
																							ptr2 += 8;
																							num = 108;
																							goto end_IL_061d;
																							IL_0c82:
																							if (17 > b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0c90;
																							IL_0c90:
																							array2[num6] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0ca8;
																							IL_0ca8:
																							array[num6] = 5;
																							goto IL_0cb6;
																							IL_0cb6:
																							num6++;
																							goto IL_0cc4;
																							IL_0cc4:
																							ptr2 += 8;
																							num = 12;
																							goto end_IL_061d;
																							IL_0889:
																							if (14 > b)
																							{
																								goto IL_0897;
																							}
																							goto IL_0c06;
																							IL_0897:
																							if (11 >= b)
																							{
																								goto IL_08a2;
																							}
																							goto IL_0916;
																							IL_08a2:
																							if (11 <= b)
																							{
																								goto IL_08b0;
																							}
																							goto IL_0aa1;
																							IL_08b0:
																							array[num6 - 1] = 0;
																							goto IL_08c4;
																							IL_08c4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0903;
																							IL_0903:
																							ptr2 += 8;
																							goto end_IL_061d;
																							IL_0aa1:
																							if (10 < b)
																							{
																								goto end_IL_05ed;
																							}
																							num = 77;
																							goto IL_0ab8;
																							IL_0b79:
																							ptr2 += 16;
																							goto end_IL_061d;
																							IL_0ab8:
																							if (10 > b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0ac6;
																							IL_0ac6:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0b28;
																							IL_0b28:
																							num6 -= 2;
																							goto end_IL_061d;
																							IL_0916:
																							if (12 >= b)
																							{
																								goto IL_0921;
																							}
																							goto IL_093d;
																							IL_0921:
																							if (12 > b)
																							{
																								goto end_IL_05ed;
																							}
																							num = 144;
																							goto end_IL_061d;
																							IL_0c06:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_061d;
																							IL_093d:
																							if (13 < b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_094b;
																							IL_094b:
																							if (13 > b)
																							{
																								goto end_IL_05ed;
																							}
																							goto IL_0b3b;
																							IL_0b3b:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0b54;
																							IL_0b54:
																							array[num6] = 1;
																							goto IL_0b62;
																						}
																						break;
																					}
																					goto IL_0db6;
																					IL_0e02:
																					ptr2 += 8;
																					goto end_IL_061d;
																					IL_0db6:
																					array[num6 - 1] = 5;
																					goto IL_0dca;
																					IL_0dca:
																					array2[num6 - 1] = ((delegate*<Component, GameObject>)intptr_0[*(int*)(ptr2 + num3)])((LineRenderer)array2[num6 - 1]);
																					goto IL_0e02;
																				}
																				goto IL_0f35;
																				IL_1667:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_061d;
																				IL_0e15:
																				if (29 >= b)
																				{
																					goto IL_0e23;
																				}
																				goto IL_12c1;
																				IL_0e23:
																				if (29 <= b)
																				{
																					goto IL_0e2e;
																				}
																				goto IL_0e9d;
																				IL_0e2e:
																				array[num6 - 1] = 3;
																				goto IL_0e42;
																				IL_0e42:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				num = 98;
																				goto IL_0e8a;
																				IL_0e8a:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_0e9d:
																				if (24 >= b)
																				{
																					goto IL_0eab;
																				}
																				goto IL_10ee;
																				IL_0eab:
																				if (24 <= b)
																				{
																					goto IL_0eb6;
																				}
																				goto IL_0f1c;
																				IL_0eb6:
																				array[num6 - 1] = 0;
																				goto IL_0eca;
																				IL_0eca:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0f09;
																				IL_0f09:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_0f1c:
																				if (21 < b)
																				{
																					goto IL_0f2a;
																				}
																				num = 126;
																				goto IL_1035;
																				IL_0f2a:
																				if (22 >= b)
																				{
																					goto IL_0f35;
																				}
																				goto IL_0fa9;
																				IL_0f35:
																				if (22 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_0f43;
																				IL_0f43:
																				array[num6 - 1] = 3;
																				goto IL_0f57;
																				IL_0f57:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0f96;
																				IL_0f96:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_0fa9:
																				if (23 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_0fb7;
																				IL_0fb7:
																				if (23 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_0fc5;
																				IL_0fc5:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1005;
																				IL_1005:
																				array[num6 - 2] = 3;
																				goto IL_1019;
																				IL_1019:
																				num6--;
																				goto end_IL_061d;
																				IL_165c:
																				if (37 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1667;
																				IL_1035:
																				if (21 <= b)
																				{
																					goto IL_1040;
																				}
																				goto IL_1088;
																				IL_1040:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_1059;
																				IL_1059:
																				array[num6] = 3;
																				goto IL_1067;
																				IL_1067:
																				num6++;
																				goto IL_1075;
																				IL_1075:
																				ptr2 += 16;
																				goto end_IL_061d;
																				IL_1088:
																				if (20 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1096;
																				IL_1096:
																				if (20 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_10a4;
																				IL_10a4:
																				((delegate*<UnityEngine.Object, void>)intptr_0[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																				goto IL_10cd;
																				IL_10cd:
																				num6--;
																				goto IL_10db;
																				IL_10db:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_10ee:
																				if (26 >= b)
																				{
																					goto IL_10fc;
																				}
																				goto IL_119b;
																				IL_10fc:
																				if (26 <= b)
																				{
																					goto IL_1107;
																				}
																				goto IL_114b;
																				IL_1107:
																				((Class180)array2[num6 - 2]).lineRenderer_0 = (LineRenderer)array2[num6 - 1];
																				num = 227;
																				goto IL_1138;
																				IL_1138:
																				num6 -= 2;
																				goto end_IL_061d;
																				IL_114b:
																				if (25 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1159;
																				IL_1159:
																				if (25 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1167;
																				IL_1167:
																				array2[num6] = null;
																				num = 170;
																				goto IL_117a;
																				IL_117a:
																				array[num6] = 5;
																				goto IL_1188;
																				IL_1188:
																				num6++;
																				goto end_IL_061d;
																				IL_119b:
																				if (27 >= b)
																				{
																					goto IL_11a6;
																				}
																				goto IL_121a;
																				IL_11a6:
																				if (27 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_11b4;
																				IL_11b4:
																				array[num6 - 1] = 3;
																				goto IL_11c8;
																				IL_11c8:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1207;
																				IL_1207:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_121a:
																				if (28 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1228;
																				IL_1228:
																				if (28 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1236;
																				IL_1236:
																				array[num6 - 2] = 0;
																				goto IL_124a;
																				IL_124a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)intptr_0[*(int*)(ptr2 + num3)])((LineRenderer)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				num = 88;
																				goto IL_12a0;
																				IL_12a0:
																				num6--;
																				goto IL_12ae;
																				IL_12ae:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_12c1:
																				if (34 >= b)
																				{
																					goto IL_12cf;
																				}
																				goto IL_1539;
																				IL_12cf:
																				if (34 > b)
																				{
																					goto IL_12dd;
																				}
																				goto IL_14d3;
																				IL_12dd:
																				if (31 >= b)
																				{
																					goto IL_12eb;
																				}
																				goto IL_13f6;
																				IL_12eb:
																				if (31 <= b)
																				{
																					goto IL_12f9;
																				}
																				goto IL_137b;
																				IL_12f9:
																				array[num6 - 2] = 0;
																				goto IL_130d;
																				IL_130d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)intptr_0[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_135a;
																				IL_135a:
																				num6--;
																				goto IL_1368;
																				IL_1368:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_137b:
																				if (30 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1389;
																				IL_1389:
																				if (30 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1397;
																				IL_1397:
																				array2[num6 - 1] = ((delegate*<Class180, Rigidbody>)intptr_0[*(int*)(ptr2 + num3)])((Class180)array2[num6 - 1]);
																				goto IL_13cf;
																				IL_13cf:
																				array[num6 - 1] = 5;
																				goto IL_13e3;
																				IL_13e3:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_13f6:
																				if (32 >= b)
																				{
																					goto IL_1401;
																				}
																				goto IL_1476;
																				IL_1401:
																				if (32 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_140f;
																				IL_140f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_144f;
																				IL_144f:
																				array[num6 - 2] = 3;
																				goto IL_1463;
																				IL_1463:
																				num6--;
																				goto end_IL_061d;
																				IL_1476:
																				if (33 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1484;
																				IL_1484:
																				if (33 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1492;
																				IL_1492:
																				((Class180)array2[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																				goto IL_14c0;
																				IL_14c0:
																				num6 -= 2;
																				goto end_IL_061d;
																				IL_14d3:
																				array[num6 - 1] = 3;
																				goto IL_14e7;
																				IL_14e7:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1526;
																				IL_1526:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_1539:
																				if (36 >= b)
																				{
																					goto IL_1547;
																				}
																				goto IL_1630;
																				IL_1547:
																				if (36 <= b)
																				{
																					goto IL_1552;
																				}
																				goto IL_15b8;
																				IL_1552:
																				array[num6 - 1] = 3;
																				goto IL_1566;
																				IL_1566:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_15a5;
																				IL_15a5:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_15b8:
																				if (35 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_15c6;
																				IL_15c6:
																				if (35 > b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_15d4;
																				IL_15d4:
																				((delegate*<Rigidbody, bool, void>)intptr_0[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																				goto IL_1612;
																				IL_1612:
																				num6 -= 2;
																				goto IL_1620;
																				IL_1620:
																				ptr2 += 8;
																				goto end_IL_061d;
																				IL_1630:
																				if (37 < b)
																				{
																					goto IL_163b;
																				}
																				goto IL_165c;
																				IL_163b:
																				if (38 < b)
																				{
																					goto end_IL_05ed;
																				}
																				goto IL_1646;
																				IL_1646:
																				if (38 <= b)
																				{
																					num = 15;
																				}
																				goto end_IL_05ed;
																				continue;
																				end_IL_05dd:
																				break;
																			}
																			continue;
																			end_IL_05ed:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_061d;
																	continue;
																	end_IL_05fd:
																	break;
																}
																continue;
																end_IL_060d:
																break;
															}
															continue;
															end_IL_061d:
															break;
														}
														continue;
														end_IL_1693:
														break;
													}
													continue;
													end_IL_16a6:
													break;
												}
												continue;
												end_IL_16b0:
												break;
											}
											continue;
											end_IL_16bb:
											break;
										}
										continue;
										end_IL_16cb:
										break;
									}
									continue;
									end_IL_16db:
									break;
								}
								continue;
								end_IL_16eb:
								break;
							}
							continue;
							end_IL_16fb:
							break;
						}
						continue;
						end_IL_170b:
						break;
					}
					continue;
					end_IL_171b:
					break;
				}
				continue;
				end_IL_172b:
				break;
			}
		}
	}

	private static int AlwaysIncludeTypesShaForNonSecretPurposes(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static Vector3 ValueTypeFixupInfosetInitLocals(Vector3 vector3_1, Vector3 vector3_2)
	{
		return vector3_1 - vector3_2;
	}

	private static void EnumeratorDropIndicesgetPersistKeyInCsp(LineRenderer lineRenderer_1, int int_1, Vector3 vector3_1)
	{
		lineRenderer_1.SetPosition(int_1, vector3_1);
	}

	private static Vector3 ParamDefAclRevision(Transform transform_0)
	{
		return transform_0.position;
	}

	private static Vector3 FUNCFLAGFDEFAULTBINDUnlockRegion(Class180 class180_1)
	{
		return class180_1.vector3_0;
	}

	private static void ThreadTransferReceiveHandledLargestWindowWidth(Class180 class180_1)
	{
		class180_1.method_0();
	}

	private unsafe static int smethod_9(int int_1, int int_2)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								num = 92;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BindToMonikerFrameworkCultures.ProcessorArchitectureListISecurableChannel);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02d4:
															byte b = *ptr2;
															num = 96;
															while (true)
															{
																IL_02c4:
																ptr2++;
																while (true)
																{
																	IL_02b4:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0297:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_0277:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_026a:
																									if (4 >= b)
																									{
																										while (4 <= b)
																										{
																											while (true)
																											{
																												IL_0226:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 129;
																												while (true)
																												{
																													if (num != 129)
																													{
																														if (num != 1110)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 29:
																														case 107:
																															goto IL_0226;
																														case 119:
																															goto IL_025a;
																														case 18:
																														case 114:
																															goto IL_026a;
																														case 64:
																														case 77:
																															goto IL_0277;
																														case 103:
																															goto IL_0287;
																														case 56:
																															goto IL_0297;
																														case 47:
																															goto IL_02a4;
																														case 70:
																															goto IL_02b4;
																														case 96:
																															goto IL_02c4;
																														case 52:
																														case 55:
																															goto IL_02d4;
																														case 68:
																														case 87:
																															goto IL_02e8;
																														case 84:
																															goto IL_02f6;
																														case 28:
																														case 90:
																															goto IL_0304;
																														case 15:
																														case 110:
																															goto IL_031c;
																														case 5:
																														case 36:
																															goto IL_032a;
																														case 46:
																															goto IL_0338;
																														case 21:
																														case 53:
																															goto IL_0343;
																														case 8:
																														case 50:
																															goto IL_0356;
																														case 102:
																															goto IL_0364;
																														case 37:
																														case 85:
																															goto IL_0372;
																														case 23:
																															goto IL_0386;
																														case 83:
																															goto IL_03c5;
																														case 22:
																														case 86:
																															goto IL_03e1;
																														case 112:
																															goto IL_03ef;
																														case 116:
																															goto IL_0402;
																														case 30:
																														case 95:
																															goto IL_0410;
																														case 111:
																															goto IL_041b;
																														case 24:
																														case 67:
																															goto IL_0429;
																														case 81:
																															goto IL_0437;
																														case 49:
																															goto IL_045a;
																														case 113:
																															goto IL_0464;
																														case 105:
																															goto IL_0472;
																														case 99:
																															goto IL_0485;
																														case 89:
																															goto IL_0493;
																														case 25:
																														case 61:
																															goto IL_04a1;
																														case 65:
																															goto IL_04ba;
																														case 54:
																															goto IL_04c8;
																														case 7:
																															goto IL_04d6;
																														case 11:
																														case 16:
																															goto IL_04e9;
																														case 42:
																															goto IL_0529;
																														case 1:
																															goto IL_053d;
																														case 117:
																														case 122:
																															goto IL_0550;
																														case 80:
																															goto IL_057a;
																														case 48:
																															goto IL_058d;
																														case 79:
																														case 91:
																															goto IL_0598;
																														case 31:
																															goto IL_05d8;
																														case 108:
																															goto IL_05ec;
																														case 0:
																															goto end_IL_0213;
																														case 12:
																														case 97:
																															goto IL_060d;
																														case 58:
																															goto IL_061b;
																														case 39:
																														case 59:
																															goto IL_0629;
																														case 40:
																															goto IL_0697;
																														case 4:
																															goto IL_06a7;
																														case 6:
																														case 20:
																														case 27:
																														case 32:
																														case 33:
																														case 35:
																														case 57:
																														case 60:
																														case 63:
																														case 66:
																														case 69:
																														case 72:
																														case 82:
																														case 88:
																														case 93:
																														case 94:
																														case 115:
																														case 120:
																															goto end_IL_025a;
																														case 14:
																															goto IL_06d5;
																														case 10:
																															goto IL_06e3;
																														case 51:
																															goto IL_06f1;
																														case 13:
																														case 19:
																														case 26:
																														case 38:
																														case 41:
																														case 43:
																														case 44:
																														case 45:
																														case 71:
																														case 73:
																														case 76:
																														case 101:
																														case 106:
																														case 109:
																														case 121:
																															goto end_IL_0287;
																														case 100:
																															goto end_IL_06ff;
																														case 118:
																															goto end_IL_0712;
																														case 17:
																															goto end_IL_071c;
																														case 92:
																															goto end_IL_0727;
																														case 3:
																															goto end_IL_073c;
																														case 9:
																														case 98:
																															goto end_IL_0751;
																														case 34:
																															goto end_IL_076a;
																														case 2:
																														case 104:
																															goto end_IL_077a;
																														case 74:
																															goto end_IL_078a;
																														case 75:
																															goto end_IL_079a;
																														case 62:
																														case 78:
																															goto IL_07b5;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto IL_057a;
																													IL_057a:
																													num5--;
																													goto end_IL_0287;
																													continue;
																													end_IL_0213:
																													break;
																												}
																												break;
																											}
																											goto IL_05ff;
																											continue;
																											end_IL_025a:
																											break;
																											IL_025a:;
																										}
																										break;
																									}
																									goto IL_02e8;
																									IL_0304:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0287;
																									IL_02e8:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_02f6;
																									IL_02f6:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0304;
																								}
																								break;
																							}
																							goto IL_058d;
																							IL_06a7:
																							if (1 <= b)
																							{
																							}
																							break;
																							IL_058d:
																							if (3 <= b)
																							{
																								goto IL_0598;
																							}
																							goto IL_05ff;
																							IL_0598:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05d8;
																							IL_05d8:
																							array[num5 - 2] = 0;
																							goto IL_05ec;
																							IL_05ec:
																							num5--;
																							goto end_IL_0287;
																							IL_05ff:
																							if (1 < b)
																							{
																								goto IL_060d;
																							}
																							goto IL_06a7;
																							IL_060d:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_061b;
																							IL_061b:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0629;
																							IL_0629:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0697;
																							IL_0697:
																							num5 -= 2;
																							goto end_IL_0287;
																						}
																						goto end_IL_02a4;
																						continue;
																						end_IL_0287:
																						break;
																						IL_0287:;
																					}
																					break;
																				}
																				goto IL_031c;
																				IL_053d:
																				num5--;
																				break;
																				IL_031c:
																				if (9 < b)
																				{
																					goto IL_032a;
																				}
																				goto IL_0402;
																				IL_032a:
																				if (11 >= b)
																				{
																					goto IL_0338;
																				}
																				goto IL_03e1;
																				IL_0338:
																				if (11 <= b)
																				{
																					goto IL_0343;
																				}
																				goto IL_0356;
																				IL_0343:
																				num5--;
																				break;
																				IL_0356:
																				if (10 < b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_0364;
																				IL_0364:
																				if (10 > b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_0372;
																				IL_0372:
																				array[num5 - 1] = 0;
																				goto IL_0386;
																				IL_0386:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)TotalFreeSpaceRSAPKCSSignatureDeformatter[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_03c5;
																				IL_03c5:
																				ptr2 += 8;
																				num = 73;
																				break;
																				IL_03e1:
																				if (12 < b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_03ef;
																				IL_03ef:
																				if (12 > b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_0550;
																				IL_0550:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0402:
																				if (9 > b)
																				{
																					goto IL_0410;
																				}
																				goto IL_04e9;
																				IL_0410:
																				if (7 >= b)
																				{
																					goto IL_041b;
																				}
																				goto IL_0485;
																				IL_041b:
																				if (7 > b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_0429;
																				IL_0429:
																				array[num5] = 0;
																				goto IL_0437;
																				IL_0437:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_045a;
																				IL_045a:
																				array2[num5] = null;
																				goto IL_0464;
																				IL_0464:
																				num5++;
																				goto IL_0472;
																				IL_0472:
																				ptr2 += 8;
																				break;
																				IL_0485:
																				if (8 < b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_0493;
																				IL_0493:
																				if (8 > b)
																				{
																					goto end_IL_02a4;
																				}
																				goto IL_04a1;
																				IL_04a1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04ba;
																				IL_04ba:
																				array[num5] = 0;
																				goto IL_04c8;
																				IL_04c8:
																				num5++;
																				goto IL_04d6;
																				IL_04d6:
																				ptr2 += 8;
																				break;
																				IL_04e9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0529;
																				IL_0529:
																				array[num5 - 2] = 0;
																				goto IL_053d;
																			}
																			goto end_IL_02b4;
																			continue;
																			end_IL_02a4:
																			break;
																			IL_02a4:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06d5;
																	IL_06f1:
																	ptr2 += 8;
																	break;
																	IL_06e3:
																	num5++;
																	goto IL_06f1;
																	IL_06d5:
																	array[num5] = 0;
																	goto IL_06e3;
																	continue;
																	end_IL_02b4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07b5;
													IL_07b5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_06ff:
													break;
												}
												continue;
												end_IL_0712:
												break;
											}
											continue;
											end_IL_071c:
											break;
										}
										continue;
										end_IL_0727:
										break;
									}
									continue;
									end_IL_073c:
									break;
								}
								continue;
								end_IL_0751:
								break;
							}
							continue;
							end_IL_076a:
							break;
						}
						continue;
						end_IL_077a:
						break;
					}
					continue;
					end_IL_078a:
					break;
				}
				continue;
				end_IL_079a:
				break;
			}
		}
	}

	private static void DirectoryStringOpenDelegateOnly(Class180 class180_1)
	{
		class180_1.method_3();
	}
}
