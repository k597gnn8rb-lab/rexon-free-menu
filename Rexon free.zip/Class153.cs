using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using ExitGames.Client.Photon;
using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Oculus Report Menu Anti Report", "Safety", "Detects when someone opens the Oculus report menu on you.", false, 13, ModType.const_0, false)]
internal class Class153 : MonoBehaviour
{
	private bool bool_0;

	private static int int_0;

	private static double double_0;

	private static int int_1;

	private static int int_2;

	private static IntPtr[] getRegistryRightsgetErrors;

	private static IntPtr[] setWriteSpinWaitNextSpinWillYield;

	private static IntPtr[] DispositionInternalParseTypeE;

	private static IntPtr[] AssemblyAlgorithmIdAttributeAsDecimal;

	private static IntPtr[] SealedgetWindowsCodePage;

	private unsafe void OnEnable()
	{
		int num = 111;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									num = 177;
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReturnValuesetAppend.SingleArrayTypeInfoSentinel);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0401:
																if (b >= 1)
																{
																	while (b <= 22)
																	{
																		while (true)
																		{
																			IL_03e4:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_03d4:
																					if (17 < b)
																					{
																						while (true)
																						{
																							IL_03c7:
																							if (20 < b)
																							{
																								while (true)
																								{
																									IL_03b7:
																									if (21 < b)
																									{
																										while (22 >= b)
																										{
																											num = 221;
																											while (true)
																											{
																												if (num != 221)
																												{
																													if (num != 1202)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 103:
																													case 164:
																														goto IL_03a4;
																													case 213:
																														goto IL_03b7;
																													case 49:
																													case 209:
																														goto IL_03c7;
																													case 105:
																														goto IL_03d4;
																													case 128:
																														goto IL_03e4;
																													case 29:
																														goto IL_03f1;
																													case 197:
																														goto IL_0401;
																													case 72:
																														goto end_IL_0401;
																													case 116:
																													case 184:
																														goto end_IL_0411;
																													case 10:
																														goto IL_042c;
																													case 59:
																														goto IL_043c;
																													case 41:
																														goto IL_0447;
																													case 97:
																													case 108:
																														goto IL_045a;
																													case 87:
																													case 112:
																														goto IL_049c;
																													case 79:
																														goto IL_04b0;
																													case 7:
																														goto IL_0504;
																													case 119:
																														goto IL_0517;
																													case 125:
																														goto IL_0527;
																													case 141:
																														goto IL_053a;
																													case 55:
																														goto IL_0545;
																													case 127:
																														goto IL_0550;
																													case 93:
																													case 140:
																														goto IL_055e;
																													case 99:
																														goto IL_0571;
																													case 14:
																														goto IL_057c;
																													case 124:
																														goto IL_058f;
																													case 52:
																													case 152:
																														goto IL_05ab;
																													case 144:
																														goto IL_05eb;
																													case 67:
																														goto IL_05ff;
																													case 154:
																														goto IL_0612;
																													case 161:
																														goto IL_0625;
																													case 42:
																													case 109:
																														goto IL_0633;
																													case 58:
																														goto IL_0647;
																													case 2:
																														goto IL_0694;
																													case 171:
																														goto IL_06a7;
																													case 38:
																														goto IL_06b5;
																													case 75:
																														goto IL_06c3;
																													case 1:
																													case 47:
																														goto IL_06d1;
																													case 115:
																														goto IL_06df;
																													case 20:
																													case 25:
																														goto IL_06ed;
																													case 98:
																														goto IL_072d;
																													case 117:
																														goto IL_0741;
																													case 162:
																														goto IL_0754;
																													case 36:
																													case 73:
																														goto IL_0762;
																													case 5:
																														goto IL_07ab;
																													case 77:
																														goto IL_07bf;
																													case 16:
																													case 17:
																														goto IL_07d2;
																													case 39:
																														goto IL_07dd;
																													case 22:
																													case 63:
																														goto IL_07eb;
																													case 81:
																														goto IL_0830;
																													case 130:
																														goto IL_083e;
																													case 40:
																													case 129:
																														goto IL_084c;
																													case 174:
																														goto IL_08ae;
																													case 148:
																													case 175:
																														goto IL_08c1;
																													case 118:
																													case 182:
																														goto IL_08d4;
																													case 185:
																														goto IL_0916;
																													case 32:
																														goto IL_092a;
																													case 191:
																														goto IL_093d;
																													case 134:
																														goto IL_0951;
																													case 201:
																														goto IL_0964;
																													case 202:
																														goto IL_0977;
																													case 15:
																													case 62:
																														goto IL_0985;
																													case 94:
																														goto IL_099e;
																													case 181:
																														goto IL_09ac;
																													case 11:
																														goto IL_09ba;
																													case 204:
																														goto IL_09cd;
																													case 166:
																														goto IL_09db;
																													case 207:
																														goto IL_09ee;
																													case 23:
																													case 92:
																														goto IL_09fc;
																													case 173:
																														goto IL_0a11;
																													case 169:
																														goto IL_0a1f;
																													case 211:
																														goto IL_0a32;
																													case 121:
																													case 210:
																														goto IL_0a40;
																													case 68:
																														goto IL_0a4e;
																													case 48:
																														goto IL_0a71;
																													case 176:
																														goto IL_0a7b;
																													case 86:
																														goto IL_0a89;
																													case 19:
																													case 214:
																														goto IL_0a9c;
																													case 71:
																														goto IL_0ac5;
																													case 180:
																														goto IL_0ad3;
																													case 9:
																														goto IL_0af9;
																													case 122:
																													case 188:
																														goto IL_0b07;
																													case 76:
																														goto IL_0b23;
																													case 50:
																													case 199:
																														goto IL_0b31;
																													case 33:
																														goto IL_0b3f;
																													case 203:
																														goto IL_0b4d;
																													case 65:
																													case 70:
																														goto IL_0b58;
																													case 153:
																														goto IL_0b66;
																													case 61:
																													case 194:
																														goto IL_0b74;
																													case 147:
																														goto IL_0b8c;
																													case 198:
																														goto IL_0b9a;
																													case 192:
																														goto IL_0ba8;
																													case 120:
																														goto IL_0bbb;
																													case 95:
																													case 208:
																														goto IL_0bce;
																													case 74:
																														goto IL_0c15;
																													case 158:
																														goto IL_0c29;
																													case 178:
																														goto IL_0c3c;
																													case 179:
																														goto IL_0c47;
																													case 96:
																														goto IL_0c52;
																													case 8:
																													case 101:
																														goto IL_0c60;
																													case 85:
																														goto IL_0c8e;
																													case 13:
																														goto IL_0cb8;
																													case 31:
																													case 196:
																														goto IL_0cc6;
																													case 131:
																														goto IL_0d24;
																													case 3:
																													case 189:
																														goto IL_0d34;
																													case 43:
																														goto IL_0d5b;
																													case 78:
																														goto IL_0d72;
																													case 163:
																														goto IL_0d89;
																													case 0:
																													case 12:
																													case 30:
																													case 34:
																													case 37:
																													case 44:
																													case 46:
																													case 53:
																													case 56:
																													case 57:
																													case 60:
																													case 66:
																													case 80:
																													case 82:
																													case 83:
																													case 84:
																													case 90:
																													case 91:
																													case 104:
																													case 107:
																													case 113:
																													case 126:
																													case 136:
																													case 139:
																													case 142:
																													case 143:
																													case 145:
																													case 146:
																													case 149:
																													case 155:
																													case 156:
																													case 160:
																													case 167:
																													case 168:
																													case 172:
																													case 187:
																													case 190:
																													case 195:
																													case 200:
																													case 206:
																													case 212:
																														goto end_IL_0391;
																													case 6:
																													case 18:
																													case 21:
																													case 26:
																													case 28:
																													case 35:
																													case 45:
																													case 51:
																													case 54:
																													case 69:
																													case 88:
																													case 100:
																													case 102:
																													case 106:
																													case 123:
																													case 132:
																													case 135:
																													case 138:
																													case 150:
																													case 151:
																													case 157:
																													case 165:
																													case 170:
																													case 183:
																													case 186:
																														goto end_IL_0421;
																													case 159:
																														goto end_IL_0dac;
																													case 205:
																														goto end_IL_0dbf;
																													case 177:
																														goto end_IL_0dc9;
																													case 89:
																														goto end_IL_0dd4;
																													case 137:
																														goto end_IL_0de4;
																													case 24:
																													case 193:
																														goto end_IL_0dfd;
																													case 64:
																														goto end_IL_0e0d;
																													case 4:
																													case 27:
																														goto end_IL_0e1d;
																													case 110:
																														goto end_IL_0e2d;
																													case 111:
																														goto end_IL_0e3d;
																													case 114:
																													case 133:
																														return;
																													}
																													continue;
																												}
																												if (22 <= b)
																												{
																												}
																												break;
																												continue;
																												end_IL_0391:
																												break;
																											}
																											break;
																											IL_03a4:;
																										}
																										break;
																									}
																									goto IL_0af9;
																									IL_0b07:
																									byte* num5 = ptr2;
																									num4 = 1;
																									ptr2 = num5 + -200;
																									goto end_IL_0421;
																									IL_0af9:
																									if (21 > b)
																									{
																										break;
																									}
																									goto IL_0b07;
																								}
																								break;
																							}
																							goto IL_043c;
																							IL_09db:
																							ptr2 += 8;
																							goto end_IL_0421;
																							IL_043c:
																							if (20 > b)
																							{
																								goto IL_0447;
																							}
																							goto IL_045a;
																							IL_0447:
																							if (18 < b)
																							{
																								goto IL_0527;
																							}
																							goto IL_09ee;
																							IL_09ee:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_09fc;
																							IL_09fc:
																							*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (void*)0;
																							goto IL_0a11;
																							IL_0a11:
																							array[num6] = 2;
																							goto IL_0a1f;
																							IL_0a1f:
																							num6++;
																							goto end_IL_0421;
																							IL_0527:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_0625;
																							IL_0625:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0633;
																							IL_0633:
																							array[num6 - 2] = 5;
																							goto IL_0647;
																							IL_0647:
																							array2[num6 - 2] = ((delegate*<object, IntPtr, Action<EventData>>)getRegistryRightsgetErrors[*(int*)(ptr2 + num3)])((Class153)array2[num6 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0694;
																							IL_0694:
																							num6--;
																							goto IL_0964;
																							IL_0964:
																							ptr2 += 8;
																							goto end_IL_0421;
																							IL_045a:
																							((delegate*<LoadBalancingClient, Action<EventData>, void>)getRegistryRightsgetErrors[*(int*)(ptr2 + num3)])((LoadBalancingClient)array2[num6 - 2], (Action<EventData>)array2[num6 - 1]);
																							goto IL_09cd;
																							IL_09cd:
																							num6 -= 2;
																							goto IL_09db;
																						}
																						break;
																					}
																					goto IL_0b23;
																					IL_0d5b:
																					array[num6] = 5;
																					num = 78;
																					goto IL_0d72;
																					IL_0b23:
																					if (17 > b)
																					{
																						goto IL_0b31;
																					}
																					goto IL_0d34;
																					IL_0b31:
																					if (14 >= b)
																					{
																						goto IL_0b3f;
																					}
																					goto IL_0c3c;
																					IL_0b3f:
																					if (14 > b)
																					{
																						goto IL_0b4d;
																					}
																					goto IL_0bce;
																					IL_0b4d:
																					if (12 < b)
																					{
																						goto IL_0b58;
																					}
																					goto IL_0bbb;
																					IL_0b58:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0b66;
																					IL_0b66:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0b74;
																					IL_0b74:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0b8c;
																					IL_0b8c:
																					array[num6] = 5;
																					goto IL_0b9a;
																					IL_0b9a:
																					num6++;
																					goto IL_0ba8;
																					IL_0ba8:
																					ptr2 += 8;
																					goto end_IL_0421;
																					IL_0bbb:
																					if (12 > b)
																					{
																						break;
																					}
																					goto end_IL_0421;
																					IL_0bce:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (((delegate*<Class153, bool>)getRegistryRightsgetErrors[*(int*)(ptr2 + num3)])((Class153)array2[num6 - 1]) ? 1 : 0);
																					num = 74;
																					goto IL_0c15;
																					IL_0c15:
																					array[num6 - 1] = 0;
																					goto IL_0c29;
																					IL_0c29:
																					ptr2 += 8;
																					goto end_IL_0421;
																					IL_0c3c:
																					if (15 < b)
																					{
																						goto IL_0c47;
																					}
																					num = 13;
																					goto IL_0cb8;
																					IL_0c47:
																					if (16 < b)
																					{
																						num = 46;
																						break;
																					}
																					goto IL_0c52;
																					IL_0c52:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0c60;
																					IL_0c60:
																					((Class153)array2[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																					goto IL_0c8e;
																					IL_0c8e:
																					num6 -= 2;
																					goto end_IL_0421;
																					IL_0d89:
																					ptr2 += 8;
																					goto end_IL_0421;
																					IL_0d72:
																					num6++;
																					num = 163;
																					goto IL_0d89;
																					IL_0cb8:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_0cc6;
																					IL_0cc6:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0d24;
																					IL_0d24:
																					num6--;
																					goto end_IL_0421;
																					IL_0d34:
																					array2[num6] = ((delegate*<LoadBalancingClient>)getRegistryRightsgetErrors[*(int*)(ptr2 + num3)])();
																					num = 43;
																					goto IL_0d5b;
																				}
																				break;
																			}
																			goto IL_042c;
																			IL_084c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_08ae;
																			IL_042c:
																			if (11 <= b)
																			{
																				goto IL_049c;
																			}
																			goto IL_0517;
																			IL_049c:
																			array[num6 - 2] = 0;
																			goto IL_04b0;
																			IL_04b0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)getRegistryRightsgetErrors[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_0504;
																			IL_0504:
																			num6--;
																			goto IL_0612;
																			IL_0612:
																			ptr2 += 8;
																			goto end_IL_0421;
																			IL_0517:
																			if (5 >= b)
																			{
																				goto IL_053a;
																			}
																			goto IL_06a7;
																			IL_053a:
																			if (5 > b)
																			{
																				goto IL_0545;
																			}
																			goto IL_05ab;
																			IL_0545:
																			if (2 >= b)
																			{
																				goto IL_0550;
																			}
																			goto IL_0571;
																			IL_0550:
																			if (2 > b)
																			{
																				goto IL_055e;
																			}
																			goto IL_08d4;
																			IL_055e:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0977;
																			IL_0977:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0985;
																			IL_0985:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_099e;
																			IL_099e:
																			array[num6] = 0;
																			goto IL_09ac;
																			IL_09ac:
																			num6++;
																			goto IL_09ba;
																			IL_09ba:
																			ptr2 += 8;
																			goto end_IL_0421;
																			IL_08d4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_093d;
																			IL_093d:
																			array[num6 - 2] = 0;
																			goto IL_0951;
																			IL_0951:
																			num6--;
																			goto end_IL_0421;
																			IL_0571:
																			if (3 >= b)
																			{
																				goto IL_057c;
																			}
																			goto IL_058f;
																			IL_057c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0a9c;
																			IL_0a9c:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0ac5;
																			IL_0ac5:
																			ptr2 += 8;
																			goto IL_0ad3;
																			IL_0ad3:
																			num6--;
																			goto end_IL_0421;
																			IL_058f:
																			if (4 < b)
																			{
																				num = 146;
																				break;
																			}
																			goto IL_0a32;
																			IL_08ae:
																			num6 -= 2;
																			goto end_IL_0421;
																			IL_0a32:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_0a40;
																			IL_0a40:
																			array[num6] = 0;
																			goto IL_0a4e;
																			IL_0a4e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0a71;
																			IL_0a71:
																			array2[num6] = null;
																			goto IL_0a7b;
																			IL_0a7b:
																			num6++;
																			goto IL_0a89;
																			IL_0a89:
																			ptr2 += 8;
																			goto end_IL_0421;
																			IL_05ab:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_05eb;
																			IL_05eb:
																			array[num6 - 2] = 0;
																			goto IL_05ff;
																			IL_05ff:
																			num6--;
																			goto end_IL_0421;
																			IL_06a7:
																			if (8 >= b)
																			{
																				goto IL_06b5;
																			}
																			goto IL_07d2;
																			IL_06b5:
																			if (8 > b)
																			{
																				goto IL_06c3;
																			}
																			goto IL_08c1;
																			IL_06c3:
																			if (6 < b)
																			{
																				goto IL_06d1;
																			}
																			goto IL_0754;
																			IL_06d1:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_06df;
																			IL_06df:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_06ed;
																			IL_06ed:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_072d;
																			IL_072d:
																			array[num6 - 2] = 0;
																			goto IL_0741;
																			IL_0741:
																			num6--;
																			goto end_IL_0421;
																			IL_0754:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0762;
																			IL_0762:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 5;
																			goto IL_07ab;
																			IL_07ab:
																			array[num6 - 2] = 0;
																			goto IL_07bf;
																			IL_07bf:
																			num6--;
																			goto end_IL_0421;
																			IL_08c1:
																			num6--;
																			goto end_IL_0421;
																			IL_07d2:
																			if (9 >= b)
																			{
																				goto IL_07dd;
																			}
																			goto IL_0830;
																			IL_07dd:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_07eb;
																			IL_07eb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0916;
																			IL_0916:
																			array[num6 - 2] = 0;
																			goto IL_092a;
																			IL_092a:
																			num6--;
																			goto end_IL_0421;
																			IL_0830:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_083e;
																			IL_083e:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_084c;
																		}
																		break;
																		IL_03f1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0421;
																continue;
																end_IL_0401:
																break;
															}
															continue;
															end_IL_0411:
															break;
														}
														continue;
														end_IL_0421:
														break;
													}
													continue;
													end_IL_0dac:
													break;
												}
												continue;
												end_IL_0dbf:
												break;
											}
											continue;
											end_IL_0dc9:
											break;
										}
										continue;
										end_IL_0dd4:
										break;
									}
									continue;
									end_IL_0de4:
									break;
								}
								continue;
								end_IL_0dfd:
								break;
							}
							continue;
							end_IL_0e0d:
							break;
						}
						continue;
						end_IL_0e1d:
						break;
					}
					continue;
					end_IL_0e2d:
					break;
				}
				continue;
				end_IL_0e3d:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 62;
				while (true)
				{
					num = 4;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[6];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMonthGenitiveNamesOnlyReferenceRegistered.RequiredAttributeAttributeIHashElementEntry);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															num = 61;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0473:
																		if (b >= 1)
																		{
																			while (b <= 22)
																			{
																				while (true)
																				{
																					IL_0456:
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_0446:
																							if (17 >= b)
																							{
																								while (true)
																								{
																									IL_0436:
																									if (17 > b)
																									{
																										while (true)
																										{
																											IL_0426:
																											if (14 >= b)
																											{
																												while (true)
																												{
																													IL_0416:
																													if (14 > b)
																													{
																														while (true)
																														{
																															IL_0406:
																															if (12 < b)
																															{
																																while (13 >= b)
																																{
																																	while (13 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_03cc:
																																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																																			while (true)
																																			{
																																				IL_03b3:
																																				array[num5] = 5;
																																				num = 46;
																																				while (true)
																																				{
																																					IL_039a:
																																					num5++;
																																					num = 222;
																																					while (true)
																																					{
																																						if (num != 222)
																																						{
																																							if (num != 1203)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 46:
																																								goto IL_039a;
																																							case 176:
																																								goto IL_03b3;
																																							case 145:
																																							case 194:
																																								goto IL_03cc;
																																							case 168:
																																								goto IL_03e6;
																																							case 160:
																																							case 204:
																																								goto IL_03f6;
																																							case 76:
																																								goto IL_0406;
																																							case 65:
																																								goto IL_0416;
																																							case 107:
																																							case 128:
																																								goto IL_0426;
																																							case 127:
																																								goto IL_0436;
																																							case 87:
																																								goto IL_0446;
																																							case 103:
																																								goto IL_0456;
																																							case 63:
																																								goto end_IL_0387;
																																							case 11:
																																								goto IL_0473;
																																							case 99:
																																								goto end_IL_0473;
																																							case 61:
																																								goto end_IL_0483;
																																							case 18:
																																								goto end_IL_0493;
																																							case 20:
																																								goto IL_04a9;
																																							case 188:
																																							case 199:
																																								goto IL_04b4;
																																							case 206:
																																								goto IL_04c2;
																																							case 3:
																																								goto IL_04e6;
																																							case 84:
																																								goto IL_04f4;
																																							case 90:
																																							case 211:
																																								goto IL_0507;
																																							case 31:
																																							case 81:
																																								goto IL_0515;
																																							case 171:
																																								goto IL_0523;
																																							case 58:
																																							case 178:
																																								goto IL_052e;
																																							case 166:
																																								goto IL_0541;
																																							case 49:
																																								goto IL_054c;
																																							case 14:
																																								goto IL_055f;
																																							case 164:
																																								goto IL_056d;
																																							case 15:
																																							case 119:
																																								goto IL_057b;
																																							case 118:
																																								goto IL_05bb;
																																							case 120:
																																								goto IL_05cf;
																																							case 195:
																																								goto IL_05e2;
																																							case 95:
																																							case 190:
																																								goto IL_05f0;
																																							case 68:
																																								goto IL_05fe;
																																							case 79:
																																							case 179:
																																								goto IL_060c;
																																							case 114:
																																								goto IL_066e;
																																							case 141:
																																								goto IL_0681;
																																							case 5:
																																							case 132:
																																								goto IL_068f;
																																							case 78:
																																								goto IL_06cf;
																																							case 155:
																																								goto IL_06e3;
																																							case 135:
																																								goto IL_06f6;
																																							case 60:
																																							case 64:
																																								goto IL_0704;
																																							case 210:
																																								goto IL_0712;
																																							case 23:
																																							case 154:
																																								goto IL_071d;
																																							case 174:
																																								goto IL_075d;
																																							case 126:
																																								goto IL_077a;
																																							case 153:
																																								goto IL_078d;
																																							case 51:
																																								goto IL_079b;
																																							case 10:
																																							case 109:
																																								goto IL_07a6;
																																							case 48:
																																								goto IL_07bf;
																																							case 57:
																																								goto IL_07cd;
																																							case 17:
																																								goto IL_07db;
																																							case 12:
																																							case 102:
																																								goto IL_0805;
																																							case 0:
																																							case 16:
																																								goto IL_0813;
																																							case 124:
																																								goto IL_082a;
																																							case 7:
																																							case 200:
																																								goto IL_0838;
																																							case 197:
																																								goto IL_0846;
																																							case 117:
																																								goto IL_0869;
																																							case 158:
																																								goto IL_0873;
																																							case 30:
																																								goto IL_0881;
																																							case 82:
																																								goto IL_0894;
																																							case 44:
																																							case 98:
																																								goto IL_08a2;
																																							case 29:
																																								goto IL_08cb;
																																							case 40:
																																								goto IL_08d9;
																																							case 138:
																																							case 169:
																																								goto IL_08ec;
																																							case 27:
																																								goto IL_092c;
																																							case 143:
																																								goto IL_0940;
																																							case 112:
																																							case 212:
																																								goto IL_0953;
																																							case 45:
																																								goto IL_0993;
																																							case 66:
																																								goto IL_09a7;
																																							case 207:
																																								goto IL_09d6;
																																							case 2:
																																							case 151:
																																								goto IL_09e9;
																																							case 214:
																																								goto IL_0a30;
																																							case 142:
																																								goto IL_0a44;
																																							case 28:
																																								goto IL_0a57;
																																							case 152:
																																								goto IL_0a62;
																																							case 38:
																																							case 192:
																																								goto IL_0a70;
																																							case 189:
																																								goto IL_0ac2;
																																							case 209:
																																								goto IL_0ad5;
																																							case 6:
																																								goto IL_0ae3;
																																							case 32:
																																							case 129:
																																								goto IL_0af1;
																																							case 185:
																																								goto IL_0b1f;
																																							case 136:
																																							case 196:
																																								goto IL_0b32;
																																							case 71:
																																								goto IL_0b59;
																																							case 175:
																																								goto IL_0b67;
																																							case 43:
																																								goto IL_0b7e;
																																							case 116:
																																								goto IL_0b91;
																																							case 72:
																																							case 150:
																																								goto IL_0b9c;
																																							case 54:
																																							case 215:
																																								goto IL_0ba7;
																																							case 22:
																																								goto IL_0bbe;
																																							case 80:
																																								goto IL_0bd1;
																																							case 115:
																																							case 186:
																																								goto IL_0bdf;
																																							case 165:
																																								goto IL_0bfb;
																																							case 47:
																																							case 163:
																																								goto IL_0c09;
																																							case 19:
																																							case 123:
																																								goto IL_0c17;
																																							case 201:
																																								goto IL_0c25;
																																							case 35:
																																							case 100:
																																								goto IL_0c33;
																																							case 36:
																																								goto IL_0c47;
																																							case 159:
																																								goto IL_0c94;
																																							case 39:
																																								goto IL_0ca2;
																																							case 146:
																																								goto IL_0cb5;
																																							case 134:
																																							case 140:
																																								goto IL_0cc3;
																																							case 156:
																																								goto IL_0cd8;
																																							case 122:
																																								goto IL_0ce6;
																																							case 33:
																																							case 59:
																																								goto IL_0cf6;
																																							case 50:
																																								goto IL_0d33;
																																							case 97:
																																								goto IL_0d4a;
																																							case 13:
																																							case 21:
																																							case 24:
																																							case 25:
																																							case 26:
																																							case 37:
																																							case 41:
																																							case 69:
																																							case 70:
																																							case 74:
																																							case 75:
																																							case 77:
																																							case 83:
																																							case 85:
																																							case 86:
																																							case 88:
																																							case 93:
																																							case 106:
																																							case 108:
																																							case 121:
																																							case 125:
																																							case 130:
																																							case 131:
																																							case 133:
																																							case 137:
																																							case 144:
																																							case 149:
																																							case 157:
																																							case 162:
																																							case 172:
																																							case 173:
																																							case 181:
																																							case 193:
																																							case 198:
																																							case 202:
																																							case 205:
																																							case 213:
																																								goto end_IL_03e6;
																																							case 8:
																																							case 34:
																																							case 52:
																																							case 53:
																																							case 56:
																																							case 73:
																																							case 89:
																																							case 94:
																																							case 96:
																																							case 101:
																																							case 105:
																																							case 110:
																																							case 111:
																																							case 113:
																																							case 139:
																																							case 147:
																																							case 148:
																																							case 161:
																																							case 167:
																																							case 177:
																																							case 183:
																																							case 187:
																																							case 191:
																																							case 203:
																																							case 208:
																																								goto end_IL_049e;
																																							case 55:
																																								goto end_IL_0d6d;
																																							case 182:
																																								goto end_IL_0d80;
																																							case 42:
																																								goto end_IL_0d8a;
																																							case 9:
																																								goto end_IL_0d95;
																																							case 104:
																																								goto end_IL_0da5;
																																							case 1:
																																							case 184:
																																								goto end_IL_0db5;
																																							case 180:
																																								goto end_IL_0dc5;
																																							case 4:
																																								goto end_IL_0dd5;
																																							case 62:
																																								goto end_IL_0de5;
																																							case 91:
																																								goto end_IL_0df5;
																																							case 92:
																																								goto end_IL_0e00;
																																							case 67:
																																							case 170:
																																								return;
																																							}
																																							continue;
																																						}
																																						ptr2 += 8;
																																						goto end_IL_049e;
																																						continue;
																																						end_IL_0387:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_0463;
																																		continue;
																																		end_IL_03e6:
																																		break;
																																		IL_03e6:;
																																	}
																																	break;
																																	IL_03f6:;
																																}
																																break;
																															}
																															goto IL_09d6;
																															IL_09d6:
																															if (12 <= b)
																															{
																																goto end_IL_049e;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_09e9;
																													IL_0a44:
																													ptr2 += 8;
																													goto end_IL_049e;
																													IL_09e9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Class153, bool>)setWriteSpinWaitNextSpinWillYield[*(int*)(ptr2 + num3)])((Class153)array2[num5 - 1]) ? 1 : 0);
																													num = 214;
																													goto IL_0a30;
																													IL_0a30:
																													array[num5 - 1] = 0;
																													goto IL_0a44;
																												}
																												break;
																											}
																											goto IL_0a57;
																											IL_0b1f:
																											num5 -= 2;
																											goto end_IL_049e;
																											IL_0a57:
																											if (15 >= b)
																											{
																												goto IL_0a62;
																											}
																											goto IL_0ad5;
																											IL_0a62:
																											if (15 > b)
																											{
																												break;
																											}
																											goto IL_0a70;
																											IL_0a70:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0ac2;
																											IL_0ac2:
																											num5--;
																											goto end_IL_049e;
																											IL_0ad5:
																											if (16 < b)
																											{
																												break;
																											}
																											goto IL_0ae3;
																											IL_0ae3:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_0af1;
																											IL_0af1:
																											((Class153)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																											goto IL_0b1f;
																										}
																										break;
																									}
																									goto IL_0b32;
																									IL_0b7e:
																									ptr2 += 8;
																									goto end_IL_049e;
																									IL_0b32:
																									array2[num5] = ((delegate*<LoadBalancingClient>)setWriteSpinWaitNextSpinWillYield[*(int*)(ptr2 + num3)])();
																									num = 71;
																									goto IL_0b59;
																									IL_0b59:
																									array[num5] = 5;
																									goto IL_0b67;
																									IL_0b67:
																									num5++;
																									num = 43;
																									goto IL_0b7e;
																								}
																								break;
																							}
																							goto IL_0b91;
																							IL_0d33:
																							num5 -= 2;
																							num = 97;
																							goto IL_0d4a;
																							IL_0b91:
																							if (20 < b)
																							{
																								goto IL_0b9c;
																							}
																							goto IL_0bfb;
																							IL_0b9c:
																							if (21 < b)
																							{
																								goto IL_0ba7;
																							}
																							goto IL_0bd1;
																							IL_0ba7:
																							if (22 < b)
																							{
																								break;
																							}
																							num = 22;
																							goto IL_0bbe;
																							IL_0d4a:
																							ptr2 += 8;
																							goto end_IL_049e;
																							IL_0bbe:
																							if (22 > b)
																							{
																							}
																							break;
																							IL_0bd1:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_0bdf;
																							IL_0bdf:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_049e;
																							IL_0bfb:
																							if (20 > b)
																							{
																								goto IL_0c09;
																							}
																							goto IL_0cf6;
																							IL_0c09:
																							if (18 < b)
																							{
																								goto IL_0c17;
																							}
																							goto IL_0cb5;
																							IL_0c17:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_0c25;
																							IL_0c25:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0c33;
																							IL_0c33:
																							array[num5 - 2] = 5;
																							goto IL_0c47;
																							IL_0c47:
																							array2[num5 - 2] = ((delegate*<object, IntPtr, Action<EventData>>)setWriteSpinWaitNextSpinWillYield[*(int*)(ptr2 + num3)])((Class153)array2[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_0c94;
																							IL_0c94:
																							num5--;
																							goto IL_0ca2;
																							IL_0ca2:
																							ptr2 += 8;
																							goto end_IL_049e;
																							IL_0cb5:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0cc3;
																							IL_0cc3:
																							*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (void*)0;
																							goto IL_0cd8;
																							IL_0cd8:
																							array[num5] = 2;
																							goto IL_0ce6;
																							IL_0ce6:
																							num5++;
																							goto end_IL_049e;
																							IL_0cf6:
																							((delegate*<LoadBalancingClient, Action<EventData>, void>)setWriteSpinWaitNextSpinWillYield[*(int*)(ptr2 + num3)])((LoadBalancingClient)array2[num5 - 2], (Action<EventData>)array2[num5 - 1]);
																							goto IL_0d33;
																						}
																						break;
																					}
																					goto IL_04a9;
																					IL_08d9:
																					num5--;
																					goto end_IL_049e;
																					IL_04a9:
																					if (11 <= b)
																					{
																						goto IL_04b4;
																					}
																					goto IL_0507;
																					IL_04b4:
																					array[num5] = 0;
																					goto IL_04c2;
																					IL_04c2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)setWriteSpinWaitNextSpinWillYield[*(int*)(ptr2 + num3)])();
																					goto IL_04e6;
																					IL_04e6:
																					num5++;
																					goto IL_04f4;
																					IL_04f4:
																					ptr2 += 8;
																					goto end_IL_049e;
																					IL_0507:
																					if (5 < b)
																					{
																						goto IL_0515;
																					}
																					goto IL_06f6;
																					IL_0515:
																					if (8 >= b)
																					{
																						goto IL_0523;
																					}
																					goto IL_05e2;
																					IL_0523:
																					if (8 <= b)
																					{
																						goto IL_052e;
																					}
																					goto IL_0541;
																					IL_052e:
																					num5--;
																					goto end_IL_049e;
																					IL_0541:
																					if (6 >= b)
																					{
																						goto IL_054c;
																					}
																					goto IL_055f;
																					IL_054c:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0953;
																					IL_0953:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0993;
																					IL_0993:
																					array[num5 - 2] = 0;
																					goto IL_09a7;
																					IL_09a7:
																					num5--;
																					num = 89;
																					goto end_IL_049e;
																					IL_055f:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_056d;
																					IL_056d:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_057b;
																					IL_057b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05bb;
																					IL_05bb:
																					array[num5 - 2] = 0;
																					goto IL_05cf;
																					IL_05cf:
																					num5--;
																					goto end_IL_049e;
																					IL_05e2:
																					if (9 < b)
																					{
																						goto IL_05f0;
																					}
																					goto IL_0681;
																					IL_05f0:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_05fe;
																					IL_05fe:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_060c;
																					IL_060c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_066e;
																					IL_066e:
																					num5 -= 2;
																					goto end_IL_049e;
																					IL_0681:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_068f;
																					IL_068f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06cf;
																					IL_06cf:
																					array[num5 - 2] = 0;
																					goto IL_06e3;
																					IL_06e3:
																					num5--;
																					goto end_IL_049e;
																					IL_06f6:
																					if (5 > b)
																					{
																						goto IL_0704;
																					}
																					goto IL_08ec;
																					IL_0704:
																					if (2 >= b)
																					{
																						goto IL_0712;
																					}
																					num = 102;
																					goto IL_0805;
																					IL_0712:
																					if (2 <= b)
																					{
																						goto IL_071d;
																					}
																					goto IL_078d;
																					IL_071d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_075d;
																					IL_075d:
																					array[num5 - 2] = 0;
																					num = 126;
																					goto IL_077a;
																					IL_077a:
																					num5--;
																					goto end_IL_049e;
																					IL_078d:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_079b;
																					IL_079b:
																					if (1 > b)
																					{
																						num = 70;
																						break;
																					}
																					goto IL_07a6;
																					IL_07a6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_07bf;
																					IL_07bf:
																					array[num5] = 0;
																					goto IL_07cd;
																					IL_07cd:
																					num5++;
																					goto IL_07db;
																					IL_07db:
																					ptr2 += 8;
																					goto end_IL_049e;
																					IL_092c:
																					array[num5 - 2] = 0;
																					goto IL_0940;
																					IL_08ec:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_092c;
																					IL_0805:
																					if (3 < b)
																					{
																						goto IL_0813;
																					}
																					goto IL_0894;
																					IL_0813:
																					if (4 < b)
																					{
																						break;
																					}
																					num = 124;
																					goto IL_082a;
																					IL_0940:
																					num5--;
																					goto end_IL_049e;
																					IL_082a:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0838;
																					IL_0838:
																					array[num5] = 0;
																					goto IL_0846;
																					IL_0846:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0869;
																					IL_0869:
																					array2[num5] = null;
																					goto IL_0873;
																					IL_0873:
																					num5++;
																					goto IL_0881;
																					IL_0881:
																					ptr2 += 8;
																					goto end_IL_049e;
																					IL_0894:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_08a2;
																					IL_08a2:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_08cb;
																					IL_08cb:
																					ptr2 += 8;
																					goto IL_08d9;
																				}
																				break;
																				IL_0463:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_049e;
																		continue;
																		end_IL_0473:
																		break;
																	}
																	continue;
																	end_IL_0483:
																	break;
																}
																continue;
																end_IL_0493:
																break;
															}
															continue;
															end_IL_049e:
															break;
														}
														continue;
														end_IL_0d6d:
														break;
													}
													continue;
													end_IL_0d80:
													break;
												}
												continue;
												end_IL_0d8a:
												break;
											}
											continue;
											end_IL_0d95:
											break;
										}
										continue;
										end_IL_0da5:
										break;
									}
									continue;
									end_IL_0db5:
									break;
								}
								continue;
								end_IL_0dc5:
								break;
							}
							continue;
							end_IL_0dd5:
							break;
						}
						continue;
						end_IL_0de5:
						break;
					}
					continue;
					end_IL_0df5:
					break;
				}
				continue;
				end_IL_0e00:
				break;
			}
		}
	}

	private void method_0(EventData eventData_0)
	{
		int num = 44;
		int num2 = 2;
		num = 22;
		num = 128;
		num2 = 4;
		num = 32;
		num = 22;
		num2 = 32;
		num = 54;
		num2 = 22;
		int num3 = 32;
		num2 = 0;
		num = 54;
		num = 54;
		num = 403;
		num2 = 13;
		num = 31;
		num = 350;
		num2 = 5;
		num = 70;
		num = 31;
		num2 = 70;
		num = 101;
		num2 = 31;
		num3 = 70;
		num2 = 2170;
		num = 2079;
		num = 2079;
		num2 = 54;
		num = 2133;
		num = 528;
		num2 = 3;
		num = 176;
		num2 = 3190;
		num3 = 11;
		num2 = 290;
		object obj = "s";
		object obj2 = obj;
		obj = "P";
		object obj3 = obj;
		obj = "C";
		object obj4 = obj;
		obj = "u";
		object obj5 = obj;
		obj = "p";
		object obj6 = obj;
		obj = "_";
		object obj7 = obj;
		obj = "]";
		object obj8 = obj;
		obj = "T";
		object obj9 = obj;
		obj = "d";
		object obj10 = obj;
		obj = " ";
		object obj11 = obj;
		obj = "I";
		object obj12 = obj;
		obj = "n";
		object obj13 = obj;
		obj = "r";
		object obj14 = obj;
		obj = "c";
		object obj15 = obj;
		obj = "e";
		object obj16 = obj;
		obj = "H";
		object obj17 = obj;
		obj = "D";
		object obj18 = obj;
		obj = "a";
		object obj19 = obj;
		obj = "S";
		object obj20 = obj;
		obj = "[";
		object obj21 = obj;
		obj = "t";
		object obj22 = obj;
		obj = "i";
		object obj23 = obj;
		obj = "g";
		object obj24 = obj;
		obj = "R";
		object obj25 = obj;
		obj = "G";
		object obj26 = obj;
		obj = "o";
		object obj27 = obj;
		obj = "A";
		object obj28 = obj;
		obj = "F";
		object obj29 = obj;
		obj = "U";
		object obj30 = obj;
		obj = "N";
		object obj31 = obj;
		obj = "y";
		object obj32 = obj;
		obj = "l";
		object obj33 = obj;
		num = 208;
		num2 = 13;
		num = 16;
		obj = new string[16];
		object obj34 = obj;
		num3 = 0;
		object obj35 = obj29;
		((string[])obj34)[0] = (string)obj35;
		obj34 = obj;
		num3 = 1;
		obj35 = obj33;
		((string[])obj34)[1] = (string)obj35;
		obj34 = obj;
		num3 = 10;
		num3 = 2;
		obj35 = obj23;
		((string[])obj34)[2] = (string)obj35;
		obj34 = obj;
		num3 = 15;
		num3 = 3;
		obj35 = obj13;
		((string[])obj34)[3] = (string)obj35;
		obj34 = obj;
		num3 = 12;
		num3 = 4;
		obj35 = obj24;
		((string[])obj34)[4] = (string)obj35;
		obj34 = obj;
		num3 = 15;
		num3 = 5;
		obj35 = obj11;
		((string[])obj34)[5] = (string)obj35;
		obj34 = obj;
		num3 = 12;
		num3 = 6;
		obj35 = obj21;
		((string[])obj34)[6] = (string)obj35;
		obj34 = obj;
		num3 = 49;
		num3 = 7;
		obj35 = obj26;
		((string[])obj34)[7] = (string)obj35;
		obj34 = obj;
		num3 = 104;
		num3 = 8;
		obj35 = obj30;
		((string[])obj34)[8] = (string)obj35;
		obj34 = obj;
		num3 = 99;
		num3 = 9;
		obj35 = obj28;
		((string[])obj34)[9] = (string)obj35;
		obj34 = obj;
		num3 = 130;
		num3 = 10;
		obj35 = obj25;
		((string[])obj34)[10] = (string)obj35;
		obj34 = obj;
		num3 = 121;
		num3 = 11;
		obj35 = obj18;
		((string[])obj34)[11] = (string)obj35;
		obj34 = obj;
		num3 = 84;
		num3 = 12;
		obj35 = obj12;
		((string[])obj34)[12] = (string)obj35;
		obj34 = obj;
		num3 = 26;
		num3 = 13;
		obj35 = obj28;
		((string[])obj34)[13] = (string)obj35;
		obj34 = obj;
		num3 = 154;
		num3 = 14;
		obj35 = obj31;
		((string[])obj34)[14] = (string)obj35;
		obj34 = obj;
		num3 = 60;
		num3 = 15;
		obj35 = obj8;
		((string[])obj34)[15] = (string)obj35;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj36 = obj;
		num = 20;
		num2 = 2;
		num = 10;
		obj = new string[10];
		obj34 = obj;
		num3 = 0;
		obj35 = obj18;
		((string[])obj34)[0] = (string)obj35;
		obj34 = obj;
		num3 = 1;
		obj35 = obj23;
		((string[])obj34)[1] = (string)obj35;
		obj34 = obj;
		num3 = 10;
		num3 = 2;
		obj35 = obj2;
		((string[])obj34)[2] = (string)obj35;
		obj34 = obj;
		num3 = 33;
		num3 = 3;
		obj35 = obj15;
		((string[])obj34)[3] = (string)obj35;
		obj34 = obj;
		num3 = 8;
		num3 = 4;
		obj35 = obj27;
		((string[])obj34)[4] = (string)obj35;
		obj34 = obj;
		num3 = 55;
		num3 = 5;
		obj35 = obj13;
		((string[])obj34)[5] = (string)obj35;
		obj34 = obj;
		num3 = 18;
		num3 = 6;
		obj35 = obj13;
		((string[])obj34)[6] = (string)obj35;
		obj34 = obj;
		num3 = 49;
		num3 = 7;
		obj35 = obj16;
		((string[])obj34)[7] = (string)obj35;
		obj34 = obj;
		num3 = 24;
		num3 = 8;
		obj35 = obj15;
		((string[])obj34)[8] = (string)obj35;
		obj34 = obj;
		num3 = 45;
		num3 = 9;
		obj35 = obj22;
		((string[])obj34)[9] = (string)obj35;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj37 = obj;
		num = 165;
		num2 = 11;
		num = 15;
		obj = new string[15];
		obj34 = obj;
		num3 = 0;
		obj35 = obj25;
		((string[])obj34)[0] = (string)obj35;
		obj34 = obj;
		num3 = 1;
		obj35 = obj3;
		((string[])obj34)[1] = (string)obj35;
		obj34 = obj;
		num3 = 8;
		num3 = 2;
		obj35 = obj4;
		((string[])obj34)[2] = (string)obj35;
		obj34 = obj;
		num3 = 12;
		num3 = 3;
		obj35 = obj7;
		((string[])obj34)[3] = (string)obj35;
		obj34 = obj;
		num3 = 12;
		num3 = 4;
		obj35 = obj3;
		((string[])obj34)[4] = (string)obj35;
		obj34 = obj;
		num3 = 25;
		num3 = 5;
		obj35 = obj33;
		((string[])obj34)[5] = (string)obj35;
		obj34 = obj;
		num3 = 12;
		num3 = 6;
		obj35 = obj19;
		((string[])obj34)[6] = (string)obj35;
		obj34 = obj;
		num3 = 28;
		num3 = 7;
		obj35 = obj32;
		((string[])obj34)[7] = (string)obj35;
		obj34 = obj;
		num3 = 24;
		num3 = 8;
		obj35 = obj17;
		((string[])obj34)[8] = (string)obj35;
		obj34 = obj;
		num3 = 63;
		num3 = 9;
		obj35 = obj19;
		((string[])obj34)[9] = (string)obj35;
		obj34 = obj;
		num3 = 30;
		num3 = 10;
		obj35 = obj13;
		((string[])obj34)[10] = (string)obj35;
		obj34 = obj;
		num3 = 77;
		num3 = 11;
		obj35 = obj10;
		((string[])obj34)[11] = (string)obj35;
		obj34 = obj;
		num3 = 156;
		num3 = 12;
		obj35 = obj9;
		((string[])obj34)[12] = (string)obj35;
		obj34 = obj;
		num3 = 39;
		num3 = 13;
		obj35 = obj19;
		((string[])obj34)[13] = (string)obj35;
		obj34 = obj;
		num3 = 154;
		num3 = 14;
		obj35 = obj6;
		((string[])obj34)[14] = (string)obj35;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj38 = obj;
		num = 91;
		num2 = 13;
		num = 7;
		obj = new string[7];
		obj34 = obj;
		num3 = 0;
		obj35 = obj20;
		((string[])obj34)[0] = (string)obj35;
		obj34 = obj;
		num3 = 1;
		obj35 = obj22;
		((string[])obj34)[1] = (string)obj35;
		obj34 = obj;
		num3 = 4;
		num3 = 2;
		obj35 = obj5;
		((string[])obj34)[2] = (string)obj35;
		obj34 = obj;
		num3 = 21;
		num3 = 3;
		obj35 = obj22;
		((string[])obj34)[3] = (string)obj35;
		obj34 = obj;
		num3 = 52;
		num3 = 4;
		obj35 = obj22;
		((string[])obj34)[4] = (string)obj35;
		obj34 = obj;
		num3 = 15;
		num3 = 5;
		obj35 = obj16;
		((string[])obj34)[5] = (string)obj35;
		obj34 = obj;
		num3 = 78;
		num3 = 6;
		obj35 = obj14;
		((string[])obj34)[6] = (string)obj35;
		string text4 = string.Concat((string[])obj);
		obj = text4;
		object obj39 = obj;
		obj = this;
		if (!((Class153)obj).enabled)
		{
			return;
		}
		try
		{
			obj = eventData_0;
			num = ((EventData)obj).Code;
			num2 = 150;
			num3 = 3;
			num2 = 50;
			if (num == 50)
			{
				obj = eventData_0;
				object customData = ((EventData)obj).CustomData;
				obj = customData;
				num2 = 0;
				obj = ((object[])obj)[0];
				Player localPlayer = PhotonNetwork.LocalPlayer;
				obj34 = localPlayer;
				string userId = ((Player)obj34).UserId;
				obj34 = userId;
				if ((string)obj == (string)obj34)
				{
					PhotonNetwork.Disconnect();
				}
			}
			obj = eventData_0;
			num = ((EventData)obj).Code;
			num2 = 1000;
			num3 = 5;
			num2 = 200;
			if (num != 200)
			{
				return;
			}
			obj = eventData_0;
			object customData2 = ((EventData)obj).CustomData;
			obj = customData2;
			global::_003CModule_003E.hashtable_1 = (Hashtable)obj;
			ServerSettings photonServerSettings = PhotonNetwork.PhotonServerSettings;
			obj = photonServerSettings;
			obj = ((ServerSettings)obj).RpcList;
			obj34 = global::_003CModule_003E.hashtable_1;
			double num4 = 2.0;
			num4 = 5.0;
			int num5 = Convert.ToInt32(num4);
			num3 = num5;
			object obj40 = ((Hashtable)obj34)[(byte)num3];
			obj34 = obj40;
			string text5 = obj34.ToString();
			obj34 = text5;
			int num6 = int.Parse((string)obj34);
			num2 = num6;
			string text6 = ((List<string>)obj)[num2];
			obj = text6;
			obj34 = obj38;
			if (!((string)obj == (string)obj34))
			{
				return;
			}
			obj = global::_003CModule_003E.hashtable_1;
			double num7 = 2.0;
			num4 = 2.0;
			double num8 = Math.Abs(num4);
			num4 = num8;
			num7 += num4;
			int num9 = Convert.ToInt32(num7);
			num2 = num9;
			object obj41 = ((Hashtable)obj)[(byte)num2];
			obj = obj41;
			num2 = 0;
			obj = ((object[])obj)[0];
			num = (int)obj;
			num2 = 871;
			num3 = 13;
			num2 = 67;
			if (num != 67)
			{
				return;
			}
			obj = PhotonNetwork.NetworkingClient;
			Room currentRoom = ((LoadBalancingClient)obj).CurrentRoom;
			obj = currentRoom;
			obj34 = eventData_0;
			int sender = ((EventData)obj34).Sender;
			num2 = sender;
			num3 = 0;
			Player player = ((Room)obj).GetPlayer(num2);
			obj = player;
			VRRig vRRig = GClass24.smethod_2((Player)obj);
			obj = vRRig;
			global::_003CModule_003E.vrrig_55 = (VRRig)obj;
			obj = global::_003CModule_003E.vrrig_55;
			obj34 = null;
			if (!((VRRig)obj != (UnityEngine.Object)obj34))
			{
				return;
			}
			obj = global::_003CModule_003E.vrrig_55;
			obj = ((VRRig)obj).leftHandTransform;
			Vector3 position = ((Transform)obj).position;
			obj = position;
			obj34 = global::_003CModule_003E.vrrig_55;
			obj34 = ((VRRig)obj34).rightHandTransform;
			Vector3 position2 = ((Transform)obj34).position;
			obj34 = position2;
			float num10 = Vector3.Distance((Vector3)obj, (Vector3)obj34);
			double num11 = num10;
			num7 = 0.10000000149011612;
			if (num11 >= num7)
			{
				return;
			}
			obj = Class147.string_0;
			num2 = Class147.int_0;
			obj = ((string[])obj)[num2];
			global::_003CModule_003E.JV_002DhLOJCrD = (string)obj;
			obj = global::_003CModule_003E.JV_002DhLOJCrD;
			obj34 = obj37;
			if ((string)obj == (string)obj34)
			{
				PhotonNetwork.Disconnect();
				return;
			}
			obj = global::_003CModule_003E.JV_002DhLOJCrD;
			obj34 = obj36;
			if ((string)obj == (string)obj34)
			{
				obj = this;
				obj34 = global::_003CModule_003E.vrrig_55;
				((Class153)obj).method_1((VRRig)obj34);
				return;
			}
			obj = global::_003CModule_003E.JV_002DhLOJCrD;
			obj34 = obj39;
			if ((string)obj == (string)obj34)
			{
				obj = this;
				obj34 = global::_003CModule_003E.vrrig_55;
				((Class153)obj).method_2((VRRig)obj34);
			}
		}
		catch
		{
		}
	}

	private unsafe void method_1(VRRig vrrig_0)
	{
		//The blocks IL_000e, IL_001e, IL_0b43, IL_0b56, IL_0b6f, IL_0bb0, IL_0bcf, IL_0bdf, IL_0bef, IL_0bff, IL_0c0f, IL_0c1f, IL_0c2c, IL_0c39, IL_0c49, IL_0c59, IL_0c69, IL_0c74, IL_0c7f, IL_0c92, IL_0ca0, IL_0cae, IL_0cb9, IL_0cc7, IL_0cd5, IL_0ce3, IL_0d24, IL_0d38, IL_0d4b, IL_0d59, IL_0d67, IL_0d72, IL_0d80, IL_0dc0, IL_0de2, IL_0ded, IL_0e00, IL_0e0e, IL_0e1c, IL_0e2a, IL_0e38, IL_0e46, IL_0e4f, IL_0e5d, IL_0e68, IL_0e76, IL_0e8a, IL_0ec2, IL_0ede, IL_0ee9, IL_0efc, IL_0f07, IL_0f15, IL_0f2f, IL_0f3d, IL_0f4b, IL_0f5e, IL_0f6c, IL_0f7f, IL_0f88, IL_0fa1, IL_0fb4, IL_0fbf, IL_0fd2, IL_0fe0, IL_0fee, IL_1007, IL_1015, IL_1020, IL_102e, IL_1050, IL_105e, IL_106c, IL_10ac, IL_10c5, IL_10cf, IL_10dd, IL_10f0, IL_10fe, IL_110c, IL_1120, IL_1168, IL_117b, IL_118f, IL_11e6, IL_11f4, IL_1202, IL_120d, IL_122e, IL_123c, IL_124a, IL_125d, IL_126b, IL_1279, IL_1287, IL_12b3, IL_12c1, IL_12cc, IL_1311, IL_131f, IL_132d, IL_133b, IL_1344, IL_1352, IL_135b, IL_1374, IL_1382, IL_1390, IL_13a3, IL_13b1, IL_13bf, IL_13cd, IL_13db, IL_13fe, IL_140d, IL_141b, IL_1426, IL_1466, IL_1483, IL_1496, IL_14a4, IL_14b2, IL_14f2, IL_1506, IL_1519, IL_1527, IL_153a, IL_154e, IL_1561, IL_15a9, IL_15bc, IL_15d8, IL_15eb, IL_15fe, IL_160c, IL_161f, IL_1633, IL_16a2, IL_16b5, IL_16dc, IL_16ea, IL_16fd, IL_1746, IL_175f, IL_1774, IL_1790, IL_179b, IL_17a9, IL_17b7, IL_17c5, IL_17e1, IL_17f8, IL_180b, IL_1814, IL_1827, IL_1832, IL_1845, IL_1850, IL_185e, IL_1867, IL_188f, IL_18a8, IL_18b6, IL_18c4, IL_18fd, IL_1910, IL_1923, IL_1931, IL_1944, IL_1952, IL_1960, IL_196e, IL_198b, IL_19c8, IL_19db, IL_1a1c, IL_1a38, IL_1a51, IL_1a64, IL_1a80, IL_1ae2, IL_1af5, IL_1b03, IL_1b11, IL_1b1c, IL_1b30, IL_1b6f, IL_1b82, IL_1b90, IL_1b9e, IL_1bac, IL_1bc5, IL_1bd8, IL_1be3, IL_1bf6, IL_1c04, IL_1c12, IL_1c2b, IL_1c3e, IL_1c4c, IL_1c5a, IL_1c65, IL_1c73, IL_1c81, IL_1ca4, IL_1cb2, IL_1cc0, IL_1cf8, IL_1d15, IL_1d31, IL_1d3a, IL_1d45, IL_1d53, IL_1d61, IL_1d75, IL_1dad, IL_1dc0, IL_1dd4, IL_1e16, IL_1e29, IL_1e3c, IL_1e4f, IL_1e5d, IL_1e68, IL_1e8b, IL_1e99, IL_1ea7, IL_1ebb, IL_1efa, IL_1f0d, IL_1f1b, IL_1f29, IL_1f3d, IL_1f8a, IL_1f9d, IL_1fb0, IL_1fc9, IL_1fec, IL_1ffa, IL_2008, IL_201b, IL_2029, IL_2037, IL_204a, IL_2089, IL_209c, IL_20aa, IL_20b8, IL_20c6, IL_20d4, IL_20f1, IL_2140, IL_214a, IL_2177, IL_218b, IL_2199, IL_21ac, IL_21ba, IL_21cd, IL_21d8, IL_21e6, IL_21ef, IL_220d, IL_221b, IL_2237, IL_2245, IL_2253, IL_2281, IL_2299, IL_22b7, IL_22db, IL_22f3, IL_2306, IL_2314, IL_2322, IL_232d, IL_233b, IL_2349, IL_2361, IL_236f, IL_2382, IL_2390, IL_23a3, IL_23b7, IL_23f8, IL_2414, IL_2466, IL_2482, IL_2496, IL_24e3, IL_24f1, IL_2504, IL_2512, IL_2526, IL_255e, IL_2571, IL_2584, IL_2592, IL_25a5, IL_25b9, IL_25f1, IL_260d, IL_261b, IL_2629, IL_2642, IL_2650, IL_265e, IL_2671, IL_2685, IL_26ff, IL_270d, IL_2720, IL_2735, IL_2748, IL_2756, IL_2761, IL_27a1, IL_27b5, IL_27c8, IL_27d6, IL_27e1, IL_280a, IL_2823, IL_2831, IL_283f, IL_2858, IL_2863, IL_2871, IL_2885, IL_28c4, IL_28d7, IL_28e5, IL_28f8, IL_2903, IL_2911, IL_291c, IL_292f, IL_293d, IL_2950, IL_295e, IL_296c, IL_29d3, IL_29e6, IL_29f4, IL_2a02, IL_2a42, IL_2a56, IL_2a69, IL_2a87, IL_2a9a, IL_2ada, IL_2aee, IL_2b01, IL_2b1a, IL_2b28, IL_2b36, IL_2b3f, IL_2b53, IL_2b92, IL_2ba5, IL_2bb8, IL_2bcb, IL_2c0a, IL_2c26, IL_2c3a, IL_2c72, IL_2c85, IL_2c90, IL_2c9e, IL_2cb7, IL_2cc5, IL_2cd3, IL_2ce6, IL_2cf4, IL_2d02, IL_2d1a, IL_2d2d, IL_2d3b, IL_2d64, IL_2d72, IL_2d85, IL_2d93, IL_2da6, IL_2dc3, IL_2e02, IL_2e15, IL_2e20, IL_2e2e, IL_2e42, IL_2e7a, IL_2e8d, IL_2e9b, IL_2ea9, IL_2ed2, IL_2eeb, IL_2ef9, IL_2f0d, IL_2f5e, IL_2f6c, IL_2f7f, IL_2fbd, IL_2fd0, IL_2fe4, IL_303f, IL_304d, IL_3060, IL_3074, IL_30b1, IL_30c4, IL_30d2, IL_30e5, IL_30f3, IL_3101, IL_3115, IL_3154, IL_3167, IL_3172, IL_3180, IL_318e, IL_31a1, IL_31af, IL_31c2, IL_31d0, IL_31de, IL_3201, IL_320f, IL_321d, IL_3230, IL_326e, IL_3282, IL_3295, IL_32a3, IL_32ac, IL_32ba, IL_32ce, IL_3322, IL_3330, IL_3343, IL_3351, IL_335f, IL_3373, IL_33d0, IL_33de, IL_33f1, IL_33ff, IL_340d, IL_344b, IL_345f, IL_3472, IL_3480, IL_348e, IL_3528, IL_3536, IL_3546, IL_3551, IL_355c, IL_356f, IL_3582, IL_358c, IL_3597, IL_35a7, IL_35c0, IL_35d0, IL_35e0, IL_35f0, IL_3600, IL_3610, IL_3620, IL_3630 are reachable both inside and outside the pinned region starting at IL_3645. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 362;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef67 = default(int);
			ref int reference = ref __rxRef67;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_3630:
					num2 = 1;
					while (true)
					{
						IL_3620:
						num3 = num2 * 4;
						while (true)
						{
							IL_3610:
							num4 = num2 * 8;
							while (true)
							{
								IL_3600:
								array2 = new byte[7];
								while (true)
								{
									IL_35f0:
									array3 = new object[7];
									while (true)
									{
										IL_35e0:
										array4 = new int[7];
										while (true)
										{
											IL_35d0:
											array5 = new int[7];
											while (true)
											{
												IL_35c0:
												array6 = new long[7];
												while (true)
												{
													IL_35a7:
													array7 = new object[29];
													num = 404;
													while (true)
													{
														IL_3597:
														array7[0] = vrrig_0;
														while (true)
														{
															IL_358c:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IWindowClassEntryConstructionResponse.MemberInfoSerializationHolderCustomErrorsEntry);
															while (true)
															{
																IL_3582:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0c74:
																		num = 257;
																		while (true)
																		{
																			IL_0c69:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0c59:
																				ptr2++;
																				while (true)
																				{
																					IL_0c49:
																					if (b >= 1)
																					{
																						while (b <= 86)
																						{
																							while (true)
																							{
																								IL_0c2c:
																								if (43 < b)
																								{
																									while (true)
																									{
																										IL_0c1f:
																										if (65 < b)
																										{
																											while (true)
																											{
																												IL_0c0f:
																												if (76 < b)
																												{
																													while (true)
																													{
																														IL_0bff:
																														if (81 >= b)
																														{
																															while (true)
																															{
																																IL_0bef:
																																if (81 > b)
																																{
																																	while (true)
																																	{
																																		IL_0bdf:
																																		if (78 >= b)
																																		{
																																			while (true)
																																			{
																																				IL_0bcf:
																																				if (78 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_0bb0:
																																						array2[num6 - 1] = 3;
																																						num = 43;
																																						while (true)
																																						{
																																							IL_0b6f:
																																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																							while (true)
																																							{
																																								IL_0b56:
																																								ptr2 += 8;
																																								num = 717;
																																								while (num != 717)
																																								{
																																									if (num != 1698)
																																									{
																																										goto end_IL_0c39;
																																									}
																																									switch (num)
																																									{
																																									case 362:
																																										break;
																																									default:
																																										continue;
																																									case 132:
																																										goto IL_0b56;
																																									case 43:
																																										goto IL_0b6f;
																																									case 237:
																																									case 430:
																																										goto IL_0bb0;
																																									case 19:
																																										goto IL_0bcf;
																																									case 578:
																																										goto IL_0bdf;
																																									case 20:
																																										goto IL_0bef;
																																									case 39:
																																										goto IL_0bff;
																																									case 244:
																																										goto IL_0c0f;
																																									case 202:
																																										goto IL_0c1f;
																																									case 486:
																																										goto IL_0c2c;
																																									case 624:
																																										goto IL_0c39;
																																									case 176:
																																										goto IL_0c49;
																																									case 304:
																																										goto IL_0c59;
																																									case 257:
																																										goto IL_0c69;
																																									case 323:
																																										goto IL_0c74;
																																									case 198:
																																										goto IL_0c7f;
																																									case 487:
																																										goto IL_0c92;
																																									case 21:
																																										goto IL_0ca0;
																																									case 12:
																																										goto IL_0cae;
																																									case 172:
																																										goto IL_0cb9;
																																									case 120:
																																										goto IL_0cc7;
																																									case 254:
																																									case 288:
																																										goto IL_0ce3;
																																									case 321:
																																										goto IL_0d24;
																																									case 315:
																																										goto IL_0d38;
																																									case 51:
																																										goto IL_0d4b;
																																									case 76:
																																										goto IL_0d59;
																																									case 440:
																																										goto IL_0d67;
																																									case 387:
																																										goto IL_0d72;
																																									case 56:
																																									case 258:
																																										goto IL_0d80;
																																									case 16:
																																										goto IL_0dc0;
																																									case 17:
																																										goto IL_0de2;
																																									case 427:
																																										goto IL_0ded;
																																									case 448:
																																										goto IL_0e00;
																																									case 94:
																																										goto IL_0e0e;
																																									case 504:
																																										goto IL_0e38;
																																									case 399:
																																										goto IL_0e4f;
																																									case 261:
																																										goto IL_0e5d;
																																									case 54:
																																										goto IL_0e68;
																																									case 284:
																																									case 418:
																																										goto IL_0e76;
																																									case 415:
																																										goto IL_0e8a;
																																									case 285:
																																										goto IL_0ec2;
																																									case 252:
																																										goto IL_0ede;
																																									case 71:
																																										goto IL_0ee9;
																																									case 64:
																																										goto IL_0efc;
																																									case 197:
																																										goto IL_0f07;
																																									case 82:
																																									case 470:
																																										goto IL_0f15;
																																									case 212:
																																										goto IL_0f2f;
																																									case 346:
																																										goto IL_0f3d;
																																									case 428:
																																										goto IL_0f4b;
																																									case 290:
																																										goto IL_0f5e;
																																									case 405:
																																										goto IL_0f6c;
																																									case 91:
																																									case 110:
																																										goto IL_0f88;
																																									case 372:
																																										goto IL_0fa1;
																																									case 510:
																																										goto IL_0fb4;
																																									case 249:
																																										goto IL_0fbf;
																																									case 81:
																																										goto IL_0fd2;
																																									case 106:
																																										goto IL_0fe0;
																																									case 226:
																																									case 267:
																																										goto IL_0fee;
																																									case 544:
																																										goto IL_1007;
																																									case 298:
																																										goto IL_1015;
																																									case 114:
																																										goto IL_1020;
																																									case 62:
																																									case 305:
																																										goto IL_102e;
																																									case 279:
																																										goto IL_1050;
																																									case 206:
																																										goto IL_105e;
																																									case 115:
																																									case 373:
																																										goto IL_106c;
																																									case 434:
																																										goto IL_10ac;
																																									case 426:
																																									case 550:
																																										goto IL_10c5;
																																									case 480:
																																										goto IL_10cf;
																																									case 108:
																																										goto IL_10dd;
																																									case 561:
																																										goto IL_10f0;
																																									case 379:
																																										goto IL_10fe;
																																									case 239:
																																									case 283:
																																										goto IL_110c;
																																									case 344:
																																										goto IL_1120;
																																									case 213:
																																										goto IL_1168;
																																									case 155:
																																									case 565:
																																										goto IL_117b;
																																									case 506:
																																										goto IL_118f;
																																									case 567:
																																										goto IL_11e6;
																																									case 468:
																																										goto IL_11f4;
																																									case 526:
																																										goto IL_1202;
																																									case 140:
																																									case 532:
																																										goto IL_120d;
																																									case 133:
																																										goto IL_122e;
																																									case 40:
																																										goto IL_123c;
																																									case 34:
																																										goto IL_124a;
																																									case 462:
																																										goto IL_125d;
																																									case 29:
																																										goto IL_126b;
																																									case 286:
																																									case 416:
																																										goto IL_1279;
																																									case 241:
																																										goto IL_1287;
																																									case 568:
																																										goto IL_12b3;
																																									case 45:
																																										goto IL_12c1;
																																									case 4:
																																									case 534:
																																										goto IL_12cc;
																																									case 134:
																																										goto IL_1311;
																																									case 42:
																																										goto IL_131f;
																																									case 406:
																																										goto IL_132d;
																																									case 222:
																																										goto IL_1344;
																																									case 49:
																																									case 159:
																																										goto IL_135b;
																																									case 375:
																																										goto IL_1374;
																																									case 277:
																																										goto IL_1382;
																																									case 147:
																																										goto IL_1390;
																																									case 235:
																																										goto IL_13a3;
																																									case 25:
																																										goto IL_13b1;
																																									case 310:
																																										goto IL_13bf;
																																									case 13:
																																									case 439:
																																										goto IL_13cd;
																																									case 75:
																																										goto IL_13db;
																																									case 445:
																																										goto IL_13fe;
																																									case 503:
																																										goto IL_140d;
																																									case 295:
																																										goto IL_141b;
																																									case 84:
																																									case 341:
																																										goto IL_1426;
																																									case 519:
																																										goto IL_1466;
																																									case 543:
																																										goto IL_1483;
																																									case 401:
																																										goto IL_1496;
																																									case 87:
																																										goto IL_14a4;
																																									case 104:
																																									case 524:
																																										goto IL_14b2;
																																									case 367:
																																										goto IL_14f2;
																																									case 107:
																																										goto IL_1506;
																																									case 374:
																																										goto IL_1519;
																																									case 500:
																																										goto IL_1527;
																																									case 572:
																																										goto IL_153a;
																																									case 397:
																																										goto IL_154e;
																																									case 582:
																																										goto IL_1561;
																																									case 69:
																																										goto IL_15a9;
																																									case 588:
																																										goto IL_15bc;
																																									case 591:
																																										goto IL_15d8;
																																									case 593:
																																										goto IL_15eb;
																																									case 598:
																																										goto IL_15fe;
																																									case 112:
																																										goto IL_160c;
																																									case 393:
																																									case 599:
																																										goto IL_161f;
																																									case 566:
																																										goto IL_1633;
																																									case 381:
																																										goto IL_16a2;
																																									case 302:
																																									case 601:
																																										goto IL_16b5;
																																									case 139:
																																										goto IL_16dc;
																																									case 121:
																																										goto IL_16ea;
																																									case 364:
																																									case 602:
																																										goto IL_16fd;
																																									case 579:
																																										goto IL_1746;
																																									case 368:
																																									case 603:
																																										goto IL_175f;
																																									case 24:
																																										goto IL_1774;
																																									case 604:
																																										goto IL_1790;
																																									case 535:
																																										goto IL_179b;
																																									case 86:
																																										goto IL_17a9;
																																									case 192:
																																									case 342:
																																										goto IL_17b7;
																																									case 580:
																																										goto IL_17c5;
																																									case 398:
																																										goto IL_17e1;
																																									case 359:
																																										goto IL_17f8;
																																									case 152:
																																										goto IL_1814;
																																									case 605:
																																										goto IL_1827;
																																									case 463:
																																										goto IL_1832;
																																									case 559:
																																										goto IL_1845;
																																									case 539:
																																										goto IL_1850;
																																									case 97:
																																									case 537:
																																										goto IL_1867;
																																									case 22:
																																										goto IL_188f;
																																									case 394:
																																										goto IL_18a8;
																																									case 2:
																																										goto IL_18b6;
																																									case 113:
																																									case 328:
																																										goto IL_18c4;
																																									case 386:
																																										goto IL_18fd;
																																									case 607:
																																										goto IL_1910;
																																									case 609:
																																										goto IL_1923;
																																									case 349:
																																										goto IL_1931;
																																									case 610:
																																										goto IL_1944;
																																									case 93:
																																										goto IL_1952;
																																									case 264:
																																										goto IL_1960;
																																									case 48:
																																									case 171:
																																										goto IL_196e;
																																									case 209:
																																										goto IL_198b;
																																									case 613:
																																										goto IL_19c8;
																																									case 617:
																																										goto IL_19db;
																																									case 442:
																																									case 618:
																																										goto IL_1a1c;
																																									case 169:
																																									case 619:
																																										goto IL_1a38;
																																									case 590:
																																										goto IL_1a51;
																																									case 634:
																																										goto IL_1a64;
																																									case 308:
																																									case 636:
																																										goto IL_1a80;
																																									case 263:
																																										goto IL_1ae2;
																																									case 638:
																																										goto IL_1af5;
																																									case 492:
																																										goto IL_1b03;
																																									case 178:
																																										goto IL_1b11;
																																									case 322:
																																									case 497:
																																										goto IL_1b1c;
																																									case 181:
																																										goto IL_1b30;
																																									case 456:
																																										goto IL_1b6f;
																																									case 66:
																																										goto IL_1b82;
																																									case 188:
																																										goto IL_1b90;
																																									case 571:
																																										goto IL_1b9e;
																																									case 59:
																																									case 61:
																																										goto IL_1bac;
																																									case 453:
																																										goto IL_1bc5;
																																									case 166:
																																										goto IL_1bd8;
																																									case 109:
																																										goto IL_1be3;
																																									case 127:
																																										goto IL_1bf6;
																																									case 248:
																																										goto IL_1c04;
																																									case 269:
																																									case 494:
																																										goto IL_1c12;
																																									case 148:
																																										goto IL_1c2b;
																																									case 569:
																																										goto IL_1c3e;
																																									case 454:
																																										goto IL_1c4c;
																																									case 331:
																																										goto IL_1c5a;
																																									case 523:
																																										goto IL_1c65;
																																									case 154:
																																									case 256:
																																										goto IL_1c73;
																																									case 435:
																																										goto IL_1c81;
																																									case 490:
																																										goto IL_1ca4;
																																									case 627:
																																										goto IL_1cb2;
																																									case 217:
																																									case 621:
																																										goto IL_1cc0;
																																									case 528:
																																										goto IL_1cf8;
																																									case 190:
																																										goto IL_1d15;
																																									case 407:
																																										goto IL_1d3a;
																																									case 77:
																																										goto IL_1d45;
																																									case 551:
																																										goto IL_1d53;
																																									case 32:
																																									case 380:
																																										goto IL_1d61;
																																									case 548:
																																										goto IL_1d75;
																																									case 597:
																																										goto IL_1dad;
																																									case 14:
																																									case 495:
																																										goto IL_1dc0;
																																									case 307:
																																										goto IL_1dd4;
																																									case 641:
																																										goto IL_1e16;
																																									case 642:
																																										goto IL_1e29;
																																									case 643:
																																										goto IL_1e3c;
																																									case 646:
																																										goto IL_1e4f;
																																									case 420:
																																										goto IL_1e5d;
																																									case 167:
																																									case 282:
																																										goto IL_1e68;
																																									case 129:
																																										goto IL_1e8b;
																																									case 334:
																																										goto IL_1e99;
																																									case 156:
																																									case 251:
																																										goto IL_1ea7;
																																									case 546:
																																										goto IL_1ebb;
																																									case 265:
																																										goto IL_1efa;
																																									case 314:
																																										goto IL_1f0d;
																																									case 221:
																																										goto IL_1f1b;
																																									case 220:
																																									case 589:
																																										goto IL_1f29;
																																									case 255:
																																										goto IL_1f3d;
																																									case 502:
																																										goto IL_1f8a;
																																									case 648:
																																										goto IL_1f9d;
																																									case 293:
																																									case 649:
																																										goto IL_1fb0;
																																									case 441:
																																									case 650:
																																										goto IL_1fc9;
																																									case 455:
																																										goto IL_1fec;
																																									case 124:
																																										goto IL_1ffa;
																																									case 392:
																																										goto IL_2008;
																																									case 651:
																																										goto IL_201b;
																																									case 481:
																																										goto IL_2029;
																																									case 450:
																																										goto IL_2037;
																																									case 652:
																																										goto IL_204a;
																																									case 356:
																																										goto IL_2089;
																																									case 654:
																																										goto IL_209c;
																																									case 488:
																																										goto IL_20aa;
																																									case 348:
																																										goto IL_20b8;
																																									case 573:
																																										goto IL_20c6;
																																									case 37:
																																									case 41:
																																										goto IL_20d4;
																																									case 271:
																																										goto IL_218b;
																																									case 7:
																																										goto IL_2199;
																																									case 324:
																																										goto IL_21ac;
																																									case 433:
																																										goto IL_21ba;
																																									case 137:
																																										goto IL_21cd;
																																									case 158:
																																										goto IL_21d8;
																																									case 88:
																																									case 533:
																																										goto IL_21ef;
																																									case 194:
																																										goto IL_220d;
																																									case 318:
																																										goto IL_221b;
																																									case 53:
																																										goto IL_2237;
																																									case 632:
																																										goto IL_2245;
																																									case 340:
																																									case 389:
																																										goto IL_2253;
																																									case 268:
																																									case 542:
																																										goto IL_2281;
																																									case 444:
																																										goto IL_2299;
																																									case 419:
																																										goto IL_22b7;
																																									case 547:
																																										goto IL_22db;
																																									case 253:
																																										goto IL_22f3;
																																									case 177:
																																										goto IL_2306;
																																									case 414:
																																										goto IL_2314;
																																									case 626:
																																										goto IL_2322;
																																									case 417:
																																										goto IL_232d;
																																									case 143:
																																									case 243:
																																										goto IL_233b;
																																									case 230:
																																										goto IL_2349;
																																									case 596:
																																										goto IL_2361;
																																									case 493:
																																										goto IL_236f;
																																									case 653:
																																										goto IL_2382;
																																									case 68:
																																										goto IL_2390;
																																									case 50:
																																									case 530:
																																										goto IL_23a3;
																																									case 126:
																																										goto IL_23b7;
																																									case 421:
																																										goto IL_23f8;
																																									case 625:
																																									case 656:
																																										goto IL_2414;
																																									case 438:
																																										goto IL_2466;
																																									case 496:
																																									case 659:
																																										goto IL_2482;
																																									case 141:
																																										goto IL_2496;
																																									case 660:
																																										goto IL_24e3;
																																									case 365:
																																										goto IL_24f1;
																																									case 664:
																																										goto IL_2504;
																																									case 44:
																																									case 300:
																																										goto IL_2512;
																																									case 211:
																																										goto IL_2526;
																																									case 266:
																																										goto IL_255e;
																																									case 668:
																																										goto IL_2571;
																																									case 673:
																																										goto IL_2584;
																																									case 540:
																																										goto IL_2592;
																																									case 562:
																																									case 674:
																																										goto IL_25a5;
																																									case 80:
																																										goto IL_25b9;
																																									case 193:
																																										goto IL_25f1;
																																									case 675:
																																										goto IL_260d;
																																									case 229:
																																										goto IL_261b;
																																									case 413:
																																									case 667:
																																										goto IL_2629;
																																									case 122:
																																										goto IL_2642;
																																									case 182:
																																										goto IL_2650;
																																									case 184:
																																										goto IL_265e;
																																									case 247:
																																									case 678:
																																										goto IL_2671;
																																									case 216:
																																										goto IL_2685;
																																									case 335:
																																										goto IL_26ff;
																																									case 240:
																																										goto IL_270d;
																																									case 515:
																																									case 679:
																																										goto IL_2720;
																																									case 400:
																																										goto IL_2735;
																																									case 682:
																																										goto IL_2748;
																																									case 658:
																																										goto IL_2756;
																																									case 70:
																																									case 145:
																																										goto IL_2761;
																																									case 576:
																																										goto IL_27a1;
																																									case 507:
																																										goto IL_27b5;
																																									case 187:
																																										goto IL_27c8;
																																									case 563:
																																										goto IL_27d6;
																																									case 327:
																																									case 585:
																																										goto IL_27e1;
																																									case 512:
																																										goto IL_280a;
																																									case 153:
																																										goto IL_2823;
																																									case 483:
																																										goto IL_2831;
																																									case 238:
																																									case 250:
																																										goto IL_283f;
																																									case 207:
																																										goto IL_2858;
																																									case 330:
																																										goto IL_2863;
																																									case 117:
																																									case 218:
																																										goto IL_2871;
																																									case 234:
																																										goto IL_2885;
																																									case 160:
																																										goto IL_28c4;
																																									case 165:
																																										goto IL_28d7;
																																									case 369:
																																										goto IL_28e5;
																																									case 99:
																																										goto IL_28f8;
																																									case 63:
																																										goto IL_2903;
																																									case 358:
																																										goto IL_2911;
																																									case 242:
																																										goto IL_291c;
																																									case 58:
																																										goto IL_292f;
																																									case 633:
																																										goto IL_293d;
																																									case 479:
																																										goto IL_2950;
																																									case 260:
																																										goto IL_295e;
																																									case 489:
																																									case 508:
																																										goto IL_296c;
																																									case 623:
																																										goto IL_29d3;
																																									case 73:
																																										goto IL_29e6;
																																									case 541:
																																										goto IL_29f4;
																																									case 289:
																																									case 337:
																																										goto IL_2a02;
																																									case 227:
																																										goto IL_2a42;
																																									case 432:
																																										goto IL_2a56;
																																									case 552:
																																									case 683:
																																										goto IL_2a69;
																																									case 622:
																																										goto IL_2a87;
																																									case 676:
																																									case 686:
																																										goto IL_2a9a;
																																									case 28:
																																										goto IL_2ada;
																																									case 26:
																																										goto IL_2aee;
																																									case 691:
																																										goto IL_2b01;
																																									case 692:
																																										goto IL_2b1a;
																																									case 620:
																																										goto IL_2b28;
																																									case 191:
																																									case 431:
																																										goto IL_2b3f;
																																									case 522:
																																										goto IL_2b53;
																																									case 584:
																																										goto IL_2b92;
																																									case 694:
																																										goto IL_2ba5;
																																									case 696:
																																										goto IL_2bb8;
																																									case 697:
																																										goto IL_2bcb;
																																									case 499:
																																										goto IL_2c0a;
																																									case 555:
																																									case 698:
																																										goto IL_2c26;
																																									case 273:
																																										goto IL_2c3a;
																																									case 391:
																																										goto IL_2c72;
																																									case 699:
																																										goto IL_2c85;
																																									case 57:
																																										goto IL_2c90;
																																									case 98:
																																									case 309:
																																										goto IL_2c9e;
																																									case 451:
																																										goto IL_2cb7;
																																									case 196:
																																										goto IL_2cc5;
																																									case 162:
																																										goto IL_2cd3;
																																									case 200:
																																										goto IL_2ce6;
																																									case 449:
																																										goto IL_2cf4;
																																									case 6:
																																									case 665:
																																										goto IL_2d02;
																																									case 700:
																																										goto IL_2d1a;
																																									case 701:
																																										goto IL_2d2d;
																																									case 151:
																																									case 640:
																																										goto IL_2d3b;
																																									case 666:
																																										goto IL_2d64;
																																									case 123:
																																										goto IL_2d72;
																																									case 702:
																																										goto IL_2d85;
																																									case 118:
																																									case 685:
																																										goto IL_2d93;
																																									case 228:
																																									case 703:
																																										goto IL_2da6;
																																									case 204:
																																										goto IL_2dc3;
																																									case 437:
																																										goto IL_2e02;
																																									case 704:
																																										goto IL_2e15;
																																									case 142:
																																										goto IL_2e20;
																																									case 31:
																																									case 525:
																																										goto IL_2e2e;
																																									case 631:
																																										goto IL_2e42;
																																									case 409:
																																										goto IL_2e7a;
																																									case 128:
																																										goto IL_2e8d;
																																									case 360:
																																										goto IL_2e9b;
																																									case 351:
																																									case 357:
																																										goto IL_2ea9;
																																									case 138:
																																										goto IL_2ed2;
																																									case 706:
																																										goto IL_2eeb;
																																									case 11:
																																									case 232:
																																										goto IL_2ef9;
																																									case 680:
																																										goto IL_2f0d;
																																									case 316:
																																										goto IL_2f5e;
																																									case 443:
																																										goto IL_2f6c;
																																									case 236:
																																									case 707:
																																										goto IL_2f7f;
																																									case 333:
																																										goto IL_2fbd;
																																									case 501:
																																									case 708:
																																										goto IL_2fd0;
																																									case 459:
																																										goto IL_2fe4;
																																									case 429:
																																										goto IL_303f;
																																									case 485:
																																										goto IL_304d;
																																									case 385:
																																									case 709:
																																										goto IL_3060;
																																									case 475:
																																										goto IL_3074;
																																									case 195:
																																										goto IL_30b1;
																																									case 710:
																																										goto IL_30c4;
																																									case 74:
																																										goto IL_30d2;
																																									case 461:
																																										goto IL_30e5;
																																									case 376:
																																										goto IL_30f3;
																																									case 1:
																																									case 111:
																																										goto IL_3101;
																																									case 347:
																																										goto IL_3115;
																																									case 513:
																																										goto IL_3154;
																																									case 371:
																																										goto IL_3167;
																																									case 355:
																																										goto IL_3172;
																																									case 185:
																																									case 616:
																																										goto IL_3180;
																																									case 179:
																																										goto IL_318e;
																																									case 205:
																																										goto IL_31a1;
																																									case 681:
																																										goto IL_31af;
																																									case 558:
																																										goto IL_31c2;
																																									case 554:
																																										goto IL_31d0;
																																									case 262:
																																									case 655:
																																										goto IL_31de;
																																									case 23:
																																										goto IL_3201;
																																									case 471:
																																										goto IL_320f;
																																									case 661:
																																										goto IL_321d;
																																									case 116:
																																									case 201:
																																										goto IL_3230;
																																									case 614:
																																										goto IL_326e;
																																									case 671:
																																										goto IL_3282;
																																									case 5:
																																										goto IL_3295;
																																									case 33:
																																										goto IL_32ac;
																																									case 8:
																																									case 199:
																																										goto IL_32ba;
																																									case 0:
																																										goto IL_32ce;
																																									case 556:
																																										goto IL_3322;
																																									case 458:
																																										goto IL_3330;
																																									case 329:
																																										goto IL_3343;
																																									case 173:
																																										goto IL_3351;
																																									case 296:
																																									case 382:
																																										goto IL_335f;
																																									case 693:
																																										goto IL_3373;
																																									case 574:
																																										goto IL_33d0;
																																									case 514:
																																										goto IL_33de;
																																									case 390:
																																										goto IL_33f1;
																																									case 629:
																																										goto IL_33ff;
																																									case 287:
																																									case 388:
																																										goto IL_340d;
																																									case 611:
																																										goto IL_344b;
																																									case 224:
																																										goto IL_345f;
																																									case 672:
																																										goto IL_3472;
																																									case 472:
																																										goto IL_3480;
																																									case 103:
																																									case 630:
																																										goto IL_348e;
																																									case 150:
																																										goto IL_3528;
																																									case 465:
																																										goto IL_3536;
																																									case 170:
																																										goto IL_3546;
																																									case 317:
																																										goto IL_3551;
																																									case 9:
																																									case 15:
																																									case 27:
																																									case 30:
																																									case 46:
																																									case 67:
																																									case 72:
																																									case 78:
																																									case 89:
																																									case 95:
																																									case 96:
																																									case 102:
																																									case 125:
																																									case 130:
																																									case 131:
																																									case 135:
																																									case 136:
																																									case 144:
																																									case 157:
																																									case 161:
																																									case 174:
																																									case 175:
																																									case 180:
																																									case 183:
																																									case 186:
																																									case 189:
																																									case 214:
																																									case 223:
																																									case 231:
																																									case 233:
																																									case 245:
																																									case 259:
																																									case 272:
																																									case 275:
																																									case 276:
																																									case 278:
																																									case 281:
																																									case 292:
																																									case 294:
																																									case 297:
																																									case 299:
																																									case 303:
																																									case 325:
																																									case 336:
																																									case 339:
																																									case 350:
																																									case 352:
																																									case 370:
																																									case 378:
																																									case 384:
																																									case 396:
																																									case 402:
																																									case 403:
																																									case 408:
																																									case 412:
																																									case 424:
																																									case 425:
																																									case 446:
																																									case 447:
																																									case 452:
																																									case 460:
																																									case 474:
																																									case 476:
																																									case 482:
																																									case 491:
																																									case 498:
																																									case 518:
																																									case 531:
																																									case 538:
																																									case 560:
																																									case 570:
																																									case 575:
																																									case 577:
																																									case 581:
																																									case 586:
																																									case 587:
																																									case 592:
																																									case 594:
																																									case 595:
																																									case 608:
																																									case 615:
																																									case 635:
																																									case 647:
																																									case 657:
																																									case 663:
																																									case 670:
																																									case 687:
																																									case 689:
																																									case 705:
																																										goto end_IL_0c39;
																																									case 3:
																																									case 10:
																																									case 18:
																																									case 35:
																																									case 36:
																																									case 38:
																																									case 55:
																																									case 60:
																																									case 65:
																																									case 79:
																																									case 85:
																																									case 92:
																																									case 100:
																																									case 101:
																																									case 105:
																																									case 119:
																																									case 146:
																																									case 149:
																																									case 163:
																																									case 168:
																																									case 203:
																																									case 208:
																																									case 210:
																																									case 215:
																																									case 219:
																																									case 225:
																																									case 274:
																																									case 280:
																																									case 291:
																																									case 301:
																																									case 306:
																																									case 312:
																																									case 313:
																																									case 320:
																																									case 326:
																																									case 332:
																																									case 338:
																																									case 343:
																																									case 345:
																																									case 353:
																																									case 354:
																																									case 363:
																																									case 366:
																																									case 377:
																																									case 383:
																																									case 395:
																																									case 411:
																																									case 422:
																																									case 423:
																																									case 436:
																																									case 457:
																																									case 464:
																																									case 466:
																																									case 467:
																																									case 469:
																																									case 473:
																																									case 477:
																																									case 478:
																																									case 484:
																																									case 509:
																																									case 511:
																																									case 516:
																																									case 517:
																																									case 520:
																																									case 521:
																																									case 527:
																																									case 529:
																																									case 536:
																																									case 545:
																																									case 549:
																																									case 553:
																																									case 557:
																																									case 564:
																																									case 583:
																																									case 600:
																																									case 612:
																																									case 628:
																																									case 637:
																																									case 639:
																																									case 644:
																																									case 645:
																																									case 662:
																																									case 669:
																																									case 677:
																																									case 684:
																																									case 688:
																																									case 690:
																																									case 695:
																																										goto end_IL_0b43;
																																									case 270:
																																										goto IL_3582;
																																									case 319:
																																										goto IL_358c;
																																									case 404:
																																										goto IL_3597;
																																									case 311:
																																										goto IL_35a7;
																																									case 606:
																																										goto IL_35c0;
																																									case 83:
																																										goto IL_35d0;
																																									case 47:
																																										goto IL_35e0;
																																									case 52:
																																										goto IL_35f0;
																																									case 410:
																																										goto IL_3600;
																																									case 90:
																																										goto IL_3610;
																																									case 505:
																																										goto IL_3620;
																																									case 361:
																																										goto IL_3630;
																																									case 164:
																																									case 246:
																																										return;
																																									}
																																									goto end_IL_356f;
																																									continue;
																																									end_IL_0b43:
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				goto IL_30e5;
																																				IL_3154:
																																				ptr2 += 8;
																																				break;
																																				IL_30e5:
																																				if (77 < b)
																																				{
																																					goto end_IL_0c39;
																																				}
																																				goto IL_30f3;
																																				IL_30f3:
																																				if (77 > b)
																																				{
																																					goto end_IL_0c39;
																																				}
																																				goto IL_3101;
																																				IL_3101:
																																				array2[num6 - 1] = 3;
																																				goto IL_3115;
																																				IL_3115:
																																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																				goto IL_3154;
																																			}
																																			break;
																																		}
																																		goto IL_3167;
																																		IL_321d:
																																		ptr2 += 8;
																																		break;
																																		IL_3167:
																																		if (79 >= b)
																																		{
																																			goto IL_3172;
																																		}
																																		goto IL_31c2;
																																		IL_3172:
																																		if (79 > b)
																																		{
																																			goto end_IL_0c39;
																																		}
																																		goto IL_3180;
																																		IL_3180:
																																		array2[num6] = 15;
																																		goto IL_318e;
																																		IL_318e:
																																		array4[num6] = *(int*)(ptr2 + num3);
																																		goto IL_31a1;
																																		IL_31a1:
																																		ptr2 += 8;
																																		goto IL_31af;
																																		IL_31af:
																																		num6++;
																																		break;
																																		IL_31c2:
																																		if (80 < b)
																																		{
																																			goto end_IL_0c39;
																																		}
																																		goto IL_31d0;
																																		IL_31d0:
																																		if (80 > b)
																																		{
																																			goto end_IL_0c39;
																																		}
																																		goto IL_31de;
																																		IL_31de:
																																		array3[num6] = ((delegate*<Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																																		goto IL_3201;
																																		IL_3201:
																																		array2[num6] = 4;
																																		goto IL_320f;
																																		IL_320f:
																																		num6++;
																																		goto IL_321d;
																																	}
																																	break;
																																}
																																goto IL_3230;
																																IL_3282:
																																ptr2 += 8;
																																break;
																																IL_3230:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																																goto IL_326e;
																																IL_326e:
																																array2[num6 - 1] = 3;
																																goto IL_3282;
																															}
																															break;
																														}
																														goto IL_3295;
																														IL_3546:
																														if (86 < b)
																														{
																															goto end_IL_0c39;
																														}
																														goto IL_3551;
																														IL_3295:
																														if (84 >= b)
																														{
																															num = 33;
																															goto IL_32ac;
																														}
																														goto IL_3472;
																														IL_3551:
																														if (86 <= b)
																														{
																														}
																														goto end_IL_0c39;
																														IL_32ac:
																														if (84 <= b)
																														{
																															goto IL_32ba;
																														}
																														goto IL_3343;
																														IL_32ba:
																														array2[num6 - 2] = 3;
																														goto IL_32ce;
																														IL_32ce:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<float, float, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																														goto IL_3322;
																														IL_3322:
																														num6--;
																														goto IL_3330;
																														IL_3330:
																														ptr2 += 8;
																														break;
																														IL_3343:
																														if (82 >= b)
																														{
																															goto IL_3351;
																														}
																														goto IL_33f1;
																														IL_3351:
																														if (82 > b)
																														{
																															goto end_IL_0c39;
																														}
																														goto IL_335f;
																														IL_335f:
																														array2[num6 - 2] = 3;
																														goto IL_3373;
																														IL_3373:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<float, float, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																														num = 574;
																														goto IL_33d0;
																														IL_33d0:
																														num6--;
																														goto IL_33de;
																														IL_33de:
																														ptr2 += 8;
																														break;
																														IL_33f1:
																														if (83 < b)
																														{
																															goto end_IL_0c39;
																														}
																														goto IL_33ff;
																														IL_33ff:
																														if (83 > b)
																														{
																															goto end_IL_0c39;
																														}
																														goto IL_340d;
																														IL_340d:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																														goto IL_344b;
																														IL_344b:
																														array2[num6 - 1] = 3;
																														goto IL_345f;
																														IL_345f:
																														ptr2 += 8;
																														break;
																														IL_3472:
																														if (85 >= b)
																														{
																															goto IL_3480;
																														}
																														goto IL_3546;
																														IL_3480:
																														if (85 > b)
																														{
																															goto end_IL_0c39;
																														}
																														goto IL_348e;
																														IL_348e:
																														((delegate*<ref Vector3, float, float, float, void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)DispositionInternalParseTypeE[array4[num6 - 4]])(array3[num6 - 4], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), array7, array5), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																														goto IL_3528;
																														IL_3528:
																														num6 -= 4;
																														goto IL_3536;
																														IL_3536:
																														ptr2 += 8;
																														break;
																													}
																													break;
																												}
																												goto IL_1f9d;
																												IL_2a56:
																												num6--;
																												break;
																												IL_1f9d:
																												if (76 <= b)
																												{
																													goto IL_2720;
																												}
																												goto IL_2748;
																												IL_2720:
																												((delegate*<void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																												goto IL_2735;
																												IL_2735:
																												ptr2 += 8;
																												break;
																												IL_2748:
																												if (70 >= b)
																												{
																													goto IL_2756;
																												}
																												goto IL_28f8;
																												IL_2756:
																												if (70 <= b)
																												{
																													goto IL_2761;
																												}
																												goto IL_27c8;
																												IL_2761:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_27a1;
																												IL_27a1:
																												array2[num6 - 2] = 3;
																												goto IL_27b5;
																												IL_27b5:
																												num6--;
																												break;
																												IL_27c8:
																												if (67 >= b)
																												{
																													goto IL_27d6;
																												}
																												goto IL_2858;
																												IL_27d6:
																												if (67 <= b)
																												{
																													goto IL_27e1;
																												}
																												goto IL_2823;
																												IL_27e1:
																												array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																												goto IL_280a;
																												IL_280a:
																												array2[num6 - 1] = 5;
																												break;
																												IL_2823:
																												if (66 < b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2831;
																												IL_2831:
																												if (66 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_283f;
																												IL_283f:
																												array2[num6 - 1] = 0;
																												goto IL_2bcb;
																												IL_2bcb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_2c0a;
																												IL_2c0a:
																												ptr2 += 8;
																												num = 10;
																												break;
																												IL_2858:
																												if (68 >= b)
																												{
																													goto IL_2863;
																												}
																												goto IL_28d7;
																												IL_2863:
																												if (68 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2871;
																												IL_2871:
																												array2[num6 - 1] = 3;
																												goto IL_2885;
																												IL_2885:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_28c4;
																												IL_28c4:
																												ptr2 += 8;
																												break;
																												IL_28d7:
																												if (69 < b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_28e5;
																												IL_28e5:
																												if (69 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2da6;
																												IL_2da6:
																												array2[num6 - 1] = 0;
																												num = 204;
																												goto IL_2dc3;
																												IL_2dc3:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_2e02;
																												IL_2e02:
																												ptr2 += 8;
																												break;
																												IL_28f8:
																												if (73 >= b)
																												{
																													goto IL_2903;
																												}
																												goto IL_2950;
																												IL_2903:
																												if (73 > b)
																												{
																													goto IL_2911;
																												}
																												goto IL_2fd0;
																												IL_2911:
																												if (71 >= b)
																												{
																													goto IL_291c;
																												}
																												goto IL_292f;
																												IL_291c:
																												if (71 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2a69;
																												IL_2a69:
																												array3[num6] = ((delegate*<NetworkSystem>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																												goto IL_2a87;
																												IL_2a87:
																												array2[num6] = 5;
																												goto IL_30c4;
																												IL_30c4:
																												num6++;
																												goto IL_30d2;
																												IL_30d2:
																												ptr2 += 8;
																												break;
																												IL_292f:
																												if (72 < b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_293d;
																												IL_293d:
																												if (72 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2c26;
																												IL_2c26:
																												array2[num6 - 1] = 5;
																												goto IL_2c3a;
																												IL_2c3a:
																												array3[num6 - 1] = ((delegate*<NetworkSystem, NetPlayer>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 1]);
																												goto IL_2c72;
																												IL_2c72:
																												ptr2 += 8;
																												break;
																												IL_2fd0:
																												array2[num6 - 2] = 0;
																												goto IL_2fe4;
																												IL_2fe4:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<GorillaGuardianManager, NetPlayer, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaGuardianManager)array3[num6 - 2], (NetPlayer)array3[num6 - 1]) ? 1 : 0);
																												num = 429;
																												goto IL_303f;
																												IL_303f:
																												num6--;
																												goto IL_304d;
																												IL_304d:
																												ptr2 += 8;
																												break;
																												IL_2950:
																												if (74 >= b)
																												{
																													goto IL_295e;
																												}
																												goto IL_29e6;
																												IL_295e:
																												if (74 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_296c;
																												IL_296c:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												num = 623;
																												goto IL_29d3;
																												IL_29d3:
																												num6--;
																												break;
																												IL_29e6:
																												if (75 < b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_29f4;
																												IL_29f4:
																												if (75 > b)
																												{
																													goto end_IL_0c39;
																												}
																												goto IL_2a02;
																												IL_2a02:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_2a42;
																												IL_2a42:
																												array2[num6 - 2] = 3;
																												goto IL_2a56;
																											}
																											break;
																										}
																										goto IL_0c7f;
																										IL_3060:
																										array2[num6 - 1] = 4;
																										goto IL_3074;
																										IL_0c7f:
																										if (65 > b)
																										{
																											goto IL_0e38;
																										}
																										goto IL_1fb0;
																										IL_0e38:
																										if (54 >= b)
																										{
																											num = 399;
																											goto IL_0e4f;
																										}
																										goto IL_1af5;
																										IL_3074:
																										array3[num6 - 1] = ((delegate*<Transform, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																										goto IL_30b1;
																										IL_0e4f:
																										if (54 > b)
																										{
																											goto IL_0e5d;
																										}
																										num = 91;
																										goto IL_0f88;
																										IL_0e5d:
																										if (48 >= b)
																										{
																											goto IL_0e68;
																										}
																										goto IL_0ede;
																										IL_0e68:
																										if (48 <= b)
																										{
																											goto IL_0e76;
																										}
																										goto IL_1e4f;
																										IL_0e76:
																										array2[num6 - 1] = 5;
																										goto IL_0e8a;
																										IL_0e8a:
																										array3[num6 - 1] = ((delegate*<string, GameObject>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																										goto IL_0ec2;
																										IL_0ec2:
																										ptr2 += 8;
																										num = 520;
																										break;
																										IL_1e4f:
																										if (45 >= b)
																										{
																											goto IL_1e5d;
																										}
																										goto IL_1f0d;
																										IL_1e5d:
																										if (45 <= b)
																										{
																											goto IL_1e68;
																										}
																										goto IL_1e8b;
																										IL_1e68:
																										array3[num6] = ((delegate*<GameObject>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																										goto IL_201b;
																										IL_201b:
																										array2[num6] = 5;
																										goto IL_2029;
																										IL_2029:
																										num6++;
																										goto IL_2037;
																										IL_2037:
																										ptr2 += 8;
																										break;
																										IL_1e8b:
																										if (44 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1e99;
																										IL_1e99:
																										if (44 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1ea7;
																										IL_1ea7:
																										array2[num6 - 1] = 3;
																										goto IL_1ebb;
																										IL_1ebb:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_1efa;
																										IL_1efa:
																										ptr2 += 8;
																										break;
																										IL_1f0d:
																										if (46 >= b)
																										{
																											goto IL_1f1b;
																										}
																										goto IL_2b1a;
																										IL_1f1b:
																										if (46 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1f29;
																										IL_1f29:
																										array2[num6 - 2] = 0;
																										goto IL_1f3d;
																										IL_1f3d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																										goto IL_1f8a;
																										IL_1f8a:
																										num6--;
																										goto IL_2ba5;
																										IL_2ba5:
																										ptr2 += 8;
																										break;
																										IL_2b1a:
																										if (47 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_2b28;
																										IL_2b28:
																										if (47 > b)
																										{
																											goto end_IL_0c39;
																										}
																										num = 431;
																										goto IL_2b3f;
																										IL_1fb0:
																										array2[num6 - 1] = 3;
																										goto IL_204a;
																										IL_2b3f:
																										array2[num6 - 1] = 3;
																										goto IL_2b53;
																										IL_2b53:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_2b92;
																										IL_2b92:
																										ptr2 += 8;
																										break;
																										IL_0ede:
																										if (51 >= b)
																										{
																											goto IL_0ee9;
																										}
																										goto IL_0efc;
																										IL_0ee9:
																										if (51 <= b)
																										{
																											goto IL_161f;
																										}
																										goto IL_1790;
																										IL_161f:
																										array2[num6 - 1] = 4;
																										goto IL_1633;
																										IL_1633:
																										array3[num6 - 1] = ((delegate*<ref Vector3, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)DispositionInternalParseTypeE[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																										goto IL_16a2;
																										IL_16a2:
																										ptr2 += 8;
																										break;
																										IL_1790:
																										if (49 < b)
																										{
																											goto IL_179b;
																										}
																										num = 152;
																										goto IL_1814;
																										IL_179b:
																										if (50 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_17a9;
																										IL_17a9:
																										if (50 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_17b7;
																										IL_17b7:
																										array2[num6] = 15;
																										goto IL_17c5;
																										IL_17c5:
																										array4[num6] = *(int*)(ptr2 + num3);
																										num = 398;
																										goto IL_17e1;
																										IL_17e1:
																										ptr2 += 8;
																										num = 359;
																										goto IL_17f8;
																										IL_17f8:
																										num6++;
																										break;
																										IL_204a:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_2089;
																										IL_1814:
																										if (49 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1a38;
																										IL_1a38:
																										global::_003CModule_003E.gameObject_24 = (GameObject)array3[num6 - 1];
																										goto IL_1a51;
																										IL_1a51:
																										num6--;
																										break;
																										IL_0efc:
																										if (52 >= b)
																										{
																											goto IL_0f07;
																										}
																										goto IL_0f5e;
																										IL_0f07:
																										if (52 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_0f15;
																										IL_0f15:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																										goto IL_0f2f;
																										IL_0f2f:
																										array2[num6] = 3;
																										goto IL_0f3d;
																										IL_0f3d:
																										num6++;
																										goto IL_0f4b;
																										IL_0f4b:
																										ptr2 += 8;
																										break;
																										IL_0f5e:
																										if (53 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_0f6c;
																										IL_0f6c:
																										if (53 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_117b;
																										IL_117b:
																										array2[num6 - 2] = 4;
																										goto IL_118f;
																										IL_118f:
																										array3[num6 - 2] = ((delegate*<Vector3, float, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																										goto IL_15eb;
																										IL_15eb:
																										num6--;
																										goto IL_1e3c;
																										IL_1e3c:
																										ptr2 += 8;
																										break;
																										IL_30b1:
																										ptr2 += 8;
																										break;
																										IL_0f88:
																										global::_003CModule_003E.vector3_113 = (Vector3)array3[num6 - 1];
																										goto IL_0fa1;
																										IL_0fa1:
																										num6--;
																										break;
																										IL_1af5:
																										if (59 < b)
																										{
																											goto IL_1b03;
																										}
																										goto IL_1c3e;
																										IL_1b03:
																										if (62 >= b)
																										{
																											goto IL_1b11;
																										}
																										goto IL_1bd8;
																										IL_1b11:
																										if (62 <= b)
																										{
																											goto IL_1b1c;
																										}
																										goto IL_1b82;
																										IL_1b1c:
																										array2[num6 - 1] = 3;
																										goto IL_1b30;
																										IL_1b30:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_1b6f;
																										IL_1b6f:
																										ptr2 += 8;
																										break;
																										IL_1b82:
																										if (60 < b)
																										{
																											goto IL_1b90;
																										}
																										goto IL_2eeb;
																										IL_1b90:
																										if (61 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1b9e;
																										IL_1b9e:
																										if (61 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1bac;
																										IL_1bac:
																										global::_003CModule_003E.vector3_112 = (Vector3)array3[num6 - 1];
																										goto IL_1bc5;
																										IL_1bc5:
																										num6--;
																										break;
																										IL_2eeb:
																										if (60 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_2ef9;
																										IL_2ef9:
																										array2[num6 - 2] = 4;
																										goto IL_2f0d;
																										IL_2f0d:
																										array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																										goto IL_2f5e;
																										IL_2f5e:
																										num6--;
																										goto IL_2f6c;
																										IL_2f6c:
																										ptr2 += 8;
																										break;
																										IL_1bd8:
																										if (63 >= b)
																										{
																											goto IL_1be3;
																										}
																										goto IL_1bf6;
																										IL_1be3:
																										if (63 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_25a5;
																										IL_25a5:
																										array2[num6 - 1] = 5;
																										goto IL_25b9;
																										IL_25b9:
																										array3[num6 - 1] = ((delegate*<GameObject, GorillaGuardianManager>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																										goto IL_25f1;
																										IL_25f1:
																										ptr2 += 8;
																										num = 628;
																										break;
																										IL_1bf6:
																										if (64 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1c04;
																										IL_1c04:
																										if (64 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1c12;
																										IL_1c12:
																										global::_003CModule_003E.gorillaGuardianManager_1 = (GorillaGuardianManager)array3[num6 - 1];
																										goto IL_1c2b;
																										IL_1c2b:
																										num6--;
																										break;
																										IL_1c3e:
																										if (59 > b)
																										{
																											goto IL_1c4c;
																										}
																										goto IL_3060;
																										IL_1c4c:
																										if (56 < b)
																										{
																											goto IL_1c5a;
																										}
																										num = 407;
																										goto IL_1d3a;
																										IL_1c5a:
																										if (57 >= b)
																										{
																											goto IL_1c65;
																										}
																										goto IL_1ca4;
																										IL_1c65:
																										if (57 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1c73;
																										IL_1c73:
																										array2[num6] = 5;
																										goto IL_1c81;
																										IL_1c81:
																										array3[num6] = ((delegate*<GorillaTagger>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																										goto IL_2584;
																										IL_2584:
																										num6++;
																										goto IL_2592;
																										IL_2592:
																										ptr2 += 8;
																										break;
																										IL_1ca4:
																										if (58 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1cb2;
																										IL_1cb2:
																										if (58 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1cc0;
																										IL_1cc0:
																										array3[num6 - 1] = ((delegate*<GorillaTagger, Transform>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																										goto IL_1cf8;
																										IL_1cf8:
																										array2[num6 - 1] = 5;
																										num = 190;
																										goto IL_1d15;
																										IL_1d15:
																										ptr2 += 8;
																										num = 353;
																										break;
																										IL_2089:
																										ptr2 += 8;
																										break;
																										IL_1d3a:
																										if (56 > b)
																										{
																											goto IL_1d45;
																										}
																										goto IL_1dc0;
																										IL_1d45:
																										if (55 < b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1d53;
																										IL_1d53:
																										if (55 > b)
																										{
																											goto end_IL_0c39;
																										}
																										goto IL_1d61;
																										IL_1d61:
																										array2[num6 - 1] = 5;
																										goto IL_1d75;
																										IL_1d75:
																										array3[num6 - 1] = ((delegate*<Component, Transform>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																										goto IL_1dad;
																										IL_1dad:
																										ptr2 += 8;
																										break;
																										IL_1dc0:
																										array2[num6 - 1] = 4;
																										goto IL_1dd4;
																										IL_1dd4:
																										array3[num6 - 1] = ((delegate*<Transform, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																										goto IL_2d1a;
																										IL_2d1a:
																										ptr2 += 8;
																										break;
																									}
																									break;
																								}
																								goto IL_0c92;
																								IL_18c4:
																								((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																								goto IL_18fd;
																								IL_0c92:
																								if (43 > b)
																								{
																									goto IL_0ca0;
																								}
																								num = 659;
																								goto IL_2482;
																								IL_0ca0:
																								if (21 >= b)
																								{
																									goto IL_0cae;
																								}
																								goto IL_0d4b;
																								IL_0cae:
																								if (21 > b)
																								{
																									goto IL_0cb9;
																								}
																								goto IL_0ce3;
																								IL_0cb9:
																								if (10 >= b)
																								{
																									goto IL_0cc7;
																								}
																								goto IL_209c;
																								IL_0cc7:
																								if (10 > b)
																								{
																									goto IL_12b3;
																								}
																								num = 636;
																								goto IL_1a80;
																								IL_2671:
																								array2[num6 - 4] = 0;
																								goto IL_2685;
																								IL_1a80:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1ae2;
																								IL_1ae2:
																								num6 -= 2;
																								break;
																								IL_12b3:
																								if (5 >= b)
																								{
																									goto IL_12c1;
																								}
																								goto IL_140d;
																								IL_12c1:
																								if (5 <= b)
																								{
																									goto IL_12cc;
																								}
																								goto IL_1311;
																								IL_12cc:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_153a;
																								IL_153a:
																								array2[num6 - 2] = 0;
																								goto IL_154e;
																								IL_154e:
																								num6--;
																								break;
																								IL_1311:
																								if (2 >= b)
																								{
																									goto IL_131f;
																								}
																								goto IL_13a3;
																								IL_131f:
																								if (2 > b)
																								{
																									goto IL_132d;
																								}
																								goto IL_16fd;
																								IL_132d:
																								if (1 < b)
																								{
																									goto end_IL_0c39;
																								}
																								num = 222;
																								goto IL_1344;
																								IL_2685:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, NetPlayer, object[], bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], (NetPlayer)array3[num6 - 2], (object[])array3[num6 - 1]) ? 1 : 0);
																								goto IL_26ff;
																								IL_1344:
																								if (1 > b)
																								{
																									goto end_IL_0c39;
																								}
																								num = 159;
																								goto IL_135b;
																								IL_26ff:
																								num6 -= 3;
																								goto IL_270d;
																								IL_135b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																								goto IL_1374;
																								IL_1374:
																								array2[num6] = 0;
																								goto IL_1382;
																								IL_1382:
																								num6++;
																								goto IL_1390;
																								IL_1390:
																								ptr2 += 8;
																								break;
																								IL_16fd:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 579;
																								goto IL_1746;
																								IL_1746:
																								array2[num6 - 2] = 0;
																								goto IL_2bb8;
																								IL_2bb8:
																								num6--;
																								break;
																								IL_13a3:
																								if (3 < b)
																								{
																									goto IL_13b1;
																								}
																								goto IL_2d2d;
																								IL_13b1:
																								if (4 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_13bf;
																								IL_13bf:
																								if (4 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_13cd;
																								IL_13cd:
																								array2[num6] = 0;
																								goto IL_13db;
																								IL_13db:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_13fe;
																								IL_13fe:
																								array3[num6] = null;
																								goto IL_15fe;
																								IL_15fe:
																								num6++;
																								goto IL_160c;
																								IL_160c:
																								ptr2 += 8;
																								break;
																								IL_2d2d:
																								if (3 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2d3b;
																								IL_2d3b:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_2d64;
																								IL_2d64:
																								ptr2 += 8;
																								goto IL_2d72;
																								IL_2d72:
																								num6--;
																								break;
																								IL_140d:
																								if (7 >= b)
																								{
																									goto IL_141b;
																								}
																								goto IL_1519;
																								IL_141b:
																								if (7 <= b)
																								{
																									goto IL_1426;
																								}
																								goto IL_1496;
																								IL_1426:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1466;
																								IL_1466:
																								array2[num6 - 2] = 0;
																								num = 543;
																								goto IL_1483;
																								IL_1483:
																								num6--;
																								break;
																								IL_1496:
																								if (6 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_14a4;
																								IL_14a4:
																								if (6 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_14b2;
																								IL_14b2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_14f2;
																								IL_14f2:
																								array2[num6 - 2] = 0;
																								goto IL_1506;
																								IL_1506:
																								num6--;
																								break;
																								IL_1519:
																								if (8 < b)
																								{
																									goto IL_1527;
																								}
																								goto IL_2d85;
																								IL_1527:
																								if (9 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_15d8;
																								IL_15d8:
																								if (9 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2a9a;
																								IL_2a9a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_2ada;
																								IL_2ada:
																								array2[num6 - 2] = 0;
																								goto IL_2aee;
																								IL_2aee:
																								num6--;
																								break;
																								IL_2d85:
																								if (8 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2d93;
																								IL_2d93:
																								num6--;
																								break;
																								IL_209c:
																								if (15 >= b)
																								{
																									goto IL_20aa;
																								}
																								goto IL_2306;
																								IL_20aa:
																								if (15 > b)
																								{
																									goto IL_20b8;
																								}
																								goto IL_2281;
																								IL_20b8:
																								if (12 >= b)
																								{
																									goto IL_20c6;
																								}
																								goto IL_21cd;
																								IL_20c6:
																								if (12 <= b)
																								{
																									goto IL_20d4;
																								}
																								goto IL_21ac;
																								IL_20d4:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_20e3;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_218b;
																								IL_270d:
																								ptr2 += 8;
																								break;
																								IL_18fd:
																								num6 -= 3;
																								break;
																								IL_2482:
																								array2[num6 - 2] = 0;
																								goto IL_2496;
																								IL_218b:
																								array2[num6] = 5;
																								goto IL_2199;
																								IL_2199:
																								num6++;
																								break;
																								IL_21ac:
																								if (11 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_21ba;
																								IL_21ba:
																								if (11 > b)
																								{
																									goto end_IL_0c39;
																								}
																								break;
																								IL_21cd:
																								if (13 >= b)
																								{
																									goto IL_21d8;
																								}
																								goto IL_2237;
																								IL_21d8:
																								if (13 > b)
																								{
																									goto end_IL_0c39;
																								}
																								num = 88;
																								goto IL_21ef;
																								IL_2496:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaGuardianManager)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																								goto IL_24e3;
																								IL_21ef:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_220d;
																								IL_220d:
																								ptr2 += 8;
																								goto IL_221b;
																								IL_221b:
																								num6--;
																								num = 395;
																								break;
																								IL_2237:
																								if (14 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2245;
																								IL_2245:
																								if (14 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2253;
																								IL_2253:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_2b01;
																								IL_2b01:
																								array2[num6 - 1] = 5;
																								break;
																								IL_2281:
																								array2[num6] = array2[num6 - 1];
																								goto IL_2299;
																								IL_2299:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_22b7;
																								IL_22b7:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_22db;
																								IL_22db:
																								array3[num6] = array3[num6 - 1];
																								goto IL_22f3;
																								IL_22f3:
																								num6++;
																								break;
																								IL_2306:
																								if (18 >= b)
																								{
																									goto IL_2314;
																								}
																								goto IL_2c85;
																								IL_2314:
																								if (18 > b)
																								{
																									goto IL_2322;
																								}
																								goto IL_23a3;
																								IL_2322:
																								if (16 >= b)
																								{
																									goto IL_232d;
																								}
																								goto IL_2382;
																								IL_232d:
																								if (16 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_233b;
																								IL_233b:
																								array2[num6] = 5;
																								goto IL_2349;
																								IL_2349:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_2361;
																								IL_2361:
																								num6++;
																								goto IL_236f;
																								IL_236f:
																								ptr2 += 8;
																								break;
																								IL_2382:
																								if (17 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2390;
																								IL_2390:
																								if (17 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2f7f;
																								IL_2f7f:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_2fbd;
																								IL_2fbd:
																								num6 -= 3;
																								break;
																								IL_23a3:
																								array2[num6 - 1] = 5;
																								goto IL_23b7;
																								IL_23b7:
																								array3[num6 - 1] = ((delegate*<string[], string>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								num = 421;
																								goto IL_23f8;
																								IL_23f8:
																								ptr2 += 8;
																								num = 383;
																								break;
																								IL_2c85:
																								if (19 >= b)
																								{
																									goto IL_2c90;
																								}
																								goto IL_2ce6;
																								IL_2c90:
																								if (19 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2c9e;
																								IL_2c9e:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_2cb7;
																								IL_2cb7:
																								array2[num6] = 1;
																								goto IL_2cc5;
																								IL_2cc5:
																								num6++;
																								goto IL_2cd3;
																								IL_2cd3:
																								ptr2 += 16;
																								break;
																								IL_2ce6:
																								if (20 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2cf4;
																								IL_2cf4:
																								if (20 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2d02;
																								IL_2d02:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0ce3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																								goto IL_0d24;
																								IL_0d24:
																								array2[num6 - 2] = 0;
																								goto IL_0d38;
																								IL_0d38:
																								num6--;
																								break;
																								IL_0d4b:
																								if (32 < b)
																								{
																									goto IL_0d59;
																								}
																								goto IL_11e6;
																								IL_0d59:
																								if (37 < b)
																								{
																									goto IL_0d67;
																								}
																								goto IL_1007;
																								IL_0d67:
																								if (40 >= b)
																								{
																									goto IL_0d72;
																								}
																								goto IL_0de2;
																								IL_0d72:
																								if (40 <= b)
																								{
																									goto IL_0d80;
																								}
																								goto IL_0fb4;
																								IL_0d80:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0dc0;
																								IL_0dc0:
																								array2[num6 - 2] = 3;
																								num = 641;
																								goto IL_1e16;
																								IL_1e16:
																								num6--;
																								break;
																								IL_0fb4:
																								if (38 >= b)
																								{
																									goto IL_0fbf;
																								}
																								goto IL_0fd2;
																								IL_0fbf:
																								if (38 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_175f;
																								IL_175f:
																								((delegate*<void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																								goto IL_1774;
																								IL_1774:
																								ptr2 += 8;
																								num = 411;
																								break;
																								IL_0fd2:
																								if (39 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_0fe0;
																								IL_0fe0:
																								if (39 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_0fee;
																								IL_0fee:
																								array2[num6 - 1] = 3;
																								goto IL_1561;
																								IL_1561:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 69;
																								goto IL_15a9;
																								IL_15a9:
																								ptr2 += 8;
																								break;
																								IL_0de2:
																								if (41 >= b)
																								{
																									goto IL_0ded;
																								}
																								goto IL_0e00;
																								IL_0ded:
																								if (41 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_16b5;
																								IL_16b5:
																								array3[num6] = ((delegate*<GorillaGuardianManager>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																								num = 139;
																								goto IL_16dc;
																								IL_16dc:
																								array2[num6] = 5;
																								goto IL_16ea;
																								IL_16ea:
																								num6++;
																								goto IL_19c8;
																								IL_19c8:
																								ptr2 += 8;
																								break;
																								IL_0e00:
																								if (42 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_0e0e;
																								IL_0e0e:
																								if (42 > b)
																								{
																									goto end_IL_0c39;
																								}
																								num = 550;
																								goto IL_10c5;
																								IL_24e3:
																								num6--;
																								goto IL_24f1;
																								IL_10c5:
																								array3[num6] = null;
																								goto IL_10cf;
																								IL_10cf:
																								array2[num6] = 5;
																								goto IL_10dd;
																								IL_10dd:
																								num6++;
																								break;
																								IL_1007:
																								if (37 > b)
																								{
																									goto IL_1015;
																								}
																								goto IL_1a1c;
																								IL_1015:
																								if (34 >= b)
																								{
																									goto IL_1020;
																								}
																								goto IL_1050;
																								IL_1020:
																								if (34 <= b)
																								{
																									goto IL_102e;
																								}
																								goto IL_260d;
																								IL_102e:
																								array2[num6 - 1] = 3;
																								num = 617;
																								goto IL_19db;
																								IL_19db:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1a64;
																								IL_1a64:
																								ptr2 += 8;
																								num = 549;
																								break;
																								IL_260d:
																								if (33 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_261b;
																								IL_261b:
																								if (33 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2629;
																								IL_2629:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																								goto IL_2642;
																								IL_2642:
																								array2[num6] = 3;
																								goto IL_2650;
																								IL_2650:
																								num6++;
																								goto IL_265e;
																								IL_265e:
																								ptr2 += 16;
																								break;
																								IL_1050:
																								if (35 >= b)
																								{
																									goto IL_105e;
																								}
																								goto IL_10f0;
																								IL_105e:
																								if (35 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_106c;
																								IL_106c:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_10ac;
																								IL_10ac:
																								array2[num6 - 2] = 3;
																								goto IL_1910;
																								IL_1910:
																								num6--;
																								break;
																								IL_10f0:
																								if (36 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_10fe;
																								IL_10fe:
																								if (36 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_110c;
																								IL_110c:
																								array2[num6 - 1] = 0;
																								goto IL_1120;
																								IL_1120:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 213;
																								goto IL_1168;
																								IL_1168:
																								ptr2 += 8;
																								break;
																								IL_1a1c:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								break;
																								IL_11e6:
																								if (32 > b)
																								{
																									goto IL_11f4;
																								}
																								goto IL_2671;
																								IL_11f4:
																								if (26 >= b)
																								{
																									goto IL_1202;
																								}
																								goto IL_1827;
																								IL_1202:
																								if (26 <= b)
																								{
																									goto IL_120d;
																								}
																								goto IL_125d;
																								IL_120d:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								num = 133;
																								goto IL_122e;
																								IL_122e:
																								array2[num6] = 5;
																								goto IL_123c;
																								IL_123c:
																								num6++;
																								goto IL_124a;
																								IL_124a:
																								ptr2 += 8;
																								break;
																								IL_125d:
																								if (23 >= b)
																								{
																									goto IL_126b;
																								}
																								goto IL_1944;
																								IL_126b:
																								if (23 <= b)
																								{
																									goto IL_1279;
																								}
																								goto IL_1923;
																								IL_1279:
																								array2[num6] = 5;
																								goto IL_1287;
																								IL_1287:
																								array3[num6] = ((delegate*<GorillaTagger>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																								num = 588;
																								goto IL_15bc;
																								IL_15bc:
																								num6++;
																								num = 642;
																								goto IL_1e29;
																								IL_1e29:
																								ptr2 += 8;
																								break;
																								IL_1923:
																								if (22 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_1931;
																								IL_1931:
																								if (22 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2414;
																								IL_2414:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_2466;
																								IL_2466:
																								num6--;
																								num = 85;
																								break;
																								IL_1944:
																								if (24 < b)
																								{
																									goto IL_1952;
																								}
																								goto IL_2504;
																								IL_1952:
																								if (25 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_1960;
																								IL_1960:
																								if (25 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_196e;
																								IL_196e:
																								array2[num6 - 1] = 5;
																								num = 209;
																								goto IL_198b;
																								IL_198b:
																								array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																								goto IL_2571;
																								IL_2571:
																								ptr2 += 8;
																								break;
																								IL_2504:
																								if (24 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2512;
																								IL_2512:
																								array2[num6 - 1] = 5;
																								goto IL_2526;
																								IL_2526:
																								array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																								goto IL_255e;
																								IL_255e:
																								ptr2 += 8;
																								break;
																								IL_1827:
																								if (29 >= b)
																								{
																									goto IL_1832;
																								}
																								goto IL_1845;
																								IL_1832:
																								if (29 <= b)
																								{
																									goto IL_1fc9;
																								}
																								goto IL_2e15;
																								IL_1fc9:
																								array3[num6] = ((delegate*<Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																								goto IL_1fec;
																								IL_1fec:
																								array2[num6] = 4;
																								goto IL_1ffa;
																								IL_1ffa:
																								num6++;
																								goto IL_2008;
																								IL_2008:
																								ptr2 += 8;
																								break;
																								IL_2e15:
																								if (27 >= b)
																								{
																									goto IL_2e20;
																								}
																								goto IL_2e8d;
																								IL_2e20:
																								if (27 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2e2e;
																								IL_2e2e:
																								array2[num6 - 1] = 5;
																								goto IL_2e42;
																								IL_2e42:
																								array3[num6 - 1] = ((delegate*<VRRig, NetPlayer>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																								goto IL_2e7a;
																								IL_2e7a:
																								ptr2 += 8;
																								break;
																								IL_2e8d:
																								if (28 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2e9b;
																								IL_2e9b:
																								if (28 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_2ea9;
																								IL_2ea9:
																								array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_2ed2;
																								IL_2ed2:
																								array2[num6 - 1] = 5;
																								break;
																								IL_1845:
																								if (30 >= b)
																								{
																									goto IL_1850;
																								}
																								goto IL_18a8;
																								IL_1850:
																								if (30 > b)
																								{
																									goto end_IL_0c39;
																								}
																								num = 97;
																								goto IL_1867;
																								IL_24f1:
																								ptr2 += 8;
																								break;
																								IL_1867:
																								array3[num6 - 1] = (Vector3)array3[num6 - 1];
																								goto IL_188f;
																								IL_188f:
																								array2[num6 - 1] = 5;
																								break;
																								IL_18a8:
																								if (31 < b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_18b6;
																								IL_18b6:
																								if (31 > b)
																								{
																									goto end_IL_0c39;
																								}
																								goto IL_18c4;
																							}
																							goto end_IL_0c49;
																							continue;
																							end_IL_0c39:
																							break;
																							IL_0c39:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					continue;
																					end_IL_0c49:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_356f:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_20e3:
			while (true)
			{
				IL_20e3_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_218b_2:
						array2[num6] = 5;
						while (true)
						{
							IL_2199_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_0c74_2:
									num = 257;
									while (true)
									{
										IL_0c69_2:
										byte b = *ptr2;
										while (true)
										{
											IL_0c59_2:
											ptr2++;
											while (true)
											{
												IL_0c49_2:
												if (b >= 1)
												{
													while (b <= 86)
													{
														while (true)
														{
															IL_0c2c_2:
															if (43 < b)
															{
																while (true)
																{
																	IL_0c1f_2:
																	if (65 < b)
																	{
																		while (true)
																		{
																			IL_0c0f_2:
																			if (76 < b)
																			{
																				while (true)
																				{
																					IL_0bff_2:
																					if (81 >= b)
																					{
																						while (true)
																						{
																							IL_0bef_2:
																							if (81 > b)
																							{
																								while (true)
																								{
																									IL_0bdf_2:
																									if (78 >= b)
																									{
																										while (true)
																										{
																											IL_0bcf_2:
																											if (78 <= b)
																											{
																												while (true)
																												{
																													IL_0bb0_2:
																													array2[num6 - 1] = 3;
																													num = 43;
																													while (true)
																													{
																														IL_0b6f_2:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														while (true)
																														{
																															IL_0b56_2:
																															ptr2 += 8;
																															num = 717;
																															while (num != 717)
																															{
																																if (num != 1698)
																																{
																																	goto end_IL_0c39_2;
																																}
																																switch (num)
																																{
																																case 132:
																																	goto IL_0b56_2;
																																case 43:
																																	goto IL_0b6f_2;
																																case 237:
																																case 430:
																																	goto IL_0bb0_2;
																																case 19:
																																	goto IL_0bcf_2;
																																case 578:
																																	goto IL_0bdf_2;
																																case 20:
																																	goto IL_0bef_2;
																																case 39:
																																	goto IL_0bff_2;
																																case 244:
																																	goto IL_0c0f_2;
																																case 202:
																																	goto IL_0c1f_2;
																																case 486:
																																	goto IL_0c2c_2;
																																case 624:
																																	goto IL_0c39_2;
																																case 176:
																																	goto IL_0c49_2;
																																case 304:
																																	goto IL_0c59_2;
																																case 257:
																																	goto IL_0c69_2;
																																case 323:
																																	goto IL_0c74_2;
																																case 198:
																																	goto IL_0c7f_2;
																																case 487:
																																	goto IL_0c92_2;
																																case 21:
																																	goto IL_0ca0_2;
																																case 12:
																																	goto IL_0cae_2;
																																case 172:
																																	goto IL_0cb9_2;
																																case 120:
																																	goto IL_0cc7_2;
																																case 254:
																																case 288:
																																	goto IL_0ce3_2;
																																case 321:
																																	goto IL_0d24_2;
																																case 315:
																																	goto IL_0d38_2;
																																case 51:
																																	goto IL_0d4b_2;
																																case 76:
																																	goto IL_0d59_2;
																																case 440:
																																	goto IL_0d67_2;
																																case 387:
																																	goto IL_0d72_2;
																																case 56:
																																case 258:
																																	goto IL_0d80_2;
																																case 16:
																																	goto IL_0dc0_2;
																																case 17:
																																	goto IL_0de2_2;
																																case 427:
																																	goto IL_0ded_2;
																																case 448:
																																	goto IL_0e00_2;
																																case 94:
																																	goto IL_0e0e_2;
																																case 504:
																																	goto IL_0e38_2;
																																case 399:
																																	goto IL_0e4f_2;
																																case 261:
																																	goto IL_0e5d_2;
																																case 54:
																																	goto IL_0e68_2;
																																case 284:
																																case 418:
																																	goto IL_0e76_2;
																																case 415:
																																	goto IL_0e8a_2;
																																case 285:
																																	goto IL_0ec2_2;
																																case 252:
																																	goto IL_0ede_2;
																																case 71:
																																	goto IL_0ee9_2;
																																case 64:
																																	goto IL_0efc_2;
																																case 197:
																																	goto IL_0f07_2;
																																case 82:
																																case 470:
																																	goto IL_0f15_2;
																																case 212:
																																	goto IL_0f2f_2;
																																case 346:
																																	goto IL_0f3d_2;
																																case 428:
																																	goto IL_0f4b_2;
																																case 290:
																																	goto IL_0f5e_2;
																																case 405:
																																	goto IL_0f6c_2;
																																case 91:
																																case 110:
																																	goto IL_0f88_2;
																																case 372:
																																	goto IL_0fa1_2;
																																case 510:
																																	goto IL_0fb4_2;
																																case 249:
																																	goto IL_0fbf_2;
																																case 81:
																																	goto IL_0fd2_2;
																																case 106:
																																	goto IL_0fe0_2;
																																case 226:
																																case 267:
																																	goto IL_0fee_2;
																																case 544:
																																	goto IL_1007_2;
																																case 298:
																																	goto IL_1015_2;
																																case 114:
																																	goto IL_1020_2;
																																case 62:
																																case 305:
																																	goto IL_102e_2;
																																case 279:
																																	goto IL_1050_2;
																																case 206:
																																	goto IL_105e_2;
																																case 115:
																																case 373:
																																	goto IL_106c_2;
																																case 434:
																																	goto IL_10ac_2;
																																case 426:
																																case 550:
																																	goto IL_10c5_2;
																																case 480:
																																	goto IL_10cf_2;
																																case 108:
																																	goto IL_10dd_2;
																																case 561:
																																	goto IL_10f0_2;
																																case 379:
																																	goto IL_10fe_2;
																																case 239:
																																case 283:
																																	goto IL_110c_2;
																																case 344:
																																	goto IL_1120_2;
																																case 213:
																																	goto IL_1168_2;
																																case 155:
																																case 565:
																																	goto IL_117b_2;
																																case 506:
																																	goto IL_118f_2;
																																case 567:
																																	goto IL_11e6_2;
																																case 468:
																																	goto IL_11f4_2;
																																case 526:
																																	goto IL_1202_2;
																																case 140:
																																case 532:
																																	goto IL_120d_2;
																																case 133:
																																	goto IL_122e_2;
																																case 40:
																																	goto IL_123c_2;
																																case 34:
																																	goto IL_124a_2;
																																case 462:
																																	goto IL_125d_2;
																																case 29:
																																	goto IL_126b_2;
																																case 286:
																																case 416:
																																	goto IL_1279_2;
																																case 241:
																																	goto IL_1287_2;
																																case 568:
																																	goto IL_12b3_2;
																																case 45:
																																	goto IL_12c1_2;
																																case 4:
																																case 534:
																																	goto IL_12cc_2;
																																case 134:
																																	goto IL_1311_2;
																																case 42:
																																	goto IL_131f_2;
																																case 406:
																																	goto IL_132d_2;
																																case 222:
																																	goto IL_1344_2;
																																case 49:
																																case 159:
																																	goto IL_135b_2;
																																case 375:
																																	goto IL_1374_2;
																																case 277:
																																	goto IL_1382_2;
																																case 147:
																																	goto IL_1390_2;
																																case 235:
																																	goto IL_13a3_2;
																																case 25:
																																	goto IL_13b1_2;
																																case 310:
																																	goto IL_13bf_2;
																																case 13:
																																case 439:
																																	goto IL_13cd_2;
																																case 75:
																																	goto IL_13db_2;
																																case 445:
																																	goto IL_13fe_2;
																																case 503:
																																	goto IL_140d_2;
																																case 295:
																																	goto IL_141b_2;
																																case 84:
																																case 341:
																																	goto IL_1426_2;
																																case 519:
																																	goto IL_1466_2;
																																case 543:
																																	goto IL_1483_2;
																																case 401:
																																	goto IL_1496_2;
																																case 87:
																																	goto IL_14a4_2;
																																case 104:
																																case 524:
																																	goto IL_14b2_2;
																																case 367:
																																	goto IL_14f2_2;
																																case 107:
																																	goto IL_1506_2;
																																case 374:
																																	goto IL_1519_2;
																																case 500:
																																	goto IL_1527_2;
																																case 572:
																																	goto IL_153a_2;
																																case 397:
																																	goto IL_154e_2;
																																case 582:
																																	goto IL_1561_2;
																																case 69:
																																	goto IL_15a9_2;
																																case 588:
																																	goto IL_15bc_2;
																																case 591:
																																	goto IL_15d8_2;
																																case 593:
																																	goto IL_15eb_2;
																																case 598:
																																	goto IL_15fe_2;
																																case 112:
																																	goto IL_160c_2;
																																case 393:
																																case 599:
																																	goto IL_161f_2;
																																case 566:
																																	goto IL_1633_2;
																																case 381:
																																	goto IL_16a2_2;
																																case 302:
																																case 601:
																																	goto IL_16b5_2;
																																case 139:
																																	goto IL_16dc_2;
																																case 121:
																																	goto IL_16ea_2;
																																case 364:
																																case 602:
																																	goto IL_16fd_2;
																																case 579:
																																	goto IL_1746_2;
																																case 368:
																																case 603:
																																	goto IL_175f_2;
																																case 24:
																																	goto IL_1774_2;
																																case 604:
																																	goto IL_1790_2;
																																case 535:
																																	goto IL_179b_2;
																																case 86:
																																	goto IL_17a9_2;
																																case 192:
																																case 342:
																																	goto IL_17b7_2;
																																case 580:
																																	goto IL_17c5_2;
																																case 398:
																																	goto IL_17e1_2;
																																case 359:
																																	goto IL_17f8_2;
																																case 152:
																																	goto IL_1814_2;
																																case 605:
																																	goto IL_1827_2;
																																case 463:
																																	goto IL_1832_2;
																																case 559:
																																	goto IL_1845_2;
																																case 539:
																																	goto IL_1850_2;
																																case 97:
																																case 537:
																																	goto IL_1867_2;
																																case 22:
																																	goto IL_188f_2;
																																case 394:
																																	goto IL_18a8_2;
																																case 2:
																																	goto IL_18b6_2;
																																case 113:
																																case 328:
																																	goto IL_18c4_2;
																																case 386:
																																	goto IL_18fd_2;
																																case 607:
																																	goto IL_1910_2;
																																case 609:
																																	goto IL_1923_2;
																																case 349:
																																	goto IL_1931_2;
																																case 610:
																																	goto IL_1944_2;
																																case 93:
																																	goto IL_1952_2;
																																case 264:
																																	goto IL_1960_2;
																																case 48:
																																case 171:
																																	goto IL_196e_2;
																																case 209:
																																	goto IL_198b_2;
																																case 613:
																																	goto IL_19c8_2;
																																case 617:
																																	goto IL_19db_2;
																																case 442:
																																case 618:
																																	goto IL_1a1c_2;
																																case 169:
																																case 619:
																																	goto IL_1a38_2;
																																case 590:
																																	goto IL_1a51_2;
																																case 634:
																																	goto IL_1a64_2;
																																case 308:
																																case 636:
																																	goto IL_1a80_2;
																																case 263:
																																	goto IL_1ae2_2;
																																case 638:
																																	goto IL_1af5_2;
																																case 492:
																																	goto IL_1b03_2;
																																case 178:
																																	goto IL_1b11_2;
																																case 322:
																																case 497:
																																	goto IL_1b1c_2;
																																case 181:
																																	goto IL_1b30_2;
																																case 456:
																																	goto IL_1b6f_2;
																																case 66:
																																	goto IL_1b82_2;
																																case 188:
																																	goto IL_1b90_2;
																																case 571:
																																	goto IL_1b9e_2;
																																case 59:
																																case 61:
																																	goto IL_1bac_2;
																																case 453:
																																	goto IL_1bc5_2;
																																case 166:
																																	goto IL_1bd8_2;
																																case 109:
																																	goto IL_1be3_2;
																																case 127:
																																	goto IL_1bf6_2;
																																case 248:
																																	goto IL_1c04_2;
																																case 269:
																																case 494:
																																	goto IL_1c12_2;
																																case 148:
																																	goto IL_1c2b_2;
																																case 569:
																																	goto IL_1c3e_2;
																																case 454:
																																	goto IL_1c4c_2;
																																case 331:
																																	goto IL_1c5a_2;
																																case 523:
																																	goto IL_1c65_2;
																																case 154:
																																case 256:
																																	goto IL_1c73_2;
																																case 435:
																																	goto IL_1c81_2;
																																case 490:
																																	goto IL_1ca4_2;
																																case 627:
																																	goto IL_1cb2_2;
																																case 217:
																																case 621:
																																	goto IL_1cc0_2;
																																case 528:
																																	goto IL_1cf8_2;
																																case 190:
																																	goto IL_1d15_2;
																																case 407:
																																	goto IL_1d3a_2;
																																case 77:
																																	goto IL_1d45_2;
																																case 551:
																																	goto IL_1d53_2;
																																case 32:
																																case 380:
																																	goto IL_1d61_2;
																																case 548:
																																	goto IL_1d75_2;
																																case 597:
																																	goto IL_1dad_2;
																																case 14:
																																case 495:
																																	goto IL_1dc0_2;
																																case 307:
																																	goto IL_1dd4_2;
																																case 641:
																																	goto IL_1e16_2;
																																case 642:
																																	goto IL_1e29_2;
																																case 643:
																																	goto IL_1e3c_2;
																																case 646:
																																	goto IL_1e4f_2;
																																case 420:
																																	goto IL_1e5d_2;
																																case 167:
																																case 282:
																																	goto IL_1e68_2;
																																case 129:
																																	goto IL_1e8b_2;
																																case 334:
																																	goto IL_1e99_2;
																																case 156:
																																case 251:
																																	goto IL_1ea7_2;
																																case 546:
																																	goto IL_1ebb_2;
																																case 265:
																																	goto IL_1efa_2;
																																case 314:
																																	goto IL_1f0d_2;
																																case 221:
																																	goto IL_1f1b_2;
																																case 220:
																																case 589:
																																	goto IL_1f29_2;
																																case 255:
																																	goto IL_1f3d_2;
																																case 502:
																																	goto IL_1f8a_2;
																																case 648:
																																	goto IL_1f9d_2;
																																case 293:
																																case 649:
																																	goto IL_1fb0_2;
																																case 441:
																																case 650:
																																	goto IL_1fc9_2;
																																case 455:
																																	goto IL_1fec_2;
																																case 124:
																																	goto IL_1ffa_2;
																																case 392:
																																	goto IL_2008_2;
																																case 651:
																																	goto IL_201b_2;
																																case 481:
																																	goto IL_2029_2;
																																case 450:
																																	goto IL_2037_2;
																																case 652:
																																	goto IL_204a_2;
																																case 356:
																																	goto IL_2089_2;
																																case 654:
																																	goto IL_209c_2;
																																case 488:
																																	goto IL_20aa_2;
																																case 348:
																																	goto IL_20b8_2;
																																case 573:
																																	goto IL_20c6_2;
																																case 37:
																																case 41:
																																	goto end_IL_356f_2;
																																case 271:
																																	goto IL_218b_2;
																																case 7:
																																	goto IL_2199_2;
																																case 324:
																																	goto IL_21ac_2;
																																case 433:
																																	goto IL_21ba_2;
																																case 137:
																																	goto IL_21cd_2;
																																case 158:
																																	goto IL_21d8_2;
																																case 88:
																																case 533:
																																	goto IL_21ef_2;
																																case 194:
																																	goto IL_220d_2;
																																case 318:
																																	goto IL_221b_2;
																																case 53:
																																	goto IL_2237_2;
																																case 632:
																																	goto IL_2245_2;
																																case 340:
																																case 389:
																																	goto IL_2253_2;
																																case 268:
																																case 542:
																																	goto IL_2281_2;
																																case 444:
																																	goto IL_2299_2;
																																case 419:
																																	goto IL_22b7_2;
																																case 547:
																																	goto IL_22db_2;
																																case 253:
																																	goto IL_22f3_2;
																																case 177:
																																	goto IL_2306_2;
																																case 414:
																																	goto IL_2314_2;
																																case 626:
																																	goto IL_2322_2;
																																case 417:
																																	goto IL_232d_2;
																																case 143:
																																case 243:
																																	goto IL_233b_2;
																																case 230:
																																	goto IL_2349_2;
																																case 596:
																																	goto IL_2361_2;
																																case 493:
																																	goto IL_236f_2;
																																case 653:
																																	goto IL_2382_2;
																																case 68:
																																	goto IL_2390_2;
																																case 50:
																																case 530:
																																	goto IL_23a3_2;
																																case 126:
																																	goto IL_23b7_2;
																																case 421:
																																	goto IL_23f8_2;
																																case 625:
																																case 656:
																																	goto IL_2414_2;
																																case 438:
																																	goto IL_2466_2;
																																case 496:
																																case 659:
																																	goto IL_2482_2;
																																case 141:
																																	goto IL_2496_2;
																																case 660:
																																	goto IL_24e3_2;
																																case 365:
																																	goto IL_24f1_2;
																																case 664:
																																	goto IL_2504_2;
																																case 44:
																																case 300:
																																	goto IL_2512_2;
																																case 211:
																																	goto IL_2526_2;
																																case 266:
																																	goto IL_255e_2;
																																case 668:
																																	goto IL_2571_2;
																																case 673:
																																	goto IL_2584_2;
																																case 540:
																																	goto IL_2592_2;
																																case 562:
																																case 674:
																																	goto IL_25a5_2;
																																case 80:
																																	goto IL_25b9_2;
																																case 193:
																																	goto IL_25f1_2;
																																case 675:
																																	goto IL_260d_2;
																																case 229:
																																	goto IL_261b_2;
																																case 413:
																																case 667:
																																	goto IL_2629_2;
																																case 122:
																																	goto IL_2642_2;
																																case 182:
																																	goto IL_2650_2;
																																case 184:
																																	goto IL_265e_2;
																																case 247:
																																case 678:
																																	goto IL_2671_2;
																																case 216:
																																	goto IL_2685_2;
																																case 335:
																																	goto IL_26ff_2;
																																case 240:
																																	goto IL_270d_2;
																																case 515:
																																case 679:
																																	goto IL_2720_2;
																																case 400:
																																	goto IL_2735_2;
																																case 682:
																																	goto IL_2748_2;
																																case 658:
																																	goto IL_2756_2;
																																case 70:
																																case 145:
																																	goto IL_2761_2;
																																case 576:
																																	goto IL_27a1_2;
																																case 507:
																																	goto IL_27b5_2;
																																case 187:
																																	goto IL_27c8_2;
																																case 563:
																																	goto IL_27d6_2;
																																case 327:
																																case 585:
																																	goto IL_27e1_2;
																																case 512:
																																	goto IL_280a_2;
																																case 153:
																																	goto IL_2823_2;
																																case 483:
																																	goto IL_2831_2;
																																case 238:
																																case 250:
																																	goto IL_283f_2;
																																case 207:
																																	goto IL_2858_2;
																																case 330:
																																	goto IL_2863_2;
																																case 117:
																																case 218:
																																	goto IL_2871_2;
																																case 234:
																																	goto IL_2885_2;
																																case 160:
																																	goto IL_28c4_2;
																																case 165:
																																	goto IL_28d7_2;
																																case 369:
																																	goto IL_28e5_2;
																																case 99:
																																	goto IL_28f8_2;
																																case 63:
																																	goto IL_2903_2;
																																case 358:
																																	goto IL_2911_2;
																																case 242:
																																	goto IL_291c_2;
																																case 58:
																																	goto IL_292f_2;
																																case 633:
																																	goto IL_293d_2;
																																case 479:
																																	goto IL_2950_2;
																																case 260:
																																	goto IL_295e_2;
																																case 489:
																																case 508:
																																	goto IL_296c_2;
																																case 623:
																																	goto IL_29d3_2;
																																case 73:
																																	goto IL_29e6_2;
																																case 541:
																																	goto IL_29f4_2;
																																case 289:
																																case 337:
																																	goto IL_2a02_2;
																																case 227:
																																	goto IL_2a42_2;
																																case 432:
																																	goto IL_2a56_2;
																																case 552:
																																case 683:
																																	goto IL_2a69_2;
																																case 622:
																																	goto IL_2a87_2;
																																case 676:
																																case 686:
																																	goto IL_2a9a_2;
																																case 28:
																																	goto IL_2ada_2;
																																case 26:
																																	goto IL_2aee_2;
																																case 691:
																																	goto IL_2b01_2;
																																case 692:
																																	goto IL_2b1a_2;
																																case 620:
																																	goto IL_2b28_2;
																																case 191:
																																case 431:
																																	goto IL_2b3f_2;
																																case 522:
																																	goto IL_2b53_2;
																																case 584:
																																	goto IL_2b92_2;
																																case 694:
																																	goto IL_2ba5_2;
																																case 696:
																																	goto IL_2bb8_2;
																																case 697:
																																	goto IL_2bcb_2;
																																case 499:
																																	goto IL_2c0a_2;
																																case 555:
																																case 698:
																																	goto IL_2c26_2;
																																case 273:
																																	goto IL_2c3a_2;
																																case 391:
																																	goto IL_2c72_2;
																																case 699:
																																	goto IL_2c85_2;
																																case 57:
																																	goto IL_2c90_2;
																																case 98:
																																case 309:
																																	goto IL_2c9e_2;
																																case 451:
																																	goto IL_2cb7_2;
																																case 196:
																																	goto IL_2cc5_2;
																																case 162:
																																	goto IL_2cd3_2;
																																case 200:
																																	goto IL_2ce6_2;
																																case 449:
																																	goto IL_2cf4_2;
																																case 6:
																																case 665:
																																	goto IL_2d02_2;
																																case 700:
																																	goto IL_2d1a_2;
																																case 701:
																																	goto IL_2d2d_2;
																																case 151:
																																case 640:
																																	goto IL_2d3b_2;
																																case 666:
																																	goto IL_2d64_2;
																																case 123:
																																	goto IL_2d72_2;
																																case 702:
																																	goto IL_2d85_2;
																																case 118:
																																case 685:
																																	goto IL_2d93_2;
																																case 228:
																																case 703:
																																	goto IL_2da6_2;
																																case 204:
																																	goto IL_2dc3_2;
																																case 437:
																																	goto IL_2e02_2;
																																case 704:
																																	goto IL_2e15_2;
																																case 142:
																																	goto IL_2e20_2;
																																case 31:
																																case 525:
																																	goto IL_2e2e_2;
																																case 631:
																																	goto IL_2e42_2;
																																case 409:
																																	goto IL_2e7a_2;
																																case 128:
																																	goto IL_2e8d_2;
																																case 360:
																																	goto IL_2e9b_2;
																																case 351:
																																case 357:
																																	goto IL_2ea9_2;
																																case 138:
																																	goto IL_2ed2_2;
																																case 706:
																																	goto IL_2eeb_2;
																																case 11:
																																case 232:
																																	goto IL_2ef9_2;
																																case 680:
																																	goto IL_2f0d_2;
																																case 316:
																																	goto IL_2f5e_2;
																																case 443:
																																	goto IL_2f6c_2;
																																case 236:
																																case 707:
																																	goto IL_2f7f_2;
																																case 333:
																																	goto IL_2fbd_2;
																																case 501:
																																case 708:
																																	goto IL_2fd0_2;
																																case 459:
																																	goto IL_2fe4_2;
																																case 429:
																																	goto IL_303f_2;
																																case 485:
																																	goto IL_304d_2;
																																case 385:
																																case 709:
																																	goto IL_3060_2;
																																case 475:
																																	goto IL_3074_2;
																																case 195:
																																	goto IL_30b1_2;
																																case 710:
																																	goto IL_30c4_2;
																																case 74:
																																	goto IL_30d2_2;
																																case 461:
																																	goto IL_30e5_2;
																																case 376:
																																	goto IL_30f3_2;
																																case 1:
																																case 111:
																																	goto IL_3101_2;
																																case 347:
																																	goto IL_3115_2;
																																case 513:
																																	goto IL_3154_2;
																																case 371:
																																	goto IL_3167_2;
																																case 355:
																																	goto IL_3172_2;
																																case 185:
																																case 616:
																																	goto IL_3180_2;
																																case 179:
																																	goto IL_318e_2;
																																case 205:
																																	goto IL_31a1_2;
																																case 681:
																																	goto IL_31af_2;
																																case 558:
																																	goto IL_31c2_2;
																																case 554:
																																	goto IL_31d0_2;
																																case 262:
																																case 655:
																																	goto IL_31de_2;
																																case 23:
																																	goto IL_3201_2;
																																case 471:
																																	goto IL_320f_2;
																																case 661:
																																	goto IL_321d_2;
																																case 116:
																																case 201:
																																	goto IL_3230_2;
																																case 614:
																																	goto IL_326e_2;
																																case 671:
																																	goto IL_3282_2;
																																case 5:
																																	goto IL_3295_2;
																																case 33:
																																	goto IL_32ac_2;
																																case 8:
																																case 199:
																																	goto IL_32ba_2;
																																case 0:
																																	goto IL_32ce_2;
																																case 556:
																																	goto IL_3322_2;
																																case 458:
																																	goto IL_3330_2;
																																case 329:
																																	goto IL_3343_2;
																																case 173:
																																	goto IL_3351_2;
																																case 296:
																																case 382:
																																	goto IL_335f_2;
																																case 693:
																																	goto IL_3373_2;
																																case 574:
																																	goto IL_33d0_2;
																																case 514:
																																	goto IL_33de_2;
																																case 390:
																																	goto IL_33f1_2;
																																case 629:
																																	goto IL_33ff_2;
																																case 287:
																																case 388:
																																	goto IL_340d_2;
																																case 611:
																																	goto IL_344b_2;
																																case 224:
																																	goto IL_345f_2;
																																case 672:
																																	goto IL_3472_2;
																																case 472:
																																	goto IL_3480_2;
																																case 103:
																																case 630:
																																	goto IL_348e_2;
																																case 150:
																																	goto IL_3528_2;
																																case 465:
																																	goto IL_3536_2;
																																case 170:
																																	goto IL_3546_2;
																																case 317:
																																	goto IL_3551_2;
																																case 9:
																																case 15:
																																case 27:
																																case 30:
																																case 46:
																																case 67:
																																case 72:
																																case 78:
																																case 89:
																																case 95:
																																case 96:
																																case 102:
																																case 125:
																																case 130:
																																case 131:
																																case 135:
																																case 136:
																																case 144:
																																case 157:
																																case 161:
																																case 174:
																																case 175:
																																case 180:
																																case 183:
																																case 186:
																																case 189:
																																case 214:
																																case 223:
																																case 231:
																																case 233:
																																case 245:
																																case 259:
																																case 272:
																																case 275:
																																case 276:
																																case 278:
																																case 281:
																																case 292:
																																case 294:
																																case 297:
																																case 299:
																																case 303:
																																case 325:
																																case 336:
																																case 339:
																																case 350:
																																case 352:
																																case 370:
																																case 378:
																																case 384:
																																case 396:
																																case 402:
																																case 403:
																																case 408:
																																case 412:
																																case 424:
																																case 425:
																																case 446:
																																case 447:
																																case 452:
																																case 460:
																																case 474:
																																case 476:
																																case 482:
																																case 491:
																																case 498:
																																case 518:
																																case 531:
																																case 538:
																																case 560:
																																case 570:
																																case 575:
																																case 577:
																																case 581:
																																case 586:
																																case 587:
																																case 592:
																																case 594:
																																case 595:
																																case 608:
																																case 615:
																																case 635:
																																case 647:
																																case 657:
																																case 663:
																																case 670:
																																case 687:
																																case 689:
																																case 705:
																																	goto end_IL_0c39_2;
																																case 3:
																																case 10:
																																case 18:
																																case 35:
																																case 36:
																																case 38:
																																case 55:
																																case 60:
																																case 65:
																																case 79:
																																case 85:
																																case 92:
																																case 100:
																																case 101:
																																case 105:
																																case 119:
																																case 146:
																																case 149:
																																case 163:
																																case 168:
																																case 203:
																																case 208:
																																case 210:
																																case 215:
																																case 219:
																																case 225:
																																case 274:
																																case 280:
																																case 291:
																																case 301:
																																case 306:
																																case 312:
																																case 313:
																																case 320:
																																case 326:
																																case 332:
																																case 338:
																																case 343:
																																case 345:
																																case 353:
																																case 354:
																																case 363:
																																case 366:
																																case 377:
																																case 383:
																																case 395:
																																case 411:
																																case 422:
																																case 423:
																																case 436:
																																case 457:
																																case 464:
																																case 466:
																																case 467:
																																case 469:
																																case 473:
																																case 477:
																																case 478:
																																case 484:
																																case 509:
																																case 511:
																																case 516:
																																case 517:
																																case 520:
																																case 521:
																																case 527:
																																case 529:
																																case 536:
																																case 545:
																																case 549:
																																case 553:
																																case 557:
																																case 564:
																																case 583:
																																case 600:
																																case 612:
																																case 628:
																																case 637:
																																case 639:
																																case 644:
																																case 645:
																																case 662:
																																case 669:
																																case 677:
																																case 684:
																																case 688:
																																case 690:
																																case 695:
																																	goto end_IL_0b43_2;
																																case 270:
																																	ptr2 = ptr;
																																	goto end_IL_0b43_2;
																																case 319:
																																	ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IWindowClassEntryConstructionResponse.MemberInfoSerializationHolderCustomErrorsEntry);
																																	goto case 270;
																																case 404:
																																	array7[0] = vrrig_0;
																																	goto case 319;
																																case 311:
																																	array7 = new object[29];
																																	num = 404;
																																	goto case 404;
																																case 606:
																																	array6 = new long[7];
																																	goto case 311;
																																case 83:
																																	array5 = new int[7];
																																	goto case 606;
																																case 47:
																																	array4 = new int[7];
																																	goto case 83;
																																case 52:
																																	array3 = new object[7];
																																	goto case 47;
																																case 410:
																																	array2 = new byte[7];
																																	goto case 52;
																																case 90:
																																	num4 = num2 * 8;
																																	goto case 410;
																																case 505:
																																	num3 = num2 * 4;
																																	goto case 90;
																																case 361:
																																	num2 = 1;
																																	goto case 505;
																																case 362:
																																	goto end_IL_20f1;
																																case 164:
																																case 246:
																																	return;
																																}
																																continue;
																																end_IL_0b43_2:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_30e5_2;
																											IL_3154_2:
																											ptr2 += 8;
																											break;
																											IL_30e5_2:
																											if (77 < b)
																											{
																												goto end_IL_0c39_2;
																											}
																											goto IL_30f3_2;
																											IL_30f3_2:
																											if (77 > b)
																											{
																												goto end_IL_0c39_2;
																											}
																											goto IL_3101_2;
																											IL_3101_2:
																											array2[num6 - 1] = 3;
																											goto IL_3115_2;
																											IL_3115_2:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_3154_2;
																										}
																										break;
																									}
																									goto IL_3167_2;
																									IL_321d_2:
																									ptr2 += 8;
																									break;
																									IL_3167_2:
																									if (79 >= b)
																									{
																										goto IL_3172_2;
																									}
																									goto IL_31c2_2;
																									IL_3172_2:
																									if (79 > b)
																									{
																										goto end_IL_0c39_2;
																									}
																									goto IL_3180_2;
																									IL_3180_2:
																									array2[num6] = 15;
																									goto IL_318e_2;
																									IL_318e_2:
																									array4[num6] = *(int*)(ptr2 + num3);
																									goto IL_31a1_2;
																									IL_31a1_2:
																									ptr2 += 8;
																									goto IL_31af_2;
																									IL_31af_2:
																									num6++;
																									break;
																									IL_31c2_2:
																									if (80 < b)
																									{
																										goto end_IL_0c39_2;
																									}
																									goto IL_31d0_2;
																									IL_31d0_2:
																									if (80 > b)
																									{
																										goto end_IL_0c39_2;
																									}
																									goto IL_31de_2;
																									IL_31de_2:
																									array3[num6] = ((delegate*<Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																									goto IL_3201_2;
																									IL_3201_2:
																									array2[num6] = 4;
																									goto IL_320f_2;
																									IL_320f_2:
																									num6++;
																									goto IL_321d_2;
																								}
																								break;
																							}
																							goto IL_3230_2;
																							IL_3282_2:
																							ptr2 += 8;
																							break;
																							IL_3230_2:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																							goto IL_326e_2;
																							IL_326e_2:
																							array2[num6 - 1] = 3;
																							goto IL_3282_2;
																						}
																						break;
																					}
																					goto IL_3295_2;
																					IL_3546_2:
																					if (86 < b)
																					{
																						goto end_IL_0c39_2;
																					}
																					goto IL_3551_2;
																					IL_3295_2:
																					if (84 >= b)
																					{
																						num = 33;
																						goto IL_32ac_2;
																					}
																					goto IL_3472_2;
																					IL_3551_2:
																					if (86 <= b)
																					{
																					}
																					goto end_IL_0c39_2;
																					IL_32ac_2:
																					if (84 <= b)
																					{
																						goto IL_32ba_2;
																					}
																					goto IL_3343_2;
																					IL_32ba_2:
																					array2[num6 - 2] = 3;
																					goto IL_32ce_2;
																					IL_32ce_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<float, float, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																					goto IL_3322_2;
																					IL_3322_2:
																					num6--;
																					goto IL_3330_2;
																					IL_3330_2:
																					ptr2 += 8;
																					break;
																					IL_3343_2:
																					if (82 >= b)
																					{
																						goto IL_3351_2;
																					}
																					goto IL_33f1_2;
																					IL_3351_2:
																					if (82 > b)
																					{
																						goto end_IL_0c39_2;
																					}
																					goto IL_335f_2;
																					IL_335f_2:
																					array2[num6 - 2] = 3;
																					goto IL_3373_2;
																					IL_3373_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<float, float, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																					num = 574;
																					goto IL_33d0_2;
																					IL_33d0_2:
																					num6--;
																					goto IL_33de_2;
																					IL_33de_2:
																					ptr2 += 8;
																					break;
																					IL_33f1_2:
																					if (83 < b)
																					{
																						goto end_IL_0c39_2;
																					}
																					goto IL_33ff_2;
																					IL_33ff_2:
																					if (83 > b)
																					{
																						goto end_IL_0c39_2;
																					}
																					goto IL_340d_2;
																					IL_340d_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, float>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																					goto IL_344b_2;
																					IL_344b_2:
																					array2[num6 - 1] = 3;
																					goto IL_345f_2;
																					IL_345f_2:
																					ptr2 += 8;
																					break;
																					IL_3472_2:
																					if (85 >= b)
																					{
																						goto IL_3480_2;
																					}
																					goto IL_3546_2;
																					IL_3480_2:
																					if (85 > b)
																					{
																						goto end_IL_0c39_2;
																					}
																					goto IL_348e_2;
																					IL_348e_2:
																					((delegate*<ref Vector3, float, float, float, void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)DispositionInternalParseTypeE[array4[num6 - 4]])(array3[num6 - 4], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), array7, array5), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																					goto IL_3528_2;
																					IL_3528_2:
																					num6 -= 4;
																					goto IL_3536_2;
																					IL_3536_2:
																					ptr2 += 8;
																					break;
																				}
																				break;
																			}
																			goto IL_1f9d_2;
																			IL_2a56_2:
																			num6--;
																			break;
																			IL_1f9d_2:
																			if (76 <= b)
																			{
																				goto IL_2720_2;
																			}
																			goto IL_2748_2;
																			IL_2720_2:
																			((delegate*<void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																			goto IL_2735_2;
																			IL_2735_2:
																			ptr2 += 8;
																			break;
																			IL_2748_2:
																			if (70 >= b)
																			{
																				goto IL_2756_2;
																			}
																			goto IL_28f8_2;
																			IL_2756_2:
																			if (70 <= b)
																			{
																				goto IL_2761_2;
																			}
																			goto IL_27c8_2;
																			IL_2761_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_27a1_2;
																			IL_27a1_2:
																			array2[num6 - 2] = 3;
																			goto IL_27b5_2;
																			IL_27b5_2:
																			num6--;
																			break;
																			IL_27c8_2:
																			if (67 >= b)
																			{
																				goto IL_27d6_2;
																			}
																			goto IL_2858_2;
																			IL_27d6_2:
																			if (67 <= b)
																			{
																				goto IL_27e1_2;
																			}
																			goto IL_2823_2;
																			IL_27e1_2:
																			array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																			goto IL_280a_2;
																			IL_280a_2:
																			array2[num6 - 1] = 5;
																			break;
																			IL_2823_2:
																			if (66 < b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2831_2;
																			IL_2831_2:
																			if (66 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_283f_2;
																			IL_283f_2:
																			array2[num6 - 1] = 0;
																			goto IL_2bcb_2;
																			IL_2bcb_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_2c0a_2;
																			IL_2c0a_2:
																			ptr2 += 8;
																			num = 10;
																			break;
																			IL_2858_2:
																			if (68 >= b)
																			{
																				goto IL_2863_2;
																			}
																			goto IL_28d7_2;
																			IL_2863_2:
																			if (68 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2871_2;
																			IL_2871_2:
																			array2[num6 - 1] = 3;
																			goto IL_2885_2;
																			IL_2885_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_28c4_2;
																			IL_28c4_2:
																			ptr2 += 8;
																			break;
																			IL_28d7_2:
																			if (69 < b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_28e5_2;
																			IL_28e5_2:
																			if (69 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2da6_2;
																			IL_2da6_2:
																			array2[num6 - 1] = 0;
																			num = 204;
																			goto IL_2dc3_2;
																			IL_2dc3_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_2e02_2;
																			IL_2e02_2:
																			ptr2 += 8;
																			break;
																			IL_28f8_2:
																			if (73 >= b)
																			{
																				goto IL_2903_2;
																			}
																			goto IL_2950_2;
																			IL_2903_2:
																			if (73 > b)
																			{
																				goto IL_2911_2;
																			}
																			goto IL_2fd0_2;
																			IL_2911_2:
																			if (71 >= b)
																			{
																				goto IL_291c_2;
																			}
																			goto IL_292f_2;
																			IL_291c_2:
																			if (71 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2a69_2;
																			IL_2a69_2:
																			array3[num6] = ((delegate*<NetworkSystem>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																			goto IL_2a87_2;
																			IL_2a87_2:
																			array2[num6] = 5;
																			goto IL_30c4_2;
																			IL_30c4_2:
																			num6++;
																			goto IL_30d2_2;
																			IL_30d2_2:
																			ptr2 += 8;
																			break;
																			IL_292f_2:
																			if (72 < b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_293d_2;
																			IL_293d_2:
																			if (72 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2c26_2;
																			IL_2c26_2:
																			array2[num6 - 1] = 5;
																			goto IL_2c3a_2;
																			IL_2c3a_2:
																			array3[num6 - 1] = ((delegate*<NetworkSystem, NetPlayer>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((NetworkSystem)array3[num6 - 1]);
																			goto IL_2c72_2;
																			IL_2c72_2:
																			ptr2 += 8;
																			break;
																			IL_2fd0_2:
																			array2[num6 - 2] = 0;
																			goto IL_2fe4_2;
																			IL_2fe4_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<GorillaGuardianManager, NetPlayer, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaGuardianManager)array3[num6 - 2], (NetPlayer)array3[num6 - 1]) ? 1 : 0);
																			num = 429;
																			goto IL_303f_2;
																			IL_303f_2:
																			num6--;
																			goto IL_304d_2;
																			IL_304d_2:
																			ptr2 += 8;
																			break;
																			IL_2950_2:
																			if (74 >= b)
																			{
																				goto IL_295e_2;
																			}
																			goto IL_29e6_2;
																			IL_295e_2:
																			if (74 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_296c_2;
																			IL_296c_2:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 623;
																			goto IL_29d3_2;
																			IL_29d3_2:
																			num6--;
																			break;
																			IL_29e6_2:
																			if (75 < b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_29f4_2;
																			IL_29f4_2:
																			if (75 > b)
																			{
																				goto end_IL_0c39_2;
																			}
																			goto IL_2a02_2;
																			IL_2a02_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_2a42_2;
																			IL_2a42_2:
																			array2[num6 - 2] = 3;
																			goto IL_2a56_2;
																		}
																		break;
																	}
																	goto IL_0c7f_2;
																	IL_3060_2:
																	array2[num6 - 1] = 4;
																	goto IL_3074_2;
																	IL_0c7f_2:
																	if (65 > b)
																	{
																		goto IL_0e38_2;
																	}
																	goto IL_1fb0_2;
																	IL_0e38_2:
																	if (54 >= b)
																	{
																		num = 399;
																		goto IL_0e4f_2;
																	}
																	goto IL_1af5_2;
																	IL_3074_2:
																	array3[num6 - 1] = ((delegate*<Transform, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																	goto IL_30b1_2;
																	IL_0e4f_2:
																	if (54 > b)
																	{
																		goto IL_0e5d_2;
																	}
																	num = 91;
																	goto IL_0f88_2;
																	IL_0e5d_2:
																	if (48 >= b)
																	{
																		goto IL_0e68_2;
																	}
																	goto IL_0ede_2;
																	IL_0e68_2:
																	if (48 <= b)
																	{
																		goto IL_0e76_2;
																	}
																	goto IL_1e4f_2;
																	IL_0e76_2:
																	array2[num6 - 1] = 5;
																	goto IL_0e8a_2;
																	IL_0e8a_2:
																	array3[num6 - 1] = ((delegate*<string, GameObject>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																	goto IL_0ec2_2;
																	IL_0ec2_2:
																	ptr2 += 8;
																	num = 520;
																	break;
																	IL_1e4f_2:
																	if (45 >= b)
																	{
																		goto IL_1e5d_2;
																	}
																	goto IL_1f0d_2;
																	IL_1e5d_2:
																	if (45 <= b)
																	{
																		goto IL_1e68_2;
																	}
																	goto IL_1e8b_2;
																	IL_1e68_2:
																	array3[num6] = ((delegate*<GameObject>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																	goto IL_201b_2;
																	IL_201b_2:
																	array2[num6] = 5;
																	goto IL_2029_2;
																	IL_2029_2:
																	num6++;
																	goto IL_2037_2;
																	IL_2037_2:
																	ptr2 += 8;
																	break;
																	IL_1e8b_2:
																	if (44 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1e99_2;
																	IL_1e99_2:
																	if (44 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1ea7_2;
																	IL_1ea7_2:
																	array2[num6 - 1] = 3;
																	goto IL_1ebb_2;
																	IL_1ebb_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1efa_2;
																	IL_1efa_2:
																	ptr2 += 8;
																	break;
																	IL_1f0d_2:
																	if (46 >= b)
																	{
																		goto IL_1f1b_2;
																	}
																	goto IL_2b1a_2;
																	IL_1f1b_2:
																	if (46 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1f29_2;
																	IL_1f29_2:
																	array2[num6 - 2] = 0;
																	goto IL_1f3d_2;
																	IL_1f3d_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																	goto IL_1f8a_2;
																	IL_1f8a_2:
																	num6--;
																	goto IL_2ba5_2;
																	IL_2ba5_2:
																	ptr2 += 8;
																	break;
																	IL_2b1a_2:
																	if (47 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_2b28_2;
																	IL_2b28_2:
																	if (47 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	num = 431;
																	goto IL_2b3f_2;
																	IL_1fb0_2:
																	array2[num6 - 1] = 3;
																	goto IL_204a_2;
																	IL_2b3f_2:
																	array2[num6 - 1] = 3;
																	goto IL_2b53_2;
																	IL_2b53_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_2b92_2;
																	IL_2b92_2:
																	ptr2 += 8;
																	break;
																	IL_0ede_2:
																	if (51 >= b)
																	{
																		goto IL_0ee9_2;
																	}
																	goto IL_0efc_2;
																	IL_0ee9_2:
																	if (51 <= b)
																	{
																		goto IL_161f_2;
																	}
																	goto IL_1790_2;
																	IL_161f_2:
																	array2[num6 - 1] = 4;
																	goto IL_1633_2;
																	IL_1633_2:
																	array3[num6 - 1] = ((delegate*<ref Vector3, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)DispositionInternalParseTypeE[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																	goto IL_16a2_2;
																	IL_16a2_2:
																	ptr2 += 8;
																	break;
																	IL_1790_2:
																	if (49 < b)
																	{
																		goto IL_179b_2;
																	}
																	num = 152;
																	goto IL_1814_2;
																	IL_179b_2:
																	if (50 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_17a9_2;
																	IL_17a9_2:
																	if (50 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_17b7_2;
																	IL_17b7_2:
																	array2[num6] = 15;
																	goto IL_17c5_2;
																	IL_17c5_2:
																	array4[num6] = *(int*)(ptr2 + num3);
																	num = 398;
																	goto IL_17e1_2;
																	IL_17e1_2:
																	ptr2 += 8;
																	num = 359;
																	goto IL_17f8_2;
																	IL_17f8_2:
																	num6++;
																	break;
																	IL_204a_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_2089_2;
																	IL_1814_2:
																	if (49 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1a38_2;
																	IL_1a38_2:
																	global::_003CModule_003E.gameObject_24 = (GameObject)array3[num6 - 1];
																	goto IL_1a51_2;
																	IL_1a51_2:
																	num6--;
																	break;
																	IL_0efc_2:
																	if (52 >= b)
																	{
																		goto IL_0f07_2;
																	}
																	goto IL_0f5e_2;
																	IL_0f07_2:
																	if (52 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_0f15_2;
																	IL_0f15_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																	goto IL_0f2f_2;
																	IL_0f2f_2:
																	array2[num6] = 3;
																	goto IL_0f3d_2;
																	IL_0f3d_2:
																	num6++;
																	goto IL_0f4b_2;
																	IL_0f4b_2:
																	ptr2 += 8;
																	break;
																	IL_0f5e_2:
																	if (53 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_0f6c_2;
																	IL_0f6c_2:
																	if (53 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_117b_2;
																	IL_117b_2:
																	array2[num6 - 2] = 4;
																	goto IL_118f_2;
																	IL_118f_2:
																	array3[num6 - 2] = ((delegate*<Vector3, float, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																	goto IL_15eb_2;
																	IL_15eb_2:
																	num6--;
																	goto IL_1e3c_2;
																	IL_1e3c_2:
																	ptr2 += 8;
																	break;
																	IL_30b1_2:
																	ptr2 += 8;
																	break;
																	IL_0f88_2:
																	global::_003CModule_003E.vector3_113 = (Vector3)array3[num6 - 1];
																	goto IL_0fa1_2;
																	IL_0fa1_2:
																	num6--;
																	break;
																	IL_1af5_2:
																	if (59 < b)
																	{
																		goto IL_1b03_2;
																	}
																	goto IL_1c3e_2;
																	IL_1b03_2:
																	if (62 >= b)
																	{
																		goto IL_1b11_2;
																	}
																	goto IL_1bd8_2;
																	IL_1b11_2:
																	if (62 <= b)
																	{
																		goto IL_1b1c_2;
																	}
																	goto IL_1b82_2;
																	IL_1b1c_2:
																	array2[num6 - 1] = 3;
																	goto IL_1b30_2;
																	IL_1b30_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1b6f_2;
																	IL_1b6f_2:
																	ptr2 += 8;
																	break;
																	IL_1b82_2:
																	if (60 < b)
																	{
																		goto IL_1b90_2;
																	}
																	goto IL_2eeb_2;
																	IL_1b90_2:
																	if (61 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1b9e_2;
																	IL_1b9e_2:
																	if (61 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1bac_2;
																	IL_1bac_2:
																	global::_003CModule_003E.vector3_112 = (Vector3)array3[num6 - 1];
																	goto IL_1bc5_2;
																	IL_1bc5_2:
																	num6--;
																	break;
																	IL_2eeb_2:
																	if (60 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_2ef9_2;
																	IL_2ef9_2:
																	array2[num6 - 2] = 4;
																	goto IL_2f0d_2;
																	IL_2f0d_2:
																	array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																	goto IL_2f5e_2;
																	IL_2f5e_2:
																	num6--;
																	goto IL_2f6c_2;
																	IL_2f6c_2:
																	ptr2 += 8;
																	break;
																	IL_1bd8_2:
																	if (63 >= b)
																	{
																		goto IL_1be3_2;
																	}
																	goto IL_1bf6_2;
																	IL_1be3_2:
																	if (63 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_25a5_2;
																	IL_25a5_2:
																	array2[num6 - 1] = 5;
																	goto IL_25b9_2;
																	IL_25b9_2:
																	array3[num6 - 1] = ((delegate*<GameObject, GorillaGuardianManager>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 1]);
																	goto IL_25f1_2;
																	IL_25f1_2:
																	ptr2 += 8;
																	num = 628;
																	break;
																	IL_1bf6_2:
																	if (64 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1c04_2;
																	IL_1c04_2:
																	if (64 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1c12_2;
																	IL_1c12_2:
																	global::_003CModule_003E.gorillaGuardianManager_1 = (GorillaGuardianManager)array3[num6 - 1];
																	goto IL_1c2b_2;
																	IL_1c2b_2:
																	num6--;
																	break;
																	IL_1c3e_2:
																	if (59 > b)
																	{
																		goto IL_1c4c_2;
																	}
																	goto IL_3060_2;
																	IL_1c4c_2:
																	if (56 < b)
																	{
																		goto IL_1c5a_2;
																	}
																	num = 407;
																	goto IL_1d3a_2;
																	IL_1c5a_2:
																	if (57 >= b)
																	{
																		goto IL_1c65_2;
																	}
																	goto IL_1ca4_2;
																	IL_1c65_2:
																	if (57 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1c73_2;
																	IL_1c73_2:
																	array2[num6] = 5;
																	goto IL_1c81_2;
																	IL_1c81_2:
																	array3[num6] = ((delegate*<GorillaTagger>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
																	goto IL_2584_2;
																	IL_2584_2:
																	num6++;
																	goto IL_2592_2;
																	IL_2592_2:
																	ptr2 += 8;
																	break;
																	IL_1ca4_2:
																	if (58 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1cb2_2;
																	IL_1cb2_2:
																	if (58 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1cc0_2;
																	IL_1cc0_2:
																	array3[num6 - 1] = ((delegate*<GorillaTagger, Transform>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																	goto IL_1cf8_2;
																	IL_1cf8_2:
																	array2[num6 - 1] = 5;
																	num = 190;
																	goto IL_1d15_2;
																	IL_1d15_2:
																	ptr2 += 8;
																	num = 353;
																	break;
																	IL_2089_2:
																	ptr2 += 8;
																	break;
																	IL_1d3a_2:
																	if (56 > b)
																	{
																		goto IL_1d45_2;
																	}
																	goto IL_1dc0_2;
																	IL_1d45_2:
																	if (55 < b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1d53_2;
																	IL_1d53_2:
																	if (55 > b)
																	{
																		goto end_IL_0c39_2;
																	}
																	goto IL_1d61_2;
																	IL_1d61_2:
																	array2[num6 - 1] = 5;
																	goto IL_1d75_2;
																	IL_1d75_2:
																	array3[num6 - 1] = ((delegate*<Component, Transform>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																	goto IL_1dad_2;
																	IL_1dad_2:
																	ptr2 += 8;
																	break;
																	IL_1dc0_2:
																	array2[num6 - 1] = 4;
																	goto IL_1dd4_2;
																	IL_1dd4_2:
																	array3[num6 - 1] = ((delegate*<Transform, Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																	goto IL_2d1a_2;
																	IL_2d1a_2:
																	ptr2 += 8;
																	break;
																}
																break;
															}
															goto IL_0c92_2;
															IL_2685_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, NetPlayer, object[], bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], (NetPlayer)array3[num6 - 2], (object[])array3[num6 - 1]) ? 1 : 0);
															goto IL_26ff_2;
															IL_0c92_2:
															if (43 > b)
															{
																goto IL_0ca0_2;
															}
															num = 659;
															goto IL_2482_2;
															IL_0ca0_2:
															if (21 >= b)
															{
																goto IL_0cae_2;
															}
															goto IL_0d4b_2;
															IL_0cae_2:
															if (21 > b)
															{
																goto IL_0cb9_2;
															}
															goto IL_0ce3_2;
															IL_0cb9_2:
															if (10 >= b)
															{
																goto IL_0cc7_2;
															}
															goto IL_209c_2;
															IL_0cc7_2:
															if (10 > b)
															{
																goto IL_12b3_2;
															}
															num = 636;
															goto IL_1a80_2;
															IL_270d_2:
															ptr2 += 8;
															break;
															IL_1a80_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_1ae2_2;
															IL_1ae2_2:
															num6 -= 2;
															break;
															IL_12b3_2:
															if (5 >= b)
															{
																goto IL_12c1_2;
															}
															goto IL_140d_2;
															IL_12c1_2:
															if (5 <= b)
															{
																goto IL_12cc_2;
															}
															goto IL_1311_2;
															IL_12cc_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_153a_2;
															IL_153a_2:
															array2[num6 - 2] = 0;
															goto IL_154e_2;
															IL_154e_2:
															num6--;
															break;
															IL_1311_2:
															if (2 >= b)
															{
																goto IL_131f_2;
															}
															goto IL_13a3_2;
															IL_131f_2:
															if (2 > b)
															{
																goto IL_132d_2;
															}
															goto IL_16fd_2;
															IL_132d_2:
															if (1 < b)
															{
																goto end_IL_0c39_2;
															}
															num = 222;
															goto IL_1344_2;
															IL_26ff_2:
															num6 -= 3;
															goto IL_270d_2;
															IL_1344_2:
															if (1 > b)
															{
																goto end_IL_0c39_2;
															}
															num = 159;
															goto IL_135b_2;
															IL_2482_2:
															array2[num6 - 2] = 0;
															goto IL_2496_2;
															IL_135b_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_1374_2;
															IL_1374_2:
															array2[num6] = 0;
															goto IL_1382_2;
															IL_1382_2:
															num6++;
															goto IL_1390_2;
															IL_1390_2:
															ptr2 += 8;
															break;
															IL_16fd_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 579;
															goto IL_1746_2;
															IL_1746_2:
															array2[num6 - 2] = 0;
															goto IL_2bb8_2;
															IL_2bb8_2:
															num6--;
															break;
															IL_13a3_2:
															if (3 < b)
															{
																goto IL_13b1_2;
															}
															goto IL_2d2d_2;
															IL_13b1_2:
															if (4 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_13bf_2;
															IL_13bf_2:
															if (4 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_13cd_2;
															IL_13cd_2:
															array2[num6] = 0;
															goto IL_13db_2;
															IL_13db_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_13fe_2;
															IL_13fe_2:
															array3[num6] = null;
															goto IL_15fe_2;
															IL_15fe_2:
															num6++;
															goto IL_160c_2;
															IL_160c_2:
															ptr2 += 8;
															break;
															IL_2d2d_2:
															if (3 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2d3b_2;
															IL_2d3b_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_2d64_2;
															IL_2d64_2:
															ptr2 += 8;
															goto IL_2d72_2;
															IL_2d72_2:
															num6--;
															break;
															IL_140d_2:
															if (7 >= b)
															{
																goto IL_141b_2;
															}
															goto IL_1519_2;
															IL_141b_2:
															if (7 <= b)
															{
																goto IL_1426_2;
															}
															goto IL_1496_2;
															IL_1426_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1466_2;
															IL_1466_2:
															array2[num6 - 2] = 0;
															num = 543;
															goto IL_1483_2;
															IL_1483_2:
															num6--;
															break;
															IL_1496_2:
															if (6 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_14a4_2;
															IL_14a4_2:
															if (6 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_14b2_2;
															IL_14b2_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_14f2_2;
															IL_14f2_2:
															array2[num6 - 2] = 0;
															goto IL_1506_2;
															IL_1506_2:
															num6--;
															break;
															IL_1519_2:
															if (8 < b)
															{
																goto IL_1527_2;
															}
															goto IL_2d85_2;
															IL_1527_2:
															if (9 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_15d8_2;
															IL_15d8_2:
															if (9 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2a9a_2;
															IL_2a9a_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_2ada_2;
															IL_2ada_2:
															array2[num6 - 2] = 0;
															goto IL_2aee_2;
															IL_2aee_2:
															num6--;
															break;
															IL_2d85_2:
															if (8 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2d93_2;
															IL_2d93_2:
															num6--;
															break;
															IL_209c_2:
															if (15 >= b)
															{
																goto IL_20aa_2;
															}
															goto IL_2306_2;
															IL_20aa_2:
															if (15 > b)
															{
																goto IL_20b8_2;
															}
															goto IL_2281_2;
															IL_20b8_2:
															if (12 >= b)
															{
																goto IL_20c6_2;
															}
															goto IL_21cd_2;
															IL_20c6_2:
															if (12 <= b)
															{
																goto end_IL_356f_2;
															}
															goto IL_21ac_2;
															IL_21ac_2:
															if (11 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_21ba_2;
															IL_21ba_2:
															if (11 > b)
															{
																goto end_IL_0c39_2;
															}
															break;
															IL_21cd_2:
															if (13 >= b)
															{
																goto IL_21d8_2;
															}
															goto IL_2237_2;
															IL_21d8_2:
															if (13 > b)
															{
																goto end_IL_0c39_2;
															}
															num = 88;
															goto IL_21ef_2;
															IL_2496_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaGuardianManager)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
															goto IL_24e3_2;
															IL_21ef_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_220d_2;
															IL_220d_2:
															ptr2 += 8;
															goto IL_221b_2;
															IL_221b_2:
															num6--;
															num = 395;
															break;
															IL_2237_2:
															if (14 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2245_2;
															IL_2245_2:
															if (14 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2253_2;
															IL_2253_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_2b01_2;
															IL_2b01_2:
															array2[num6 - 1] = 5;
															break;
															IL_2281_2:
															array2[num6] = array2[num6 - 1];
															goto IL_2299_2;
															IL_2299_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_22b7_2;
															IL_22b7_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_22db_2;
															IL_22db_2:
															array3[num6] = array3[num6 - 1];
															goto IL_22f3_2;
															IL_22f3_2:
															num6++;
															break;
															IL_2306_2:
															if (18 >= b)
															{
																goto IL_2314_2;
															}
															goto IL_2c85_2;
															IL_2314_2:
															if (18 > b)
															{
																goto IL_2322_2;
															}
															goto IL_23a3_2;
															IL_2322_2:
															if (16 >= b)
															{
																goto IL_232d_2;
															}
															goto IL_2382_2;
															IL_232d_2:
															if (16 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_233b_2;
															IL_233b_2:
															array2[num6] = 5;
															goto IL_2349_2;
															IL_2349_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_2361_2;
															IL_2361_2:
															num6++;
															goto IL_236f_2;
															IL_236f_2:
															ptr2 += 8;
															break;
															IL_2382_2:
															if (17 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2390_2;
															IL_2390_2:
															if (17 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2f7f_2;
															IL_2f7f_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_2fbd_2;
															IL_2fbd_2:
															num6 -= 3;
															break;
															IL_23a3_2:
															array2[num6 - 1] = 5;
															goto IL_23b7_2;
															IL_23b7_2:
															array3[num6 - 1] = ((delegate*<string[], string>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															num = 421;
															goto IL_23f8_2;
															IL_23f8_2:
															ptr2 += 8;
															num = 383;
															break;
															IL_2c85_2:
															if (19 >= b)
															{
																goto IL_2c90_2;
															}
															goto IL_2ce6_2;
															IL_2c90_2:
															if (19 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2c9e_2;
															IL_2c9e_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_2cb7_2;
															IL_2cb7_2:
															array2[num6] = 1;
															goto IL_2cc5_2;
															IL_2cc5_2:
															num6++;
															goto IL_2cd3_2;
															IL_2cd3_2:
															ptr2 += 16;
															break;
															IL_2ce6_2:
															if (20 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2cf4_2;
															IL_2cf4_2:
															if (20 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2d02_2;
															IL_2d02_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															IL_0ce3_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_0d24_2;
															IL_0d24_2:
															array2[num6 - 2] = 0;
															goto IL_0d38_2;
															IL_0d38_2:
															num6--;
															break;
															IL_0d4b_2:
															if (32 < b)
															{
																goto IL_0d59_2;
															}
															goto IL_11e6_2;
															IL_0d59_2:
															if (37 < b)
															{
																goto IL_0d67_2;
															}
															goto IL_1007_2;
															IL_0d67_2:
															if (40 >= b)
															{
																goto IL_0d72_2;
															}
															goto IL_0de2_2;
															IL_0d72_2:
															if (40 <= b)
															{
																goto IL_0d80_2;
															}
															goto IL_0fb4_2;
															IL_0d80_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0dc0_2;
															IL_0dc0_2:
															array2[num6 - 2] = 3;
															num = 641;
															goto IL_1e16_2;
															IL_1e16_2:
															num6--;
															break;
															IL_0fb4_2:
															if (38 >= b)
															{
																goto IL_0fbf_2;
															}
															goto IL_0fd2_2;
															IL_0fbf_2:
															if (38 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_175f_2;
															IL_175f_2:
															((delegate*<void>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
															goto IL_1774_2;
															IL_1774_2:
															ptr2 += 8;
															num = 411;
															break;
															IL_0fd2_2:
															if (39 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_0fe0_2;
															IL_0fe0_2:
															if (39 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_0fee_2;
															IL_0fee_2:
															array2[num6 - 1] = 3;
															goto IL_1561_2;
															IL_1561_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 69;
															goto IL_15a9_2;
															IL_15a9_2:
															ptr2 += 8;
															break;
															IL_0de2_2:
															if (41 >= b)
															{
																goto IL_0ded_2;
															}
															goto IL_0e00_2;
															IL_0ded_2:
															if (41 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_16b5_2;
															IL_16b5_2:
															array3[num6] = ((delegate*<GorillaGuardianManager>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
															num = 139;
															goto IL_16dc_2;
															IL_16dc_2:
															array2[num6] = 5;
															goto IL_16ea_2;
															IL_16ea_2:
															num6++;
															goto IL_19c8_2;
															IL_19c8_2:
															ptr2 += 8;
															break;
															IL_0e00_2:
															if (42 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_0e0e_2;
															IL_0e0e_2:
															if (42 > b)
															{
																goto end_IL_0c39_2;
															}
															num = 550;
															goto IL_10c5_2;
															IL_24e3_2:
															num6--;
															goto IL_24f1_2;
															IL_10c5_2:
															array3[num6] = null;
															goto IL_10cf_2;
															IL_10cf_2:
															array2[num6] = 5;
															goto IL_10dd_2;
															IL_10dd_2:
															num6++;
															break;
															IL_1007_2:
															if (37 > b)
															{
																goto IL_1015_2;
															}
															goto IL_1a1c_2;
															IL_1015_2:
															if (34 >= b)
															{
																goto IL_1020_2;
															}
															goto IL_1050_2;
															IL_1020_2:
															if (34 <= b)
															{
																goto IL_102e_2;
															}
															goto IL_260d_2;
															IL_102e_2:
															array2[num6 - 1] = 3;
															num = 617;
															goto IL_19db_2;
															IL_19db_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1a64_2;
															IL_1a64_2:
															ptr2 += 8;
															num = 549;
															break;
															IL_260d_2:
															if (33 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_261b_2;
															IL_261b_2:
															if (33 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2629_2;
															IL_2629_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															goto IL_2642_2;
															IL_2642_2:
															array2[num6] = 3;
															goto IL_2650_2;
															IL_2650_2:
															num6++;
															goto IL_265e_2;
															IL_265e_2:
															ptr2 += 16;
															break;
															IL_1050_2:
															if (35 >= b)
															{
																goto IL_105e_2;
															}
															goto IL_10f0_2;
															IL_105e_2:
															if (35 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_106c_2;
															IL_106c_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_10ac_2;
															IL_10ac_2:
															array2[num6 - 2] = 3;
															goto IL_1910_2;
															IL_1910_2:
															num6--;
															break;
															IL_10f0_2:
															if (36 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_10fe_2;
															IL_10fe_2:
															if (36 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_110c_2;
															IL_110c_2:
															array2[num6 - 1] = 0;
															goto IL_1120_2;
															IL_1120_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 213;
															goto IL_1168_2;
															IL_1168_2:
															ptr2 += 8;
															break;
															IL_1a1c_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															break;
															IL_11e6_2:
															if (32 > b)
															{
																goto IL_11f4_2;
															}
															goto IL_2671_2;
															IL_11f4_2:
															if (26 >= b)
															{
																goto IL_1202_2;
															}
															goto IL_1827_2;
															IL_1202_2:
															if (26 <= b)
															{
																goto IL_120d_2;
															}
															goto IL_125d_2;
															IL_120d_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															num = 133;
															goto IL_122e_2;
															IL_122e_2:
															array2[num6] = 5;
															goto IL_123c_2;
															IL_123c_2:
															num6++;
															goto IL_124a_2;
															IL_124a_2:
															ptr2 += 8;
															break;
															IL_125d_2:
															if (23 >= b)
															{
																goto IL_126b_2;
															}
															goto IL_1944_2;
															IL_126b_2:
															if (23 <= b)
															{
																goto IL_1279_2;
															}
															goto IL_1923_2;
															IL_1279_2:
															array2[num6] = 5;
															goto IL_1287_2;
															IL_1287_2:
															array3[num6] = ((delegate*<GorillaTagger>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
															num = 588;
															goto IL_15bc_2;
															IL_15bc_2:
															num6++;
															num = 642;
															goto IL_1e29_2;
															IL_1e29_2:
															ptr2 += 8;
															break;
															IL_1923_2:
															if (22 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_1931_2;
															IL_1931_2:
															if (22 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2414_2;
															IL_2414_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_2466_2;
															IL_2466_2:
															num6--;
															num = 85;
															break;
															IL_1944_2:
															if (24 < b)
															{
																goto IL_1952_2;
															}
															goto IL_2504_2;
															IL_1952_2:
															if (25 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_1960_2;
															IL_1960_2:
															if (25 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_196e_2;
															IL_196e_2:
															array2[num6 - 1] = 5;
															num = 209;
															goto IL_198b_2;
															IL_198b_2:
															array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
															goto IL_2571_2;
															IL_2571_2:
															ptr2 += 8;
															break;
															IL_2504_2:
															if (24 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2512_2;
															IL_2512_2:
															array2[num6 - 1] = 5;
															goto IL_2526_2;
															IL_2526_2:
															array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
															goto IL_255e_2;
															IL_255e_2:
															ptr2 += 8;
															break;
															IL_1827_2:
															if (29 >= b)
															{
																goto IL_1832_2;
															}
															goto IL_1845_2;
															IL_1832_2:
															if (29 <= b)
															{
																goto IL_1fc9_2;
															}
															goto IL_2e15_2;
															IL_1fc9_2:
															array3[num6] = ((delegate*<Vector3>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])();
															goto IL_1fec_2;
															IL_1fec_2:
															array2[num6] = 4;
															goto IL_1ffa_2;
															IL_1ffa_2:
															num6++;
															goto IL_2008_2;
															IL_2008_2:
															ptr2 += 8;
															break;
															IL_2e15_2:
															if (27 >= b)
															{
																goto IL_2e20_2;
															}
															goto IL_2e8d_2;
															IL_2e20_2:
															if (27 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2e2e_2;
															IL_2e2e_2:
															array2[num6 - 1] = 5;
															goto IL_2e42_2;
															IL_2e42_2:
															array3[num6 - 1] = ((delegate*<VRRig, NetPlayer>)DispositionInternalParseTypeE[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
															goto IL_2e7a_2;
															IL_2e7a_2:
															ptr2 += 8;
															break;
															IL_2e8d_2:
															if (28 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2e9b_2;
															IL_2e9b_2:
															if (28 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_2ea9_2;
															IL_2ea9_2:
															array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_2ed2_2;
															IL_2ed2_2:
															array2[num6 - 1] = 5;
															break;
															IL_1845_2:
															if (30 >= b)
															{
																goto IL_1850_2;
															}
															goto IL_18a8_2;
															IL_1850_2:
															if (30 > b)
															{
																goto end_IL_0c39_2;
															}
															num = 97;
															goto IL_1867_2;
															IL_24f1_2:
															ptr2 += 8;
															break;
															IL_1867_2:
															array3[num6 - 1] = (Vector3)array3[num6 - 1];
															goto IL_188f_2;
															IL_188f_2:
															array2[num6 - 1] = 5;
															break;
															IL_18a8_2:
															if (31 < b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_18b6_2;
															IL_18b6_2:
															if (31 > b)
															{
																goto end_IL_0c39_2;
															}
															goto IL_18c4_2;
															IL_18c4_2:
															((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
															goto IL_18fd_2;
															IL_18fd_2:
															num6 -= 3;
															break;
															IL_2671_2:
															array2[num6 - 4] = 0;
															goto IL_2685_2;
														}
														goto end_IL_0c49_2;
														continue;
														end_IL_0c39_2:
														break;
														IL_0c39_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												break;
												continue;
												end_IL_0c49_2:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_356f_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_20e3_2;
					}
					continue;
					end_IL_20f1:
					break;
				}
				break;
			}
		}
	}

	private unsafe void method_2(VRRig vrrig_0)
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0825, IL_0838, IL_0851, IL_0861, IL_0881, IL_089a, IL_08aa, IL_08bd, IL_08cd, IL_08dd, IL_08ed, IL_08fd, IL_090d, IL_091a, IL_092a, IL_093a, IL_094a, IL_095a, IL_0965, IL_0973, IL_099e, IL_09ac, IL_09ba, IL_09c8, IL_09f1, IL_0a0a, IL_0a1d, IL_0a36, IL_0a44, IL_0a52, IL_0a60, IL_0a6e, IL_0a7c, IL_0a8c, IL_0a9a, IL_0aa8, IL_0abb, IL_0afb, IL_0b0f, IL_0b22, IL_0b45, IL_0b50, IL_0b69, IL_0b7c, IL_0b91, IL_0ba4, IL_0bb2, IL_0bbd, IL_0bcb, IL_0bd9, IL_0be7, IL_0bf5, IL_0c00, IL_0c13, IL_0c21, IL_0c2f, IL_0c3d, IL_0c98, IL_0cab, IL_0cb9, IL_0cc4, IL_0cd2, IL_0ce2, IL_0cf0, IL_0d0d, IL_0d45, IL_0d58, IL_0d70, IL_0d8e, IL_0db7, IL_0dc5, IL_0dd0, IL_0e13, IL_0e21, IL_0e2a, IL_0e38, IL_0e46, IL_0e54, IL_0e5d, IL_0e70, IL_0ea0, IL_0eb9, IL_0ed0, IL_0ee3, IL_0eee, IL_0efc, IL_0f10, IL_0f58, IL_0f6b, IL_0f79, IL_0f87, IL_0f9b, IL_0fda, IL_0fed, IL_0ffb, IL_1009, IL_1017, IL_102f, IL_104c, IL_1057, IL_107b, IL_1089, IL_109c, IL_10a7, IL_10ba, IL_10c8, IL_10d6, IL_10df, IL_10ed, IL_1101, IL_1149, IL_115c, IL_1165, IL_1170, IL_118a, IL_119d, IL_11ab, IL_11b9, IL_11f9, IL_120d, IL_1220, IL_1233, IL_1247, IL_127f, IL_1292, IL_12a5, IL_12c1, IL_12cf, IL_12e3, IL_132b, IL_133e, IL_1349, IL_136d, IL_137b, IL_1389, IL_139c, IL_13ac, IL_13bf, IL_13cd, IL_140d, IL_1421, IL_1434, IL_144d, IL_1460, IL_146e, IL_147c, IL_148f, IL_149d, IL_14b5, IL_14c3, IL_14d6, IL_14e1, IL_14ea, IL_14fe, IL_153d, IL_1550, IL_155e, IL_156c, IL_157a, IL_15ba, IL_15ce, IL_15e1, IL_15f5, IL_1634, IL_1647, IL_1655, IL_1663, IL_16a1, IL_16b4, IL_16d0, IL_16de, IL_16e9, IL_1707, IL_1715, IL_1723, IL_1736, IL_1744, IL_1757, IL_1775, IL_1788, IL_1796, IL_17a4, IL_17b2, IL_17bd, IL_17e6, IL_17f4, IL_1807, IL_1812, IL_1820, IL_1839, IL_1847, IL_1855, IL_1868, IL_1876, IL_1884, IL_18cd, IL_18e1, IL_18f4, IL_18ff, IL_190d, IL_191b, IL_192e, IL_193c, IL_194a, IL_198a, IL_199e, IL_19b1, IL_19bf, IL_19cd, IL_19db, IL_19e6, IL_19f4, IL_1a02, IL_1a0b, IL_1a1e, IL_1a5e, IL_1a72, IL_1a85, IL_1a93, IL_1aa1, IL_1b03, IL_1b16, IL_1b24, IL_1b32, IL_1b40, IL_1b49, IL_1b57, IL_1b74, IL_1bc3, IL_1bcd, IL_1bfa, IL_1c13, IL_1c31, IL_1c3f, IL_1c52, IL_1c60, IL_1c6e, IL_1c97, IL_1cb0, IL_1cbe, IL_1cc9, IL_1cdd, IL_1d1c, IL_1d2f, IL_1d3d, IL_1d4b, IL_1d83, IL_1d97, IL_1daa, IL_1db8, IL_1dc6, IL_1dda, IL_1e19, IL_1e2c, IL_1e3a, IL_1e4d, IL_1e61, IL_1ea0, IL_1eb3, IL_1ec1, IL_1ecf, IL_1edd, IL_1ef6, IL_1f04, IL_1f12, IL_1f25, IL_1f33, IL_1f6c, IL_1f7f, IL_1f8d, IL_1f9b, IL_1fef, IL_2002, IL_201b, IL_202e, IL_2050, IL_205b, IL_2078, IL_20b0, IL_20c3, IL_20d1, IL_20df, IL_20f7, IL_2105, IL_2113, IL_2126, IL_2167, IL_217b, IL_218e, IL_21ce, IL_21e2, IL_21f5, IL_2203, IL_2226, IL_2230, IL_223e, IL_2251, IL_2291, IL_22a5, IL_22b8, IL_22cc, IL_230b, IL_231e, IL_2398, IL_23a6, IL_23b9, IL_23c7, IL_23d2, IL_23e0, IL_23ee, IL_23f8, IL_2406, IL_2419, IL_242d, IL_2483, IL_2491, IL_24a1, IL_24ac, IL_24b7, IL_24c0, IL_24d3, IL_24e6, IL_24f9, IL_250d, IL_251d, IL_252d, IL_253d, IL_254d, IL_255d, IL_256d, IL_257d, IL_258d, IL_259d are reachable both inside and outside the pinned region starting at IL_25b2. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 448;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef68 = default(int);
			ref int reference = ref __rxRef68;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_259d:
					num2 = 1;
					while (true)
					{
						IL_258d:
						num3 = num2 * 4;
						while (true)
						{
							IL_257d:
							num4 = num2 * 8;
							while (true)
							{
								IL_256d:
								array2 = new byte[8];
								while (true)
								{
									IL_255d:
									array3 = new object[8];
									while (true)
									{
										IL_254d:
										array4 = new int[8];
										while (true)
										{
											IL_253d:
											array5 = new int[7];
											while (true)
											{
												IL_252d:
												array6 = new long[8];
												while (true)
												{
													IL_251d:
													array7 = new object[21];
													while (true)
													{
														IL_250d:
														array7[0] = vrrig_0;
														while (true)
														{
															IL_24f9:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetParentTokenGetPathRoot.RenewalgetNumberNegativePattern);
															num = 433;
															while (true)
															{
																IL_24e6:
																ptr2 = ptr;
																num = 343;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_095a:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_094a:
																			ptr2++;
																			while (true)
																			{
																				IL_093a:
																				if (b >= 1)
																				{
																					while (b <= 62)
																					{
																						while (true)
																						{
																							IL_091a:
																							if (31 < b)
																							{
																								while (true)
																								{
																									IL_090d:
																									if (47 < b)
																									{
																										while (true)
																										{
																											IL_08fd:
																											if (55 < b)
																											{
																												while (true)
																												{
																													IL_08ed:
																													if (59 >= b)
																													{
																														while (true)
																														{
																															IL_08dd:
																															if (59 > b)
																															{
																																while (true)
																																{
																																	IL_08cd:
																																	if (57 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_08bd:
																																			if (57 > b)
																																			{
																																				while (56 >= b)
																																				{
																																					num = 23;
																																					while (56 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_0881:
																																							array2[num6] = 5;
																																							num = 411;
																																							while (true)
																																							{
																																								IL_0861:
																																								array3[num6] = ((delegate*<FriendshipGroupDetection>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																																								while (true)
																																								{
																																									IL_0851:
																																									num6++;
																																									while (true)
																																									{
																																										IL_0838:
																																										ptr2 += 8;
																																										num = 514;
																																										while (num != 514)
																																										{
																																											if (num != 1495)
																																											{
																																												goto IL_136d;
																																											}
																																											switch (num)
																																											{
																																											case 448:
																																												break;
																																											default:
																																												continue;
																																											case 120:
																																												goto IL_0838;
																																											case 421:
																																												goto IL_0851;
																																											case 411:
																																												goto IL_0861;
																																											case 13:
																																											case 244:
																																												goto IL_0881;
																																											case 23:
																																												goto IL_089a;
																																											case 368:
																																												goto IL_08aa;
																																											case 501:
																																												goto IL_08bd;
																																											case 239:
																																												goto IL_08cd;
																																											case 301:
																																												goto IL_08dd;
																																											case 353:
																																												goto IL_08ed;
																																											case 387:
																																												goto IL_08fd;
																																											case 317:
																																												goto IL_090d;
																																											case 54:
																																												goto IL_091a;
																																											case 150:
																																												goto IL_092a;
																																											case 450:
																																												goto IL_093a;
																																											case 440:
																																												goto IL_094a;
																																											case 16:
																																											case 354:
																																												goto IL_095a;
																																											case 33:
																																												goto IL_0965;
																																											case 15:
																																											case 82:
																																												goto IL_0973;
																																											case 128:
																																												goto IL_099e;
																																											case 65:
																																												goto IL_09ac;
																																											case 106:
																																												goto IL_09ba;
																																											case 25:
																																											case 158:
																																												goto IL_09c8;
																																											case 110:
																																												goto IL_09f1;
																																											case 224:
																																												goto IL_0a0a;
																																											case 251:
																																												goto IL_0a1d;
																																											case 294:
																																												goto IL_0a36;
																																											case 126:
																																												goto IL_0a44;
																																											case 6:
																																												goto IL_0a52;
																																											case 286:
																																												goto IL_0a60;
																																											case 135:
																																												goto IL_0a6e;
																																											case 209:
																																												goto IL_0a7c;
																																											case 304:
																																												goto IL_0a8c;
																																											case 249:
																																												goto IL_0a9a;
																																											case 218:
																																												goto IL_0aa8;
																																											case 280:
																																											case 310:
																																												goto IL_0abb;
																																											case 119:
																																												goto IL_0afb;
																																											case 98:
																																												goto IL_0b0f;
																																											case 89:
																																											case 323:
																																												goto IL_0b22;
																																											case 330:
																																												goto IL_0b45;
																																											case 67:
																																											case 156:
																																												goto IL_0b50;
																																											case 69:
																																												goto IL_0b69;
																																											case 87:
																																											case 337:
																																												goto IL_0b7c;
																																											case 153:
																																												goto IL_0b91;
																																											case 371:
																																												goto IL_0ba4;
																																											case 255:
																																												goto IL_0bb2;
																																											case 124:
																																												goto IL_0bbd;
																																											case 235:
																																												goto IL_0bd9;
																																											case 370:
																																												goto IL_0be7;
																																											case 57:
																																												goto IL_0bf5;
																																											case 346:
																																												goto IL_0c00;
																																											case 51:
																																												goto IL_0c13;
																																											case 46:
																																												goto IL_0c21;
																																											case 142:
																																												goto IL_0c2f;
																																											case 8:
																																											case 217:
																																												goto IL_0c3d;
																																											case 109:
																																												goto IL_0c98;
																																											case 75:
																																												goto IL_0cab;
																																											case 20:
																																												goto IL_0cb9;
																																											case 197:
																																												goto IL_0cc4;
																																											case 179:
																																												goto IL_0cd2;
																																											case 203:
																																											case 381:
																																												goto IL_0cf0;
																																											case 284:
																																												goto IL_0d0d;
																																											case 329:
																																												goto IL_0d45;
																																											case 262:
																																											case 382:
																																												goto IL_0d58;
																																											case 292:
																																												goto IL_0d70;
																																											case 295:
																																												goto IL_0d8e;
																																											case 384:
																																												goto IL_0db7;
																																											case 340:
																																												goto IL_0dc5;
																																											case 335:
																																											case 372:
																																												goto IL_0dd0;
																																											case 154:
																																												goto IL_0e13;
																																											case 192:
																																												goto IL_0e2a;
																																											case 39:
																																												goto IL_0e46;
																																											case 268:
																																												goto IL_0e5d;
																																											case 213:
																																											case 391:
																																												goto IL_0e70;
																																											case 62:
																																											case 392:
																																												goto IL_0ea0;
																																											case 211:
																																												goto IL_0eb9;
																																											case 352:
																																												goto IL_0ed0;
																																											case 399:
																																												goto IL_0ee3;
																																											case 302:
																																												goto IL_0eee;
																																											case 2:
																																											case 246:
																																												goto IL_0efc;
																																											case 333:
																																												goto IL_0f10;
																																											case 305:
																																												goto IL_0f58;
																																											case 12:
																																												goto IL_0f6b;
																																											case 380:
																																												goto IL_0f79;
																																											case 131:
																																											case 238:
																																												goto IL_0f87;
																																											case 91:
																																												goto IL_0f9b;
																																											case 356:
																																												goto IL_0fda;
																																											case 405:
																																												goto IL_0fed;
																																											case 137:
																																												goto IL_0ffb;
																																											case 22:
																																												goto IL_1009;
																																											case 70:
																																											case 133:
																																												goto IL_1017;
																																											case 408:
																																												goto IL_102f;
																																											case 430:
																																												goto IL_104c;
																																											case 152:
																																											case 308:
																																												goto IL_1057;
																																											case 282:
																																												goto IL_107b;
																																											case 336:
																																												goto IL_1089;
																																											case 420:
																																												goto IL_109c;
																																											case 199:
																																												goto IL_10a7;
																																											case 293:
																																												goto IL_10ba;
																																											case 210:
																																												goto IL_10c8;
																																											case 234:
																																												goto IL_10df;
																																											case 0:
																																											case 66:
																																												goto IL_10ed;
																																											case 422:
																																												goto IL_1101;
																																											case 347:
																																												goto IL_1149;
																																											case 36:
																																												goto IL_1165;
																																											case 115:
																																											case 328:
																																												goto IL_1170;
																																											case 225:
																																												goto IL_118a;
																																											case 222:
																																												goto IL_119d;
																																											case 312:
																																												goto IL_11ab;
																																											case 60:
																																											case 267:
																																												goto IL_11b9;
																																											case 269:
																																												goto IL_11f9;
																																											case 167:
																																												goto IL_120d;
																																											case 434:
																																												goto IL_1220;
																																											case 369:
																																											case 439:
																																												goto IL_1233;
																																											case 163:
																																												goto IL_1247;
																																											case 400:
																																												goto IL_127f;
																																											case 449:
																																												goto IL_1292;
																																											case 360:
																																											case 459:
																																												goto IL_12a5;
																																											case 461:
																																												goto IL_12c1;
																																											case 334:
																																											case 390:
																																												goto IL_12cf;
																																											case 429:
																																												goto IL_12e3;
																																											case 359:
																																												goto IL_132b;
																																											case 462:
																																												goto IL_133e;
																																											case 172:
																																											case 189:
																																												goto IL_1349;
																																											case 180:
																																												goto IL_136d;
																																											case 256:
																																												goto IL_137b;
																																											case 394:
																																												goto IL_1389;
																																											case 162:
																																												goto IL_139c;
																																											case 463:
																																												goto IL_13ac;
																																											case 466:
																																												goto IL_13bf;
																																											case 296:
																																											case 454:
																																												goto IL_13cd;
																																											case 94:
																																												goto IL_140d;
																																											case 446:
																																												goto IL_1421;
																																											case 164:
																																											case 467:
																																												goto IL_1434;
																																											case 415:
																																												goto IL_144d;
																																											case 468:
																																												goto IL_1460;
																																											case 141:
																																												goto IL_146e;
																																											case 130:
																																												goto IL_147c;
																																											case 419:
																																											case 471:
																																												goto IL_148f;
																																											case 205:
																																												goto IL_149d;
																																											case 401:
																																												goto IL_14b5;
																																											case 112:
																																												goto IL_14c3;
																																											case 473:
																																												goto IL_14d6;
																																											case 331:
																																											case 366:
																																												goto IL_14ea;
																																											case 11:
																																												goto IL_14fe;
																																											case 458:
																																												goto IL_153d;
																																											case 470:
																																												goto IL_1550;
																																											case 327:
																																												goto IL_155e;
																																											case 373:
																																												goto IL_156c;
																																											case 250:
																																											case 361:
																																												goto IL_157a;
																																											case 278:
																																												goto IL_15ba;
																																											case 314:
																																												goto IL_15ce;
																																											case 168:
																																											case 476:
																																												goto IL_15e1;
																																											case 272:
																																												goto IL_15f5;
																																											case 52:
																																												goto IL_1634;
																																											case 477:
																																												goto IL_1647;
																																											case 125:
																																												goto IL_1655;
																																											case 160:
																																											case 287:
																																												goto IL_1663;
																																											case 398:
																																												goto IL_16a1;
																																											case 479:
																																												goto IL_16b4;
																																											case 480:
																																												goto IL_16d0;
																																											case 177:
																																												goto IL_16de;
																																											case 184:
																																											case 457:
																																												goto IL_16e9;
																																											case 407:
																																												goto IL_1707;
																																											case 216:
																																												goto IL_1715;
																																											case 321:
																																												goto IL_1723;
																																											case 53:
																																												goto IL_1736;
																																											case 290:
																																												goto IL_1744;
																																											case 367:
																																											case 481:
																																												goto IL_1757;
																																											case 281:
																																												goto IL_1775;
																																											case 482:
																																												goto IL_1788;
																																											case 198:
																																												goto IL_1796;
																																											case 453:
																																												goto IL_17a4;
																																											case 455:
																																												goto IL_17b2;
																																											case 219:
																																											case 350:
																																												goto IL_17bd;
																																											case 181:
																																												goto IL_17e6;
																																											case 258:
																																												goto IL_17f4;
																																											case 426:
																																												goto IL_1807;
																																											case 116:
																																												goto IL_1812;
																																											case 215:
																																											case 410:
																																												goto IL_1820;
																																											case 395:
																																												goto IL_1839;
																																											case 248:
																																												goto IL_1847;
																																											case 339:
																																												goto IL_1855;
																																											case 143:
																																												goto IL_1868;
																																											case 472:
																																												goto IL_1876;
																																											case 79:
																																											case 187:
																																												goto IL_1884;
																																											case 318:
																																												goto IL_18cd;
																																											case 196:
																																												goto IL_18e1;
																																											case 365:
																																												goto IL_18f4;
																																											case 223:
																																												goto IL_18ff;
																																											case 18:
																																												goto IL_190d;
																																											case 232:
																																												goto IL_191b;
																																											case 1:
																																												goto IL_192e;
																																											case 85:
																																												goto IL_193c;
																																											case 136:
																																											case 276:
																																												goto IL_194a;
																																											case 201:
																																												goto IL_198a;
																																											case 374:
																																												goto IL_199e;
																																											case 483:
																																												goto IL_19b1;
																																											case 175:
																																												goto IL_19bf;
																																											case 138:
																																												goto IL_19cd;
																																											case 178:
																																												goto IL_19db;
																																											case 469:
																																												goto IL_19e6;
																																											case 227:
																																												goto IL_19f4;
																																											case 349:
																																											case 377:
																																												goto IL_1a0b;
																																											case 191:
																																											case 297:
																																												goto IL_1a1e;
																																											case 81:
																																												goto IL_1a5e;
																																											case 45:
																																												goto IL_1a72;
																																											case 375:
																																												goto IL_1a85;
																																											case 108:
																																												goto IL_1a93;
																																											case 47:
																																											case 303:
																																												goto IL_1aa1;
																																											case 95:
																																												goto IL_1b03;
																																											case 14:
																																												goto IL_1b16;
																																											case 348:
																																												goto IL_1b24;
																																											case 149:
																																												goto IL_1b32;
																																											case 107:
																																												goto IL_1b49;
																																											case 64:
																																											case 435:
																																												goto IL_1b57;
																																											case 5:
																																											case 182:
																																												goto IL_1c13;
																																											case 364:
																																												goto IL_1c31;
																																											case 357:
																																												goto IL_1c3f;
																																											case 285:
																																												goto IL_1c52;
																																											case 270:
																																												goto IL_1c60;
																																											case 165:
																																											case 274:
																																												goto IL_1c6e;
																																											case 253:
																																												goto IL_1c97;
																																											case 485:
																																												goto IL_1cb0;
																																											case 73:
																																												goto IL_1cbe;
																																											case 207:
																																											case 338:
																																												goto IL_1cc9;
																																											case 452:
																																												goto IL_1cdd;
																																											case 71:
																																												goto IL_1d1c;
																																											case 145:
																																												goto IL_1d2f;
																																											case 271:
																																												goto IL_1d3d;
																																											case 83:
																																											case 431:
																																												goto IL_1d4b;
																																											case 402:
																																												goto IL_1d83;
																																											case 166:
																																												goto IL_1d97;
																																											case 28:
																																												goto IL_1daa;
																																											case 102:
																																												goto IL_1db8;
																																											case 40:
																																											case 56:
																																												goto IL_1dc6;
																																											case 32:
																																												goto IL_1dda;
																																											case 74:
																																												goto IL_1e19;
																																											case 486:
																																												goto IL_1e2c;
																																											case 451:
																																												goto IL_1e3a;
																																											case 113:
																																											case 487:
																																												goto IL_1e4d;
																																											case 92:
																																												goto IL_1e61;
																																											case 148:
																																												goto IL_1ea0;
																																											case 488:
																																												goto IL_1eb3;
																																											case 243:
																																												goto IL_1ec1;
																																											case 289:
																																												goto IL_1ecf;
																																											case 386:
																																											case 484:
																																												goto IL_1edd;
																																											case 427:
																																												goto IL_1ef6;
																																											case 322:
																																												goto IL_1f04;
																																											case 220:
																																												goto IL_1f12;
																																											case 489:
																																												goto IL_1f25;
																																											case 170:
																																											case 326:
																																												goto IL_1f33;
																																											case 30:
																																												goto IL_1f6c;
																																											case 491:
																																												goto IL_1f7f;
																																											case 376:
																																												goto IL_1f8d;
																																											case 214:
																																											case 378:
																																												goto IL_1f9b;
																																											case 393:
																																												goto IL_1fef;
																																											case 202:
																																											case 492:
																																												goto IL_2002;
																																											case 55:
																																												goto IL_201b;
																																											case 493:
																																												goto IL_202e;
																																											case 496:
																																												goto IL_2050;
																																											case 100:
																																											case 320:
																																												goto IL_205b;
																																											case 309:
																																												goto IL_2078;
																																											case 358:
																																												goto IL_20b0;
																																											case 195:
																																												goto IL_20c3;
																																											case 403:
																																												goto IL_20d1;
																																											case 122:
																																											case 443:
																																												goto IL_20df;
																																											case 193:
																																												goto IL_20f7;
																																											case 61:
																																												goto IL_2105;
																																											case 146:
																																												goto IL_2113;
																																											case 194:
																																											case 497:
																																												goto IL_2126;
																																											case 9:
																																												goto IL_2167;
																																											case 21:
																																												goto IL_217b;
																																											case 129:
																																											case 499:
																																												goto IL_218e;
																																											case 10:
																																												goto IL_21ce;
																																											case 291:
																																												goto IL_21e2;
																																											case 78:
																																											case 502:
																																												goto IL_21f5;
																																											case 404:
																																												goto IL_2203;
																																											case 406:
																																												goto IL_2226;
																																											case 345:
																																												goto IL_2230;
																																											case 413:
																																												goto IL_223e;
																																											case 236:
																																											case 503:
																																												goto IL_2251;
																																											case 80:
																																												goto IL_2291;
																																											case 265:
																																												goto IL_22a5;
																																											case 417:
																																											case 505:
																																												goto IL_22b8;
																																											case 311:
																																												goto IL_22cc;
																																											case 68:
																																												goto IL_230b;
																																											case 506:
																																												goto IL_231e;
																																											case 388:
																																												goto IL_2398;
																																											case 241:
																																												goto IL_23a6;
																																											case 176:
																																												goto IL_23b9;
																																											case 332:
																																												goto IL_23c7;
																																											case 298:
																																												goto IL_23d2;
																																											case 341:
																																												goto IL_23e0;
																																											case 188:
																																											case 300:
																																												goto IL_23ee;
																																											case 362:
																																												goto IL_23f8;
																																											case 4:
																																												goto IL_2406;
																																											case 96:
																																											case 299:
																																												goto IL_2419;
																																											case 59:
																																												goto IL_242d;
																																											case 355:
																																												goto IL_2483;
																																											case 117:
																																												goto IL_2491;
																																											case 104:
																																												goto IL_24a1;
																																											case 456:
																																												goto IL_24ac;
																																											case 17:
																																											case 19:
																																											case 26:
																																											case 27:
																																											case 31:
																																											case 35:
																																											case 38:
																																											case 43:
																																											case 44:
																																											case 49:
																																											case 50:
																																											case 58:
																																											case 77:
																																											case 84:
																																											case 86:
																																											case 90:
																																											case 105:
																																											case 123:
																																											case 132:
																																											case 140:
																																											case 147:
																																											case 151:
																																											case 157:
																																											case 159:
																																											case 171:
																																											case 173:
																																											case 174:
																																											case 185:
																																											case 200:
																																											case 204:
																																											case 206:
																																											case 212:
																																											case 221:
																																											case 226:
																																											case 229:
																																											case 231:
																																											case 233:
																																											case 240:
																																											case 245:
																																											case 247:
																																											case 252:
																																											case 257:
																																											case 259:
																																											case 260:
																																											case 261:
																																											case 273:
																																											case 275:
																																											case 277:
																																											case 283:
																																											case 288:
																																											case 307:
																																											case 324:
																																											case 325:
																																											case 342:
																																											case 344:
																																											case 351:
																																											case 414:
																																											case 418:
																																											case 424:
																																											case 441:
																																											case 475:
																																											case 478:
																																											case 490:
																																											case 495:
																																											case 504:
																																												goto end_IL_089a;
																																											case 7:
																																											case 24:
																																											case 29:
																																											case 34:
																																											case 37:
																																											case 41:
																																											case 42:
																																											case 48:
																																											case 63:
																																											case 72:
																																											case 76:
																																											case 88:
																																											case 93:
																																											case 97:
																																											case 99:
																																											case 101:
																																											case 103:
																																											case 111:
																																											case 114:
																																											case 118:
																																											case 121:
																																											case 134:
																																											case 139:
																																											case 144:
																																											case 155:
																																											case 161:
																																											case 169:
																																											case 183:
																																											case 186:
																																											case 190:
																																											case 208:
																																											case 228:
																																											case 230:
																																											case 254:
																																											case 266:
																																											case 306:
																																											case 315:
																																											case 316:
																																											case 319:
																																											case 343:
																																											case 363:
																																											case 379:
																																											case 383:
																																											case 389:
																																											case 396:
																																											case 397:
																																											case 409:
																																											case 412:
																																											case 416:
																																											case 423:
																																											case 425:
																																											case 428:
																																											case 432:
																																											case 437:
																																											case 442:
																																											case 444:
																																											case 445:
																																											case 460:
																																											case 464:
																																											case 465:
																																											case 474:
																																											case 498:
																																											case 500:
																																											case 507:
																																												goto end_IL_0825;
																																											case 433:
																																												goto IL_24e6;
																																											case 494:
																																												goto IL_24f9;
																																											case 438:
																																												goto IL_250d;
																																											case 385:
																																												goto IL_251d;
																																											case 127:
																																												goto IL_252d;
																																											case 264:
																																												goto IL_253d;
																																											case 279:
																																												goto IL_254d;
																																											case 237:
																																												goto IL_255d;
																																											case 313:
																																												goto IL_256d;
																																											case 3:
																																												goto IL_257d;
																																											case 436:
																																												goto IL_258d;
																																											case 447:
																																												goto IL_259d;
																																											case 242:
																																											case 263:
																																												return;
																																											}
																																											goto end_IL_24d3;
																																											continue;
																																											end_IL_0825:
																																											break;
																																										}
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						goto end_IL_093a;
																																						continue;
																																						end_IL_089a:
																																						break;
																																						IL_089a:;
																																					}
																																					break;
																																					IL_08aa:;
																																				}
																																				break;
																																			}
																																			goto IL_1434;
																																			IL_144d:
																																			num6--;
																																			goto end_IL_093a;
																																			IL_1434:
																																			global::_003CModule_003E.friendshipGroupDetection_1 = (FriendshipGroupDetection)array3[num6 - 1];
																																			goto IL_144d;
																																		}
																																		break;
																																	}
																																	goto IL_0a0a;
																																	IL_132b:
																																	ptr2 += 8;
																																	goto end_IL_093a;
																																	IL_0a0a:
																																	if (58 < b)
																																	{
																																		break;
																																	}
																																	goto IL_12c1;
																																	IL_12c1:
																																	if (58 > b)
																																	{
																																		break;
																																	}
																																	goto IL_12cf;
																																	IL_12cf:
																																	array2[num6 - 1] = 3;
																																	goto IL_12e3;
																																	IL_12e3:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																	num = 359;
																																	goto IL_132b;
																																}
																																break;
																															}
																															goto IL_0b7c;
																															IL_0b91:
																															ptr2 += 8;
																															goto end_IL_093a;
																															IL_0b7c:
																															((delegate*<void>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																															goto IL_0b91;
																														}
																														break;
																													}
																													goto IL_23b9;
																													IL_24ac:
																													if (62 <= b)
																													{
																														num = 212;
																													}
																													break;
																													IL_23b9:
																													if (61 >= b)
																													{
																														goto IL_23c7;
																													}
																													goto IL_24a1;
																													IL_23c7:
																													if (61 > b)
																													{
																														goto IL_23d2;
																													}
																													goto IL_2419;
																													IL_23d2:
																													if (60 < b)
																													{
																														break;
																													}
																													goto IL_23e0;
																													IL_23e0:
																													if (60 > b)
																													{
																														break;
																													}
																													goto IL_23ee;
																													IL_23ee:
																													array3[num6] = null;
																													goto IL_23f8;
																													IL_23f8:
																													array2[num6] = 5;
																													goto IL_2406;
																													IL_2406:
																													num6++;
																													goto end_IL_093a;
																													IL_2419:
																													array2[num6 - 2] = 0;
																													goto IL_242d;
																													IL_242d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(FriendshipGroupDetection)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																													num = 355;
																													goto IL_2483;
																													IL_2483:
																													num6--;
																													goto IL_2491;
																													IL_2491:
																													ptr2 += 8;
																													goto end_IL_093a;
																													IL_24a1:
																													if (62 < b)
																													{
																														break;
																													}
																													goto IL_24ac;
																												}
																												break;
																											}
																											goto IL_099e;
																											IL_202e:
																											array2[num6 - 1] = 0;
																											num = 409;
																											goto end_IL_093a;
																											IL_099e:
																											if (55 > b)
																											{
																												goto IL_09ac;
																											}
																											goto IL_0e70;
																											IL_09ac:
																											if (51 >= b)
																											{
																												goto IL_09ba;
																											}
																											goto IL_0a8c;
																											IL_09ba:
																											if (51 <= b)
																											{
																												goto IL_09c8;
																											}
																											goto IL_0ee3;
																											IL_09c8:
																											array3[num6 - 1] = (short)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_09f1;
																											IL_09f1:
																											array2[num6 - 1] = 5;
																											goto end_IL_093a;
																											IL_0ee3:
																											if (49 >= b)
																											{
																												goto IL_0eee;
																											}
																											goto IL_0f6b;
																											IL_0eee:
																											if (49 <= b)
																											{
																												goto IL_0efc;
																											}
																											goto IL_1647;
																											IL_0efc:
																											array2[num6 - 1] = 3;
																											goto IL_0f10;
																											IL_0f10:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											num = 305;
																											goto IL_0f58;
																											IL_0f58:
																											ptr2 += 8;
																											goto end_IL_093a;
																											IL_1647:
																											if (48 < b)
																											{
																												break;
																											}
																											goto IL_1655;
																											IL_1655:
																											if (48 > b)
																											{
																												break;
																											}
																											goto IL_1663;
																											IL_1663:
																											((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											goto IL_16a1;
																											IL_16a1:
																											num6 -= 3;
																											goto end_IL_093a;
																											IL_0f6b:
																											if (50 < b)
																											{
																												break;
																											}
																											goto IL_0f79;
																											IL_0f79:
																											if (50 > b)
																											{
																												break;
																											}
																											goto IL_0f87;
																											IL_0f87:
																											array2[num6 - 1] = 0;
																											goto IL_0f9b;
																											IL_0f9b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0fda;
																											IL_0fda:
																											ptr2 += 8;
																											goto end_IL_093a;
																											IL_0a8c:
																											if (53 < b)
																											{
																												goto IL_0a9a;
																											}
																											goto IL_0b45;
																											IL_0a9a:
																											if (54 < b)
																											{
																												break;
																											}
																											goto IL_0aa8;
																											IL_0aa8:
																											if (54 > b)
																											{
																												break;
																											}
																											goto IL_12a5;
																											IL_12a5:
																											num7 = ptr2;
																											num8 = -200;
																											num5 = 1;
																											ptr2 = num7 + num8;
																											goto end_IL_093a;
																											IL_0b45:
																											if (53 <= b)
																											{
																												goto IL_0b50;
																											}
																											goto IL_0b69;
																											IL_0b50:
																											array2[num6 - 4] = 0;
																											goto IL_231e;
																											IL_231e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, Player, object[], bool>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], (Player)array3[num6 - 2], (object[])array3[num6 - 1]) ? 1 : 0);
																											goto IL_2398;
																											IL_2398:
																											num6 -= 3;
																											goto IL_23a6;
																											IL_23a6:
																											ptr2 += 8;
																											goto end_IL_093a;
																											IL_0b69:
																											if (52 < b)
																											{
																												break;
																											}
																											goto IL_1f25;
																											IL_1f25:
																											if (52 > b)
																											{
																												break;
																											}
																											goto IL_1f33;
																											IL_1f33:
																											((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																											goto IL_1f6c;
																											IL_1f6c:
																											num6 -= 3;
																											goto end_IL_093a;
																											IL_0e70:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_202e;
																										}
																										break;
																									}
																									goto IL_0965;
																									IL_11b9:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_11f9;
																									IL_0965:
																									if (47 <= b)
																									{
																										goto IL_0973;
																									}
																									goto IL_0a36;
																									IL_0973:
																									array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0a1d;
																									IL_0a1d:
																									array2[num6 - 1] = 5;
																									goto end_IL_093a;
																									IL_0a36:
																									if (39 < b)
																									{
																										goto IL_0a44;
																									}
																									goto IL_104c;
																									IL_0a44:
																									if (43 >= b)
																									{
																										goto IL_0a52;
																									}
																									goto IL_1cb0;
																									IL_0a52:
																									if (43 > b)
																									{
																										goto IL_0a60;
																									}
																									goto IL_0b22;
																									IL_0a60:
																									if (41 < b)
																									{
																										goto IL_0a6e;
																									}
																									goto IL_133e;
																									IL_0a6e:
																									if (42 < b)
																									{
																										break;
																									}
																									goto IL_0a7c;
																									IL_0a7c:
																									if (42 > b)
																									{
																										break;
																									}
																									goto IL_0abb;
																									IL_0abb:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0afb;
																									IL_0afb:
																									array2[num6 - 2] = 3;
																									goto IL_0b0f;
																									IL_0b0f:
																									num6--;
																									goto end_IL_093a;
																									IL_133e:
																									if (41 <= b)
																									{
																										goto IL_1349;
																									}
																									goto IL_139c;
																									IL_1349:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																									goto IL_136d;
																									IL_136d:
																									array2[num6] = 0;
																									goto IL_137b;
																									IL_137b:
																									num6++;
																									goto IL_1389;
																									IL_1389:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_139c:
																									if (40 < b)
																									{
																										break;
																									}
																									goto IL_13bf;
																									IL_13bf:
																									if (40 > b)
																									{
																										break;
																									}
																									goto IL_13cd;
																									IL_13cd:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_140d;
																									IL_140d:
																									array2[num6 - 2] = 3;
																									goto IL_1421;
																									IL_1421:
																									num6--;
																									goto end_IL_093a;
																									IL_0b22:
																									array3[num6] = ((delegate*<FriendshipGroupDetection>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																									goto IL_1460;
																									IL_1460:
																									array2[num6] = 5;
																									goto IL_146e;
																									IL_146e:
																									num6++;
																									goto IL_147c;
																									IL_147c:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_1cb0:
																									if (45 >= b)
																									{
																										goto IL_1cbe;
																									}
																									goto IL_1daa;
																									IL_1cbe:
																									if (45 <= b)
																									{
																										goto IL_1cc9;
																									}
																									goto IL_1d2f;
																									IL_1cc9:
																									array2[num6 - 1] = 3;
																									goto IL_1cdd;
																									IL_1cdd:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1d1c;
																									IL_1d1c:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_1d2f:
																									if (44 < b)
																									{
																										break;
																									}
																									goto IL_1d3d;
																									IL_1d3d:
																									if (44 > b)
																									{
																										break;
																									}
																									goto IL_1d4b;
																									IL_1d4b:
																									array3[num6 - 1] = ((delegate*<FriendshipGroupDetection, PhotonView>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((FriendshipGroupDetection)array3[num6 - 1]);
																									goto IL_1d83;
																									IL_1d83:
																									array2[num6 - 1] = 5;
																									goto IL_1d97;
																									IL_1d97:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_1daa:
																									if (46 < b)
																									{
																										break;
																									}
																									goto IL_1db8;
																									IL_1db8:
																									if (46 > b)
																									{
																										break;
																									}
																									goto IL_1dc6;
																									IL_1dc6:
																									array2[num6 - 1] = 0;
																									goto IL_1dda;
																									IL_1dda:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1e19;
																									IL_1e19:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_104c:
																									if (39 <= b)
																									{
																										goto IL_1057;
																									}
																									goto IL_109c;
																									IL_1057:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																									goto IL_107b;
																									IL_107b:
																									array2[num6] = 0;
																									goto IL_1089;
																									IL_1089:
																									num6++;
																									goto IL_1220;
																									IL_1220:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_109c:
																									if (35 >= b)
																									{
																										goto IL_10a7;
																									}
																									goto IL_10ba;
																									IL_10a7:
																									if (35 <= b)
																									{
																										goto IL_15e1;
																									}
																									goto IL_16d0;
																									IL_15e1:
																									array2[num6 - 1] = 3;
																									goto IL_15f5;
																									IL_15f5:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1634;
																									IL_1634:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_16d0:
																									if (33 >= b)
																									{
																										goto IL_16de;
																									}
																									goto IL_1f7f;
																									IL_16de:
																									if (33 <= b)
																									{
																										goto IL_16e9;
																									}
																									goto IL_1736;
																									IL_16e9:
																									array3[num6] = ((delegate*<Player>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																									goto IL_1707;
																									IL_1707:
																									array2[num6] = 5;
																									goto IL_1715;
																									IL_1715:
																									num6++;
																									goto IL_1723;
																									IL_1723:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_1736:
																									if (32 < b)
																									{
																										break;
																									}
																									goto IL_1744;
																									IL_1744:
																									if (32 > b)
																									{
																										break;
																									}
																									goto IL_1e4d;
																									IL_1e4d:
																									array2[num6 - 1] = 3;
																									goto IL_1e61;
																									IL_1e61:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1ea0;
																									IL_1ea0:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_1f7f:
																									if (34 < b)
																									{
																										break;
																									}
																									goto IL_1f8d;
																									IL_1f8d:
																									if (34 > b)
																									{
																										break;
																									}
																									goto IL_1f9b;
																									IL_1f9b:
																									ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1fef;
																									IL_1fef:
																									num6--;
																									goto end_IL_093a;
																									IL_10ba:
																									if (37 < b)
																									{
																										goto IL_10c8;
																									}
																									num = 36;
																									goto IL_1165;
																									IL_10c8:
																									if (38 < b)
																									{
																										break;
																									}
																									num = 234;
																									goto IL_10df;
																									IL_120d:
																									num6--;
																									goto end_IL_093a;
																									IL_10df:
																									if (38 > b)
																									{
																										break;
																									}
																									goto IL_10ed;
																									IL_10ed:
																									array2[num6 - 1] = 3;
																									goto IL_1101;
																									IL_1101:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									num = 347;
																									goto IL_1149;
																									IL_1149:
																									ptr2 += 8;
																									goto end_IL_093a;
																									IL_11f9:
																									array2[num6 - 2] = 3;
																									goto IL_120d;
																									IL_1165:
																									if (37 <= b)
																									{
																										goto IL_1170;
																									}
																									goto IL_119d;
																									IL_1170:
																									global::_003CModule_003E.int_206 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_118a;
																									IL_118a:
																									num6--;
																									goto end_IL_093a;
																									IL_119d:
																									if (36 < b)
																									{
																										break;
																									}
																									goto IL_11ab;
																									IL_11ab:
																									if (36 > b)
																									{
																										break;
																									}
																									goto IL_11b9;
																								}
																								break;
																							}
																							goto IL_0ba4;
																							IL_1eb3:
																							if (25 > b)
																							{
																								goto IL_1ec1;
																							}
																							goto IL_22b8;
																							IL_0ba4:
																							if (31 > b)
																							{
																								goto IL_0bb2;
																							}
																							goto IL_2002;
																							IL_0bb2:
																							if (15 >= b)
																							{
																								goto IL_0bbd;
																							}
																							goto IL_0bd9;
																							IL_0bbd:
																							if (15 <= b)
																							{
																								num = 382;
																								goto IL_0d58;
																							}
																							goto IL_1788;
																							IL_1ec1:
																							if (24 < b)
																							{
																								break;
																							}
																							goto IL_1ecf;
																							IL_0d58:
																							array2[num6] = array2[num6 - 1];
																							goto IL_0d70;
																							IL_0d70:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_0d8e;
																							IL_0d8e:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_102f;
																							IL_102f:
																							array3[num6] = array3[num6 - 1];
																							goto IL_16b4;
																							IL_16b4:
																							num6++;
																							num = 99;
																							goto end_IL_093a;
																							IL_1788:
																							if (7 >= b)
																							{
																								goto IL_1796;
																							}
																							goto IL_19b1;
																							IL_1796:
																							if (7 > b)
																							{
																								goto IL_17a4;
																							}
																							goto IL_218e;
																							IL_17a4:
																							if (3 >= b)
																							{
																								goto IL_17b2;
																							}
																							goto IL_18f4;
																							IL_17b2:
																							if (3 <= b)
																							{
																								goto IL_17bd;
																							}
																							goto IL_1807;
																							IL_17bd:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_17e6;
																							IL_17e6:
																							ptr2 += 8;
																							goto IL_17f4;
																							IL_17f4:
																							num6--;
																							goto end_IL_093a;
																							IL_1807:
																							if (1 >= b)
																							{
																								goto IL_1812;
																							}
																							goto IL_1868;
																							IL_1812:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_1820;
																							IL_1820:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_1839;
																							IL_1839:
																							array2[num6] = 0;
																							goto IL_1847;
																							IL_1847:
																							num6++;
																							goto IL_1855;
																							IL_1855:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_1868:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_1876;
																							IL_1876:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_1884;
																							IL_1884:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 318;
																							goto IL_18cd;
																							IL_18cd:
																							array2[num6 - 2] = 0;
																							goto IL_18e1;
																							IL_18e1:
																							num6--;
																							goto end_IL_093a;
																							IL_18f4:
																							if (5 >= b)
																							{
																								goto IL_18ff;
																							}
																							goto IL_192e;
																							IL_18ff:
																							if (5 > b)
																							{
																								goto IL_190d;
																							}
																							goto IL_2251;
																							IL_190d:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_191b;
																							IL_191b:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_21f5;
																							IL_21f5:
																							array2[num6] = 0;
																							goto IL_2203;
																							IL_2203:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_2226;
																							IL_2226:
																							array3[num6] = null;
																							goto IL_2230;
																							IL_2230:
																							num6++;
																							goto IL_223e;
																							IL_223e:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_2251:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_2291;
																							IL_2291:
																							array2[num6 - 2] = 0;
																							goto IL_22a5;
																							IL_22a5:
																							num6--;
																							goto end_IL_093a;
																							IL_192e:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_193c;
																							IL_193c:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_194a;
																							IL_194a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_198a;
																							IL_198a:
																							array2[num6 - 2] = 0;
																							goto IL_199e;
																							IL_199e:
																							num6--;
																							goto end_IL_093a;
																							IL_218e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_21ce;
																							IL_21ce:
																							array2[num6 - 2] = 0;
																							goto IL_21e2;
																							IL_21e2:
																							num6--;
																							goto end_IL_093a;
																							IL_19b1:
																							if (11 >= b)
																							{
																								goto IL_19bf;
																							}
																							goto IL_1b16;
																							IL_19bf:
																							if (11 <= b)
																							{
																								goto end_IL_093a;
																							}
																							goto IL_19cd;
																							IL_19cd:
																							if (9 >= b)
																							{
																								goto IL_19db;
																							}
																							goto IL_1a85;
																							IL_19db:
																							if (9 > b)
																							{
																								goto IL_19e6;
																							}
																							goto IL_1a1e;
																							IL_19e6:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_19f4;
																							IL_19f4:
																							if (8 > b)
																							{
																								break;
																							}
																							num = 377;
																							goto IL_1a0b;
																							IL_1ecf:
																							if (24 > b)
																							{
																								break;
																							}
																							goto IL_1edd;
																							IL_1a0b:
																							num6--;
																							goto end_IL_093a;
																							IL_1a1e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1a5e;
																							IL_1a5e:
																							array2[num6 - 2] = 0;
																							goto IL_1a72;
																							IL_1a72:
																							num6--;
																							goto end_IL_093a;
																							IL_1a85:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_1a93;
																							IL_1a93:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_1aa1;
																							IL_1aa1:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1b03;
																							IL_1b03:
																							num6 -= 2;
																							goto end_IL_093a;
																							IL_1b16:
																							if (13 >= b)
																							{
																								goto IL_1b24;
																							}
																							goto IL_1c52;
																							IL_1b24:
																							if (13 > b)
																							{
																								goto IL_1b32;
																							}
																							goto IL_1c13;
																							IL_1b32:
																							if (12 < b)
																							{
																								break;
																							}
																							num = 107;
																							goto IL_1b49;
																							IL_1edd:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_1ef6;
																							IL_1b49:
																							if (12 > b)
																							{
																								break;
																							}
																							goto IL_1b57;
																							IL_1b57:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_1b66;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_1e2c;
																							IL_1ef6:
																							array2[num6] = 3;
																							goto IL_1f04;
																							IL_1f04:
																							num6++;
																							goto IL_1f12;
																							IL_1f12:
																							ptr2 += 16;
																							goto end_IL_093a;
																							IL_1e2c:
																							array2[num6] = 5;
																							goto IL_1e3a;
																							IL_1e3a:
																							num6++;
																							goto end_IL_093a;
																							IL_1c13:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_1c31;
																							IL_1c31:
																							ptr2 += 8;
																							goto IL_1c3f;
																							IL_1c3f:
																							num6--;
																							goto end_IL_093a;
																							IL_1c52:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_1c60;
																							IL_1c60:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_1c6e;
																							IL_1c6e:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1c97;
																							IL_1c97:
																							array2[num6 - 1] = 5;
																							goto end_IL_093a;
																							IL_0bd9:
																							if (23 >= b)
																							{
																								goto IL_0be7;
																							}
																							goto IL_0cab;
																							IL_0be7:
																							if (23 > b)
																							{
																								goto IL_0bf5;
																							}
																							goto IL_1757;
																							IL_0bf5:
																							if (19 >= b)
																							{
																								goto IL_0c00;
																							}
																							goto IL_0c13;
																							IL_0c00:
																							if (19 > b)
																							{
																								goto IL_0db7;
																							}
																							goto IL_0ea0;
																							IL_0ea0:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0eb9;
																							IL_0eb9:
																							array2[num6] = 1;
																							num = 352;
																							goto IL_0ed0;
																							IL_0ed0:
																							num6++;
																							goto IL_1292;
																							IL_1292:
																							ptr2 += 16;
																							goto end_IL_093a;
																							IL_0db7:
																							if (17 >= b)
																							{
																								goto IL_0dc5;
																							}
																							goto IL_0e46;
																							IL_0dc5:
																							if (17 <= b)
																							{
																								goto IL_0dd0;
																							}
																							goto IL_0e13;
																							IL_0dd0:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_13ac;
																							IL_13ac:
																							num6 -= 3;
																							goto end_IL_093a;
																							IL_0e13:
																							if (16 < b)
																							{
																								break;
																							}
																							num = 192;
																							goto IL_0e2a;
																							IL_22b8:
																							array2[num6 - 1] = 3;
																							goto IL_22cc;
																							IL_0e2a:
																							if (16 > b)
																							{
																								break;
																							}
																							num = 419;
																							goto IL_148f;
																							IL_22cc:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_230b;
																							IL_148f:
																							array2[num6] = 5;
																							goto IL_149d;
																							IL_149d:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_14b5;
																							IL_14b5:
																							num6++;
																							goto IL_14c3;
																							IL_14c3:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_0e46:
																							if (18 < b)
																							{
																								break;
																							}
																							num = 268;
																							goto IL_0e5d;
																							IL_230b:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_0e5d:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_1233;
																							IL_1233:
																							array2[num6 - 1] = 5;
																							goto IL_1247;
																							IL_1247:
																							array3[num6 - 1] = ((delegate*<string[], string>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_127f;
																							IL_127f:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_0c13:
																							if (21 < b)
																							{
																								goto IL_0c21;
																							}
																							goto IL_0fed;
																							IL_0c21:
																							if (22 < b)
																							{
																								break;
																							}
																							goto IL_0c2f;
																							IL_0c2f:
																							if (22 > b)
																							{
																								break;
																							}
																							goto IL_0c3d;
																							IL_0c3d:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 109;
																							goto IL_0c98;
																							IL_0c98:
																							num6--;
																							goto end_IL_093a;
																							IL_0fed:
																							if (21 > b)
																							{
																								goto IL_0ffb;
																							}
																							goto IL_2126;
																							IL_0ffb:
																							if (20 < b)
																							{
																								break;
																							}
																							goto IL_1009;
																							IL_1009:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_1017;
																							IL_1017:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_093a;
																							IL_2126:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_2167;
																							IL_2167:
																							array2[num6 - 2] = 0;
																							goto IL_217b;
																							IL_217b:
																							num6--;
																							goto end_IL_093a;
																							IL_1757:
																							((delegate*<void>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																							num = 281;
																							goto IL_1775;
																							IL_1775:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_0cab:
																							if (27 < b)
																							{
																								goto IL_0cb9;
																							}
																							goto IL_14d6;
																							IL_0cb9:
																							if (29 < b)
																							{
																								goto IL_0cc4;
																							}
																							num = 496;
																							goto IL_2050;
																							IL_0cc4:
																							if (30 < b)
																							{
																								break;
																							}
																							goto IL_0cd2;
																							IL_0cd2:
																							if (30 > b)
																							{
																								break;
																							}
																							goto IL_0cf0;
																							IL_0cf0:
																							array2[num6 - 1] = 5;
																							num = 284;
																							goto IL_0d0d;
																							IL_0d0d:
																							array3[num6 - 1] = ((delegate*<NetPlayer, Player>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((NetPlayer)array3[num6 - 1]);
																							goto IL_0d45;
																							IL_0d45:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_2002:
																							global::_003CModule_003E.player_92 = (Player)array3[num6 - 1];
																							goto IL_201b;
																							IL_2050:
																							if (29 <= b)
																							{
																								goto IL_205b;
																							}
																							goto IL_20c3;
																							IL_205b:
																							array2[num6 - 1] = 5;
																							num = 309;
																							goto IL_2078;
																							IL_2078:
																							array3[num6 - 1] = ((delegate*<VRRig, NetPlayer>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																							goto IL_20b0;
																							IL_20b0:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_20c3:
																							if (28 < b)
																							{
																								break;
																							}
																							goto IL_20d1;
																							IL_20d1:
																							if (28 > b)
																							{
																								break;
																							}
																							goto IL_20df;
																							IL_20df:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_20f7;
																							IL_20f7:
																							array2[num6] = 5;
																							goto IL_2105;
																							IL_2105:
																							num6++;
																							goto IL_2113;
																							IL_2113:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_14d6:
																							if (27 <= b)
																							{
																								num = 331;
																								goto IL_14ea;
																							}
																							goto IL_1550;
																							IL_201b:
																							num6--;
																							goto end_IL_093a;
																							IL_14ea:
																							array2[num6 - 1] = 0;
																							goto IL_14fe;
																							IL_14fe:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_153d;
																							IL_153d:
																							ptr2 += 8;
																							goto end_IL_093a;
																							IL_1550:
																							if (25 < b)
																							{
																								goto IL_155e;
																							}
																							goto IL_1eb3;
																							IL_155e:
																							if (26 < b)
																							{
																								break;
																							}
																							goto IL_156c;
																							IL_156c:
																							if (26 > b)
																							{
																								break;
																							}
																							goto IL_157a;
																							IL_157a:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_15ba;
																							IL_15ba:
																							array2[num6 - 2] = 3;
																							goto IL_15ce;
																							IL_15ce:
																							num6--;
																							goto end_IL_093a;
																						}
																						break;
																						IL_092a:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				continue;
																				end_IL_093a:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_24d3:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1b66:
			while (true)
			{
				IL_1b66_2:
				array = new byte[4];
				while (true)
				{
					IL_1b74:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_1e3a_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_095a_2:
									byte b = *ptr2;
									while (true)
									{
										IL_094a_2:
										ptr2++;
										while (true)
										{
											IL_093a_2:
											if (b >= 1)
											{
												while (b <= 62)
												{
													while (true)
													{
														IL_091a_2:
														if (31 < b)
														{
															while (true)
															{
																IL_090d_2:
																if (47 < b)
																{
																	while (true)
																	{
																		IL_08fd_2:
																		if (55 < b)
																		{
																			while (true)
																			{
																				IL_08ed_2:
																				if (59 >= b)
																				{
																					while (true)
																					{
																						IL_08dd_2:
																						if (59 > b)
																						{
																							while (true)
																							{
																								IL_08cd_2:
																								if (57 >= b)
																								{
																									while (true)
																									{
																										IL_08bd_2:
																										if (57 > b)
																										{
																											while (56 >= b)
																											{
																												num = 23;
																												while (56 <= b)
																												{
																													while (true)
																													{
																														IL_0881_2:
																														array2[num6] = 5;
																														num = 411;
																														while (true)
																														{
																															IL_0861_2:
																															array3[num6] = ((delegate*<FriendshipGroupDetection>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																															while (true)
																															{
																																IL_0851_2:
																																num6++;
																																while (true)
																																{
																																	IL_0838_2:
																																	ptr2 += 8;
																																	num = 514;
																																	while (num != 514)
																																	{
																																		if (num != 1495)
																																		{
																																			goto IL_136d_2;
																																		}
																																		switch (num)
																																		{
																																		case 120:
																																			goto IL_0838_2;
																																		case 421:
																																			goto IL_0851_2;
																																		case 411:
																																			goto IL_0861_2;
																																		case 13:
																																		case 244:
																																			goto IL_0881_2;
																																		case 23:
																																			goto IL_089a_2;
																																		case 368:
																																			goto IL_08aa_2;
																																		case 501:
																																			goto IL_08bd_2;
																																		case 239:
																																			goto IL_08cd_2;
																																		case 301:
																																			goto IL_08dd_2;
																																		case 353:
																																			goto IL_08ed_2;
																																		case 387:
																																			goto IL_08fd_2;
																																		case 317:
																																			goto IL_090d_2;
																																		case 54:
																																			goto IL_091a_2;
																																		case 150:
																																			goto IL_092a_2;
																																		case 450:
																																			goto IL_093a_2;
																																		case 440:
																																			goto IL_094a_2;
																																		case 16:
																																		case 354:
																																			goto IL_095a_2;
																																		case 33:
																																			goto IL_0965_2;
																																		case 15:
																																		case 82:
																																			goto IL_0973_2;
																																		case 128:
																																			goto IL_099e_2;
																																		case 65:
																																			goto IL_09ac_2;
																																		case 106:
																																			goto IL_09ba_2;
																																		case 25:
																																		case 158:
																																			goto IL_09c8_2;
																																		case 110:
																																			goto IL_09f1_2;
																																		case 224:
																																			goto IL_0a0a_2;
																																		case 251:
																																			goto IL_0a1d_2;
																																		case 294:
																																			goto IL_0a36_2;
																																		case 126:
																																			goto IL_0a44_2;
																																		case 6:
																																			goto IL_0a52_2;
																																		case 286:
																																			goto IL_0a60_2;
																																		case 135:
																																			goto IL_0a6e_2;
																																		case 209:
																																			goto IL_0a7c_2;
																																		case 304:
																																			goto IL_0a8c_2;
																																		case 249:
																																			goto IL_0a9a_2;
																																		case 218:
																																			goto IL_0aa8_2;
																																		case 280:
																																		case 310:
																																			goto IL_0abb_2;
																																		case 119:
																																			goto IL_0afb_2;
																																		case 98:
																																			goto IL_0b0f_2;
																																		case 89:
																																		case 323:
																																			goto IL_0b22_2;
																																		case 330:
																																			goto IL_0b45_2;
																																		case 67:
																																		case 156:
																																			goto IL_0b50_2;
																																		case 69:
																																			goto IL_0b69_2;
																																		case 87:
																																		case 337:
																																			goto IL_0b7c_2;
																																		case 153:
																																			goto IL_0b91_2;
																																		case 371:
																																			goto IL_0ba4_2;
																																		case 255:
																																			goto IL_0bb2_2;
																																		case 124:
																																			goto IL_0bbd_2;
																																		case 235:
																																			goto IL_0bd9_2;
																																		case 370:
																																			goto IL_0be7_2;
																																		case 57:
																																			goto IL_0bf5_2;
																																		case 346:
																																			goto IL_0c00_2;
																																		case 51:
																																			goto IL_0c13_2;
																																		case 46:
																																			goto IL_0c21_2;
																																		case 142:
																																			goto IL_0c2f_2;
																																		case 8:
																																		case 217:
																																			goto IL_0c3d_2;
																																		case 109:
																																			goto IL_0c98_2;
																																		case 75:
																																			goto IL_0cab_2;
																																		case 20:
																																			goto IL_0cb9_2;
																																		case 197:
																																			goto IL_0cc4_2;
																																		case 179:
																																			goto IL_0cd2_2;
																																		case 203:
																																		case 381:
																																			goto IL_0cf0_2;
																																		case 284:
																																			goto IL_0d0d_2;
																																		case 329:
																																			goto IL_0d45_2;
																																		case 262:
																																		case 382:
																																			goto IL_0d58_2;
																																		case 292:
																																			goto IL_0d70_2;
																																		case 295:
																																			goto IL_0d8e_2;
																																		case 384:
																																			goto IL_0db7_2;
																																		case 340:
																																			goto IL_0dc5_2;
																																		case 335:
																																		case 372:
																																			goto IL_0dd0_2;
																																		case 154:
																																			goto IL_0e13_2;
																																		case 192:
																																			goto IL_0e2a_2;
																																		case 39:
																																			goto IL_0e46_2;
																																		case 268:
																																			goto IL_0e5d_2;
																																		case 213:
																																		case 391:
																																			goto IL_0e70_2;
																																		case 62:
																																		case 392:
																																			goto IL_0ea0_2;
																																		case 211:
																																			goto IL_0eb9_2;
																																		case 352:
																																			goto IL_0ed0_2;
																																		case 399:
																																			goto IL_0ee3_2;
																																		case 302:
																																			goto IL_0eee_2;
																																		case 2:
																																		case 246:
																																			goto IL_0efc_2;
																																		case 333:
																																			goto IL_0f10_2;
																																		case 305:
																																			goto IL_0f58_2;
																																		case 12:
																																			goto IL_0f6b_2;
																																		case 380:
																																			goto IL_0f79_2;
																																		case 131:
																																		case 238:
																																			goto IL_0f87_2;
																																		case 91:
																																			goto IL_0f9b_2;
																																		case 356:
																																			goto IL_0fda_2;
																																		case 405:
																																			goto IL_0fed_2;
																																		case 137:
																																			goto IL_0ffb_2;
																																		case 22:
																																			goto IL_1009_2;
																																		case 70:
																																		case 133:
																																			goto IL_1017_2;
																																		case 408:
																																			goto IL_102f_2;
																																		case 430:
																																			goto IL_104c_2;
																																		case 152:
																																		case 308:
																																			goto IL_1057_2;
																																		case 282:
																																			goto IL_107b_2;
																																		case 336:
																																			goto IL_1089_2;
																																		case 420:
																																			goto IL_109c_2;
																																		case 199:
																																			goto IL_10a7_2;
																																		case 293:
																																			goto IL_10ba_2;
																																		case 210:
																																			goto IL_10c8_2;
																																		case 234:
																																			goto IL_10df_2;
																																		case 0:
																																		case 66:
																																			goto IL_10ed_2;
																																		case 422:
																																			goto IL_1101_2;
																																		case 347:
																																			goto IL_1149_2;
																																		case 36:
																																			goto IL_1165_2;
																																		case 115:
																																		case 328:
																																			goto IL_1170_2;
																																		case 225:
																																			goto IL_118a_2;
																																		case 222:
																																			goto IL_119d_2;
																																		case 312:
																																			goto IL_11ab_2;
																																		case 60:
																																		case 267:
																																			goto IL_11b9_2;
																																		case 269:
																																			goto IL_11f9_2;
																																		case 167:
																																			goto IL_120d_2;
																																		case 434:
																																			goto IL_1220_2;
																																		case 369:
																																		case 439:
																																			goto IL_1233_2;
																																		case 163:
																																			goto IL_1247_2;
																																		case 400:
																																			goto IL_127f_2;
																																		case 449:
																																			goto IL_1292_2;
																																		case 360:
																																		case 459:
																																			goto IL_12a5_2;
																																		case 461:
																																			goto IL_12c1_2;
																																		case 334:
																																		case 390:
																																			goto IL_12cf_2;
																																		case 429:
																																			goto IL_12e3_2;
																																		case 359:
																																			goto IL_132b_2;
																																		case 462:
																																			goto IL_133e_2;
																																		case 172:
																																		case 189:
																																			goto IL_1349_2;
																																		case 180:
																																			goto IL_136d_2;
																																		case 256:
																																			goto IL_137b_2;
																																		case 394:
																																			goto IL_1389_2;
																																		case 162:
																																			goto IL_139c_2;
																																		case 463:
																																			goto IL_13ac_2;
																																		case 466:
																																			goto IL_13bf_2;
																																		case 296:
																																		case 454:
																																			goto IL_13cd_2;
																																		case 94:
																																			goto IL_140d_2;
																																		case 446:
																																			goto IL_1421_2;
																																		case 164:
																																		case 467:
																																			goto IL_1434_2;
																																		case 415:
																																			goto IL_144d_2;
																																		case 468:
																																			goto IL_1460_2;
																																		case 141:
																																			goto IL_146e_2;
																																		case 130:
																																			goto IL_147c_2;
																																		case 419:
																																		case 471:
																																			goto IL_148f_2;
																																		case 205:
																																			goto IL_149d_2;
																																		case 401:
																																			goto IL_14b5_2;
																																		case 112:
																																			goto IL_14c3_2;
																																		case 473:
																																			goto IL_14d6_2;
																																		case 331:
																																		case 366:
																																			goto IL_14ea_2;
																																		case 11:
																																			goto IL_14fe_2;
																																		case 458:
																																			goto IL_153d_2;
																																		case 470:
																																			goto IL_1550_2;
																																		case 327:
																																			goto IL_155e_2;
																																		case 373:
																																			goto IL_156c_2;
																																		case 250:
																																		case 361:
																																			goto IL_157a_2;
																																		case 278:
																																			goto IL_15ba_2;
																																		case 314:
																																			goto IL_15ce_2;
																																		case 168:
																																		case 476:
																																			goto IL_15e1_2;
																																		case 272:
																																			goto IL_15f5_2;
																																		case 52:
																																			goto IL_1634_2;
																																		case 477:
																																			goto IL_1647_2;
																																		case 125:
																																			goto IL_1655_2;
																																		case 160:
																																		case 287:
																																			goto IL_1663_2;
																																		case 398:
																																			goto IL_16a1_2;
																																		case 479:
																																			goto IL_16b4_2;
																																		case 480:
																																			goto IL_16d0_2;
																																		case 177:
																																			goto IL_16de_2;
																																		case 184:
																																		case 457:
																																			goto IL_16e9_2;
																																		case 407:
																																			goto IL_1707_2;
																																		case 216:
																																			goto IL_1715_2;
																																		case 321:
																																			goto IL_1723_2;
																																		case 53:
																																			goto IL_1736_2;
																																		case 290:
																																			goto IL_1744_2;
																																		case 367:
																																		case 481:
																																			goto IL_1757_2;
																																		case 281:
																																			goto IL_1775_2;
																																		case 482:
																																			goto IL_1788_2;
																																		case 198:
																																			goto IL_1796_2;
																																		case 453:
																																			goto IL_17a4_2;
																																		case 455:
																																			goto IL_17b2_2;
																																		case 219:
																																		case 350:
																																			goto IL_17bd_2;
																																		case 181:
																																			goto IL_17e6_2;
																																		case 258:
																																			goto IL_17f4_2;
																																		case 426:
																																			goto IL_1807_2;
																																		case 116:
																																			goto IL_1812_2;
																																		case 215:
																																		case 410:
																																			goto IL_1820_2;
																																		case 395:
																																			goto IL_1839_2;
																																		case 248:
																																			goto IL_1847_2;
																																		case 339:
																																			goto IL_1855_2;
																																		case 143:
																																			goto IL_1868_2;
																																		case 472:
																																			goto IL_1876_2;
																																		case 79:
																																		case 187:
																																			goto IL_1884_2;
																																		case 318:
																																			goto IL_18cd_2;
																																		case 196:
																																			goto IL_18e1_2;
																																		case 365:
																																			goto IL_18f4_2;
																																		case 223:
																																			goto IL_18ff_2;
																																		case 18:
																																			goto IL_190d_2;
																																		case 232:
																																			goto IL_191b_2;
																																		case 1:
																																			goto IL_192e_2;
																																		case 85:
																																			goto IL_193c_2;
																																		case 136:
																																		case 276:
																																			goto IL_194a_2;
																																		case 201:
																																			goto IL_198a_2;
																																		case 374:
																																			goto IL_199e_2;
																																		case 483:
																																			goto IL_19b1_2;
																																		case 175:
																																			goto IL_19bf_2;
																																		case 138:
																																			goto IL_19cd_2;
																																		case 178:
																																			goto IL_19db_2;
																																		case 469:
																																			goto IL_19e6_2;
																																		case 227:
																																			goto IL_19f4_2;
																																		case 349:
																																		case 377:
																																			goto IL_1a0b_2;
																																		case 191:
																																		case 297:
																																			goto IL_1a1e_2;
																																		case 81:
																																			goto IL_1a5e_2;
																																		case 45:
																																			goto IL_1a72_2;
																																		case 375:
																																			goto IL_1a85_2;
																																		case 108:
																																			goto IL_1a93_2;
																																		case 47:
																																		case 303:
																																			goto IL_1aa1_2;
																																		case 95:
																																			goto IL_1b03_2;
																																		case 14:
																																			goto IL_1b16_2;
																																		case 348:
																																			goto IL_1b24_2;
																																		case 149:
																																			goto IL_1b32_2;
																																		case 107:
																																			goto IL_1b49_2;
																																		case 64:
																																		case 435:
																																			goto IL_1b57_2;
																																		case 5:
																																		case 182:
																																			goto IL_1c13_2;
																																		case 364:
																																			goto IL_1c31_2;
																																		case 357:
																																			goto IL_1c3f_2;
																																		case 285:
																																			goto IL_1c52_2;
																																		case 270:
																																			goto IL_1c60_2;
																																		case 165:
																																		case 274:
																																			goto IL_1c6e_2;
																																		case 253:
																																			goto IL_1c97_2;
																																		case 485:
																																			goto IL_1cb0_2;
																																		case 73:
																																			goto IL_1cbe_2;
																																		case 207:
																																		case 338:
																																			goto IL_1cc9_2;
																																		case 452:
																																			goto IL_1cdd_2;
																																		case 71:
																																			goto IL_1d1c_2;
																																		case 145:
																																			goto IL_1d2f_2;
																																		case 271:
																																			goto IL_1d3d_2;
																																		case 83:
																																		case 431:
																																			goto IL_1d4b_2;
																																		case 402:
																																			goto IL_1d83_2;
																																		case 166:
																																			goto IL_1d97_2;
																																		case 28:
																																			goto IL_1daa_2;
																																		case 102:
																																			goto IL_1db8_2;
																																		case 40:
																																		case 56:
																																			goto IL_1dc6_2;
																																		case 32:
																																			goto IL_1dda_2;
																																		case 74:
																																			goto IL_1e19_2;
																																		case 486:
																																			goto end_IL_24d3_2;
																																		case 451:
																																			goto IL_1e3a_2;
																																		case 113:
																																		case 487:
																																			goto IL_1e4d_2;
																																		case 92:
																																			goto IL_1e61_2;
																																		case 148:
																																			goto IL_1ea0_2;
																																		case 488:
																																			goto IL_1eb3_2;
																																		case 243:
																																			goto IL_1ec1_2;
																																		case 289:
																																			goto IL_1ecf_2;
																																		case 386:
																																		case 484:
																																			goto IL_1edd_2;
																																		case 427:
																																			goto IL_1ef6_2;
																																		case 322:
																																			goto IL_1f04_2;
																																		case 220:
																																			goto IL_1f12_2;
																																		case 489:
																																			goto IL_1f25_2;
																																		case 170:
																																		case 326:
																																			goto IL_1f33_2;
																																		case 30:
																																			goto IL_1f6c_2;
																																		case 491:
																																			goto IL_1f7f_2;
																																		case 376:
																																			goto IL_1f8d_2;
																																		case 214:
																																		case 378:
																																			goto IL_1f9b_2;
																																		case 393:
																																			goto IL_1fef_2;
																																		case 202:
																																		case 492:
																																			goto IL_2002_2;
																																		case 55:
																																			goto IL_201b_2;
																																		case 493:
																																			goto IL_202e_2;
																																		case 496:
																																			goto IL_2050_2;
																																		case 100:
																																		case 320:
																																			goto IL_205b_2;
																																		case 309:
																																			goto IL_2078_2;
																																		case 358:
																																			goto IL_20b0_2;
																																		case 195:
																																			goto IL_20c3_2;
																																		case 403:
																																			goto IL_20d1_2;
																																		case 122:
																																		case 443:
																																			goto IL_20df_2;
																																		case 193:
																																			goto IL_20f7_2;
																																		case 61:
																																			goto IL_2105_2;
																																		case 146:
																																			goto IL_2113_2;
																																		case 194:
																																		case 497:
																																			goto IL_2126_2;
																																		case 9:
																																			goto IL_2167_2;
																																		case 21:
																																			goto IL_217b_2;
																																		case 129:
																																		case 499:
																																			goto IL_218e_2;
																																		case 10:
																																			goto IL_21ce_2;
																																		case 291:
																																			goto IL_21e2_2;
																																		case 78:
																																		case 502:
																																			goto IL_21f5_2;
																																		case 404:
																																			goto IL_2203_2;
																																		case 406:
																																			goto IL_2226_2;
																																		case 345:
																																			goto IL_2230_2;
																																		case 413:
																																			goto IL_223e_2;
																																		case 236:
																																		case 503:
																																			goto IL_2251_2;
																																		case 80:
																																			goto IL_2291_2;
																																		case 265:
																																			goto IL_22a5_2;
																																		case 417:
																																		case 505:
																																			goto IL_22b8_2;
																																		case 311:
																																			goto IL_22cc_2;
																																		case 68:
																																			goto IL_230b_2;
																																		case 506:
																																			goto IL_231e_2;
																																		case 388:
																																			goto IL_2398_2;
																																		case 241:
																																			goto IL_23a6_2;
																																		case 176:
																																			goto IL_23b9_2;
																																		case 332:
																																			goto IL_23c7_2;
																																		case 298:
																																			goto IL_23d2_2;
																																		case 341:
																																			goto IL_23e0_2;
																																		case 188:
																																		case 300:
																																			goto IL_23ee_2;
																																		case 362:
																																			goto IL_23f8_2;
																																		case 4:
																																			goto IL_2406_2;
																																		case 96:
																																		case 299:
																																			goto IL_2419_2;
																																		case 59:
																																			goto IL_242d_2;
																																		case 355:
																																			goto IL_2483_2;
																																		case 117:
																																			goto IL_2491_2;
																																		case 104:
																																			goto IL_24a1_2;
																																		case 456:
																																			goto IL_24ac_2;
																																		case 17:
																																		case 19:
																																		case 26:
																																		case 27:
																																		case 31:
																																		case 35:
																																		case 38:
																																		case 43:
																																		case 44:
																																		case 49:
																																		case 50:
																																		case 58:
																																		case 77:
																																		case 84:
																																		case 86:
																																		case 90:
																																		case 105:
																																		case 123:
																																		case 132:
																																		case 140:
																																		case 147:
																																		case 151:
																																		case 157:
																																		case 159:
																																		case 171:
																																		case 173:
																																		case 174:
																																		case 185:
																																		case 200:
																																		case 204:
																																		case 206:
																																		case 212:
																																		case 221:
																																		case 226:
																																		case 229:
																																		case 231:
																																		case 233:
																																		case 240:
																																		case 245:
																																		case 247:
																																		case 252:
																																		case 257:
																																		case 259:
																																		case 260:
																																		case 261:
																																		case 273:
																																		case 275:
																																		case 277:
																																		case 283:
																																		case 288:
																																		case 307:
																																		case 324:
																																		case 325:
																																		case 342:
																																		case 344:
																																		case 351:
																																		case 414:
																																		case 418:
																																		case 424:
																																		case 441:
																																		case 475:
																																		case 478:
																																		case 490:
																																		case 495:
																																		case 504:
																																			goto end_IL_089a_2;
																																		case 7:
																																		case 24:
																																		case 29:
																																		case 34:
																																		case 37:
																																		case 41:
																																		case 42:
																																		case 48:
																																		case 63:
																																		case 72:
																																		case 76:
																																		case 88:
																																		case 93:
																																		case 97:
																																		case 99:
																																		case 101:
																																		case 103:
																																		case 111:
																																		case 114:
																																		case 118:
																																		case 121:
																																		case 134:
																																		case 139:
																																		case 144:
																																		case 155:
																																		case 161:
																																		case 169:
																																		case 183:
																																		case 186:
																																		case 190:
																																		case 208:
																																		case 228:
																																		case 230:
																																		case 254:
																																		case 266:
																																		case 306:
																																		case 315:
																																		case 316:
																																		case 319:
																																		case 343:
																																		case 363:
																																		case 379:
																																		case 383:
																																		case 389:
																																		case 396:
																																		case 397:
																																		case 409:
																																		case 412:
																																		case 416:
																																		case 423:
																																		case 425:
																																		case 428:
																																		case 432:
																																		case 437:
																																		case 442:
																																		case 444:
																																		case 445:
																																		case 460:
																																		case 464:
																																		case 465:
																																		case 474:
																																		case 498:
																																		case 500:
																																		case 507:
																																			goto end_IL_0825_2;
																																		case 433:
																																			ptr2 = ptr;
																																			num = 343;
																																			goto end_IL_0825_2;
																																		case 494:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetParentTokenGetPathRoot.RenewalgetNumberNegativePattern);
																																			num = 433;
																																			goto case 433;
																																		case 438:
																																			array7[0] = vrrig_0;
																																			goto case 494;
																																		case 385:
																																			array7 = new object[21];
																																			goto case 438;
																																		case 127:
																																			array6 = new long[8];
																																			goto case 385;
																																		case 264:
																																			array5 = new int[7];
																																			goto case 127;
																																		case 279:
																																			array4 = new int[8];
																																			goto case 264;
																																		case 237:
																																			array3 = new object[8];
																																			goto case 279;
																																		case 313:
																																			array2 = new byte[8];
																																			goto case 237;
																																		case 3:
																																			num4 = num2 * 8;
																																			goto case 313;
																																		case 436:
																																			num3 = num2 * 4;
																																			goto case 3;
																																		case 447:
																																			num2 = 1;
																																			goto case 436;
																																		case 448:
																																			goto end_IL_1e2c;
																																		case 242:
																																		case 263:
																																			return;
																																		}
																																		continue;
																																		end_IL_0825_2:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_093a_2;
																													continue;
																													end_IL_089a_2:
																													break;
																													IL_089a_2:;
																												}
																												break;
																												IL_08aa_2:;
																											}
																											break;
																										}
																										goto IL_1434_2;
																										IL_144d_2:
																										num6--;
																										goto end_IL_093a_2;
																										IL_1434_2:
																										global::_003CModule_003E.friendshipGroupDetection_1 = (FriendshipGroupDetection)array3[num6 - 1];
																										goto IL_144d_2;
																									}
																									break;
																								}
																								goto IL_0a0a_2;
																								IL_132b_2:
																								ptr2 += 8;
																								goto end_IL_093a_2;
																								IL_0a0a_2:
																								if (58 < b)
																								{
																									break;
																								}
																								goto IL_12c1_2;
																								IL_12c1_2:
																								if (58 > b)
																								{
																									break;
																								}
																								goto IL_12cf_2;
																								IL_12cf_2:
																								array2[num6 - 1] = 3;
																								goto IL_12e3_2;
																								IL_12e3_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 359;
																								goto IL_132b_2;
																							}
																							break;
																						}
																						goto IL_0b7c_2;
																						IL_0b91_2:
																						ptr2 += 8;
																						goto end_IL_093a_2;
																						IL_0b7c_2:
																						((delegate*<void>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																						goto IL_0b91_2;
																					}
																					break;
																				}
																				goto IL_23b9_2;
																				IL_24ac_2:
																				if (62 <= b)
																				{
																					num = 212;
																				}
																				break;
																				IL_23b9_2:
																				if (61 >= b)
																				{
																					goto IL_23c7_2;
																				}
																				goto IL_24a1_2;
																				IL_23c7_2:
																				if (61 > b)
																				{
																					goto IL_23d2_2;
																				}
																				goto IL_2419_2;
																				IL_23d2_2:
																				if (60 < b)
																				{
																					break;
																				}
																				goto IL_23e0_2;
																				IL_23e0_2:
																				if (60 > b)
																				{
																					break;
																				}
																				goto IL_23ee_2;
																				IL_23ee_2:
																				array3[num6] = null;
																				goto IL_23f8_2;
																				IL_23f8_2:
																				array2[num6] = 5;
																				goto IL_2406_2;
																				IL_2406_2:
																				num6++;
																				goto end_IL_093a_2;
																				IL_2419_2:
																				array2[num6 - 2] = 0;
																				goto IL_242d_2;
																				IL_242d_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(FriendshipGroupDetection)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																				num = 355;
																				goto IL_2483_2;
																				IL_2483_2:
																				num6--;
																				goto IL_2491_2;
																				IL_2491_2:
																				ptr2 += 8;
																				goto end_IL_093a_2;
																				IL_24a1_2:
																				if (62 < b)
																				{
																					break;
																				}
																				goto IL_24ac_2;
																			}
																			break;
																		}
																		goto IL_099e_2;
																		IL_202e_2:
																		array2[num6 - 1] = 0;
																		num = 409;
																		goto end_IL_093a_2;
																		IL_099e_2:
																		if (55 > b)
																		{
																			goto IL_09ac_2;
																		}
																		goto IL_0e70_2;
																		IL_09ac_2:
																		if (51 >= b)
																		{
																			goto IL_09ba_2;
																		}
																		goto IL_0a8c_2;
																		IL_09ba_2:
																		if (51 <= b)
																		{
																			goto IL_09c8_2;
																		}
																		goto IL_0ee3_2;
																		IL_09c8_2:
																		array3[num6 - 1] = (short)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_09f1_2;
																		IL_09f1_2:
																		array2[num6 - 1] = 5;
																		goto end_IL_093a_2;
																		IL_0ee3_2:
																		if (49 >= b)
																		{
																			goto IL_0eee_2;
																		}
																		goto IL_0f6b_2;
																		IL_0eee_2:
																		if (49 <= b)
																		{
																			goto IL_0efc_2;
																		}
																		goto IL_1647_2;
																		IL_0efc_2:
																		array2[num6 - 1] = 3;
																		goto IL_0f10_2;
																		IL_0f10_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		num = 305;
																		goto IL_0f58_2;
																		IL_0f58_2:
																		ptr2 += 8;
																		goto end_IL_093a_2;
																		IL_1647_2:
																		if (48 < b)
																		{
																			break;
																		}
																		goto IL_1655_2;
																		IL_1655_2:
																		if (48 > b)
																		{
																			break;
																		}
																		goto IL_1663_2;
																		IL_1663_2:
																		((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_16a1_2;
																		IL_16a1_2:
																		num6 -= 3;
																		goto end_IL_093a_2;
																		IL_0f6b_2:
																		if (50 < b)
																		{
																			break;
																		}
																		goto IL_0f79_2;
																		IL_0f79_2:
																		if (50 > b)
																		{
																			break;
																		}
																		goto IL_0f87_2;
																		IL_0f87_2:
																		array2[num6 - 1] = 0;
																		goto IL_0f9b_2;
																		IL_0f9b_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0fda_2;
																		IL_0fda_2:
																		ptr2 += 8;
																		goto end_IL_093a_2;
																		IL_0a8c_2:
																		if (53 < b)
																		{
																			goto IL_0a9a_2;
																		}
																		goto IL_0b45_2;
																		IL_0a9a_2:
																		if (54 < b)
																		{
																			break;
																		}
																		goto IL_0aa8_2;
																		IL_0aa8_2:
																		if (54 > b)
																		{
																			break;
																		}
																		goto IL_12a5_2;
																		IL_12a5_2:
																		num7 = ptr2;
																		num8 = -200;
																		num5 = 1;
																		ptr2 = num7 + num8;
																		goto end_IL_093a_2;
																		IL_0b45_2:
																		if (53 <= b)
																		{
																			goto IL_0b50_2;
																		}
																		goto IL_0b69_2;
																		IL_0b50_2:
																		array2[num6 - 4] = 0;
																		goto IL_231e_2;
																		IL_231e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, Player, object[], bool>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], (Player)array3[num6 - 2], (object[])array3[num6 - 1]) ? 1 : 0);
																		goto IL_2398_2;
																		IL_2398_2:
																		num6 -= 3;
																		goto IL_23a6_2;
																		IL_23a6_2:
																		ptr2 += 8;
																		goto end_IL_093a_2;
																		IL_0b69_2:
																		if (52 < b)
																		{
																			break;
																		}
																		goto IL_1f25_2;
																		IL_1f25_2:
																		if (52 > b)
																		{
																			break;
																		}
																		goto IL_1f33_2;
																		IL_1f33_2:
																		((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																		goto IL_1f6c_2;
																		IL_1f6c_2:
																		num6 -= 3;
																		goto end_IL_093a_2;
																		IL_0e70_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_202e_2;
																	}
																	break;
																}
																goto IL_0965_2;
																IL_11b9_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_11f9_2;
																IL_0965_2:
																if (47 <= b)
																{
																	goto IL_0973_2;
																}
																goto IL_0a36_2;
																IL_0973_2:
																array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_0a1d_2;
																IL_0a1d_2:
																array2[num6 - 1] = 5;
																goto end_IL_093a_2;
																IL_0a36_2:
																if (39 < b)
																{
																	goto IL_0a44_2;
																}
																goto IL_104c_2;
																IL_0a44_2:
																if (43 >= b)
																{
																	goto IL_0a52_2;
																}
																goto IL_1cb0_2;
																IL_0a52_2:
																if (43 > b)
																{
																	goto IL_0a60_2;
																}
																goto IL_0b22_2;
																IL_0a60_2:
																if (41 < b)
																{
																	goto IL_0a6e_2;
																}
																goto IL_133e_2;
																IL_0a6e_2:
																if (42 < b)
																{
																	break;
																}
																goto IL_0a7c_2;
																IL_0a7c_2:
																if (42 > b)
																{
																	break;
																}
																goto IL_0abb_2;
																IL_0abb_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0afb_2;
																IL_0afb_2:
																array2[num6 - 2] = 3;
																goto IL_0b0f_2;
																IL_0b0f_2:
																num6--;
																goto end_IL_093a_2;
																IL_133e_2:
																if (41 <= b)
																{
																	goto IL_1349_2;
																}
																goto IL_139c_2;
																IL_1349_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																goto IL_136d_2;
																IL_136d_2:
																array2[num6] = 0;
																goto IL_137b_2;
																IL_137b_2:
																num6++;
																goto IL_1389_2;
																IL_1389_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_139c_2:
																if (40 < b)
																{
																	break;
																}
																goto IL_13bf_2;
																IL_13bf_2:
																if (40 > b)
																{
																	break;
																}
																goto IL_13cd_2;
																IL_13cd_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_140d_2;
																IL_140d_2:
																array2[num6 - 2] = 3;
																goto IL_1421_2;
																IL_1421_2:
																num6--;
																goto end_IL_093a_2;
																IL_0b22_2:
																array3[num6] = ((delegate*<FriendshipGroupDetection>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																goto IL_1460_2;
																IL_1460_2:
																array2[num6] = 5;
																goto IL_146e_2;
																IL_146e_2:
																num6++;
																goto IL_147c_2;
																IL_147c_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_1cb0_2:
																if (45 >= b)
																{
																	goto IL_1cbe_2;
																}
																goto IL_1daa_2;
																IL_1cbe_2:
																if (45 <= b)
																{
																	goto IL_1cc9_2;
																}
																goto IL_1d2f_2;
																IL_1cc9_2:
																array2[num6 - 1] = 3;
																goto IL_1cdd_2;
																IL_1cdd_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1d1c_2;
																IL_1d1c_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_1d2f_2:
																if (44 < b)
																{
																	break;
																}
																goto IL_1d3d_2;
																IL_1d3d_2:
																if (44 > b)
																{
																	break;
																}
																goto IL_1d4b_2;
																IL_1d4b_2:
																array3[num6 - 1] = ((delegate*<FriendshipGroupDetection, PhotonView>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((FriendshipGroupDetection)array3[num6 - 1]);
																goto IL_1d83_2;
																IL_1d83_2:
																array2[num6 - 1] = 5;
																goto IL_1d97_2;
																IL_1d97_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_1daa_2:
																if (46 < b)
																{
																	break;
																}
																goto IL_1db8_2;
																IL_1db8_2:
																if (46 > b)
																{
																	break;
																}
																goto IL_1dc6_2;
																IL_1dc6_2:
																array2[num6 - 1] = 0;
																goto IL_1dda_2;
																IL_1dda_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1e19_2;
																IL_1e19_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_104c_2:
																if (39 <= b)
																{
																	goto IL_1057_2;
																}
																goto IL_109c_2;
																IL_1057_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																goto IL_107b_2;
																IL_107b_2:
																array2[num6] = 0;
																goto IL_1089_2;
																IL_1089_2:
																num6++;
																goto IL_1220_2;
																IL_1220_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_109c_2:
																if (35 >= b)
																{
																	goto IL_10a7_2;
																}
																goto IL_10ba_2;
																IL_10a7_2:
																if (35 <= b)
																{
																	goto IL_15e1_2;
																}
																goto IL_16d0_2;
																IL_15e1_2:
																array2[num6 - 1] = 3;
																goto IL_15f5_2;
																IL_15f5_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1634_2;
																IL_1634_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_16d0_2:
																if (33 >= b)
																{
																	goto IL_16de_2;
																}
																goto IL_1f7f_2;
																IL_16de_2:
																if (33 <= b)
																{
																	goto IL_16e9_2;
																}
																goto IL_1736_2;
																IL_16e9_2:
																array3[num6] = ((delegate*<Player>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
																goto IL_1707_2;
																IL_1707_2:
																array2[num6] = 5;
																goto IL_1715_2;
																IL_1715_2:
																num6++;
																goto IL_1723_2;
																IL_1723_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_1736_2:
																if (32 < b)
																{
																	break;
																}
																goto IL_1744_2;
																IL_1744_2:
																if (32 > b)
																{
																	break;
																}
																goto IL_1e4d_2;
																IL_1e4d_2:
																array2[num6 - 1] = 3;
																goto IL_1e61_2;
																IL_1e61_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1ea0_2;
																IL_1ea0_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_1f7f_2:
																if (34 < b)
																{
																	break;
																}
																goto IL_1f8d_2;
																IL_1f8d_2:
																if (34 > b)
																{
																	break;
																}
																goto IL_1f9b_2;
																IL_1f9b_2:
																ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_1fef_2;
																IL_1fef_2:
																num6--;
																goto end_IL_093a_2;
																IL_10ba_2:
																if (37 < b)
																{
																	goto IL_10c8_2;
																}
																num = 36;
																goto IL_1165_2;
																IL_10c8_2:
																if (38 < b)
																{
																	break;
																}
																num = 234;
																goto IL_10df_2;
																IL_120d_2:
																num6--;
																goto end_IL_093a_2;
																IL_10df_2:
																if (38 > b)
																{
																	break;
																}
																goto IL_10ed_2;
																IL_10ed_2:
																array2[num6 - 1] = 3;
																goto IL_1101_2;
																IL_1101_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																num = 347;
																goto IL_1149_2;
																IL_1149_2:
																ptr2 += 8;
																goto end_IL_093a_2;
																IL_11f9_2:
																array2[num6 - 2] = 3;
																goto IL_120d_2;
																IL_1165_2:
																if (37 <= b)
																{
																	goto IL_1170_2;
																}
																goto IL_119d_2;
																IL_1170_2:
																global::_003CModule_003E.int_206 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_118a_2;
																IL_118a_2:
																num6--;
																goto end_IL_093a_2;
																IL_119d_2:
																if (36 < b)
																{
																	break;
																}
																goto IL_11ab_2;
																IL_11ab_2:
																if (36 > b)
																{
																	break;
																}
																goto IL_11b9_2;
															}
															break;
														}
														goto IL_0ba4_2;
														IL_1edd_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_1ef6_2;
														IL_0ba4_2:
														if (31 > b)
														{
															goto IL_0bb2_2;
														}
														goto IL_2002_2;
														IL_0bb2_2:
														if (15 >= b)
														{
															goto IL_0bbd_2;
														}
														goto IL_0bd9_2;
														IL_0bbd_2:
														if (15 <= b)
														{
															num = 382;
															goto IL_0d58_2;
														}
														goto IL_1788_2;
														IL_1ef6_2:
														array2[num6] = 3;
														goto IL_1f04_2;
														IL_0d58_2:
														array2[num6] = array2[num6 - 1];
														goto IL_0d70_2;
														IL_0d70_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_0d8e_2;
														IL_0d8e_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_102f_2;
														IL_102f_2:
														array3[num6] = array3[num6 - 1];
														goto IL_16b4_2;
														IL_16b4_2:
														num6++;
														num = 99;
														goto end_IL_093a_2;
														IL_1788_2:
														if (7 >= b)
														{
															goto IL_1796_2;
														}
														goto IL_19b1_2;
														IL_1796_2:
														if (7 > b)
														{
															goto IL_17a4_2;
														}
														goto IL_218e_2;
														IL_17a4_2:
														if (3 >= b)
														{
															goto IL_17b2_2;
														}
														goto IL_18f4_2;
														IL_17b2_2:
														if (3 <= b)
														{
															goto IL_17bd_2;
														}
														goto IL_1807_2;
														IL_17bd_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_17e6_2;
														IL_17e6_2:
														ptr2 += 8;
														goto IL_17f4_2;
														IL_17f4_2:
														num6--;
														goto end_IL_093a_2;
														IL_1807_2:
														if (1 >= b)
														{
															goto IL_1812_2;
														}
														goto IL_1868_2;
														IL_1812_2:
														if (1 > b)
														{
															break;
														}
														goto IL_1820_2;
														IL_1820_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_1839_2;
														IL_1839_2:
														array2[num6] = 0;
														goto IL_1847_2;
														IL_1847_2:
														num6++;
														goto IL_1855_2;
														IL_1855_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_1868_2:
														if (2 < b)
														{
															break;
														}
														goto IL_1876_2;
														IL_1876_2:
														if (2 > b)
														{
															break;
														}
														goto IL_1884_2;
														IL_1884_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 318;
														goto IL_18cd_2;
														IL_18cd_2:
														array2[num6 - 2] = 0;
														goto IL_18e1_2;
														IL_18e1_2:
														num6--;
														goto end_IL_093a_2;
														IL_18f4_2:
														if (5 >= b)
														{
															goto IL_18ff_2;
														}
														goto IL_192e_2;
														IL_18ff_2:
														if (5 > b)
														{
															goto IL_190d_2;
														}
														goto IL_2251_2;
														IL_190d_2:
														if (4 < b)
														{
															break;
														}
														goto IL_191b_2;
														IL_191b_2:
														if (4 > b)
														{
															break;
														}
														goto IL_21f5_2;
														IL_21f5_2:
														array2[num6] = 0;
														goto IL_2203_2;
														IL_2203_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_2226_2;
														IL_2226_2:
														array3[num6] = null;
														goto IL_2230_2;
														IL_2230_2:
														num6++;
														goto IL_223e_2;
														IL_223e_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_2251_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2291_2;
														IL_2291_2:
														array2[num6 - 2] = 0;
														goto IL_22a5_2;
														IL_22a5_2:
														num6--;
														goto end_IL_093a_2;
														IL_192e_2:
														if (6 < b)
														{
															break;
														}
														goto IL_193c_2;
														IL_193c_2:
														if (6 > b)
														{
															break;
														}
														goto IL_194a_2;
														IL_194a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_198a_2;
														IL_198a_2:
														array2[num6 - 2] = 0;
														goto IL_199e_2;
														IL_199e_2:
														num6--;
														goto end_IL_093a_2;
														IL_218e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_21ce_2;
														IL_21ce_2:
														array2[num6 - 2] = 0;
														goto IL_21e2_2;
														IL_21e2_2:
														num6--;
														goto end_IL_093a_2;
														IL_19b1_2:
														if (11 >= b)
														{
															goto IL_19bf_2;
														}
														goto IL_1b16_2;
														IL_19bf_2:
														if (11 <= b)
														{
															goto end_IL_093a_2;
														}
														goto IL_19cd_2;
														IL_19cd_2:
														if (9 >= b)
														{
															goto IL_19db_2;
														}
														goto IL_1a85_2;
														IL_19db_2:
														if (9 > b)
														{
															goto IL_19e6_2;
														}
														goto IL_1a1e_2;
														IL_19e6_2:
														if (8 < b)
														{
															break;
														}
														goto IL_19f4_2;
														IL_19f4_2:
														if (8 > b)
														{
															break;
														}
														num = 377;
														goto IL_1a0b_2;
														IL_1f04_2:
														num6++;
														goto IL_1f12_2;
														IL_1a0b_2:
														num6--;
														goto end_IL_093a_2;
														IL_1a1e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1a5e_2;
														IL_1a5e_2:
														array2[num6 - 2] = 0;
														goto IL_1a72_2;
														IL_1a72_2:
														num6--;
														goto end_IL_093a_2;
														IL_1a85_2:
														if (10 < b)
														{
															break;
														}
														goto IL_1a93_2;
														IL_1a93_2:
														if (10 > b)
														{
															break;
														}
														goto IL_1aa1_2;
														IL_1aa1_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1b03_2;
														IL_1b03_2:
														num6 -= 2;
														goto end_IL_093a_2;
														IL_1b16_2:
														if (13 >= b)
														{
															goto IL_1b24_2;
														}
														goto IL_1c52_2;
														IL_1b24_2:
														if (13 > b)
														{
															goto IL_1b32_2;
														}
														goto IL_1c13_2;
														IL_1b32_2:
														if (12 < b)
														{
															break;
														}
														num = 107;
														goto IL_1b49_2;
														IL_1f12_2:
														ptr2 += 16;
														goto end_IL_093a_2;
														IL_1b49_2:
														if (12 > b)
														{
															break;
														}
														goto IL_1b57_2;
														IL_1b57_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_1b66_2;
														}
														goto IL_1b74;
														IL_1c13_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_1c31_2;
														IL_1c31_2:
														ptr2 += 8;
														goto IL_1c3f_2;
														IL_1c3f_2:
														num6--;
														goto end_IL_093a_2;
														IL_1c52_2:
														if (14 < b)
														{
															break;
														}
														goto IL_1c60_2;
														IL_1c60_2:
														if (14 > b)
														{
															break;
														}
														goto IL_1c6e_2;
														IL_1c6e_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1c97_2;
														IL_1c97_2:
														array2[num6 - 1] = 5;
														goto end_IL_093a_2;
														IL_0bd9_2:
														if (23 >= b)
														{
															goto IL_0be7_2;
														}
														goto IL_0cab_2;
														IL_0be7_2:
														if (23 > b)
														{
															goto IL_0bf5_2;
														}
														goto IL_1757_2;
														IL_0bf5_2:
														if (19 >= b)
														{
															goto IL_0c00_2;
														}
														goto IL_0c13_2;
														IL_0c00_2:
														if (19 > b)
														{
															goto IL_0db7_2;
														}
														goto IL_0ea0_2;
														IL_0ea0_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_0eb9_2;
														IL_0eb9_2:
														array2[num6] = 1;
														num = 352;
														goto IL_0ed0_2;
														IL_0ed0_2:
														num6++;
														goto IL_1292_2;
														IL_1292_2:
														ptr2 += 16;
														goto end_IL_093a_2;
														IL_0db7_2:
														if (17 >= b)
														{
															goto IL_0dc5_2;
														}
														goto IL_0e46_2;
														IL_0dc5_2:
														if (17 <= b)
														{
															goto IL_0dd0_2;
														}
														goto IL_0e13_2;
														IL_0dd0_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_13ac_2;
														IL_13ac_2:
														num6 -= 3;
														goto end_IL_093a_2;
														IL_0e13_2:
														if (16 < b)
														{
															break;
														}
														num = 192;
														goto IL_0e2a_2;
														IL_22b8_2:
														array2[num6 - 1] = 3;
														goto IL_22cc_2;
														IL_0e2a_2:
														if (16 > b)
														{
															break;
														}
														num = 419;
														goto IL_148f_2;
														IL_22cc_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_230b_2;
														IL_148f_2:
														array2[num6] = 5;
														goto IL_149d_2;
														IL_149d_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_14b5_2;
														IL_14b5_2:
														num6++;
														goto IL_14c3_2;
														IL_14c3_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_0e46_2:
														if (18 < b)
														{
															break;
														}
														num = 268;
														goto IL_0e5d_2;
														IL_230b_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_0e5d_2:
														if (18 > b)
														{
															break;
														}
														goto IL_1233_2;
														IL_1233_2:
														array2[num6 - 1] = 5;
														goto IL_1247_2;
														IL_1247_2:
														array3[num6 - 1] = ((delegate*<string[], string>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_127f_2;
														IL_127f_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_0c13_2:
														if (21 < b)
														{
															goto IL_0c21_2;
														}
														goto IL_0fed_2;
														IL_0c21_2:
														if (22 < b)
														{
															break;
														}
														goto IL_0c2f_2;
														IL_0c2f_2:
														if (22 > b)
														{
															break;
														}
														goto IL_0c3d_2;
														IL_0c3d_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														num = 109;
														goto IL_0c98_2;
														IL_0c98_2:
														num6--;
														goto end_IL_093a_2;
														IL_0fed_2:
														if (21 > b)
														{
															goto IL_0ffb_2;
														}
														goto IL_2126_2;
														IL_0ffb_2:
														if (20 < b)
														{
															break;
														}
														goto IL_1009_2;
														IL_1009_2:
														if (20 > b)
														{
															break;
														}
														goto IL_1017_2;
														IL_1017_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto end_IL_093a_2;
														IL_2126_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_2167_2;
														IL_2167_2:
														array2[num6 - 2] = 0;
														goto IL_217b_2;
														IL_217b_2:
														num6--;
														goto end_IL_093a_2;
														IL_1757_2:
														((delegate*<void>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])();
														num = 281;
														goto IL_1775_2;
														IL_1775_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_0cab_2:
														if (27 < b)
														{
															goto IL_0cb9_2;
														}
														goto IL_14d6_2;
														IL_0cb9_2:
														if (29 < b)
														{
															goto IL_0cc4_2;
														}
														num = 496;
														goto IL_2050_2;
														IL_0cc4_2:
														if (30 < b)
														{
															break;
														}
														goto IL_0cd2_2;
														IL_0cd2_2:
														if (30 > b)
														{
															break;
														}
														goto IL_0cf0_2;
														IL_0cf0_2:
														array2[num6 - 1] = 5;
														num = 284;
														goto IL_0d0d_2;
														IL_0d0d_2:
														array3[num6 - 1] = ((delegate*<NetPlayer, Player>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((NetPlayer)array3[num6 - 1]);
														goto IL_0d45_2;
														IL_0d45_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_2002_2:
														global::_003CModule_003E.player_92 = (Player)array3[num6 - 1];
														goto IL_201b_2;
														IL_2050_2:
														if (29 <= b)
														{
															goto IL_205b_2;
														}
														goto IL_20c3_2;
														IL_205b_2:
														array2[num6 - 1] = 5;
														num = 309;
														goto IL_2078_2;
														IL_2078_2:
														array3[num6 - 1] = ((delegate*<VRRig, NetPlayer>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
														goto IL_20b0_2;
														IL_20b0_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_20c3_2:
														if (28 < b)
														{
															break;
														}
														goto IL_20d1_2;
														IL_20d1_2:
														if (28 > b)
														{
															break;
														}
														goto IL_20df_2;
														IL_20df_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_20f7_2;
														IL_20f7_2:
														array2[num6] = 5;
														goto IL_2105_2;
														IL_2105_2:
														num6++;
														goto IL_2113_2;
														IL_2113_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_14d6_2:
														if (27 <= b)
														{
															num = 331;
															goto IL_14ea_2;
														}
														goto IL_1550_2;
														IL_201b_2:
														num6--;
														goto end_IL_093a_2;
														IL_14ea_2:
														array2[num6 - 1] = 0;
														goto IL_14fe_2;
														IL_14fe_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)AssemblyAlgorithmIdAttributeAsDecimal[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_153d_2;
														IL_153d_2:
														ptr2 += 8;
														goto end_IL_093a_2;
														IL_1550_2:
														if (25 < b)
														{
															goto IL_155e_2;
														}
														goto IL_1eb3_2;
														IL_155e_2:
														if (26 < b)
														{
															break;
														}
														goto IL_156c_2;
														IL_156c_2:
														if (26 > b)
														{
															break;
														}
														goto IL_157a_2;
														IL_157a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_15ba_2;
														IL_15ba_2:
														array2[num6 - 2] = 3;
														goto IL_15ce_2;
														IL_15ce_2:
														num6--;
														goto end_IL_093a_2;
														IL_1eb3_2:
														if (25 > b)
														{
															goto IL_1ec1_2;
														}
														goto IL_22b8_2;
														IL_1ec1_2:
														if (24 < b)
														{
															break;
														}
														goto IL_1ecf_2;
														IL_1ecf_2:
														if (24 > b)
														{
															break;
														}
														goto IL_1edd_2;
													}
													break;
													IL_092a_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											break;
											continue;
											end_IL_093a_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_24d3_2:
								break;
							}
							break;
						}
						continue;
						end_IL_1e2c:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class153()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3)
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 101;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NumOverflowProcessorArchitectureAMD.BuiltinPowerUsersSidgetName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c8:
															byte b = *ptr2;
															while (true)
															{
																IL_02b8:
																ptr2++;
																while (true)
																{
																	IL_02a8:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0288:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0278:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0268:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_025b:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_0220:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_0207:
																															array[num5] = 0;
																															num = 96;
																															while (true)
																															{
																																IL_01f7:
																																num5++;
																																while (true)
																																{
																																	IL_01de:
																																	ptr2 += 8;
																																	num = 111;
																																	while (num != 111 && num == 1092)
																																	{
																																		switch (num)
																																		{
																																		case 62:
																																			goto IL_01de;
																																		case 96:
																																			goto IL_01f7;
																																		case 76:
																																			goto IL_0207;
																																		case 92:
																																		case 94:
																																			goto IL_0220;
																																		case 6:
																																			goto IL_023b;
																																		case 70:
																																			goto IL_024b;
																																		case 74:
																																			goto IL_025b;
																																		case 40:
																																		case 97:
																																			goto IL_0268;
																																		case 51:
																																			goto IL_0278;
																																		case 26:
																																			goto IL_0288;
																																		case 25:
																																			goto IL_0298;
																																		case 10:
																																			goto IL_02a8;
																																		case 63:
																																			goto IL_02b8;
																																		case 81:
																																		case 103:
																																			goto IL_02c8;
																																		case 89:
																																		case 102:
																																			goto IL_02d3;
																																		case 0:
																																			goto IL_02fc;
																																		case 69:
																																			goto IL_030a;
																																		case 35:
																																			goto IL_031d;
																																		case 36:
																																			goto IL_0328;
																																		case 18:
																																		case 87:
																																			goto IL_0336;
																																		case 22:
																																		case 73:
																																			goto IL_0357;
																																		case 20:
																																			goto IL_0365;
																																		case 39:
																																		case 68:
																																			goto IL_0378;
																																		case 31:
																																			goto IL_0386;
																																		case 49:
																																			goto IL_03a9;
																																		case 52:
																																			goto IL_03b3;
																																		case 27:
																																			goto IL_03c1;
																																		case 93:
																																			goto IL_03d4;
																																		case 14:
																																		case 57:
																																			goto IL_03df;
																																		case 72:
																																			goto IL_03ea;
																																		case 9:
																																		case 37:
																																			goto IL_03f8;
																																		case 98:
																																			goto IL_0414;
																																		case 42:
																																			goto IL_0422;
																																		case 64:
																																			goto IL_043e;
																																		case 13:
																																		case 30:
																																			goto IL_0449;
																																		case 3:
																																			goto IL_04ab;
																																		case 45:
																																		case 95:
																																			goto IL_04be;
																																		case 4:
																																		case 21:
																																			goto IL_04c9;
																																		case 80:
																																			goto IL_04d7;
																																		case 47:
																																		case 91:
																																			goto IL_04e5;
																																		case 66:
																																			goto IL_0508;
																																		case 46:
																																			goto IL_0516;
																																		case 65:
																																			goto IL_0524;
																																		case 59:
																																			goto IL_0537;
																																		case 33:
																																		case 54:
																																			goto IL_054b;
																																		case 15:
																																			goto IL_058b;
																																		case 17:
																																			goto IL_05a8;
																																		case 1:
																																		case 2:
																																		case 7:
																																		case 8:
																																		case 12:
																																		case 24:
																																		case 53:
																																		case 56:
																																		case 58:
																																		case 60:
																																		case 61:
																																		case 71:
																																		case 78:
																																		case 85:
																																		case 86:
																																		case 88:
																																		case 90:
																																		case 99:
																																		case 104:
																																			goto end_IL_023b;
																																		case 16:
																																		case 28:
																																		case 29:
																																		case 32:
																																		case 34:
																																		case 41:
																																		case 43:
																																		case 67:
																																		case 75:
																																		case 77:
																																		case 79:
																																		case 84:
																																			goto end_IL_01cb;
																																		case 50:
																																			goto end_IL_05cb;
																																		case 100:
																																			goto end_IL_05de;
																																		case 48:
																																			goto end_IL_05e8;
																																		case 5:
																																			goto end_IL_05f3;
																																		case 11:
																																		case 55:
																																			goto end_IL_0608;
																																		case 23:
																																			goto end_IL_0618;
																																		case 101:
																																			goto end_IL_0628;
																																		case 19:
																																			goto end_IL_0638;
																																		case 82:
																																			goto end_IL_0648;
																																		case 83:
																																			goto end_IL_0653;
																																		case 38:
																																		case 44:
																																			goto IL_0677;
																																		}
																																		continue;
																																		end_IL_01cb:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02a8;
																													continue;
																													end_IL_023b:
																													break;
																													IL_023b:;
																												}
																												break;
																												IL_024b:;
																											}
																											break;
																										}
																										goto IL_02d3;
																										IL_030a:
																										num5--;
																										goto end_IL_02a8;
																										IL_02d3:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_02fc;
																										IL_02fc:
																										ptr2 += 8;
																										goto IL_030a;
																									}
																									break;
																								}
																								goto IL_031d;
																								IL_0357:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0365;
																								IL_031d:
																								if (3 >= b)
																								{
																									goto IL_0328;
																								}
																								num = 73;
																								goto IL_0357;
																								IL_0328:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0336;
																								IL_0336:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02a8;
																								IL_0365:
																								if (4 > b)
																								{
																									break;
																								}
																								goto end_IL_02a8;
																							}
																							break;
																						}
																						goto IL_0378;
																						IL_03c1:
																						ptr2 += 8;
																						goto end_IL_02a8;
																						IL_0378:
																						array[num5] = 0;
																						goto IL_0386;
																						IL_0386:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03a9;
																						IL_03a9:
																						array2[num5] = null;
																						goto IL_03b3;
																						IL_03b3:
																						num5++;
																						goto IL_03c1;
																					}
																					break;
																				}
																				goto IL_03d4;
																				IL_054b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_058b;
																				IL_03d4:
																				if (8 < b)
																				{
																					goto IL_03df;
																				}
																				goto IL_043e;
																				IL_03df:
																				if (9 >= b)
																				{
																					goto IL_03ea;
																				}
																				goto IL_0414;
																				IL_03ea:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_03f8;
																				IL_03f8:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a8;
																				IL_0414:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0422;
																				IL_0422:
																				if (10 > b)
																				{
																					num = 78;
																				}
																				break;
																				IL_058b:
																				array[num5 - 2] = 0;
																				num = 17;
																				goto IL_05a8;
																				IL_043e:
																				if (8 <= b)
																				{
																					goto IL_0449;
																				}
																				goto IL_04be;
																				IL_0449:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_04ab;
																				IL_04ab:
																				num5 -= 2;
																				goto end_IL_02a8;
																				IL_04be:
																				if (6 < b)
																				{
																					goto IL_04c9;
																				}
																				goto IL_0537;
																				IL_04c9:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_04d7;
																				IL_04d7:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04e5;
																				IL_04e5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0508;
																				IL_0508:
																				array[num5] = 0;
																				goto IL_0516;
																				IL_0516:
																				num5++;
																				goto IL_0524;
																				IL_0524:
																				ptr2 += 8;
																				goto end_IL_02a8;
																				IL_0537:
																				if (6 > b)
																				{
																					break;
																				}
																				num = 33;
																				goto IL_054b;
																				IL_05a8:
																				num5--;
																				goto end_IL_02a8;
																			}
																			break;
																			IL_0298:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02a8:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 44;
													goto IL_0677;
													IL_0677:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05cb:
													break;
												}
												continue;
												end_IL_05de:
												break;
											}
											continue;
											end_IL_05e8:
											break;
										}
										continue;
										end_IL_05f3:
										break;
									}
									continue;
									end_IL_0608:
									break;
								}
								continue;
								end_IL_0618:
								break;
							}
							continue;
							end_IL_0628:
							break;
						}
						continue;
						end_IL_0638:
						break;
					}
					continue;
					end_IL_0648:
					break;
				}
				continue;
				end_IL_0653:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 29;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BestFitMaskgetRoot.VerifyDataNativeObjectSecurity);
										num = 154;
										while (true)
										{
											if (num != 154)
											{
												if (num != 1135)
												{
													goto IL_08f5;
												}
												switch (num)
												{
												case 61:
													goto end_IL_0277;
												case 78:
													goto end_IL_028a;
												case 89:
													goto end_IL_029e;
												case 13:
												case 52:
													goto end_IL_02ae;
												case 37:
													goto end_IL_02be;
												case 75:
												case 126:
													goto end_IL_02ce;
												case 28:
													goto end_IL_02de;
												case 29:
													goto end_IL_02ee;
												case 0:
												case 5:
												case 12:
												case 36:
												case 39:
												case 44:
												case 51:
												case 53:
												case 59:
												case 60:
												case 66:
												case 76:
												case 88:
												case 106:
												case 109:
												case 125:
												case 127:
												case 135:
													goto IL_0311;
												case 96:
												case 146:
													goto IL_0321;
												case 72:
													goto IL_032a;
												case 64:
													goto IL_0338;
												case 32:
													goto IL_0346;
												case 91:
													goto IL_0354;
												case 47:
												case 120:
													goto IL_0362;
												case 58:
													goto IL_0370;
												case 35:
												case 74:
													goto IL_037e;
												case 82:
													goto IL_038c;
												case 104:
												case 134:
													goto IL_0397;
												case 30:
													goto IL_03a5;
												case 48:
												case 118:
													goto IL_03b8;
												case 92:
													goto IL_03c6;
												case 62:
													goto IL_03e9;
												case 140:
													goto IL_03f3;
												case 14:
													goto IL_0401;
												case 141:
													goto IL_0414;
												case 95:
													goto IL_0422;
												case 45:
												case 94:
													goto IL_0430;
												case 71:
													goto IL_0474;
												case 147:
													goto IL_0488;
												case 85:
												case 136:
													goto IL_049b;
												case 119:
													goto IL_04db;
												case 16:
													goto IL_04ef;
												case 93:
													goto IL_0502;
												case 84:
													goto IL_0510;
												case 112:
												case 128:
													goto IL_051e;
												case 122:
													goto IL_052c;
												case 57:
												case 100:
													goto IL_053a;
												case 73:
													goto IL_059c;
												case 83:
												case 133:
													goto IL_05af;
												case 102:
													goto IL_05cb;
												case 124:
													goto IL_05d9;
												case 18:
													goto IL_05ec;
												case 23:
												case 137:
													goto IL_05f7;
												case 77:
												case 132:
													goto IL_0618;
												case 113:
													goto IL_0626;
												case 46:
												case 55:
													goto IL_0631;
												case 11:
													goto IL_064f;
												case 142:
													goto IL_065d;
												case 2:
													goto IL_0670;
												case 80:
													goto IL_067e;
												case 90:
												case 139:
													goto IL_0689;
												case 6:
													goto IL_06c9;
												case 145:
													goto IL_06dd;
												case 115:
													goto IL_06f0;
												case 33:
													goto IL_06fe;
												case 1:
												case 114:
													goto IL_070c;
												case 97:
													goto IL_072e;
												case 50:
													goto IL_073c;
												case 123:
													goto IL_074a;
												case 105:
													goto IL_075d;
												case 81:
													goto IL_076b;
												case 24:
												case 130:
													goto IL_0779;
												case 129:
													goto IL_07a2;
												case 34:
													goto IL_07bb;
												case 41:
												case 63:
													goto IL_07c6;
												case 70:
													goto IL_07dd;
												case 67:
												case 117:
													goto IL_07eb;
												case 143:
													goto IL_0814;
												case 31:
													goto IL_0822;
												case 43:
													goto IL_0835;
												case 22:
												case 42:
													goto IL_0840;
												case 20:
													goto IL_084e;
												case 110:
												case 131:
													goto IL_085c;
												case 111:
													goto IL_086a;
												case 17:
													goto IL_0882;
												case 87:
													goto IL_0890;
												case 9:
												case 86:
													goto IL_08a3;
												case 108:
													goto IL_08e2;
												case 3:
												case 4:
												case 7:
												case 8:
												case 10:
												case 15:
												case 19:
												case 21:
												case 25:
												case 27:
												case 38:
												case 40:
												case 49:
												case 54:
												case 56:
												case 65:
												case 68:
												case 69:
												case 98:
												case 99:
												case 101:
												case 103:
												case 107:
												case 116:
												case 121:
												case 138:
												case 144:
													goto IL_08f5;
												case 26:
												case 79:
													goto IL_090d;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_0311;
											IL_0882:
											num4++;
											goto IL_0890;
											IL_08a3:
											((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_08e2;
											IL_0890:
											ptr2 += 8;
											goto IL_0311;
											IL_0311:
											if (num5 != 1)
											{
												goto IL_0321;
											}
											goto IL_090d;
											IL_090d:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											IL_0321:
											b = *ptr2;
											goto IL_032a;
											IL_032a:
											ptr2++;
											goto IL_0338;
											IL_0338:
											if (b >= 1)
											{
												goto IL_0346;
											}
											goto IL_08f5;
											IL_0346:
											if (b <= 15)
											{
												goto IL_0354;
											}
											goto IL_08f5;
											IL_0354:
											if (8 < b)
											{
												goto IL_0362;
											}
											goto IL_05ec;
											IL_0362:
											if (12 >= b)
											{
												goto IL_0370;
											}
											goto IL_0502;
											IL_0370:
											if (12 > b)
											{
												goto IL_037e;
											}
											goto IL_049b;
											IL_037e:
											if (10 >= b)
											{
												goto IL_038c;
											}
											goto IL_0414;
											IL_038c:
											if (10 > b)
											{
												goto IL_0397;
											}
											goto IL_03b8;
											IL_0397:
											if (9 >= b)
											{
												goto IL_03a5;
											}
											goto IL_08f5;
											IL_03a5:
											if (9 <= b)
											{
												goto IL_0311;
											}
											goto IL_08f5;
											IL_03b8:
											array[num4] = 0;
											goto IL_03c6;
											IL_03c6:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_03e9;
											IL_03e9:
											array2[num4] = null;
											goto IL_03f3;
											IL_03f3:
											num4++;
											goto IL_0401;
											IL_0401:
											ptr2 += 8;
											goto IL_0311;
											IL_0414:
											if (11 >= b)
											{
												goto IL_0422;
											}
											goto IL_08f5;
											IL_0422:
											if (11 <= b)
											{
												goto IL_0430;
											}
											goto IL_08f5;
											IL_0430:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
											goto IL_0474;
											IL_0474:
											array[num4 - 2] = 0;
											goto IL_0488;
											IL_0488:
											num4--;
											goto IL_0311;
											IL_049b:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_04db;
											IL_04db:
											array[num4 - 2] = 0;
											goto IL_04ef;
											IL_04ef:
											num4--;
											goto IL_0311;
											IL_0502:
											if (14 >= b)
											{
												goto IL_0510;
											}
											goto IL_05cb;
											IL_0510:
											if (14 > b)
											{
												goto IL_051e;
											}
											goto IL_05af;
											IL_051e:
											if (13 >= b)
											{
												goto IL_052c;
											}
											goto IL_08f5;
											IL_052c:
											if (13 <= b)
											{
												goto IL_053a;
											}
											goto IL_08f5;
											IL_053a:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_059c;
											IL_059c:
											num4 -= 2;
											goto IL_0311;
											IL_05af:
											byte* num6 = ptr2;
											num5 = 1;
											ptr2 = num6 + -200;
											goto IL_0311;
											IL_05cb:
											if (15 >= b)
											{
												goto IL_05d9;
											}
											goto IL_08f5;
											IL_05d9:
											if (15 <= b)
											{
											}
											goto IL_08f5;
											IL_05ec:
											if (8 <= b)
											{
												goto IL_05f7;
											}
											num = 77;
											goto IL_0618;
											IL_05f7:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0311;
											IL_08e2:
											num4 -= 3;
											goto IL_0311;
											IL_0618:
											if (4 >= b)
											{
												goto IL_0626;
											}
											goto IL_07bb;
											IL_0626:
											if (4 <= b)
											{
												goto IL_0631;
											}
											goto IL_0670;
											IL_0631:
											array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
											goto IL_064f;
											IL_064f:
											ptr2 += 8;
											goto IL_065d;
											IL_065d:
											num4--;
											goto IL_0311;
											IL_0670:
											if (2 >= b)
											{
												goto IL_067e;
											}
											goto IL_075d;
											IL_067e:
											if (2 <= b)
											{
												goto IL_0689;
											}
											goto IL_06f0;
											IL_0689:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_06c9;
											IL_06c9:
											array[num4 - 2] = 0;
											goto IL_06dd;
											IL_06dd:
											num4--;
											goto IL_0311;
											IL_06f0:
											if (1 >= b)
											{
												goto IL_06fe;
											}
											goto IL_08f5;
											IL_06fe:
											if (1 <= b)
											{
												goto IL_070c;
											}
											goto IL_08f5;
											IL_070c:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
											num = 97;
											goto IL_072e;
											IL_072e:
											array[num4] = 0;
											goto IL_073c;
											IL_073c:
											num4++;
											goto IL_074a;
											IL_074a:
											ptr2 += 8;
											goto IL_0311;
											IL_075d:
											if (3 >= b)
											{
												goto IL_076b;
											}
											goto IL_08f5;
											IL_076b:
											if (3 <= b)
											{
												goto IL_0779;
											}
											goto IL_08f5;
											IL_0779:
											array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
											goto IL_07a2;
											IL_07a2:
											array[num4 - 1] = 5;
											goto IL_0311;
											IL_07bb:
											if (6 < b)
											{
												goto IL_07c6;
											}
											goto IL_0835;
											IL_07c6:
											if (7 >= b)
											{
												num = 70;
												goto IL_07dd;
											}
											goto IL_08f5;
											IL_08f5:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0311;
											IL_07dd:
											if (7 <= b)
											{
												goto IL_07eb;
											}
											goto IL_08f5;
											IL_07eb:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0814;
											IL_0814:
											ptr2 += 8;
											goto IL_0822;
											IL_0822:
											num4--;
											goto IL_0311;
											IL_0835:
											if (6 > b)
											{
												goto IL_0840;
											}
											goto IL_08a3;
											IL_0840:
											if (5 >= b)
											{
												goto IL_084e;
											}
											goto IL_08f5;
											IL_084e:
											if (5 <= b)
											{
												goto IL_085c;
											}
											goto IL_08f5;
											IL_085c:
											array[num4] = 5;
											goto IL_086a;
											IL_086a:
											array2[num4] = array5[*(int*)(ptr2 + num3)];
											goto IL_0882;
											continue;
											end_IL_0277:
											break;
										}
										continue;
										end_IL_028a:
										break;
									}
									continue;
									end_IL_029e:
									break;
								}
								continue;
								end_IL_02ae:
								break;
							}
							continue;
							end_IL_02be:
							break;
						}
						continue;
						end_IL_02ce:
						break;
					}
					continue;
					end_IL_02de:
					break;
				}
				continue;
				end_IL_02ee:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 77;
		object[] array2 = default(object[]);
		byte b = default(byte);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 113;
					while (true)
					{
						if (num != 113)
						{
							if (num != 1094)
							{
								goto IL_050a;
							}
							switch (num)
							{
							case 0:
							case 104:
								goto end_IL_01d3;
							case 76:
								goto end_IL_01e3;
							case 77:
								goto end_IL_01fc;
							case 29:
								goto IL_0225;
							case 97:
								goto IL_022e;
							case 67:
								goto IL_023c;
							case 10:
								goto IL_024a;
							case 70:
								goto IL_025d;
							case 22:
								goto IL_0266;
							case 3:
							case 15:
							case 19:
							case 34:
							case 35:
							case 54:
							case 62:
							case 71:
							case 75:
							case 89:
							case 92:
							case 93:
							case 98:
								goto IL_026e;
							case 64:
							case 80:
								goto IL_027e;
							case 81:
								goto IL_0290;
							case 6:
								goto IL_029e;
							case 99:
								goto IL_02ac;
							case 59:
								goto IL_02ba;
							case 58:
								goto IL_02c8;
							case 30:
							case 31:
								goto IL_02d3;
							case 41:
								goto IL_02e1;
							case 33:
								goto IL_0304;
							case 32:
								goto IL_030e;
							case 2:
								goto IL_0325;
							case 63:
								goto IL_0341;
							case 12:
							case 91:
								goto IL_034c;
							case 57:
							case 85:
								goto IL_0357;
							case 16:
								goto IL_0365;
							case 5:
								goto IL_0378;
							case 11:
							case 21:
								goto IL_0386;
							case 23:
								goto IL_039e;
							case 13:
							case 49:
								goto IL_03a9;
							case 61:
								goto IL_03b7;
							case 28:
							case 40:
								goto IL_03c5;
							case 39:
								goto IL_03de;
							case 9:
								goto IL_03ec;
							case 38:
								goto IL_03fa;
							case 44:
							case 65:
								goto IL_040d;
							case 14:
								goto IL_043f;
							case 100:
								goto IL_044d;
							case 4:
							case 96:
								goto IL_0460;
							case 8:
								goto IL_046e;
							case 73:
							case 95:
								goto IL_047c;
							case 46:
								goto IL_0487;
							case 79:
							case 101:
								goto IL_0495;
							case 68:
								goto IL_04d5;
							case 94:
								goto IL_04e9;
							case 43:
								goto IL_04fc;
							case 66:
								goto IL_050a;
							case 24:
							case 53:
								goto IL_0521;
							case 47:
								goto IL_0544;
							case 17:
								goto IL_0552;
							case 42:
								goto IL_0560;
							case 52:
							case 72:
								goto IL_0573;
							case 78:
								goto IL_05d5;
							case 90:
								goto IL_05e8;
							case 37:
								goto IL_05f3;
							case 69:
								goto IL_05fe;
							case 74:
								goto IL_060b;
							case 51:
							case 82:
								goto IL_0616;
							case 1:
							case 7:
							case 18:
							case 20:
							case 25:
							case 26:
							case 27:
							case 36:
							case 45:
							case 48:
							case 50:
							case 56:
							case 60:
							case 83:
							case 84:
							case 86:
							case 87:
							case 102:
							case 103:
							case 105:
							case 106:
								goto IL_0632;
							case 55:
							case 88:
								goto IL_0653;
							}
							continue;
						}
						array2 = new object[2];
						goto IL_0225;
						IL_05f3:
						if (10 >= b)
						{
							goto IL_05fe;
						}
						goto IL_0632;
						IL_060b:
						if (9 <= b)
						{
							goto IL_0616;
						}
						goto IL_0632;
						IL_05fe:
						if (10 <= b)
						{
						}
						goto IL_0632;
						IL_0225:
						num = 97;
						goto IL_022e;
						IL_022e:
						array3 = new int[3];
						goto IL_023c;
						IL_023c:
						array4 = new long[2];
						goto IL_024a;
						IL_024a:
						array3[0] = int_3;
						goto IL_025d;
						IL_025d:
						ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnicodeEncodingGetActiveObject.ppStringManifestBasedResourceGroveler);
						goto IL_0266;
						IL_0266:
						ptr2 = ptr;
						goto IL_026e;
						IL_026e:
						if (num4 != 1)
						{
							goto IL_027e;
						}
						num = 88;
						goto IL_0653;
						IL_0616:
						byte* num5 = ptr2;
						num4 = 1;
						ptr2 = num5 + -200;
						goto IL_026e;
						IL_0653:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
						IL_027e:
						b = *ptr2;
						num = 81;
						goto IL_0290;
						IL_0290:
						ptr2++;
						goto IL_029e;
						IL_029e:
						if (b >= 1)
						{
							goto IL_02ac;
						}
						goto IL_0632;
						IL_02ac:
						if (b <= 10)
						{
							goto IL_02ba;
						}
						goto IL_0632;
						IL_02ba:
						if (5 >= b)
						{
							goto IL_02c8;
						}
						goto IL_0460;
						IL_02c8:
						if (5 <= b)
						{
							goto IL_02d3;
						}
						goto IL_0341;
						IL_02d3:
						array[num6] = 0;
						goto IL_02e1;
						IL_02e1:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
						goto IL_0304;
						IL_0304:
						array2[num6] = null;
						goto IL_030e;
						IL_030e:
						num6++;
						num = 2;
						goto IL_0325;
						IL_0325:
						ptr2 += 8;
						num = 19;
						goto IL_026e;
						IL_0341:
						if (2 < b)
						{
							goto IL_034c;
						}
						goto IL_039e;
						IL_034c:
						if (3 < b)
						{
							goto IL_0357;
						}
						goto IL_0378;
						IL_0357:
						if (4 >= b)
						{
							goto IL_0365;
						}
						goto IL_0632;
						IL_0365:
						if (4 <= b)
						{
							goto IL_026e;
						}
						goto IL_0632;
						IL_0378:
						if (3 <= b)
						{
							goto IL_0386;
						}
						goto IL_0632;
						IL_0386:
						ptr2 = ptr + *(int*)(ptr2 + num3);
						goto IL_026e;
						IL_039e:
						if (2 > b)
						{
							goto IL_03a9;
						}
						goto IL_040d;
						IL_03a9:
						if (1 >= b)
						{
							goto IL_03b7;
						}
						goto IL_0632;
						IL_03b7:
						if (1 <= b)
						{
							goto IL_03c5;
						}
						goto IL_0632;
						IL_03c5:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
						goto IL_03de;
						IL_03de:
						array[num6] = 0;
						goto IL_03ec;
						IL_03ec:
						num6++;
						goto IL_03fa;
						IL_03fa:
						ptr2 += 8;
						goto IL_026e;
						IL_040d:
						ref int reference = ref array3[*(int*)(ptr2 + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
						num = 14;
						goto IL_043f;
						IL_043f:
						ptr2 += 8;
						goto IL_044d;
						IL_044d:
						num6--;
						goto IL_026e;
						IL_0460:
						if (8 >= b)
						{
							goto IL_046e;
						}
						goto IL_05e8;
						IL_046e:
						if (8 > b)
						{
							goto IL_047c;
						}
						goto IL_0573;
						IL_047c:
						if (6 >= b)
						{
							goto IL_0487;
						}
						goto IL_04fc;
						IL_0487:
						if (6 <= b)
						{
							goto IL_0495;
						}
						goto IL_0632;
						IL_0495:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
						goto IL_04d5;
						IL_04d5:
						array[num6 - 2] = 0;
						goto IL_04e9;
						IL_04e9:
						num6--;
						goto IL_026e;
						IL_04fc:
						if (7 >= b)
						{
							goto IL_050a;
						}
						goto IL_0632;
						IL_050a:
						if (7 <= b)
						{
							num = 24;
							goto IL_0521;
						}
						goto IL_0632;
						IL_0632:
						ptr2 = ptr + *(int*)(ptr2 + num3);
						goto IL_026e;
						IL_0521:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
						goto IL_0544;
						IL_0544:
						array[num6] = 0;
						goto IL_0552;
						IL_0552:
						num6++;
						goto IL_0560;
						IL_0560:
						ptr2 += 8;
						goto IL_026e;
						IL_0573:
						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
						goto IL_05d5;
						IL_05d5:
						num6 -= 2;
						goto IL_026e;
						IL_05e8:
						if (9 < b)
						{
							goto IL_05f3;
						}
						goto IL_060b;
						continue;
						end_IL_01d3:
						break;
					}
					continue;
					end_IL_01e3:
					break;
				}
				continue;
				end_IL_01fc:
				break;
			}
		}
	}

	private static int smethod_3(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		if (num <= num2)
		{
			num = int_4;
			num2 = int_3;
			return num - num2;
		}
		num = int_3;
		num2 = int_4;
		return num - num2;
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 25;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 45;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IntegerBrowserForward.SZArrayHelpergetFormatJapaneseFirstYearAsANumber);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_05c0:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 113;
												while (true)
												{
													if (num != 113)
													{
														if (num != 1094)
														{
															break;
														}
														switch (num)
														{
														case 78:
														case 95:
															break;
														case 52:
															goto IL_0017;
														case 58:
															goto IL_0025;
														case 42:
															goto IL_0033;
														case 98:
															goto IL_0041;
														case 74:
															goto IL_004f;
														case 36:
														case 76:
															goto IL_005d;
														case 97:
															goto IL_006b;
														case 32:
														case 51:
															goto IL_0076;
														case 15:
															goto IL_009f;
														case 23:
															goto IL_00ad;
														case 17:
															goto IL_00c9;
														case 9:
															goto IL_00d7;
														case 8:
														case 65:
															goto IL_00e5;
														case 64:
															goto IL_0107;
														case 79:
															goto IL_0115;
														case 19:
															goto IL_0123;
														case 63:
															goto IL_0136;
														case 44:
														case 77:
															goto IL_0141;
														case 106:
															goto IL_014f;
														case 28:
															goto IL_0162;
														case 13:
														case 39:
															goto end_IL_05ad;
														case 16:
														case 89:
															goto IL_0188;
														case 29:
															goto IL_0196;
														case 18:
															goto IL_01b9;
														case 91:
															goto IL_01c3;
														case 68:
															goto IL_01d1;
														case 22:
														case 27:
															goto IL_01e4;
														case 3:
														case 92:
															goto IL_01ef;
														case 72:
														case 85:
															goto IL_01fa;
														case 2:
															goto IL_0208;
														case 67:
															goto IL_021b;
														case 46:
														case 88:
															goto IL_0229;
														case 66:
															goto IL_0245;
														case 12:
														case 73:
															goto IL_0250;
														case 56:
															goto IL_02b2;
														case 40:
														case 103:
															goto IL_02ce;
														case 90:
														case 96:
															goto IL_02d9;
														case 82:
															goto IL_02e7;
														case 1:
														case 35:
															goto IL_02f5;
														case 104:
															goto IL_0318;
														case 59:
															goto IL_0326;
														case 83:
															goto IL_033d;
														case 34:
															goto IL_0350;
														case 6:
														case 62:
															goto IL_035b;
														case 4:
															goto IL_039b;
														case 86:
															goto IL_03af;
														case 10:
														case 14:
														case 21:
														case 31:
														case 38:
														case 48:
														case 50:
														case 55:
														case 57:
														case 60:
														case 69:
														case 71:
														case 80:
														case 81:
														case 87:
														case 94:
														case 99:
														case 100:
														case 102:
															goto IL_03c2;
														default:
															continue;
														case 0:
														case 7:
														case 20:
														case 26:
														case 37:
														case 41:
														case 43:
														case 47:
														case 53:
														case 54:
														case 75:
														case 93:
														case 101:
															goto IL_05c0;
														case 11:
															goto end_IL_05c0;
														case 84:
															goto end_IL_05d3;
														case 45:
															goto end_IL_05dd;
														case 61:
															goto end_IL_05e8;
														case 49:
														case 105:
															goto end_IL_05fd;
														case 33:
															goto end_IL_0616;
														case 30:
														case 70:
															goto end_IL_0626;
														case 24:
															goto end_IL_0636;
														case 25:
															goto end_IL_0646;
														case 5:
															goto IL_0661;
														}
														goto IL_000e;
													}
													goto IL_0661;
													IL_0661:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05ad:
													break;
												}
												goto IL_0170;
												IL_039b:
												array[num5 - 2] = 0;
												goto IL_03af;
												IL_03af:
												num5--;
												continue;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_03c2;
												IL_0033:
												if (b <= 10)
												{
													goto IL_0041;
												}
												goto IL_03c2;
												IL_0041:
												if (5 >= b)
												{
													goto IL_004f;
												}
												goto IL_01e4;
												IL_004f:
												if (5 > b)
												{
													goto IL_005d;
												}
												goto IL_0188;
												IL_005d:
												if (2 >= b)
												{
													goto IL_006b;
												}
												goto IL_0136;
												IL_006b:
												if (2 <= b)
												{
													goto IL_0076;
												}
												goto IL_00c9;
												IL_0076:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_009f;
												IL_009f:
												ptr2 += 8;
												goto IL_00ad;
												IL_00ad:
												num5--;
												num = 43;
												continue;
												IL_00c9:
												if (1 >= b)
												{
													goto IL_00d7;
												}
												goto IL_03c2;
												IL_00d7:
												if (1 <= b)
												{
													goto IL_00e5;
												}
												goto IL_03c2;
												IL_00e5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												num = 64;
												goto IL_0107;
												IL_0107:
												array[num5] = 0;
												goto IL_0115;
												IL_0115:
												num5++;
												goto IL_0123;
												IL_0123:
												ptr2 += 8;
												continue;
												IL_0136:
												if (3 < b)
												{
													goto IL_0141;
												}
												goto IL_0162;
												IL_0141:
												if (4 >= b)
												{
													goto IL_014f;
												}
												goto IL_03c2;
												IL_014f:
												if (4 <= b)
												{
													continue;
												}
												goto IL_03c2;
												IL_0162:
												if (3 <= b)
												{
													goto IL_0170;
												}
												goto IL_03c2;
												IL_0170:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_0188:
												array[num5] = 0;
												goto IL_0196;
												IL_0196:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_01b9;
												IL_01b9:
												array2[num5] = null;
												goto IL_01c3;
												IL_01c3:
												num5++;
												goto IL_01d1;
												IL_01d1:
												ptr2 += 8;
												continue;
												IL_01e4:
												if (8 < b)
												{
													goto IL_01ef;
												}
												goto IL_0245;
												IL_01ef:
												if (9 < b)
												{
													goto IL_01fa;
												}
												goto IL_021b;
												IL_01fa:
												if (10 >= b)
												{
													goto IL_0208;
												}
												goto IL_03c2;
												IL_0208:
												if (10 <= b)
												{
												}
												goto IL_03c2;
												IL_021b:
												if (9 <= b)
												{
													goto IL_0229;
												}
												goto IL_03c2;
												IL_0229:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_0245:
												if (8 <= b)
												{
													goto IL_0250;
												}
												num = 103;
												goto IL_02ce;
												IL_0250:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_02b2;
												IL_02b2:
												num5 -= 2;
												continue;
												IL_03c2:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_02ce:
												if (6 < b)
												{
													goto IL_02d9;
												}
												goto IL_0350;
												IL_02d9:
												if (7 >= b)
												{
													goto IL_02e7;
												}
												goto IL_03c2;
												IL_02e7:
												if (7 <= b)
												{
													goto IL_02f5;
												}
												goto IL_03c2;
												IL_02f5:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0318;
												IL_0318:
												array[num5] = 0;
												goto IL_0326;
												IL_0326:
												num5++;
												num = 83;
												goto IL_033d;
												IL_033d:
												ptr2 += 8;
												continue;
												IL_0350:
												if (6 <= b)
												{
													goto IL_035b;
												}
												goto IL_03c2;
												IL_035b:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_039b;
												continue;
												end_IL_05c0:
												break;
											}
											continue;
											end_IL_05d3:
											break;
										}
										continue;
										end_IL_05dd:
										break;
									}
									continue;
									end_IL_05e8:
									break;
								}
								continue;
								end_IL_05fd:
								break;
							}
							continue;
							end_IL_0616:
							break;
						}
						continue;
						end_IL_0626:
						break;
					}
					continue;
					end_IL_0636:
					break;
				}
				continue;
				end_IL_0646:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3, int int_4)
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IProgIdRedirectionEntryelemdescVar.StackOverflowExceptionSyncStream);
											num = 48;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_030d:
															byte b = *ptr2;
															while (true)
															{
																IL_02fd:
																ptr2++;
																while (true)
																{
																	IL_02f0:
																	if (b < 1)
																	{
																		goto IL_02b8;
																	}
																	goto IL_02e0;
																	IL_02e0:
																	if (b <= 8)
																	{
																		goto IL_000e;
																	}
																	goto IL_02b8;
																	IL_000e:
																	if (4 < b)
																	{
																		goto IL_001c;
																	}
																	goto IL_023e;
																	IL_023e:
																	if (4 > b)
																	{
																		goto IL_024c;
																	}
																	goto IL_03b5;
																	IL_024c:
																	if (2 >= b)
																	{
																		goto IL_0257;
																	}
																	goto IL_0272;
																	IL_0272:
																	if (3 >= b)
																	{
																		goto IL_027d;
																	}
																	goto IL_02b8;
																	IL_02b8:
																	while (true)
																	{
																		IL_02b8_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_0205:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_01f5:
																				num5++;
																				while (true)
																				{
																					IL_01dc:
																					ptr2 += 8;
																					num = 93;
																					while (num != 93)
																					{
																						if (num != 1074)
																						{
																							goto IL_0318;
																						}
																						switch (num)
																						{
																						case 74:
																							break;
																						case 46:
																							goto IL_001c;
																						case 18:
																							goto IL_0033;
																						case 36:
																							goto IL_0041;
																						default:
																							continue;
																						case 60:
																							goto IL_01dc;
																						case 19:
																							goto IL_01f5;
																						case 57:
																							goto IL_0205;
																						case 25:
																							goto IL_0215;
																						case 5:
																						case 51:
																							goto IL_0220;
																						case 1:
																							goto IL_022e;
																						case 53:
																							goto IL_023e;
																						case 49:
																							goto IL_024c;
																						case 34:
																							goto IL_0257;
																						case 40:
																							goto IL_0265;
																						case 38:
																							goto IL_0272;
																						case 21:
																							goto IL_027d;
																						case 62:
																							goto IL_028d;
																						case 65:
																							goto IL_029d;
																						case 72:
																							goto IL_02ad;
																						case 6:
																						case 26:
																						case 27:
																						case 29:
																						case 31:
																						case 33:
																						case 50:
																						case 52:
																						case 55:
																						case 64:
																						case 68:
																						case 69:
																						case 73:
																						case 75:
																						case 80:
																						case 81:
																						case 82:
																							goto IL_02b8_2;
																						case 41:
																							goto IL_02e0;
																						case 35:
																							goto IL_02f0;
																						case 66:
																							goto IL_02fd;
																						case 20:
																						case 67:
																							goto IL_030d;
																						case 45:
																						case 47:
																							goto IL_0318;
																						case 17:
																						case 37:
																							goto IL_0334;
																						case 39:
																							goto IL_03a2;
																						case 3:
																						case 4:
																							goto IL_03b5;
																						case 10:
																						case 23:
																							goto IL_03e9;
																						case 9:
																						case 70:
																							goto IL_0401;
																						case 43:
																							goto IL_0441;
																						case 71:
																							goto IL_045a;
																						case 32:
																							goto IL_0468;
																						case 54:
																						case 76:
																							goto IL_0478;
																						case 11:
																							goto IL_0486;
																						case 22:
																							goto IL_04a9;
																						case 12:
																							goto IL_04bc;
																						case 58:
																							goto IL_04ca;
																						case 78:
																							goto IL_04da;
																						case 0:
																						case 8:
																						case 15:
																						case 24:
																						case 30:
																						case 42:
																						case 44:
																						case 61:
																						case 63:
																						case 84:
																							goto end_IL_01c9;
																						case 48:
																							goto end_IL_04e8;
																						case 85:
																							goto end_IL_04fb;
																						case 7:
																							goto end_IL_0505;
																						case 28:
																							goto end_IL_0519;
																						case 56:
																							goto end_IL_052e;
																						case 77:
																						case 86:
																							goto end_IL_0543;
																						case 83:
																							goto end_IL_0553;
																						case 16:
																						case 79:
																							goto end_IL_0563;
																						case 13:
																							goto end_IL_0573;
																						case 14:
																							goto end_IL_0583;
																						case 2:
																						case 59:
																							goto IL_059e;
																						}
																						goto IL_000e;
																						continue;
																						end_IL_01c9:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																	IL_027d:
																	if (3 > b)
																	{
																		goto IL_02b8;
																	}
																	goto IL_0401;
																	IL_0401:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0441;
																	IL_0441:
																	array[num5 - 2] = 0;
																	goto IL_04da;
																	IL_04da:
																	num5--;
																	break;
																	IL_0257:
																	if (2 > b)
																	{
																		goto IL_0265;
																	}
																	goto IL_0334;
																	IL_0265:
																	if (1 >= b)
																	{
																		goto IL_02ad;
																	}
																	goto IL_02b8;
																	IL_02ad:
																	if (1 > b)
																	{
																	}
																	goto IL_02b8;
																	IL_0334:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_03a2;
																	IL_03a2:
																	num5 -= 2;
																	break;
																	IL_001c:
																	if (6 >= b)
																	{
																		num = 18;
																		goto IL_0033;
																	}
																	goto IL_0215;
																	IL_045a:
																	ptr2 += 8;
																	goto IL_0468;
																	IL_0033:
																	if (6 <= b)
																	{
																		break;
																	}
																	goto IL_0041;
																	IL_0041:
																	if (5 >= b)
																	{
																		goto IL_029d;
																	}
																	goto IL_02b8;
																	IL_029d:
																	if (5 > b)
																	{
																		goto IL_02b8;
																	}
																	num = 23;
																	goto IL_03e9;
																	IL_0468:
																	num5--;
																	break;
																	IL_03e9:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_0215:
																	if (7 < b)
																	{
																		goto IL_0220;
																	}
																	goto IL_028d;
																	IL_0220:
																	if (8 >= b)
																	{
																		goto IL_022e;
																	}
																	goto IL_02b8;
																	IL_022e:
																	if (8 > b)
																	{
																		goto IL_02b8;
																	}
																	goto IL_0318;
																	IL_0318:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_028d:
																	if (7 > b)
																	{
																		goto IL_02b8;
																	}
																	goto IL_0478;
																	IL_0478:
																	array[num5] = 0;
																	goto IL_0486;
																	IL_0486:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a9;
																	IL_04a9:
																	array2[num5] = null;
																	num = 12;
																	goto IL_04bc;
																	IL_04bc:
																	num5++;
																	goto IL_04ca;
																	IL_04ca:
																	ptr2 += 8;
																	break;
																	IL_03b5:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_045a;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_059e;
													IL_059e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e8:
													break;
												}
												continue;
												end_IL_04fb:
												break;
											}
											continue;
											end_IL_0505:
											break;
										}
										continue;
										end_IL_0519:
										break;
									}
									continue;
									end_IL_052e:
									break;
								}
								continue;
								end_IL_0543:
								break;
							}
							continue;
							end_IL_0553:
							break;
						}
						continue;
						end_IL_0563:
						break;
					}
					continue;
					end_IL_0573:
					break;
				}
				continue;
				end_IL_0583:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_3, int int_4)
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 44;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref clsidLeftArrow.GetHostEnumeratorgetProduceLegacyHmacValues);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f0:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02d3:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02c3:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_02b6:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_02a6:
																										if (11 > b)
																										{
																											while (10 >= b)
																											{
																												while (10 <= b)
																												{
																													while (true)
																													{
																														IL_0270:
																														array[num5 - 1] = 0;
																														while (true)
																														{
																															IL_0226:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SealedgetWindowsCodePage[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																															num = 129;
																															while (true)
																															{
																																if (num != 129)
																																{
																																	if (num != 1110)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 104:
																																		goto IL_0226;
																																	case 38:
																																	case 109:
																																		goto IL_0270;
																																	case 111:
																																		goto IL_0286;
																																	case 9:
																																	case 62:
																																		goto IL_0296;
																																	case 35:
																																		goto IL_02a6;
																																	case 41:
																																		goto IL_02b6;
																																	case 82:
																																		goto IL_02c3;
																																	case 73:
																																		goto IL_02d3;
																																	case 16:
																																		goto IL_02e0;
																																	case 51:
																																		goto IL_02f0;
																																	case 89:
																																		goto end_IL_02f0;
																																	case 65:
																																	case 91:
																																		goto end_IL_0300;
																																	case 31:
																																		goto IL_031b;
																																	case 3:
																																	case 108:
																																		goto IL_032b;
																																	case 61:
																																	case 119:
																																		goto IL_033e;
																																	case 46:
																																		goto IL_034c;
																																	case 5:
																																	case 90:
																																		goto IL_0357;
																																	case 10:
																																		goto IL_0397;
																																	case 14:
																																		goto IL_03ab;
																																	case 37:
																																		goto IL_03be;
																																	case 80:
																																		goto IL_03c9;
																																	case 53:
																																		goto IL_03dc;
																																	case 40:
																																		goto IL_03ea;
																																	case 0:
																																	case 97:
																																		goto end_IL_0213;
																																	case 95:
																																		goto IL_0466;
																																	case 63:
																																	case 93:
																																		goto IL_0482;
																																	case 13:
																																		goto IL_048d;
																																	case 42:
																																	case 81:
																																		goto IL_049b;
																																	case 20:
																																		goto IL_04c4;
																																	case 66:
																																		goto IL_04d2;
																																	case 8:
																																	case 45:
																																		goto IL_04f7;
																																	case 18:
																																		goto IL_050e;
																																	case 19:
																																	case 39:
																																		goto IL_051c;
																																	case 121:
																																		goto IL_0534;
																																	case 29:
																																	case 36:
																																		goto IL_0542;
																																	case 50:
																																	case 85:
																																		goto IL_057a;
																																	case 107:
																																		goto IL_058d;
																																	case 28:
																																	case 68:
																																		goto IL_0598;
																																	case 116:
																																		goto IL_05d8;
																																	case 92:
																																		goto IL_05ec;
																																	case 57:
																																	case 86:
																																		goto IL_05ff;
																																	case 23:
																																		goto IL_060a;
																																	case 60:
																																	case 115:
																																		goto IL_0618;
																																	case 74:
																																		goto IL_0626;
																																	case 17:
																																		goto IL_0649;
																																	case 88:
																																		goto IL_0653;
																																	case 49:
																																		goto IL_0661;
																																	case 47:
																																		goto IL_0674;
																																	case 7:
																																		goto IL_067f;
																																	case 11:
																																	case 106:
																																		goto IL_068a;
																																	case 25:
																																		goto IL_06a3;
																																	case 30:
																																		goto IL_06b1;
																																	case 26:
																																		goto IL_06bf;
																																	case 1:
																																	case 6:
																																	case 15:
																																	case 21:
																																	case 24:
																																	case 32:
																																	case 43:
																																	case 52:
																																	case 54:
																																	case 55:
																																	case 56:
																																	case 67:
																																	case 78:
																																	case 84:
																																	case 101:
																																	case 102:
																																	case 103:
																																	case 113:
																																	case 117:
																																	case 118:
																																	case 122:
																																		goto end_IL_0286;
																																	case 83:
																																		goto IL_06f2;
																																	case 48:
																																		goto IL_0700;
																																	case 96:
																																		goto IL_070e;
																																	case 2:
																																	case 12:
																																	case 33:
																																	case 58:
																																	case 64:
																																	case 70:
																																	case 71:
																																	case 75:
																																	case 76:
																																	case 94:
																																	case 100:
																																	case 110:
																																	case 112:
																																	case 114:
																																	case 120:
																																		goto end_IL_0310;
																																	case 77:
																																		goto end_IL_071c;
																																	case 69:
																																		goto end_IL_072f;
																																	case 72:
																																		goto end_IL_0739;
																																	case 79:
																																		goto end_IL_0744;
																																	case 59:
																																		goto end_IL_0759;
																																	case 22:
																																	case 27:
																																		goto end_IL_076e;
																																	case 44:
																																		goto end_IL_077e;
																																	case 34:
																																	case 105:
																																		goto end_IL_078e;
																																	case 98:
																																		goto end_IL_079e;
																																	case 99:
																																		goto end_IL_07b7;
																																	case 4:
																																	case 87:
																																		goto IL_07d2;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_0310;
																																continue;
																																end_IL_0213:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_03f8;
																													continue;
																													end_IL_0286:
																													break;
																													IL_0286:;
																												}
																												break;
																												IL_0296:;
																											}
																											break;
																										}
																										goto IL_057a;
																										IL_057a:
																										num5--;
																										goto end_IL_0310;
																									}
																									break;
																								}
																								goto IL_032b;
																								IL_0542:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								num = 64;
																								goto end_IL_0310;
																								IL_032b:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_0534;
																								IL_0534:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0542;
																							}
																							break;
																						}
																						goto IL_058d;
																						IL_06bf:
																						ptr2 += 8;
																						goto end_IL_0310;
																						IL_058d:
																						if (9 <= b)
																						{
																							goto IL_0598;
																						}
																						goto IL_05ff;
																						IL_0598:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05d8;
																						IL_05d8:
																						array[num5 - 2] = 0;
																						goto IL_05ec;
																						IL_05ec:
																						num5--;
																						goto end_IL_0310;
																						IL_05ff:
																						if (7 >= b)
																						{
																							goto IL_060a;
																						}
																						goto IL_0674;
																						IL_060a:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0618;
																						IL_0618:
																						array[num5] = 0;
																						goto IL_0626;
																						IL_0626:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0649;
																						IL_0649:
																						array2[num5] = null;
																						goto IL_0653;
																						IL_0653:
																						num5++;
																						goto IL_0661;
																						IL_0661:
																						ptr2 += 8;
																						goto end_IL_0310;
																						IL_0674:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_067f;
																						IL_067f:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_068a;
																						IL_068a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_06a3;
																						IL_06a3:
																						array[num5] = 0;
																						goto IL_06b1;
																						IL_06b1:
																						num5++;
																						goto IL_06bf;
																					}
																					break;
																				}
																				goto IL_031b;
																				IL_051c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0310;
																				IL_031b:
																				if (6 <= b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_033e;
																				IL_033e:
																				if (3 >= b)
																				{
																					goto IL_034c;
																				}
																				goto IL_0482;
																				IL_034c:
																				if (3 <= b)
																				{
																					goto IL_0357;
																				}
																				goto IL_03be;
																				IL_0357:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0397;
																				IL_0397:
																				array[num5 - 2] = 0;
																				goto IL_03ab;
																				IL_03ab:
																				num5--;
																				goto end_IL_0310;
																				IL_03be:
																				if (1 >= b)
																				{
																					goto IL_03c9;
																				}
																				goto IL_03dc;
																				IL_03c9:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_03dc:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_03ea;
																				IL_03ea:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_03f8;
																				IL_03f8:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0466;
																				IL_0466:
																				num5 -= 2;
																				num = 33;
																				goto end_IL_0310;
																				IL_0482:
																				if (4 >= b)
																				{
																					goto IL_048d;
																				}
																				num = 8;
																				goto IL_04f7;
																				IL_048d:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_049b;
																				IL_049b:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c4;
																				IL_04c4:
																				ptr2 += 8;
																				goto IL_04d2;
																				IL_04d2:
																				num5--;
																				num = 100;
																				goto end_IL_0310;
																				IL_050e:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_051c;
																				IL_04f7:
																				if (5 < b)
																				{
																					break;
																				}
																				num = 18;
																				goto IL_050e;
																			}
																			break;
																			IL_02e0:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06f2;
																	IL_070e:
																	ptr2 += 8;
																	goto end_IL_0310;
																	IL_0700:
																	num5++;
																	goto IL_070e;
																	IL_06f2:
																	array[num5] = 0;
																	goto IL_0700;
																	continue;
																	end_IL_02f0:
																	break;
																}
																continue;
																end_IL_0300:
																break;
															}
															continue;
															end_IL_0310:
															break;
														}
														continue;
													}
													goto IL_07d2;
													IL_07d2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071c:
													break;
												}
												continue;
												end_IL_072f:
												break;
											}
											continue;
											end_IL_0739:
											break;
										}
										continue;
										end_IL_0744:
										break;
									}
									continue;
									end_IL_0759:
									break;
								}
								continue;
								end_IL_076e:
								break;
							}
							continue;
							end_IL_077e:
							break;
						}
						continue;
						end_IL_078e:
						break;
					}
					continue;
					end_IL_079e:
					break;
				}
				continue;
				end_IL_07b7:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 48;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OpenMethodDecimalConstantAttribute.getBuildPrimitive);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 120;
											while (true)
											{
												if (num == 120 || num != 1101)
												{
													goto IL_0290;
												}
												switch (num)
												{
												case 35:
													goto end_IL_01ef;
												case 100:
													goto end_IL_0202;
												case 39:
													goto end_IL_0215;
												case 71:
													goto end_IL_0220;
												case 18:
												case 104:
													goto end_IL_0235;
												case 102:
													goto end_IL_0245;
												case 12:
												case 105:
													goto end_IL_0255;
												case 47:
													goto end_IL_0265;
												case 48:
													goto end_IL_0275;
												case 1:
												case 24:
												case 36:
												case 38:
												case 58:
												case 59:
												case 67:
												case 81:
												case 91:
												case 92:
												case 94:
												case 95:
												case 111:
													goto IL_0290;
												case 33:
												case 106:
													goto IL_02a0;
												case 4:
													goto IL_02a9;
												case 23:
													goto IL_02b7;
												case 87:
													goto IL_02c5;
												case 89:
													goto IL_02d3;
												case 9:
												case 32:
													goto IL_02e1;
												case 61:
													goto IL_02ef;
												case 8:
												case 15:
													goto IL_02fa;
												case 50:
													goto IL_035c;
												case 22:
												case 113:
													goto IL_036f;
												case 43:
													goto IL_037d;
												case 14:
												case 109:
													goto IL_0396;
												case 55:
													goto IL_03d6;
												case 112:
													goto IL_03ea;
												case 110:
													goto IL_03fd;
												case 13:
													goto IL_040b;
												case 5:
												case 10:
													goto IL_0422;
												case 86:
													goto IL_0445;
												case 30:
													goto IL_0453;
												case 60:
													goto IL_0461;
												case 101:
													goto IL_0474;
												case 88:
													goto IL_047f;
												case 25:
												case 70:
													goto IL_048d;
												case 46:
													goto IL_04a9;
												case 0:
													goto IL_04b7;
												case 96:
													goto IL_04ca;
												case 42:
												case 63:
													goto IL_04d8;
												case 16:
													goto IL_04e6;
												case 62:
													goto IL_04f4;
												case 31:
												case 76:
													goto IL_04ff;
												case 21:
													goto IL_050d;
												case 3:
												case 19:
													goto IL_051b;
												case 66:
													goto IL_054d;
												case 54:
													goto IL_055b;
												case 34:
													goto IL_056e;
												case 7:
												case 78:
													goto IL_057c;
												case 40:
													goto IL_059e;
												case 80:
													goto IL_05ac;
												case 27:
													goto IL_05ba;
												case 74:
												case 77:
													goto IL_05cd;
												case 29:
													goto IL_05e5;
												case 6:
												case 72:
													goto IL_05f0;
												case 107:
													goto IL_05fe;
												case 11:
												case 97:
													goto IL_060c;
												case 85:
													goto IL_061a;
												case 79:
													goto IL_063d;
												case 93:
													goto IL_0647;
												case 37:
													goto IL_0655;
												case 83:
													goto IL_0668;
												case 2:
												case 90:
													goto IL_0678;
												case 28:
													goto IL_06b8;
												case 84:
													goto IL_06cc;
												case 20:
												case 26:
												case 41:
												case 44:
												case 45:
												case 51:
												case 52:
												case 53:
												case 56:
												case 57:
												case 64:
												case 65:
												case 68:
												case 69:
												case 73:
												case 75:
												case 82:
												case 98:
												case 99:
												case 103:
												case 108:
													goto IL_06e8;
												case 17:
												case 49:
													goto IL_0700;
												}
												continue;
												IL_0678:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_06b8;
												IL_06b8:
												array[num4 - 2] = 0;
												goto IL_06cc;
												IL_0290:
												if (num5 != 1)
												{
													goto IL_02a0;
												}
												goto IL_0700;
												IL_0700:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_02a0:
												b = *ptr2;
												goto IL_02a9;
												IL_02a9:
												ptr2++;
												goto IL_02b7;
												IL_02b7:
												if (b >= 1)
												{
													goto IL_02c5;
												}
												goto IL_06e8;
												IL_02c5:
												if (b <= 11)
												{
													goto IL_02d3;
												}
												goto IL_06e8;
												IL_02d3:
												if (6 < b)
												{
													goto IL_02e1;
												}
												goto IL_04ca;
												IL_02e1:
												if (9 >= b)
												{
													goto IL_02ef;
												}
												goto IL_0474;
												IL_02ef:
												if (9 <= b)
												{
													goto IL_02fa;
												}
												goto IL_036f;
												IL_02fa:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_035c;
												IL_035c:
												num4 -= 2;
												goto IL_0290;
												IL_036f:
												if (7 >= b)
												{
													goto IL_037d;
												}
												goto IL_03fd;
												IL_037d:
												if (7 <= b)
												{
													goto IL_0396;
												}
												num = 68;
												goto IL_06e8;
												IL_06cc:
												num4--;
												num = 111;
												goto IL_0290;
												IL_0396:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_03d6;
												IL_03d6:
												array[num4 - 2] = 0;
												goto IL_03ea;
												IL_03ea:
												num4--;
												goto IL_0290;
												IL_03fd:
												if (8 >= b)
												{
													goto IL_040b;
												}
												goto IL_06e8;
												IL_040b:
												if (8 <= b)
												{
													num = 10;
													goto IL_0422;
												}
												goto IL_06e8;
												IL_06e8:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0290;
												IL_0422:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0445;
												IL_0445:
												array[num4] = 0;
												goto IL_0453;
												IL_0453:
												num4++;
												goto IL_0461;
												IL_0461:
												ptr2 += 8;
												goto IL_0290;
												IL_0474:
												if (10 >= b)
												{
													goto IL_047f;
												}
												goto IL_04a9;
												IL_047f:
												if (10 <= b)
												{
													goto IL_048d;
												}
												goto IL_06e8;
												IL_048d:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_0290;
												IL_04a9:
												if (11 >= b)
												{
													goto IL_04b7;
												}
												goto IL_06e8;
												IL_04b7:
												if (11 <= b)
												{
												}
												goto IL_06e8;
												IL_04ca:
												if (6 > b)
												{
													goto IL_04d8;
												}
												goto IL_0678;
												IL_04d8:
												if (3 >= b)
												{
													goto IL_04e6;
												}
												goto IL_05e5;
												IL_04e6:
												if (3 > b)
												{
													goto IL_04f4;
												}
												goto IL_05cd;
												IL_04f4:
												if (1 < b)
												{
													goto IL_04ff;
												}
												goto IL_056e;
												IL_04ff:
												if (2 >= b)
												{
													goto IL_050d;
												}
												goto IL_06e8;
												IL_050d:
												if (2 <= b)
												{
													goto IL_051b;
												}
												goto IL_06e8;
												IL_051b:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												num = 66;
												goto IL_054d;
												IL_054d:
												ptr2 += 8;
												goto IL_055b;
												IL_055b:
												num4--;
												goto IL_0290;
												IL_056e:
												if (1 <= b)
												{
													goto IL_057c;
												}
												goto IL_06e8;
												IL_057c:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												num = 40;
												goto IL_059e;
												IL_059e:
												array[num4] = 0;
												goto IL_05ac;
												IL_05ac:
												num4++;
												goto IL_05ba;
												IL_05ba:
												ptr2 += 8;
												goto IL_0290;
												IL_05cd:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0290;
												IL_05e5:
												if (4 < b)
												{
													goto IL_05f0;
												}
												goto IL_0668;
												IL_05f0:
												if (5 >= b)
												{
													goto IL_05fe;
												}
												goto IL_06e8;
												IL_05fe:
												if (5 <= b)
												{
													goto IL_060c;
												}
												goto IL_06e8;
												IL_060c:
												array[num4] = 0;
												goto IL_061a;
												IL_061a:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_063d;
												IL_063d:
												array2[num4] = null;
												goto IL_0647;
												IL_0647:
												num4++;
												goto IL_0655;
												IL_0655:
												ptr2 += 8;
												goto IL_0290;
												IL_0668:
												if (4 <= b)
												{
													goto IL_0290;
												}
												goto IL_06e8;
												continue;
												end_IL_01ef:
												break;
											}
											continue;
											end_IL_0202:
											break;
										}
										continue;
										end_IL_0215:
										break;
									}
									continue;
									end_IL_0220:
									break;
								}
								continue;
								end_IL_0235:
								break;
							}
							continue;
							end_IL_0245:
							break;
						}
						continue;
						end_IL_0255:
						break;
					}
					continue;
					end_IL_0265:
					break;
				}
				continue;
				end_IL_0275:
				break;
			}
		}
	}

	static Class153()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 4;
					while (true)
					{
						num = 15;
						while (true)
						{
							if (num != 15)
							{
								if (num != 996)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 1:
								case 4:
								case 7:
									goto end_IL_0048;
								case 5:
								case 8:
									goto end_IL_0055;
								case 2:
									goto end_IL_006a;
								case 3:
									goto end_IL_0079;
								case 6:
									return;
								}
								continue;
							}
							num = 6;
							return;
							continue;
							end_IL_0048:
							break;
						}
						continue;
						end_IL_0055:
						break;
					}
					continue;
					end_IL_006a:
					break;
				}
				continue;
				end_IL_0079:
				break;
			}
		}
	}
}
