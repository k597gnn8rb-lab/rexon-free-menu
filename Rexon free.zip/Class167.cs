using System;
using System.Runtime.CompilerServices;
using ExitGames.Client.Photon;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Network Platforms", "Room", "See other Rexon users' platforms.", false, 8, ModType.const_0, false)]
internal class Class167 : MonoBehaviour
{
	private static Vector3 vector3_0;

	private GameObject[] gameObject_0;

	private GameObject[] gameObject_1;

	private bool bool_0;

	private static GradientColorKey[] gradientColorKey_0;

	private static double double_0;

	private static float float_0;

	private static double double_1;

	private static int int_0;

	private static float float_1;

	private static IntPtr[] VTBOOLgetCodeBase;

	private static IntPtr[] setIsReadOnlyGetDefaultWriter;

	private static IntPtr[] DXNMgetLeaseManagerPollTime;

	private static IntPtr[] SetAuditADEra;

	private static IntPtr[] getDeniedPermissionsIUnknownConstantAttribute;

	private static IntPtr[] AssemblyVersionAttributeCreateProxy;

	private static IntPtr[] GetClassLayoutTYPEATTR;

	private static IntPtr[] getPermissionSetNameMetadataSectionContentType;

	private static IntPtr[] RuntimeTypeCacheGetCultureInfo;

	private unsafe void OnEnable()
	{
		int num = 154;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 170;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									num = 68;
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StringToCoTaskMemAutogetAsUi.getNextActivatorReuseSlot);
											num = 109;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 177;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															IL_049f:
															byte b = *ptr2;
															while (true)
															{
																IL_048f:
																ptr2++;
																while (true)
																{
																	IL_047f:
																	if (b >= 1)
																	{
																		while (b <= 21)
																		{
																			while (true)
																			{
																				IL_045f:
																				if (11 >= b)
																				{
																					while (11 > b)
																					{
																						while (true)
																						{
																							IL_043f:
																							if (5 < b)
																							{
																								while (true)
																								{
																									IL_042f:
																									if (8 >= b)
																									{
																										while (true)
																										{
																											IL_041f:
																											if (8 > b)
																											{
																												while (true)
																												{
																													IL_040f:
																													if (6 < b)
																													{
																														while (7 >= b)
																														{
																															while (7 <= b)
																															{
																																while (true)
																																{
																																	IL_03ad:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																	while (true)
																																	{
																																		IL_0397:
																																		array[num5 - 2] = 0;
																																		while (true)
																																		{
																																			IL_037e:
																																			num5--;
																																			num = 215;
																																			while (num != 215 && num == 1196)
																																			{
																																				switch (num)
																																				{
																																				case 184:
																																					goto IL_037e;
																																				case 80:
																																					goto IL_0397;
																																				case 82:
																																				case 122:
																																					goto IL_03ad;
																																				case 8:
																																					goto IL_03ef;
																																				case 147:
																																					goto IL_03ff;
																																				case 21:
																																					goto IL_040f;
																																				case 5:
																																					goto IL_041f;
																																				case 39:
																																					goto IL_042f;
																																				case 189:
																																					goto IL_043f;
																																				case 7:
																																					goto IL_044f;
																																				case 114:
																																					goto IL_045f;
																																				case 17:
																																					goto IL_046f;
																																				case 1:
																																					goto IL_047f;
																																				case 103:
																																					goto IL_048f;
																																				case 65:
																																				case 207:
																																					goto IL_049f;
																																				case 67:
																																					goto IL_04aa;
																																				case 52:
																																				case 72:
																																					goto IL_04bd;
																																				case 93:
																																					goto IL_04d0;
																																				case 161:
																																					goto IL_04de;
																																				case 32:
																																				case 148:
																																					goto IL_04e9;
																																				case 164:
																																					goto IL_0502;
																																				case 73:
																																				case 85:
																																					goto IL_0510;
																																				case 116:
																																					goto IL_0539;
																																				case 172:
																																					goto IL_0547;
																																				case 179:
																																					goto IL_055a;
																																				case 18:
																																					goto IL_0568;
																																				case 128:
																																					goto IL_0576;
																																				case 47:
																																				case 142:
																																					goto IL_0584;
																																				case 95:
																																					goto IL_059d;
																																				case 112:
																																					goto IL_05ab;
																																				case 156:
																																					goto IL_05b9;
																																				case 88:
																																				case 183:
																																					goto IL_05cc;
																																				case 11:
																																					goto IL_0615;
																																				case 40:
																																					goto IL_0632;
																																				case 77:
																																				case 185:
																																					goto IL_0645;
																																				case 138:
																																					goto IL_0685;
																																				case 83:
																																					goto IL_0699;
																																				case 155:
																																				case 196:
																																					goto IL_06ac;
																																				case 160:
																																				case 198:
																																					goto IL_06f1;
																																				case 19:
																																					goto IL_06fc;
																																				case 41:
																																				case 55:
																																					goto IL_070a;
																																				case 86:
																																					goto IL_0721;
																																				case 54:
																																					goto IL_0744;
																																				case 200:
																																					goto IL_075e;
																																				case 151:
																																					goto IL_076c;
																																				case 204:
																																					goto IL_077f;
																																				case 15:
																																					goto IL_0793;
																																				case 135:
																																					goto IL_07a6;
																																				case 45:
																																					goto IL_07b1;
																																				case 136:
																																				case 145:
																																					goto IL_07bf;
																																				case 63:
																																					goto IL_07ff;
																																				case 36:
																																					goto IL_081c;
																																				case 69:
																																				case 199:
																																					goto IL_082f;
																																				case 6:
																																					goto IL_083d;
																																				case 35:
																																				case 171:
																																					goto IL_084b;
																																				case 78:
																																					goto IL_08b6;
																																				case 64:
																																					goto IL_08c9;
																																				case 193:
																																					goto IL_08d7;
																																				case 20:
																																				case 60:
																																					goto IL_08e5;
																																				case 3:
																																				case 57:
																																					goto IL_08f3;
																																				case 101:
																																					goto IL_08fe;
																																				case 107:
																																				case 140:
																																					goto IL_090c;
																																				case 30:
																																					goto IL_096a;
																																				case 44:
																																					goto IL_097d;
																																				case 130:
																																					goto IL_098b;
																																				case 24:
																																				case 90:
																																					goto IL_0999;
																																				case 121:
																																					goto IL_09b7;
																																				case 94:
																																					goto IL_09c5;
																																				case 159:
																																					goto IL_09d3;
																																				case 202:
																																					goto IL_09ef;
																																				case 118:
																																				case 133:
																																					goto IL_09fa;
																																				case 100:
																																					goto IL_0a08;
																																				case 91:
																																				case 129:
																																					goto IL_0a1f;
																																				case 81:
																																					goto IL_0a37;
																																				case 182:
																																					goto IL_0a45;
																																				case 152:
																																					goto IL_0a53;
																																				case 42:
																																				case 106:
																																					goto IL_0a66;
																																				case 167:
																																					goto IL_0aa4;
																																				case 97:
																																					goto IL_0ab8;
																																				case 165:
																																				case 166:
																																					goto IL_0acb;
																																				case 0:
																																					goto IL_0ae0;
																																				case 169:
																																					goto IL_0aee;
																																				case 162:
																																					goto IL_0b01;
																																				case 71:
																																				case 150:
																																					goto IL_0b0c;
																																				case 29:
																																				case 70:
																																					goto IL_0b17;
																																				case 181:
																																					goto IL_0b25;
																																				case 28:
																																					goto IL_0b38;
																																				case 123:
																																				case 194:
																																					goto IL_0b46;
																																				case 9:
																																					goto IL_0b6b;
																																				case 105:
																																				case 158:
																																					goto IL_0b79;
																																				case 12:
																																					goto IL_0b87;
																																				case 10:
																																				case 56:
																																					goto IL_0b95;
																																				case 104:
																																					goto IL_0ba9;
																																				case 87:
																																					goto IL_0bff;
																																				case 190:
																																					goto IL_0c0d;
																																				case 186:
																																					goto IL_0c20;
																																				case 115:
																																					goto IL_0c2e;
																																				case 173:
																																				case 192:
																																					goto IL_0c3c;
																																				case 108:
																																					goto IL_0c79;
																																				case 46:
																																					goto IL_0c87;
																																				case 113:
																																				case 195:
																																					goto IL_0c97;
																																				case 14:
																																					goto IL_0cce;
																																				case 13:
																																				case 16:
																																				case 22:
																																				case 25:
																																				case 26:
																																				case 27:
																																				case 31:
																																				case 38:
																																				case 43:
																																				case 48:
																																				case 49:
																																				case 50:
																																				case 51:
																																				case 53:
																																				case 58:
																																				case 61:
																																				case 62:
																																				case 74:
																																				case 76:
																																				case 79:
																																				case 84:
																																				case 92:
																																				case 110:
																																				case 111:
																																				case 117:
																																				case 119:
																																				case 120:
																																				case 125:
																																				case 127:
																																				case 131:
																																				case 139:
																																				case 141:
																																				case 143:
																																				case 146:
																																				case 168:
																																				case 174:
																																				case 180:
																																				case 187:
																																				case 201:
																																				case 203:
																																				case 206:
																																					goto end_IL_03ef;
																																				case 2:
																																				case 4:
																																				case 23:
																																				case 33:
																																				case 75:
																																				case 96:
																																				case 102:
																																				case 124:
																																				case 132:
																																				case 134:
																																				case 144:
																																				case 149:
																																				case 157:
																																				case 163:
																																				case 175:
																																				case 176:
																																				case 177:
																																				case 178:
																																				case 191:
																																				case 197:
																																				case 205:
																																				case 208:
																																					goto end_IL_036b;
																																				case 137:
																																					goto end_IL_0cf1;
																																				case 109:
																																					goto end_IL_0d04;
																																				case 126:
																																					goto end_IL_0d0f;
																																				case 68:
																																					goto end_IL_0d19;
																																				case 99:
																																					goto end_IL_0d2d;
																																				case 188:
																																					goto end_IL_0d3d;
																																				case 34:
																																				case 89:
																																					goto end_IL_0d56;
																																				case 170:
																																					goto end_IL_0d66;
																																				case 37:
																																				case 66:
																																					goto end_IL_0d76;
																																				case 153:
																																					goto end_IL_0d86;
																																				case 154:
																																					goto end_IL_0d9f;
																																				case 59:
																																				case 98:
																																					return;
																																				}
																																				continue;
																																				end_IL_036b:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto end_IL_044f;
																																continue;
																																end_IL_03ef:
																																break;
																																IL_03ef:;
																															}
																															break;
																															IL_03ff:;
																														}
																														break;
																													}
																													goto IL_04aa;
																													IL_0632:
																													num5--;
																													goto end_IL_044f;
																													IL_04aa:
																													if (6 > b)
																													{
																														break;
																													}
																													goto IL_05cc;
																													IL_05cc:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 11;
																													goto IL_0615;
																													IL_0615:
																													array[num5 - 2] = 0;
																													num = 40;
																													goto IL_0632;
																												}
																												break;
																											}
																											goto IL_04bd;
																											IL_04bd:
																											num5--;
																											goto end_IL_044f;
																										}
																										break;
																									}
																									goto IL_07a6;
																									IL_08b6:
																									num5 -= 2;
																									goto end_IL_044f;
																									IL_07a6:
																									if (9 >= b)
																									{
																										goto IL_07b1;
																									}
																									goto IL_082f;
																									IL_07b1:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_07bf;
																									IL_07bf:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_07ff;
																									IL_07ff:
																									array[num5 - 2] = 0;
																									num = 36;
																									goto IL_081c;
																									IL_081c:
																									num5--;
																									goto end_IL_044f;
																									IL_082f:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_083d;
																									IL_083d:
																									if (10 > b)
																									{
																										break;
																									}
																									goto IL_084b;
																									IL_084b:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 78;
																									goto IL_08b6;
																								}
																								break;
																							}
																							goto IL_04d0;
																							IL_06ac:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_077f;
																							IL_04d0:
																							if (5 > b)
																							{
																								goto IL_04de;
																							}
																							goto IL_06ac;
																							IL_04de:
																							if (2 < b)
																							{
																								goto IL_04e9;
																							}
																							goto IL_055a;
																							IL_04e9:
																							if (3 >= b)
																							{
																								goto IL_0502;
																							}
																							num = 198;
																							goto IL_06f1;
																							IL_077f:
																							array[num5 - 2] = 0;
																							goto IL_0793;
																							IL_06f1:
																							if (4 < b)
																							{
																								num = 119;
																								break;
																							}
																							goto IL_06fc;
																							IL_06fc:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_070a;
																							IL_070a:
																							array[num5] = 0;
																							num = 86;
																							goto IL_0721;
																							IL_0721:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0744;
																							IL_0744:
																							array2[num5] = null;
																							goto IL_075e;
																							IL_075e:
																							num5++;
																							goto IL_076c;
																							IL_076c:
																							ptr2 += 8;
																							goto end_IL_044f;
																							IL_0793:
																							num5--;
																							goto end_IL_044f;
																							IL_0502:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0510;
																							IL_0510:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0539;
																							IL_0539:
																							ptr2 += 8;
																							goto IL_0547;
																							IL_0547:
																							num5--;
																							goto end_IL_044f;
																							IL_055a:
																							if (2 > b)
																							{
																								goto IL_0568;
																							}
																							goto IL_0645;
																							IL_0568:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0576;
																							IL_0576:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0584;
																							IL_0584:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_059d;
																							IL_059d:
																							array[num5] = 0;
																							goto IL_05ab;
																							IL_05ab:
																							num5++;
																							goto IL_05b9;
																							IL_05b9:
																							ptr2 += 8;
																							goto end_IL_044f;
																							IL_0645:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0685;
																							IL_0685:
																							array[num5 - 2] = 0;
																							goto IL_0699;
																							IL_0699:
																							num5--;
																							goto end_IL_044f;
																						}
																						goto end_IL_046f;
																						continue;
																						end_IL_044f:
																						break;
																						IL_044f:;
																					}
																					break;
																				}
																				goto IL_08c9;
																				IL_0c97:
																				((Class167)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																				num = 14;
																				goto IL_0cce;
																				IL_08c9:
																				if (16 >= b)
																				{
																					goto IL_08d7;
																				}
																				goto IL_0b01;
																				IL_08d7:
																				if (16 > b)
																				{
																					goto IL_08e5;
																				}
																				goto IL_0acb;
																				IL_08e5:
																				if (13 < b)
																				{
																					goto IL_08f3;
																				}
																				goto IL_09ef;
																				IL_08f3:
																				if (14 >= b)
																				{
																					goto IL_08fe;
																				}
																				goto IL_097d;
																				IL_08fe:
																				if (14 > b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_090c;
																				IL_090c:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_096a;
																				IL_096a:
																				num5--;
																				break;
																				IL_097d:
																				if (15 < b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_098b;
																				IL_098b:
																				if (15 > b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0999;
																				IL_0999:
																				array2[num5] = ((delegate*<LoadBalancingClient>)VTBOOLgetCodeBase[*(int*)(ptr2 + num3)])();
																				goto IL_09b7;
																				IL_09b7:
																				array[num5] = 5;
																				goto IL_09c5;
																				IL_09c5:
																				num5++;
																				goto IL_09d3;
																				IL_09d3:
																				ptr2 += 8;
																				num = 197;
																				break;
																				IL_09ef:
																				if (13 > b)
																				{
																					goto IL_09fa;
																				}
																				goto IL_0a66;
																				IL_09fa:
																				if (12 < b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0a08;
																				IL_0a08:
																				if (12 > b)
																				{
																					goto end_IL_046f;
																				}
																				num = 129;
																				goto IL_0a1f;
																				IL_0cce:
																				num5 -= 2;
																				break;
																				IL_0a1f:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0a37;
																				IL_0a37:
																				array[num5] = 5;
																				goto IL_0a45;
																				IL_0a45:
																				num5++;
																				goto IL_0a53;
																				IL_0a53:
																				ptr2 += 8;
																				break;
																				IL_0a66:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Class167, bool>)VTBOOLgetCodeBase[*(int*)(ptr2 + num3)])((Class167)array2[num5 - 1]) ? 1 : 0);
																				goto IL_0aa4;
																				IL_0aa4:
																				array[num5 - 1] = 0;
																				goto IL_0ab8;
																				IL_0ab8:
																				ptr2 += 8;
																				break;
																				IL_0acb:
																				*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (void*)0;
																				goto IL_0ae0;
																				IL_0ae0:
																				array[num5] = 2;
																				goto IL_0aee;
																				IL_0aee:
																				num5++;
																				break;
																				IL_0b01:
																				if (19 < b)
																				{
																					goto IL_0b0c;
																				}
																				goto IL_0b6b;
																				IL_0b0c:
																				if (20 < b)
																				{
																					goto IL_0b17;
																				}
																				goto IL_0b38;
																				IL_0b17:
																				if (21 < b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0b25;
																				IL_0b25:
																				if (21 <= b)
																				{
																				}
																				goto end_IL_046f;
																				IL_0b38:
																				if (20 > b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0b46;
																				IL_0b46:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 176;
																				break;
																				IL_0b6b:
																				if (19 > b)
																				{
																					goto IL_0b79;
																				}
																				goto IL_0c97;
																				IL_0b79:
																				if (17 >= b)
																				{
																					goto IL_0b87;
																				}
																				goto IL_0c20;
																				IL_0b87:
																				if (17 > b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0b95;
																				IL_0b95:
																				array[num5 - 2] = 5;
																				goto IL_0ba9;
																				IL_0ba9:
																				array2[num5 - 2] = ((delegate*<object, IntPtr, Action<EventData>>)VTBOOLgetCodeBase[*(int*)(ptr2 + num3)])((Class167)array2[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				num = 87;
																				goto IL_0bff;
																				IL_0bff:
																				num5--;
																				goto IL_0c0d;
																				IL_0c0d:
																				ptr2 += 8;
																				break;
																				IL_0c20:
																				if (18 < b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0c2e;
																				IL_0c2e:
																				if (18 > b)
																				{
																					goto end_IL_046f;
																				}
																				goto IL_0c3c;
																				IL_0c3c:
																				((delegate*<LoadBalancingClient, Action<EventData>, void>)VTBOOLgetCodeBase[*(int*)(ptr2 + num3)])((LoadBalancingClient)array2[num5 - 2], (Action<EventData>)array2[num5 - 1]);
																				goto IL_0c79;
																				IL_0c79:
																				num5 -= 2;
																				goto IL_0c87;
																				IL_0c87:
																				ptr2 += 8;
																				break;
																			}
																			goto end_IL_047f;
																			continue;
																			end_IL_046f:
																			break;
																			IL_046f:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_047f:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0cf1:
														break;
													}
													continue;
													end_IL_0d04:
													break;
												}
												continue;
												end_IL_0d0f:
												break;
											}
											continue;
											end_IL_0d19:
											break;
										}
										continue;
										end_IL_0d2d:
										break;
									}
									continue;
									end_IL_0d3d:
									break;
								}
								continue;
								end_IL_0d56:
								break;
							}
							continue;
							end_IL_0d66:
							break;
						}
						continue;
						end_IL_0d76:
						break;
					}
					continue;
					end_IL_0d86:
					break;
				}
				continue;
				end_IL_0d9f:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 123;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								num = 66;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IBindableVectorReturnValueInArray.ReleaseAllResourcesChangeNamedPermissionSet);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_04ac:
														byte b = *ptr2;
														while (true)
														{
															IL_049c:
															ptr2++;
															while (true)
															{
																IL_048c:
																if (b >= 1)
																{
																	while (b <= 22)
																	{
																		while (true)
																		{
																			IL_046c:
																			if (11 >= b)
																			{
																				while (11 > b)
																				{
																					while (true)
																					{
																						IL_044f:
																						if (5 < b)
																						{
																							while (true)
																							{
																								IL_043f:
																								if (8 >= b)
																								{
																									while (true)
																									{
																										IL_042f:
																										if (8 > b)
																										{
																											while (true)
																											{
																												IL_041f:
																												if (6 >= b)
																												{
																													while (6 <= b)
																													{
																														while (true)
																														{
																															IL_03cd:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_03ae:
																																array[num5 - 2] = 0;
																																num = 227;
																																while (true)
																																{
																																	if (num != 227)
																																	{
																																		if (num != 1208)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 64:
																																			goto IL_03ae;
																																		case 0:
																																		case 87:
																																			goto IL_03cd;
																																		case 8:
																																			goto IL_040f;
																																		case 91:
																																		case 149:
																																			goto IL_041f;
																																		case 68:
																																			goto IL_042f;
																																		case 129:
																																			goto IL_043f;
																																		case 113:
																																		case 170:
																																			goto IL_044f;
																																		case 86:
																																			goto IL_045c;
																																		case 45:
																																			goto IL_046c;
																																		case 65:
																																			goto IL_047c;
																																		case 78:
																																			goto IL_048c;
																																		case 15:
																																			goto IL_049c;
																																		case 72:
																																		case 102:
																																			goto IL_04ac;
																																		case 79:
																																			goto IL_04b7;
																																		case 52:
																																		case 75:
																																			goto IL_04c5;
																																		case 46:
																																			goto IL_0505;
																																		case 14:
																																			goto IL_0519;
																																		case 10:
																																		case 127:
																																			goto IL_052c;
																																		case 21:
																																			goto IL_053a;
																																		case 94:
																																			goto IL_0545;
																																		case 150:
																																			goto IL_0553;
																																		case 138:
																																		case 139:
																																			goto IL_0561;
																																		case 156:
																																			goto IL_057d;
																																		case 110:
																																			goto IL_0588;
																																		case 37:
																																			goto IL_0593;
																																		case 16:
																																			goto IL_05a6;
																																		case 71:
																																		case 147:
																																			goto IL_05b9;
																																		case 44:
																																		case 187:
																																			goto IL_05e7;
																																		case 34:
																																			goto IL_05f5;
																																		case 190:
																																			goto IL_0608;
																																		case 67:
																																		case 85:
																																			goto IL_0616;
																																		case 121:
																																			goto IL_062a;
																																		case 63:
																																			goto IL_0677;
																																		case 73:
																																			goto IL_0685;
																																		case 51:
																																		case 96:
																																			goto IL_0698;
																																		case 89:
																																			goto IL_06a6;
																																		case 120:
																																		case 126:
																																			goto IL_06b1;
																																		case 20:
																																			goto IL_0708;
																																		case 143:
																																			goto IL_0713;
																																		case 76:
																																		case 176:
																																			goto IL_0726;
																																		case 13:
																																			goto IL_0731;
																																		case 81:
																																		case 169:
																																			goto IL_073f;
																																		case 108:
																																		case 188:
																																			goto IL_078d;
																																		case 134:
																																			goto IL_0798;
																																		case 194:
																																			goto IL_07a8;
																																		case 197:
																																			goto IL_07bb;
																																		case 55:
																																		case 199:
																																			goto IL_07d1;
																																		case 201:
																																			goto IL_07e4;
																																		case 202:
																																			goto IL_07f7;
																																		case 92:
																																		case 203:
																																			goto IL_080a;
																																		case 157:
																																			goto IL_0828;
																																		case 114:
																																			goto IL_0836;
																																		case 17:
																																			goto IL_0844;
																																		case 4:
																																		case 205:
																																			goto IL_0857;
																																		case 25:
																																		case 166:
																																			goto IL_0865;
																																		case 180:
																																			goto IL_0870;
																																		case 5:
																																		case 164:
																																			goto IL_087e;
																																		case 6:
																																			goto IL_08a7;
																																		case 195:
																																			goto IL_08b5;
																																		case 54:
																																		case 104:
																																			goto IL_08c8;
																																		case 29:
																																			goto IL_08d6;
																																		case 93:
																																		case 135:
																																			goto IL_08e4;
																																		case 186:
																																			goto IL_08f2;
																																		case 98:
																																			goto IL_0915;
																																		case 88:
																																			goto IL_091f;
																																		case 59:
																																			goto IL_0932;
																																		case 100:
																																		case 128:
																																			goto IL_093d;
																																		case 101:
																																			goto IL_0954;
																																		case 154:
																																		case 185:
																																			goto IL_096d;
																																		case 35:
																																			goto IL_0986;
																																		case 39:
																																			goto IL_0994;
																																		case 191:
																																		case 206:
																																			goto IL_09a7;
																																		case 3:
																																			goto IL_09e7;
																																		case 24:
																																			goto IL_09fb;
																																		case 208:
																																			goto IL_0a0e;
																																		case 82:
																																		case 209:
																																			goto IL_0a1c;
																																		case 181:
																																			goto IL_0a3a;
																																		case 130:
																																			goto IL_0a48;
																																		case 210:
																																			goto IL_0a5b;
																																		case 118:
																																		case 211:
																																			goto IL_0a6e;
																																		case 193:
																																			goto IL_0a86;
																																		case 7:
																																			goto IL_0a94;
																																		case 28:
																																			goto IL_0aa2;
																																		case 212:
																																			goto IL_0ab5;
																																		case 40:
																																		case 214:
																																			goto IL_0ac5;
																																		case 95:
																																			goto IL_0b02;
																																		case 142:
																																			goto IL_0b10;
																																		case 217:
																																			goto IL_0b23;
																																		case 179:
																																		case 219:
																																			goto IL_0b36;
																																		case 70:
																																			goto IL_0b64;
																																		case 220:
																																			goto IL_0b77;
																																		case 41:
																																		case 196:
																																			goto end_IL_039b;
																																		case 168:
																																			goto IL_0bb4;
																																		case 31:
																																		case 131:
																																			goto IL_0bc2;
																																		case 125:
																																			goto IL_0c0b;
																																		case 36:
																																			goto IL_0c1f;
																																		case 48:
																																		case 137:
																																			goto IL_0c32;
																																		case 215:
																																			goto IL_0c45;
																																		case 42:
																																		case 153:
																																			goto IL_0c53;
																																		case 109:
																																			goto IL_0c61;
																																		case 106:
																																		case 111:
																																			goto IL_0c78;
																																		case 167:
																																			goto IL_0cda;
																																		case 175:
																																			goto IL_0ced;
																																		case 47:
																																		case 216:
																																			goto IL_0cf8;
																																		case 19:
																																			goto IL_0d41;
																																		case 107:
																																			goto IL_0d55;
																																		case 1:
																																		case 2:
																																		case 9:
																																		case 18:
																																		case 22:
																																		case 27:
																																		case 38:
																																		case 49:
																																		case 50:
																																		case 56:
																																		case 57:
																																		case 61:
																																		case 77:
																																		case 105:
																																		case 116:
																																		case 119:
																																		case 124:
																																		case 132:
																																		case 144:
																																		case 145:
																																		case 151:
																																		case 155:
																																		case 158:
																																		case 159:
																																		case 160:
																																		case 161:
																																		case 162:
																																		case 163:
																																		case 165:
																																		case 171:
																																		case 173:
																																		case 177:
																																		case 178:
																																		case 182:
																																		case 183:
																																		case 189:
																																		case 198:
																																		case 200:
																																		case 207:
																																		case 213:
																																		case 218:
																																			goto end_IL_040f;
																																		case 11:
																																		case 12:
																																		case 23:
																																		case 26:
																																		case 30:
																																		case 43:
																																		case 53:
																																		case 58:
																																		case 60:
																																		case 69:
																																		case 74:
																																		case 80:
																																		case 83:
																																		case 84:
																																		case 90:
																																		case 97:
																																		case 103:
																																		case 112:
																																		case 140:
																																		case 141:
																																		case 148:
																																		case 152:
																																		case 174:
																																		case 192:
																																		case 204:
																																			goto end_IL_045c;
																																		case 172:
																																			goto end_IL_0d78;
																																		case 115:
																																			goto end_IL_0d8b;
																																		case 32:
																																			goto end_IL_0d95;
																																		case 66:
																																			goto end_IL_0da0;
																																		case 62:
																																			goto end_IL_0db0;
																																		case 146:
																																		case 184:
																																			goto end_IL_0dc0;
																																		case 133:
																																			goto end_IL_0dd9;
																																		case 33:
																																		case 117:
																																			goto end_IL_0de9;
																																		case 122:
																																			goto end_IL_0df9;
																																		case 123:
																																			goto end_IL_0e09;
																																		case 99:
																																		case 136:
																																			return;
																																		}
																																		continue;
																																	}
																																	num5--;
																																	goto end_IL_045c;
																																	continue;
																																	end_IL_039b:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0ba6;
																														continue;
																														end_IL_040f:
																														break;
																														IL_040f:;
																													}
																													break;
																												}
																												num = 41;
																												goto IL_0ba6;
																												IL_0c0b:
																												array[num5 - 2] = 0;
																												goto IL_0c1f;
																												IL_0c1f:
																												num5--;
																												goto end_IL_045c;
																												IL_0ba6:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_0bb4;
																												IL_0bb4:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_0bc2;
																												IL_0bc2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 125;
																												goto IL_0c0b;
																											}
																											break;
																										}
																										goto IL_0c32;
																										IL_0c32:
																										num5--;
																										goto end_IL_045c;
																									}
																									break;
																								}
																								goto IL_0c45;
																								IL_0d41:
																								array[num5 - 2] = 0;
																								goto IL_0d55;
																								IL_0c45:
																								if (9 < b)
																								{
																									goto IL_0c53;
																								}
																								goto IL_0ced;
																								IL_0c53:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0c61;
																								IL_0c61:
																								if (10 > b)
																								{
																									break;
																								}
																								num = 106;
																								goto IL_0c78;
																								IL_0d55:
																								num5--;
																								goto end_IL_045c;
																								IL_0c78:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0cda;
																								IL_0cda:
																								num5 -= 2;
																								goto end_IL_045c;
																								IL_0ced:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0cf8;
																								IL_0cf8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 19;
																								goto IL_0d41;
																							}
																							break;
																						}
																						goto IL_04b7;
																						IL_09a7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_09e7;
																						IL_04b7:
																						if (5 <= b)
																						{
																							goto IL_04c5;
																						}
																						goto IL_0857;
																						IL_04c5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0505;
																						IL_0505:
																						array[num5 - 2] = 0;
																						goto IL_0519;
																						IL_0519:
																						num5--;
																						goto end_IL_045c;
																						IL_0857:
																						if (2 < b)
																						{
																							goto IL_0865;
																						}
																						goto IL_0932;
																						IL_0865:
																						if (3 >= b)
																						{
																							goto IL_0870;
																						}
																						goto IL_08c8;
																						IL_0870:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_087e;
																						IL_087e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_08a7;
																						IL_08a7:
																						ptr2 += 8;
																						goto IL_08b5;
																						IL_08b5:
																						num5--;
																						goto end_IL_045c;
																						IL_08c8:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_08d6;
																						IL_08d6:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_08e4;
																						IL_08e4:
																						array[num5] = 0;
																						goto IL_08f2;
																						IL_08f2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0915;
																						IL_0915:
																						array2[num5] = null;
																						goto IL_091f;
																						IL_091f:
																						num5++;
																						goto IL_0b23;
																						IL_0b23:
																						ptr2 += 8;
																						goto end_IL_045c;
																						IL_0932:
																						if (2 > b)
																						{
																							goto IL_093d;
																						}
																						goto IL_09a7;
																						IL_093d:
																						if (1 < b)
																						{
																							break;
																						}
																						num = 101;
																						goto IL_0954;
																						IL_09e7:
																						array[num5 - 2] = 0;
																						goto IL_09fb;
																						IL_0954:
																						if (1 > b)
																						{
																							num = 49;
																							break;
																						}
																						goto IL_096d;
																						IL_09fb:
																						num5--;
																						goto end_IL_045c;
																						IL_096d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0986;
																						IL_0986:
																						array[num5] = 0;
																						goto IL_0994;
																						IL_0994:
																						num5++;
																						goto IL_0b77;
																						IL_0b77:
																						ptr2 += 8;
																						goto end_IL_045c;
																					}
																					goto end_IL_047c;
																					continue;
																					end_IL_045c:
																					break;
																					IL_045c:;
																				}
																				break;
																			}
																			goto IL_052c;
																			IL_0a3a:
																			array[num5] = 2;
																			goto IL_0a48;
																			IL_052c:
																			if (17 < b)
																			{
																				goto IL_053a;
																			}
																			goto IL_0608;
																			IL_053a:
																			if (20 < b)
																			{
																				goto IL_0545;
																			}
																			goto IL_057d;
																			IL_0545:
																			if (21 >= b)
																			{
																				goto IL_0553;
																			}
																			goto IL_05e7;
																			IL_0553:
																			if (21 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0561;
																			IL_0561:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_05e7:
																			if (22 < b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_05f5;
																			IL_05f5:
																			if (22 <= b)
																			{
																			}
																			goto end_IL_047c;
																			IL_057d:
																			if (20 > b)
																			{
																				goto IL_0588;
																			}
																			goto IL_05b9;
																			IL_0588:
																			if (18 >= b)
																			{
																				goto IL_0593;
																			}
																			goto IL_05a6;
																			IL_0593:
																			if (18 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0ac5;
																			IL_0ac5:
																			((delegate*<LoadBalancingClient, Action<EventData>, void>)setIsReadOnlyGetDefaultWriter[*(int*)(ptr2 + num3)])((LoadBalancingClient)array2[num5 - 2], (Action<EventData>)array2[num5 - 1]);
																			goto IL_0b02;
																			IL_0b02:
																			num5 -= 2;
																			goto IL_0b10;
																			IL_0b10:
																			ptr2 += 8;
																			break;
																			IL_05a6:
																			if (19 < b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0ab5;
																			IL_0ab5:
																			if (19 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0b36;
																			IL_0b36:
																			((Class167)array2[num5 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0b64;
																			IL_0b64:
																			num5 -= 2;
																			break;
																			IL_05b9:
																			((delegate*<Class167, void>)setIsReadOnlyGetDefaultWriter[*(int*)(ptr2 + num3)])((Class167)array2[num5 - 1]);
																			goto IL_07e4;
																			IL_07e4:
																			num5--;
																			goto IL_0a5b;
																			IL_0a5b:
																			ptr2 += 8;
																			break;
																			IL_0608:
																			if (17 <= b)
																			{
																				goto IL_0616;
																			}
																			goto IL_0698;
																			IL_0616:
																			array[num5 - 2] = 5;
																			goto IL_062a;
																			IL_062a:
																			array2[num5 - 2] = ((delegate*<object, IntPtr, Action<EventData>>)setIsReadOnlyGetDefaultWriter[*(int*)(ptr2 + num3)])((Class167)array2[num5 - 2], *(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0677;
																			IL_0677:
																			num5--;
																			goto IL_0685;
																			IL_0685:
																			ptr2 += 8;
																			break;
																			IL_0698:
																			if (14 >= b)
																			{
																				goto IL_06a6;
																			}
																			goto IL_078d;
																			IL_06a6:
																			if (14 <= b)
																			{
																				goto IL_06b1;
																			}
																			goto IL_0708;
																			IL_06b1:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_07a8;
																			IL_07a8:
																			num5--;
																			break;
																			IL_0708:
																			if (12 >= b)
																			{
																				goto IL_0713;
																			}
																			goto IL_0726;
																			IL_0713:
																			if (12 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0a6e;
																			IL_0a6e:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0a86;
																			IL_0a86:
																			array[num5] = 5;
																			goto IL_0a94;
																			IL_0a94:
																			num5++;
																			goto IL_0aa2;
																			IL_0aa2:
																			ptr2 += 8;
																			break;
																			IL_0726:
																			if (13 < b)
																			{
																				num = 116;
																				goto end_IL_047c;
																			}
																			goto IL_0731;
																			IL_0731:
																			if (13 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_073f;
																			IL_073f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Class167, bool>)setIsReadOnlyGetDefaultWriter[*(int*)(ptr2 + num3)])((Class167)array2[num5 - 1]) ? 1 : 0);
																			goto IL_07bb;
																			IL_07bb:
																			array[num5 - 1] = 0;
																			goto IL_07f7;
																			IL_07f7:
																			ptr2 += 8;
																			break;
																			IL_0a48:
																			num5++;
																			break;
																			IL_078d:
																			if (15 >= b)
																			{
																				goto IL_0798;
																			}
																			goto IL_07d1;
																			IL_0798:
																			if (15 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_080a;
																			IL_080a:
																			array2[num5] = ((delegate*<LoadBalancingClient>)setIsReadOnlyGetDefaultWriter[*(int*)(ptr2 + num3)])();
																			goto IL_0828;
																			IL_0828:
																			array[num5] = 5;
																			goto IL_0836;
																			IL_0836:
																			num5++;
																			goto IL_0844;
																			IL_0844:
																			ptr2 += 8;
																			break;
																			IL_07d1:
																			if (16 < b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0a0e;
																			IL_0a0e:
																			if (16 > b)
																			{
																				goto end_IL_047c;
																			}
																			goto IL_0a1c;
																			IL_0a1c:
																			*(void**)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (void*)0;
																			num = 181;
																			goto IL_0a3a;
																		}
																		goto end_IL_048c;
																		continue;
																		end_IL_047c:
																		break;
																		IL_047c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_048c:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0d78:
													break;
												}
												continue;
												end_IL_0d8b:
												break;
											}
											continue;
											end_IL_0d95:
											break;
										}
										continue;
										end_IL_0da0:
										break;
									}
									continue;
									end_IL_0db0:
									break;
								}
								continue;
								end_IL_0dc0:
								break;
							}
							continue;
							end_IL_0dd9:
							break;
						}
						continue;
						end_IL_0de9:
						break;
					}
					continue;
					end_IL_0df9:
					break;
				}
				continue;
				end_IL_0e09:
				break;
			}
		}
	}

	private unsafe void method_0(EventData eventData_0)
	{
		int num = 38;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[2];
										while (true)
										{
											array5[0] = eventData_0;
											num = 155;
											while (true)
											{
												array5[1] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FromOADateCMSSECTIONIDCLRSURROGATESECTION.GetIDispatchForObjectInContextAssemblyLoadEventHandler);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_09c4:
																		if (b >= 1)
																		{
																			while (b <= 69)
																			{
																				while (true)
																				{
																					if (35 >= b)
																					{
																						while (true)
																						{
																							if (35 > b)
																							{
																								while (true)
																								{
																									if (17 < b)
																									{
																										while (true)
																										{
																											if (26 >= b)
																											{
																												while (true)
																												{
																													if (26 > b)
																													{
																														while (true)
																														{
																															if (21 < b)
																															{
																																while (true)
																																{
																																	IL_0944:
																																	if (23 < b)
																																	{
																																		goto IL_1484;
																																	}
																																	while (true)
																																	{
																																		IL_0934:
																																		if (23 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_0906:
																																				array2[num6] = ((delegate*<Vector3>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])();
																																				num = 569;
																																				while (true)
																																				{
																																					if (num != 569)
																																					{
																																						if (num != 1550)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 52:
																																						case 288:
																																							goto IL_0906;
																																						case 130:
																																							goto IL_0934;
																																						case 157:
																																							goto IL_0944;
																																						case 169:
																																							goto end_IL_0944;
																																						case 43:
																																							goto end_IL_0954;
																																						case 470:
																																							goto end_IL_0964;
																																						case 45:
																																							goto end_IL_0974;
																																						case 246:
																																							goto end_IL_0984;
																																						case 514:
																																							goto end_IL_0994;
																																						case 161:
																																							goto end_IL_09a4;
																																						case 5:
																																							goto IL_09c4;
																																						case 254:
																																							goto end_IL_09c4;
																																						case 3:
																																						case 14:
																																							goto end_IL_09d4;
																																						case 236:
																																							goto IL_09ef;
																																						case 120:
																																							goto IL_09fd;
																																						case 39:
																																							goto IL_0a0b;
																																						case 75:
																																							goto IL_0a19;
																																						case 323:
																																							goto IL_0a2c;
																																						case 10:
																																						case 250:
																																							goto IL_0a37;
																																						case 133:
																																							goto IL_0a54;
																																						case 266:
																																							goto IL_0a62;
																																						case 135:
																																							goto IL_0a70;
																																						case 172:
																																							goto IL_0a7e;
																																						case 80:
																																							goto IL_0a8c;
																																						case 193:
																																							goto IL_0a97;
																																						case 100:
																																						case 183:
																																							goto IL_0aaa;
																																						case 277:
																																							goto IL_0b0c;
																																						case 242:
																																							goto IL_0b28;
																																						case 320:
																																							goto IL_0b36;
																																						case 109:
																																							goto IL_0b49;
																																						case 244:
																																							goto IL_0b57;
																																						case 162:
																																							goto IL_0b65;
																																						case 303:
																																							goto IL_0b73;
																																						case 34:
																																						case 208:
																																							goto IL_0b81;
																																						case 136:
																																							goto IL_0ba8;
																																						case 174:
																																							goto IL_0bc1;
																																						case 86:
																																							goto IL_0bcf;
																																						case 214:
																																							goto IL_0bda;
																																						case 241:
																																						case 280:
																																							goto IL_0be8;
																																						case 152:
																																							goto IL_0c28;
																																						case 271:
																																							goto IL_0c3e;
																																						case 260:
																																							goto IL_0c55;
																																						case 384:
																																							goto IL_0c71;
																																						case 407:
																																							goto IL_0c84;
																																						case 251:
																																						case 412:
																																							goto IL_0c97;
																																						case 79:
																																						case 429:
																																							goto IL_0caf;
																																						case 351:
																																							goto IL_0ce8;
																																						case 379:
																																							goto IL_0cfc;
																																						case 125:
																																						case 434:
																																							goto IL_0d0f;
																																						case 403:
																																							goto IL_0d27;
																																						case 402:
																																							goto IL_0d35;
																																						case 367:
																																						case 440:
																																							goto IL_0d48;
																																						case 439:
																																							goto IL_0d5c;
																																						case 192:
																																							goto IL_0d9b;
																																						case 182:
																																						case 461:
																																							goto IL_0dae;
																																						case 108:
																																							goto IL_0dc2;
																																						case 451:
																																							goto IL_0e01;
																																						case 473:
																																							goto IL_0e14;
																																						case 213:
																																							goto IL_0e22;
																																						case 427:
																																							goto IL_0e30;
																																						case 472:
																																						case 481:
																																							goto IL_0e43;
																																						case 245:
																																							goto IL_0e83;
																																						case 74:
																																							goto IL_0e97;
																																						case 94:
																																						case 482:
																																							goto IL_0eaa;
																																						case 73:
																																							goto IL_0ebe;
																																						case 485:
																																							goto IL_0f01;
																																						case 46:
																																							goto IL_0f0c;
																																						case 144:
																																						case 314:
																																							goto IL_0f1a;
																																						case 264:
																																							goto IL_0f60;
																																						case 302:
																																							goto IL_0f6e;
																																						case 419:
																																						case 478:
																																							goto IL_0f85;
																																						case 284:
																																							goto IL_0fd7;
																																						case 492:
																																							goto IL_0fea;
																																						case 310:
																																						case 506:
																																							goto IL_0ffd;
																																						case 515:
																																							goto IL_1010;
																																						case 390:
																																							goto IL_1027;
																																						case 127:
																																						case 424:
																																							goto IL_1035;
																																						case 336:
																																							goto IL_106d;
																																						case 188:
																																							goto IL_1081;
																																						case 518:
																																							goto IL_1094;
																																						case 58:
																																							goto IL_10a2;
																																						case 522:
																																							goto IL_10b5;
																																						case 11:
																																							goto IL_10c3;
																																						case 16:
																																						case 168:
																																							goto IL_10d1;
																																						case 110:
																																							goto IL_1111;
																																						case 8:
																																							goto IL_1125;
																																						case 528:
																																							goto IL_1141;
																																						case 530:
																																							goto IL_1154;
																																						case 4:
																																						case 57:
																																							goto IL_1162;
																																						case 270:
																																							goto IL_11a2;
																																						case 249:
																																							goto IL_11bf;
																																						case 532:
																																							goto IL_11d2;
																																						case 231:
																																							goto IL_11e6;
																																						case 536:
																																							goto IL_11f9;
																																						case 102:
																																						case 344:
																																							goto IL_1204;
																																						case 380:
																																							goto IL_1212;
																																						case 433:
																																							goto IL_1235;
																																						case 55:
																																							goto IL_123f;
																																						case 56:
																																							goto IL_124d;
																																						case 399:
																																							goto IL_1260;
																																						case 163:
																																							goto IL_126b;
																																						case 101:
																																							goto IL_1287;
																																						case 383:
																																						case 389:
																																							goto IL_1292;
																																						case 346:
																																							goto IL_12d2;
																																						case 106:
																																							goto IL_12e6;
																																						case 315:
																																							goto IL_12f9;
																																						case 496:
																																							goto IL_1310;
																																						case 233:
																																						case 371:
																																							goto IL_131e;
																																						case 197:
																																							goto IL_1337;
																																						case 531:
																																							goto IL_1345;
																																						case 468:
																																							goto IL_1353;
																																						case 538:
																																							goto IL_1366;
																																						case 542:
																																							goto IL_1379;
																																						case 257:
																																						case 517:
																																							goto IL_1387;
																																						case 331:
																																							goto IL_13b0;
																																						case 548:
																																							goto IL_13be;
																																						case 365:
																																							goto IL_13df;
																																						case 171:
																																							goto IL_13ed;
																																						case 189:
																																							goto IL_1400;
																																						case 502:
																																							goto IL_140e;
																																						case 176:
																																						case 343:
																																							goto IL_141c;
																																						case 386:
																																							goto IL_1439;
																																						case 267:
																																							goto IL_1471;
																																						case 539:
																																							goto IL_1484;
																																						case 373:
																																							goto IL_148f;
																																						case 44:
																																						case 122:
																																							goto IL_149d;
																																						case 469:
																																							goto IL_14da;
																																						case 525:
																																							goto IL_14e8;
																																						case 33:
																																							goto IL_14fb;
																																						case 64:
																																							goto end_IL_08f3;
																																						case 97:
																																						case 124:
																																							goto IL_1517;
																																						case 265:
																																							goto IL_1530;
																																						case 354:
																																							goto IL_153e;
																																						case 48:
																																							goto IL_154c;
																																						case 413:
																																							goto IL_155f;
																																						case 283:
																																							goto IL_156d;
																																						case 228:
																																						case 487:
																																							goto IL_1578;
																																						case 204:
																																							goto IL_159c;
																																						case 332:
																																							goto IL_15aa;
																																						case 333:
																																							goto IL_15b8;
																																						case 211:
																																							goto IL_15cb;
																																						case 165:
																																							goto IL_15d9;
																																						case 513:
																																							goto IL_15e7;
																																						case 290:
																																							goto IL_15f5;
																																						case 294:
																																						case 489:
																																							goto IL_1603;
																																						case 462:
																																							goto IL_1643;
																																						case 357:
																																							goto IL_1657;
																																						case 185:
																																						case 556:
																																							goto IL_166a;
																																						case 96:
																																							goto IL_167e;
																																						case 259:
																																							goto IL_16bd;
																																						case 104:
																																							goto IL_16d0;
																																						case 222:
																																							goto IL_16de;
																																						case 217:
																																						case 398:
																																							goto IL_16ec;
																																						case 316:
																																							goto IL_1708;
																																						case 42:
																																							goto IL_1716;
																																						case 173:
																																						case 198:
																																							goto IL_1721;
																																						case 376:
																																							goto IL_1735;
																																						case 524:
																																							goto IL_177d;
																																						case 426:
																																							goto IL_1790;
																																						case 274:
																																							goto IL_17a7;
																																						case 313:
																																						case 558:
																																							goto IL_17b5;
																																						case 394:
																																							goto IL_1823;
																																						case 411:
																																							goto IL_1836;
																																						case 117:
																																							goto IL_1841;
																																						case 36:
																																						case 95:
																																							goto IL_184f;
																																						case 450:
																																							goto IL_188f;
																																						case 397:
																																							goto IL_18a3;
																																						case 103:
																																							goto IL_18b6;
																																						case 340:
																																							goto IL_18c4;
																																						case 76:
																																						case 400:
																																							goto IL_18d2;
																																						case 465:
																																							goto IL_190a;
																																						case 77:
																																							goto IL_191e;
																																						case 25:
																																						case 30:
																																							goto IL_1931;
																																						case 422:
																																							goto IL_194e;
																																						case 545:
																																							goto IL_198d;
																																						case 26:
																																							goto IL_19a0;
																																						case 408:
																																							goto IL_19ae;
																																						case 181:
																																						case 325:
																																							goto IL_19b9;
																																						case 21:
																																							goto IL_19f6;
																																						case 421:
																																							goto IL_1a04;
																																						case 345:
																																							goto IL_1a17;
																																						case 418:
																																							goto IL_1a25;
																																						case 366:
																																						case 387:
																																							goto IL_1a30;
																																						case 370:
																																							goto IL_1a69;
																																						case 6:
																																							goto IL_1a7d;
																																						case 319:
																																							goto IL_1a90;
																																						case 191:
																																							goto IL_1a9e;
																																						case 391:
																																						case 495:
																																							goto IL_1aa9;
																																						case 23:
																																							goto IL_1ae7;
																																						case 226:
																																							goto IL_1afa;
																																						case 555:
																																							goto IL_1b08;
																																						case 195:
																																							goto IL_1b16;
																																						case 142:
																																							goto IL_1b24;
																																						case 210:
																																						case 464:
																																							goto IL_1b32;
																																						case 89:
																																							goto IL_1b46;
																																						case 31:
																																							goto IL_1b85;
																																						case 41:
																																						case 286:
																																							goto IL_1b98;
																																						case 549:
																																							goto IL_1bb5;
																																						case 491:
																																							goto IL_1bf4;
																																						case 454:
																																							goto IL_1c07;
																																						case 364:
																																							goto IL_1c15;
																																						case 118:
																																						case 232:
																																							goto IL_1c23;
																																						case 453:
																																							goto IL_1c37;
																																						case 483:
																																							goto IL_1c70;
																																						case 68:
																																							goto IL_1c8c;
																																						case 312:
																																							goto IL_1c9a;
																																						case 62:
																																						case 305:
																																							goto IL_1ca5;
																																						case 494:
																																							goto IL_1cb9;
																																						case 150:
																																							goto IL_1cf8;
																																						case 497:
																																							goto IL_1d0b;
																																						case 512:
																																							goto IL_1d19;
																																						case 148:
																																						case 523:
																																							goto IL_1d27;
																																						case 243:
																																							goto IL_1d50;
																																						case 298:
																																							goto IL_1d67;
																																						case 221:
																																							goto IL_1d7a;
																																						case 281:
																																							goto IL_1d88;
																																						case 248:
																																						case 405:
																																							goto IL_1d96;
																																						case 519:
																																							goto IL_1db4;
																																						case 428:
																																							goto IL_1dc2;
																																						case 98:
																																							goto IL_1dd0;
																																						case 550:
																																							goto IL_1de3;
																																						case 459:
																																							goto IL_1df1;
																																						case 223:
																																						case 295:
																																							goto IL_1dfc;
																																						case 87:
																																							goto IL_1e39;
																																						case 401:
																																							goto IL_1e47;
																																						case 187:
																																							goto IL_1e5a;
																																						case 247:
																																							goto IL_1e68;
																																						case 363:
																																						case 369:
																																							goto IL_1e73;
																																						case 457:
																																							goto IL_1eb0;
																																						case 255:
																																							goto IL_1ebe;
																																						case 338:
																																							goto IL_1ed1;
																																						case 455:
																																							goto IL_1edf;
																																						case 253:
																																						case 324:
																																							goto IL_1eed;
																																						case 516:
																																							goto IL_1f15;
																																						case 83:
																																							goto IL_1f2e;
																																						case 553:
																																							goto IL_1f3c;
																																						case 293:
																																						case 409:
																																							goto IL_1f4a;
																																						case 446:
																																							goto IL_1f5e;
																																						case 190:
																																							goto IL_1f9c;
																																						case 141:
																																							goto IL_1faf;
																																						case 276:
																																							goto IL_1fbd;
																																						case 285:
																																							goto IL_1fc8;
																																						case 307:
																																						case 352:
																																							goto IL_1fd6;
																																						case 500:
																																							goto IL_200f;
																																						case 443:
																																							goto IL_2022;
																																						case 328:
																																							goto IL_2030;
																																						case 396:
																																						case 463:
																																							goto IL_203e;
																																						case 129:
																																							goto IL_2066;
																																						case 194:
																																							goto IL_2088;
																																						case 258:
																																						case 423:
																																							goto IL_2093;
																																						case 326:
																																							goto IL_209d;
																																						case 19:
																																							goto IL_20ab;
																																						case 322:
																																							goto IL_20be;
																																						case 479:
																																							goto IL_20cc;
																																						case 368:
																																						case 460:
																																							goto IL_20e3;
																																						case 121:
																																							goto IL_20f7;
																																						case 252:
																																							goto IL_2136;
																																						case 156:
																																							goto IL_2149;
																																						case 341:
																																							goto IL_2157;
																																						case 392:
																																							goto IL_2165;
																																						case 272:
																																							goto IL_2173;
																																						case 81:
																																						case 227:
																																							goto IL_217e;
																																						case 381:
																																							goto IL_21be;
																																						case 537:
																																							goto IL_21d2;
																																						case 526:
																																							goto IL_21e5;
																																						case 107:
																																							goto IL_21f3;
																																						case 63:
																																						case 186:
																																							goto IL_21fe;
																																						case 406:
																																							goto IL_221b;
																																						case 196:
																																							goto IL_225a;
																																						case 554:
																																							goto IL_226d;
																																						case 420:
																																							goto IL_227b;
																																						case 224:
																																						case 238:
																																							goto IL_2289;
																																						case 179:
																																							goto IL_229d;
																																						case 51:
																																							goto IL_22e5;
																																						case 503:
																																							goto IL_22f8;
																																						case 359:
																																							goto IL_2306;
																																						case 321:
																																						case 431:
																																							goto IL_2314;
																																						case 153:
																																							goto IL_2328;
																																						case 499:
																																							goto IL_2375;
																																						case 91:
																																							goto IL_2383;
																																						case 71:
																																							goto IL_2396;
																																						case 378:
																																							goto IL_23a4;
																																						case 445:
																																							goto IL_23af;
																																						case 53:
																																						case 82:
																																							goto IL_23c6;
																																						case 93:
																																							goto IL_23da;
																																						case 282:
																																							goto IL_2419;
																																						case 237:
																																							goto IL_242c;
																																						case 67:
																																							goto IL_243a;
																																						case 140:
																																						case 382:
																																							goto IL_2448;
																																						case 115:
																																							goto IL_246f;
																																						case 113:
																																							goto IL_247d;
																																						case 269:
																																							goto IL_2494;
																																						case 535:
																																							goto IL_24a7;
																																						case 149:
																																							goto IL_24b5;
																																						case 178:
																																							goto IL_24c3;
																																						case 78:
																																						case 134:
																																							goto IL_24d1;
																																						case 12:
																																							goto IL_24e5;
																																						case 28:
																																							goto IL_2524;
																																						case 220:
																																						case 559:
																																							goto IL_2537;
																																						case 552:
																																							goto IL_254b;
																																						case 170:
																																							goto IL_258a;
																																						case 32:
																																						case 126:
																																							goto IL_25a6;
																																						case 458:
																																							goto IL_25ba;
																																						case 546:
																																							goto IL_25f9;
																																						case 415:
																																							goto IL_260c;
																																						case 505:
																																							goto IL_261a;
																																						case 105:
																																						case 425:
																																							goto IL_2625;
																																						case 22:
																																							goto IL_263e;
																																						case 18:
																																							goto IL_2651;
																																						case 342:
																																							goto IL_265f;
																																						case 29:
																																							goto IL_266d;
																																						case 488:
																																							goto IL_267b;
																																						case 235:
																																						case 306:
																																							goto IL_2692;
																																						case 199:
																																							goto IL_26d2;
																																						case 147:
																																							goto IL_26e6;
																																						case 85:
																																						case 317:
																																							goto IL_270b;
																																						case 520:
																																							goto IL_271f;
																																						case 436:
																																							goto IL_2757;
																																						case 205:
																																							goto IL_276a;
																																						case 299:
																																							goto IL_2781;
																																						case 164:
																																							goto IL_2794;
																																						case 116:
																																							goto IL_27a2;
																																						case 358:
																																							goto IL_27ad;
																																						case 158:
																																							goto IL_27bb;
																																						case 131:
																																						case 339:
																																							goto IL_27c9;
																																						case 385:
																																							goto IL_27eb;
																																						case 160:
																																						case 543:
																																							goto IL_27fe;
																																						case 239:
																																							goto IL_283c;
																																						case 2:
																																							goto IL_2850;
																																						case 54:
																																							goto IL_2860;
																																						case 347:
																																							goto IL_286b;
																																						case 329:
																																						case 444:
																																							goto IL_287f;
																																						case 88:
																																							goto IL_2899;
																																						case 60:
																																							goto IL_28a9;
																																						case 132:
																																							goto IL_28b4;
																																						case 7:
																																						case 9:
																																						case 15:
																																						case 27:
																																						case 35:
																																						case 40:
																																						case 47:
																																						case 49:
																																						case 59:
																																						case 65:
																																						case 99:
																																						case 114:
																																						case 123:
																																						case 137:
																																						case 138:
																																						case 146:
																																						case 159:
																																						case 177:
																																						case 180:
																																						case 200:
																																						case 202:
																																						case 206:
																																						case 212:
																																						case 215:
																																						case 218:
																																						case 219:
																																						case 261:
																																						case 263:
																																						case 268:
																																						case 273:
																																						case 275:
																																						case 278:
																																						case 287:
																																						case 291:
																																						case 296:
																																						case 300:
																																						case 301:
																																						case 304:
																																						case 308:
																																						case 309:
																																						case 311:
																																						case 318:
																																						case 327:
																																						case 330:
																																						case 337:
																																						case 349:
																																						case 356:
																																						case 361:
																																						case 362:
																																						case 375:
																																						case 404:
																																						case 410:
																																						case 416:
																																						case 432:
																																						case 441:
																																						case 452:
																																						case 467:
																																						case 471:
																																						case 475:
																																						case 477:
																																						case 480:
																																						case 486:
																																						case 490:
																																						case 498:
																																						case 509:
																																						case 510:
																																						case 521:
																																						case 533:
																																						case 540:
																																						case 547:
																																						case 560:
																																						case 562:
																																							goto end_IL_09b4;
																																						case 0:
																																						case 1:
																																						case 13:
																																						case 17:
																																						case 20:
																																						case 24:
																																						case 61:
																																						case 66:
																																						case 72:
																																						case 84:
																																						case 90:
																																						case 92:
																																						case 111:
																																						case 112:
																																						case 128:
																																						case 139:
																																						case 143:
																																						case 145:
																																						case 166:
																																						case 167:
																																						case 175:
																																						case 184:
																																						case 201:
																																						case 203:
																																						case 209:
																																						case 229:
																																						case 230:
																																						case 234:
																																						case 240:
																																						case 256:
																																						case 262:
																																						case 279:
																																						case 289:
																																						case 292:
																																						case 297:
																																						case 334:
																																						case 348:
																																						case 350:
																																						case 353:
																																						case 355:
																																						case 360:
																																						case 372:
																																						case 374:
																																						case 377:
																																						case 388:
																																						case 393:
																																						case 395:
																																						case 414:
																																						case 417:
																																						case 430:
																																						case 435:
																																						case 437:
																																						case 438:
																																						case 442:
																																						case 447:
																																						case 448:
																																						case 456:
																																						case 466:
																																						case 474:
																																						case 476:
																																						case 493:
																																						case 501:
																																						case 504:
																																						case 507:
																																						case 508:
																																						case 511:
																																						case 527:
																																						case 529:
																																						case 534:
																																						case 541:
																																						case 544:
																																						case 551:
																																						case 557:
																																						case 561:
																																							goto end_IL_09e4;
																																						case 484:
																																							goto end_IL_28d2;
																																						case 207:
																																							goto end_IL_28e5;
																																						case 155:
																																							goto end_IL_28ef;
																																						case 151:
																																							goto end_IL_28fa;
																																						case 119:
																																							goto end_IL_290a;
																																						case 154:
																																							goto end_IL_2923;
																																						case 216:
																																						case 449:
																																							goto end_IL_2933;
																																						case 225:
																																							goto end_IL_2943;
																																						case 69:
																																							goto end_IL_2953;
																																						case 70:
																																							goto end_IL_2963;
																																						case 37:
																																							goto end_IL_2973;
																																						case 38:
																																							goto end_IL_2983;
																																						case 50:
																																						case 335:
																																							return;
																																						}
																																						continue;
																																					}
																																					array[num6] = 4;
																																					goto IL_13df;
																																					IL_13df:
																																					num6++;
																																					goto IL_13ed;
																																					IL_13ed:
																																					ptr2 += 8;
																																					goto end_IL_09e4;
																																					continue;
																																					end_IL_08f3:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_1400;
																																		IL_1471:
																																		ptr2 += 8;
																																		goto end_IL_09e4;
																																		IL_1400:
																																		if (22 < b)
																																		{
																																			goto end_IL_09b4;
																																		}
																																		goto IL_140e;
																																		IL_140e:
																																		if (22 > b)
																																		{
																																			goto end_IL_09b4;
																																		}
																																		goto IL_141c;
																																		IL_141c:
																																		array[num6 - 1] = 5;
																																		num = 386;
																																		goto IL_1439;
																																		IL_1439:
																																		array2[num6 - 1] = ((delegate*<GameObject, Transform>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																																		goto IL_1471;
																																	}
																																	goto IL_1509;
																																	IL_154c:
																																	ptr2 += 16;
																																	goto end_IL_09e4;
																																	IL_1484:
																																	if (24 >= b)
																																	{
																																		goto IL_148f;
																																	}
																																	goto IL_14fb;
																																	IL_148f:
																																	if (24 > b)
																																	{
																																		goto end_IL_09b4;
																																	}
																																	goto IL_149d;
																																	IL_149d:
																																	((delegate*<Transform, Vector3, void>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																																	goto IL_14da;
																																	IL_14da:
																																	num6 -= 2;
																																	goto IL_14e8;
																																	IL_14e8:
																																	ptr2 += 8;
																																	goto end_IL_09e4;
																																	IL_14fb:
																																	if (25 < b)
																																	{
																																		goto end_IL_09b4;
																																	}
																																	goto IL_1509;
																																	IL_1509:
																																	if (25 > b)
																																	{
																																		goto end_IL_09b4;
																																	}
																																	goto IL_1517;
																																	IL_1517:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																																	goto IL_1530;
																																	IL_1530:
																																	array[num6] = 3;
																																	goto IL_153e;
																																	IL_153e:
																																	num6++;
																																	goto IL_154c;
																																	continue;
																																	end_IL_0944:
																																	break;
																																}
																																continue;
																															}
																															goto IL_09ef;
																															IL_0ce8:
																															array[num6 - 2] = 5;
																															goto IL_0cfc;
																															IL_09ef:
																															if (21 > b)
																															{
																																goto IL_09fd;
																															}
																															goto IL_0caf;
																															IL_09fd:
																															if (19 < b)
																															{
																																goto IL_0a0b;
																															}
																															goto IL_0c71;
																															IL_0a0b:
																															if (20 < b)
																															{
																																goto end_IL_09b4;
																															}
																															goto IL_0a19;
																															IL_0a19:
																															if (20 > b)
																															{
																																goto end_IL_09b4;
																															}
																															goto IL_0eaa;
																															IL_0eaa:
																															array[num6 - 1] = 0;
																															goto IL_0ebe;
																															IL_0ebe:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<EventData, int>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((EventData)array2[num6 - 1]);
																															goto IL_0fea;
																															IL_0fea:
																															ptr2 += 8;
																															goto end_IL_09e4;
																															IL_0c71:
																															if (19 <= b)
																															{
																																goto IL_0d0f;
																															}
																															goto IL_1010;
																															IL_0d0f:
																															array2[num6] = array5[*(int*)(ptr2 + num3)];
																															goto IL_0d27;
																															IL_0d27:
																															array[num6] = 5;
																															goto IL_0d35;
																															IL_0d35:
																															num6++;
																															goto IL_1141;
																															IL_1141:
																															ptr2 += 8;
																															goto end_IL_09e4;
																															IL_1010:
																															if (18 < b)
																															{
																																goto end_IL_09b4;
																															}
																															num = 390;
																															goto IL_1027;
																															IL_0cfc:
																															num6--;
																															goto end_IL_09e4;
																															IL_1027:
																															if (18 > b)
																															{
																																goto end_IL_09b4;
																															}
																															goto IL_1035;
																															IL_1035:
																															array2[num6 - 1] = ((delegate*<Class167, GameObject[]>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Class167)array2[num6 - 1]);
																															goto IL_106d;
																															IL_106d:
																															array[num6 - 1] = 5;
																															goto IL_1081;
																															IL_1081:
																															ptr2 += 8;
																															goto end_IL_09e4;
																															IL_0caf:
																															array2[num6 - 2] = ((GameObject[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																															goto IL_0ce8;
																															continue;
																															end_IL_0954:
																															break;
																														}
																														continue;
																													}
																													goto IL_0d48;
																													IL_0d9b:
																													ptr2 += 8;
																													goto end_IL_09e4;
																													IL_0d48:
																													array[num6 - 1] = 3;
																													goto IL_0d5c;
																													IL_0d5c:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_0d9b;
																													continue;
																													end_IL_0964:
																													break;
																												}
																												continue;
																											}
																											goto IL_155f;
																											IL_190a:
																											array[num6 - 1] = 5;
																											goto IL_191e;
																											IL_155f:
																											if (30 >= b)
																											{
																												goto IL_156d;
																											}
																											goto IL_1708;
																											IL_156d:
																											if (30 <= b)
																											{
																												goto IL_1578;
																											}
																											goto IL_15cb;
																											IL_1578:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<byte>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])();
																											goto IL_159c;
																											IL_159c:
																											array[num6] = 0;
																											goto IL_15aa;
																											IL_15aa:
																											num6++;
																											goto IL_15b8;
																											IL_15b8:
																											ptr2 += 8;
																											goto end_IL_09e4;
																											IL_15cb:
																											if (28 >= b)
																											{
																												goto IL_15d9;
																											}
																											goto IL_16d0;
																											IL_15d9:
																											if (28 > b)
																											{
																												goto IL_15e7;
																											}
																											goto IL_166a;
																											IL_15e7:
																											if (27 < b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_15f5;
																											IL_15f5:
																											if (27 > b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_1603;
																											IL_1603:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_1643;
																											IL_1643:
																											array[num6 - 2] = 3;
																											goto IL_1657;
																											IL_1657:
																											num6--;
																											goto end_IL_09e4;
																											IL_166a:
																											array[num6 - 1] = 0;
																											goto IL_167e;
																											IL_167e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_16bd;
																											IL_16bd:
																											ptr2 += 8;
																											goto end_IL_09e4;
																											IL_16d0:
																											if (29 < b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_16de;
																											IL_16de:
																											if (29 > b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_16ec;
																											IL_16ec:
																											byte* num7 = ptr2;
																											num5 = 1;
																											ptr2 = num7 + -200;
																											goto end_IL_09e4;
																											IL_1708:
																											if (32 >= b)
																											{
																												goto IL_1716;
																											}
																											goto IL_1836;
																											IL_1716:
																											if (32 <= b)
																											{
																												goto IL_1721;
																											}
																											goto IL_1790;
																											IL_1721:
																											array[num6 - 1] = 3;
																											goto IL_1735;
																											IL_1735:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											num = 524;
																											goto IL_177d;
																											IL_177d:
																											ptr2 += 8;
																											goto end_IL_09e4;
																											IL_1790:
																											if (31 < b)
																											{
																												goto end_IL_09b4;
																											}
																											num = 274;
																											goto IL_17a7;
																											IL_191e:
																											ptr2 += 8;
																											goto end_IL_09e4;
																											IL_17a7:
																											if (31 > b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_17b5;
																											IL_17b5:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_1823;
																											IL_1823:
																											num6 -= 2;
																											goto end_IL_09e4;
																											IL_1836:
																											if (33 >= b)
																											{
																												goto IL_1841;
																											}
																											goto IL_18b6;
																											IL_1841:
																											if (33 > b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_184f;
																											IL_184f:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_188f;
																											IL_188f:
																											array[num6 - 2] = 3;
																											goto IL_18a3;
																											IL_18a3:
																											num6--;
																											goto end_IL_09e4;
																											IL_18b6:
																											if (34 < b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_18c4;
																											IL_18c4:
																											if (34 > b)
																											{
																												goto end_IL_09b4;
																											}
																											goto IL_18d2;
																											IL_18d2:
																											array2[num6 - 1] = ((delegate*<Class167, GameObject[]>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Class167)array2[num6 - 1]);
																											goto IL_190a;
																											continue;
																											end_IL_0974:
																											break;
																										}
																										continue;
																									}
																									goto IL_0a2c;
																									IL_12e6:
																									num6--;
																									goto end_IL_09e4;
																									IL_0a2c:
																									if (17 <= b)
																									{
																										goto IL_0a37;
																									}
																									goto IL_0a54;
																									IL_0a37:
																									array2[num6] = array5[*(int*)(ptr2 + num3)];
																									goto IL_1094;
																									IL_1094:
																									array[num6] = 5;
																									goto IL_10a2;
																									IL_10a2:
																									num6++;
																									goto IL_1366;
																									IL_1366:
																									ptr2 += 8;
																									goto end_IL_09e4;
																									IL_0a54:
																									if (8 < b)
																									{
																										goto IL_0a62;
																									}
																									num = 136;
																									goto IL_0ba8;
																									IL_0a62:
																									if (12 >= b)
																									{
																										goto IL_0a70;
																									}
																									goto IL_0b49;
																									IL_0a70:
																									if (12 <= b)
																									{
																										goto end_IL_09e4;
																									}
																									goto IL_0a7e;
																									IL_0a7e:
																									if (10 >= b)
																									{
																										goto IL_0a8c;
																									}
																									goto IL_0b28;
																									IL_0a8c:
																									if (10 > b)
																									{
																										goto IL_0a97;
																									}
																									goto IL_0aaa;
																									IL_0a97:
																									if (9 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_1154;
																									IL_1154:
																									if (9 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_1162;
																									IL_1162:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_11a2;
																									IL_11a2:
																									array[num6 - 2] = 0;
																									num = 249;
																									goto IL_11bf;
																									IL_11bf:
																									num6--;
																									goto end_IL_09e4;
																									IL_0aaa:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0b0c;
																									IL_0b0c:
																									num6 -= 2;
																									num = 262;
																									goto end_IL_09e4;
																									IL_0b28:
																									if (11 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0b36;
																									IL_0b36:
																									if (11 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0dae;
																									IL_0dae:
																									array[num6 - 1] = 0;
																									goto IL_0dc2;
																									IL_0dc2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_0e01;
																									IL_0e01:
																									ptr2 += 8;
																									goto end_IL_09e4;
																									IL_0b49:
																									if (14 >= b)
																									{
																										goto IL_0b57;
																									}
																									goto IL_0f01;
																									IL_0b57:
																									if (14 > b)
																									{
																										goto IL_0b65;
																									}
																									goto IL_0c97;
																									IL_0b65:
																									if (13 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0b73;
																									IL_0b73:
																									if (13 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0b81;
																									IL_0b81:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0e14;
																									IL_0e14:
																									array[num6] = 1;
																									goto IL_0e22;
																									IL_0e22:
																									num6++;
																									goto IL_0e30;
																									IL_0e30:
																									ptr2 += 16;
																									goto end_IL_09e4;
																									IL_0c97:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_09e4;
																									IL_0f01:
																									if (15 >= b)
																									{
																										goto IL_0f0c;
																									}
																									goto IL_0f60;
																									IL_0f0c:
																									if (15 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0f1a;
																									IL_0f1a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_11d2;
																									IL_11d2:
																									array[num6 - 2] = 0;
																									goto IL_11e6;
																									IL_11e6:
																									num6--;
																									goto end_IL_09e4;
																									IL_0f60:
																									if (16 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_0f6e;
																									IL_0f6e:
																									if (16 > b)
																									{
																										goto end_IL_09b4;
																									}
																									num = 419;
																									goto IL_0f85;
																									IL_1353:
																									ptr2 += 8;
																									goto end_IL_09e4;
																									IL_0f85:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0fd7;
																									IL_0fd7:
																									num6--;
																									goto end_IL_09e4;
																									IL_12f9:
																									if (1 < b)
																									{
																										goto end_IL_09b4;
																									}
																									num = 496;
																									goto IL_1310;
																									IL_0ba8:
																									if (8 > b)
																									{
																										goto IL_0bc1;
																									}
																									num = 506;
																									goto IL_0ffd;
																									IL_1310:
																									if (1 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_131e;
																									IL_0ffd:
																									num6--;
																									goto end_IL_09e4;
																									IL_0bc1:
																									if (4 < b)
																									{
																										goto IL_0bcf;
																									}
																									goto IL_11f9;
																									IL_0bcf:
																									if (6 >= b)
																									{
																										goto IL_0bda;
																									}
																									goto IL_0c3e;
																									IL_0bda:
																									if (6 <= b)
																									{
																										goto IL_0be8;
																									}
																									goto IL_10b5;
																									IL_0be8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0c28;
																									IL_0c28:
																									array[num6 - 2] = 0;
																									goto IL_0c84;
																									IL_0c84:
																									num6--;
																									goto end_IL_09e4;
																									IL_10b5:
																									if (5 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_10c3;
																									IL_10c3:
																									if (5 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_10d1;
																									IL_10d1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_1111;
																									IL_1111:
																									array[num6 - 2] = 0;
																									goto IL_1125;
																									IL_1125:
																									num6--;
																									num = 466;
																									goto end_IL_09e4;
																									IL_0c3e:
																									if (7 < b)
																									{
																										goto end_IL_09b4;
																									}
																									num = 260;
																									goto IL_0c55;
																									IL_131e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_1337;
																									IL_0c55:
																									if (7 > b)
																									{
																										goto end_IL_09b4;
																									}
																									num = 481;
																									goto IL_0e43;
																									IL_1337:
																									array[num6] = 0;
																									goto IL_1345;
																									IL_0e43:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0e83;
																									IL_0e83:
																									array[num6 - 2] = 0;
																									goto IL_0e97;
																									IL_0e97:
																									num6--;
																									goto end_IL_09e4;
																									IL_11f9:
																									if (4 <= b)
																									{
																										goto IL_1204;
																									}
																									goto IL_1260;
																									IL_1204:
																									array[num6] = 0;
																									goto IL_1212;
																									IL_1212:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_1235;
																									IL_1235:
																									array2[num6] = null;
																									goto IL_123f;
																									IL_123f:
																									num6++;
																									goto IL_124d;
																									IL_124d:
																									ptr2 += 8;
																									goto end_IL_09e4;
																									IL_1260:
																									if (2 < b)
																									{
																										goto IL_126b;
																									}
																									num = 101;
																									goto IL_1287;
																									IL_126b:
																									if (3 < b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_1379;
																									IL_1379:
																									if (3 > b)
																									{
																										goto end_IL_09b4;
																									}
																									goto IL_1387;
																									IL_1387:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_13b0;
																									IL_13b0:
																									ptr2 += 8;
																									goto IL_13be;
																									IL_13be:
																									num6--;
																									goto end_IL_09e4;
																									IL_1345:
																									num6++;
																									goto IL_1353;
																									IL_1287:
																									if (2 <= b)
																									{
																										goto IL_1292;
																									}
																									goto IL_12f9;
																									IL_1292:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_12d2;
																									IL_12d2:
																									array[num6 - 2] = 0;
																									goto IL_12e6;
																									continue;
																									end_IL_0984:
																									break;
																								}
																								continue;
																							}
																							goto IL_1931;
																							IL_198d:
																							ptr2 += 8;
																							goto end_IL_09e4;
																							IL_1931:
																							array[num6 - 1] = 3;
																							num = 422;
																							goto IL_194e;
																							IL_194e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_198d;
																							continue;
																							end_IL_0994:
																							break;
																						}
																						continue;
																					}
																					goto IL_19a0;
																					IL_283c:
																					array[num6 - 1] = 0;
																					goto IL_2850;
																					IL_19a0:
																					if (52 >= b)
																					{
																						goto IL_19ae;
																					}
																					goto IL_2149;
																					IL_19ae:
																					if (52 <= b)
																					{
																						goto IL_19b9;
																					}
																					goto IL_1a17;
																					IL_19b9:
																					((delegate*<Transform, Quaternion, void>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Quaternion)array2[num6 - 1]);
																					goto IL_19f6;
																					IL_19f6:
																					num6 -= 2;
																					goto IL_1a04;
																					IL_1a04:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1a17:
																					if (43 >= b)
																					{
																						goto IL_1a25;
																					}
																					goto IL_1de3;
																					IL_1a25:
																					if (43 <= b)
																					{
																						goto IL_1a30;
																					}
																					goto IL_1a90;
																					IL_1a30:
																					array2[num6 - 2] = ((object[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_1a69;
																					IL_1a69:
																					array[num6 - 2] = 5;
																					goto IL_1a7d;
																					IL_1a7d:
																					num6--;
																					goto end_IL_09e4;
																					IL_1a90:
																					if (39 >= b)
																					{
																						goto IL_1a9e;
																					}
																					goto IL_1c8c;
																					IL_1a9e:
																					if (39 <= b)
																					{
																						goto IL_1aa9;
																					}
																					goto IL_1afa;
																					IL_1aa9:
																					((GameObject[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = (GameObject)array2[num6 - 1];
																					goto IL_1ae7;
																					IL_1ae7:
																					num6 -= 3;
																					goto end_IL_09e4;
																					IL_1afa:
																					if (37 >= b)
																					{
																						goto IL_1b08;
																					}
																					goto IL_1c07;
																					IL_1b08:
																					if (37 > b)
																					{
																						goto IL_1b16;
																					}
																					goto IL_1b98;
																					IL_1b16:
																					if (36 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1b24;
																					IL_1b24:
																					if (36 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1b32;
																					IL_1b32:
																					array[num6 - 1] = 3;
																					goto IL_1b46;
																					IL_1b46:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1b85;
																					IL_1b85:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1b98:
																					array[num6 - 1] = 0;
																					num = 549;
																					goto IL_1bb5;
																					IL_1bb5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1bf4;
																					IL_1bf4:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1c07:
																					if (38 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1c15;
																					IL_1c15:
																					if (38 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1c23;
																					IL_1c23:
																					array[num6 - 1] = 5;
																					goto IL_1c37;
																					IL_1c37:
																					array2[num6 - 1] = ((delegate*<PrimitiveType, GameObject>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(PrimitiveType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1c70;
																					IL_1c70:
																					ptr2 += 8;
																					num = 437;
																					goto end_IL_09e4;
																					IL_1c8c:
																					if (41 >= b)
																					{
																						goto IL_1c9a;
																					}
																					goto IL_1d7a;
																					IL_1c9a:
																					if (41 <= b)
																					{
																						goto IL_1ca5;
																					}
																					goto IL_1d0b;
																					IL_1ca5:
																					array[num6 - 1] = 3;
																					goto IL_1cb9;
																					IL_1cb9:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1cf8;
																					IL_1cf8:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1d0b:
																					if (40 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1d19;
																					IL_1d19:
																					if (40 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1d27;
																					IL_1d27:
																					((delegate*<UnityEngine.Object, void>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_1d50;
																					IL_1d50:
																					num6--;
																					num = 298;
																					goto IL_1d67;
																					IL_1d67:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1d7a:
																					if (42 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1d88;
																					IL_1d88:
																					if (42 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1d96;
																					IL_1d96:
																					array2[num6] = ((delegate*<object[]>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])();
																					goto IL_1db4;
																					IL_1db4:
																					array[num6] = 5;
																					goto IL_1dc2;
																					IL_1dc2:
																					num6++;
																					goto IL_1dd0;
																					IL_1dd0:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1de3:
																					if (47 >= b)
																					{
																						goto IL_1df1;
																					}
																					goto IL_1faf;
																					IL_1df1:
																					if (47 <= b)
																					{
																						goto IL_1dfc;
																					}
																					goto IL_1e5a;
																					IL_1dfc:
																					((delegate*<Class167, GameObject, void>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Class167)array2[num6 - 2], (GameObject)array2[num6 - 1]);
																					goto IL_1e39;
																					IL_1e39:
																					num6 -= 2;
																					goto IL_1e47;
																					IL_1e47:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1e5a:
																					if (45 >= b)
																					{
																						goto IL_1e68;
																					}
																					goto IL_1f2e;
																					IL_1e68:
																					if (45 <= b)
																					{
																						goto IL_1e73;
																					}
																					goto IL_1ed1;
																					IL_1e73:
																					((delegate*<Transform, Vector3, void>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_1eb0;
																					IL_1eb0:
																					num6 -= 2;
																					goto IL_1ebe;
																					IL_1ebe:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1ed1:
																					if (44 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1edf;
																					IL_1edf:
																					if (44 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1eed;
																					IL_1eed:
																					array2[num6 - 1] = (Vector3)array2[num6 - 1];
																					goto IL_1f15;
																					IL_1f15:
																					array[num6 - 1] = 4;
																					goto end_IL_09e4;
																					IL_1f2e:
																					if (46 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1f3c;
																					IL_1f3c:
																					if (46 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1f4a;
																					IL_1f4a:
																					array[num6 - 1] = 0;
																					goto IL_1f5e;
																					IL_1f5e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<EventData, int>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((EventData)array2[num6 - 1]);
																					goto IL_1f9c;
																					IL_1f9c:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_1faf:
																					if (49 < b)
																					{
																						goto IL_1fbd;
																					}
																					num = 194;
																					goto IL_2088;
																					IL_1fbd:
																					if (50 >= b)
																					{
																						goto IL_1fc8;
																					}
																					goto IL_2022;
																					IL_1fc8:
																					if (50 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_1fd6;
																					IL_1fd6:
																					((GameObject[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = (GameObject)array2[num6 - 1];
																					goto IL_200f;
																					IL_200f:
																					num6 -= 3;
																					goto end_IL_09e4;
																					IL_2022:
																					if (51 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_2030;
																					IL_2030:
																					if (51 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_203e;
																					IL_203e:
																					array2[num6 - 1] = (Quaternion)array2[num6 - 1];
																					goto IL_2066;
																					IL_2066:
																					array[num6 - 1] = 4;
																					goto end_IL_09e4;
																					IL_2850:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_2088:
																					if (49 <= b)
																					{
																						goto IL_2093;
																					}
																					goto IL_20be;
																					IL_2093:
																					array2[num6] = null;
																					goto IL_209d;
																					IL_209d:
																					array[num6] = 5;
																					goto IL_20ab;
																					IL_20ab:
																					num6++;
																					goto end_IL_09e4;
																					IL_20be:
																					if (48 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_20cc;
																					IL_20cc:
																					if (48 > b)
																					{
																						goto end_IL_09b4;
																					}
																					num = 460;
																					goto IL_20e3;
																					IL_2860:
																					if (68 >= b)
																					{
																						goto IL_286b;
																					}
																					goto IL_28a9;
																					IL_20e3:
																					array[num6 - 1] = 3;
																					goto IL_20f7;
																					IL_20f7:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2136;
																					IL_2136:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_2149:
																					if (61 >= b)
																					{
																						goto IL_2157;
																					}
																					goto IL_260c;
																					IL_2157:
																					if (61 > b)
																					{
																						goto IL_2165;
																					}
																					num = 126;
																					goto IL_25a6;
																					IL_2165:
																					if (56 >= b)
																					{
																						goto IL_2173;
																					}
																					goto IL_2396;
																					IL_2173:
																					if (56 <= b)
																					{
																						goto IL_217e;
																					}
																					goto IL_21e5;
																					IL_217e:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_21be;
																					IL_21be:
																					array[num6 - 2] = 3;
																					goto IL_21d2;
																					IL_21d2:
																					num6--;
																					goto end_IL_09e4;
																					IL_21e5:
																					if (54 >= b)
																					{
																						goto IL_21f3;
																					}
																					goto IL_22f8;
																					IL_21f3:
																					if (54 <= b)
																					{
																						goto IL_21fe;
																					}
																					goto IL_226d;
																					IL_21fe:
																					array[num6 - 1] = 3;
																					num = 406;
																					goto IL_221b;
																					IL_221b:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_225a;
																					IL_225a:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_226d:
																					if (53 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_227b;
																					IL_227b:
																					if (53 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_2289;
																					IL_2289:
																					array[num6 - 1] = 3;
																					goto IL_229d;
																					IL_229d:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 51;
																					goto IL_22e5;
																					IL_22e5:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_22f8:
																					if (55 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_2306;
																					IL_2306:
																					if (55 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_2314;
																					IL_2314:
																					array[num6 - 2] = 0;
																					goto IL_2328;
																					IL_2328:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_2375;
																					IL_2375:
																					num6--;
																					goto IL_2383;
																					IL_2383:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_2396:
																					if (58 < b)
																					{
																						goto IL_23a4;
																					}
																					goto IL_24a7;
																					IL_23a4:
																					if (59 >= b)
																					{
																						goto IL_23af;
																					}
																					goto IL_242c;
																					IL_23af:
																					if (59 > b)
																					{
																						goto end_IL_09b4;
																					}
																					num = 53;
																					goto IL_23c6;
																					IL_28b4:
																					if (69 <= b)
																					{
																					}
																					goto end_IL_09b4;
																					IL_23c6:
																					array[num6 - 1] = 3;
																					goto IL_23da;
																					IL_23da:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2419;
																					IL_2419:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_242c:
																					if (60 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_243a;
																					IL_243a:
																					if (60 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_2448;
																					IL_2448:
																					array2[num6] = ((delegate*<object[]>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])();
																					num = 115;
																					goto IL_246f;
																					IL_246f:
																					array[num6] = 5;
																					goto IL_247d;
																					IL_247d:
																					num6++;
																					num = 269;
																					goto IL_2494;
																					IL_2494:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_24a7:
																					if (58 > b)
																					{
																						goto IL_24b5;
																					}
																					goto IL_2537;
																					IL_24b5:
																					if (57 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_24c3;
																					IL_24c3:
																					if (57 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_24d1;
																					IL_24d1:
																					array[num6 - 1] = 3;
																					goto IL_24e5;
																					IL_24e5:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2524;
																					IL_2524:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_2537:
																					array[num6 - 1] = 3;
																					goto IL_254b;
																					IL_254b:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_258a;
																					IL_258a:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_286b:
																					if (68 > b)
																					{
																						goto end_IL_09b4;
																					}
																					num = 329;
																					goto IL_287f;
																					IL_25a6:
																					array[num6 - 1] = 3;
																					goto IL_25ba;
																					IL_25ba:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_25f9;
																					IL_25f9:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_260c:
																					if (65 >= b)
																					{
																						goto IL_261a;
																					}
																					goto IL_2794;
																					IL_261a:
																					if (65 <= b)
																					{
																						goto IL_2625;
																					}
																					goto IL_2651;
																					IL_2625:
																					global::_003CModule_003E.object_13 = (object[])array2[num6 - 1];
																					goto IL_263e;
																					IL_263e:
																					num6--;
																					goto end_IL_09e4;
																					IL_2651:
																					if (63 >= b)
																					{
																						goto IL_265f;
																					}
																					goto IL_276a;
																					IL_265f:
																					if (63 > b)
																					{
																						goto IL_266d;
																					}
																					num = 317;
																					goto IL_270b;
																					IL_266d:
																					if (62 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_267b;
																					IL_267b:
																					if (62 > b)
																					{
																						goto end_IL_09b4;
																					}
																					num = 306;
																					goto IL_2692;
																					IL_2899:
																					num6--;
																					goto end_IL_09e4;
																					IL_2692:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_26d2;
																					IL_26d2:
																					array[num6 - 2] = 3;
																					goto IL_26e6;
																					IL_26e6:
																					num6--;
																					num = 414;
																					goto end_IL_09e4;
																					IL_287f:
																					global::_003CModule_003E.byte_11 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_2899;
																					IL_270b:
																					array[num6 - 1] = 5;
																					goto IL_271f;
																					IL_271f:
																					array2[num6 - 1] = ((delegate*<EventData, object>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((EventData)array2[num6 - 1]);
																					goto IL_2757;
																					IL_2757:
																					ptr2 += 8;
																					goto end_IL_09e4;
																					IL_276a:
																					if (64 < b)
																					{
																						goto end_IL_09b4;
																					}
																					num = 299;
																					goto IL_2781;
																					IL_28a9:
																					if (69 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_28b4;
																					IL_2781:
																					if (64 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto end_IL_09e4;
																					IL_2794:
																					if (67 >= b)
																					{
																						goto IL_27a2;
																					}
																					goto IL_2860;
																					IL_27a2:
																					if (67 > b)
																					{
																						goto IL_27ad;
																					}
																					goto IL_27fe;
																					IL_27ad:
																					if (66 < b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_27bb;
																					IL_27bb:
																					if (66 > b)
																					{
																						goto end_IL_09b4;
																					}
																					goto IL_27c9;
																					IL_27c9:
																					global::_003CModule_003E.object_12 = (object[])array2[num6 - 1];
																					num = 385;
																					goto IL_27eb;
																					IL_27eb:
																					num6--;
																					goto end_IL_09e4;
																					IL_27fe:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<EventData, byte>)DXNMgetLeaseManagerPollTime[*(int*)(ptr2 + num3)])((EventData)array2[num6 - 1]);
																					goto IL_283c;
																					continue;
																					end_IL_09a4:
																					break;
																				}
																				continue;
																				end_IL_09b4:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_09e4;
																		continue;
																		end_IL_09c4:
																		break;
																	}
																	continue;
																	end_IL_09d4:
																	break;
																}
																continue;
																end_IL_09e4:
																break;
															}
															continue;
															end_IL_28d2:
															break;
														}
														continue;
														end_IL_28e5:
														break;
													}
													continue;
													end_IL_28ef:
													break;
												}
												continue;
												end_IL_28fa:
												break;
											}
											continue;
											end_IL_290a:
											break;
										}
										continue;
										end_IL_2923:
										break;
									}
									continue;
									end_IL_2933:
									break;
								}
								continue;
								end_IL_2943:
								break;
							}
							continue;
							end_IL_2953:
							break;
						}
						continue;
						end_IL_2963:
						break;
					}
					continue;
					end_IL_2973:
					break;
				}
				continue;
				end_IL_2983:
				break;
			}
		}
	}

	private unsafe void method_1(GameObject gameObject_2)
	{
		int num = 227;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[4];
										while (true)
										{
											object[] array6 = new object[1];
											num = 50;
											while (true)
											{
												array6[0] = gameObject_2;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getServicePackMajorsetRole.ConsoleCancelEventArgsTargetTypeName);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_04d4:
																		if (b >= 1)
																		{
																			while (b <= 31)
																			{
																				while (true)
																				{
																					IL_04b4:
																					if (16 >= b)
																					{
																						while (true)
																						{
																							IL_04a4:
																							if (16 > b)
																							{
																								while (true)
																								{
																									IL_0494:
																									if (8 < b)
																									{
																										while (true)
																										{
																											IL_0484:
																											if (12 < b)
																											{
																												while (true)
																												{
																													IL_0474:
																													if (14 >= b)
																													{
																														num = 273;
																														while (true)
																														{
																															if (num != 273)
																															{
																																if (num != 1254)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 74:
																																	goto IL_0474;
																																case 34:
																																	goto IL_0484;
																																case 224:
																																	goto IL_0494;
																																case 102:
																																	goto IL_04a4;
																																case 107:
																																	goto IL_04b4;
																																case 254:
																																	goto IL_04c4;
																																case 98:
																																	goto IL_04d4;
																																case 28:
																																	goto end_IL_04d4;
																																case 113:
																																case 136:
																																	goto end_IL_04e4;
																																case 0:
																																	goto IL_04ff;
																																case 15:
																																	goto IL_050d;
																																case 13:
																																case 139:
																																	goto IL_051b;
																																case 132:
																																	goto IL_055c;
																																case 140:
																																	goto IL_0575;
																																case 112:
																																	goto IL_0583;
																																case 59:
																																	goto IL_0591;
																																case 16:
																																	goto IL_059f;
																																case 54:
																																	goto IL_05aa;
																																case 92:
																																case 142:
																																	goto IL_05bd;
																																case 155:
																																	goto IL_05ff;
																																case 29:
																																case 159:
																																	goto IL_0612;
																																case 163:
																																	goto IL_0625;
																																case 122:
																																	goto IL_0639;
																																case 138:
																																case 165:
																																	goto IL_064c;
																																case 147:
																																	goto IL_069e;
																																case 179:
																																	goto IL_06b1;
																																case 198:
																																	goto IL_06c1;
																																case 12:
																																case 26:
																																	goto IL_06cf;
																																case 52:
																																	goto IL_070f;
																																case 4:
																																	goto IL_0723;
																																case 63:
																																case 209:
																																	goto IL_0736;
																																case 106:
																																	goto IL_0744;
																																case 173:
																																	goto IL_0767;
																																case 67:
																																	goto IL_0771;
																																case 87:
																																	goto IL_077f;
																																case 215:
																																	goto IL_0792;
																																case 123:
																																	goto IL_079d;
																																case 61:
																																case 97:
																																	goto IL_07a8;
																																case 44:
																																	goto IL_07ed;
																																case 193:
																																	goto IL_07fb;
																																case 121:
																																	goto IL_080b;
																																case 73:
																																	goto IL_0819;
																																case 199:
																																case 218:
																																	goto IL_0829;
																																case 180:
																																	goto IL_0842;
																																case 177:
																																	goto IL_0850;
																																case 207:
																																	goto IL_0867;
																																case 204:
																																case 228:
																																	goto IL_087a;
																																case 229:
																																	goto IL_08a5;
																																case 171:
																																	goto IL_08b9;
																																case 233:
																																	goto IL_08cc;
																																case 51:
																																	goto IL_08da;
																																case 247:
																																	goto IL_08ea;
																																case 238:
																																	goto IL_08f8;
																																case 80:
																																case 257:
																																	goto IL_090b;
																																case 178:
																																	goto IL_094b;
																																case 169:
																																	goto IL_095f;
																																case 262:
																																	goto IL_0972;
																																case 95:
																																	goto IL_0980;
																																case 96:
																																	goto IL_098e;
																																case 82:
																																case 200:
																																	goto IL_0999;
																																case 109:
																																	goto IL_09fb;
																																case 49:
																																	goto IL_0a0e;
																																case 246:
																																	goto IL_0a1c;
																																case 94:
																																case 119:
																																	goto IL_0a2a;
																																case 197:
																																	goto IL_0a6f;
																																case 42:
																																	goto IL_0a86;
																																case 153:
																																case 202:
																																	goto IL_0a9d;
																																case 166:
																																	goto IL_0ab1;
																																case 182:
																																	goto IL_0b05;
																																case 190:
																																	goto IL_0b13;
																																case 265:
																																	goto IL_0b26;
																																case 196:
																																	goto IL_0b3a;
																																case 100:
																																case 220:
																																	goto IL_0b58;
																																case 239:
																																	goto IL_0b70;
																																case 65:
																																	goto IL_0b7e;
																																case 76:
																																case 249:
																																	goto IL_0b8c;
																																case 30:
																																	goto IL_0ba5;
																																case 45:
																																	goto IL_0bb3;
																																case 99:
																																	goto IL_0bca;
																																case 253:
																																	goto IL_0bdd;
																																case 244:
																																	goto IL_0beb;
																																case 25:
																																case 70:
																																	goto IL_0bf6;
																																case 128:
																																	goto IL_0c0a;
																																case 181:
																																	goto IL_0c42;
																																case 56:
																																	goto IL_0c55;
																																case 55:
																																	goto IL_0c63;
																																case 23:
																																	goto IL_0c6e;
																																case 81:
																																	goto IL_0c7c;
																																case 103:
																																case 116:
																																	goto IL_0c8a;
																																case 108:
																																	goto IL_0ca3;
																																case 230:
																																	goto IL_0cbf;
																																case 88:
																																	goto IL_0cca;
																																case 130:
																																	goto IL_0cd8;
																																case 6:
																																case 32:
																																	goto IL_0ce6;
																																case 78:
																																	goto IL_0d04;
																																case 22:
																																	goto IL_0d12;
																																case 60:
																																	goto IL_0d20;
																																case 17:
																																case 191:
																																	goto IL_0d3c;
																																case 221:
																																	goto IL_0d79;
																																case 167:
																																	goto IL_0d87;
																																case 68:
																																	goto IL_0dac;
																																case 118:
																																case 143:
																																	goto IL_0dba;
																																case 223:
																																	goto IL_0dd2;
																																case 232:
																																	goto IL_0df0;
																																case 39:
																																	goto IL_0e14;
																																case 47:
																																	goto IL_0e2c;
																																case 187:
																																	goto IL_0e3f;
																																case 38:
																																	goto IL_0e4d;
																																case 127:
																																case 161:
																																	goto IL_0e58;
																																case 192:
																																	goto IL_0e6c;
																																case 11:
																																	goto IL_0ea4;
																																case 129:
																																	goto IL_0eb7;
																																case 114:
																																	goto IL_0ec5;
																																case 33:
																																case 157:
																																	goto IL_0ed3;
																																case 248:
																																	goto IL_0eeb;
																																case 255:
																																	goto IL_0ef9;
																																case 137:
																																	goto IL_0f07;
																																case 245:
																																	goto IL_0f1a;
																																case 144:
																																	goto IL_0f28;
																																case 37:
																																case 149:
																																	goto IL_0f36;
																																case 57:
																																	goto IL_0f44;
																																case 174:
																																	goto IL_0f62;
																																case 43:
																																	goto IL_0f70;
																																case 194:
																																	goto IL_0f8c;
																																case 125:
																																	goto IL_0f9a;
																																case 83:
																																	goto IL_0fa8;
																																case 14:
																																	goto IL_0fb6;
																																case 19:
																																case 168:
																																	goto IL_0fc1;
																																case 260:
																																	goto IL_0fdb;
																																case 148:
																																	goto IL_0fe9;
																																case 183:
																																	goto IL_0ff7;
																																case 104:
																																	goto IL_100a;
																																case 146:
																																	goto IL_1018;
																																case 62:
																																case 186:
																																	goto IL_1026;
																																case 236:
																																	goto IL_1044;
																																case 225:
																																	goto IL_1052;
																																case 160:
																																	goto IL_1060;
																																case 69:
																																	goto IL_1073;
																																case 131:
																																	goto IL_1081;
																																case 79:
																																case 206:
																																	goto IL_108f;
																																case 219:
																																	goto IL_10a3;
																																case 208:
																																	goto IL_10fe;
																																case 189:
																																	goto IL_110c;
																																case 90:
																																case 162:
																																	goto IL_1128;
																																case 124:
																																	goto IL_1165;
																																case 105:
																																	goto IL_1173;
																																case 231:
																																	goto IL_1186;
																																case 86:
																																	goto IL_1191;
																																case 115:
																																case 259:
																																	goto IL_119c;
																																case 205:
																																	goto IL_11b8;
																																case 117:
																																	goto IL_11c3;
																																case 93:
																																case 184:
																																	goto IL_11ce;
																																case 188:
																																	goto IL_11f9;
																																case 46:
																																	goto IL_120f;
																																case 258:
																																	goto IL_121a;
																																case 1:
																																case 7:
																																case 8:
																																case 9:
																																case 18:
																																case 20:
																																case 21:
																																case 27:
																																case 36:
																																case 58:
																																case 75:
																																case 89:
																																case 91:
																																case 101:
																																case 135:
																																case 141:
																																case 145:
																																case 151:
																																case 152:
																																case 154:
																																case 164:
																																case 170:
																																case 172:
																																case 175:
																																case 176:
																																case 185:
																																case 216:
																																case 217:
																																case 237:
																																case 242:
																																case 251:
																																case 252:
																																case 261:
																																case 266:
																																	goto end_IL_0461;
																																case 2:
																																case 10:
																																case 24:
																																case 31:
																																case 35:
																																case 41:
																																case 48:
																																case 64:
																																case 66:
																																case 71:
																																case 72:
																																case 77:
																																case 84:
																																case 110:
																																case 111:
																																case 120:
																																case 126:
																																case 150:
																																case 156:
																																case 201:
																																case 203:
																																case 210:
																																case 211:
																																case 212:
																																case 213:
																																case 222:
																																case 234:
																																case 235:
																																case 240:
																																case 241:
																																case 243:
																																case 256:
																																case 263:
																																case 264:
																																	goto end_IL_04f4;
																																case 5:
																																	goto end_IL_1238;
																																case 214:
																																	goto end_IL_124b;
																																case 50:
																																	goto end_IL_1255;
																																case 40:
																																	goto end_IL_1260;
																																case 158:
																																	goto end_IL_1270;
																																case 195:
																																	goto end_IL_1289;
																																case 134:
																																	goto end_IL_1299;
																																case 3:
																																	goto end_IL_12a9;
																																case 85:
																																	goto end_IL_12b9;
																																case 250:
																																	goto end_IL_12c9;
																																case 226:
																																	goto end_IL_12d9;
																																case 227:
																																	goto end_IL_12e9;
																																case 53:
																																case 133:
																																	return;
																																}
																																continue;
																															}
																															if (14 <= b)
																															{
																																goto IL_0b58;
																															}
																															goto IL_0b70;
																															IL_0ba5:
																															array[num6] = 1;
																															goto IL_0bb3;
																															IL_0bca:
																															ptr2 += 16;
																															goto end_IL_04f4;
																															IL_0bb3:
																															num6++;
																															num = 99;
																															goto IL_0bca;
																															IL_0b58:
																															ptr2 = ptr + *(int*)(ptr2 + num3);
																															goto end_IL_04f4;
																															IL_0b70:
																															if (13 < b)
																															{
																																break;
																															}
																															goto IL_0b7e;
																															IL_0b7e:
																															if (13 > b)
																															{
																																break;
																															}
																															goto IL_0b8c;
																															IL_0b8c:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																															goto IL_0ba5;
																															continue;
																															end_IL_0461:
																															break;
																														}
																														break;
																													}
																													goto IL_04ff;
																													IL_055c:
																													array[num6 - 2] = 0;
																													goto IL_05ff;
																													IL_05ff:
																													num6--;
																													goto end_IL_04f4;
																													IL_04ff:
																													if (15 < b)
																													{
																														break;
																													}
																													goto IL_050d;
																													IL_050d:
																													if (15 > b)
																													{
																														break;
																													}
																													goto IL_051b;
																													IL_051b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																													goto IL_055c;
																												}
																												break;
																											}
																											goto IL_0972;
																											IL_0ab1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)SetAuditADEra[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																											goto IL_0b05;
																											IL_0972:
																											if (12 <= b)
																											{
																												goto end_IL_04f4;
																											}
																											goto IL_0980;
																											IL_0980:
																											if (10 >= b)
																											{
																												goto IL_098e;
																											}
																											goto IL_0a6f;
																											IL_098e:
																											if (10 <= b)
																											{
																												goto IL_0999;
																											}
																											goto IL_0a0e;
																											IL_0999:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_09fb;
																											IL_09fb:
																											num6 -= 2;
																											goto end_IL_04f4;
																											IL_0a0e:
																											if (9 < b)
																											{
																												break;
																											}
																											goto IL_0a1c;
																											IL_0a1c:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_0a2a;
																											IL_0a2a:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_0b26;
																											IL_0b26:
																											array[num6 - 2] = 0;
																											goto IL_0b3a;
																											IL_0b3a:
																											num6--;
																											goto end_IL_04f4;
																											IL_0a6f:
																											if (11 < b)
																											{
																												break;
																											}
																											num = 42;
																											goto IL_0a86;
																											IL_0b05:
																											num6--;
																											goto IL_0b13;
																											IL_0a86:
																											if (11 > b)
																											{
																												break;
																											}
																											num = 153;
																											goto IL_0a9d;
																											IL_0b13:
																											ptr2 += 8;
																											goto end_IL_04f4;
																											IL_0a9d:
																											array[num6 - 2] = 0;
																											goto IL_0ab1;
																										}
																										break;
																									}
																									goto IL_0575;
																									IL_0612:
																									num6--;
																									goto end_IL_04f4;
																									IL_0575:
																									if (8 > b)
																									{
																										goto IL_0583;
																									}
																									goto IL_0612;
																									IL_0583:
																									if (4 < b)
																									{
																										goto IL_0591;
																									}
																									goto IL_06b1;
																									IL_0591:
																									if (6 >= b)
																									{
																										goto IL_059f;
																									}
																									goto IL_08cc;
																									IL_059f:
																									if (6 > b)
																									{
																										goto IL_05aa;
																									}
																									goto IL_05bd;
																									IL_05aa:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_06c1;
																									IL_06c1:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_06cf;
																									IL_06cf:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_070f;
																									IL_070f:
																									array[num6 - 2] = 0;
																									goto IL_0723;
																									IL_0723:
																									num6--;
																									goto end_IL_04f4;
																									IL_05bd:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_0625;
																									IL_0625:
																									array[num6 - 2] = 0;
																									goto IL_0639;
																									IL_0639:
																									num6--;
																									goto end_IL_04f4;
																									IL_08cc:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_08da;
																									IL_08da:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_090b;
																									IL_090b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_094b;
																									IL_094b:
																									array[num6 - 2] = 0;
																									goto IL_095f;
																									IL_095f:
																									num6--;
																									goto end_IL_04f4;
																									IL_06b1:
																									if (4 <= b)
																									{
																										goto IL_0736;
																									}
																									goto IL_0792;
																									IL_0736:
																									array[num6] = 0;
																									goto IL_0744;
																									IL_0744:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																									goto IL_0767;
																									IL_0767:
																									array2[num6] = null;
																									goto IL_0771;
																									IL_0771:
																									num6++;
																									goto IL_077f;
																									IL_077f:
																									ptr2 += 8;
																									goto end_IL_04f4;
																									IL_0792:
																									if (2 >= b)
																									{
																										goto IL_079d;
																									}
																									goto IL_080b;
																									IL_079d:
																									if (2 <= b)
																									{
																										goto IL_07a8;
																									}
																									goto IL_07ed;
																									IL_07a8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_08a5;
																									IL_08a5:
																									array[num6 - 2] = 0;
																									goto IL_08b9;
																									IL_08b9:
																									num6--;
																									goto end_IL_04f4;
																									IL_07ed:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_07fb;
																									IL_07fb:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_0829;
																									IL_0829:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																									goto IL_0842;
																									IL_0842:
																									array[num6] = 0;
																									goto IL_0850;
																									IL_0850:
																									num6++;
																									num = 207;
																									goto IL_0867;
																									IL_0867:
																									ptr2 += 8;
																									goto end_IL_04f4;
																									IL_080b:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_0819;
																									IL_0819:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_087a;
																									IL_087a:
																									ref int reference = ref array4[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_08ea;
																									IL_08ea:
																									ptr2 += 8;
																									goto IL_08f8;
																									IL_08f8:
																									num6--;
																									goto end_IL_04f4;
																								}
																								break;
																							}
																							goto IL_064c;
																							IL_069e:
																							num6--;
																							goto end_IL_04f4;
																							IL_064c:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_069e;
																						}
																						break;
																					}
																					goto IL_0bdd;
																					IL_11c3:
																					if (29 > b)
																					{
																						break;
																					}
																					goto IL_11ce;
																					IL_0bdd:
																					if (24 >= b)
																					{
																						goto IL_0beb;
																					}
																					goto IL_0f8c;
																					IL_0beb:
																					if (24 <= b)
																					{
																						goto IL_0bf6;
																					}
																					goto IL_0c55;
																					IL_0bf6:
																					array[num6 - 1] = 5;
																					goto IL_0c0a;
																					IL_0c0a:
																					array2[num6 - 1] = ((delegate*<Renderer, Material>)SetAuditADEra[*(int*)(ptr2 + num3)])((Renderer)array2[num6 - 1]);
																					goto IL_0c42;
																					IL_0c42:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_0c55:
																					if (20 < b)
																					{
																						goto IL_0c63;
																					}
																					num = 68;
																					goto IL_0dac;
																					IL_0c63:
																					if (22 < b)
																					{
																						goto IL_0c6e;
																					}
																					num = 230;
																					goto IL_0cbf;
																					IL_0c6e:
																					if (23 < b)
																					{
																						break;
																					}
																					goto IL_0c7c;
																					IL_0c7c:
																					if (23 > b)
																					{
																						break;
																					}
																					goto IL_0c8a;
																					IL_0c8a:
																					global::_003CModule_003E.gradient_2 = (Gradient)array2[num6 - 1];
																					goto IL_0ca3;
																					IL_0ca3:
																					num6--;
																					goto end_IL_04f4;
																					IL_11f9:
																					array[num6 - 1] = 0;
																					goto end_IL_04f4;
																					IL_0cbf:
																					if (22 > b)
																					{
																						goto IL_0cca;
																					}
																					num = 17;
																					goto IL_0d3c;
																					IL_0cca:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_0cd8;
																					IL_0cd8:
																					if (21 > b)
																					{
																						break;
																					}
																					goto IL_0ce6;
																					IL_0ce6:
																					array2[num6] = ((delegate*<GradientColorKey[]>)SetAuditADEra[*(int*)(ptr2 + num3)])();
																					goto IL_0d04;
																					IL_0d04:
																					array[num6] = 5;
																					goto IL_0d12;
																					IL_0d12:
																					num6++;
																					goto IL_0d20;
																					IL_0d20:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_120f:
																					if (31 < b)
																					{
																						break;
																					}
																					goto IL_121a;
																					IL_0d3c:
																					((delegate*<Gradient, GradientColorKey[], void>)SetAuditADEra[*(int*)(ptr2 + num3)])((Gradient)array2[num6 - 2], (GradientColorKey[])array2[num6 - 1]);
																					goto IL_0d79;
																					IL_0d79:
																					num6 -= 2;
																					goto IL_0d87;
																					IL_0d87:
																					ptr2 += 8;
																					num = 2;
																					goto end_IL_04f4;
																					IL_11ce:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_11f9;
																					IL_0dac:
																					if (20 <= b)
																					{
																						goto IL_0dba;
																					}
																					goto IL_0e3f;
																					IL_0dba:
																					array[num6] = array[num6 - 1];
																					goto IL_0dd2;
																					IL_0dd2:
																					array3[num6 - 0] = array3[num6 - 1];
																					goto IL_0df0;
																					IL_0df0:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0e14;
																					IL_0e14:
																					array2[num6] = array2[num6 - 1];
																					goto IL_0e2c;
																					IL_0e2c:
																					num6++;
																					goto end_IL_04f4;
																					IL_0e3f:
																					if (18 >= b)
																					{
																						goto IL_0e4d;
																					}
																					goto IL_0f1a;
																					IL_0e4d:
																					if (18 <= b)
																					{
																						goto IL_0e58;
																					}
																					goto IL_0eb7;
																					IL_0e58:
																					array[num6 - 1] = 5;
																					goto IL_0e6c;
																					IL_0e6c:
																					array2[num6 - 1] = ((delegate*<GameObject, Renderer>)SetAuditADEra[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_0ea4;
																					IL_0ea4:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_0eb7:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_0ec5;
																					IL_0ec5:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0ed3;
																					IL_0ed3:
																					array2[num6] = array6[*(int*)(ptr2 + num3)];
																					goto IL_0eeb;
																					IL_0eeb:
																					array[num6] = 5;
																					goto IL_0ef9;
																					IL_0ef9:
																					num6++;
																					goto IL_0f07;
																					IL_0f07:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_0f1a:
																					if (19 < b)
																					{
																						break;
																					}
																					goto IL_0f28;
																					IL_0f28:
																					if (19 > b)
																					{
																						break;
																					}
																					goto IL_0f36;
																					IL_0f36:
																					array[num6] = 5;
																					goto IL_0f44;
																					IL_0f44:
																					array2[num6] = ((delegate*<Gradient>)SetAuditADEra[*(int*)(ptr2 + num3)])();
																					goto IL_0f62;
																					IL_0f62:
																					num6++;
																					goto IL_0f70;
																					IL_0f70:
																					ptr2 += 8;
																					num = 120;
																					goto end_IL_04f4;
																					IL_0f8c:
																					if (28 >= b)
																					{
																						goto IL_0f9a;
																					}
																					goto IL_1186;
																					IL_0f9a:
																					if (28 > b)
																					{
																						goto IL_0fa8;
																					}
																					num = 90;
																					goto IL_1128;
																					IL_0fa8:
																					if (26 >= b)
																					{
																						goto IL_0fb6;
																					}
																					goto IL_1073;
																					IL_0fb6:
																					if (26 <= b)
																					{
																						goto IL_0fc1;
																					}
																					goto IL_100a;
																					IL_0fc1:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																					goto IL_0fdb;
																					IL_0fdb:
																					array[num6] = 3;
																					goto IL_0fe9;
																					IL_0fe9:
																					num6++;
																					goto IL_0ff7;
																					IL_0ff7:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_100a:
																					if (25 < b)
																					{
																						break;
																					}
																					goto IL_1018;
																					IL_1018:
																					if (25 > b)
																					{
																						break;
																					}
																					goto IL_1026;
																					IL_1026:
																					array2[num6] = ((delegate*<Gradient>)SetAuditADEra[*(int*)(ptr2 + num3)])();
																					goto IL_1044;
																					IL_1044:
																					array[num6] = 5;
																					goto IL_1052;
																					IL_1052:
																					num6++;
																					goto IL_1060;
																					IL_1060:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_1073:
																					if (27 < b)
																					{
																						break;
																					}
																					goto IL_1081;
																					IL_1081:
																					if (27 > b)
																					{
																						break;
																					}
																					goto IL_108f;
																					IL_108f:
																					array[num6 - 2] = 4;
																					goto IL_10a3;
																					IL_10a3:
																					array2[num6 - 2] = ((delegate*<Gradient, float, Color>)SetAuditADEra[*(int*)(ptr2 + num3)])((Gradient)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																					num = 208;
																					goto IL_10fe;
																					IL_10fe:
																					num6--;
																					goto IL_110c;
																					IL_110c:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_121a:
																					if (31 <= b)
																					{
																					}
																					break;
																					IL_1128:
																					((delegate*<Material, Color, void>)SetAuditADEra[*(int*)(ptr2 + num3)])((Material)array2[num6 - 2], (Color)array2[num6 - 1]);
																					goto IL_1165;
																					IL_1165:
																					num6 -= 2;
																					goto IL_1173;
																					IL_1173:
																					ptr2 += 8;
																					goto end_IL_04f4;
																					IL_1186:
																					if (30 >= b)
																					{
																						goto IL_1191;
																					}
																					goto IL_120f;
																					IL_1191:
																					if (30 <= b)
																					{
																						goto IL_119c;
																					}
																					goto IL_11b8;
																					IL_119c:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_04f4;
																					IL_11b8:
																					if (29 < b)
																					{
																						break;
																					}
																					goto IL_11c3;
																				}
																				break;
																				IL_04c4:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_04f4;
																		continue;
																		end_IL_04d4:
																		break;
																	}
																	continue;
																	end_IL_04e4:
																	break;
																}
																continue;
																end_IL_04f4:
																break;
															}
															continue;
															end_IL_1238:
															break;
														}
														continue;
														end_IL_124b:
														break;
													}
													continue;
													end_IL_1255:
													break;
												}
												continue;
												end_IL_1260:
												break;
											}
											continue;
											end_IL_1270:
											break;
										}
										continue;
										end_IL_1289:
										break;
									}
									continue;
									end_IL_1299:
									break;
								}
								continue;
								end_IL_12a9:
								break;
							}
							continue;
							end_IL_12b9:
							break;
						}
						continue;
						end_IL_12c9:
						break;
					}
					continue;
					end_IL_12d9:
					break;
				}
				continue;
				end_IL_12e9:
				break;
			}
		}
	}

	private unsafe void method_2()
	{
		int num = 100;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMaxDegreeOfParallelismElementDecl.StringReaderAttribs);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_072b:
															num = 56;
															while (true)
															{
																IL_0720:
																byte b = *ptr2;
																while (true)
																{
																	IL_0710:
																	ptr2++;
																	while (true)
																	{
																		IL_0700:
																		if (b >= 1)
																		{
																			while (b <= 44)
																			{
																				while (true)
																				{
																					IL_06e3:
																					if (22 >= b)
																					{
																						while (true)
																						{
																							IL_06d3:
																							if (22 > b)
																							{
																								while (true)
																								{
																									IL_06c3:
																									if (11 >= b)
																									{
																										while (11 > b)
																										{
																											while (true)
																											{
																												IL_06a3:
																												if (5 < b)
																												{
																													while (true)
																													{
																														IL_0693:
																														if (8 < b)
																														{
																															while (true)
																															{
																																IL_0683:
																																if (9 < b)
																																{
																																	while (10 >= b)
																																	{
																																		while (10 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_05ff:
																																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																				while (true)
																																				{
																																					IL_05e6:
																																					num6 -= 2;
																																					num = 369;
																																					while (num != 369)
																																					{
																																						if (num != 1350)
																																						{
																																							goto IL_0720;
																																						}
																																						switch (num)
																																						{
																																						case 168:
																																							goto IL_05e6;
																																						case 11:
																																						case 259:
																																							goto IL_05ff;
																																						case 139:
																																							goto IL_0663;
																																						case 216:
																																							goto IL_0673;
																																						case 81:
																																							goto IL_0683;
																																						case 76:
																																							goto IL_0693;
																																						case 307:
																																							goto IL_06a3;
																																						case 338:
																																							goto IL_06b3;
																																						case 287:
																																							goto IL_06c3;
																																						case 343:
																																							goto IL_06d3;
																																						case 312:
																																							goto IL_06e3;
																																						case 169:
																																							goto IL_06f0;
																																						case 153:
																																							goto IL_0700;
																																						case 142:
																																							goto IL_0710;
																																						case 56:
																																							goto IL_0720;
																																						case 159:
																																							goto IL_072b;
																																						case 136:
																																							goto IL_0736;
																																						case 182:
																																							goto IL_0744;
																																						case 125:
																																							goto IL_074f;
																																						case 157:
																																							goto IL_0763;
																																						case 86:
																																						case 186:
																																							goto IL_0776;
																																						case 187:
																																							goto IL_078a;
																																						case 196:
																																							goto IL_07ce;
																																						case 90:
																																							goto IL_07d9;
																																						case 170:
																																							goto IL_07e7;
																																						case 18:
																																							goto IL_07f5;
																																						case 36:
																																							goto IL_0803;
																																						case 20:
																																							goto IL_0816;
																																						case 154:
																																							goto IL_0821;
																																						case 14:
																																							goto IL_0834;
																																						case 214:
																																							goto IL_0847;
																																						case 221:
																																							goto IL_0863;
																																						case 224:
																																							goto IL_0876;
																																						case 194:
																																							goto IL_0881;
																																						case 77:
																																							goto IL_088f;
																																						case 126:
																																							goto IL_089a;
																																						case 122:
																																							goto IL_08a8;
																																						case 222:
																																							goto IL_08b6;
																																						case 178:
																																							goto IL_08c9;
																																						case 3:
																																							goto IL_08dc;
																																						case 210:
																																							goto IL_08ea;
																																						case 173:
																																						case 215:
																																							goto IL_08f8;
																																						case 180:
																																							goto IL_090c;
																																						case 228:
																																							goto IL_0950;
																																						case 236:
																																							goto IL_0963;
																																						case 94:
																																							goto IL_0971;
																																						case 240:
																																							goto IL_0984;
																																						case 38:
																																							goto IL_098f;
																																						case 150:
																																						case 225:
																																							goto IL_099d;
																																						case 6:
																																							goto IL_09cb;
																																						case 43:
																																							goto IL_09d9;
																																						case 103:
																																						case 251:
																																							goto IL_09ec;
																																						case 202:
																																							goto IL_0a25;
																																						case 73:
																																						case 252:
																																							goto IL_0a3e;
																																						case 257:
																																							goto IL_0a4d;
																																						case 25:
																																						case 249:
																																							goto IL_0a5b;
																																						case 92:
																																							goto IL_0a6f;
																																						case 258:
																																							goto IL_0ac1;
																																						case 67:
																																						case 267:
																																							goto IL_0ad4;
																																						case 96:
																																							goto IL_0aff;
																																						case 71:
																																						case 268:
																																							goto IL_0b18;
																																						case 271:
																																							goto IL_0b5d;
																																						case 284:
																																							goto IL_0b70;
																																						case 264:
																																							goto IL_0b7b;
																																						case 205:
																																							goto IL_0b8e;
																																						case 253:
																																						case 294:
																																							goto IL_0ba1;
																																						case 190:
																																							goto IL_0bb5;
																																						case 291:
																																							goto IL_0bf4;
																																						case 297:
																																							goto IL_0c07;
																																						case 298:
																																							goto IL_0c1a;
																																						case 8:
																																							goto IL_0c28;
																																						case 134:
																																							goto IL_0c36;
																																						case 299:
																																							goto IL_0c49;
																																						case 69:
																																							goto IL_0c57;
																																						case 57:
																																						case 177:
																																							goto IL_0c65;
																																						case 147:
																																							goto IL_0c79;
																																						case 110:
																																							goto IL_0cc1;
																																						case 141:
																																						case 300:
																																							goto IL_0cd4;
																																						case 200:
																																							goto IL_0d0d;
																																						case 303:
																																							goto IL_0d20;
																																						case 309:
																																							goto IL_0d33;
																																						case 188:
																																							goto IL_0d41;
																																						case 313:
																																							goto IL_0d54;
																																						case 318:
																																							goto IL_0d67;
																																						case 83:
																																						case 323:
																																							goto IL_0d83;
																																						case 238:
																																							goto IL_0dc3;
																																						case 289:
																																							goto IL_0dd7;
																																						case 327:
																																							goto IL_0dea;
																																						case 207:
																																							goto IL_0e01;
																																						case 104:
																																						case 292:
																																							goto IL_0e0f;
																																						case 223:
																																							goto IL_0e27;
																																						case 40:
																																							goto IL_0e35;
																																						case 79:
																																							goto IL_0e43;
																																						case 328:
																																						case 332:
																																							goto IL_0e56;
																																						case 82:
																																							goto IL_0e6a;
																																						case 62:
																																							goto IL_0ea9;
																																						case 48:
																																						case 333:
																																							goto IL_0ebc;
																																						case 337:
																																							goto IL_0eeb;
																																						case 148:
																																							goto IL_0ef9;
																																						case 276:
																																						case 280:
																																							goto IL_0f04;
																																						case 290:
																																							goto IL_0f44;
																																						case 301:
																																							goto IL_0f58;
																																						case 89:
																																							goto IL_0f6b;
																																						case 37:
																																							goto IL_0f79;
																																						case 39:
																																							goto IL_0f8c;
																																						case 65:
																																							goto IL_0f97;
																																						case 10:
																																						case 226:
																																							goto IL_0fa5;
																																						case 137:
																																							goto IL_0fce;
																																						case 66:
																																							goto IL_0fdc;
																																						case 2:
																																							goto IL_0fef;
																																						case 68:
																																							goto IL_0ffd;
																																						case 123:
																																						case 144:
																																							goto IL_100b;
																																						case 269:
																																							goto IL_1019;
																																						case 115:
																																							goto IL_103c;
																																						case 246:
																																							goto IL_1046;
																																						case 234:
																																							goto IL_1054;
																																						case 340:
																																							goto IL_1067;
																																						case 319:
																																							goto IL_107e;
																																						case 237:
																																						case 341:
																																							goto IL_1091;
																																						case 15:
																																							goto IL_10bc;
																																						case 88:
																																						case 342:
																																							goto IL_10d5;
																																						case 219:
																																							goto IL_10f2;
																																						case 64:
																																							goto IL_1131;
																																						case 346:
																																							goto IL_1144;
																																						case 295:
																																							goto IL_1152;
																																						case 227:
																																						case 348:
																																							goto IL_1165;
																																						case 165:
																																							goto IL_119d;
																																						case 285:
																																							goto IL_11b1;
																																						case 176:
																																						case 350:
																																							goto IL_11cd;
																																						case 352:
																																							goto IL_11e9;
																																						case 220:
																																							goto IL_11fd;
																																						case 31:
																																						case 353:
																																							goto IL_1210;
																																						case 206:
																																							goto IL_122a;
																																						case 308:
																																						case 354:
																																							goto IL_123d;
																																						case 162:
																																							goto IL_1251;
																																						case 117:
																																							goto IL_1290;
																																						case 355:
																																							goto IL_12a3;
																																						case 145:
																																						case 356:
																																							goto IL_12b6;
																																						case 260:
																																							goto IL_12cf;
																																						case 4:
																																							goto IL_12dd;
																																						case 17:
																																							goto IL_12eb;
																																						case 357:
																																							goto IL_12fe;
																																						case 111:
																																						case 359:
																																							goto IL_1317;
																																						case 58:
																																							goto IL_134f;
																																						case 52:
																																							goto IL_1363;
																																						case 21:
																																							goto IL_1376;
																																						case 155:
																																						case 175:
																																							goto IL_1384;
																																						case 47:
																																							goto IL_13c4;
																																						case 277:
																																							goto IL_13d8;
																																						case 132:
																																							goto IL_13f4;
																																						case 23:
																																						case 174:
																																							goto IL_13ff;
																																						case 22:
																																							goto IL_1412;
																																						case 310:
																																							goto IL_141d;
																																						case 98:
																																						case 283:
																																							goto IL_142b;
																																						case 296:
																																							goto IL_146b;
																																						case 266:
																																							goto IL_147f;
																																						case 211:
																																							goto IL_1492;
																																						case 87:
																																							goto IL_14a9;
																																						case 282:
																																						case 361:
																																							goto IL_14c0;
																																						case 317:
																																							goto IL_1500;
																																						case 160:
																																							goto IL_1514;
																																						case 118:
																																							goto IL_1527;
																																						case 50:
																																							goto IL_1535;
																																						case 7:
																																						case 254:
																																							goto IL_1549;
																																						case 347:
																																							goto IL_156d;
																																						case 114:
																																							goto IL_157b;
																																						case 60:
																																							goto IL_1589;
																																						case 198:
																																							goto IL_159c;
																																						case 45:
																																							goto IL_15aa;
																																						case 53:
																																						case 189:
																																							goto IL_15b5;
																																						case 101:
																																							goto IL_15cd;
																																						case 12:
																																							goto IL_15db;
																																						case 42:
																																						case 235:
																																							goto IL_15e9;
																																						case 232:
																																							goto IL_1602;
																																						case 33:
																																							goto IL_1610;
																																						case 112:
																																							goto IL_161e;
																																						case 212:
																																							goto IL_1631;
																																						case 201:
																																							goto IL_163c;
																																						case 51:
																																						case 95:
																																							goto IL_164a;
																																						case 278:
																																							goto IL_168b;
																																						case 1:
																																							goto IL_169f;
																																						case 120:
																																							goto IL_16b2;
																																						case 230:
																																							goto IL_16c0;
																																						case 256:
																																						case 344:
																																							goto IL_16ce;
																																						case 113:
																																							goto IL_1720;
																																						case 85:
																																							goto IL_1733;
																																						case 29:
																																							goto IL_1741;
																																						case 133:
																																							goto IL_174f;
																																						case 106:
																																							goto IL_175a;
																																						case 279:
																																						case 349:
																																							goto IL_1768;
																																						case 78:
																																							goto IL_1782;
																																						case 16:
																																							goto IL_179e;
																																						case 171:
																																							goto IL_17ac;
																																						case 128:
																																						case 163:
																																							goto IL_17ba;
																																						case 209:
																																							goto IL_17dc;
																																						case 330:
																																							goto IL_17ea;
																																						case 306:
																																							goto IL_17f8;
																																						case 293:
																																						case 358:
																																							goto IL_180b;
																																						case 32:
																																							goto IL_181f;
																																						case 324:
																																							goto IL_185e;
																																						case 195:
																																							goto IL_1871;
																																						case 119:
																																							goto IL_1885;
																																						case 181:
																																						case 261:
																																							goto IL_1893;
																																						case 26:
																																							goto IL_18d3;
																																						case 331:
																																							goto IL_18e7;
																																						case 131:
																																							goto IL_18fa;
																																						case 199:
																																							goto IL_1908;
																																						case 75:
																																						case 164:
																																							goto IL_1916;
																																						case 204:
																																							goto IL_1933;
																																						case 105:
																																							goto IL_1972;
																																						case 55:
																																						case 151:
																																							goto IL_1982;
																																						case 61:
																																							goto IL_19af;
																																						case 339:
																																							goto IL_19bd;
																																						case 91:
																																							goto IL_19cb;
																																						case 0:
																																						case 9:
																																						case 13:
																																						case 24:
																																						case 27:
																																						case 28:
																																						case 35:
																																						case 70:
																																						case 80:
																																						case 93:
																																						case 109:
																																						case 124:
																																						case 129:
																																						case 130:
																																						case 135:
																																						case 138:
																																						case 140:
																																						case 143:
																																						case 146:
																																						case 156:
																																						case 158:
																																						case 179:
																																						case 183:
																																						case 191:
																																						case 229:
																																						case 233:
																																						case 239:
																																						case 241:
																																						case 242:
																																						case 244:
																																						case 247:
																																						case 248:
																																						case 270:
																																						case 273:
																																						case 274:
																																						case 275:
																																						case 286:
																																						case 302:
																																						case 304:
																																						case 305:
																																						case 314:
																																						case 320:
																																						case 325:
																																						case 326:
																																						case 334:
																																						case 336:
																																						case 362:
																																							goto end_IL_0663;
																																						case 19:
																																						case 30:
																																						case 34:
																																						case 41:
																																						case 44:
																																						case 59:
																																						case 63:
																																						case 84:
																																						case 97:
																																						case 107:
																																						case 108:
																																						case 116:
																																						case 121:
																																						case 127:
																																						case 149:
																																						case 152:
																																						case 161:
																																						case 166:
																																						case 167:
																																						case 172:
																																						case 184:
																																						case 185:
																																						case 192:
																																						case 197:
																																						case 203:
																																						case 208:
																																						case 213:
																																						case 217:
																																						case 218:
																																						case 231:
																																						case 243:
																																						case 245:
																																						case 250:
																																						case 255:
																																						case 262:
																																						case 265:
																																						case 272:
																																						case 281:
																																						case 311:
																																						case 315:
																																						case 316:
																																						case 322:
																																						case 329:
																																						case 335:
																																						case 345:
																																						case 351:
																																							goto end_IL_05d3;
																																						case 54:
																																							goto end_IL_19ee;
																																						case 321:
																																							goto end_IL_1a01;
																																						case 360:
																																							goto end_IL_1a0b;
																																						case 5:
																																							goto end_IL_1a16;
																																						case 263:
																																							goto end_IL_1a26;
																																						case 46:
																																						case 193:
																																							goto end_IL_1a36;
																																						case 72:
																																							goto end_IL_1a46;
																																						case 288:
																																							goto end_IL_1a56;
																																						case 102:
																																							goto end_IL_1a66;
																																						case 99:
																																							goto end_IL_1a76;
																																						case 100:
																																							goto end_IL_1a86;
																																						case 49:
																																						case 74:
																																							return;
																																						}
																																						continue;
																																						end_IL_05d3:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			goto end_IL_06b3;
																																			continue;
																																			end_IL_0663:
																																			break;
																																			IL_0663:;
																																		}
																																		break;
																																		IL_0673:;
																																	}
																																	break;
																																}
																																goto IL_1376;
																																IL_13d8:
																																num6--;
																																num = 127;
																																goto end_IL_06b3;
																																IL_1376:
																																if (9 > b)
																																{
																																	break;
																																}
																																goto IL_1384;
																																IL_1384:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																goto IL_13c4;
																																IL_13c4:
																																array[num6 - 2] = 0;
																																goto IL_13d8;
																															}
																															break;
																														}
																														goto IL_13f4;
																														IL_14c0:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_1500;
																														IL_13f4:
																														if (8 <= b)
																														{
																															goto IL_13ff;
																														}
																														goto IL_1412;
																														IL_13ff:
																														num6--;
																														goto end_IL_06b3;
																														IL_1412:
																														if (6 >= b)
																														{
																															goto IL_141d;
																														}
																														goto IL_1492;
																														IL_141d:
																														if (6 > b)
																														{
																															break;
																														}
																														goto IL_142b;
																														IL_142b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_146b;
																														IL_146b:
																														array[num6 - 2] = 0;
																														goto IL_147f;
																														IL_147f:
																														num6--;
																														goto end_IL_06b3;
																														IL_1492:
																														if (7 < b)
																														{
																															break;
																														}
																														num = 87;
																														goto IL_14a9;
																														IL_1500:
																														array[num6 - 2] = 0;
																														goto IL_1514;
																														IL_14a9:
																														if (7 > b)
																														{
																															break;
																														}
																														num = 282;
																														goto IL_14c0;
																														IL_1514:
																														num6--;
																														goto end_IL_06b3;
																													}
																													break;
																												}
																												goto IL_0950;
																												IL_1054:
																												ptr2 += 8;
																												goto end_IL_06b3;
																												IL_0950:
																												if (5 <= b)
																												{
																													goto IL_0b18;
																												}
																												goto IL_0eeb;
																												IL_0b18:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_11e9;
																												IL_11e9:
																												array[num6 - 2] = 0;
																												goto IL_11fd;
																												IL_11fd:
																												num6--;
																												goto end_IL_06b3;
																												IL_0eeb:
																												if (2 >= b)
																												{
																													goto IL_0ef9;
																												}
																												goto IL_0f8c;
																												IL_0ef9:
																												if (2 <= b)
																												{
																													goto IL_0f04;
																												}
																												goto IL_0f6b;
																												IL_0f04:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0f44;
																												IL_0f44:
																												array[num6 - 2] = 0;
																												goto IL_0f58;
																												IL_0f58:
																												num6--;
																												goto end_IL_06b3;
																												IL_0f6b:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_0f79;
																												IL_0f79:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_12b6;
																												IL_12b6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																												goto IL_12cf;
																												IL_12cf:
																												array[num6] = 0;
																												goto IL_12dd;
																												IL_12dd:
																												num6++;
																												goto IL_12eb;
																												IL_12eb:
																												ptr2 += 8;
																												goto end_IL_06b3;
																												IL_0f8c:
																												if (3 >= b)
																												{
																													goto IL_0f97;
																												}
																												goto IL_0fef;
																												IL_0f97:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_0fa5;
																												IL_0fa5:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0fce;
																												IL_0fce:
																												ptr2 += 8;
																												goto IL_0fdc;
																												IL_0fdc:
																												num6--;
																												goto end_IL_06b3;
																												IL_0fef:
																												if (4 < b)
																												{
																													break;
																												}
																												goto IL_0ffd;
																												IL_0ffd:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_100b;
																												IL_100b:
																												array[num6] = 0;
																												goto IL_1019;
																												IL_1019:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_103c;
																												IL_103c:
																												array2[num6] = null;
																												goto IL_1046;
																												IL_1046:
																												num6++;
																												goto IL_1054;
																											}
																											goto end_IL_06f0;
																											continue;
																											end_IL_06b3:
																											break;
																											IL_06b3:;
																										}
																										break;
																									}
																									goto IL_1527;
																									IL_1916:
																									array[num6 - 1] = 0;
																									num = 204;
																									goto IL_1933;
																									IL_1527:
																									if (16 >= b)
																									{
																										goto IL_1535;
																									}
																									goto IL_1733;
																									IL_1535:
																									if (16 <= b)
																									{
																										num = 7;
																										goto IL_1549;
																									}
																									goto IL_159c;
																									IL_1933:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_1972;
																									IL_1549:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])();
																									goto IL_156d;
																									IL_156d:
																									array[num6] = 0;
																									goto IL_157b;
																									IL_157b:
																									num6++;
																									goto IL_1589;
																									IL_1589:
																									ptr2 += 8;
																									break;
																									IL_159c:
																									if (13 >= b)
																									{
																										goto IL_15aa;
																									}
																									goto IL_1631;
																									IL_15aa:
																									if (13 <= b)
																									{
																										goto IL_15b5;
																									}
																									goto IL_15cd;
																									IL_15b5:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_15cd:
																									if (12 < b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_15db;
																									IL_15db:
																									if (12 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_15e9;
																									IL_15e9:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_1602;
																									IL_1602:
																									array[num6] = 1;
																									goto IL_1610;
																									IL_1610:
																									num6++;
																									goto IL_161e;
																									IL_161e:
																									ptr2 += 16;
																									break;
																									IL_1631:
																									if (14 >= b)
																									{
																										goto IL_163c;
																									}
																									goto IL_16b2;
																									IL_163c:
																									if (14 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_164a;
																									IL_164a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_168b;
																									IL_168b:
																									array[num6 - 2] = 0;
																									goto IL_169f;
																									IL_169f:
																									num6--;
																									break;
																									IL_16b2:
																									if (15 < b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_16c0;
																									IL_16c0:
																									if (15 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_16ce;
																									IL_16ce:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1720;
																									IL_1720:
																									num6--;
																									break;
																									IL_1733:
																									if (19 >= b)
																									{
																										goto IL_1741;
																									}
																									goto IL_1871;
																									IL_1741:
																									if (19 > b)
																									{
																										goto IL_174f;
																									}
																									goto IL_180b;
																									IL_174f:
																									if (17 >= b)
																									{
																										goto IL_175a;
																									}
																									goto IL_179e;
																									IL_175a:
																									if (17 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_1768;
																									IL_1768:
																									global::_003CModule_003E.int_209 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_1782;
																									IL_1782:
																									num6--;
																									num = 243;
																									break;
																									IL_179e:
																									if (18 < b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_17ac;
																									IL_17ac:
																									if (18 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_17ba;
																									IL_17ba:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																									num = 209;
																									goto IL_17dc;
																									IL_17dc:
																									array[num6] = 3;
																									goto IL_17ea;
																									IL_17ea:
																									num6++;
																									goto IL_17f8;
																									IL_17f8:
																									ptr2 += 16;
																									break;
																									IL_180b:
																									array[num6 - 1] = 3;
																									goto IL_181f;
																									IL_181f:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_185e;
																									IL_185e:
																									ptr2 += 8;
																									break;
																									IL_1871:
																									if (20 >= b)
																									{
																										num = 119;
																										goto IL_1885;
																									}
																									goto IL_18fa;
																									IL_1972:
																									ptr2 += 8;
																									break;
																									IL_1885:
																									if (20 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_1893;
																									IL_1893:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_18d3;
																									IL_18d3:
																									array[num6 - 2] = 3;
																									goto IL_18e7;
																									IL_18e7:
																									num6--;
																									break;
																									IL_18fa:
																									if (21 < b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_1908;
																									IL_1908:
																									if (21 > b)
																									{
																										goto end_IL_06f0;
																									}
																									goto IL_1916;
																								}
																								break;
																							}
																							goto IL_1982;
																							IL_19cb:
																							ptr2 += 8;
																							break;
																							IL_1982:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])();
																							num = 61;
																							goto IL_19af;
																							IL_19af:
																							array[num6] = 0;
																							goto IL_19bd;
																							IL_19bd:
																							num6++;
																							goto IL_19cb;
																						}
																						break;
																					}
																					goto IL_0736;
																					IL_0b70:
																					if (43 >= b)
																					{
																						goto IL_0b7b;
																					}
																					goto IL_0b8e;
																					IL_0736:
																					if (33 >= b)
																					{
																						goto IL_0744;
																					}
																					goto IL_0876;
																					IL_0744:
																					if (33 > b)
																					{
																						goto IL_074f;
																					}
																					goto IL_0776;
																					IL_074f:
																					if (27 >= b)
																					{
																						num = 157;
																						goto IL_0763;
																					}
																					goto IL_07ce;
																					IL_0b7b:
																					if (43 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_11cd;
																					IL_0763:
																					if (27 > b)
																					{
																						goto IL_0847;
																					}
																					goto IL_0ebc;
																					IL_0ebc:
																					*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((GameObject[])array2[num6 - 1]).LongLength;
																					goto IL_12fe;
																					IL_12fe:
																					array[num6 - 1] = 2;
																					break;
																					IL_0847:
																					if (24 >= b)
																					{
																						num = 298;
																						goto IL_0c1a;
																					}
																					goto IL_0dea;
																					IL_11cd:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					break;
																					IL_0c1a:
																					if (24 > b)
																					{
																						goto IL_0c28;
																					}
																					goto IL_10d5;
																					IL_0c28:
																					if (23 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0c36;
																					IL_0c36:
																					if (23 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_1210;
																					IL_1210:
																					global::_003CModule_003E.int_210 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_122a;
																					IL_122a:
																					num6--;
																					break;
																					IL_10d5:
																					array[num6 - 1] = 3;
																					num = 219;
																					goto IL_10f2;
																					IL_10f2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1131;
																					IL_1131:
																					ptr2 += 8;
																					break;
																					IL_0dea:
																					if (25 >= b)
																					{
																						num = 207;
																						goto IL_0e01;
																					}
																					goto IL_1067;
																					IL_0b8e:
																					if (44 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0d67;
																					IL_0e01:
																					if (25 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0e0f;
																					IL_0e0f:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0e27;
																					IL_0e27:
																					array[num6] = 5;
																					goto IL_0e35;
																					IL_0e35:
																					num6++;
																					goto IL_0e43;
																					IL_0e43:
																					ptr2 += 8;
																					break;
																					IL_1067:
																					if (26 < b)
																					{
																						goto end_IL_06f0;
																					}
																					num = 319;
																					goto IL_107e;
																					IL_0d67:
																					if (44 <= b)
																					{
																						num = 130;
																					}
																					goto end_IL_06f0;
																					IL_107e:
																					if (26 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_1165;
																					IL_1165:
																					array2[num6 - 1] = ((delegate*<Class167, GameObject[]>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])((Class167)array2[num6 - 1]);
																					goto IL_119d;
																					IL_119d:
																					array[num6 - 1] = 5;
																					goto IL_11b1;
																					IL_11b1:
																					ptr2 += 8;
																					num = 167;
																					break;
																					IL_07ce:
																					if (30 >= b)
																					{
																						goto IL_07d9;
																					}
																					goto IL_0816;
																					IL_07d9:
																					if (30 > b)
																					{
																						goto IL_07e7;
																					}
																					goto IL_09ec;
																					IL_07e7:
																					if (28 < b)
																					{
																						goto IL_07f5;
																					}
																					goto IL_0d20;
																					IL_07f5:
																					if (29 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0803;
																					IL_0803:
																					if (29 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_123d;
																					IL_123d:
																					array[num6 - 1] = 3;
																					goto IL_1251;
																					IL_1251:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1290;
																					IL_1290:
																					ptr2 += 8;
																					break;
																					IL_0d20:
																					if (28 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_1091;
																					IL_1091:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_10bc;
																					IL_10bc:
																					array[num6 - 1] = 0;
																					break;
																					IL_09ec:
																					array2[num6 - 2] = ((GameObject[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_0a25;
																					IL_0a25:
																					array[num6 - 2] = 5;
																					goto IL_0b5d;
																					IL_0b5d:
																					num6--;
																					break;
																					IL_0816:
																					if (31 < b)
																					{
																						goto IL_0821;
																					}
																					goto IL_0834;
																					IL_0821:
																					if (32 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0a4d;
																					IL_0a4d:
																					if (32 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0a5b;
																					IL_0a5b:
																					array[num6 - 2] = 0;
																					goto IL_0a6f;
																					IL_0a6f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_1144;
																					IL_1144:
																					num6--;
																					goto IL_1152;
																					IL_1152:
																					ptr2 += 8;
																					break;
																					IL_0834:
																					if (31 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0a3e;
																					IL_0a3e:
																					array2[num6] = null;
																					goto IL_0c07;
																					IL_0c07:
																					array[num6] = 5;
																					goto IL_0d54;
																					IL_0d54:
																					num6++;
																					break;
																					IL_0776:
																					array[num6 - 1] = 3;
																					goto IL_078a;
																					IL_078a:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0863;
																					IL_0863:
																					ptr2 += 8;
																					break;
																					IL_0876:
																					if (39 >= b)
																					{
																						goto IL_0881;
																					}
																					goto IL_08dc;
																					IL_0881:
																					if (39 > b)
																					{
																						goto IL_088f;
																					}
																					goto IL_0e56;
																					IL_088f:
																					if (36 >= b)
																					{
																						goto IL_089a;
																					}
																					goto IL_08c9;
																					IL_089a:
																					if (36 > b)
																					{
																						goto IL_08a8;
																					}
																					goto IL_0d83;
																					IL_08a8:
																					if (34 >= b)
																					{
																						goto IL_08b6;
																					}
																					goto IL_0963;
																					IL_08b6:
																					if (34 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_1317;
																					IL_1317:
																					array2[num6 - 1] = ((delegate*<Class167, GameObject[]>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])((Class167)array2[num6 - 1]);
																					goto IL_134f;
																					IL_134f:
																					array[num6 - 1] = 5;
																					goto IL_1363;
																					IL_1363:
																					ptr2 += 8;
																					break;
																					IL_0963:
																					if (35 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0971;
																					IL_0971:
																					if (35 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0ba1;
																					IL_0ba1:
																					array[num6 - 1] = 3;
																					goto IL_0bb5;
																					IL_0bb5:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0bf4;
																					IL_0bf4:
																					ptr2 += 8;
																					break;
																					IL_0d83:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0dc3;
																					IL_0dc3:
																					array[num6 - 2] = 3;
																					goto IL_0dd7;
																					IL_0dd7:
																					num6--;
																					break;
																					IL_08c9:
																					if (37 >= b)
																					{
																						goto IL_0ac1;
																					}
																					goto IL_0c49;
																					IL_0ac1:
																					if (37 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0cd4;
																					IL_0cd4:
																					((GameObject[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = (GameObject)array2[num6 - 1];
																					goto IL_0d0d;
																					IL_0d0d:
																					num6 -= 3;
																					break;
																					IL_0c49:
																					if (38 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0c57;
																					IL_0c57:
																					if (38 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0c65;
																					IL_0c65:
																					array[num6 - 1] = 3;
																					goto IL_0c79;
																					IL_0c79:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 110;
																					goto IL_0cc1;
																					IL_0cc1:
																					ptr2 += 8;
																					break;
																					IL_0e56:
																					array[num6 - 1] = 3;
																					goto IL_0e6a;
																					IL_0e6a:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0ea9;
																					IL_0ea9:
																					ptr2 += 8;
																					break;
																					IL_08dc:
																					if (42 >= b)
																					{
																						goto IL_08ea;
																					}
																					goto IL_0b70;
																					IL_08ea:
																					if (42 <= b)
																					{
																						goto IL_08f8;
																					}
																					goto IL_0984;
																					IL_08f8:
																					array[num6 - 1] = 3;
																					goto IL_090c;
																					IL_090c:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_12a3;
																					IL_12a3:
																					ptr2 += 8;
																					break;
																					IL_0984:
																					if (40 >= b)
																					{
																						goto IL_098f;
																					}
																					goto IL_09cb;
																					IL_098f:
																					if (40 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_099d;
																					IL_099d:
																					((delegate*<UnityEngine.Object, void>)getDeniedPermissionsIUnknownConstantAttribute[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_0d33;
																					IL_0d33:
																					num6--;
																					goto IL_0d41;
																					IL_0d41:
																					ptr2 += 8;
																					break;
																					IL_09cb:
																					if (41 < b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_09d9;
																					IL_09d9:
																					if (41 > b)
																					{
																						goto end_IL_06f0;
																					}
																					goto IL_0ad4;
																					IL_0ad4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0aff;
																					IL_0aff:
																					array[num6 - 1] = 0;
																					break;
																				}
																				goto end_IL_0700;
																				continue;
																				end_IL_06f0:
																				break;
																				IL_06f0:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0700:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_19ee:
														break;
													}
													continue;
													end_IL_1a01:
													break;
												}
												continue;
												end_IL_1a0b:
												break;
											}
											continue;
											end_IL_1a16:
											break;
										}
										continue;
										end_IL_1a26:
										break;
									}
									continue;
									end_IL_1a36:
									break;
								}
								continue;
								end_IL_1a46:
								break;
							}
							continue;
							end_IL_1a56:
							break;
						}
						continue;
						end_IL_1a66:
						break;
					}
					continue;
					end_IL_1a76:
					break;
				}
				continue;
				end_IL_1a86:
				break;
			}
		}
	}

	public Class167()
	{
		object obj = this;
		object obj2 = new GameObject[9999];
		((Class167)obj).gameObject_0 = (GameObject[])obj2;
		obj = this;
		obj2 = new GameObject[9999];
		((Class167)obj).gameObject_1 = (GameObject[])obj2;
	}

	static Class167()
	{
		double num = 0.012500000186264515;
		double num2 = 0.2800000011920929;
		double num3 = 0.3824999928474426;
		Vector3 vector = new Vector3((float)num, (float)num2, (float)num3);
		object obj = vector;
		vector3_0 = (Vector3)obj;
		obj = new GradientColorKey[4];
		object obj2 = obj;
		Color32 color = new Color32(83, 5, 185, byte.MaxValue);
		object obj3 = color;
		Color color2 = (Color32)obj3;
		obj3 = color2;
		double num4 = 0.0;
		GradientColorKey gradientColorKey = new GradientColorKey((Color)obj3, (float)num4);
		obj3 = gradientColorKey;
		((GradientColorKey[])obj2)[0] = (GradientColorKey)obj3;
		obj2 = obj;
		Color32 color3 = new Color32(30, 5, 140, byte.MaxValue);
		obj3 = color3;
		Color color4 = (Color32)obj3;
		obj3 = color4;
		num4 = 0.30000001192092896;
		GradientColorKey gradientColorKey2 = new GradientColorKey((Color)obj3, (float)num4);
		obj3 = gradientColorKey2;
		((GradientColorKey[])obj2)[1] = (GradientColorKey)obj3;
		obj2 = obj;
		Color32 color5 = new Color32(10, 5, 140, byte.MaxValue);
		obj3 = color5;
		Color color6 = (Color32)obj3;
		obj3 = color6;
		num4 = 0.6000000238418579;
		GradientColorKey gradientColorKey3 = new GradientColorKey((Color)obj3, (float)num4);
		obj3 = gradientColorKey3;
		((GradientColorKey[])obj2)[2] = (GradientColorKey)obj3;
		obj2 = obj;
		Color32 color7 = new Color32(83, 5, 185, byte.MaxValue);
		obj3 = color7;
		Color color8 = (Color32)obj3;
		obj3 = color8;
		num4 = 1.0;
		GradientColorKey gradientColorKey4 = new GradientColorKey((Color)obj3, (float)num4);
		obj3 = gradientColorKey4;
		((GradientColorKey[])obj2)[3] = (GradientColorKey)obj3;
		gradientColorKey_0 = (GradientColorKey[])obj;
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 15;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_1;
										num = 58;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FUNCFLAGFBINDABLETraceLoggingEventTypes.HasCreationContextFreeBufferNull);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0819:
													if (num4 != 1)
													{
														goto IL_000e;
													}
													num = 146;
													while (true)
													{
														if (num != 146)
														{
															if (num != 1127)
															{
																break;
															}
															switch (num)
															{
															case 76:
															case 105:
																break;
															case 119:
																goto IL_0017;
															case 34:
																goto IL_0025;
															case 37:
																goto IL_0033;
															case 42:
																goto IL_0041;
															case 3:
																goto IL_004f;
															case 45:
															case 92:
																goto IL_005d;
															case 97:
															case 102:
																goto IL_006b;
															case 75:
															case 136:
																goto IL_0079;
															case 114:
																goto IL_0087;
															case 57:
															case 63:
																goto IL_009e;
															case 128:
																goto IL_00de;
															case 66:
																goto IL_00f2;
															case 24:
																goto IL_0105;
															case 38:
															case 47:
																goto IL_0110;
															case 112:
																goto IL_011e;
															case 127:
																goto IL_0141;
															case 46:
																goto IL_0154;
															case 22:
																goto IL_0162;
															case 18:
																goto IL_0175;
															case 21:
																goto IL_0183;
															case 96:
																goto IL_0196;
															case 29:
															case 70:
																goto IL_01a1;
															case 123:
																goto IL_01b9;
															case 16:
															case 91:
																goto IL_01c4;
															case 67:
																goto IL_01d2;
															case 79:
															case 115:
																goto IL_01e0;
															case 134:
																goto IL_0209;
															case 78:
																goto IL_0217;
															case 139:
																goto IL_0233;
															case 7:
															case 74:
																goto IL_0241;
															case 73:
																goto IL_025a;
															case 106:
																goto IL_0268;
															case 135:
																goto IL_027f;
															case 13:
															case 93:
																goto IL_0292;
															case 120:
																goto IL_02d2;
															case 14:
																goto IL_02ef;
															case 65:
																goto IL_0302;
															case 52:
																goto IL_0310;
															case 39:
															case 69:
																goto IL_031e;
															case 129:
																goto IL_0332;
															case 17:
																goto IL_0386;
															case 27:
																goto IL_0394;
															case 122:
																goto IL_03a7;
															case 54:
																goto IL_03b5;
															case 35:
															case 84:
																goto IL_03c0;
															case 48:
																goto IL_0422;
															case 5:
																goto IL_0435;
															case 60:
																goto IL_0443;
															case 1:
															case 117:
																goto end_IL_0806;
															case 116:
																goto IL_0474;
															case 49:
																goto IL_0482;
															case 68:
																goto IL_0490;
															case 53:
																goto IL_04a3;
															case 28:
																goto IL_04b1;
															case 4:
															case 80:
																goto IL_04bf;
															case 43:
																goto IL_04ff;
															case 82:
																goto IL_0513;
															case 31:
																goto IL_0526;
															case 131:
																goto IL_0531;
															case 55:
															case 89:
																goto IL_053c;
															case 100:
																goto IL_0558;
															case 26:
																goto IL_0563;
															case 12:
															case 94:
																goto IL_056e;
															case 32:
																goto IL_0581;
															case 77:
																goto IL_058c;
															case 10:
															case 19:
															case 20:
															case 25:
															case 33:
															case 36:
															case 41:
															case 50:
															case 56:
															case 62:
															case 71:
															case 85:
															case 86:
															case 87:
															case 88:
															case 95:
															case 99:
															case 101:
															case 103:
															case 107:
															case 108:
															case 109:
															case 118:
															case 121:
															case 126:
															case 132:
															case 133:
															case 137:
																goto IL_0597;
															default:
																continue;
															case 0:
															case 2:
															case 6:
															case 23:
															case 30:
															case 40:
															case 44:
															case 51:
															case 59:
															case 64:
															case 72:
															case 81:
															case 98:
															case 104:
															case 110:
															case 113:
															case 138:
																goto IL_0819;
															case 125:
																goto end_IL_0819;
															case 58:
																goto end_IL_082c;
															case 90:
																goto end_IL_0836;
															case 111:
																goto end_IL_0841;
															case 15:
																goto end_IL_085f;
															case 11:
																goto end_IL_086f;
															case 61:
																goto end_IL_087f;
															case 124:
															case 130:
																goto end_IL_088a;
															case 8:
																goto end_IL_089a;
															case 9:
																goto end_IL_08aa;
															case 83:
																goto IL_08c5;
															}
															goto IL_000e;
														}
														goto IL_08c5;
														IL_08c5:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0806:
														break;
													}
													goto IL_0451;
													IL_0581:
													if (14 >= b)
													{
														goto IL_058c;
													}
													goto IL_0597;
													IL_058c:
													if (14 > b)
													{
													}
													goto IL_0597;
													IL_000e:
													b = *ptr2;
													goto IL_0017;
													IL_0017:
													ptr2++;
													goto IL_0025;
													IL_0025:
													if (b >= 1)
													{
														goto IL_0033;
													}
													goto IL_0597;
													IL_0033:
													if (b <= 14)
													{
														goto IL_0041;
													}
													goto IL_0597;
													IL_0041:
													if (7 >= b)
													{
														goto IL_004f;
													}
													goto IL_0302;
													IL_004f:
													if (7 > b)
													{
														goto IL_005d;
													}
													goto IL_0292;
													IL_005d:
													if (3 < b)
													{
														goto IL_006b;
													}
													goto IL_0196;
													IL_006b:
													if (5 < b)
													{
														goto IL_0079;
													}
													goto IL_0105;
													IL_0079:
													if (6 >= b)
													{
														goto IL_0087;
													}
													goto IL_0597;
													IL_0087:
													if (6 <= b)
													{
														num = 63;
														goto IL_009e;
													}
													goto IL_0597;
													IL_0597:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													continue;
													IL_009e:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_00de;
													IL_00de:
													array[num5 - 2] = 0;
													goto IL_00f2;
													IL_00f2:
													num5--;
													continue;
													IL_0105:
													if (5 <= b)
													{
														goto IL_0110;
													}
													goto IL_0175;
													IL_0110:
													array[num5] = 0;
													goto IL_011e;
													IL_011e:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0141;
													IL_0141:
													array2[num5] = null;
													num = 46;
													goto IL_0154;
													IL_0154:
													num5++;
													goto IL_0162;
													IL_0162:
													ptr2 += 8;
													continue;
													IL_0175:
													if (4 >= b)
													{
														goto IL_0183;
													}
													goto IL_0597;
													IL_0183:
													if (4 <= b)
													{
														continue;
													}
													goto IL_0597;
													IL_0196:
													if (3 <= b)
													{
														goto IL_01a1;
													}
													goto IL_01b9;
													IL_01a1:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													continue;
													IL_01b9:
													if (1 < b)
													{
														goto IL_01c4;
													}
													goto IL_0233;
													IL_01c4:
													if (2 >= b)
													{
														goto IL_01d2;
													}
													goto IL_0597;
													IL_01d2:
													if (2 <= b)
													{
														goto IL_01e0;
													}
													goto IL_0597;
													IL_01e0:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_0209;
													IL_0209:
													ptr2 += 8;
													goto IL_0217;
													IL_0217:
													num5--;
													num = 64;
													continue;
													IL_0233:
													if (1 <= b)
													{
														goto IL_0241;
													}
													goto IL_0597;
													IL_0241:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
													goto IL_025a;
													IL_025a:
													array[num5] = 0;
													goto IL_0268;
													IL_0268:
													num5++;
													num = 135;
													goto IL_027f;
													IL_027f:
													ptr2 += 8;
													continue;
													IL_0292:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_02d2;
													IL_02d2:
													array[num5 - 2] = 0;
													num = 14;
													goto IL_02ef;
													IL_02ef:
													num5--;
													continue;
													IL_0302:
													if (11 >= b)
													{
														goto IL_0310;
													}
													goto IL_0526;
													IL_0310:
													if (11 <= b)
													{
														goto IL_031e;
													}
													goto IL_03a7;
													IL_031e:
													array[num5 - 2] = 0;
													goto IL_0332;
													IL_0332:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AssemblyVersionAttributeCreateProxy[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
													goto IL_0386;
													IL_0386:
													num5--;
													goto IL_0394;
													IL_0394:
													ptr2 += 8;
													continue;
													IL_03a7:
													if (9 >= b)
													{
														goto IL_03b5;
													}
													goto IL_04a3;
													IL_03b5:
													if (9 <= b)
													{
														goto IL_03c0;
													}
													goto IL_0435;
													IL_03c0:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0422;
													IL_0422:
													num5 -= 2;
													continue;
													IL_0435:
													if (8 >= b)
													{
														goto IL_0443;
													}
													goto IL_0597;
													IL_0443:
													if (8 <= b)
													{
														goto IL_0451;
													}
													goto IL_0597;
													IL_0451:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0474;
													IL_0474:
													array[num5] = 0;
													goto IL_0482;
													IL_0482:
													num5++;
													goto IL_0490;
													IL_0490:
													ptr2 += 8;
													continue;
													IL_04a3:
													if (10 >= b)
													{
														goto IL_04b1;
													}
													goto IL_0597;
													IL_04b1:
													if (10 <= b)
													{
														goto IL_04bf;
													}
													goto IL_0597;
													IL_04bf:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_04ff;
													IL_04ff:
													array[num5 - 2] = 0;
													goto IL_0513;
													IL_0513:
													num5--;
													continue;
													IL_0526:
													if (13 >= b)
													{
														goto IL_0531;
													}
													goto IL_0581;
													IL_0531:
													if (13 <= b)
													{
														goto IL_053c;
													}
													goto IL_0558;
													IL_053c:
													byte* num6 = ptr2;
													num4 = 1;
													ptr2 = num6 + -200;
													continue;
													IL_0558:
													if (12 >= b)
													{
														goto IL_0563;
													}
													goto IL_0597;
													IL_0563:
													if (12 <= b)
													{
														goto IL_056e;
													}
													goto IL_0597;
													IL_056e:
													num5--;
													continue;
													end_IL_0819:
													break;
												}
												continue;
												end_IL_082c:
												break;
											}
											continue;
											end_IL_0836:
											break;
										}
										continue;
										end_IL_0841:
										break;
									}
									continue;
									end_IL_085f:
									break;
								}
								continue;
								end_IL_086f:
								break;
							}
							continue;
							end_IL_087f:
							break;
						}
						continue;
						end_IL_088a:
						break;
					}
					continue;
					end_IL_089a:
					break;
				}
				continue;
				end_IL_08aa:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								num = 49;
								while (true)
								{
									array3[0] = int_1;
									num = 11;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KeyListsetMonitoringIsEnabled.MonitoringSurvivedProcessMemorySizeSEPMonthSuff);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																if (b >= 1)
																{
																	while (true)
																	{
																		if (b <= 13)
																		{
																			while (true)
																			{
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02a0:
																						if (7 <= b)
																						{
																							while (true)
																							{
																								IL_027b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_026b:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_0252:
																										num5++;
																										num = 140;
																										while (true)
																										{
																											if (num != 140)
																											{
																												if (num != 1121)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 48:
																													goto IL_0252;
																												case 16:
																													goto IL_026b;
																												case 60:
																												case 74:
																													goto IL_027b;
																												case 8:
																													goto IL_02a0;
																												case 18:
																													goto end_IL_02a0;
																												case 51:
																													goto end_IL_02ad;
																												case 133:
																													goto end_IL_02bd;
																												case 109:
																													goto end_IL_02cd;
																												case 91:
																												case 123:
																													goto end_IL_02dd;
																												case 68:
																												case 106:
																													goto IL_02f8;
																												case 118:
																													goto IL_0306;
																												case 13:
																												case 94:
																													goto IL_0311;
																												case 7:
																												case 119:
																													goto IL_0329;
																												case 71:
																													goto IL_0334;
																												case 88:
																												case 108:
																													goto IL_0342;
																												case 103:
																													goto IL_035b;
																												case 85:
																													goto IL_0369;
																												case 41:
																													goto IL_0377;
																												case 34:
																													goto IL_038a;
																												case 58:
																													goto IL_0398;
																												case 104:
																												case 111:
																													goto IL_03a6;
																												case 26:
																													goto IL_03cf;
																												case 105:
																													goto IL_03dd;
																												case 84:
																												case 130:
																													goto end_IL_023f;
																												case 22:
																													goto IL_0407;
																												case 50:
																												case 97:
																													goto IL_0412;
																												case 0:
																													goto IL_0420;
																												case 121:
																													goto IL_0443;
																												case 3:
																													goto IL_044d;
																												case 15:
																													goto IL_045b;
																												case 127:
																													goto IL_046e;
																												case 31:
																													goto IL_047c;
																												case 96:
																													goto IL_048f;
																												case 87:
																													goto IL_049d;
																												case 46:
																												case 93:
																													goto IL_04ab;
																												case 100:
																													goto IL_04eb;
																												case 35:
																													goto IL_0508;
																												case 80:
																												case 132:
																													goto IL_051b;
																												case 30:
																												case 66:
																													goto IL_0529;
																												case 25:
																												case 29:
																													goto IL_0534;
																												case 107:
																													goto IL_0542;
																												case 43:
																													goto IL_0555;
																												case 19:
																												case 125:
																													goto IL_0560;
																												case 72:
																													goto IL_057c;
																												case 59:
																													goto IL_0593;
																												case 5:
																												case 90:
																													goto IL_05a1;
																												case 117:
																													goto IL_05b4;
																												case 98:
																													goto IL_05c2;
																												case 14:
																												case 99:
																													goto IL_05d0;
																												case 10:
																													goto IL_05de;
																												case 75:
																												case 126:
																													goto IL_05ec;
																												case 95:
																													goto IL_062c;
																												case 27:
																													goto IL_0640;
																												case 9:
																													goto IL_0653;
																												case 56:
																												case 81:
																													goto IL_0661;
																												case 63:
																													goto IL_06c3;
																												case 36:
																												case 120:
																													goto IL_06d6;
																												case 23:
																													goto IL_06ea;
																												case 33:
																													goto IL_073e;
																												case 101:
																													goto IL_074c;
																												case 2:
																												case 4:
																												case 6:
																												case 17:
																												case 20:
																												case 21:
																												case 42:
																												case 44:
																												case 45:
																												case 47:
																												case 52:
																												case 53:
																												case 55:
																												case 61:
																												case 64:
																												case 65:
																												case 77:
																												case 82:
																												case 83:
																												case 102:
																												case 112:
																												case 114:
																												case 116:
																												case 128:
																												case 129:
																												case 131:
																													goto IL_0780;
																												case 1:
																												case 12:
																												case 24:
																												case 38:
																												case 39:
																												case 40:
																												case 57:
																												case 62:
																												case 67:
																												case 69:
																												case 73:
																												case 76:
																												case 110:
																												case 113:
																												case 115:
																												case 124:
																													goto end_IL_02ed;
																												case 37:
																													goto end_IL_0793;
																												case 11:
																													goto end_IL_07a6;
																												case 49:
																													goto end_IL_07b0;
																												case 89:
																													goto end_IL_07bb;
																												case 54:
																												case 86:
																													goto end_IL_07d9;
																												case 92:
																													goto end_IL_07f2;
																												case 32:
																												case 70:
																													goto end_IL_0802;
																												case 78:
																													goto end_IL_0812;
																												case 79:
																													goto end_IL_0822;
																												case 28:
																												case 122:
																													goto IL_083d;
																												}
																												continue;
																											}
																											ptr2 += 8;
																											goto end_IL_02ed;
																											continue;
																											end_IL_023f:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_03f9;
																						}
																						goto IL_02f8;
																						IL_0508:
																						num5--;
																						goto end_IL_02ed;
																						IL_02f8:
																						if (3 >= b)
																						{
																							goto IL_0306;
																						}
																						goto IL_03f9;
																						IL_0306:
																						if (3 <= b)
																						{
																							goto IL_0311;
																						}
																						goto IL_0329;
																						IL_0311:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02ed;
																						IL_0329:
																						if (1 >= b)
																						{
																							goto IL_0334;
																						}
																						goto IL_038a;
																						IL_0334:
																						if (1 <= b)
																						{
																							goto IL_0342;
																						}
																						goto IL_0780;
																						IL_0342:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_035b;
																						IL_035b:
																						array[num5] = 0;
																						goto IL_0369;
																						IL_0369:
																						num5++;
																						goto IL_0377;
																						IL_0377:
																						ptr2 += 8;
																						goto end_IL_02ed;
																						IL_038a:
																						if (2 >= b)
																						{
																							goto IL_0398;
																						}
																						goto IL_0780;
																						IL_0398:
																						if (2 <= b)
																						{
																							goto IL_03a6;
																						}
																						goto IL_0780;
																						IL_03a6:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03cf;
																						IL_03cf:
																						ptr2 += 8;
																						goto IL_03dd;
																						IL_03dd:
																						num5--;
																						num = 62;
																						goto end_IL_02ed;
																						IL_03f9:
																						if (5 >= b)
																						{
																							goto IL_0407;
																						}
																						goto IL_048f;
																						IL_0407:
																						if (5 <= b)
																						{
																							goto IL_0412;
																						}
																						goto IL_046e;
																						IL_0412:
																						array[num5] = 0;
																						goto IL_0420;
																						IL_0420:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0443;
																						IL_0443:
																						array2[num5] = null;
																						goto IL_044d;
																						IL_044d:
																						num5++;
																						goto IL_045b;
																						IL_045b:
																						ptr2 += 8;
																						goto end_IL_02ed;
																						IL_046e:
																						if (4 >= b)
																						{
																							goto IL_047c;
																						}
																						goto IL_0780;
																						IL_047c:
																						if (4 <= b)
																						{
																							goto end_IL_02ed;
																						}
																						goto IL_0780;
																						IL_048f:
																						if (6 >= b)
																						{
																							goto IL_049d;
																						}
																						goto IL_0780;
																						IL_049d:
																						if (6 <= b)
																						{
																							goto IL_04ab;
																						}
																						goto IL_0780;
																						IL_04ab:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04eb;
																						IL_04eb:
																						array[num5 - 2] = 0;
																						num = 35;
																						goto IL_0508;
																						continue;
																						end_IL_02a0:
																						break;
																					}
																					continue;
																				}
																				goto IL_051b;
																				IL_073e:
																				num5--;
																				goto IL_074c;
																				IL_051b:
																				if (10 < b)
																				{
																					goto IL_0529;
																				}
																				goto IL_05b4;
																				IL_0529:
																				if (12 < b)
																				{
																					goto IL_0534;
																				}
																				goto IL_0555;
																				IL_0534:
																				if (13 >= b)
																				{
																					goto IL_0542;
																				}
																				goto IL_0780;
																				IL_0542:
																				if (13 > b)
																				{
																				}
																				goto IL_0780;
																				IL_0555:
																				if (12 <= b)
																				{
																					goto IL_0560;
																				}
																				goto IL_057c;
																				IL_0560:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ed;
																				IL_057c:
																				if (11 >= b)
																				{
																					num = 59;
																					goto IL_0593;
																				}
																				goto IL_0780;
																				IL_074c:
																				ptr2 += 8;
																				goto end_IL_02ed;
																				IL_0593:
																				if (11 <= b)
																				{
																					goto IL_05a1;
																				}
																				goto IL_0780;
																				IL_05a1:
																				num5--;
																				goto end_IL_02ed;
																				IL_05b4:
																				if (10 > b)
																				{
																					goto IL_05c2;
																				}
																				goto IL_06d6;
																				IL_05c2:
																				if (8 < b)
																				{
																					goto IL_05d0;
																				}
																				goto IL_0653;
																				IL_05d0:
																				if (9 >= b)
																				{
																					goto IL_05de;
																				}
																				goto IL_0780;
																				IL_05de:
																				if (9 <= b)
																				{
																					goto IL_05ec;
																				}
																				goto IL_0780;
																				IL_05ec:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062c;
																				IL_062c:
																				array[num5 - 2] = 0;
																				goto IL_0640;
																				IL_0640:
																				num5--;
																				goto end_IL_02ed;
																				IL_0653:
																				if (8 <= b)
																				{
																					goto IL_0661;
																				}
																				goto IL_0780;
																				IL_0661:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06c3;
																				IL_06c3:
																				num5 -= 2;
																				goto end_IL_02ed;
																				IL_06d6:
																				array[num5 - 2] = 0;
																				goto IL_06ea;
																				IL_06ea:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)GetClassLayoutTYPEATTR[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_073e;
																				continue;
																				end_IL_02ad:
																				break;
																			}
																			continue;
																		}
																		num = 42;
																		goto IL_0780;
																		continue;
																		end_IL_02bd:
																		break;
																	}
																	continue;
																}
																num = 129;
																goto IL_0780;
																IL_0780:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ed;
																continue;
																end_IL_02cd:
																break;
															}
															continue;
															end_IL_02dd:
															break;
														}
														continue;
														end_IL_02ed:
														break;
													}
													continue;
												}
												goto IL_083d;
												IL_083d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0793:
												break;
											}
											continue;
											end_IL_07a6:
											break;
										}
										continue;
										end_IL_07b0:
										break;
									}
									continue;
									end_IL_07bb:
									break;
								}
								continue;
								end_IL_07d9:
								break;
							}
							continue;
							end_IL_07f2:
							break;
						}
						continue;
						end_IL_0802:
						break;
					}
					continue;
					end_IL_0812:
					break;
				}
				continue;
				end_IL_0822:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 41;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 71;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref continuationIdNetCodeGroup.PushrgetFormatJapaneseFirstYearAsANumber);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_029b:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_027b:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_026b:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_025e:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_024e:
																											if (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_021a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														num = 126;
																														while (true)
																														{
																															if (num != 126)
																															{
																																if (num != 1107)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 16:
																																case 65:
																																	goto IL_021a;
																																case 91:
																																	goto IL_023e;
																																case 112:
																																	goto IL_024e;
																																case 89:
																																	goto IL_025e;
																																case 94:
																																	goto IL_026b;
																																case 11:
																																	goto IL_027b;
																																case 70:
																																	goto IL_028b;
																																case 103:
																																	goto IL_029b;
																																case 0:
																																	goto end_IL_029b;
																																case 14:
																																case 106:
																																	goto end_IL_02ab;
																																case 17:
																																case 28:
																																	goto IL_02c6;
																																case 72:
																																	goto IL_02da;
																																case 24:
																																	goto IL_0322;
																																case 82:
																																	goto IL_033e;
																																case 12:
																																case 51:
																																	goto IL_0349;
																																case 59:
																																	goto IL_038e;
																																case 50:
																																	goto IL_0399;
																																case 32:
																																	goto IL_03a4;
																																case 74:
																																	goto IL_03b2;
																																case 10:
																																case 31:
																																	goto IL_03c5;
																																case 33:
																																	goto IL_03ee;
																																case 66:
																																	goto IL_0405;
																																case 13:
																																	goto IL_0418;
																																case 46:
																																	goto IL_0423;
																																case 37:
																																	goto IL_0433;
																																case 23:
																																	goto IL_044a;
																																case 75:
																																case 76:
																																	goto IL_0458;
																																case 4:
																																case 100:
																																	goto IL_0474;
																																case 52:
																																	goto IL_0482;
																																case 44:
																																case 111:
																																	goto IL_0495;
																																case 20:
																																	goto IL_04d5;
																																case 55:
																																	goto IL_04e9;
																																case 113:
																																	goto IL_04fc;
																																case 85:
																																	goto IL_0510;
																																case 116:
																																	goto IL_0523;
																																case 43:
																																	goto end_IL_0207;
																																case 67:
																																	goto IL_0550;
																																case 8:
																																	goto IL_055e;
																																case 96:
																																case 117:
																																	goto IL_0571;
																																case 102:
																																	goto IL_05b1;
																																case 61:
																																	goto IL_05c5;
																																case 15:
																																	goto IL_05ef;
																																case 105:
																																	goto IL_05fd;
																																case 104:
																																	goto IL_0610;
																																case 45:
																																	goto IL_061e;
																																case 88:
																																case 109:
																																	goto IL_062c;
																																case 9:
																																	goto IL_0675;
																																case 7:
																																	goto IL_0689;
																																case 95:
																																	goto IL_06a5;
																																case 29:
																																case 36:
																																	goto IL_06b0;
																																case 108:
																																	goto IL_06bb;
																																case 3:
																																case 97:
																																	goto IL_06c6;
																																case 115:
																																	goto IL_06df;
																																case 64:
																																case 110:
																																	goto IL_06ea;
																																case 6:
																																case 21:
																																case 25:
																																case 27:
																																case 30:
																																case 34:
																																case 42:
																																case 56:
																																case 60:
																																case 62:
																																case 68:
																																case 69:
																																case 77:
																																case 78:
																																case 79:
																																case 81:
																																case 83:
																																case 86:
																																case 87:
																																case 92:
																																case 101:
																																case 114:
																																case 119:
																																	goto end_IL_023e;
																																case 53:
																																	goto IL_071d;
																																case 2:
																																	goto IL_072b;
																																case 118:
																																	goto IL_0739;
																																case 18:
																																case 19:
																																case 38:
																																case 40:
																																case 47:
																																case 54:
																																case 58:
																																case 63:
																																case 73:
																																case 80:
																																case 90:
																																case 93:
																																case 98:
																																	goto end_IL_02bb;
																																case 84:
																																	goto end_IL_0747;
																																case 71:
																																	goto end_IL_075a;
																																case 5:
																																	goto end_IL_0764;
																																case 39:
																																	goto end_IL_076f;
																																case 35:
																																	goto end_IL_078d;
																																case 26:
																																case 57:
																																	goto end_IL_07a2;
																																case 22:
																																	goto end_IL_07b2;
																																case 41:
																																	goto end_IL_07c2;
																																case 1:
																																	goto end_IL_07d2;
																																case 48:
																																	goto end_IL_07e2;
																																case 49:
																																	goto end_IL_07ed;
																																case 99:
																																case 107:
																																	goto IL_0808;
																																}
																																continue;
																															}
																															array[num5] = 0;
																															goto IL_05ef;
																															IL_05ef:
																															num5++;
																															goto IL_05fd;
																															IL_05fd:
																															ptr2 += 8;
																															goto end_IL_02bb;
																															continue;
																															end_IL_0207:
																															break;
																														}
																														break;
																													}
																													goto IL_0546;
																													continue;
																													end_IL_023e:
																													break;
																													IL_023e:;
																												}
																												break;
																											}
																											goto IL_0610;
																											IL_0689:
																											num5--;
																											num = 90;
																											goto end_IL_02bb;
																											IL_0610:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_061e;
																											IL_061e:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_062c;
																											IL_062c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 9;
																											goto IL_0675;
																											IL_0675:
																											array[num5 - 2] = 0;
																											goto IL_0689;
																										}
																										break;
																									}
																									goto IL_02c6;
																									IL_0322:
																									ptr2 += 8;
																									num = 38;
																									goto end_IL_02bb;
																									IL_02c6:
																									array[num5 - 1] = 0;
																									goto IL_02da;
																									IL_02da:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getPermissionSetNameMetadataSectionContentType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																									num = 24;
																									goto IL_0322;
																								}
																								break;
																							}
																							goto IL_06a5;
																							IL_06ea:
																							num5--;
																							goto end_IL_02bb;
																							IL_06a5:
																							if (10 < b)
																							{
																								goto IL_06b0;
																							}
																							goto IL_06df;
																							IL_06b0:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_06bb;
																							IL_06bb:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_06c6;
																							IL_06c6:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_02bb;
																							IL_06df:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_06ea;
																						}
																						break;
																					}
																					goto IL_033e;
																					IL_0550:
																					num5++;
																					goto IL_055e;
																					IL_033e:
																					if (6 <= b)
																					{
																						goto IL_0349;
																					}
																					goto IL_038e;
																					IL_0349:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04fc;
																					IL_04fc:
																					array[num5 - 2] = 0;
																					goto IL_0510;
																					IL_0510:
																					num5--;
																					goto end_IL_02bb;
																					IL_038e:
																					if (3 >= b)
																					{
																						goto IL_0399;
																					}
																					goto IL_0418;
																					IL_0399:
																					if (3 > b)
																					{
																						goto IL_03a4;
																					}
																					goto IL_03c5;
																					IL_03a4:
																					if (1 >= b)
																					{
																						goto IL_03b2;
																					}
																					goto IL_0474;
																					IL_03b2:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_0474:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0482;
																					IL_0482:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0571;
																					IL_0571:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05b1;
																					IL_05b1:
																					array[num5 - 2] = 0;
																					goto IL_05c5;
																					IL_05c5:
																					num5--;
																					num = 19;
																					goto end_IL_02bb;
																					IL_03c5:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03ee;
																					IL_03ee:
																					ptr2 += 8;
																					num = 66;
																					goto IL_0405;
																					IL_0405:
																					num5--;
																					goto end_IL_02bb;
																					IL_0418:
																					if (4 >= b)
																					{
																						goto IL_0423;
																					}
																					goto IL_0433;
																					IL_0423:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0495;
																					IL_0495:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04d5;
																					IL_04d5:
																					array[num5 - 2] = 0;
																					goto IL_04e9;
																					IL_04e9:
																					num5--;
																					goto end_IL_02bb;
																					IL_0433:
																					if (5 < b)
																					{
																						break;
																					}
																					num = 23;
																					goto IL_044a;
																					IL_055e:
																					ptr2 += 8;
																					goto end_IL_02bb;
																					IL_044a:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_0458;
																					IL_0458:
																					array[num5] = 0;
																					num = 116;
																					goto IL_0523;
																					IL_0523:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0546;
																					IL_0546:
																					array2[num5] = null;
																					goto IL_0550;
																				}
																				break;
																				IL_028b:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_071d;
																		IL_0739:
																		ptr2 += 8;
																		goto end_IL_02bb;
																		IL_072b:
																		num5++;
																		goto IL_0739;
																		IL_071d:
																		array[num5] = 0;
																		goto IL_072b;
																		continue;
																		end_IL_029b:
																		break;
																	}
																	continue;
																	end_IL_02ab:
																	break;
																}
																continue;
																end_IL_02bb:
																break;
															}
															continue;
														}
														goto IL_0808;
														IL_0808:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0747:
														break;
													}
													continue;
													end_IL_075a:
													break;
												}
												continue;
												end_IL_0764:
												break;
											}
											continue;
											end_IL_076f:
											break;
										}
										continue;
										end_IL_078d:
										break;
									}
									continue;
									end_IL_07a2:
									break;
								}
								continue;
								end_IL_07b2:
								break;
							}
							continue;
							end_IL_07c2:
							break;
						}
						continue;
						end_IL_07d2:
						break;
					}
					continue;
					end_IL_07e2:
					break;
				}
				continue;
				end_IL_07ed:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 43;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									num = 6;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConnectorPunctuationgetHashAlgorithm.PermitOnlySetInstanceDecimalDigitNumber);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_024c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_022c:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_021f:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_020f:
																							if (9 < b)
																							{
																								while (10 >= b)
																								{
																									while (10 <= b)
																									{
																										num = 111;
																										while (num != 111 && num == 1092)
																										{
																											switch (num)
																											{
																											case 76:
																												goto IL_01ec;
																											case 2:
																											case 89:
																												goto IL_01ff;
																											case 31:
																											case 75:
																												goto IL_020f;
																											case 29:
																											case 60:
																												goto IL_021f;
																											case 10:
																												goto IL_022c;
																											case 65:
																												goto IL_023c;
																											case 53:
																												goto IL_024c;
																											case 46:
																												goto end_IL_024c;
																											case 20:
																											case 57:
																												goto end_IL_025c;
																											case 47:
																												goto IL_0277;
																											case 64:
																											case 79:
																												goto IL_0285;
																											case 22:
																												goto IL_0290;
																											case 67:
																												goto IL_02a0;
																											case 61:
																												goto IL_02ae;
																											case 1:
																											case 30:
																												goto IL_02bc;
																											case 72:
																												goto IL_02df;
																											case 17:
																												goto IL_02ed;
																											case 28:
																												goto IL_02fb;
																											case 93:
																											case 96:
																												goto IL_030e;
																											case 36:
																												goto IL_034e;
																											case 12:
																												goto IL_0362;
																											case 41:
																											case 104:
																												goto IL_0375;
																											case 82:
																												goto IL_03e0;
																											case 85:
																												goto IL_03f3;
																											case 23:
																											case 35:
																												goto IL_0401;
																											case 40:
																												goto IL_041d;
																											case 3:
																											case 55:
																												goto IL_0428;
																											case 54:
																												goto IL_0436;
																											case 90:
																												goto IL_0459;
																											case 88:
																												goto IL_0463;
																											case 78:
																												goto IL_0471;
																											case 59:
																												goto IL_0484;
																											case 5:
																												goto IL_0492;
																											case 86:
																											case 98:
																												goto IL_049d;
																											case 71:
																												goto IL_04c6;
																											case 66:
																												goto IL_04d4;
																											case 21:
																												goto IL_04e7;
																											case 74:
																												goto IL_04f5;
																											case 39:
																											case 73:
																												goto IL_0503;
																											case 70:
																												goto IL_051c;
																											case 83:
																												goto IL_052a;
																											case 99:
																												goto IL_0538;
																											case 94:
																												goto IL_0548;
																											case 58:
																												goto IL_0553;
																											case 62:
																											case 77:
																												goto IL_055e;
																											case 0:
																											case 97:
																												goto IL_0573;
																											case 33:
																												goto IL_057e;
																											case 13:
																											case 14:
																											case 15:
																											case 16:
																											case 24:
																											case 25:
																											case 27:
																											case 37:
																											case 45:
																											case 49:
																											case 51:
																											case 56:
																											case 63:
																											case 69:
																											case 92:
																											case 95:
																											case 100:
																											case 101:
																												goto end_IL_01d9;
																											case 4:
																											case 8:
																											case 11:
																											case 19:
																											case 32:
																											case 44:
																											case 48:
																											case 50:
																											case 52:
																											case 81:
																											case 84:
																											case 87:
																											case 91:
																												goto end_IL_026c;
																											case 18:
																												goto end_IL_059c;
																											case 6:
																												goto end_IL_05af;
																											case 7:
																												goto end_IL_05b9;
																											case 38:
																												goto end_IL_05c4;
																											case 26:
																											case 34:
																												goto end_IL_05e2;
																											case 68:
																												goto end_IL_05f2;
																											case 9:
																											case 80:
																												goto end_IL_0602;
																											case 42:
																												goto end_IL_0612;
																											case 43:
																												goto end_IL_0622;
																											case 102:
																											case 103:
																												goto IL_063d;
																											}
																											continue;
																											end_IL_01d9:
																											break;
																										}
																										break;
																										IL_01ec:;
																									}
																									break;
																									IL_01ff:;
																								}
																								break;
																							}
																							goto IL_03f3;
																							IL_0401:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_026c;
																							IL_03f3:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0401;
																						}
																						break;
																					}
																					goto IL_0277;
																					IL_03e0:
																					num6 -= 2;
																					goto end_IL_026c;
																					IL_0277:
																					if (8 > b)
																					{
																						goto IL_0285;
																					}
																					goto IL_0375;
																					IL_0285:
																					if (6 >= b)
																					{
																						goto IL_0290;
																					}
																					goto IL_02a0;
																					IL_0290:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_030e;
																					IL_030e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_034e;
																					IL_034e:
																					array[num6 - 2] = 0;
																					goto IL_0362;
																					IL_0362:
																					num6--;
																					goto end_IL_026c;
																					IL_02a0:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_02ae;
																					IL_02ae:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_02bc;
																					IL_02bc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02df;
																					IL_02df:
																					array[num6] = 0;
																					goto IL_02ed;
																					IL_02ed:
																					num6++;
																					goto IL_02fb;
																					IL_02fb:
																					ptr2 += 8;
																					goto end_IL_026c;
																					IL_0375:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 82;
																					goto IL_03e0;
																				}
																				break;
																			}
																			goto IL_041d;
																			IL_057e:
																			if (4 <= b)
																			{
																				goto end_IL_026c;
																			}
																			break;
																			IL_041d:
																			if (5 <= b)
																			{
																				goto IL_0428;
																			}
																			goto IL_0484;
																			IL_0428:
																			array[num6] = 0;
																			goto IL_0436;
																			IL_0436:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0459;
																			IL_0459:
																			array2[num6] = null;
																			goto IL_0463;
																			IL_0463:
																			num6++;
																			goto IL_0471;
																			IL_0471:
																			ptr2 += 8;
																			goto end_IL_026c;
																			IL_0484:
																			if (2 >= b)
																			{
																				goto IL_0492;
																			}
																			goto IL_0548;
																			IL_0492:
																			if (2 <= b)
																			{
																				goto IL_049d;
																			}
																			goto IL_04e7;
																			IL_049d:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_04c6;
																			IL_04c6:
																			ptr2 += 8;
																			goto IL_04d4;
																			IL_04d4:
																			num6--;
																			goto end_IL_026c;
																			IL_04e7:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04f5;
																			IL_04f5:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0503;
																			IL_0503:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_051c;
																			IL_051c:
																			array[num6] = 0;
																			goto IL_052a;
																			IL_052a:
																			num6++;
																			goto IL_0538;
																			IL_0538:
																			ptr2 += 8;
																			goto end_IL_026c;
																			IL_0548:
																			if (3 >= b)
																			{
																				goto IL_0553;
																			}
																			goto IL_0573;
																			IL_0553:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_055e;
																			IL_055e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_026c;
																			IL_0573:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_057e;
																		}
																		break;
																		IL_023c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_026c;
																continue;
																end_IL_024c:
																break;
															}
															continue;
															end_IL_025c:
															break;
														}
														continue;
														end_IL_026c:
														break;
													}
													continue;
												}
												goto IL_063d;
												IL_063d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_059c:
												break;
											}
											continue;
											end_IL_05af:
											break;
										}
										continue;
										end_IL_05b9:
										break;
									}
									continue;
									end_IL_05c4:
									break;
								}
								continue;
								end_IL_05e2:
								break;
							}
							continue;
							end_IL_05f2:
							break;
						}
						continue;
						end_IL_0602:
						break;
					}
					continue;
					end_IL_0612:
					break;
				}
				continue;
				end_IL_0622:
				break;
			}
		}
	}

	private static int smethod_4(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 55;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsSupportedBindReferenceToAssemblyIdentity.MarshalgetModuleVersionId);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02fc:
															byte b = *ptr2;
															while (true)
															{
																IL_02ec:
																ptr2++;
																while (true)
																{
																	IL_02dc:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02bc:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_029f:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_028f:
																									if (3 <= b)
																									{
																										while (true)
																										{
																											IL_024d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_022e:
																												array[num5 - 2] = 0;
																												num = 131;
																												while (true)
																												{
																													if (num != 131)
																													{
																														if (num != 1112)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 111:
																															goto IL_022e;
																														case 75:
																														case 116:
																															goto IL_024d;
																														case 114:
																															goto IL_028f;
																														case 68:
																														case 74:
																															goto IL_029f;
																														case 28:
																															goto IL_02ac;
																														case 97:
																															goto IL_02bc;
																														case 87:
																															goto IL_02cc;
																														case 66:
																															goto IL_02dc;
																														case 85:
																															goto IL_02ec;
																														case 15:
																														case 19:
																															goto IL_02fc;
																														case 22:
																															goto IL_0307;
																														case 27:
																															goto IL_0315;
																														case 73:
																														case 92:
																															goto IL_0323;
																														case 51:
																															goto IL_0355;
																														case 69:
																															goto IL_0363;
																														case 102:
																															goto IL_0376;
																														case 53:
																															goto IL_0381;
																														case 104:
																															goto IL_0394;
																														case 90:
																															goto IL_03a2;
																														case 9:
																														case 77:
																															goto IL_03b9;
																														case 34:
																															goto IL_0427;
																														case 50:
																														case 105:
																															goto IL_043a;
																														case 95:
																															goto IL_0448;
																														case 16:
																														case 67:
																															goto IL_0456;
																														case 99:
																															goto IL_0461;
																														case 30:
																														case 42:
																															goto IL_0478;
																														case 8:
																															goto IL_0486;
																														case 29:
																															goto IL_04a9;
																														case 39:
																															goto IL_04b3;
																														case 88:
																															goto IL_04c6;
																														case 82:
																															goto IL_04d4;
																														case 3:
																														case 86:
																															goto IL_04e2;
																														case 23:
																															goto IL_04fb;
																														case 45:
																															goto IL_0509;
																														case 7:
																															goto IL_0517;
																														case 56:
																														case 65:
																															goto IL_052a;
																														case 17:
																															goto IL_056a;
																														case 44:
																															goto IL_0583;
																														case 2:
																														case 32:
																															goto IL_058e;
																														case 52:
																															goto IL_059c;
																														case 64:
																														case 79:
																															goto IL_05aa;
																														case 20:
																															goto IL_05c6;
																														case 5:
																														case 60:
																															goto IL_05d1;
																														case 100:
																														case 115:
																															goto IL_05e1;
																														case 36:
																															goto IL_05ef;
																														case 12:
																														case 98:
																															goto IL_05fd;
																														case 4:
																														case 117:
																															goto IL_0615;
																														case 118:
																															goto IL_0628;
																														case 121:
																															goto IL_063b;
																														case 122:
																															goto IL_064e;
																														case 6:
																														case 61:
																															goto IL_0659;
																														case 80:
																															goto IL_066d;
																														case 89:
																															goto IL_06b5;
																														case 1:
																														case 11:
																														case 25:
																														case 26:
																														case 31:
																														case 33:
																														case 37:
																														case 38:
																														case 46:
																														case 47:
																														case 48:
																														case 59:
																														case 63:
																														case 70:
																														case 71:
																														case 72:
																														case 83:
																														case 84:
																														case 93:
																														case 96:
																														case 112:
																														case 119:
																														case 124:
																															goto end_IL_021b;
																														case 13:
																															goto IL_06f8;
																														case 40:
																															goto IL_0706;
																														case 0:
																															goto IL_0714;
																														case 14:
																														case 24:
																														case 35:
																														case 41:
																														case 43:
																														case 57:
																														case 62:
																														case 76:
																														case 94:
																														case 103:
																														case 108:
																														case 109:
																														case 110:
																														case 120:
																														case 123:
																															goto end_IL_02ac;
																														case 49:
																															goto end_IL_0722;
																														case 113:
																															goto end_IL_0735;
																														case 106:
																															goto end_IL_073f;
																														case 78:
																															goto end_IL_074a;
																														case 107:
																															goto end_IL_075f;
																														case 21:
																														case 81:
																															goto end_IL_0774;
																														case 10:
																															goto end_IL_0784;
																														case 18:
																														case 58:
																															goto end_IL_0794;
																														case 54:
																															goto end_IL_07a4;
																														case 55:
																															goto end_IL_07b4;
																														case 91:
																														case 101:
																															goto IL_07cf;
																														}
																														continue;
																													}
																													num5--;
																													goto end_IL_02ac;
																													continue;
																													end_IL_021b:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0376;
																									IL_03b9:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0427;
																									IL_0376:
																									if (1 >= b)
																									{
																										goto IL_0381;
																									}
																									goto IL_0394;
																									IL_0381:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_0394:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_03a2;
																									IL_03a2:
																									if (2 > b)
																									{
																										break;
																									}
																									num = 77;
																									goto IL_03b9;
																									IL_0427:
																									num5 -= 2;
																									goto end_IL_02ac;
																								}
																								break;
																							}
																							goto IL_0307;
																							IL_05fd:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02ac;
																							IL_0307:
																							if (4 >= b)
																							{
																								goto IL_0315;
																							}
																							goto IL_05e1;
																							IL_0315:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0323;
																							IL_0323:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 51;
																							goto IL_0355;
																							IL_0355:
																							ptr2 += 8;
																							goto IL_0363;
																							IL_0363:
																							num5--;
																							goto end_IL_02ac;
																							IL_05e1:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_05ef;
																							IL_05ef:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_05fd;
																						}
																						goto end_IL_02cc;
																						continue;
																						end_IL_02ac:
																						break;
																						IL_02ac:;
																					}
																					break;
																				}
																				goto IL_043a;
																				IL_06b5:
																				ptr2 += 8;
																				break;
																				IL_043a:
																				if (9 >= b)
																				{
																					goto IL_0448;
																				}
																				goto IL_0583;
																				IL_0448:
																				if (9 > b)
																				{
																					goto IL_0456;
																				}
																				goto IL_052a;
																				IL_0456:
																				if (7 >= b)
																				{
																					goto IL_0461;
																				}
																				goto IL_04c6;
																				IL_0461:
																				if (7 > b)
																				{
																					goto end_IL_02cc;
																				}
																				num = 30;
																				goto IL_0478;
																				IL_0615:
																				num5--;
																				break;
																				IL_0478:
																				array[num5] = 0;
																				goto IL_0486;
																				IL_0486:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04a9;
																				IL_04a9:
																				array2[num5] = null;
																				goto IL_04b3;
																				IL_04b3:
																				num5++;
																				goto IL_0628;
																				IL_0628:
																				ptr2 += 8;
																				break;
																				IL_04c6:
																				if (8 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_04d4;
																				IL_04d4:
																				if (8 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_04e2;
																				IL_04e2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04fb;
																				IL_04fb:
																				array[num5] = 0;
																				goto IL_0509;
																				IL_0509:
																				num5++;
																				goto IL_0517;
																				IL_0517:
																				ptr2 += 8;
																				break;
																				IL_052a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_056a;
																				IL_056a:
																				array[num5 - 2] = 0;
																				goto IL_063b;
																				IL_063b:
																				num5--;
																				break;
																				IL_0583:
																				if (11 < b)
																				{
																					goto IL_058e;
																				}
																				goto IL_05c6;
																				IL_058e:
																				if (12 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_059c;
																				IL_059c:
																				if (12 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_05aa;
																				IL_05aa:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_05c6:
																				if (11 > b)
																				{
																					goto IL_05d1;
																				}
																				goto IL_0615;
																				IL_05d1:
																				if (10 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_064e;
																				IL_064e:
																				if (10 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_0659;
																				IL_0659:
																				array[num5 - 1] = 0;
																				goto IL_066d;
																				IL_066d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)RuntimeTypeCacheGetCultureInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				num = 89;
																				goto IL_06b5;
																			}
																			goto end_IL_02dc;
																			continue;
																			end_IL_02cc:
																			break;
																			IL_02cc:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06f8;
																	IL_0714:
																	ptr2 += 8;
																	break;
																	IL_0706:
																	num5++;
																	goto IL_0714;
																	IL_06f8:
																	array[num5] = 0;
																	goto IL_0706;
																	continue;
																	end_IL_02dc:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07cf;
													IL_07cf:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0722:
													break;
												}
												continue;
												end_IL_0735:
												break;
											}
											continue;
											end_IL_073f:
											break;
										}
										continue;
										end_IL_074a:
										break;
									}
									continue;
									end_IL_075f:
									break;
								}
								continue;
								end_IL_0774:
								break;
							}
							continue;
							end_IL_0784:
							break;
						}
						continue;
						end_IL_0794:
						break;
					}
					continue;
					end_IL_07a4:
					break;
				}
				continue;
				end_IL_07b4:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 15;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetOwnerMajorRevision.SignatureHelperConstructorOnTypeBuilderInstantiation);
										num = 93;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 6;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0254:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0234:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0227:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0217:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_0207:
																										if (6 < b)
																										{
																											while (true)
																											{
																												IL_01f4:
																												if (7 < b)
																												{
																													num = 113;
																													while (num != 113)
																													{
																														if (num != 1094)
																														{
																															goto IL_057b;
																														}
																														switch (num)
																														{
																														case 34:
																															goto IL_01f4;
																														case 1:
																														case 51:
																															goto IL_0207;
																														case 77:
																															goto IL_0217;
																														case 19:
																															goto IL_0227;
																														case 73:
																															goto IL_0234;
																														case 63:
																															goto IL_0244;
																														case 94:
																															goto IL_0254;
																														case 65:
																															goto end_IL_0254;
																														case 6:
																															goto end_IL_0264;
																														case 104:
																															goto end_IL_0274;
																														case 16:
																														case 70:
																															goto IL_028a;
																														case 32:
																														case 36:
																															goto IL_0298;
																														case 81:
																															goto IL_02b1;
																														case 82:
																															goto IL_02c1;
																														case 92:
																															goto IL_02d4;
																														case 3:
																														case 83:
																															goto IL_02e2;
																														case 28:
																															goto IL_0305;
																														case 13:
																															goto IL_0313;
																														case 47:
																															goto IL_0321;
																														case 0:
																														case 96:
																															goto IL_0334;
																														case 101:
																															goto IL_0374;
																														case 58:
																															goto IL_0388;
																														case 105:
																															goto IL_039b;
																														case 48:
																														case 55:
																															goto IL_03a9;
																														case 61:
																														case 91:
																															goto IL_03c5;
																														case 49:
																															goto IL_0427;
																														case 95:
																															goto IL_043a;
																														case 9:
																														case 99:
																															goto IL_0445;
																														case 22:
																															goto IL_0453;
																														case 40:
																															goto IL_0476;
																														case 44:
																															goto IL_0480;
																														case 43:
																															goto IL_048e;
																														case 52:
																															goto IL_04a1;
																														case 74:
																															goto IL_04af;
																														case 5:
																														case 41:
																															goto IL_04ba;
																														case 69:
																															goto IL_04e3;
																														case 4:
																															goto IL_04f1;
																														case 29:
																															goto IL_0504;
																														case 38:
																															goto IL_0512;
																														case 25:
																														case 86:
																															goto IL_0520;
																														case 84:
																															goto IL_0539;
																														case 75:
																															goto IL_0547;
																														case 67:
																															goto IL_0555;
																														case 12:
																														case 23:
																															goto IL_0565;
																														case 98:
																															goto IL_0570;
																														case 18:
																														case 57:
																															goto IL_057b;
																														case 7:
																															goto IL_0590;
																														case 90:
																															goto IL_059b;
																														case 2:
																														case 8:
																														case 11:
																														case 17:
																														case 21:
																														case 24:
																														case 26:
																														case 30:
																														case 31:
																														case 37:
																														case 46:
																														case 53:
																														case 54:
																														case 56:
																														case 62:
																														case 72:
																														case 80:
																														case 85:
																														case 87:
																														case 89:
																														case 102:
																															goto end_IL_01e1;
																														case 10:
																														case 33:
																														case 35:
																														case 42:
																														case 50:
																														case 59:
																														case 68:
																														case 71:
																														case 76:
																														case 79:
																														case 88:
																														case 103:
																														case 106:
																															goto end_IL_027f;
																														case 93:
																															goto end_IL_05b9;
																														case 66:
																															goto end_IL_05cc;
																														case 60:
																															goto end_IL_05d6;
																														case 78:
																															goto end_IL_05ea;
																														case 27:
																														case 100:
																															goto end_IL_05ff;
																														case 64:
																															goto end_IL_060f;
																														case 39:
																														case 97:
																															goto end_IL_061f;
																														case 14:
																															goto end_IL_062f;
																														case 15:
																															goto end_IL_063f;
																														case 20:
																														case 45:
																															goto IL_0663;
																														}
																														continue;
																														end_IL_01e1:
																														break;
																													}
																													break;
																												}
																												goto IL_02d4;
																												IL_0313:
																												num5++;
																												goto IL_0321;
																												IL_0321:
																												ptr2 += 8;
																												goto end_IL_027f;
																												IL_02d4:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_02e2;
																												IL_02e2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0305;
																												IL_0305:
																												array[num5] = 0;
																												goto IL_0313;
																											}
																											break;
																										}
																										goto IL_02b1;
																										IL_0388:
																										num5--;
																										goto end_IL_027f;
																										IL_02b1:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_0334;
																										IL_0334:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0374;
																										IL_0374:
																										array[num5 - 2] = 0;
																										goto IL_0388;
																									}
																									break;
																								}
																								goto IL_03c5;
																								IL_0427:
																								num5 -= 2;
																								goto end_IL_027f;
																								IL_03c5:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0427;
																							}
																							break;
																						}
																						goto IL_028a;
																						IL_039b:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_03a9;
																						IL_028a:
																						if (9 < b)
																						{
																							goto IL_0298;
																						}
																						goto IL_039b;
																						IL_0298:
																						if (10 < b)
																						{
																							break;
																						}
																						num = 82;
																						goto IL_02c1;
																						IL_03a9:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_027f;
																						IL_02c1:
																						if (10 <= b)
																						{
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_043a;
																				IL_059b:
																				if (4 <= b)
																				{
																					goto end_IL_027f;
																				}
																				break;
																				IL_043a:
																				if (5 <= b)
																				{
																					goto IL_0445;
																				}
																				goto IL_04a1;
																				IL_0445:
																				array[num5] = 0;
																				goto IL_0453;
																				IL_0453:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0476;
																				IL_0476:
																				array2[num5] = null;
																				goto IL_0480;
																				IL_0480:
																				num5++;
																				goto IL_048e;
																				IL_048e:
																				ptr2 += 8;
																				goto end_IL_027f;
																				IL_04a1:
																				if (2 >= b)
																				{
																					goto IL_04af;
																				}
																				goto IL_0565;
																				IL_04af:
																				if (2 <= b)
																				{
																					goto IL_04ba;
																				}
																				goto IL_0504;
																				IL_04ba:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e3;
																				IL_04e3:
																				ptr2 += 8;
																				goto IL_04f1;
																				IL_04f1:
																				num5--;
																				goto end_IL_027f;
																				IL_0504:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0512;
																				IL_0512:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0520;
																				IL_0520:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0539;
																				IL_0539:
																				array[num5] = 0;
																				goto IL_0547;
																				IL_0547:
																				num5++;
																				goto IL_0555;
																				IL_0555:
																				ptr2 += 8;
																				goto end_IL_027f;
																				IL_0565:
																				if (3 >= b)
																				{
																					goto IL_0570;
																				}
																				goto IL_0590;
																				IL_0570:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_057b;
																				IL_057b:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_027f;
																				IL_0590:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_059b;
																			}
																			break;
																			IL_0244:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_027f;
																	continue;
																	end_IL_0254:
																	break;
																}
																continue;
																end_IL_0264:
																break;
															}
															continue;
															end_IL_0274:
															break;
														}
														continue;
														end_IL_027f:
														break;
													}
													continue;
												}
												num = 45;
												goto IL_0663;
												IL_0663:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b9:
												break;
											}
											continue;
											end_IL_05cc:
											break;
										}
										continue;
										end_IL_05d6:
										break;
									}
									continue;
									end_IL_05ea:
									break;
								}
								continue;
								end_IL_05ff:
								break;
							}
							continue;
							end_IL_060f:
							break;
						}
						continue;
						end_IL_061f:
						break;
					}
					continue;
					end_IL_062f:
					break;
				}
				continue;
				end_IL_063f:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 112;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 55;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsRightToLeftExp.RightCtrlPressedFileWritableType);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025c:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_023c:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_022c:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_020c:
																									if (4 >= b)
																									{
																										num = 119;
																										while (true)
																										{
																											if (num != 119)
																											{
																												if (num != 1100)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 75:
																												case 102:
																													goto IL_020c;
																												case 4:
																													goto IL_021c;
																												case 12:
																													goto IL_022c;
																												case 25:
																													goto IL_023c;
																												case 72:
																													goto end_IL_01f9;
																												case 16:
																													goto IL_025c;
																												case 65:
																													goto end_IL_025c;
																												case 58:
																												case 90:
																													goto end_IL_026c;
																												case 45:
																													goto IL_0287;
																												case 92:
																													goto IL_0295;
																												case 2:
																												case 42:
																													goto IL_02a3;
																												case 84:
																													goto IL_02b1;
																												case 41:
																													goto IL_02d4;
																												case 5:
																													goto IL_02de;
																												case 70:
																													goto IL_02ec;
																												case 93:
																												case 95:
																													goto IL_02ff;
																												case 53:
																													goto IL_030d;
																												case 14:
																												case 32:
																													goto IL_0318;
																												case 43:
																													goto IL_0326;
																												case 39:
																												case 49:
																													goto IL_0334;
																												case 18:
																												case 76:
																													goto IL_0379;
																												case 78:
																													goto IL_03db;
																												case 33:
																												case 63:
																													goto IL_03ee;
																												case 36:
																													goto IL_03f9;
																												case 67:
																													goto IL_0409;
																												case 59:
																													goto IL_0417;
																												case 71:
																												case 96:
																													goto IL_042a;
																												case 105:
																													goto IL_044f;
																												case 62:
																													goto IL_0463;
																												case 108:
																													goto IL_047f;
																												case 54:
																													goto IL_048d;
																												case 28:
																												case 73:
																													goto IL_049b;
																												case 15:
																													goto IL_04be;
																												case 34:
																													goto IL_04cc;
																												case 100:
																													goto IL_04da;
																												case 50:
																													goto IL_0509;
																												case 27:
																												case 47:
																													goto IL_0517;
																												case 0:
																													goto IL_0522;
																												case 46:
																												case 51:
																													goto IL_0530;
																												case 44:
																													goto IL_0549;
																												case 80:
																													goto IL_0557;
																												case 11:
																													goto IL_0565;
																												case 29:
																												case 83:
																													goto IL_0578;
																												case 30:
																													goto IL_0586;
																												case 81:
																												case 86:
																													goto IL_0594;
																												case 3:
																													goto IL_05bd;
																												case 37:
																													goto IL_05cb;
																												case 8:
																												case 57:
																													goto IL_05de;
																												case 97:
																												case 103:
																													goto IL_05ff;
																												case 74:
																													goto IL_063f;
																												case 48:
																													goto IL_0653;
																												case 9:
																												case 17:
																												case 20:
																												case 21:
																												case 22:
																												case 23:
																												case 24:
																												case 26:
																												case 38:
																												case 56:
																												case 60:
																												case 66:
																												case 68:
																												case 82:
																												case 85:
																												case 91:
																												case 94:
																												case 101:
																												case 107:
																													goto end_IL_024c;
																												case 1:
																												case 10:
																												case 13:
																												case 40:
																												case 52:
																												case 69:
																												case 77:
																												case 79:
																												case 87:
																												case 89:
																												case 99:
																												case 104:
																												case 106:
																												case 109:
																													goto end_IL_027c;
																												case 98:
																													goto end_IL_067f;
																												case 64:
																													goto end_IL_0692;
																												case 88:
																													goto end_IL_069c;
																												case 55:
																													goto end_IL_06a7;
																												case 35:
																												case 61:
																													goto end_IL_06bc;
																												case 7:
																													goto end_IL_06cc;
																												case 6:
																												case 31:
																													goto end_IL_06e5;
																												case 111:
																													goto end_IL_06f5;
																												case 112:
																													goto end_IL_0705;
																												case 19:
																												case 110:
																													goto IL_0720;
																												}
																												continue;
																											}
																											if (4 > b)
																											{
																												goto end_IL_024c;
																											}
																											goto end_IL_027c;
																											continue;
																											end_IL_01f9:
																											break;
																										}
																										break;
																									}
																									goto IL_0287;
																									IL_02de:
																									num5++;
																									goto IL_02ec;
																									IL_02ec:
																									ptr2 += 8;
																									goto end_IL_027c;
																									IL_0287:
																									if (5 < b)
																									{
																										goto end_IL_024c;
																									}
																									goto IL_0295;
																									IL_0295:
																									if (5 > b)
																									{
																										goto end_IL_024c;
																									}
																									goto IL_02a3;
																									IL_02a3:
																									array[num5] = 0;
																									goto IL_02b1;
																									IL_02b1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_02d4;
																									IL_02d4:
																									array2[num5] = null;
																									goto IL_02de;
																								}
																								break;
																							}
																							goto IL_0509;
																							IL_05de:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_027c;
																							IL_0509:
																							if (3 > b)
																							{
																								goto IL_0517;
																							}
																							goto IL_05de;
																							IL_0517:
																							if (1 >= b)
																							{
																								goto IL_0522;
																							}
																							goto IL_0578;
																							IL_0522:
																							if (1 > b)
																							{
																								goto end_IL_024c;
																							}
																							goto IL_0530;
																							IL_0530:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0549;
																							IL_0549:
																							array[num5] = 0;
																							goto IL_0557;
																							IL_0557:
																							num5++;
																							goto IL_0565;
																							IL_0565:
																							ptr2 += 8;
																							goto end_IL_027c;
																							IL_0578:
																							if (2 < b)
																							{
																								goto end_IL_024c;
																							}
																							goto IL_0586;
																							IL_0586:
																							if (2 > b)
																							{
																								goto end_IL_024c;
																							}
																							goto IL_0594;
																							IL_0594:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05bd;
																							IL_05bd:
																							ptr2 += 8;
																							goto IL_05cb;
																							IL_05cb:
																							num5--;
																							goto end_IL_027c;
																						}
																						break;
																					}
																					num = 97;
																					goto IL_05ff;
																					IL_063f:
																					array[num5 - 2] = 0;
																					goto IL_0653;
																					IL_0653:
																					num5--;
																					goto end_IL_027c;
																					IL_05ff:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_063f;
																				}
																				break;
																			}
																			goto IL_02ff;
																			IL_0417:
																			if (11 <= b)
																			{
																			}
																			goto end_IL_024c;
																			IL_02ff:
																			if (9 >= b)
																			{
																				goto IL_030d;
																			}
																			goto IL_03ee;
																			IL_030d:
																			if (9 > b)
																			{
																				goto IL_0318;
																			}
																			goto IL_0379;
																			IL_0318:
																			if (7 >= b)
																			{
																				goto IL_0326;
																			}
																			goto IL_047f;
																			IL_0326:
																			if (7 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_0334;
																			IL_0334:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_044f;
																			IL_044f:
																			array[num5 - 2] = 0;
																			goto IL_0463;
																			IL_0463:
																			num5--;
																			num = 13;
																			goto end_IL_027c;
																			IL_047f:
																			if (8 < b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_048d;
																			IL_048d:
																			if (8 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_049b;
																			IL_049b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04be;
																			IL_04be:
																			array[num5] = 0;
																			goto IL_04cc;
																			IL_04cc:
																			num5++;
																			goto IL_04da;
																			IL_04da:
																			ptr2 += 8;
																			num = 89;
																			goto end_IL_027c;
																			IL_0379:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03db;
																			IL_03db:
																			num5 -= 2;
																			goto end_IL_027c;
																			IL_03ee:
																			if (10 >= b)
																			{
																				goto IL_03f9;
																			}
																			goto IL_0409;
																			IL_03f9:
																			if (10 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_042a;
																			IL_042a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 87;
																			goto end_IL_027c;
																			IL_0409:
																			if (11 < b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_0417;
																		}
																		continue;
																		end_IL_024c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 79;
																goto end_IL_027c;
																continue;
																end_IL_025c:
																break;
															}
															continue;
															end_IL_026c:
															break;
														}
														continue;
														end_IL_027c:
														break;
													}
													continue;
												}
												goto IL_0720;
												IL_0720:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067f:
												break;
											}
											continue;
											end_IL_0692:
											break;
										}
										continue;
										end_IL_069c:
										break;
									}
									continue;
									end_IL_06a7:
									break;
								}
								continue;
								end_IL_06bc:
								break;
							}
							continue;
							end_IL_06cc:
							break;
						}
						continue;
						end_IL_06e5:
						break;
					}
					continue;
					end_IL_06f5:
					break;
				}
				continue;
				end_IL_0705:
				break;
			}
		}
	}
}
