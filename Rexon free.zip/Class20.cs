using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion.Gameplay;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Ropes Down", "World", "Moves ropes downward.", false, 27, ModType.const_0, false)]
internal class Class20 : MonoBehaviour
{
	internal sealed class _003CRopeCoroutine_003Ed__7 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		public Class20 class20_0;

		private float float_0;

		private static IntPtr[] LongToStringSetter;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		public _003CRopeCoroutine_003Ed__7(int _003C_003E1__state)
		{
			object obj = this;
			((_003CRopeCoroutine_003Ed__7)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 64;
			object[] array2 = default(object[]);
			int num4 = default(int);
			object[] array3 = default(object[]);
			byte* ptr = default(byte*);
			long[] array4 = default(long[]);
			byte* ptr2 = default(byte*);
			int num5 = default(int);
			byte b = default(byte);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						num = 72;
						while (true)
						{
							if (num != 72)
							{
								if (num != 1053)
								{
									break;
								}
								switch (num)
								{
								case 40:
								case 42:
									goto end_IL_012f;
								case 63:
									goto end_IL_013f;
								case 64:
									goto end_IL_0158;
								case 13:
								case 60:
									goto IL_018a;
								case 5:
									goto IL_0198;
								case 43:
									goto IL_01a6;
								case 51:
									goto IL_01b4;
								case 20:
									goto IL_01bd;
								case 6:
								case 17:
								case 19:
								case 23:
								case 28:
								case 54:
								case 58:
									goto IL_01c5;
								case 24:
									goto IL_01d5;
								case 59:
									goto IL_01de;
								case 35:
									goto IL_01e7;
								case 32:
									goto IL_01f5;
								case 49:
									goto IL_0203;
								case 44:
									goto IL_0211;
								case 62:
									goto IL_021f;
								case 46:
									goto IL_022a;
								case 1:
								case 41:
									goto IL_0238;
								case 21:
									goto IL_0266;
								case 3:
									goto IL_0279;
								case 57:
									goto IL_0287;
								case 26:
								case 29:
									goto IL_0295;
								case 18:
									goto IL_02b1;
								case 7:
								case 8:
									goto IL_02c8;
								case 12:
								case 15:
									goto IL_02d3;
								case 0:
									goto IL_02de;
								case 33:
								case 56:
									goto IL_02ec;
								case 11:
									goto IL_0305;
								case 25:
									goto IL_0313;
								case 4:
									goto IL_0321;
								case 38:
									goto IL_0342;
								case 34:
									goto IL_0355;
								case 9:
									goto IL_0363;
								case 10:
									goto IL_0371;
								case 48:
								case 55:
									goto IL_038d;
								case 36:
									goto IL_03cd;
								case 65:
									goto IL_03e1;
								case 2:
								case 14:
								case 22:
								case 27:
								case 30:
								case 31:
								case 37:
								case 39:
								case 45:
								case 47:
								case 52:
								case 53:
								case 61:
									goto IL_03f4;
								case 16:
								case 50:
									return;
								}
								continue;
							}
							array2 = new object[3];
							num = 13;
							goto IL_018a;
							IL_03e1:
							num4--;
							goto IL_01c5;
							IL_0355:
							array[num4] = 5;
							goto IL_0363;
							IL_03f4:
							array2[num4] = array3[*(int*)(ptr + num3)];
							goto IL_0355;
							IL_018a:
							array4 = new long[3];
							goto IL_0198;
							IL_0198:
							array3 = new object[1];
							goto IL_01a6;
							IL_01a6:
							array3[0] = this;
							goto IL_01b4;
							IL_01b4:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsMethodDefgetKeyAvailable.getIsReadyHasInfo);
							goto IL_01bd;
							IL_01bd:
							ptr = ptr2;
							goto IL_01c5;
							IL_01c5:
							if (num5 == 1)
							{
								return;
							}
							goto IL_01d5;
							IL_01d5:
							num = 59;
							goto IL_01de;
							IL_01de:
							b = *ptr;
							goto IL_01e7;
							IL_01e7:
							ptr++;
							goto IL_01f5;
							IL_01f5:
							if (b >= 1)
							{
								goto IL_0203;
							}
							goto IL_03f4;
							IL_0203:
							if (b <= 5)
							{
								goto IL_0211;
							}
							goto IL_03f4;
							IL_0211:
							if (3 < b)
							{
								goto IL_021f;
							}
							goto IL_02b1;
							IL_021f:
							if (4 >= b)
							{
								goto IL_022a;
							}
							goto IL_0279;
							IL_022a:
							if (4 <= b)
							{
								goto IL_0238;
							}
							goto IL_03f4;
							IL_0238:
							((_003CRopeCoroutine_003Ed__7)array2[num4 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0266;
							IL_0266:
							num4 -= 2;
							goto IL_01c5;
							IL_0279:
							if (5 >= b)
							{
								goto IL_0287;
							}
							goto IL_03f4;
							IL_0287:
							if (5 <= b)
							{
								goto IL_0295;
							}
							goto IL_03f4;
							IL_0295:
							byte* num6 = ptr;
							num5 = 1;
							ptr = num6 + -200;
							goto IL_01c5;
							IL_02b1:
							if (3 > b)
							{
								num = 8;
								goto IL_02c8;
							}
							goto IL_038d;
							IL_0363:
							num4++;
							goto IL_0371;
							IL_02c8:
							if (1 < b)
							{
								goto IL_02d3;
							}
							goto IL_0342;
							IL_02d3:
							if (2 >= b)
							{
								goto IL_02de;
							}
							num = 14;
							goto IL_03f4;
							IL_02de:
							if (2 <= b)
							{
								goto IL_02ec;
							}
							goto IL_03f4;
							IL_02ec:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
							goto IL_0305;
							IL_0305:
							array[num4] = 0;
							goto IL_0313;
							IL_0313:
							num4++;
							goto IL_0321;
							IL_0321:
							ptr += 8;
							goto IL_01c5;
							IL_0371:
							ptr += 8;
							num = 28;
							goto IL_01c5;
							IL_0342:
							if (1 > b)
							{
							}
							goto IL_03f4;
							IL_038d:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_03cd;
							IL_03cd:
							array[num4 - 2] = 0;
							goto IL_03e1;
							continue;
							end_IL_012f:
							break;
						}
						continue;
						end_IL_013f:
						break;
					}
					continue;
					end_IL_0158:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			int num = 214;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				num = 213;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[5];
						while (true)
						{
							object[] array2 = new object[5];
							num = 284;
							while (true)
							{
								int[] array3 = new int[1];
								num = 355;
								while (true)
								{
									long[] array4 = new long[5];
									while (true)
									{
										object[] array5 = new object[3];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CollectFromServerContextEnumNestedTypes.AnnotationHeader);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0810:
																byte b = *ptr2;
																while (true)
																{
																	IL_0800:
																	ptr2++;
																	while (true)
																	{
																		IL_07ed:
																		if (b >= 1)
																		{
																			num = 51;
																			while (b <= 53)
																			{
																				num = 236;
																				while (true)
																				{
																					IL_07ca:
																					if (27 >= b)
																					{
																						while (true)
																						{
																							IL_07bd:
																							if (27 > b)
																							{
																								while (true)
																								{
																									IL_07ad:
																									if (13 >= b)
																									{
																										while (true)
																										{
																											IL_079d:
																											if (13 <= b)
																											{
																												while (true)
																												{
																													IL_0747:
																													ptr2 = (((array2[num5 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													while (true)
																													{
																														IL_072e:
																														num5--;
																														num = 444;
																														while (num != 444)
																														{
																															if (num != 1425)
																															{
																																goto IL_1127;
																															}
																															switch (num)
																															{
																															case 407:
																																goto IL_072e;
																															case 148:
																															case 239:
																																goto IL_0747;
																															case 78:
																																goto IL_079d;
																															case 343:
																																goto IL_07ad;
																															case 417:
																																goto IL_07bd;
																															case 236:
																																goto IL_07ca;
																															case 51:
																																goto IL_07da;
																															case 158:
																																goto IL_07ed;
																															case 128:
																																goto IL_0800;
																															case 319:
																															case 414:
																																goto IL_0810;
																															case 145:
																															case 198:
																																goto IL_081b;
																															case 243:
																																goto IL_0848;
																															case 25:
																																goto IL_085b;
																															case 188:
																																goto IL_0869;
																															case 337:
																															case 383:
																																goto IL_0874;
																															case 117:
																																goto IL_0882;
																															case 118:
																																goto IL_08a5;
																															case 116:
																																goto IL_08af;
																															case 296:
																																goto IL_08bd;
																															case 55:
																																goto IL_08d0;
																															case 322:
																																goto IL_08de;
																															case 248:
																																goto IL_08ec;
																															case 149:
																																goto IL_08fa;
																															case 216:
																																goto IL_0908;
																															case 43:
																															case 177:
																																goto IL_091f;
																															case 67:
																																goto IL_095d;
																															case 419:
																																goto IL_097a;
																															case 75:
																																goto IL_098d;
																															case 138:
																															case 318:
																																goto IL_099b;
																															case 366:
																																goto IL_09b3;
																															case 143:
																																goto IL_09c1;
																															case 425:
																																goto IL_09cf;
																															case 263:
																															case 385:
																																goto IL_09eb;
																															case 135:
																																goto IL_0a14;
																															case 406:
																																goto IL_0a22;
																															case 72:
																																goto IL_0a35;
																															case 415:
																																goto IL_0a40;
																															case 228:
																															case 418:
																																goto IL_0a4e;
																															case 371:
																																goto IL_0a8f;
																															case 28:
																																goto IL_0aa3;
																															case 293:
																																goto IL_0ab6;
																															case 353:
																																goto IL_0ac4;
																															case 127:
																															case 325:
																																goto IL_0ad2;
																															case 173:
																																goto IL_0af0;
																															case 119:
																																goto IL_0afe;
																															case 242:
																																goto IL_0b11;
																															case 33:
																																goto IL_0b1f;
																															case 346:
																															case 432:
																																goto IL_0b2a;
																															case 280:
																																goto IL_0b46;
																															case 157:
																																goto IL_0b54;
																															case 91:
																															case 95:
																																goto IL_0b62;
																															case 81:
																																goto IL_0be0;
																															case 396:
																																goto IL_0bf3;
																															case 363:
																																goto IL_0c01;
																															case 217:
																															case 254:
																																goto IL_0c0f;
																															case 333:
																																goto IL_0c28;
																															case 300:
																																goto IL_0c36;
																															case 229:
																																goto IL_0c44;
																															case 176:
																																goto IL_0c57;
																															case 101:
																																goto IL_0c65;
																															case 112:
																															case 389:
																																goto IL_0c70;
																															case 201:
																																goto IL_0c7e;
																															case 352:
																																goto IL_0c96;
																															case 274:
																																goto IL_0ca4;
																															case 18:
																																goto IL_0cb7;
																															case 330:
																																goto IL_0cc5;
																															case 16:
																															case 73:
																																goto IL_0cdc;
																															case 232:
																																goto IL_0d0a;
																															case 430:
																																goto IL_0d1d;
																															case 22:
																																goto IL_0d2b;
																															case 187:
																															case 421:
																																goto IL_0d39;
																															case 12:
																																goto IL_0d71;
																															case 227:
																																goto IL_0d8e;
																															case 137:
																																goto IL_0da1;
																															case 373:
																																goto IL_0daf;
																															case 249:
																															case 386:
																																goto IL_0dba;
																															case 184:
																																goto IL_0de7;
																															case 265:
																																goto IL_0dfa;
																															case 69:
																																goto IL_0e08;
																															case 224:
																															case 399:
																																goto IL_0e13;
																															case 109:
																																goto IL_0e3d;
																															case 354:
																																goto IL_0e56;
																															case 183:
																																goto IL_0e61;
																															case 21:
																															case 99:
																																goto IL_0e6f;
																															case 6:
																																goto IL_0e7d;
																															case 431:
																																goto IL_0e9b;
																															case 359:
																																goto IL_0ea9;
																															case 113:
																																goto IL_0ebc;
																															case 159:
																																goto IL_0eca;
																															case 94:
																															case 314:
																																goto IL_0ed8;
																															case 303:
																																goto IL_0f05;
																															case 334:
																																goto IL_0f18;
																															case 74:
																																goto IL_0f26;
																															case 102:
																															case 350:
																																goto IL_0f31;
																															case 11:
																																goto IL_0f4b;
																															case 347:
																																goto IL_0f59;
																															case 53:
																																goto IL_0f67;
																															case 372:
																																goto IL_0f7a;
																															case 31:
																																goto IL_0f88;
																															case 35:
																															case 191:
																																goto IL_0f96;
																															case 100:
																																goto IL_0ff5;
																															case 189:
																																goto IL_1011;
																															case 49:
																																goto IL_101f;
																															case 327:
																															case 335:
																																goto IL_102d;
																															case 382:
																																goto IL_1041;
																															case 144:
																																goto IL_107a;
																															case 203:
																																goto IL_108d;
																															case 272:
																																goto IL_109b;
																															case 294:
																															case 394:
																																goto IL_10a6;
																															case 156:
																																goto IL_10b0;
																															case 253:
																																goto IL_10c7;
																															case 237:
																																goto IL_10da;
																															case 154:
																																goto IL_10e5;
																															case 14:
																															case 316:
																																goto IL_10f3;
																															case 380:
																																goto IL_110b;
																															case 344:
																																goto IL_1119;
																															case 328:
																															case 341:
																																goto IL_1127;
																															case 218:
																																goto IL_115f;
																															case 233:
																																goto IL_1173;
																															case 246:
																																goto IL_1186;
																															case 199:
																																goto IL_1194;
																															case 221:
																																goto IL_11a2;
																															case 351:
																																goto IL_11b0;
																															case 153:
																															case 226:
																																goto IL_11be;
																															case 206:
																																goto IL_11d2;
																															case 132:
																																goto IL_121f;
																															case 424:
																																goto IL_122d;
																															case 125:
																															case 266:
																																goto IL_1249;
																															case 290:
																																goto IL_129b;
																															case 411:
																																goto IL_12b7;
																															case 301:
																																goto IL_12c5;
																															case 139:
																															case 223:
																																goto IL_12d3;
																															case 361:
																																goto IL_130c;
																															case 56:
																																goto IL_1320;
																															case 336:
																																goto IL_1333;
																															case 36:
																																goto IL_1341;
																															case 185:
																																goto IL_134f;
																															case 39:
																																goto IL_135d;
																															case 131:
																															case 162:
																																goto IL_1368;
																															case 180:
																																goto IL_13ca;
																															case 277:
																																goto IL_13dd;
																															case 7:
																																goto IL_13eb;
																															case 136:
																															case 395:
																																goto IL_13f6;
																															case 278:
																																goto IL_1404;
																															case 362:
																																goto IL_1428;
																															case 121:
																																goto IL_1436;
																															case 186:
																																goto IL_1449;
																															case 257:
																																goto IL_1454;
																															case 168:
																															case 403:
																																goto IL_1462;
																															case 270:
																																goto IL_1470;
																															case 305:
																																goto IL_1494;
																															case 17:
																																goto IL_14a2;
																															case 256:
																																goto IL_14b5;
																															case 342:
																																goto IL_14c3;
																															case 174:
																															case 298:
																																goto IL_14d1;
																															case 84:
																																goto IL_14ff;
																															case 62:
																																goto IL_1512;
																															case 244:
																																goto IL_151d;
																															case 234:
																															case 404:
																																goto IL_152b;
																															case 377:
																																goto IL_1569;
																															case 269:
																																goto IL_157d;
																															case 146:
																																goto IL_1590;
																															case 387:
																																goto IL_159e;
																															case 281:
																															case 357:
																																goto IL_15ac;
																															case 115:
																																goto IL_15ec;
																															case 196:
																																goto IL_1600;
																															case 326:
																																goto IL_1613;
																															case 34:
																																goto IL_1621;
																															case 71:
																																goto IL_162f;
																															case 23:
																															case 329:
																																goto IL_163a;
																															case 320:
																																goto IL_1662;
																															case 87:
																																goto IL_1675;
																															case 321:
																																goto IL_1683;
																															case 402:
																															case 423:
																																goto IL_1691;
																															case 93:
																																goto IL_16e2;
																															case 302:
																																goto IL_16f0;
																															case 64:
																																goto IL_1703;
																															case 129:
																																goto IL_1711;
																															case 308:
																															case 375:
																																goto IL_171f;
																															case 3:
																																goto IL_175f;
																															case 179:
																																goto IL_1773;
																															case 192:
																																goto IL_178f;
																															case 120:
																															case 204:
																																goto IL_179d;
																															case 306:
																																goto IL_17ba;
																															case 141:
																																goto IL_181d;
																															case 250:
																																goto IL_182b;
																															case 313:
																																goto IL_183e;
																															case 76:
																																goto IL_1849;
																															case 48:
																															case 405:
																																goto IL_1857;
																															case 310:
																																goto IL_1865;
																															case 391:
																																goto IL_1889;
																															case 279:
																																goto IL_1897;
																															case 288:
																																goto IL_18aa;
																															case 289:
																																goto IL_18b8;
																															case 42:
																															case 103:
																																goto IL_18c6;
																															case 211:
																																goto IL_18f4;
																															case 47:
																															case 367:
																																goto IL_1907;
																															case 161:
																																goto IL_1945;
																															case 215:
																																goto IL_1959;
																															case 96:
																																goto IL_196c;
																															case 155:
																																goto IL_197a;
																															case 147:
																															case 285:
																																goto IL_1985;
																															case 428:
																																goto IL_19c3;
																															case 45:
																																goto IL_19d1;
																															case 210:
																																goto IL_19e4;
																															case 37:
																																goto IL_19f2;
																															case 152:
																															case 412:
																																goto IL_19fd;
																															case 317:
																																goto IL_1a35;
																															case 193:
																																goto IL_1a49;
																															case 61:
																																goto IL_1a5c;
																															case 309:
																																goto IL_1a67;
																															case 261:
																															case 365:
																																goto IL_1a75;
																															case 41:
																																goto IL_1ab5;
																															case 85:
																																goto IL_1ac9;
																															case 50:
																																goto IL_1adc;
																															case 134:
																																goto IL_1aea;
																															case 295:
																															case 384:
																																goto IL_1af8;
																															case 111:
																																goto IL_1b5a;
																															case 108:
																																goto IL_1b6d;
																															case 392:
																																goto IL_1b7b;
																															case 150:
																															case 388:
																																goto IL_1b86;
																															case 235:
																																goto IL_1b9a;
																															case 20:
																																goto IL_1bd8;
																															case 401:
																																goto IL_1beb;
																															case 38:
																																goto IL_1c02;
																															case 175:
																															case 258:
																																goto IL_1c10;
																															case 241:
																																goto IL_1c4d;
																															case 24:
																																goto IL_1c5b;
																															case 219:
																																goto IL_1c6e;
																															case 247:
																																goto IL_1c7c;
																															case 140:
																															case 209:
																																goto IL_1c8a;
																															case 77:
																																goto IL_1cf8;
																															case 63:
																																goto IL_1d0b;
																															case 299:
																																goto IL_1d19;
																															case 323:
																															case 348:
																																goto IL_1d24;
																															case 378:
																																goto IL_1d3b;
																															case 165:
																																goto IL_1d53;
																															case 59:
																																goto IL_1d6a;
																															case 205:
																																goto IL_1d7d;
																															case 292:
																																goto IL_1d88;
																															case 195:
																															case 200:
																																goto IL_1d96;
																															case 29:
																																goto IL_1daa;
																															case 207:
																																goto IL_1de2;
																															case 422:
																																goto IL_1df5;
																															case 169:
																																goto IL_1e0c;
																															case 66:
																															case 97:
																																goto IL_1e1a;
																															case 106:
																																goto IL_1e38;
																															case 434:
																																goto IL_1e46;
																															case 166:
																																goto IL_1e59;
																															case 238:
																																goto IL_1e70;
																															case 171:
																															case 339:
																																goto IL_1e7b;
																															case 86:
																																goto IL_1ea4;
																															case 360:
																																goto IL_1eb2;
																															case 0:
																																goto IL_1ec5;
																															case 172:
																																goto IL_1ed3;
																															case 368:
																															case 426:
																																goto IL_1ee1;
																															case 332:
																																goto IL_1ef5;
																															case 10:
																																goto IL_1f42;
																															case 142:
																																goto IL_1f50;
																															case 393:
																																goto IL_1f60;
																															case 398:
																																goto IL_1f6b;
																															case 1:
																															case 2:
																															case 5:
																															case 19:
																															case 32:
																															case 40:
																															case 44:
																															case 46:
																															case 57:
																															case 60:
																															case 65:
																															case 68:
																															case 80:
																															case 82:
																															case 88:
																															case 89:
																															case 90:
																															case 92:
																															case 98:
																															case 105:
																															case 107:
																															case 110:
																															case 122:
																															case 124:
																															case 130:
																															case 133:
																															case 160:
																															case 163:
																															case 167:
																															case 170:
																															case 178:
																															case 190:
																															case 197:
																															case 202:
																															case 220:
																															case 225:
																															case 252:
																															case 255:
																															case 260:
																															case 268:
																															case 271:
																															case 282:
																															case 283:
																															case 312:
																															case 315:
																															case 338:
																															case 356:
																															case 358:
																															case 370:
																															case 374:
																															case 381:
																															case 408:
																															case 409:
																															case 410:
																															case 429:
																															case 436:
																																goto end_IL_07da;
																															case 4:
																															case 8:
																															case 13:
																															case 26:
																															case 30:
																															case 52:
																															case 54:
																															case 58:
																															case 70:
																															case 79:
																															case 83:
																															case 104:
																															case 114:
																															case 123:
																															case 151:
																															case 181:
																															case 182:
																															case 194:
																															case 208:
																															case 212:
																															case 222:
																															case 230:
																															case 231:
																															case 240:
																															case 245:
																															case 251:
																															case 259:
																															case 262:
																															case 264:
																															case 267:
																															case 273:
																															case 275:
																															case 286:
																															case 287:
																															case 291:
																															case 297:
																															case 304:
																															case 307:
																															case 311:
																															case 340:
																															case 345:
																															case 349:
																															case 364:
																															case 369:
																															case 376:
																															case 379:
																															case 390:
																															case 397:
																															case 400:
																															case 413:
																															case 416:
																															case 420:
																															case 427:
																															case 433:
																																goto end_IL_071b;
																															case 435:
																																goto end_IL_1f89;
																															case 27:
																																goto end_IL_1f9c;
																															case 15:
																																goto end_IL_1fa6;
																															case 331:
																																goto end_IL_1fb1;
																															case 355:
																																goto end_IL_1fc1;
																															case 164:
																															case 284:
																																goto end_IL_1fd1;
																															case 126:
																																goto end_IL_1fe1;
																															case 324:
																															case 437:
																																goto end_IL_1ffa;
																															case 213:
																																goto end_IL_2013;
																															case 214:
																																goto end_IL_2023;
																															case 9:
																															case 276:
																																goto IL_2047;
																															}
																															continue;
																															end_IL_071b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_085b;
																											IL_0d2b:
																											if (12 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0d39;
																											IL_085b:
																											if (6 >= b)
																											{
																												goto IL_0869;
																											}
																											goto IL_0b11;
																											IL_0869:
																											if (6 <= b)
																											{
																												goto IL_0874;
																											}
																											goto IL_08d0;
																											IL_0874:
																											array[num5] = 0;
																											goto IL_0882;
																											IL_0882:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_08a5;
																											IL_08a5:
																											array2[num5] = null;
																											goto IL_08af;
																											IL_08af:
																											num5++;
																											goto IL_08bd;
																											IL_08bd:
																											ptr2 += 8;
																											break;
																											IL_08d0:
																											if (3 >= b)
																											{
																												goto IL_08de;
																											}
																											goto IL_0a35;
																											IL_08de:
																											if (3 > b)
																											{
																												goto IL_08ec;
																											}
																											num = 263;
																											goto IL_09eb;
																											IL_08ec:
																											if (1 < b)
																											{
																												goto IL_08fa;
																											}
																											goto IL_098d;
																											IL_08fa:
																											if (2 < b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0908;
																											IL_0908:
																											if (2 > b)
																											{
																												goto end_IL_07da;
																											}
																											num = 177;
																											goto IL_091f;
																											IL_0d71:
																											array[num5 - 1] = 5;
																											num = 227;
																											goto IL_0d8e;
																											IL_091f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CRopeCoroutine_003Ed__7, int>)LongToStringSetter[*(int*)(ptr2 + num3)])((_003CRopeCoroutine_003Ed__7)array2[num5 - 1]);
																											goto IL_095d;
																											IL_095d:
																											array[num5 - 1] = 0;
																											num = 419;
																											goto IL_097a;
																											IL_097a:
																											ptr2 += 8;
																											break;
																											IL_098d:
																											if (1 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_099b;
																											IL_099b:
																											array2[num5] = array5[*(int*)(ptr2 + num3)];
																											goto IL_09b3;
																											IL_09b3:
																											array[num5] = 5;
																											goto IL_09c1;
																											IL_09c1:
																											num5++;
																											goto IL_09cf;
																											IL_09cf:
																											ptr2 += 8;
																											break;
																											IL_0d39:
																											array2[num5 - 1] = ((delegate*<Class20, GorillaRopeSwing[]>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																											goto IL_0d71;
																											IL_09eb:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0a14;
																											IL_0a14:
																											ptr2 += 8;
																											goto IL_0a22;
																											IL_0a22:
																											num5--;
																											break;
																											IL_0a35:
																											if (4 >= b)
																											{
																												goto IL_0a40;
																											}
																											goto IL_0ab6;
																											IL_0a40:
																											if (4 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0a4e;
																											IL_0a4e:
																											array2[num5 - 1] = ((delegate*<_003CRopeCoroutine_003Ed__7, Class20>)LongToStringSetter[*(int*)(ptr2 + num3)])((_003CRopeCoroutine_003Ed__7)array2[num5 - 1]);
																											num = 371;
																											goto IL_0a8f;
																											IL_0a8f:
																											array[num5 - 1] = 5;
																											goto IL_0aa3;
																											IL_0aa3:
																											ptr2 += 8;
																											break;
																											IL_0ab6:
																											if (5 < b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0ac4;
																											IL_0ac4:
																											if (5 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0ad2;
																											IL_0ad2:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_0af0;
																											IL_0af0:
																											ptr2 += 8;
																											goto IL_0afe;
																											IL_0afe:
																											num5--;
																											break;
																											IL_0b11:
																											if (9 >= b)
																											{
																												goto IL_0b1f;
																											}
																											goto IL_0c57;
																											IL_0b1f:
																											if (9 <= b)
																											{
																												goto IL_0b2a;
																											}
																											goto IL_0b46;
																											IL_0b2a:
																											byte* num6 = ptr2;
																											num4 = 1;
																											ptr2 = num6 + -200;
																											break;
																											IL_0b46:
																											if (7 >= b)
																											{
																												goto IL_0b54;
																											}
																											goto IL_0bf3;
																											IL_0b54:
																											if (7 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0b62;
																											IL_0b62:
																											ptr2 = ptr + *(int*)(ptr2 + (*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) - (*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) - *(int*)(ptr2 + num3)) * (((uint)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) > (uint)(*(int*)(ptr2 + num3) - 1)) ? 1 : 0) + 1) * 8 + num3);
																											goto IL_0be0;
																											IL_0be0:
																											num5--;
																											break;
																											IL_0bf3:
																											if (8 < b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0c01;
																											IL_0c01:
																											if (8 > b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0c0f;
																											IL_0c0f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0c28;
																											IL_0c28:
																											array[num5] = 0;
																											goto IL_0c36;
																											IL_0c36:
																											num5++;
																											goto IL_0c44;
																											IL_0c44:
																											ptr2 += 8;
																											break;
																											IL_0c57:
																											if (11 >= b)
																											{
																												goto IL_0c65;
																											}
																											goto IL_0d1d;
																											IL_0c65:
																											if (11 <= b)
																											{
																												goto IL_0c70;
																											}
																											goto IL_0cb7;
																											IL_0c70:
																											array[num5] = 5;
																											goto IL_0c7e;
																											IL_0c7e:
																											array2[num5] = array5[*(int*)(ptr2 + num3)];
																											goto IL_0c96;
																											IL_0c96:
																											num5++;
																											goto IL_0ca4;
																											IL_0ca4:
																											ptr2 += 8;
																											break;
																											IL_0cb7:
																											if (10 < b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0cc5;
																											IL_0cc5:
																											if (10 > b)
																											{
																												goto end_IL_07da;
																											}
																											num = 16;
																											goto IL_0cdc;
																											IL_0d8e:
																											ptr2 += 8;
																											break;
																											IL_0cdc:
																											((_003CRopeCoroutine_003Ed__7)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0d0a;
																											IL_0d0a:
																											num5 -= 2;
																											break;
																											IL_0d1d:
																											if (12 < b)
																											{
																												goto end_IL_07da;
																											}
																											goto IL_0d2b;
																										}
																										break;
																									}
																									goto IL_0da1;
																									IL_1320:
																									num5--;
																									break;
																									IL_0da1:
																									if (20 >= b)
																									{
																										goto IL_0daf;
																									}
																									goto IL_108d;
																									IL_0daf:
																									if (20 <= b)
																									{
																										goto IL_0dba;
																									}
																									goto IL_0dfa;
																									IL_0dba:
																									((_003CRopeCoroutine_003Ed__7)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																									goto IL_0de7;
																									IL_0de7:
																									num5 -= 2;
																									break;
																									IL_0dfa:
																									if (16 >= b)
																									{
																										goto IL_0e08;
																									}
																									goto IL_0f18;
																									IL_0e08:
																									if (16 <= b)
																									{
																										goto IL_0e13;
																									}
																									goto IL_0e56;
																									IL_0e13:
																									*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((GorillaRopeSwing[])array2[num5 - 1]).LongLength;
																									goto IL_0e3d;
																									IL_0e3d:
																									array[num5 - 1] = 2;
																									break;
																									IL_0e56:
																									if (14 >= b)
																									{
																										goto IL_0e61;
																									}
																									goto IL_0ebc;
																									IL_0e61:
																									if (14 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_0e6f;
																									IL_0e6f:
																									array[num5] = 5;
																									goto IL_0e7d;
																									IL_0e7d:
																									array2[num5] = ((delegate*<GorillaRopeSwing[]>)LongToStringSetter[*(int*)(ptr2 + num3)])();
																									goto IL_0e9b;
																									IL_0e9b:
																									num5++;
																									goto IL_0ea9;
																									IL_0ea9:
																									ptr2 += 8;
																									break;
																									IL_0ebc:
																									if (15 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_0eca;
																									IL_0eca:
																									if (15 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_0ed8;
																									IL_0ed8:
																									((Class20)array2[num5 - 2]).gorillaRopeSwing_0 = (GorillaRopeSwing[])array2[num5 - 1];
																									goto IL_0f05;
																									IL_0f05:
																									num5 -= 2;
																									break;
																									IL_0f18:
																									if (18 >= b)
																									{
																										goto IL_0f26;
																									}
																									goto IL_1011;
																									IL_0f26:
																									if (18 <= b)
																									{
																										goto IL_0f31;
																									}
																									goto IL_0f7a;
																									IL_0f31:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																									goto IL_0f4b;
																									IL_0f4b:
																									array[num5] = 3;
																									goto IL_0f59;
																									IL_0f59:
																									num5++;
																									goto IL_0f67;
																									IL_0f67:
																									ptr2 += 8;
																									break;
																									IL_0f7a:
																									if (17 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_0f88;
																									IL_0f88:
																									if (17 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_0f96;
																									IL_0f96:
																									ptr2 = (((*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == (IntPtr)0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0ff5;
																									IL_0ff5:
																									num5--;
																									num = 52;
																									break;
																									IL_1011:
																									if (19 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_101f;
																									IL_101f:
																									if (19 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_102d;
																									IL_102d:
																									array[num5 - 1] = 5;
																									goto IL_1041;
																									IL_1041:
																									array2[num5 - 1] = ((delegate*<float, WaitForSeconds>)LongToStringSetter[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																									goto IL_107a;
																									IL_107a:
																									ptr2 += 8;
																									break;
																									IL_108d:
																									if (23 >= b)
																									{
																										goto IL_109b;
																									}
																									goto IL_1186;
																									IL_109b:
																									if (23 <= b)
																									{
																										goto IL_10a6;
																									}
																									goto IL_10da;
																									IL_10a6:
																									array2[num5] = null;
																									goto IL_10b0;
																									IL_10b0:
																									array[num5] = 5;
																									num = 253;
																									goto IL_10c7;
																									IL_10c7:
																									num5++;
																									break;
																									IL_10da:
																									if (21 >= b)
																									{
																										goto IL_10e5;
																									}
																									goto IL_110b;
																									IL_10e5:
																									if (21 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_10f3;
																									IL_10f3:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_110b:
																									if (22 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_1119;
																									IL_1119:
																									if (22 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_1127;
																									IL_1127:
																									array2[num5 - 1] = ((delegate*<Class20, GorillaRopeSwing>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																									goto IL_115f;
																									IL_115f:
																									array[num5 - 1] = 5;
																									goto IL_1173;
																									IL_1173:
																									ptr2 += 8;
																									break;
																									IL_1186:
																									if (25 >= b)
																									{
																										goto IL_1194;
																									}
																									goto IL_12b7;
																									IL_1194:
																									if (25 > b)
																									{
																										goto IL_11a2;
																									}
																									goto IL_1249;
																									IL_11a2:
																									if (24 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_11b0;
																									IL_11b0:
																									if (24 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_11be;
																									IL_11be:
																									array[num5 - 2] = 0;
																									goto IL_11d2;
																									IL_11d2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)LongToStringSetter[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																									goto IL_121f;
																									IL_121f:
																									num5--;
																									goto IL_122d;
																									IL_122d:
																									ptr2 += 8;
																									num = 4;
																									break;
																									IL_1249:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_129b;
																									IL_129b:
																									num5--;
																									num = 349;
																									break;
																									IL_12b7:
																									if (26 < b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_12c5;
																									IL_12c5:
																									if (26 > b)
																									{
																										goto end_IL_07da;
																									}
																									goto IL_12d3;
																									IL_12d3:
																									array2[num5 - 2] = ((GorillaRopeSwing[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_130c;
																									IL_130c:
																									array[num5 - 2] = 5;
																									goto IL_1320;
																								}
																								break;
																							}
																							goto IL_081b;
																							IL_0848:
																							num5 -= 2;
																							break;
																							IL_081b:
																							((Class20)array2[num5 - 2]).gorillaRopeSwing_1 = (GorillaRopeSwing)array2[num5 - 1];
																							goto IL_0848;
																						}
																						break;
																					}
																					goto IL_1333;
																					IL_1f42:
																					num5--;
																					goto IL_1f50;
																					IL_1333:
																					if (40 >= b)
																					{
																						goto IL_1341;
																					}
																					goto IL_196c;
																					IL_1341:
																					if (40 > b)
																					{
																						goto IL_134f;
																					}
																					goto IL_1907;
																					IL_134f:
																					if (33 >= b)
																					{
																						goto IL_135d;
																					}
																					goto IL_1613;
																					IL_135d:
																					if (33 <= b)
																					{
																						goto IL_1368;
																					}
																					goto IL_13dd;
																					IL_1368:
																					ptr2 = ((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]))) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_13ca;
																					IL_13ca:
																					num5 -= 2;
																					break;
																					IL_13dd:
																					if (30 >= b)
																					{
																						goto IL_13eb;
																					}
																					goto IL_1512;
																					IL_13eb:
																					if (30 <= b)
																					{
																						goto IL_13f6;
																					}
																					goto IL_1449;
																					IL_13f6:
																					array[num5] = 3;
																					goto IL_1404;
																					IL_1404:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<float>)LongToStringSetter[*(int*)(ptr2 + num3)])();
																					goto IL_1428;
																					IL_1428:
																					num5++;
																					goto IL_1436;
																					IL_1436:
																					ptr2 += 8;
																					break;
																					IL_1449:
																					if (28 >= b)
																					{
																						goto IL_1454;
																					}
																					goto IL_14b5;
																					IL_1454:
																					if (28 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1462;
																					IL_1462:
																					array[num5] = 3;
																					goto IL_1470;
																					IL_1470:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<float>)LongToStringSetter[*(int*)(ptr2 + num3)])();
																					goto IL_1494;
																					IL_1494:
																					num5++;
																					goto IL_14a2;
																					IL_14a2:
																					ptr2 += 8;
																					break;
																					IL_14b5:
																					if (29 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_14c3;
																					IL_14c3:
																					if (29 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_14d1;
																					IL_14d1:
																					((_003CRopeCoroutine_003Ed__7)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_14ff;
																					IL_14ff:
																					num5 -= 2;
																					break;
																					IL_1512:
																					if (31 >= b)
																					{
																						goto IL_151d;
																					}
																					goto IL_1590;
																					IL_151d:
																					if (31 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_152b;
																					IL_152b:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<Class20, float>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																					goto IL_1569;
																					IL_1569:
																					array[num5 - 1] = 3;
																					goto IL_157d;
																					IL_157d:
																					ptr2 += 8;
																					break;
																					IL_1590:
																					if (32 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_159e;
																					IL_159e:
																					if (32 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_15ac;
																					IL_15ac:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_15ec;
																					IL_15ec:
																					array[num5 - 2] = 3;
																					goto IL_1600;
																					IL_1600:
																					num5--;
																					break;
																					IL_1613:
																					if (36 < b)
																					{
																						goto IL_1621;
																					}
																					goto IL_178f;
																					IL_1621:
																					if (38 >= b)
																					{
																						goto IL_162f;
																					}
																					goto IL_1703;
																					IL_162f:
																					if (38 <= b)
																					{
																						goto IL_163a;
																					}
																					goto IL_1675;
																					IL_163a:
																					((_003CRopeCoroutine_003Ed__7)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																					goto IL_1662;
																					IL_1662:
																					num5 -= 2;
																					break;
																					IL_1675:
																					if (37 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1683;
																					IL_1683:
																					if (37 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1691;
																					IL_1691:
																					((delegate*<Class20, GorillaRopeSwing, Vector3, void>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 3], (GorillaRopeSwing)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																					goto IL_16e2;
																					IL_16e2:
																					num5 -= 3;
																					goto IL_16f0;
																					IL_16f0:
																					ptr2 += 8;
																					break;
																					IL_1703:
																					if (39 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1711;
																					IL_1711:
																					if (39 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_171f;
																					IL_171f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_175f;
																					IL_175f:
																					array[num5 - 2] = 0;
																					goto IL_1773;
																					IL_1773:
																					num5--;
																					num = 104;
																					break;
																					IL_178f:
																					if (36 <= b)
																					{
																						goto IL_179d;
																					}
																					goto IL_183e;
																					IL_179d:
																					array[num5 - 3] = 5;
																					num = 306;
																					goto IL_17ba;
																					IL_17ba:
																					array2[num5 - 3] = ((delegate*<float, float, float, object>)LongToStringSetter[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_181d;
																					IL_181d:
																					num5 -= 2;
																					goto IL_182b;
																					IL_182b:
																					ptr2 += 8;
																					break;
																					IL_183e:
																					if (34 >= b)
																					{
																						goto IL_1849;
																					}
																					goto IL_18aa;
																					IL_1849:
																					if (34 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1857;
																					IL_1857:
																					array[num5] = 3;
																					goto IL_1865;
																					IL_1865:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<float>)LongToStringSetter[*(int*)(ptr2 + num3)])();
																					goto IL_1889;
																					IL_1889:
																					num5++;
																					goto IL_1897;
																					IL_1897:
																					ptr2 += 8;
																					break;
																					IL_18aa:
																					if (35 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_18b8;
																					IL_18b8:
																					if (35 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_18c6;
																					IL_18c6:
																					((Class20)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_18f4;
																					IL_18f4:
																					num5 -= 2;
																					break;
																					IL_1907:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CRopeCoroutine_003Ed__7, float>)LongToStringSetter[*(int*)(ptr2 + num3)])((_003CRopeCoroutine_003Ed__7)array2[num5 - 1]);
																					goto IL_1945;
																					IL_1945:
																					array[num5 - 1] = 3;
																					goto IL_1959;
																					IL_1959:
																					ptr2 += 8;
																					break;
																					IL_196c:
																					if (47 >= b)
																					{
																						goto IL_197a;
																					}
																					goto IL_1d0b;
																					IL_197a:
																					if (47 <= b)
																					{
																						goto IL_1985;
																					}
																					goto IL_19e4;
																					IL_1985:
																					((delegate*<List<GorillaRopeSwing>, int, void>)LongToStringSetter[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_19c3;
																					IL_19c3:
																					num5 -= 2;
																					goto IL_19d1;
																					IL_19d1:
																					ptr2 += 8;
																					break;
																					IL_19e4:
																					if (43 >= b)
																					{
																						goto IL_19f2;
																					}
																					goto IL_1b6d;
																					IL_19f2:
																					if (43 <= b)
																					{
																						goto IL_19fd;
																					}
																					goto IL_1a5c;
																					IL_19fd:
																					array2[num5 - 1] = ((delegate*<Class20, List<GorillaRopeSwing>>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																					goto IL_1a35;
																					IL_1a35:
																					array[num5 - 1] = 5;
																					goto IL_1a49;
																					IL_1a49:
																					ptr2 += 8;
																					break;
																					IL_1a5c:
																					if (41 >= b)
																					{
																						goto IL_1a67;
																					}
																					goto IL_1adc;
																					IL_1a67:
																					if (41 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1a75;
																					IL_1a75:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_1ab5;
																					IL_1ab5:
																					array[num5 - 2] = 3;
																					goto IL_1ac9;
																					IL_1ac9:
																					num5--;
																					break;
																					IL_1adc:
																					if (42 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1aea;
																					IL_1aea:
																					if (42 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1af8;
																					IL_1af8:
																					ptr2 = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_1b5a;
																					IL_1b5a:
																					num5 -= 2;
																					break;
																					IL_1b6d:
																					if (45 >= b)
																					{
																						goto IL_1b7b;
																					}
																					goto IL_1c6e;
																					IL_1b7b:
																					if (45 <= b)
																					{
																						goto IL_1b86;
																					}
																					goto IL_1beb;
																					IL_1b86:
																					array[num5 - 1] = 0;
																					goto IL_1b9a;
																					IL_1b9a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<List<GorillaRopeSwing>, int>)LongToStringSetter[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 1]);
																					goto IL_1bd8;
																					IL_1bd8:
																					ptr2 += 8;
																					break;
																					IL_1beb:
																					if (44 < b)
																					{
																						goto end_IL_07da;
																					}
																					num = 38;
																					goto IL_1c02;
																					IL_1f50:
																					ptr2 += 8;
																					break;
																					IL_1c02:
																					if (44 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1c10;
																					IL_1c10:
																					((delegate*<List<GorillaRopeSwing>, GorillaRopeSwing, void>)LongToStringSetter[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 2], (GorillaRopeSwing)array2[num5 - 1]);
																					goto IL_1c4d;
																					IL_1c4d:
																					num5 -= 2;
																					goto IL_1c5b;
																					IL_1c5b:
																					ptr2 += 8;
																					break;
																					IL_1c6e:
																					if (46 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1c7c;
																					IL_1c7c:
																					if (46 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1c8a;
																					IL_1c8a:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_1cf8;
																					IL_1cf8:
																					num5 -= 2;
																					break;
																					IL_1d0b:
																					if (50 >= b)
																					{
																						goto IL_1d19;
																					}
																					goto IL_1e59;
																					IL_1d19:
																					if (50 <= b)
																					{
																						goto IL_1d24;
																					}
																					goto IL_1d7d;
																					IL_1d24:
																					array[num5] = 5;
																					num = 378;
																					goto IL_1d3b;
																					IL_1d3b:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_1d53;
																					IL_1d53:
																					num5++;
																					num = 59;
																					goto IL_1d6a;
																					IL_1d6a:
																					ptr2 += 8;
																					break;
																					IL_1d7d:
																					if (48 >= b)
																					{
																						goto IL_1d88;
																					}
																					goto IL_1df5;
																					IL_1d88:
																					if (48 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1d96;
																					IL_1d96:
																					array[num5 - 1] = 5;
																					goto IL_1daa;
																					IL_1daa:
																					array2[num5 - 1] = ((delegate*<Class20, GorillaRopeSwing>)LongToStringSetter[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																					goto IL_1de2;
																					IL_1de2:
																					ptr2 += 8;
																					break;
																					IL_1df5:
																					if (49 < b)
																					{
																						goto end_IL_07da;
																					}
																					num = 169;
																					goto IL_1e0c;
																					IL_1f60:
																					if (53 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1f6b;
																					IL_1e0c:
																					if (49 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1e1a;
																					IL_1e1a:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_1e38;
																					IL_1e38:
																					ptr2 += 8;
																					goto IL_1e46;
																					IL_1e46:
																					num5--;
																					break;
																					IL_1e59:
																					if (52 >= b)
																					{
																						num = 238;
																						goto IL_1e70;
																					}
																					goto IL_1f60;
																					IL_1f6b:
																					if (53 <= b)
																					{
																					}
																					goto end_IL_07da;
																					IL_1e70:
																					if (52 <= b)
																					{
																						goto IL_1e7b;
																					}
																					goto IL_1ec5;
																					IL_1e7b:
																					((delegate*<List<GorillaRopeSwing>, void>)LongToStringSetter[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 1]);
																					goto IL_1ea4;
																					IL_1ea4:
																					num5--;
																					goto IL_1eb2;
																					IL_1eb2:
																					ptr2 += 8;
																					break;
																					IL_1ec5:
																					if (51 < b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1ed3;
																					IL_1ed3:
																					if (51 > b)
																					{
																						goto end_IL_07da;
																					}
																					goto IL_1ee1;
																					IL_1ee1:
																					array[num5 - 2] = 0;
																					goto IL_1ef5;
																					IL_1ef5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)LongToStringSetter[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																					goto IL_1f42;
																				}
																				goto end_IL_07ed;
																				continue;
																				end_IL_07da:
																				break;
																				IL_07da:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_07ed:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_2047;
														IL_2047:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														continue;
														end_IL_1f89:
														break;
													}
													continue;
													end_IL_1f9c:
													break;
												}
												continue;
												end_IL_1fa6:
												break;
											}
											continue;
											end_IL_1fb1:
											break;
										}
										continue;
										end_IL_1fc1:
										break;
									}
									continue;
									end_IL_1fd1:
									break;
								}
								continue;
								end_IL_1fe1:
								break;
							}
							continue;
							end_IL_1ffa:
							break;
						}
						continue;
						end_IL_2013:
						break;
					}
					continue;
					end_IL_2023:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		void IEnumerator.Reset()
		{
			NotSupportedException ex = new NotSupportedException();
			object obj = ex;
			throw (Exception)obj;
		}

		static _003CRopeCoroutine_003Ed__7()
		{
			int num = 4;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					IL_0068:
					Class300.smethod_0();
					while (true)
					{
						IL_0056:
						num = 1;
						while (true)
						{
							IL_004a:
							num = 13;
							while (true)
							{
								if (num != 13)
								{
									if (num != 994)
									{
										break;
									}
									switch (num)
									{
									case 1:
										goto IL_004a;
									case 0:
									case 2:
									case 5:
										goto IL_0056;
									case 3:
										goto IL_0068;
									case 4:
										goto end_IL_003d;
									case 6:
										return;
									}
									continue;
								}
								return;
								continue;
								end_IL_003d:
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	private Coroutine coroutine_0;

	private GorillaRopeSwing[] gorillaRopeSwing_0;

	private GorillaRopeSwing gorillaRopeSwing_1;

	private List<GorillaRopeSwing> list_0;

	private float float_0;

	private static float float_1;

	private static bool bool_0;

	private static bool bool_1;

	private static int int_0;

	private static double double_0;

	private static double double_1;

	private static IntPtr[] JustificationComEventsMethod;

	private static IntPtr[] getWrappedExceptionSetComObjectData;

	private static IntPtr[] getYearShouldOverrideFieldName;

	private static IntPtr[] LocallocDoesTextualDefinitionMatchTextualReference;

	private static IntPtr[] ExclusiveTokenRestrictedUserClaimAttributes;

	private static IntPtr[] ProviderTypegetSecurityZone;

	private static IntPtr[] EventTokengetShortestDayNames;

	private unsafe void OnEnable()
	{
		int num = 168;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getProtectedResourcesTrustedComputingBase.getAssemblyEvidenceSoapNmtoken);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0488:
														byte b = *ptr2;
														while (true)
														{
															IL_046f:
															ptr2++;
															num = 146;
															while (true)
															{
																IL_045f:
																if (b >= 1)
																{
																	while (b <= 21)
																	{
																		while (true)
																		{
																			IL_043f:
																			if (11 >= b)
																			{
																				while (11 > b)
																				{
																					while (true)
																					{
																						IL_041f:
																						if (5 < b)
																						{
																							while (true)
																							{
																								IL_040f:
																								if (8 >= b)
																								{
																									while (true)
																									{
																										IL_03ff:
																										if (8 > b)
																										{
																											while (true)
																											{
																												IL_03ef:
																												if (6 >= b)
																												{
																													while (6 <= b)
																													{
																														while (true)
																														{
																															IL_039d:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_0387:
																																array[num5 - 2] = 0;
																																while (true)
																																{
																																	IL_036e:
																																	num5--;
																																	num = 211;
																																	while (num != 211)
																																	{
																																		if (num != 1192)
																																		{
																																			goto end_IL_03df;
																																		}
																																		switch (num)
																																		{
																																		case 110:
																																			goto IL_036e;
																																		case 103:
																																			goto IL_0387;
																																		case 98:
																																		case 138:
																																			goto IL_039d;
																																		case 65:
																																			goto IL_03df;
																																		case 161:
																																			goto IL_03ef;
																																		case 81:
																																			goto IL_03ff;
																																		case 198:
																																			goto IL_040f;
																																		case 77:
																																		case 88:
																																			goto IL_041f;
																																		case 147:
																																			goto IL_042f;
																																		case 91:
																																			goto IL_043f;
																																		case 72:
																																			goto IL_044f;
																																		case 146:
																																			goto IL_045f;
																																		case 144:
																																			goto IL_046f;
																																		case 62:
																																		case 74:
																																			goto IL_0488;
																																		case 19:
																																		case 126:
																																			goto IL_0493;
																																		case 106:
																																			goto IL_04a1;
																																		case 14:
																																		case 46:
																																			goto IL_04af;
																																		case 16:
																																			goto IL_04ef;
																																		case 101:
																																			goto IL_0503;
																																		case 133:
																																		case 134:
																																			goto IL_0516;
																																		case 34:
																																		case 165:
																																			goto IL_0529;
																																		case 7:
																																			goto IL_0534;
																																		case 116:
																																			goto IL_0547;
																																		case 0:
																																			goto IL_0552;
																																		case 25:
																																			goto IL_0565;
																																		case 82:
																																			goto IL_0570;
																																		case 80:
																																			goto IL_057e;
																																		case 64:
																																		case 92:
																																			goto IL_058c;
																																		case 4:
																																			goto IL_05b1;
																																		case 166:
																																			goto IL_05c4;
																																		case 83:
																																		case 96:
																																			goto IL_05cf;
																																		case 17:
																																			goto IL_05dd;
																																		case 15:
																																		case 93:
																																			goto IL_05eb;
																																		case 100:
																																			goto IL_0613;
																																		case 137:
																																			goto IL_0626;
																																		case 47:
																																		case 149:
																																			goto IL_0631;
																																		case 109:
																																			goto IL_0640;
																																		case 118:
																																			goto IL_064e;
																																		case 135:
																																		case 136:
																																			goto IL_065c;
																																		case 84:
																																			goto IL_0674;
																																		case 68:
																																			goto IL_0682;
																																		case 128:
																																		case 174:
																																			goto IL_0695;
																																		case 71:
																																			goto IL_06cd;
																																		case 176:
																																			goto IL_06e6;
																																		case 70:
																																		case 150:
																																			goto IL_06f1;
																																		case 145:
																																			goto IL_0731;
																																		case 121:
																																			goto IL_0745;
																																		case 169:
																																			goto IL_0758;
																																		case 112:
																																			goto IL_0763;
																																		case 57:
																																			goto IL_0771;
																																		case 24:
																																			goto IL_0784;
																																		case 29:
																																			goto IL_078f;
																																		case 3:
																																		case 140:
																																			goto IL_079d;
																																		case 172:
																																			goto IL_07cb;
																																		case 49:
																																			goto IL_07d9;
																																		case 86:
																																		case 148:
																																			goto IL_07e7;
																																		case 162:
																																			goto IL_07f5;
																																		case 89:
																																			goto IL_0818;
																																		case 1:
																																			goto IL_0822;
																																		case 44:
																																			goto IL_0830;
																																		case 178:
																																			goto IL_084c;
																																		case 102:
																																		case 182:
																																			goto IL_085f;
																																		case 43:
																																			goto IL_089f;
																																		case 142:
																																			goto IL_08b3;
																																		case 185:
																																			goto IL_08c6;
																																		case 156:
																																		case 188:
																																			goto IL_08d9;
																																		case 163:
																																			goto IL_0906;
																																		case 164:
																																		case 189:
																																			goto IL_0919;
																																		case 141:
																																			goto IL_0924;
																																		case 30:
																																		case 63:
																																			goto IL_0932;
																																		case 175:
																																			goto IL_095b;
																																		case 139:
																																			goto IL_0969;
																																		case 51:
																																			goto IL_097c;
																																		case 187:
																																			goto IL_098a;
																																		case 119:
																																		case 155:
																																			goto IL_0998;
																																		case 56:
																																			goto IL_09ac;
																																		case 111:
																																			goto IL_09e4;
																																		case 190:
																																			goto IL_09f7;
																																		case 36:
																																			goto IL_0a05;
																																		case 73:
																																		case 191:
																																			goto IL_0a18;
																																		case 159:
																																			goto IL_0a2c;
																																		case 192:
																																			goto IL_0a7d;
																																		case 194:
																																			goto IL_0a90;
																																		case 5:
																																			goto IL_0a9e;
																																		case 79:
																																		case 196:
																																			goto IL_0ab1;
																																		case 52:
																																			goto IL_0abf;
																																		case 27:
																																		case 124:
																																			goto IL_0acd;
																																		case 20:
																																			goto IL_0af5;
																																		case 41:
																																		case 197:
																																			goto IL_0b08;
																																		case 67:
																																			goto IL_0b13;
																																		case 99:
																																		case 152:
																																			goto IL_0b21;
																																		case 158:
																																			goto IL_0b61;
																																		case 45:
																																			goto IL_0b75;
																																		case 186:
																																			goto IL_0b88;
																																		case 201:
																																			goto IL_0b96;
																																		case 69:
																																		case 153:
																																			goto IL_0ba4;
																																		case 132:
																																			goto IL_0c06;
																																		case 204:
																																			goto IL_0c16;
																																		case 95:
																																			goto IL_0c24;
																																		case 8:
																																		case 9:
																																		case 12:
																																		case 13:
																																		case 18:
																																		case 23:
																																		case 32:
																																		case 33:
																																		case 35:
																																		case 38:
																																		case 40:
																																		case 42:
																																		case 50:
																																		case 54:
																																		case 58:
																																		case 61:
																																		case 76:
																																		case 78:
																																		case 85:
																																		case 94:
																																		case 108:
																																		case 113:
																																		case 115:
																																		case 117:
																																		case 122:
																																		case 123:
																																		case 131:
																																		case 143:
																																		case 151:
																																		case 157:
																																		case 160:
																																		case 170:
																																		case 171:
																																		case 179:
																																		case 183:
																																		case 193:
																																		case 199:
																																		case 200:
																																		case 203:
																																			goto end_IL_03df;
																																		case 22:
																																			goto IL_0c56;
																																		case 177:
																																			goto IL_0c64;
																																		case 60:
																																			goto IL_0c72;
																																		case 6:
																																		case 10:
																																		case 11:
																																		case 26:
																																		case 28:
																																		case 31:
																																		case 37:
																																		case 48:
																																		case 53:
																																		case 55:
																																		case 66:
																																		case 75:
																																		case 87:
																																		case 90:
																																		case 97:
																																		case 104:
																																		case 114:
																																		case 127:
																																		case 129:
																																		case 173:
																																		case 181:
																																		case 184:
																																		case 195:
																																			goto end_IL_035b;
																																		case 2:
																																			goto end_IL_0c80;
																																		case 154:
																																			goto end_IL_0c93;
																																		case 125:
																																			goto end_IL_0c9d;
																																		case 21:
																																			goto end_IL_0ca8;
																																		case 105:
																																			goto end_IL_0cb8;
																																		case 120:
																																		case 180:
																																			goto end_IL_0cc8;
																																		case 59:
																																			goto end_IL_0cd8;
																																		case 107:
																																		case 130:
																																			goto end_IL_0ce8;
																																		case 167:
																																			goto end_IL_0cf8;
																																		case 168:
																																			goto end_IL_0d08;
																																		case 39:
																																		case 202:
																																			return;
																																		}
																																		continue;
																																		end_IL_035b:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_042f;
																														continue;
																														end_IL_03df:
																														break;
																														IL_03df:;
																													}
																													break;
																												}
																												goto IL_0493;
																												IL_0503:
																												num5--;
																												goto end_IL_042f;
																												IL_0493:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_04a1;
																												IL_04a1:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_04af;
																												IL_04af:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_04ef;
																												IL_04ef:
																												array[num5 - 2] = 0;
																												goto IL_0503;
																											}
																											break;
																										}
																										goto IL_0516;
																										IL_0516:
																										num5--;
																										goto end_IL_042f;
																									}
																									break;
																								}
																								goto IL_0b08;
																								IL_0c06:
																								num5 -= 2;
																								goto end_IL_042f;
																								IL_0b08:
																								if (9 >= b)
																								{
																									goto IL_0b13;
																								}
																								goto IL_0b88;
																								IL_0b13:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0b21;
																								IL_0b21:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0b61;
																								IL_0b61:
																								array[num5 - 2] = 0;
																								goto IL_0b75;
																								IL_0b75:
																								num5--;
																								goto end_IL_042f;
																								IL_0b88:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0b96;
																								IL_0b96:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0ba4;
																								IL_0ba4:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0c06;
																							}
																							break;
																						}
																						goto IL_06e6;
																						IL_0830:
																						ptr2 += 8;
																						num = 48;
																						goto end_IL_042f;
																						IL_06e6:
																						if (5 <= b)
																						{
																							goto IL_06f1;
																						}
																						goto IL_0758;
																						IL_06f1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0731;
																						IL_0731:
																						array[num5 - 2] = 0;
																						goto IL_0745;
																						IL_0745:
																						num5--;
																						goto end_IL_042f;
																						IL_0758:
																						if (2 >= b)
																						{
																							goto IL_0763;
																						}
																						goto IL_0784;
																						IL_0763:
																						if (2 > b)
																						{
																							goto IL_0771;
																						}
																						goto IL_085f;
																						IL_0771:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_08c6;
																						IL_08c6:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_085f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_089f;
																						IL_089f:
																						array[num5 - 2] = 0;
																						goto IL_08b3;
																						IL_08b3:
																						num5--;
																						goto end_IL_042f;
																						IL_0784:
																						if (3 >= b)
																						{
																							goto IL_078f;
																						}
																						goto IL_07cb;
																						IL_078f:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_079d;
																						IL_079d:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_09f7;
																						IL_09f7:
																						ptr2 += 8;
																						goto IL_0a05;
																						IL_0a05:
																						num5--;
																						goto end_IL_042f;
																						IL_07cb:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_07d9;
																						IL_07d9:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_07e7;
																						IL_07e7:
																						array[num5] = 0;
																						goto IL_07f5;
																						IL_07f5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0818;
																						IL_0818:
																						array2[num5] = null;
																						goto IL_0822;
																						IL_0822:
																						num5++;
																						goto IL_0830;
																					}
																					goto end_IL_044f;
																					continue;
																					end_IL_042f:
																					break;
																					IL_042f:;
																				}
																				break;
																			}
																			goto IL_0529;
																			IL_08d9:
																			((Class20)array2[num5 - 2]).coroutine_0 = (Coroutine)array2[num5 - 1];
																			goto IL_0906;
																			IL_0529:
																			if (16 >= b)
																			{
																				goto IL_0534;
																			}
																			goto IL_0547;
																			IL_0534:
																			if (16 > b)
																			{
																				goto IL_05c4;
																			}
																			goto IL_0695;
																			IL_0695:
																			array2[num5 - 1] = ((delegate*<Class20, List<GorillaRopeSwing>>)JustificationComEventsMethod[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																			goto IL_06cd;
																			IL_06cd:
																			array[num5 - 1] = 5;
																			goto IL_084c;
																			IL_084c:
																			ptr2 += 8;
																			break;
																			IL_05c4:
																			if (13 < b)
																			{
																				goto IL_05cf;
																			}
																			goto IL_0626;
																			IL_05cf:
																			if (14 >= b)
																			{
																				goto IL_05dd;
																			}
																			goto IL_0ab1;
																			IL_05dd:
																			if (14 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_05eb;
																			IL_05eb:
																			((Class20)array2[num5 - 2]).gorillaRopeSwing_0 = (GorillaRopeSwing[])array2[num5 - 1];
																			goto IL_0613;
																			IL_0613:
																			num5 -= 2;
																			break;
																			IL_0ab1:
																			if (15 < b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_0abf;
																			IL_0abf:
																			if (15 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_0acd;
																			IL_0acd:
																			((Class20)array2[num5 - 2]).gorillaRopeSwing_1 = (GorillaRopeSwing)array2[num5 - 1];
																			goto IL_0af5;
																			IL_0af5:
																			num5 -= 2;
																			break;
																			IL_0626:
																			if (13 <= b)
																			{
																				goto IL_0631;
																			}
																			goto IL_0640;
																			IL_0631:
																			array2[num5] = null;
																			goto IL_0a90;
																			IL_0a90:
																			array[num5] = 5;
																			goto IL_0a9e;
																			IL_0a9e:
																			num5++;
																			break;
																			IL_0640:
																			if (12 < b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_064e;
																			IL_064e:
																			if (12 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_065c;
																			IL_065c:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0674;
																			IL_0674:
																			array[num5] = 5;
																			goto IL_0682;
																			IL_0682:
																			num5++;
																			goto IL_0a7d;
																			IL_0a7d:
																			ptr2 += 8;
																			break;
																			IL_0547:
																			if (19 >= b)
																			{
																				goto IL_0552;
																			}
																			goto IL_0565;
																			IL_0552:
																			if (19 > b)
																			{
																				goto IL_0919;
																			}
																			goto IL_0a18;
																			IL_0919:
																			if (17 >= b)
																			{
																				goto IL_0924;
																			}
																			goto IL_097c;
																			IL_0924:
																			if (17 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_0932;
																			IL_0932:
																			((delegate*<List<GorillaRopeSwing>, void>)JustificationComEventsMethod[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 1]);
																			goto IL_095b;
																			IL_095b:
																			num5--;
																			goto IL_0969;
																			IL_0969:
																			ptr2 += 8;
																			break;
																			IL_097c:
																			if (18 < b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_098a;
																			IL_098a:
																			if (18 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_0998;
																			IL_0998:
																			array[num5 - 1] = 5;
																			goto IL_09ac;
																			IL_09ac:
																			array2[num5 - 1] = ((delegate*<Class20, IEnumerator>)JustificationComEventsMethod[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																			goto IL_09e4;
																			IL_09e4:
																			ptr2 += 8;
																			break;
																			IL_0a18:
																			array[num5 - 2] = 5;
																			goto IL_0a2c;
																			IL_0a2c:
																			array2[num5 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)JustificationComEventsMethod[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 2], (IEnumerator)array2[num5 - 1]);
																			goto IL_0c16;
																			IL_0c16:
																			num5--;
																			goto IL_0c24;
																			IL_0c24:
																			ptr2 += 8;
																			num = 37;
																			break;
																			IL_0565:
																			if (20 < b)
																			{
																				goto IL_0570;
																			}
																			num = 4;
																			goto IL_05b1;
																			IL_0570:
																			if (21 < b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_057e;
																			IL_057e:
																			if (21 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_058c;
																			IL_058c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0906:
																			num5 -= 2;
																			break;
																			IL_05b1:
																			if (20 > b)
																			{
																				goto end_IL_044f;
																			}
																			goto IL_08d9;
																		}
																		goto end_IL_045f;
																		continue;
																		end_IL_044f:
																		break;
																		IL_044f:;
																	}
																}
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0c56;
																IL_0c72:
																ptr2 += 8;
																break;
																IL_0c64:
																num5++;
																goto IL_0c72;
																IL_0c56:
																array[num5] = 0;
																goto IL_0c64;
																continue;
																end_IL_045f:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0c80:
													break;
												}
												continue;
												end_IL_0c93:
												break;
											}
											continue;
											end_IL_0c9d:
											break;
										}
										continue;
										end_IL_0ca8:
										break;
									}
									continue;
									end_IL_0cb8:
									break;
								}
								continue;
								end_IL_0cc8:
								break;
							}
							continue;
							end_IL_0cd8:
							break;
						}
						continue;
						end_IL_0ce8:
						break;
					}
					continue;
					end_IL_0cf8:
					break;
				}
				continue;
				end_IL_0d08:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 188;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSchedulerPairBuiltinDomainSid.bodyWithStateEnvelope);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0533:
																if (b >= 1)
																{
																	while (b <= 29)
																	{
																		while (true)
																		{
																			IL_0513:
																			if (15 >= b)
																			{
																				while (true)
																				{
																					IL_0503:
																					if (15 > b)
																					{
																						while (true)
																						{
																							IL_04f3:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_04e3:
																									if (7 > b)
																									{
																										while (true)
																										{
																											IL_04d3:
																											if (3 < b)
																											{
																												while (true)
																												{
																													IL_04c3:
																													if (5 >= b)
																													{
																														while (true)
																														{
																															IL_04b3:
																															if (5 > b)
																															{
																																while (4 >= b)
																																{
																																	while (true)
																																	{
																																		IL_0490:
																																		if (4 > b)
																																		{
																																			num = 280;
																																			while (num != 280)
																																			{
																																				if (num != 1261)
																																				{
																																					goto IL_0bfa;
																																				}
																																				switch (num)
																																				{
																																				case 226:
																																					goto IL_0490;
																																				case 255:
																																					goto IL_04a3;
																																				case 184:
																																					goto IL_04b3;
																																				case 50:
																																				case 168:
																																					goto IL_04c3;
																																				case 140:
																																				case 245:
																																					goto IL_04d3;
																																				case 137:
																																					goto IL_04e3;
																																				case 13:
																																				case 189:
																																					goto IL_04f3;
																																				case 23:
																																					goto IL_0503;
																																				case 157:
																																					goto IL_0513;
																																				case 3:
																																					goto IL_0523;
																																				case 118:
																																					goto IL_0533;
																																				case 181:
																																					goto end_IL_0533;
																																				case 37:
																																				case 193:
																																					goto end_IL_0543;
																																				case 5:
																																				case 38:
																																					goto IL_055e;
																																				case 70:
																																					goto IL_056c;
																																				case 80:
																																					goto IL_0591;
																																				case 87:
																																					goto IL_05a4;
																																				case 4:
																																					goto IL_05ae;
																																				case 95:
																																				case 129:
																																					goto IL_05c1;
																																				case 15:
																																					goto IL_05fe;
																																				case 94:
																																				case 162:
																																					goto IL_0611;
																																				case 67:
																																				case 124:
																																					goto IL_061f;
																																				case 153:
																																					goto IL_062d;
																																				case 47:
																																				case 89:
																																					goto IL_0638;
																																				case 7:
																																				case 136:
																																					goto IL_064b;
																																				case 46:
																																					goto IL_0683;
																																				case 21:
																																					goto IL_0697;
																																				case 163:
																																					goto IL_06aa;
																																				case 186:
																																					goto IL_06bd;
																																				case 231:
																																					goto IL_06d0;
																																				case 100:
																																				case 138:
																																					goto IL_06db;
																																				case 176:
																																					goto IL_06f3;
																																				case 88:
																																					goto IL_0701;
																																				case 34:
																																					goto IL_070f;
																																				case 253:
																																					goto IL_0730;
																																				case 82:
																																					goto IL_073e;
																																				case 75:
																																					goto IL_074c;
																																				case 25:
																																				case 160:
																																					goto IL_0757;
																																				case 127:
																																					goto IL_0797;
																																				case 86:
																																					goto IL_07ab;
																																				case 170:
																																					goto IL_07c7;
																																				case 146:
																																					goto IL_07d5;
																																				case 19:
																																				case 224:
																																					goto IL_07e3;
																																				case 213:
																																					goto IL_07f6;
																																				case 85:
																																					goto IL_0804;
																																				case 22:
																																				case 78:
																																					goto IL_0812;
																																				case 219:
																																					goto IL_0874;
																																				case 44:
																																				case 254:
																																					goto IL_0887;
																																				case 152:
																																					goto IL_08c7;
																																				case 222:
																																					goto IL_08db;
																																				case 262:
																																					goto IL_08ee;
																																				case 6:
																																				case 270:
																																					goto IL_0901;
																																				case 59:
																																					goto IL_090f;
																																				case 132:
																																				case 177:
																																					goto IL_091d;
																																				case 108:
																																					goto IL_0965;
																																				case 98:
																																				case 215:
																																					goto IL_0981;
																																				case 40:
																																					goto IL_09c1;
																																				case 128:
																																					goto IL_09d5;
																																				case 101:
																																					goto IL_09e8;
																																				case 77:
																																					goto IL_09f6;
																																				case 2:
																																				case 48:
																																					goto IL_0a04;
																																				case 43:
																																					goto IL_0a12;
																																				case 35:
																																				case 52:
																																					goto IL_0a20;
																																				case 144:
																																					goto IL_0a69;
																																				case 194:
																																					goto IL_0a7d;
																																				case 106:
																																					goto IL_0a90;
																																				case 0:
																																				case 192:
																																					goto IL_0a9e;
																																				case 197:
																																					goto IL_0ab7;
																																				case 174:
																																					goto IL_0ac5;
																																				case 68:
																																					goto IL_0adc;
																																				case 9:
																																				case 183:
																																					goto IL_0aef;
																																				case 73:
																																					goto IL_0b18;
																																				case 112:
																																					goto IL_0b26;
																																				case 206:
																																				case 243:
																																					goto IL_0b42;
																																				case 212:
																																					goto IL_0b82;
																																				case 218:
																																					goto IL_0b96;
																																				case 110:
																																					goto IL_0ba9;
																																				case 216:
																																					goto IL_0bb7;
																																				case 211:
																																				case 251:
																																					goto IL_0bc5;
																																				case 190:
																																					goto IL_0bd3;
																																				case 56:
																																				case 79:
																																					goto IL_0bde;
																																				case 257:
																																					goto IL_0bec;
																																				case 39:
																																				case 158:
																																					goto IL_0bfa;
																																				case 84:
																																					goto IL_0c38;
																																				case 61:
																																					goto IL_0c46;
																																				case 18:
																																				case 185:
																																					goto IL_0c59;
																																				case 133:
																																					goto IL_0c75;
																																				case 74:
																																					goto IL_0c83;
																																				case 83:
																																					goto IL_0c96;
																																				case 45:
																																					goto IL_0ca4;
																																				case 246:
																																					goto IL_0cb2;
																																				case 20:
																																				case 159:
																																					goto IL_0cbd;
																																				case 239:
																																					goto IL_0d0f;
																																				case 51:
																																				case 54:
																																					goto IL_0d2b;
																																				case 241:
																																					goto IL_0d39;
																																				case 28:
																																				case 57:
																																					goto IL_0d47;
																																				case 220:
																																					goto IL_0d5b;
																																				case 96:
																																					goto IL_0da8;
																																				case 41:
																																					goto IL_0db6;
																																				case 12:
																																					goto IL_0dc9;
																																				case 178:
																																					goto IL_0dd7;
																																				case 99:
																																				case 134:
																																					goto IL_0de5;
																																				case 123:
																																					goto IL_0e1d;
																																				case 8:
																																					goto IL_0e31;
																																				case 210:
																																				case 272:
																																					goto IL_0e44;
																																				case 165:
																																					goto IL_0e58;
																																				case 105:
																																					goto IL_0ea5;
																																				case 256:
																																					goto IL_0eb3;
																																				case 115:
																																					goto IL_0ec6;
																																				case 139:
																																				case 169:
																																					goto IL_0ed4;
																																				case 55:
																																					goto IL_0ee2;
																																				case 65:
																																				case 142:
																																					goto IL_0ef0;
																																				case 242:
																																					goto IL_0efb;
																																				case 221:
																																				case 252:
																																					goto IL_0f09;
																																				case 264:
																																					goto IL_0f13;
																																				case 121:
																																					goto IL_0f21;
																																				case 122:
																																					goto IL_0f34;
																																				case 164:
																																					goto IL_0f4b;
																																				case 14:
																																				case 119:
																																					goto IL_0f59;
																																				case 237:
																																					goto IL_0f81;
																																				case 69:
																																				case 172:
																																					goto IL_0f9d;
																																				case 120:
																																					goto IL_0fc5;
																																				case 229:
																																					goto IL_0fd8;
																																				case 104:
																																				case 240:
																																					goto IL_0fe3;
																																				case 227:
																																					goto IL_0ff1;
																																				case 156:
																																				case 199:
																																					goto IL_0fff;
																																				case 258:
																																					goto IL_1028;
																																				case 107:
																																					goto IL_1036;
																																				case 150:
																																					goto IL_1049;
																																				case 26:
																																				case 91:
																																					goto IL_1054;
																																				case 90:
																																					goto IL_108c;
																																				case 102:
																																					goto IL_10a9;
																																				case 126:
																																				case 143:
																																					goto IL_10c5;
																																				case 214:
																																					goto IL_10d3;
																																				case 155:
																																				case 205:
																																					goto IL_10e1;
																																				case 31:
																																					goto IL_1109;
																																				case 131:
																																				case 209:
																																					goto IL_1119;
																																				case 265:
																																					goto IL_1127;
																																				case 147:
																																					goto IL_114e;
																																				case 249:
																																					goto IL_115c;
																																				case 1:
																																				case 10:
																																				case 11:
																																				case 17:
																																				case 29:
																																				case 30:
																																				case 33:
																																				case 42:
																																				case 49:
																																				case 53:
																																				case 58:
																																				case 66:
																																				case 72:
																																				case 76:
																																				case 81:
																																				case 93:
																																				case 97:
																																				case 114:
																																				case 116:
																																				case 135:
																																				case 154:
																																				case 161:
																																				case 171:
																																				case 175:
																																				case 179:
																																				case 196:
																																				case 198:
																																				case 200:
																																				case 201:
																																				case 203:
																																				case 204:
																																				case 207:
																																				case 208:
																																				case 217:
																																				case 228:
																																				case 233:
																																				case 235:
																																				case 236:
																																				case 238:
																																				case 244:
																																				case 247:
																																				case 248:
																																				case 259:
																																				case 260:
																																				case 261:
																																					goto end_IL_047d;
																																				case 16:
																																				case 24:
																																				case 36:
																																				case 60:
																																				case 63:
																																				case 64:
																																				case 71:
																																				case 92:
																																				case 103:
																																				case 109:
																																				case 111:
																																				case 113:
																																				case 117:
																																				case 125:
																																				case 130:
																																				case 145:
																																				case 148:
																																				case 149:
																																				case 151:
																																				case 173:
																																				case 180:
																																				case 191:
																																				case 195:
																																				case 202:
																																				case 225:
																																				case 230:
																																				case 234:
																																				case 263:
																																				case 266:
																																				case 267:
																																				case 268:
																																				case 271:
																																					goto end_IL_0553;
																																				case 32:
																																					goto end_IL_117f;
																																				case 269:
																																					goto end_IL_1192;
																																				case 167:
																																					goto end_IL_119c;
																																				case 182:
																																					goto end_IL_11a7;
																																				case 273:
																																					goto end_IL_11b7;
																																				case 166:
																																				case 232:
																																					goto end_IL_11c7;
																																				case 62:
																																					goto end_IL_11d7;
																																				case 223:
																																				case 250:
																																					goto end_IL_11e7;
																																				case 187:
																																					goto end_IL_11f7;
																																				case 188:
																																					goto end_IL_1207;
																																				case 27:
																																				case 141:
																																					return;
																																				}
																																				continue;
																																				end_IL_047d:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_055e;
																																		IL_05ae:
																																		num5++;
																																		goto IL_06aa;
																																		IL_06aa:
																																		ptr2 += 8;
																																		goto end_IL_0553;
																																		IL_055e:
																																		array[num5] = 0;
																																		goto IL_056c;
																																		IL_056c:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																		goto IL_05a4;
																																		IL_05a4:
																																		array2[num5] = null;
																																		goto IL_05ae;
																																	}
																																	break;
																																	IL_04a3:;
																																}
																																break;
																															}
																															num = 98;
																															goto IL_0981;
																															IL_09c1:
																															array[num5 - 2] = 0;
																															goto IL_09d5;
																															IL_09d5:
																															num5--;
																															goto end_IL_0553;
																															IL_0981:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_09c1;
																														}
																														break;
																													}
																													goto IL_0591;
																													IL_08db:
																													num5--;
																													goto end_IL_0553;
																													IL_0591:
																													if (6 < b)
																													{
																														break;
																													}
																													goto IL_06bd;
																													IL_06bd:
																													if (6 > b)
																													{
																														break;
																													}
																													goto IL_0887;
																													IL_0887:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_08c7;
																													IL_08c7:
																													array[num5 - 2] = 0;
																													goto IL_08db;
																												}
																												break;
																											}
																											goto IL_09e8;
																											IL_0b26:
																											num5--;
																											num = 180;
																											goto end_IL_0553;
																											IL_09e8:
																											if (3 > b)
																											{
																												goto IL_09f6;
																											}
																											goto IL_0aef;
																											IL_09f6:
																											if (1 < b)
																											{
																												goto IL_0a04;
																											}
																											goto IL_0a90;
																											IL_0a04:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0a12;
																											IL_0a12:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0a20;
																											IL_0a20:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 144;
																											goto IL_0a69;
																											IL_0a69:
																											array[num5 - 2] = 0;
																											goto IL_0a7d;
																											IL_0a7d:
																											num5--;
																											goto end_IL_0553;
																											IL_0a90:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0a9e;
																											IL_0a9e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0ab7;
																											IL_0ab7:
																											array[num5] = 0;
																											goto IL_0ac5;
																											IL_0ac5:
																											num5++;
																											num = 68;
																											goto IL_0adc;
																											IL_0adc:
																											ptr2 += 8;
																											goto end_IL_0553;
																											IL_0aef:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0b18;
																											IL_0b18:
																											ptr2 += 8;
																											goto IL_0b26;
																										}
																										break;
																									}
																									goto IL_0b42;
																									IL_0b96:
																									num5--;
																									goto end_IL_0553;
																									IL_0b42:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0b82;
																									IL_0b82:
																									array[num5 - 2] = 0;
																									goto IL_0b96;
																								}
																								break;
																							}
																							goto IL_0611;
																							IL_0812:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0874;
																							IL_0611:
																							if (11 < b)
																							{
																								goto IL_061f;
																							}
																							goto IL_0730;
																							IL_061f:
																							if (13 >= b)
																							{
																								goto IL_062d;
																							}
																							goto IL_0901;
																							IL_062d:
																							if (13 > b)
																							{
																								goto IL_0638;
																							}
																							goto IL_064b;
																							IL_0638:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_06d0;
																							IL_06d0:
																							if (12 > b)
																							{
																								num = 49;
																								break;
																							}
																							goto IL_06db;
																							IL_06db:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_06f3;
																							IL_06f3:
																							array[num5] = 5;
																							goto IL_0701;
																							IL_0701:
																							num5++;
																							goto IL_070f;
																							IL_070f:
																							ptr2 += 8;
																							goto end_IL_0553;
																							IL_0874:
																							num5 -= 2;
																							goto end_IL_0553;
																							IL_064b:
																							array2[num5 - 1] = ((delegate*<Class20, Coroutine>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																							goto IL_0683;
																							IL_0683:
																							array[num5 - 1] = 5;
																							goto IL_0697;
																							IL_0697:
																							ptr2 += 8;
																							goto end_IL_0553;
																							IL_0901:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_090f;
																							IL_090f:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_091d;
																							IL_091d:
																							ptr2 = ((array2[num5 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0965;
																							IL_0965:
																							num5--;
																							goto end_IL_0553;
																							IL_0730:
																							if (11 <= b)
																							{
																								goto end_IL_0553;
																							}
																							goto IL_073e;
																							IL_073e:
																							if (9 >= b)
																							{
																								goto IL_074c;
																							}
																							goto IL_07f6;
																							IL_074c:
																							if (9 <= b)
																							{
																								goto IL_0757;
																							}
																							goto IL_07c7;
																							IL_0757:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0797;
																							IL_0797:
																							array[num5 - 2] = 0;
																							goto IL_07ab;
																							IL_07ab:
																							num5--;
																							num = 125;
																							goto end_IL_0553;
																							IL_07c7:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_07d5;
																							IL_07d5:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_07e3;
																							IL_07e3:
																							num5--;
																							goto end_IL_0553;
																							IL_07f6:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0804;
																							IL_0804:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0812;
																						}
																						break;
																					}
																					goto IL_05c1;
																					IL_08ee:
																					ptr2 += 8;
																					goto end_IL_0553;
																					IL_05c1:
																					((delegate*<MonoBehaviour, Coroutine, void>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 2], (Coroutine)array2[num5 - 1]);
																					goto IL_05fe;
																					IL_05fe:
																					num5 -= 2;
																					goto IL_08ee;
																				}
																				break;
																			}
																			goto IL_0ba9;
																			IL_1119:
																			array[num5] = 5;
																			goto IL_1127;
																			IL_0ba9:
																			if (22 < b)
																			{
																				goto IL_0bb7;
																			}
																			goto IL_0ec6;
																			IL_0bb7:
																			if (26 < b)
																			{
																				goto IL_0bc5;
																			}
																			goto IL_0c96;
																			IL_0bc5:
																			if (28 >= b)
																			{
																				goto IL_0bd3;
																			}
																			goto IL_0c75;
																			IL_0bd3:
																			if (28 > b)
																			{
																				goto IL_0bde;
																			}
																			goto IL_0c59;
																			IL_0bde:
																			if (27 < b)
																			{
																				break;
																			}
																			goto IL_0bec;
																			IL_0bec:
																			if (27 > b)
																			{
																				break;
																			}
																			goto IL_0bfa;
																			IL_0bfa:
																			((delegate*<Behaviour, bool, void>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																			goto IL_0c38;
																			IL_0c38:
																			num5 -= 2;
																			goto IL_0c46;
																			IL_0c46:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_0c59:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0553;
																			IL_0c75:
																			if (29 < b)
																			{
																				break;
																			}
																			goto IL_0c83;
																			IL_0c83:
																			if (29 <= b)
																			{
																			}
																			break;
																			IL_0c96:
																			if (26 > b)
																			{
																				goto IL_0ca4;
																			}
																			goto IL_0e44;
																			IL_0ca4:
																			if (24 >= b)
																			{
																				goto IL_0cb2;
																			}
																			goto IL_0dc9;
																			IL_0cb2:
																			if (24 <= b)
																			{
																				goto IL_0cbd;
																			}
																			num = 54;
																			goto IL_0d2b;
																			IL_0cbd:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0d0f;
																			IL_0d0f:
																			num5--;
																			goto end_IL_0553;
																			IL_1127:
																			array2[num5] = ((delegate*<GorillaTagger>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])();
																			num = 147;
																			goto IL_114e;
																			IL_0d2b:
																			if (23 < b)
																			{
																				break;
																			}
																			goto IL_0d39;
																			IL_0d39:
																			if (23 > b)
																			{
																				break;
																			}
																			goto IL_0d47;
																			IL_0d47:
																			array[num5 - 2] = 0;
																			goto IL_0d5b;
																			IL_0d5b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																			goto IL_0da8;
																			IL_0da8:
																			num5--;
																			goto IL_0db6;
																			IL_0db6:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_0dc9:
																			if (25 < b)
																			{
																				break;
																			}
																			goto IL_0dd7;
																			IL_0dd7:
																			if (25 > b)
																			{
																				break;
																			}
																			goto IL_0de5;
																			IL_0de5:
																			array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																			goto IL_0e1d;
																			IL_0e1d:
																			array[num5 - 1] = 5;
																			goto IL_0e31;
																			IL_0e31:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_0e44:
																			array[num5 - 2] = 0;
																			goto IL_0e58;
																			IL_0e58:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																			goto IL_0ea5;
																			IL_0ea5:
																			num5--;
																			goto IL_0eb3;
																			IL_0eb3:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_0ec6:
																			if (22 > b)
																			{
																				goto IL_0ed4;
																			}
																			goto IL_1119;
																			IL_0ed4:
																			if (18 >= b)
																			{
																				goto IL_0ee2;
																			}
																			goto IL_0fd8;
																			IL_0ee2:
																			if (18 > b)
																			{
																				goto IL_0ef0;
																			}
																			goto IL_0f9d;
																			IL_0ef0:
																			if (16 >= b)
																			{
																				goto IL_0efb;
																			}
																			goto IL_0f34;
																			IL_0efb:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_0f09;
																			IL_0f09:
																			array2[num5] = null;
																			goto IL_0f13;
																			IL_0f13:
																			array[num5] = 5;
																			goto IL_0f21;
																			IL_0f21:
																			num5++;
																			goto end_IL_0553;
																			IL_0f34:
																			if (17 < b)
																			{
																				break;
																			}
																			num = 164;
																			goto IL_0f4b;
																			IL_114e:
																			num5++;
																			goto IL_115c;
																			IL_0f4b:
																			if (17 > b)
																			{
																				break;
																			}
																			goto IL_0f59;
																			IL_0f59:
																			((Class20)array2[num5 - 2]).coroutine_0 = (Coroutine)array2[num5 - 1];
																			goto IL_0f81;
																			IL_0f81:
																			num5 -= 2;
																			num = 234;
																			goto end_IL_0553;
																			IL_0f9d:
																			((Class20)array2[num5 - 2]).gorillaRopeSwing_0 = (GorillaRopeSwing[])array2[num5 - 1];
																			goto IL_0fc5;
																			IL_0fc5:
																			num5 -= 2;
																			goto end_IL_0553;
																			IL_0fd8:
																			if (20 < b)
																			{
																				goto IL_0fe3;
																			}
																			goto IL_1049;
																			IL_0fe3:
																			if (21 < b)
																			{
																				break;
																			}
																			goto IL_0ff1;
																			IL_0ff1:
																			if (21 > b)
																			{
																				break;
																			}
																			goto IL_0fff;
																			IL_0fff:
																			((delegate*<List<GorillaRopeSwing>, void>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num5 - 1]);
																			goto IL_1028;
																			IL_1028:
																			num5--;
																			goto IL_1036;
																			IL_1036:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_1049:
																			if (20 <= b)
																			{
																				goto IL_1054;
																			}
																			num = 126;
																			goto IL_10c5;
																			IL_1054:
																			array2[num5 - 1] = ((delegate*<Class20, List<GorillaRopeSwing>>)getWrappedExceptionSetComObjectData[*(int*)(ptr2 + num3)])((Class20)array2[num5 - 1]);
																			goto IL_108c;
																			IL_108c:
																			array[num5 - 1] = 5;
																			num = 102;
																			goto IL_10a9;
																			IL_10a9:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_115c:
																			ptr2 += 8;
																			goto end_IL_0553;
																			IL_10c5:
																			if (19 < b)
																			{
																				break;
																			}
																			goto IL_10d3;
																			IL_10d3:
																			if (19 > b)
																			{
																				break;
																			}
																			goto IL_10e1;
																			IL_10e1:
																			((Class20)array2[num5 - 2]).gorillaRopeSwing_1 = (GorillaRopeSwing)array2[num5 - 1];
																			goto IL_1109;
																			IL_1109:
																			num5 -= 2;
																			goto end_IL_0553;
																		}
																		break;
																		IL_0523:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0553;
																continue;
																end_IL_0533:
																break;
															}
															continue;
															end_IL_0543:
															break;
														}
														continue;
														end_IL_0553:
														break;
													}
													continue;
													end_IL_117f:
													break;
												}
												continue;
												end_IL_1192:
												break;
											}
											continue;
											end_IL_119c:
											break;
										}
										continue;
										end_IL_11a7:
										break;
									}
									continue;
									end_IL_11b7:
									break;
								}
								continue;
								end_IL_11c7:
								break;
							}
							continue;
							end_IL_11d7:
							break;
						}
						continue;
						end_IL_11e7:
						break;
					}
					continue;
					end_IL_11f7:
					break;
				}
				continue;
				end_IL_1207:
				break;
			}
		}
	}

	private unsafe IEnumerator method_0()
	{
		int num = 206;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											object[] array6 = new object[1];
											num = 22;
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReplacementCulturesProgIdRedirectionRedirectedGuid.HashElementEntryFieldIdgetFrameworkDescription);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															num = 186;
															while (true)
															{
																if (num5 != 1)
																{
																	while (true)
																	{
																		byte b = *ptr2;
																		while (true)
																		{
																			ptr2++;
																			while (true)
																			{
																				IL_0410:
																				if (b >= 1)
																				{
																					while (b <= 22)
																					{
																						while (true)
																						{
																							IL_03f0:
																							if (11 >= b)
																							{
																								while (true)
																								{
																									IL_03e0:
																									if (11 > b)
																									{
																										while (true)
																										{
																											IL_03d3:
																											if (5 >= b)
																											{
																												while (true)
																												{
																													IL_03c3:
																													if (5 > b)
																													{
																														while (true)
																														{
																															IL_03b3:
																															if (2 < b)
																															{
																																while (true)
																																{
																																	IL_03a3:
																																	if (3 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_0390:
																																			if (3 > b)
																																			{
																																				num = 216;
																																				while (num != 216 && num == 1197)
																																				{
																																					switch (num)
																																					{
																																					case 62:
																																						goto IL_0390;
																																					case 3:
																																						goto IL_03a3;
																																					case 202:
																																						goto IL_03b3;
																																					case 70:
																																						goto IL_03c3;
																																					case 19:
																																						goto IL_03d3;
																																					case 179:
																																						goto IL_03e0;
																																					case 203:
																																						goto IL_03f0;
																																					case 84:
																																						goto IL_0400;
																																					case 207:
																																						goto IL_0410;
																																					case 94:
																																						goto end_IL_0410;
																																					case 178:
																																					case 184:
																																						goto end_IL_0420;
																																					case 39:
																																						goto IL_043b;
																																					case 9:
																																						goto IL_0446;
																																					case 68:
																																						goto IL_0459;
																																					case 83:
																																					case 88:
																																						goto IL_0469;
																																					case 120:
																																						goto IL_0497;
																																					case 131:
																																						goto IL_04aa;
																																					case 17:
																																					case 43:
																																						goto IL_04b8;
																																					case 92:
																																						goto IL_04c6;
																																					case 26:
																																					case 133:
																																						goto IL_04d4;
																																					case 82:
																																						goto IL_04ed;
																																					case 126:
																																						goto IL_04fb;
																																					case 64:
																																						goto IL_0512;
																																					case 143:
																																						goto IL_0525;
																																					case 29:
																																					case 151:
																																						goto IL_0538;
																																					case 124:
																																					case 164:
																																						goto IL_057d;
																																					case 169:
																																						goto IL_05c2;
																																					case 75:
																																						goto IL_05d0;
																																					case 69:
																																					case 111:
																																						goto IL_05de;
																																					case 21:
																																						goto IL_0640;
																																					case 67:
																																					case 173:
																																						goto IL_0653;
																																					case 146:
																																						goto IL_0661;
																																					case 36:
																																					case 171:
																																						goto IL_066f;
																																					case 61:
																																						goto IL_06af;
																																					case 18:
																																						goto IL_06c3;
																																					case 47:
																																					case 174:
																																						goto IL_06d6;
																																					case 187:
																																						goto IL_06e9;
																																					case 102:
																																						goto IL_06fd;
																																					case 188:
																																						goto IL_0710;
																																					case 57:
																																					case 177:
																																						goto IL_071e;
																																					case 147:
																																						goto IL_075e;
																																					case 141:
																																						goto IL_0772;
																																					case 189:
																																						goto IL_0785;
																																					case 54:
																																						goto IL_0799;
																																					case 148:
																																					case 192:
																																						goto IL_07ac;
																																					case 6:
																																						goto IL_07ec;
																																					case 27:
																																						goto IL_0800;
																																					case 194:
																																						goto IL_0813;
																																					case 136:
																																						goto IL_0821;
																																					case 113:
																																						goto IL_0834;
																																					case 95:
																																						goto IL_0842;
																																					case 4:
																																					case 93:
																																						goto IL_0850;
																																					case 74:
																																						goto IL_085e;
																																					case 24:
																																						goto IL_0881;
																																					case 23:
																																						goto IL_088b;
																																					case 37:
																																						goto IL_0899;
																																					case 40:
																																					case 149:
																																						goto IL_08ac;
																																					case 119:
																																						goto IL_08c0;
																																					case 85:
																																						goto IL_08ff;
																																					case 71:
																																					case 90:
																																						goto IL_0912;
																																					case 100:
																																						goto IL_0920;
																																					case 176:
																																					case 180:
																																						goto IL_092e;
																																					case 127:
																																						goto IL_093c;
																																					case 15:
																																					case 123:
																																						goto IL_094a;
																																					case 76:
																																						goto IL_0955;
																																					case 197:
																																						goto IL_0963;
																																					case 41:
																																					case 49:
																																						goto IL_0971;
																																					case 165:
																																						goto IL_098a;
																																					case 153:
																																						goto IL_0998;
																																					case 13:
																																						goto IL_09a6;
																																					case 150:
																																						goto IL_09b9;
																																					case 182:
																																					case 209:
																																						goto IL_09cc;
																																					case 107:
																																						goto IL_09e4;
																																					case 35:
																																					case 101:
																																						goto IL_09f2;
																																					case 175:
																																						goto IL_0a00;
																																					case 14:
																																					case 198:
																																						goto IL_0a0e;
																																					case 32:
																																						goto IL_0a69;
																																					case 190:
																																						goto IL_0a7c;
																																					case 73:
																																					case 159:
																																						goto IL_0a8a;
																																					case 155:
																																						goto IL_0acb;
																																					case 50:
																																						goto IL_0adf;
																																					case 33:
																																					case 81:
																																						goto IL_0af2;
																																					case 106:
																																						goto IL_0b0f;
																																					case 59:
																																						goto IL_0b48;
																																					case 152:
																																						goto IL_0b5b;
																																					case 110:
																																					case 163:
																																						goto IL_0b66;
																																					case 16:
																																						goto IL_0b71;
																																					case 87:
																																					case 193:
																																						goto IL_0b7f;
																																					case 137:
																																						goto IL_0b9b;
																																					case 144:
																																						goto IL_0ba9;
																																					case 117:
																																						goto IL_0bc5;
																																					case 28:
																																					case 139:
																																						goto IL_0bd0;
																																					case 142:
																																						goto IL_0bfd;
																																					case 66:
																																						goto IL_0c10;
																																					case 115:
																																						goto IL_0c1e;
																																					case 160:
																																					case 200:
																																						goto IL_0c2c;
																																					case 138:
																																						goto IL_0c44;
																																					case 51:
																																						goto IL_0c62;
																																					case 140:
																																						goto IL_0c86;
																																					case 44:
																																						goto IL_0c9e;
																																					case 58:
																																						goto IL_0cae;
																																					case 104:
																																						goto IL_0cb9;
																																					case 5:
																																					case 105:
																																						goto IL_0cc4;
																																					case 199:
																																						goto IL_0ce5;
																																					case 125:
																																						goto IL_0cf3;
																																					case 34:
																																						goto IL_0d01;
																																					case 7:
																																					case 8:
																																					case 10:
																																					case 11:
																																					case 12:
																																					case 25:
																																					case 30:
																																					case 31:
																																					case 42:
																																					case 45:
																																					case 46:
																																					case 52:
																																					case 65:
																																					case 89:
																																					case 91:
																																					case 96:
																																					case 103:
																																					case 108:
																																					case 112:
																																					case 114:
																																					case 121:
																																					case 122:
																																					case 128:
																																					case 129:
																																					case 130:
																																					case 134:
																																					case 135:
																																					case 145:
																																					case 156:
																																					case 157:
																																					case 167:
																																					case 168:
																																					case 170:
																																					case 183:
																																					case 185:
																																					case 191:
																																					case 196:
																																						goto end_IL_037d;
																																					case 0:
																																					case 20:
																																					case 38:
																																					case 48:
																																					case 53:
																																					case 55:
																																					case 77:
																																					case 78:
																																					case 80:
																																					case 86:
																																					case 97:
																																					case 98:
																																					case 118:
																																					case 132:
																																					case 154:
																																					case 158:
																																					case 161:
																																					case 162:
																																					case 166:
																																					case 172:
																																					case 181:
																																					case 186:
																																					case 201:
																																					case 208:
																																						goto end_IL_0430;
																																					case 60:
																																						goto end_IL_0d24;
																																					case 109:
																																						goto end_IL_0d37;
																																					case 63:
																																						goto end_IL_0d42;
																																					case 22:
																																						goto end_IL_0d4c;
																																					case 56:
																																						goto end_IL_0d57;
																																					case 116:
																																						goto end_IL_0d67;
																																					case 79:
																																						goto end_IL_0d80;
																																					case 204:
																																						goto end_IL_0d90;
																																					case 99:
																																						goto end_IL_0da0;
																																					case 1:
																																						goto end_IL_0db0;
																																					case 72:
																																						goto end_IL_0dc0;
																																					case 205:
																																						goto end_IL_0dd0;
																																					case 206:
																																						goto end_IL_0de0;
																																					case 2:
																																					case 195:
																																						goto IL_0dfb;
																																					}
																																					continue;
																																					end_IL_037d:
																																					break;
																																				}
																																				break;
																																			}
																																			goto IL_0469;
																																			IL_0813:
																																			ptr2 += 8;
																																			goto IL_0821;
																																			IL_0821:
																																			num6--;
																																			goto end_IL_0430;
																																			IL_0469:
																																			ref int reference = ref array4[*(int*)(ptr2 + num3)];
																																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																			goto IL_0813;
																																		}
																																		break;
																																	}
																																	goto IL_0834;
																																	IL_0899:
																																	ptr2 += 8;
																																	goto end_IL_0430;
																																	IL_0834:
																																	if (4 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0842;
																																	IL_0842:
																																	if (4 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0850;
																																	IL_0850:
																																	array[num6] = 0;
																																	goto IL_085e;
																																	IL_085e:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																																	goto IL_0881;
																																	IL_0881:
																																	array2[num6] = null;
																																	goto IL_088b;
																																	IL_088b:
																																	num6++;
																																	goto IL_0899;
																																}
																																break;
																															}
																															goto IL_04aa;
																															IL_0799:
																															num6--;
																															goto end_IL_0430;
																															IL_04aa:
																															if (2 > b)
																															{
																																goto IL_04b8;
																															}
																															goto IL_057d;
																															IL_04b8:
																															if (1 < b)
																															{
																																break;
																															}
																															goto IL_04c6;
																															IL_04c6:
																															if (1 > b)
																															{
																																break;
																															}
																															goto IL_04d4;
																															IL_04d4:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																															goto IL_04ed;
																															IL_04ed:
																															array[num6] = 0;
																															goto IL_04fb;
																															IL_04fb:
																															num6++;
																															num = 64;
																															goto IL_0512;
																															IL_0512:
																															ptr2 += 8;
																															goto end_IL_0430;
																															IL_057d:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																															goto IL_0785;
																															IL_0785:
																															array[num6 - 2] = 0;
																															goto IL_0799;
																														}
																														break;
																													}
																													goto IL_0538;
																													IL_06fd:
																													num6--;
																													goto end_IL_0430;
																													IL_0538:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																													goto IL_06e9;
																													IL_06e9:
																													array[num6 - 2] = 0;
																													goto IL_06fd;
																												}
																												break;
																											}
																											goto IL_043b;
																											IL_06d6:
																											num6--;
																											goto end_IL_0430;
																											IL_043b:
																											if (8 < b)
																											{
																												goto IL_0446;
																											}
																											goto IL_0459;
																											IL_0446:
																											if (9 >= b)
																											{
																												goto IL_0525;
																											}
																											goto IL_05c2;
																											IL_0525:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_07ac;
																											IL_07ac:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_07ec;
																											IL_07ec:
																											array[num6 - 2] = 0;
																											goto IL_0800;
																											IL_0800:
																											num6--;
																											goto end_IL_0430;
																											IL_05c2:
																											if (10 < b)
																											{
																												break;
																											}
																											goto IL_05d0;
																											IL_05d0:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_05de;
																											IL_05de:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0640;
																											IL_0640:
																											num6 -= 2;
																											goto end_IL_0430;
																											IL_0459:
																											if (8 > b)
																											{
																												goto IL_0497;
																											}
																											goto IL_06d6;
																											IL_0497:
																											if (6 < b)
																											{
																												goto IL_0653;
																											}
																											goto IL_0710;
																											IL_0653:
																											if (7 < b)
																											{
																												break;
																											}
																											goto IL_0661;
																											IL_0661:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_066f;
																											IL_066f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_06af;
																											IL_06af:
																											array[num6 - 2] = 0;
																											goto IL_06c3;
																											IL_06c3:
																											num6--;
																											goto end_IL_0430;
																											IL_0710:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_071e;
																											IL_071e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_075e;
																											IL_075e:
																											array[num6 - 2] = 0;
																											goto IL_0772;
																											IL_0772:
																											num6--;
																											goto end_IL_0430;
																										}
																										break;
																									}
																									goto IL_08ac;
																									IL_08ff:
																									ptr2 += 8;
																									goto end_IL_0430;
																									IL_08ac:
																									array[num6 - 1] = 0;
																									goto IL_08c0;
																									IL_08c0:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<int, int>)getYearShouldOverrideFieldName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_08ff;
																								}
																								break;
																							}
																							goto IL_0912;
																							IL_0cf3:
																							num6++;
																							goto IL_0d01;
																							IL_0912:
																							if (17 >= b)
																							{
																								goto IL_0920;
																							}
																							goto IL_0b5b;
																							IL_0920:
																							if (17 > b)
																							{
																								goto IL_092e;
																							}
																							goto IL_0af2;
																							IL_092e:
																							if (14 >= b)
																							{
																								goto IL_093c;
																							}
																							goto IL_09e4;
																							IL_093c:
																							if (14 > b)
																							{
																								goto IL_094a;
																							}
																							goto IL_09cc;
																							IL_094a:
																							if (12 < b)
																							{
																								goto IL_0955;
																							}
																							goto IL_09b9;
																							IL_0955:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0963;
																							IL_0963:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0971;
																							IL_0971:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																							goto IL_098a;
																							IL_098a:
																							array[num6] = 1;
																							goto IL_0998;
																							IL_0998:
																							num6++;
																							goto IL_09a6;
																							IL_09a6:
																							ptr2 += 16;
																							goto end_IL_0430;
																							IL_09b9:
																							if (12 <= b)
																							{
																								goto end_IL_0430;
																							}
																							break;
																							IL_09cc:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0430;
																							IL_09e4:
																							if (15 < b)
																							{
																								goto IL_09f2;
																							}
																							goto IL_0a7c;
																							IL_09f2:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0a00;
																							IL_0a00:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0a0e;
																							IL_0a0e:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 32;
																							goto IL_0a69;
																							IL_0a69:
																							num6--;
																							goto end_IL_0430;
																							IL_0a7c:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0a8a;
																							IL_0a8a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																							goto IL_0acb;
																							IL_0acb:
																							array[num6 - 2] = 0;
																							goto IL_0adf;
																							IL_0adf:
																							num6--;
																							goto end_IL_0430;
																							IL_0af2:
																							array[num6 - 1] = 5;
																							num = 106;
																							goto IL_0b0f;
																							IL_0b0f:
																							array2[num6 - 1] = ((delegate*<int, _003CRopeCoroutine_003Ed__7>)getYearShouldOverrideFieldName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0b48;
																							IL_0b48:
																							ptr2 += 8;
																							goto end_IL_0430;
																							IL_0b5b:
																							if (20 < b)
																							{
																								goto IL_0b66;
																							}
																							goto IL_0bc5;
																							IL_0b66:
																							if (21 >= b)
																							{
																								goto IL_0b71;
																							}
																							goto IL_0b9b;
																							IL_0b71:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_0b7f;
																							IL_0b7f:
																							byte* num7 = ptr2;
																							num5 = 1;
																							ptr2 = num7 + -200;
																							goto end_IL_0430;
																							IL_0b9b:
																							if (22 < b)
																							{
																								break;
																							}
																							goto IL_0ba9;
																							IL_0ba9:
																							if (22 <= b)
																							{
																								num = 196;
																							}
																							break;
																							IL_0d01:
																							ptr2 += 8;
																							goto end_IL_0430;
																							IL_0bc5:
																							if (20 <= b)
																							{
																								goto IL_0bd0;
																							}
																							goto IL_0c10;
																							IL_0bd0:
																							((_003CRopeCoroutine_003Ed__7)array2[num6 - 2]).class20_0 = (Class20)array2[num6 - 1];
																							goto IL_0bfd;
																							IL_0bfd:
																							num6 -= 2;
																							goto end_IL_0430;
																							IL_0c10:
																							if (18 >= b)
																							{
																								goto IL_0c1e;
																							}
																							goto IL_0cae;
																							IL_0c1e:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0c2c;
																							IL_0c2c:
																							array[num6] = array[num6 - 1];
																							goto IL_0c44;
																							IL_0c44:
																							array3[num6 - 0] = array3[num6 - 1];
																							goto IL_0c62;
																							IL_0c62:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0c86;
																							IL_0c86:
																							array2[num6] = array2[num6 - 1];
																							goto IL_0c9e;
																							IL_0c9e:
																							num6++;
																							goto end_IL_0430;
																							IL_0cae:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_0cb9;
																							IL_0cb9:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0cc4;
																							IL_0cc4:
																							array2[num6] = array6[*(int*)(ptr2 + num3)];
																							num = 199;
																							goto IL_0ce5;
																							IL_0ce5:
																							array[num6] = 5;
																							goto IL_0cf3;
																						}
																						break;
																						IL_0400:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0430;
																				continue;
																				end_IL_0410:
																				break;
																			}
																			continue;
																			end_IL_0420:
																			break;
																		}
																		continue;
																		end_IL_0430:
																		break;
																	}
																	continue;
																}
																goto IL_0dfb;
																IL_0dfb:
																return (IEnumerator)array2[num6 - 1];
																continue;
																end_IL_0d24:
																break;
															}
															continue;
															end_IL_0d37:
															break;
														}
														continue;
														end_IL_0d42:
														break;
													}
													continue;
													end_IL_0d4c:
													break;
												}
												continue;
												end_IL_0d57:
												break;
											}
											continue;
											end_IL_0d67:
											break;
										}
										continue;
										end_IL_0d80:
										break;
									}
									continue;
									end_IL_0d90:
									break;
								}
								continue;
								end_IL_0da0:
								break;
							}
							continue;
							end_IL_0db0:
							break;
						}
						continue;
						end_IL_0dc0:
						break;
					}
					continue;
					end_IL_0dd0:
					break;
				}
				continue;
				end_IL_0de0:
				break;
			}
		}
	}

	private unsafe void method_1(GorillaRopeSwing gorillaRopeSwing_2, Vector3 vector3_0)
	{
		int num = 486;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 485;
			while (true)
			{
				int num3 = num2 * 4;
				num = 205;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[5];
						while (true)
						{
							object[] array2 = new object[5];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[5];
									while (true)
									{
										object[] array5 = new object[2];
										while (true)
										{
											array5[0] = gorillaRopeSwing_2;
											while (true)
											{
												array5[1] = vector3_0;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegistryOptionsCMSSCHEMAVERSION.BaseCodePageEncodingDecoderNLS);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															num = 548;
															while (true)
															{
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0a28:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0a18:
																		ptr2++;
																		while (true)
																		{
																			IL_0a08:
																			if (b >= 1)
																			{
																				while (b <= 67)
																				{
																					while (true)
																					{
																						IL_09e8:
																						if (34 >= b)
																						{
																							while (true)
																							{
																								IL_09db:
																								if (34 > b)
																								{
																									while (true)
																									{
																										IL_09cb:
																										if (17 >= b)
																										{
																											while (true)
																											{
																												IL_09bb:
																												if (17 > b)
																												{
																													while (true)
																													{
																														IL_09ab:
																														if (8 < b)
																														{
																															while (true)
																															{
																																IL_099b:
																																if (12 < b)
																																{
																																	while (true)
																																	{
																																		IL_098b:
																																		if (14 < b)
																																		{
																																			while (true)
																																			{
																																				IL_097b:
																																				if (15 < b)
																																				{
																																					while (16 >= b)
																																					{
																																						while (16 <= b)
																																						{
																																							while (true)
																																							{
																																								IL_0907:
																																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																								while (true)
																																								{
																																									IL_08ee:
																																									num6--;
																																									num = 563;
																																									while (num != 563)
																																									{
																																										if (num != 1544)
																																										{
																																											goto IL_1b49;
																																										}
																																										switch (num)
																																										{
																																										case 441:
																																											goto IL_08ee;
																																										case 152:
																																										case 533:
																																											goto IL_0907;
																																										case 298:
																																											goto IL_095b;
																																										case 434:
																																											goto IL_096b;
																																										case 229:
																																											goto IL_097b;
																																										case 287:
																																											goto IL_098b;
																																										case 256:
																																											goto IL_099b;
																																										case 292:
																																											goto IL_09ab;
																																										case 547:
																																											goto IL_09bb;
																																										case 323:
																																											goto IL_09cb;
																																										case 368:
																																											goto IL_09db;
																																										case 321:
																																											goto IL_09e8;
																																										case 106:
																																											goto IL_09f8;
																																										case 406:
																																											goto IL_0a08;
																																										case 128:
																																											goto IL_0a18;
																																										case 195:
																																										case 476:
																																											goto IL_0a28;
																																										case 33:
																																											goto IL_0a33;
																																										case 94:
																																											goto IL_0a43;
																																										case 56:
																																										case 126:
																																											goto IL_0a56;
																																										case 175:
																																											goto IL_0a74;
																																										case 187:
																																											goto IL_0a87;
																																										case 199:
																																											goto IL_0a97;
																																										case 120:
																																											goto IL_0aa2;
																																										case 209:
																																											goto IL_0ab5;
																																										case 230:
																																											goto IL_0ac8;
																																										case 95:
																																										case 285:
																																											goto IL_0adb;
																																										case 303:
																																											goto IL_0af3;
																																										case 46:
																																											goto IL_0b01;
																																										case 337:
																																											goto IL_0b0f;
																																										case 51:
																																											goto IL_0b1a;
																																										case 208:
																																											goto IL_0b2d;
																																										case 340:
																																											goto IL_0b3b;
																																										case 61:
																																										case 84:
																																											goto IL_0b49;
																																										case 57:
																																											goto IL_0b89;
																																										case 348:
																																											goto IL_0ba2;
																																										case 25:
																																											goto IL_0bb0;
																																										case 34:
																																										case 130:
																																											goto IL_0bbb;
																																										case 81:
																																											goto IL_0c22;
																																										case 2:
																																											goto IL_0c30;
																																										case 129:
																																											goto IL_0c43;
																																										case 165:
																																											goto IL_0c51;
																																										case 254:
																																										case 351:
																																											goto IL_0c64;
																																										case 404:
																																											goto IL_0c7a;
																																										case 408:
																																											goto IL_0c8d;
																																										case 409:
																																											goto IL_0ca0;
																																										case 78:
																																											goto IL_0cdf;
																																										case 433:
																																											goto IL_0cf2;
																																										case 177:
																																										case 185:
																																											goto IL_0cfd;
																																										case 258:
																																											goto IL_0d13;
																																										case 145:
																																											goto IL_0d1e;
																																										case 226:
																																											goto IL_0d29;
																																										case 155:
																																											goto IL_0d37;
																																										case 329:
																																											goto IL_0d58;
																																										case 466:
																																											goto IL_0d6b;
																																										case 259:
																																											goto IL_0daa;
																																										case 400:
																																										case 473:
																																											goto IL_0dbd;
																																										case 459:
																																											goto IL_0dfd;
																																										case 273:
																																											goto IL_0e11;
																																										case 481:
																																											goto IL_0e24;
																																										case 89:
																																											goto IL_0e32;
																																										case 122:
																																										case 487:
																																											goto IL_0e45;
																																										case 280:
																																											goto IL_0e79;
																																										case 493:
																																											goto IL_0e92;
																																										case 138:
																																											goto IL_0ea0;
																																										case 124:
																																										case 255:
																																											goto IL_0eab;
																																										case 296:
																																											goto IL_0eb9;
																																										case 410:
																																											goto IL_0edc;
																																										case 54:
																																											goto IL_0ee6;
																																										case 250:
																																											goto IL_0ef4;
																																										case 151:
																																											goto IL_0f07;
																																										case 297:
																																											goto IL_0f15;
																																										case 268:
																																											goto IL_0f20;
																																										case 314:
																																											goto IL_0f2e;
																																										case 108:
																																										case 210:
																																											goto IL_0f3c;
																																										case 0:
																																											goto IL_0f55;
																																										case 74:
																																											goto IL_0f63;
																																										case 248:
																																											goto IL_0f71;
																																										case 369:
																																										case 453:
																																											goto IL_0f8d;
																																										case 269:
																																											goto IL_0fcd;
																																										case 367:
																																											goto IL_0fe1;
																																										case 463:
																																											goto IL_0ff4;
																																										case 371:
																																											goto IL_1002;
																																										case 8:
																																											goto IL_1015;
																																										case 27:
																																											goto IL_1023;
																																										case 73:
																																											goto IL_1031;
																																										case 13:
																																										case 415:
																																											goto IL_103f;
																																										case 435:
																																											goto IL_107f;
																																										case 445:
																																											goto IL_1093;
																																										case 372:
																																										case 500:
																																											goto IL_10a6;
																																										case 436:
																																											goto IL_10b4;
																																										case 160:
																																											goto IL_10d2;
																																										case 312:
																																											goto IL_10e0;
																																										case 502:
																																											goto IL_10fc;
																																										case 150:
																																											goto IL_110a;
																																										case 17:
																																										case 36:
																																											goto IL_1115;
																																										case 223:
																																											goto IL_1123;
																																										case 421:
																																											goto IL_1141;
																																										case 382:
																																											goto IL_114f;
																																										case 310:
																																											goto IL_1162;
																																										case 278:
																																											goto IL_1170;
																																										case 14:
																																										case 381:
																																											goto IL_117e;
																																										case 117:
																																											goto IL_11be;
																																										case 37:
																																											goto IL_11d2;
																																										case 189:
																																										case 510:
																																											goto IL_11e5;
																																										case 425:
																																											goto IL_120e;
																																										case 28:
																																											goto IL_121c;
																																										case 512:
																																											goto IL_122f;
																																										case 244:
																																											goto IL_123d;
																																										case 437:
																																										case 496:
																																											goto IL_1254;
																																										case 514:
																																											goto IL_1272;
																																										case 413:
																																										case 518:
																																											goto IL_1285;
																																										case 307:
																																											goto IL_129e;
																																										case 77:
																																											goto IL_12ac;
																																										case 257:
																																											goto IL_12ba;
																																										case 140:
																																										case 523:
																																											goto IL_12cd;
																																										case 306:
																																											goto IL_12e2;
																																										case 12:
																																										case 528:
																																											goto IL_12f5;
																																										case 180:
																																											goto IL_1309;
																																										case 55:
																																											goto IL_1348;
																																										case 222:
																																										case 532:
																																											goto IL_135b;
																																										case 148:
																																											goto IL_139c;
																																										case 163:
																																											goto IL_13b0;
																																										case 142:
																																										case 541:
																																											goto IL_13c3;
																																										case 352:
																																											goto IL_13ec;
																																										case 18:
																																											goto IL_13fa;
																																										case 542:
																																											goto IL_140d;
																																										case 21:
																																											goto IL_141b;
																																										case 49:
																																											goto IL_1429;
																																										case 235:
																																										case 543:
																																											goto IL_143c;
																																										case 191:
																																											goto IL_144a;
																																										case 353:
																																											goto IL_146e;
																																										case 498:
																																											goto IL_147c;
																																										case 549:
																																											goto IL_148f;
																																										case 281:
																																											goto IL_149a;
																																										case 194:
																																										case 417:
																																											goto IL_14a8;
																																										case 423:
																																											goto IL_14e0;
																																										case 92:
																																											goto IL_14f4;
																																										case 489:
																																											goto IL_1510;
																																										case 156:
																																											goto IL_151e;
																																										case 330:
																																										case 380:
																																											goto IL_152c;
																																										case 538:
																																											goto IL_1540;
																																										case 67:
																																											goto IL_1578;
																																										case 550:
																																											goto IL_158b;
																																										case 317:
																																											goto IL_1599;
																																										case 234:
																																											goto IL_15a7;
																																										case 263:
																																										case 327:
																																											goto IL_15b2;
																																										case 181:
																																											goto IL_15c6;
																																										case 275:
																																											goto IL_15fe;
																																										case 3:
																																											goto IL_1611;
																																										case 224:
																																											goto IL_161f;
																																										case 240:
																																										case 469:
																																											goto IL_162d;
																																										case 492:
																																											goto IL_1665;
																																										case 101:
																																											goto IL_1679;
																																										case 79:
																																											goto IL_168c;
																																										case 284:
																																											goto IL_169a;
																																										case 154:
																																										case 534:
																																											goto IL_16b1;
																																										case 252:
																																											goto IL_16bf;
																																										case 98:
																																											goto IL_16e6;
																																										case 451:
																																											goto IL_16f4;
																																										case 109:
																																										case 399:
																																											goto IL_1707;
																																										case 137:
																																											goto IL_175d;
																																										case 552:
																																											goto IL_1770;
																																										case 42:
																																										case 158:
																																											goto IL_177b;
																																										case 338:
																																											goto IL_17bb;
																																										case 41:
																																											goto IL_17cf;
																																										case 357:
																																											goto IL_17e2;
																																										case 241:
																																											goto IL_17f0;
																																										case 378:
																																										case 422:
																																											goto IL_17fe;
																																										case 107:
																																											goto IL_183e;
																																										case 276:
																																											goto IL_1852;
																																										case 531:
																																										case 553:
																																											goto IL_1865;
																																										case 556:
																																											goto IL_1881;
																																										case 162:
																																											goto IL_189d;
																																										case 71:
																																											goto IL_18ab;
																																										case 149:
																																										case 516:
																																											goto IL_18b6;
																																										case 398:
																																											goto IL_18ca;
																																										case 461:
																																											goto IL_1909;
																																										case 432:
																																											goto IL_191c;
																																										case 339:
																																											goto IL_192a;
																																										case 535:
																																											goto IL_1938;
																																										case 53:
																																										case 315:
																																											goto IL_1943;
																																										case 35:
																																											goto IL_19a5;
																																										case 218:
																																											goto IL_19b8;
																																										case 196:
																																											goto IL_19c6;
																																										case 123:
																																										case 325:
																																											goto IL_19d1;
																																										case 308:
																																											goto IL_19e5;
																																										case 22:
																																											goto IL_1a22;
																																										case 457:
																																											goto IL_1a35;
																																										case 494:
																																											goto IL_1a43;
																																										case 141:
																																										case 377:
																																											goto IL_1a51;
																																										case 173:
																																											goto IL_1a65;
																																										case 483:
																																											goto IL_1a9d;
																																										case 283:
																																											goto IL_1ab0;
																																										case 511:
																																											goto IL_1abe;
																																										case 15:
																																										case 349:
																																											goto IL_1acc;
																																										case 482:
																																											goto IL_1ae9;
																																										case 328:
																																											goto IL_1b3b;
																																										case 174:
																																											goto IL_1b49;
																																										case 104:
																																											goto IL_1b5c;
																																										case 456:
																																											goto IL_1b6a;
																																										case 448:
																																											goto IL_1b78;
																																										case 72:
																																											goto IL_1b86;
																																										case 75:
																																										case 97:
																																											goto IL_1b94;
																																										case 491:
																																											goto IL_1ba8;
																																										case 316:
																																											goto IL_1be7;
																																										case 389:
																																										case 426:
																																											goto IL_1bfa;
																																										case 233:
																																											goto IL_1c1f;
																																										case 467:
																																											goto IL_1c2a;
																																										case 428:
																																										case 555:
																																											goto IL_1c38;
																																										case 293:
																																											goto IL_1c42;
																																										case 517:
																																											goto IL_1c50;
																																										case 403:
																																											goto IL_1c63;
																																										case 414:
																																											goto IL_1c71;
																																										case 143:
																																										case 375:
																																											goto IL_1c7f;
																																										case 157:
																																											goto IL_1c93;
																																										case 9:
																																											goto IL_1ce0;
																																										case 90:
																																											goto IL_1cee;
																																										case 225:
																																											goto IL_1d0a;
																																										case 178:
																																										case 418:
																																											goto IL_1d15;
																																										case 474:
																																											goto IL_1d23;
																																										case 214:
																																											goto IL_1d41;
																																										case 407:
																																											goto IL_1d4f;
																																										case 401:
																																											goto IL_1d62;
																																										case 247:
																																											goto IL_1d70;
																																										case 38:
																																										case 335:
																																											goto IL_1d7e;
																																										case 5:
																																											goto IL_1d9b;
																																										case 385:
																																											goto IL_1dec;
																																										case 134:
																																											goto IL_1e03;
																																										case 326:
																																											goto IL_1e16;
																																										case 546:
																																											goto IL_1e24;
																																										case 513:
																																										case 522:
																																											goto IL_1e2f;
																																										case 402:
																																											goto IL_1e49;
																																										case 304:
																																											goto IL_1e57;
																																										case 544:
																																											goto IL_1e65;
																																										case 190:
																																											goto IL_1e78;
																																										case 172:
																																											goto IL_1e86;
																																										case 373:
																																										case 526:
																																											goto IL_1e94;
																																										case 362:
																																											goto IL_1ea8;
																																										case 88:
																																											goto IL_1ee5;
																																										case 198:
																																											goto IL_1ef8;
																																										case 69:
																																											goto IL_1f06;
																																										case 363:
																																										case 503:
																																											goto IL_1f14;
																																										case 211:
																																											goto IL_1f28;
																																										case 261:
																																											goto IL_1f8b;
																																										case 361:
																																											goto IL_1f99;
																																										case 114:
																																											goto IL_1fac;
																																										case 245:
																																											goto IL_1fba;
																																										case 213:
																																											goto IL_1fc8;
																																										case 322:
																																											goto IL_1fd6;
																																										case 6:
																																										case 499:
																																											goto IL_1fed;
																																										case 384:
																																											goto IL_202a;
																																										case 440:
																																											goto IL_2038;
																																										case 243:
																																										case 387:
																																											goto IL_2054;
																																										case 393:
																																											goto IL_2068;
																																										case 524:
																																											goto IL_20a7;
																																										case 62:
																																											goto IL_20ba;
																																										case 144:
																																											goto IL_20c8;
																																										case 200:
																																										case 319:
																																											goto IL_20d6;
																																										case 43:
																																											goto IL_20ea;
																																										case 443:
																																											goto IL_2130;
																																										case 465:
																																											goto IL_2143;
																																										case 452:
																																											goto IL_2151;
																																										case 50:
																																										case 343:
																																											goto IL_215c;
																																										case 519:
																																											goto IL_2170;
																																										case 264:
																																											goto IL_21af;
																																										case 85:
																																											goto IL_21c2;
																																										case 20:
																																											goto IL_21d0;
																																										case 305:
																																										case 470:
																																											goto IL_21db;
																																										case 131:
																																											goto IL_2205;
																																										case 277:
																																											goto IL_221e;
																																										case 193:
																																											goto IL_222c;
																																										case 44:
																																										case 146:
																																											goto IL_2237;
																																										case 471:
																																											goto IL_2275;
																																										case 166:
																																											goto IL_2289;
																																										case 344:
																																											goto IL_229c;
																																										case 334:
																																											goto IL_22aa;
																																										case 246:
																																										case 412:
																																											goto IL_22c1;
																																										case 4:
																																											goto IL_22d9;
																																										case 29:
																																											goto IL_22f0;
																																										case 91:
																																											goto IL_22fe;
																																										case 161:
																																											goto IL_2311;
																																										case 341:
																																											goto IL_231f;
																																										case 116:
																																										case 484:
																																											goto IL_232d;
																																										case 168:
																																											goto IL_2365;
																																										case 279:
																																											goto IL_2379;
																																										case 121:
																																											goto IL_238c;
																																										case 501:
																																											goto IL_239a;
																																										case 96:
																																										case 324:
																																											goto IL_23a5;
																																										case 179:
																																											goto IL_23c7;
																																										case 39:
																																											goto IL_23d5;
																																										case 391:
																																											goto IL_23e3;
																																										case 60:
																																											goto IL_23f6;
																																										case 274:
																																											goto IL_2404;
																																										case 105:
																																										case 554:
																																											goto IL_2412;
																																										case 52:
																																											goto IL_243d;
																																										case 472:
																																											goto IL_2456;
																																										case 424:
																																											goto IL_246d;
																																										case 197:
																																										case 397:
																																											goto IL_2484;
																																										case 19:
																																											goto IL_2500;
																																										case 76:
																																											goto IL_250e;
																																										case 216:
																																											goto IL_2521;
																																										case 430:
																																											goto IL_252f;
																																										case 356:
																																											goto IL_253d;
																																										case 24:
																																										case 266:
																																											goto IL_2548;
																																										case 26:
																																											goto IL_255d;
																																										case 366:
																																											goto IL_2570;
																																										case 64:
																																											goto IL_257e;
																																										case 313:
																																										case 370:
																																											goto IL_258c;
																																										case 388:
																																											goto IL_25ca;
																																										case 374:
																																											goto IL_25e1;
																																										case 125:
																																											goto IL_25f4;
																																										case 236:
																																											goto IL_25ff;
																																										case 282:
																																										case 450:
																																											goto IL_260d;
																																										case 506:
																																											goto IL_2621;
																																										case 207:
																																											goto IL_2660;
																																										case 345:
																																											goto IL_267c;
																																										case 118:
																																											goto IL_268a;
																																										case 551:
																																											goto IL_269d;
																																										case 217:
																																										case 227:
																																											goto IL_26a8;
																																										case 376:
																																											goto IL_26c1;
																																										case 184:
																																											goto IL_26d4;
																																										case 455:
																																											goto IL_26e2;
																																										case 300:
																																										case 364:
																																											goto IL_26ed;
																																										case 454:
																																											goto IL_272d;
																																										case 176:
																																											goto IL_2741;
																																										case 346:
																																											goto IL_2754;
																																										case 215:
																																											goto IL_2762;
																																										case 65:
																																										case 183:
																																											goto IL_2770;
																																										case 427:
																																											goto IL_2784;
																																										case 48:
																																											goto IL_27d1;
																																										case 508:
																																											goto IL_27df;
																																										case 99:
																																											goto IL_27f2;
																																										case 63:
																																											goto IL_2800;
																																										case 336:
																																										case 449:
																																											goto IL_280e;
																																										case 182:
																																											goto IL_282b;
																																										case 58:
																																											goto IL_2878;
																																										case 232:
																																											goto IL_2886;
																																										case 1:
																																										case 7:
																																										case 10:
																																										case 11:
																																										case 16:
																																										case 32:
																																										case 45:
																																										case 47:
																																										case 66:
																																										case 80:
																																										case 86:
																																										case 100:
																																										case 103:
																																										case 113:
																																										case 119:
																																										case 127:
																																										case 132:
																																										case 133:
																																										case 135:
																																										case 139:
																																										case 147:
																																										case 153:
																																										case 164:
																																										case 167:
																																										case 186:
																																										case 201:
																																										case 204:
																																										case 219:
																																										case 237:
																																										case 238:
																																										case 242:
																																										case 260:
																																										case 262:
																																										case 265:
																																										case 267:
																																										case 271:
																																										case 289:
																																										case 299:
																																										case 301:
																																										case 302:
																																										case 309:
																																										case 320:
																																										case 331:
																																										case 347:
																																										case 354:
																																										case 355:
																																										case 358:
																																										case 360:
																																										case 390:
																																										case 392:
																																										case 394:
																																										case 395:
																																										case 411:
																																										case 416:
																																										case 429:
																																										case 438:
																																										case 439:
																																										case 446:
																																										case 447:
																																										case 477:
																																										case 478:
																																										case 490:
																																										case 495:
																																										case 504:
																																										case 505:
																																										case 515:
																																										case 520:
																																										case 527:
																																										case 530:
																																										case 539:
																																											goto end_IL_095b;
																																										case 23:
																																										case 30:
																																										case 31:
																																										case 40:
																																										case 59:
																																										case 68:
																																										case 70:
																																										case 82:
																																										case 83:
																																										case 87:
																																										case 93:
																																										case 102:
																																										case 111:
																																										case 112:
																																										case 115:
																																										case 136:
																																										case 169:
																																										case 170:
																																										case 171:
																																										case 188:
																																										case 202:
																																										case 206:
																																										case 212:
																																										case 220:
																																										case 221:
																																										case 231:
																																										case 239:
																																										case 251:
																																										case 253:
																																										case 270:
																																										case 272:
																																										case 286:
																																										case 288:
																																										case 290:
																																										case 291:
																																										case 294:
																																										case 295:
																																										case 318:
																																										case 332:
																																										case 350:
																																										case 359:
																																										case 365:
																																										case 379:
																																										case 383:
																																										case 386:
																																										case 396:
																																										case 405:
																																										case 420:
																																										case 431:
																																										case 444:
																																										case 458:
																																										case 460:
																																										case 462:
																																										case 464:
																																										case 468:
																																										case 475:
																																										case 479:
																																										case 480:
																																										case 488:
																																										case 497:
																																										case 509:
																																										case 521:
																																										case 525:
																																										case 529:
																																										case 537:
																																										case 540:
																																										case 545:
																																										case 548:
																																											goto end_IL_08db;
																																										case 192:
																																											goto end_IL_28a9;
																																										case 249:
																																											goto end_IL_28bc;
																																										case 110:
																																											goto end_IL_28c7;
																																										case 228:
																																											goto end_IL_28d1;
																																										case 442:
																																											goto end_IL_28dc;
																																										case 536:
																																											goto end_IL_28f1;
																																										case 419:
																																											goto end_IL_2901;
																																										case 203:
																																										case 333:
																																											goto end_IL_2911;
																																										case 311:
																																											goto end_IL_2921;
																																										case 507:
																																											goto end_IL_2931;
																																										case 205:
																																											goto end_IL_2941;
																																										case 485:
																																											goto end_IL_2951;
																																										case 486:
																																											goto end_IL_2961;
																																										case 159:
																																										case 342:
																																											return;
																																										}
																																										continue;
																																										end_IL_08db:
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							goto end_IL_0a08;
																																							continue;
																																							end_IL_095b:
																																							break;
																																							IL_095b:;
																																						}
																																						break;
																																						IL_096b:;
																																					}
																																					break;
																																				}
																																				goto IL_0a43;
																																				IL_13b0:
																																				num6--;
																																				goto end_IL_0a08;
																																				IL_0a43:
																																				if (15 > b)
																																				{
																																					break;
																																				}
																																				goto IL_135b;
																																				IL_135b:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																																				goto IL_139c;
																																				IL_139c:
																																				array[num6 - 2] = 0;
																																				goto IL_13b0;
																																			}
																																			break;
																																		}
																																		goto IL_0a33;
																																		IL_12ba:
																																		ptr2 += 16;
																																		goto end_IL_0a08;
																																		IL_0a33:
																																		if (14 > b)
																																		{
																																			goto IL_0a87;
																																		}
																																		goto IL_0adb;
																																		IL_0adb:
																																		ptr2 = ptr + *(int*)(ptr2 + num3);
																																		goto end_IL_0a08;
																																		IL_0a87:
																																		if (13 < b)
																																		{
																																			break;
																																		}
																																		goto IL_0ab5;
																																		IL_0ab5:
																																		if (13 > b)
																																		{
																																			break;
																																		}
																																		goto IL_1285;
																																		IL_1285:
																																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																																		goto IL_129e;
																																		IL_129e:
																																		array[num6] = 1;
																																		goto IL_12ac;
																																		IL_12ac:
																																		num6++;
																																		goto IL_12ba;
																																	}
																																	break;
																																}
																																goto IL_0ac8;
																																IL_147c:
																																ptr2 += 8;
																																goto end_IL_0a08;
																																IL_0ac8:
																																if (12 <= b)
																																{
																																	goto end_IL_0a08;
																																}
																																goto IL_0ba2;
																																IL_0ba2:
																																if (10 >= b)
																																{
																																	goto IL_0bb0;
																																}
																																goto IL_0c43;
																																IL_0bb0:
																																if (10 <= b)
																																{
																																	goto IL_0bbb;
																																}
																																goto IL_0c22;
																																IL_0bbb:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																goto IL_1881;
																																IL_1881:
																																num6 -= 2;
																																num = 540;
																																goto end_IL_0a08;
																																IL_0c22:
																																if (9 < b)
																																{
																																	break;
																																}
																																goto IL_0c30;
																																IL_0c30:
																																if (9 > b)
																																{
																																	break;
																																}
																																goto IL_0dbd;
																																IL_0dbd:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																goto IL_0dfd;
																																IL_0dfd:
																																array[num6 - 2] = 0;
																																goto IL_0e11;
																																IL_0e11:
																																num6--;
																																goto end_IL_0a08;
																																IL_0c43:
																																if (11 < b)
																																{
																																	break;
																																}
																																goto IL_0c51;
																																IL_0c51:
																																if (11 > b)
																																{
																																	break;
																																}
																																goto IL_143c;
																																IL_143c:
																																array[num6] = 0;
																																goto IL_144a;
																																IL_144a:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																																goto IL_146e;
																																IL_146e:
																																num6++;
																																goto IL_147c;
																															}
																															break;
																														}
																														goto IL_0c7a;
																														IL_1852:
																														num6--;
																														goto end_IL_0a08;
																														IL_0c7a:
																														if (8 > b)
																														{
																															goto IL_0e92;
																														}
																														goto IL_1865;
																														IL_0e92:
																														if (4 >= b)
																														{
																															goto IL_0ea0;
																														}
																														goto IL_1015;
																														IL_0ea0:
																														if (4 <= b)
																														{
																															goto IL_0eab;
																														}
																														goto IL_0f07;
																														IL_0eab:
																														array[num6] = 0;
																														goto IL_0eb9;
																														IL_0eb9:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																														goto IL_0edc;
																														IL_0edc:
																														array2[num6] = null;
																														goto IL_0ee6;
																														IL_0ee6:
																														num6++;
																														goto IL_0ef4;
																														IL_0ef4:
																														ptr2 += 8;
																														goto end_IL_0a08;
																														IL_0f07:
																														if (2 >= b)
																														{
																															goto IL_0f15;
																														}
																														goto IL_0ff4;
																														IL_0f15:
																														if (2 > b)
																														{
																															goto IL_0f20;
																														}
																														num = 453;
																														goto IL_0f8d;
																														IL_0f20:
																														if (1 < b)
																														{
																															break;
																														}
																														goto IL_0f2e;
																														IL_0f2e:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_0f3c;
																														IL_0f3c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																														goto IL_0f55;
																														IL_0f55:
																														array[num6] = 0;
																														goto IL_0f63;
																														IL_0f63:
																														num6++;
																														goto IL_0f71;
																														IL_0f71:
																														ptr2 += 8;
																														goto end_IL_0a08;
																														IL_1865:
																														num6--;
																														num = 537;
																														goto end_IL_0a08;
																														IL_0f8d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_0fcd;
																														IL_0fcd:
																														array[num6 - 2] = 0;
																														goto IL_0fe1;
																														IL_0fe1:
																														num6--;
																														goto end_IL_0a08;
																														IL_0ff4:
																														if (3 < b)
																														{
																															break;
																														}
																														goto IL_1002;
																														IL_1002:
																														if (3 > b)
																														{
																															break;
																														}
																														goto IL_11e5;
																														IL_11e5:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_120e;
																														IL_120e:
																														ptr2 += 8;
																														goto IL_121c;
																														IL_121c:
																														num6--;
																														goto end_IL_0a08;
																														IL_1015:
																														if (6 < b)
																														{
																															goto IL_1023;
																														}
																														goto IL_1770;
																														IL_1023:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_1031;
																														IL_1031:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_103f;
																														IL_103f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_107f;
																														IL_107f:
																														array[num6 - 2] = 0;
																														goto IL_1093;
																														IL_1093:
																														num6--;
																														goto end_IL_0a08;
																														IL_1770:
																														if (6 <= b)
																														{
																															goto IL_177b;
																														}
																														goto IL_17e2;
																														IL_177b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_17bb;
																														IL_17bb:
																														array[num6 - 2] = 0;
																														goto IL_17cf;
																														IL_17cf:
																														num6--;
																														goto end_IL_0a08;
																														IL_17e2:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_17f0;
																														IL_17f0:
																														if (5 > b)
																														{
																															break;
																														}
																														goto IL_17fe;
																														IL_17fe:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_183e;
																														IL_183e:
																														array[num6 - 2] = 0;
																														goto IL_1852;
																													}
																													break;
																												}
																												goto IL_10a6;
																												IL_10e0:
																												ptr2 += 8;
																												num = 70;
																												goto end_IL_0a08;
																												IL_10a6:
																												array[num6] = 5;
																												goto IL_10b4;
																												IL_10b4:
																												array2[num6] = ((delegate*<RopeSwingManager>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																												goto IL_10d2;
																												IL_10d2:
																												num6++;
																												goto IL_10e0;
																											}
																											break;
																										}
																										goto IL_0a97;
																										IL_175d:
																										num6 -= 2;
																										goto end_IL_0a08;
																										IL_0a97:
																										if (25 < b)
																										{
																											goto IL_0aa2;
																										}
																										goto IL_0af3;
																										IL_0aa2:
																										if (29 >= b)
																										{
																											goto IL_0cf2;
																										}
																										goto IL_10fc;
																										IL_0cf2:
																										if (29 <= b)
																										{
																											goto IL_0cfd;
																										}
																										goto IL_0d13;
																										IL_0cfd:
																										array[num6 - 1] = 3;
																										goto IL_0d6b;
																										IL_0d6b:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_0daa;
																										IL_0daa:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_0d13:
																										if (27 >= b)
																										{
																											goto IL_0d1e;
																										}
																										goto IL_0d58;
																										IL_0d1e:
																										if (27 > b)
																										{
																											goto IL_0d29;
																										}
																										num = 122;
																										goto IL_0e45;
																										IL_0d29:
																										if (26 < b)
																										{
																											break;
																										}
																										goto IL_0d37;
																										IL_0d37:
																										if (26 > b)
																										{
																											break;
																										}
																										goto IL_12cd;
																										IL_12cd:
																										((delegate*<void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																										goto IL_12e2;
																										IL_12e2:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_12f5:
																										array[num6 - 1] = 0;
																										goto IL_1309;
																										IL_0e45:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 280;
																										goto IL_0e79;
																										IL_0e79:
																										array[num6 - 1] = 0;
																										goto end_IL_0a08;
																										IL_0d58:
																										if (28 < b)
																										{
																											break;
																										}
																										goto IL_1272;
																										IL_1272:
																										if (28 > b)
																										{
																											break;
																										}
																										goto IL_13c3;
																										IL_13c3:
																										((delegate*<PhotonView, void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((PhotonView)array2[num6 - 1]);
																										goto IL_13ec;
																										IL_13ec:
																										num6--;
																										goto IL_13fa;
																										IL_13fa:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_10fc:
																										if (31 >= b)
																										{
																											goto IL_110a;
																										}
																										goto IL_148f;
																										IL_110a:
																										if (31 <= b)
																										{
																											goto IL_1115;
																										}
																										goto IL_1162;
																										IL_1115:
																										array[num6] = 5;
																										goto IL_1123;
																										IL_1123:
																										array2[num6] = ((delegate*<GorillaTagger>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																										goto IL_1141;
																										IL_1141:
																										num6++;
																										goto IL_114f;
																										IL_114f:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_1162:
																										if (30 < b)
																										{
																											break;
																										}
																										goto IL_1170;
																										IL_1170:
																										if (30 > b)
																										{
																											break;
																										}
																										goto IL_117e;
																										IL_117e:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_11be;
																										IL_11be:
																										array[num6 - 2] = 3;
																										goto IL_11d2;
																										IL_11d2:
																										num6--;
																										goto end_IL_0a08;
																										IL_148f:
																										if (32 >= b)
																										{
																											goto IL_149a;
																										}
																										goto IL_1510;
																										IL_149a:
																										if (32 > b)
																										{
																											break;
																										}
																										goto IL_14a8;
																										IL_14a8:
																										array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																										goto IL_14e0;
																										IL_14e0:
																										array[num6 - 1] = 5;
																										goto IL_14f4;
																										IL_14f4:
																										ptr2 += 8;
																										num = 31;
																										goto end_IL_0a08;
																										IL_1510:
																										if (33 < b)
																										{
																											break;
																										}
																										goto IL_151e;
																										IL_151e:
																										if (33 > b)
																										{
																											break;
																										}
																										goto IL_152c;
																										IL_152c:
																										array[num6 - 1] = 5;
																										goto IL_1540;
																										IL_1540:
																										array2[num6 - 1] = ((delegate*<Component, Transform>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																										goto IL_1578;
																										IL_1578:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_0af3:
																										if (25 > b)
																										{
																											goto IL_0b01;
																										}
																										goto IL_12f5;
																										IL_0b01:
																										if (21 < b)
																										{
																											goto IL_0b0f;
																										}
																										goto IL_158b;
																										IL_0b0f:
																										if (23 >= b)
																										{
																											goto IL_0b1a;
																										}
																										goto IL_0b2d;
																										IL_0b1a:
																										if (23 <= b)
																										{
																											goto IL_0c64;
																										}
																										goto IL_122f;
																										IL_0c64:
																										array[num6 - 1] = 3;
																										goto IL_0ca0;
																										IL_0ca0:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_0cdf;
																										IL_0cdf:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_122f:
																										if (22 < b)
																										{
																											break;
																										}
																										goto IL_123d;
																										IL_123d:
																										if (22 > b)
																										{
																											break;
																										}
																										num = 437;
																										goto IL_1254;
																										IL_1309:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_1348;
																										IL_1254:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_140d;
																										IL_140d:
																										array[num6] = 3;
																										goto IL_141b;
																										IL_141b:
																										num6++;
																										goto IL_1429;
																										IL_1429:
																										ptr2 += 16;
																										goto end_IL_0a08;
																										IL_0b2d:
																										if (24 < b)
																										{
																											break;
																										}
																										goto IL_0b3b;
																										IL_0b3b:
																										if (24 > b)
																										{
																											break;
																										}
																										goto IL_0b49;
																										IL_0b49:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0b89;
																										IL_0b89:
																										array[num6 - 2] = 3;
																										goto IL_0c8d;
																										IL_0c8d:
																										num6--;
																										goto end_IL_0a08;
																										IL_158b:
																										if (21 > b)
																										{
																											goto IL_1599;
																										}
																										goto IL_1707;
																										IL_1599:
																										if (19 >= b)
																										{
																											goto IL_15a7;
																										}
																										goto IL_168c;
																										IL_15a7:
																										if (19 <= b)
																										{
																											goto IL_15b2;
																										}
																										goto IL_1611;
																										IL_15b2:
																										array[num6 - 1] = 5;
																										goto IL_15c6;
																										IL_15c6:
																										array2[num6 - 1] = ((delegate*<PhotonView, Player>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((PhotonView)array2[num6 - 1]);
																										goto IL_15fe;
																										IL_15fe:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_1611:
																										if (18 < b)
																										{
																											break;
																										}
																										goto IL_161f;
																										IL_161f:
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_162d;
																										IL_162d:
																										array2[num6 - 1] = ((delegate*<RopeSwingManager, PhotonView>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((RopeSwingManager)array2[num6 - 1]);
																										goto IL_1665;
																										IL_1665:
																										array[num6 - 1] = 5;
																										goto IL_1679;
																										IL_1679:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_168c:
																										if (20 < b)
																										{
																											break;
																										}
																										goto IL_169a;
																										IL_169a:
																										if (20 > b)
																										{
																											break;
																										}
																										num = 534;
																										goto IL_16b1;
																										IL_1348:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_16b1:
																										array[num6] = 5;
																										goto IL_16bf;
																										IL_16bf:
																										array2[num6] = ((delegate*<Player>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																										num = 98;
																										goto IL_16e6;
																										IL_16e6:
																										num6++;
																										goto IL_16f4;
																										IL_16f4:
																										ptr2 += 8;
																										goto end_IL_0a08;
																										IL_1707:
																										ptr2 = ((array2[num6 - 2] == array2[num6 - 1]) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_175d;
																									}
																									break;
																								}
																								goto IL_0a56;
																								IL_0e32:
																								ptr2 += 8;
																								goto end_IL_0a08;
																								IL_0a56:
																								array2[num6] = ((delegate*<Transform>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																								goto IL_0a74;
																								IL_0a74:
																								array[num6] = 5;
																								goto IL_0e24;
																								IL_0e24:
																								num6++;
																								goto IL_0e32;
																							}
																							break;
																						}
																						goto IL_189d;
																						IL_27df:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_189d:
																						if (51 >= b)
																						{
																							goto IL_18ab;
																						}
																						goto IL_2143;
																						IL_18ab:
																						if (51 <= b)
																						{
																							goto IL_18b6;
																						}
																						goto IL_191c;
																						IL_18b6:
																						array[num6 - 1] = 3;
																						goto IL_18ca;
																						IL_18ca:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1909;
																						IL_1909:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_191c:
																						if (42 < b)
																						{
																							goto IL_192a;
																						}
																						num = 225;
																						goto IL_1d0a;
																						IL_192a:
																						if (46 >= b)
																						{
																							goto IL_1938;
																						}
																						goto IL_1b5c;
																						IL_1938:
																						if (46 <= b)
																						{
																							goto IL_1943;
																						}
																						goto IL_19b8;
																						IL_1943:
																						ptr2 = ((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_19a5;
																						IL_19a5:
																						num6 -= 2;
																						goto end_IL_0a08;
																						IL_19b8:
																						if (44 >= b)
																						{
																							goto IL_19c6;
																						}
																						goto IL_1ab0;
																						IL_19c6:
																						if (44 <= b)
																						{
																							goto IL_19d1;
																						}
																						goto IL_1a35;
																						IL_19d1:
																						array[num6 - 1] = 4;
																						goto IL_19e5;
																						IL_19e5:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						goto IL_1a22;
																						IL_1a22:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1a35:
																						if (43 < b)
																						{
																							break;
																						}
																						goto IL_1a43;
																						IL_1a43:
																						if (43 > b)
																						{
																							break;
																						}
																						goto IL_1a51;
																						IL_1a51:
																						array[num6 - 1] = 5;
																						goto IL_1a65;
																						IL_1a65:
																						array2[num6 - 1] = ((delegate*<Component, Transform>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																						goto IL_1a9d;
																						IL_1a9d:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1ab0:
																						if (45 < b)
																						{
																							break;
																						}
																						goto IL_1abe;
																						IL_1abe:
																						if (45 > b)
																						{
																							break;
																						}
																						goto IL_1acc;
																						IL_1acc:
																						array[num6 - 2] = 3;
																						num = 482;
																						goto IL_1ae9;
																						IL_1ae9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<Vector3, Vector3, float>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																						goto IL_1b3b;
																						IL_1b3b:
																						num6--;
																						goto IL_1b49;
																						IL_1b49:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1b5c:
																						if (48 >= b)
																						{
																							goto IL_1b6a;
																						}
																						goto IL_1c1f;
																						IL_1b6a:
																						if (48 > b)
																						{
																							goto IL_1b78;
																						}
																						goto IL_1bfa;
																						IL_1b78:
																						if (47 < b)
																						{
																							break;
																						}
																						goto IL_1b86;
																						IL_1b86:
																						if (47 > b)
																						{
																							break;
																						}
																						goto IL_1b94;
																						IL_1b94:
																						array[num6 - 1] = 3;
																						goto IL_1ba8;
																						IL_1ba8:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_1be7;
																						IL_1be7:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1bfa:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						num = 460;
																						goto end_IL_0a08;
																						IL_1c1f:
																						if (49 >= b)
																						{
																							goto IL_1c2a;
																						}
																						goto IL_1c63;
																						IL_1c2a:
																						if (49 > b)
																						{
																							break;
																						}
																						goto IL_1c38;
																						IL_1c38:
																						array2[num6] = null;
																						goto IL_1c42;
																						IL_1c42:
																						array[num6] = 5;
																						goto IL_1c50;
																						IL_1c50:
																						num6++;
																						goto end_IL_0a08;
																						IL_1c63:
																						if (50 < b)
																						{
																							break;
																						}
																						goto IL_1c71;
																						IL_1c71:
																						if (50 > b)
																						{
																							break;
																						}
																						goto IL_1c7f;
																						IL_1c7f:
																						array[num6 - 2] = 0;
																						goto IL_1c93;
																						IL_1c93:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																						goto IL_1ce0;
																						IL_1ce0:
																						num6--;
																						goto IL_1cee;
																						IL_1cee:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_27f2:
																						if (62 < b)
																						{
																							break;
																						}
																						goto IL_2800;
																						IL_1d0a:
																						if (42 <= b)
																						{
																							goto IL_1d15;
																						}
																						goto IL_1d62;
																						IL_1d15:
																						array[num6] = 5;
																						goto IL_1d23;
																						IL_1d23:
																						array2[num6] = ((delegate*<GorillaTagger>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																						goto IL_1d41;
																						IL_1d41:
																						num6++;
																						goto IL_1d4f;
																						IL_1d4f:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1d62:
																						if (38 >= b)
																						{
																							goto IL_1d70;
																						}
																						goto IL_1fac;
																						IL_1d70:
																						if (38 <= b)
																						{
																							goto IL_1d7e;
																						}
																						goto IL_1e16;
																						IL_1d7e:
																						array[num6 - 2] = 4;
																						num = 5;
																						goto IL_1d9b;
																						IL_1d9b:
																						array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																						goto IL_1dec;
																						IL_1dec:
																						num6--;
																						num = 134;
																						goto IL_1e03;
																						IL_1e03:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1e16:
																						if (36 >= b)
																						{
																							goto IL_1e24;
																						}
																						goto IL_1ef8;
																						IL_1e24:
																						if (36 <= b)
																						{
																							goto IL_1e2f;
																						}
																						goto IL_1e78;
																						IL_1e2f:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																						goto IL_1e49;
																						IL_1e49:
																						array[num6] = 3;
																						goto IL_1e57;
																						IL_1e57:
																						num6++;
																						goto IL_1e65;
																						IL_1e65:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1e78:
																						if (35 < b)
																						{
																							break;
																						}
																						goto IL_1e86;
																						IL_1e86:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_1e94;
																						IL_1e94:
																						array[num6 - 1] = 4;
																						goto IL_1ea8;
																						IL_1ea8:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						goto IL_1ee5;
																						IL_1ee5:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1ef8:
																						if (37 < b)
																						{
																							break;
																						}
																						goto IL_1f06;
																						IL_1f06:
																						if (37 > b)
																						{
																							break;
																						}
																						goto IL_1f14;
																						IL_1f14:
																						array[num6 - 3] = 5;
																						goto IL_1f28;
																						IL_1f28:
																						array2[num6 - 3] = ((delegate*<float, float, float, object>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																						goto IL_1f8b;
																						IL_1f8b:
																						num6 -= 2;
																						goto IL_1f99;
																						IL_1f99:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_1fac:
																						if (40 >= b)
																						{
																							goto IL_1fba;
																						}
																						goto IL_20ba;
																						IL_1fba:
																						if (40 > b)
																						{
																							goto IL_1fc8;
																						}
																						num = 387;
																						goto IL_2054;
																						IL_1fc8:
																						if (39 < b)
																						{
																							break;
																						}
																						goto IL_1fd6;
																						IL_1fd6:
																						if (39 > b)
																						{
																							break;
																						}
																						num = 6;
																						goto IL_1fed;
																						IL_280e:
																						array[num6 - 2] = 5;
																						num = 182;
																						goto IL_282b;
																						IL_1fed:
																						((delegate*<Transform, Vector3, void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																						goto IL_202a;
																						IL_202a:
																						num6 -= 2;
																						goto IL_2038;
																						IL_2038:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2800:
																						if (62 > b)
																						{
																							break;
																						}
																						goto IL_280e;
																						IL_2054:
																						array[num6 - 1] = 3;
																						goto IL_2068;
																						IL_2068:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_20a7;
																						IL_20a7:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_20ba:
																						if (41 < b)
																						{
																							break;
																						}
																						goto IL_20c8;
																						IL_20c8:
																						if (41 > b)
																						{
																							break;
																						}
																						goto IL_20d6;
																						IL_20d6:
																						array[num6 - 1] = 4;
																						goto IL_20ea;
																						IL_20ea:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						num = 443;
																						goto IL_2130;
																						IL_2130:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2143:
																						if (59 >= b)
																						{
																							goto IL_2151;
																						}
																						goto IL_2521;
																						IL_2151:
																						if (59 <= b)
																						{
																							goto IL_215c;
																						}
																						goto IL_21c2;
																						IL_215c:
																						array[num6 - 1] = 3;
																						goto IL_2170;
																						IL_2170:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_21af;
																						IL_21af:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_21c2:
																						if (55 >= b)
																						{
																							goto IL_21d0;
																						}
																						goto IL_238c;
																						IL_21d0:
																						if (55 <= b)
																						{
																							goto IL_21db;
																						}
																						goto IL_221e;
																						IL_21db:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((Transform[])array2[num6 - 1]).LongLength;
																						goto IL_2205;
																						IL_2205:
																						array[num6 - 1] = 2;
																						goto end_IL_0a08;
																						IL_221e:
																						if (53 >= b)
																						{
																							goto IL_222c;
																						}
																						goto IL_2311;
																						IL_222c:
																						if (53 <= b)
																						{
																							goto IL_2237;
																						}
																						goto IL_229c;
																						IL_2237:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<GorillaRopeSwing, int>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 1]);
																						goto IL_2275;
																						IL_2275:
																						array[num6 - 1] = 0;
																						goto IL_2289;
																						IL_2289:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_229c:
																						if (52 < b)
																						{
																							break;
																						}
																						goto IL_22aa;
																						IL_22aa:
																						if (52 > b)
																						{
																							break;
																						}
																						num = 246;
																						goto IL_22c1;
																						IL_282b:
																						array2[num6 - 2] = ((delegate*<GorillaRopeSwing, int, Transform>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_2878;
																						IL_22c1:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_22d9;
																						IL_22d9:
																						array[num6] = 5;
																						num = 29;
																						goto IL_22f0;
																						IL_22f0:
																						num6++;
																						goto IL_22fe;
																						IL_22fe:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2311:
																						if (54 < b)
																						{
																							break;
																						}
																						goto IL_231f;
																						IL_231f:
																						if (54 > b)
																						{
																							break;
																						}
																						goto IL_232d;
																						IL_232d:
																						array2[num6 - 1] = ((delegate*<GorillaRopeSwing, Transform[]>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 1]);
																						goto IL_2365;
																						IL_2365:
																						array[num6 - 1] = 5;
																						goto IL_2379;
																						IL_2379:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_238c:
																						if (57 >= b)
																						{
																							goto IL_239a;
																						}
																						goto IL_2456;
																						IL_239a:
																						if (57 <= b)
																						{
																							goto IL_23a5;
																						}
																						goto IL_23f6;
																						IL_23a5:
																						array2[num6] = (Vector3)array5[*(int*)(ptr2 + num3)];
																						goto IL_23c7;
																						IL_23c7:
																						array[num6] = 4;
																						goto IL_23d5;
																						IL_23d5:
																						num6++;
																						goto IL_23e3;
																						IL_23e3:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_23f6:
																						if (56 < b)
																						{
																							break;
																						}
																						goto IL_2404;
																						IL_2404:
																						if (56 > b)
																						{
																							break;
																						}
																						goto IL_2412;
																						IL_2412:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_243d;
																						IL_243d:
																						array[num6 - 1] = 0;
																						goto end_IL_0a08;
																						IL_2456:
																						if (58 < b)
																						{
																							break;
																						}
																						num = 424;
																						goto IL_246d;
																						IL_2878:
																						num6--;
																						goto IL_2886;
																						IL_246d:
																						if (58 > b)
																						{
																							break;
																						}
																						num = 397;
																						goto IL_2484;
																						IL_2886:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2484:
																						((delegate*<RopeSwingManager, int, int, Vector3, bool, void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((RopeSwingManager)array2[num6 - 5], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 4]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]), (Vector3)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																						goto IL_2500;
																						IL_2500:
																						num6 -= 5;
																						goto IL_250e;
																						IL_250e:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2521:
																						if (63 < b)
																						{
																							goto IL_252f;
																						}
																						goto IL_269d;
																						IL_252f:
																						if (65 >= b)
																						{
																							goto IL_253d;
																						}
																						goto IL_25f4;
																						IL_253d:
																						if (65 <= b)
																						{
																							goto IL_2548;
																						}
																						goto IL_2570;
																						IL_2548:
																						((delegate*<void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])();
																						goto IL_255d;
																						IL_255d:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_2570:
																						if (64 < b)
																						{
																							break;
																						}
																						goto IL_257e;
																						IL_257e:
																						if (64 > b)
																						{
																							break;
																						}
																						goto IL_258c;
																						IL_258c:
																						((delegate*<Behaviour, bool, void>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																						goto IL_25ca;
																						IL_25ca:
																						num6 -= 2;
																						num = 374;
																						goto IL_25e1;
																						IL_25e1:
																						ptr2 += 8;
																						goto end_IL_0a08;
																						IL_25f4:
																						if (66 >= b)
																						{
																							goto IL_25ff;
																						}
																						goto IL_267c;
																						IL_25ff:
																						if (66 > b)
																						{
																							break;
																						}
																						goto IL_260d;
																						IL_260d:
																						array[num6 - 1] = 3;
																						goto IL_2621;
																						IL_2621:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_2660;
																						IL_2660:
																						ptr2 += 8;
																						num = 171;
																						goto end_IL_0a08;
																						IL_267c:
																						if (67 < b)
																						{
																							break;
																						}
																						goto IL_268a;
																						IL_268a:
																						if (67 > b)
																						{
																						}
																						break;
																						IL_269d:
																						if (63 <= b)
																						{
																							goto IL_26a8;
																						}
																						goto IL_26d4;
																						IL_26a8:
																						global::_003CModule_003E.transform_6 = (Transform)array2[num6 - 1];
																						goto IL_26c1;
																						IL_26c1:
																						num6--;
																						goto end_IL_0a08;
																						IL_26d4:
																						if (61 >= b)
																						{
																							goto IL_26e2;
																						}
																						goto IL_27f2;
																						IL_26e2:
																						if (61 <= b)
																						{
																							goto IL_26ed;
																						}
																						goto IL_2754;
																						IL_26ed:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_272d;
																						IL_272d:
																						array[num6 - 2] = 3;
																						goto IL_2741;
																						IL_2741:
																						num6--;
																						goto end_IL_0a08;
																						IL_2754:
																						if (60 < b)
																						{
																							break;
																						}
																						goto IL_2762;
																						IL_2762:
																						if (60 > b)
																						{
																							break;
																						}
																						goto IL_2770;
																						IL_2770:
																						array[num6 - 2] = 0;
																						goto IL_2784;
																						IL_2784:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)LocallocDoesTextualDefinitionMatchTextualReference[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(RopeSwingManager)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																						goto IL_27d1;
																						IL_27d1:
																						num6--;
																						goto IL_27df;
																					}
																					break;
																					IL_09f8:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_0a08:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_28a9:
																break;
															}
															continue;
															end_IL_28bc:
															break;
														}
														continue;
														end_IL_28c7:
														break;
													}
													continue;
													end_IL_28d1:
													break;
												}
												continue;
												end_IL_28dc:
												break;
											}
											continue;
											end_IL_28f1:
											break;
										}
										continue;
										end_IL_2901:
										break;
									}
									continue;
									end_IL_2911:
									break;
								}
								continue;
								end_IL_2921:
								break;
							}
							continue;
							end_IL_2931:
							break;
						}
						continue;
						end_IL_2941:
						break;
					}
					continue;
					end_IL_2951:
					break;
				}
				continue;
				end_IL_2961:
				break;
			}
		}
	}

	private unsafe GorillaRopeSwing method_2()
	{
		int num = 502;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ElementCountGetDecoder.setUIContextUser);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 276;
																	while (true)
																	{
																		IL_08cf:
																		if (b >= 1)
																		{
																			while (b <= 62)
																			{
																				while (true)
																				{
																					IL_08af:
																					if (31 >= b)
																					{
																						while (true)
																						{
																							IL_089f:
																							if (31 > b)
																							{
																								while (true)
																								{
																									IL_088f:
																									if (15 < b)
																									{
																										while (true)
																										{
																											IL_087f:
																											if (23 >= b)
																											{
																												while (true)
																												{
																													IL_086f:
																													if (23 > b)
																													{
																														while (true)
																														{
																															IL_085f:
																															if (19 < b)
																															{
																																while (true)
																																{
																																	IL_084f:
																																	if (21 < b)
																																	{
																																		while (22 >= b)
																																		{
																																			num = 515;
																																			while (true)
																																			{
																																				if (num != 515)
																																				{
																																					if (num != 1496)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 302:
																																						goto IL_083c;
																																					case 341:
																																						goto IL_084f;
																																					case 457:
																																						goto IL_085f;
																																					case 153:
																																						goto IL_086f;
																																					case 256:
																																						goto IL_087f;
																																					case 437:
																																						goto IL_088f;
																																					case 499:
																																						goto IL_089f;
																																					case 497:
																																						goto IL_08af;
																																					case 80:
																																						goto IL_08bf;
																																					case 276:
																																						goto IL_08cf;
																																					case 409:
																																						goto end_IL_08cf;
																																					case 188:
																																					case 495:
																																						goto end_IL_08df;
																																					case 18:
																																						goto IL_0903;
																																					case 87:
																																					case 167:
																																						goto IL_0911;
																																					case 103:
																																						goto IL_092e;
																																					case 46:
																																						goto IL_096d;
																																					case 227:
																																						goto IL_0980;
																																					case 211:
																																						goto IL_098b;
																																					case 4:
																																					case 196:
																																						goto IL_0999;
																																					case 220:
																																						goto IL_09b2;
																																					case 270:
																																						goto IL_09c2;
																																					case 232:
																																						goto IL_09d0;
																																					case 15:
																																						goto IL_09de;
																																					case 168:
																																						goto IL_09ec;
																																					case 101:
																																						goto IL_09fa;
																																					case 281:
																																						goto IL_0a0d;
																																					case 12:
																																						goto IL_0a18;
																																					case 35:
																																						goto IL_0a26;
																																					case 65:
																																						goto IL_0a34;
																																					case 172:
																																						goto IL_0a47;
																																					case 235:
																																						goto IL_0a55;
																																					case 47:
																																						goto IL_0a60;
																																					case 14:
																																						goto IL_0a6e;
																																					case 94:
																																					case 263:
																																						goto IL_0a81;
																																					case 79:
																																					case 324:
																																						goto IL_0a9d;
																																					case 202:
																																						goto IL_0aef;
																																					case 338:
																																						goto IL_0b02;
																																					case 85:
																																						goto IL_0b0d;
																																					case 274:
																																						goto IL_0b1d;
																																					case 26:
																																					case 120:
																																						goto IL_0b2b;
																																					case 356:
																																						goto IL_0b43;
																																					case 60:
																																					case 293:
																																						goto IL_0b51;
																																					case 100:
																																						goto IL_0b92;
																																					case 290:
																																						goto IL_0ba6;
																																					case 367:
																																						goto IL_0bb9;
																																					case 388:
																																						goto IL_0bcc;
																																					case 278:
																																						goto IL_0bda;
																																					case 389:
																																						goto IL_0bed;
																																					case 96:
																																						goto IL_0bfb;
																																					case 242:
																																						goto IL_0c09;
																																					case 396:
																																						goto IL_0c1c;
																																					case 6:
																																					case 230:
																																						goto IL_0c27;
																																					case 255:
																																						goto IL_0c67;
																																					case 231:
																																						goto IL_0c7b;
																																					case 186:
																																						goto IL_0c8e;
																																					case 68:
																																						goto IL_0c99;
																																					case 357:
																																						goto IL_0cac;
																																					case 393:
																																						goto IL_0cba;
																																					case 114:
																																					case 148:
																																						goto IL_0cc5;
																																					case 182:
																																						goto IL_0d05;
																																					case 58:
																																						goto IL_0d19;
																																					case 314:
																																						goto IL_0d2c;
																																					case 208:
																																						goto IL_0d3a;
																																					case 184:
																																						goto IL_0d4d;
																																					case 130:
																																						goto IL_0d5b;
																																					case 398:
																																						goto IL_0d6e;
																																					case 16:
																																					case 106:
																																						goto IL_0d85;
																																					case 408:
																																						goto IL_0da3;
																																					case 43:
																																					case 176:
																																						goto IL_0db1;
																																					case 322:
																																						goto IL_0dc5;
																																					case 269:
																																						goto IL_0e0d;
																																					case 20:
																																					case 419:
																																						goto IL_0e20;
																																					case 243:
																																						goto IL_0e44;
																																					case 225:
																																						goto IL_0e52;
																																					case 282:
																																						goto IL_0e60;
																																					case 420:
																																						goto IL_0e73;
																																					case 415:
																																						goto IL_0e81;
																																					case 74:
																																						goto IL_0e8f;
																																					case 69:
																																					case 316:
																																						goto IL_0e9a;
																																					case 413:
																																						goto IL_0eae;
																																					case 319:
																																						goto IL_0ef2;
																																					case 147:
																																						goto IL_0efd;
																																					case 348:
																																						goto IL_0f14;
																																					case 359:
																																						goto IL_0f27;
																																					case 56:
																																					case 241:
																																						goto IL_0f32;
																																					case 112:
																																						goto IL_0f46;
																																					case 272:
																																						goto IL_0f85;
																																					case 394:
																																						goto IL_0f98;
																																					case 5:
																																						goto IL_0fab;
																																					case 75:
																																						goto IL_0fb6;
																																					case 51:
																																					case 139:
																																						goto IL_0fc1;
																																					case 245:
																																						goto IL_0feb;
																																					case 321:
																																						goto IL_100d;
																																					case 149:
																																						goto IL_101b;
																																					case 37:
																																						goto IL_102e;
																																					case 399:
																																						goto IL_103c;
																																					case 107:
																																					case 423:
																																						goto IL_1058;
																																					case 234:
																																						goto IL_1072;
																																					case 135:
																																						goto IL_1080;
																																					case 361:
																																						goto IL_108e;
																																					case 424:
																																						goto IL_10a1;
																																					case 360:
																																						goto IL_10af;
																																					case 7:
																																					case 67:
																																						goto IL_10bd;
																																					case 221:
																																					case 431:
																																						goto IL_10db;
																																					case 49:
																																						goto IL_10ef;
																																					case 141:
																																						goto IL_112e;
																																					case 21:
																																					case 434:
																																						goto IL_1141;
																																					case 169:
																																						goto IL_116c;
																																					case 435:
																																						goto IL_1185;
																																					case 128:
																																					case 195:
																																						goto IL_1190;
																																					case 358:
																																						goto IL_11c8;
																																					case 36:
																																						goto IL_11dc;
																																					case 342:
																																						goto IL_11ef;
																																					case 438:
																																						goto IL_1202;
																																					case 116:
																																						goto IL_1254;
																																					case 228:
																																						goto IL_1262;
																																					case 440:
																																						goto IL_1275;
																																					case 237:
																																						goto IL_1283;
																																					case 446:
																																						goto IL_1296;
																																					case 131:
																																					case 418:
																																						goto IL_12a4;
																																					case 57:
																																						goto IL_12bd;
																																					case 448:
																																						goto IL_12d0;
																																					case 99:
																																					case 254:
																																						goto IL_12de;
																																					case 326:
																																						goto IL_12f7;
																																					case 410:
																																					case 450:
																																						goto IL_130a;
																																					case 111:
																																						goto IL_1343;
																																					case 385:
																																						goto IL_1357;
																																					case 453:
																																						goto IL_136a;
																																					case 206:
																																					case 455:
																																						goto IL_137d;
																																					case 129:
																																						goto IL_139b;
																																					case 223:
																																						goto IL_13a9;
																																					case 249:
																																						goto IL_13b7;
																																					case 461:
																																						goto IL_13ca;
																																					case 386:
																																						goto IL_13d8;
																																					case 180:
																																					case 441:
																																						goto IL_13e3;
																																					case 439:
																																						goto IL_13fc;
																																					case 368:
																																						goto IL_140f;
																																					case 30:
																																						goto IL_141d;
																																					case 181:
																																						goto IL_142b;
																																					case 383:
																																						goto IL_1439;
																																					case 391:
																																						goto IL_1447;
																																					case 224:
																																						goto IL_1455;
																																					case 144:
																																					case 353:
																																						goto IL_1463;
																																					case 189:
																																						goto IL_1477;
																																					case 214:
																																						goto IL_14b4;
																																					case 286:
																																						goto IL_14c7;
																																					case 350:
																																						goto IL_14d5;
																																					case 379:
																																						goto IL_14e3;
																																					case 436:
																																						goto IL_14f1;
																																					case 136:
																																					case 343:
																																						goto IL_14ff;
																																					case 82:
																																						goto IL_155d;
																																					case 253:
																																						goto IL_1579;
																																					case 124:
																																					case 404:
																																						goto IL_1587;
																																					case 143:
																																						goto IL_159b;
																																					case 273:
																																						goto IL_15ed;
																																					case 425:
																																						goto IL_15fb;
																																					case 349:
																																						goto IL_160e;
																																					case 285:
																																						goto IL_1625;
																																					case 55:
																																					case 70:
																																						goto IL_163c;
																																					case 260:
																																						goto IL_1674;
																																					case 352:
																																						goto IL_1691;
																																					case 199:
																																						goto IL_16ad;
																																					case 123:
																																					case 429:
																																						goto IL_16b8;
																																					case 371:
																																						goto IL_16cc;
																																					case 267:
																																						goto IL_170b;
																																					case 154:
																																						goto IL_171e;
																																					case 309:
																																						goto IL_172c;
																																					case 311:
																																						goto IL_173a;
																																					case 289:
																																						goto IL_1748;
																																					case 19:
																																					case 377:
																																						goto IL_1756;
																																					case 215:
																																						goto IL_1796;
																																					case 73:
																																						goto IL_17aa;
																																					case 284:
																																					case 291:
																																						goto IL_17c6;
																																					case 17:
																																						goto IL_17ea;
																																					case 296:
																																						goto IL_17f8;
																																					case 22:
																																						goto IL_1806;
																																					case 422:
																																						goto IL_1819;
																																					case 387:
																																						goto IL_1827;
																																					case 83:
																																					case 456:
																																						goto IL_1835;
																																					case 458:
																																						goto IL_184f;
																																					case 25:
																																					case 463:
																																						goto IL_1862;
																																					case 395:
																																						goto IL_1880;
																																					case 34:
																																						goto IL_188e;
																																					case 239:
																																						goto IL_189c;
																																					case 354:
																																					case 464:
																																						goto IL_18af;
																																					case 54:
																																					case 466:
																																						goto IL_18f4;
																																					case 468:
																																						goto IL_1907;
																																					case 279:
																																					case 459:
																																						goto IL_1915;
																																					case 460:
																																					case 470:
																																						goto IL_192e;
																																					case 193:
																																						goto IL_194b;
																																					case 160:
																																						goto IL_1988;
																																					case 244:
																																					case 474:
																																						goto IL_199b;
																																					case 426:
																																						goto IL_19b9;
																																					case 317:
																																						goto IL_19c7;
																																					case 213:
																																						goto IL_19d5;
																																					case 476:
																																						goto IL_19e8;
																																					case 258:
																																						goto IL_19fc;
																																					case 479:
																																						goto IL_1a0f;
																																					case 306:
																																						goto IL_1a1d;
																																					case 312:
																																						goto IL_1a2b;
																																					case 481:
																																						goto IL_1a3e;
																																					case 330:
																																						goto IL_1a55;
																																					case 301:
																																					case 345:
																																						goto IL_1a6c;
																																					case 191:
																																						goto IL_1ace;
																																					case 384:
																																					case 482:
																																						goto IL_1ae1;
																																					case 300:
																																						goto IL_1b21;
																																					case 125:
																																						goto IL_1b35;
																																					case 483:
																																						goto IL_1b48;
																																					case 117:
																																						goto IL_1b56;
																																					case 133:
																																					case 332:
																																						goto IL_1b64;
																																					case 140:
																																						goto IL_1b78;
																																					case 444:
																																						goto IL_1bb0;
																																					case 488:
																																						goto IL_1bc3;
																																					case 369:
																																						goto IL_1bce;
																																					case 9:
																																					case 248:
																																						goto IL_1bd9;
																																					case 137:
																																						goto IL_1bed;
																																					case 150:
																																						goto IL_1c00;
																																					case 42:
																																						goto IL_1c0e;
																																					case 257:
																																					case 323:
																																						goto IL_1c1c;
																																					case 280:
																																						goto IL_1c26;
																																					case 236:
																																						goto IL_1c34;
																																					case 365:
																																						goto IL_1c47;
																																					case 190:
																																						goto IL_1c55;
																																					case 192:
																																					case 402:
																																						goto IL_1c63;
																																					case 166:
																																						goto IL_1c7c;
																																					case 200:
																																						goto IL_1c93;
																																					case 351:
																																						goto IL_1ca1;
																																					case 490:
																																						goto IL_1cbd;
																																					case 414:
																																						goto IL_1ccb;
																																					case 320:
																																					case 381:
																																						goto IL_1cd9;
																																					case 432:
																																						goto IL_1d19;
																																					case 187:
																																						goto IL_1d2d;
																																					case 491:
																																						goto IL_1d40;
																																					case 427:
																																						goto IL_1d4e;
																																					case 347:
																																						goto IL_1d5c;
																																					case 376:
																																					case 492:
																																						goto IL_1d6f;
																																					case 487:
																																						goto IL_1d86;
																																					case 0:
																																						goto IL_1da9;
																																					case 407:
																																						goto IL_1db3;
																																					case 71:
																																						goto IL_1dc1;
																																					case 238:
																																					case 493:
																																						goto IL_1dd4;
																																					case 355:
																																						goto IL_1dfd;
																																					case 375:
																																						goto IL_1e0b;
																																					case 38:
																																					case 494:
																																						goto IL_1e1e;
																																					case 310:
																																						goto IL_1e5e;
																																					case 119:
																																						goto IL_1e72;
																																					case 496:
																																						goto IL_1e8e;
																																					case 158:
																																						goto IL_1ecd;
																																					case 507:
																																						goto IL_1ee9;
																																					case 157:
																																						goto IL_1ef7;
																																					case 27:
																																						goto IL_1f05;
																																					case 430:
																																						goto IL_1f13;
																																					case 29:
																																					case 76:
																																						goto IL_1f21;
																																					case 222:
																																						goto IL_1f35;
																																					case 53:
																																						goto IL_1f87;
																																					case 44:
																																						goto IL_1f95;
																																					case 247:
																																					case 447:
																																						goto IL_1fb1;
																																					case 2:
																																						goto IL_1fcb;
																																					case 171:
																																						goto IL_1fde;
																																					case 264:
																																						goto IL_1fec;
																																					case 251:
																																					case 373:
																																						goto IL_1ffa;
																																					case 61:
																																						goto IL_203a;
																																					case 203:
																																						goto IL_204e;
																																					case 145:
																																					case 337:
																																						goto IL_206f;
																																					case 428:
																																						goto IL_2093;
																																					case 252:
																																						goto IL_20aa;
																																					case 45:
																																						goto IL_20b8;
																																					case 500:
																																						goto IL_20cb;
																																					case 185:
																																						goto IL_20d9;
																																					case 98:
																																					case 400:
																																						goto IL_20e4;
																																					case 151:
																																						goto IL_20fe;
																																					case 95:
																																						goto IL_2111;
																																					case 364:
																																						goto IL_211f;
																																					case 89:
																																						goto IL_212d;
																																					case 198:
																																					case 201:
																																						goto IL_213b;
																																					case 23:
																																						goto IL_217b;
																																					case 433:
																																						goto IL_218f;
																																					case 489:
																																						goto IL_21ab;
																																					case 179:
																																					case 292:
																																						goto IL_21b6;
																																					case 412:
																																						goto IL_21ca;
																																					case 90:
																																						goto IL_2209;
																																					case 508:
																																						goto end_IL_0829;
																																					case 485:
																																						goto IL_2233;
																																					case 1:
																																					case 92:
																																						goto IL_2241;
																																					case 299:
																																						goto IL_22af;
																																					case 451:
																																						goto IL_22c2;
																																					case 86:
																																						goto IL_22d0;
																																					case 163:
																																					case 304:
																																						goto IL_22db;
																																					case 271:
																																						goto IL_22f3;
																																					case 115:
																																						goto IL_2301;
																																					case 207:
																																						goto IL_230f;
																																					case 506:
																																						goto IL_2322;
																																					case 313:
																																						goto IL_2330;
																																					case 93:
																																					case 259:
																																						goto IL_233e;
																																					case 261:
																																						goto IL_2352;
																																					case 62:
																																						goto IL_2391;
																																					case 161:
																																						goto IL_23a4;
																																					case 480:
																																						goto IL_23b2;
																																					case 31:
																																					case 333:
																																						goto IL_23c0;
																																					case 469:
																																						goto IL_23f8;
																																					case 443:
																																						goto IL_240c;
																																					case 372:
																																					case 442:
																																						goto IL_2425;
																																					case 175:
																																						goto IL_2439;
																																					case 218:
																																						goto IL_2471;
																																					case 11:
																																					case 24:
																																					case 33:
																																					case 48:
																																					case 66:
																																					case 88:
																																					case 91:
																																					case 97:
																																					case 102:
																																					case 104:
																																					case 105:
																																					case 113:
																																					case 118:
																																					case 122:
																																					case 127:
																																					case 138:
																																					case 142:
																																					case 152:
																																					case 159:
																																					case 162:
																																					case 165:
																																					case 174:
																																					case 194:
																																					case 204:
																																					case 205:
																																					case 209:
																																					case 219:
																																					case 229:
																																					case 233:
																																					case 262:
																																					case 265:
																																					case 268:
																																					case 275:
																																					case 288:
																																					case 294:
																																					case 297:
																																					case 305:
																																					case 308:
																																					case 331:
																																					case 336:
																																					case 340:
																																					case 344:
																																					case 346:
																																					case 362:
																																					case 363:
																																					case 366:
																																					case 374:
																																					case 378:
																																					case 380:
																																					case 382:
																																					case 390:
																																					case 392:
																																					case 405:
																																					case 416:
																																					case 417:
																																					case 445:
																																					case 449:
																																					case 473:
																																					case 475:
																																					case 477:
																																					case 478:
																																					case 486:
																																					case 498:
																																					case 503:
																																					case 504:
																																						goto end_IL_083c;
																																					case 10:
																																					case 13:
																																					case 28:
																																					case 32:
																																					case 39:
																																					case 40:
																																					case 41:
																																					case 50:
																																					case 52:
																																					case 59:
																																					case 63:
																																					case 72:
																																					case 77:
																																					case 81:
																																					case 84:
																																					case 108:
																																					case 109:
																																					case 110:
																																					case 126:
																																					case 132:
																																					case 134:
																																					case 146:
																																					case 155:
																																					case 156:
																																					case 170:
																																					case 173:
																																					case 177:
																																					case 178:
																																					case 183:
																																					case 197:
																																					case 210:
																																					case 212:
																																					case 216:
																																					case 217:
																																					case 226:
																																					case 240:
																																					case 246:
																																					case 250:
																																					case 266:
																																					case 277:
																																					case 283:
																																					case 287:
																																					case 298:
																																					case 303:
																																					case 307:
																																					case 318:
																																					case 325:
																																					case 327:
																																					case 328:
																																					case 329:
																																					case 335:
																																					case 370:
																																					case 397:
																																					case 401:
																																					case 403:
																																					case 406:
																																					case 411:
																																					case 421:
																																					case 452:
																																					case 454:
																																					case 462:
																																					case 467:
																																					case 471:
																																					case 472:
																																					case 484:
																																						goto end_IL_08f8;
																																					case 64:
																																						goto end_IL_2494;
																																					case 505:
																																						goto end_IL_24a7;
																																					case 315:
																																						goto end_IL_24b1;
																																					case 334:
																																						goto end_IL_24bc;
																																					case 295:
																																						goto end_IL_24cc;
																																					case 339:
																																					case 465:
																																						goto end_IL_24dc;
																																					case 164:
																																						goto end_IL_24ec;
																																					case 78:
																																						goto end_IL_24fc;
																																					case 121:
																																						goto end_IL_250c;
																																					case 501:
																																						goto end_IL_251c;
																																					case 502:
																																						goto end_IL_252c;
																																					case 3:
																																					case 8:
																																						goto IL_2547;
																																					}
																																					continue;
																																				}
																																				if (22 > b)
																																				{
																																					goto end_IL_083c;
																																				}
																																				goto IL_206f;
																																				IL_2093:
																																				array[num6] = 3;
																																				num = 252;
																																				goto IL_20aa;
																																				IL_20b8:
																																				ptr2 += 8;
																																				goto end_IL_08f8;
																																				IL_20aa:
																																				num6++;
																																				goto IL_20b8;
																																				IL_206f:
																																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																																				goto IL_2093;
																																				continue;
																																				end_IL_0829:
																																				break;
																																			}
																																			goto IL_221c;
																																			continue;
																																			end_IL_083c:
																																			break;
																																			IL_083c:;
																																		}
																																		break;
																																	}
																																	goto IL_0da3;
																																	IL_1e72:
																																	num6--;
																																	num = 329;
																																	goto end_IL_08f8;
																																	IL_0da3:
																																	if (21 <= b)
																																	{
																																		goto IL_0db1;
																																	}
																																	goto IL_1275;
																																	IL_0db1:
																																	array[num6 - 1] = 0;
																																	goto IL_0dc5;
																																	IL_0dc5:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																	num = 269;
																																	goto IL_0e0d;
																																	IL_0e0d:
																																	ptr2 += 8;
																																	goto end_IL_08f8;
																																	IL_1275:
																																	if (20 < b)
																																	{
																																		break;
																																	}
																																	goto IL_1283;
																																	IL_1283:
																																	if (20 > b)
																																	{
																																		break;
																																	}
																																	goto IL_1e1e;
																																	IL_1e1e:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	goto IL_1e5e;
																																	IL_1e5e:
																																	array[num6 - 2] = 3;
																																	goto IL_1e72;
																																}
																																break;
																															}
																															goto IL_0903;
																															IL_1ca1:
																															ptr2 += 16;
																															num = 298;
																															goto end_IL_08f8;
																															IL_0903:
																															if (19 <= b)
																															{
																																goto IL_0911;
																															}
																															goto IL_1bc3;
																															IL_0911:
																															array[num6 - 1] = 3;
																															num = 103;
																															goto IL_092e;
																															IL_092e:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																															goto IL_096d;
																															IL_096d:
																															ptr2 += 8;
																															goto end_IL_08f8;
																															IL_1bc3:
																															if (17 >= b)
																															{
																																goto IL_1bce;
																															}
																															goto IL_1c47;
																															IL_1bce:
																															if (17 <= b)
																															{
																																goto IL_1bd9;
																															}
																															goto IL_1c00;
																															IL_1bd9:
																															global::_003CModule_003E.gorillaRopeSwing_0 = (GorillaRopeSwing)array2[num6 - 1];
																															goto IL_1bed;
																															IL_1bed:
																															num6--;
																															goto end_IL_08f8;
																															IL_1c00:
																															if (16 < b)
																															{
																																break;
																															}
																															goto IL_1c0e;
																															IL_1c0e:
																															if (16 > b)
																															{
																																break;
																															}
																															goto IL_1c1c;
																															IL_1c1c:
																															array2[num6] = null;
																															goto IL_1c26;
																															IL_1c26:
																															array[num6] = 5;
																															goto IL_1c34;
																															IL_1c34:
																															num6++;
																															goto end_IL_08f8;
																															IL_1c47:
																															if (18 < b)
																															{
																																break;
																															}
																															goto IL_1c55;
																															IL_1c55:
																															if (18 > b)
																															{
																																break;
																															}
																															goto IL_1c63;
																															IL_1c63:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																															goto IL_1c7c;
																															IL_1c7c:
																															array[num6] = 3;
																															num = 200;
																															goto IL_1c93;
																															IL_1c93:
																															num6++;
																															goto IL_1ca1;
																														}
																														break;
																													}
																													goto IL_0e20;
																													IL_0e60:
																													ptr2 += 8;
																													goto end_IL_08f8;
																													IL_0e20:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																													goto IL_0e44;
																													IL_0e44:
																													array[num6] = 3;
																													goto IL_0e52;
																													IL_0e52:
																													num6++;
																													goto IL_0e60;
																												}
																												break;
																											}
																											goto IL_20cb;
																											IL_23c0:
																											array2[num6 - 1] = ((delegate*<Class20, GorillaRopeSwing>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Class20)array2[num6 - 1]);
																											goto IL_23f8;
																											IL_20cb:
																											if (27 >= b)
																											{
																												goto IL_20d9;
																											}
																											goto IL_22c2;
																											IL_20d9:
																											if (27 <= b)
																											{
																												goto IL_20e4;
																											}
																											goto IL_2111;
																											IL_20e4:
																											global::_003CModule_003E.float_40 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_20fe;
																											IL_20fe:
																											num6--;
																											goto end_IL_08f8;
																											IL_2111:
																											if (25 < b)
																											{
																												goto IL_211f;
																											}
																											num = 489;
																											goto IL_21ab;
																											IL_211f:
																											if (26 < b)
																											{
																												break;
																											}
																											goto IL_212d;
																											IL_212d:
																											if (26 > b)
																											{
																												break;
																											}
																											goto IL_213b;
																											IL_213b:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_217b;
																											IL_217b:
																											array[num6 - 2] = 3;
																											goto IL_218f;
																											IL_218f:
																											num6--;
																											goto end_IL_08f8;
																											IL_23f8:
																											array[num6 - 1] = 5;
																											goto IL_240c;
																											IL_21ab:
																											if (25 <= b)
																											{
																												goto IL_21b6;
																											}
																											goto IL_221c;
																											IL_21b6:
																											array[num6 - 1] = 3;
																											goto IL_21ca;
																											IL_21ca:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_2209;
																											IL_2209:
																											ptr2 += 8;
																											goto end_IL_08f8;
																											IL_221c:
																											if (24 < b)
																											{
																												break;
																											}
																											num = 485;
																											goto IL_2233;
																											IL_240c:
																											ptr2 += 8;
																											goto end_IL_08f8;
																											IL_2233:
																											if (24 > b)
																											{
																												break;
																											}
																											goto IL_2241;
																											IL_2241:
																											ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_22af;
																											IL_22af:
																											num6 -= 2;
																											goto end_IL_08f8;
																											IL_22c2:
																											if (29 >= b)
																											{
																												goto IL_22d0;
																											}
																											goto IL_23a4;
																											IL_22d0:
																											if (29 <= b)
																											{
																												goto IL_22db;
																											}
																											goto IL_2322;
																											IL_22db:
																											array2[num6] = array5[*(int*)(ptr2 + num3)];
																											goto IL_22f3;
																											IL_22f3:
																											array[num6] = 5;
																											goto IL_2301;
																											IL_2301:
																											num6++;
																											goto IL_230f;
																											IL_230f:
																											ptr2 += 8;
																											goto end_IL_08f8;
																											IL_2322:
																											if (28 < b)
																											{
																												break;
																											}
																											goto IL_2330;
																											IL_2330:
																											if (28 > b)
																											{
																												break;
																											}
																											goto IL_233e;
																											IL_233e:
																											array[num6 - 1] = 3;
																											goto IL_2352;
																											IL_2352:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_2391;
																											IL_2391:
																											ptr2 += 8;
																											goto end_IL_08f8;
																											IL_23a4:
																											if (30 < b)
																											{
																												break;
																											}
																											goto IL_23b2;
																											IL_23b2:
																											if (30 > b)
																											{
																												break;
																											}
																											goto IL_23c0;
																										}
																										break;
																									}
																									goto IL_09c2;
																									IL_1b21:
																									array[num6 - 2] = 0;
																									goto IL_1b35;
																									IL_09c2:
																									if (15 > b)
																									{
																										goto IL_09d0;
																									}
																									goto IL_0a9d;
																									IL_09d0:
																									if (7 < b)
																									{
																										goto IL_09de;
																									}
																									goto IL_0c1c;
																									IL_09de:
																									if (11 >= b)
																									{
																										goto IL_09ec;
																									}
																									goto IL_0b02;
																									IL_09ec:
																									if (11 <= b)
																									{
																										goto end_IL_08f8;
																									}
																									goto IL_09fa;
																									IL_09fa:
																									if (9 >= b)
																									{
																										goto IL_0bed;
																									}
																									goto IL_1a3e;
																									IL_0bed:
																									if (9 > b)
																									{
																										goto IL_0bfb;
																									}
																									goto IL_18af;
																									IL_0bfb:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0c09;
																									IL_0c09:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_18f4;
																									IL_18f4:
																									num6--;
																									goto end_IL_08f8;
																									IL_18af:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_19e8;
																									IL_19e8:
																									array[num6 - 2] = 0;
																									goto IL_19fc;
																									IL_19fc:
																									num6--;
																									goto end_IL_08f8;
																									IL_1a3e:
																									if (10 < b)
																									{
																										break;
																									}
																									num = 330;
																									goto IL_1a55;
																									IL_1b35:
																									num6--;
																									goto end_IL_08f8;
																									IL_1a55:
																									if (10 > b)
																									{
																										break;
																									}
																									num = 301;
																									goto IL_1a6c;
																									IL_0a9d:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0aef;
																									IL_1a6c:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1ace;
																									IL_1ace:
																									num6 -= 2;
																									goto end_IL_08f8;
																									IL_0b02:
																									if (13 < b)
																									{
																										goto IL_0b0d;
																									}
																									goto IL_0b1d;
																									IL_0b0d:
																									if (14 < b)
																									{
																										break;
																									}
																									goto IL_0b43;
																									IL_0b43:
																									if (14 > b)
																									{
																										break;
																									}
																									goto IL_0b51;
																									IL_0b51:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_0b92;
																									IL_0b92:
																									array[num6 - 2] = 0;
																									goto IL_0ba6;
																									IL_0ba6:
																									num6--;
																									goto end_IL_08f8;
																									IL_0b1d:
																									if (13 <= b)
																									{
																										goto IL_0b2b;
																									}
																									goto IL_0bb9;
																									IL_0b2b:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_08f8;
																									IL_0bb9:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0d6e;
																									IL_0d6e:
																									if (12 > b)
																									{
																										break;
																									}
																									num = 16;
																									goto IL_0d85;
																									IL_0aef:
																									num6--;
																									goto end_IL_08f8;
																									IL_0d85:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_1a0f;
																									IL_1a0f:
																									array[num6] = 1;
																									goto IL_1a1d;
																									IL_1a1d:
																									num6++;
																									goto IL_1a2b;
																									IL_1a2b:
																									ptr2 += 16;
																									goto end_IL_08f8;
																									IL_0c1c:
																									if (7 <= b)
																									{
																										goto IL_0c27;
																									}
																									goto IL_0c8e;
																									IL_0c27:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0c67;
																									IL_0c67:
																									array[num6 - 2] = 0;
																									goto IL_0c7b;
																									IL_0c7b:
																									num6--;
																									goto end_IL_08f8;
																									IL_0c8e:
																									if (3 >= b)
																									{
																										goto IL_0c99;
																									}
																									goto IL_0cac;
																									IL_0c99:
																									if (3 > b)
																									{
																										goto IL_10a1;
																									}
																									goto IL_1dd4;
																									IL_10a1:
																									if (1 >= b)
																									{
																										goto IL_10af;
																									}
																									goto IL_1cbd;
																									IL_10af:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_10bd;
																									IL_10bd:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_1d40;
																									IL_1d40:
																									array[num6] = 0;
																									goto IL_1d4e;
																									IL_1d4e:
																									num6++;
																									goto IL_1d5c;
																									IL_1d5c:
																									ptr2 += 8;
																									goto end_IL_08f8;
																									IL_1cbd:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_1ccb;
																									IL_1ccb:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_1cd9;
																									IL_1cd9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_1d19;
																									IL_1d19:
																									array[num6 - 2] = 0;
																									goto IL_1d2d;
																									IL_1d2d:
																									num6--;
																									goto end_IL_08f8;
																									IL_1dd4:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_1dfd;
																									IL_1dfd:
																									ptr2 += 8;
																									goto IL_1e0b;
																									IL_1e0b:
																									num6--;
																									goto end_IL_08f8;
																									IL_0cac:
																									if (5 >= b)
																									{
																										goto IL_0cba;
																									}
																									goto IL_0d4d;
																									IL_0cba:
																									if (5 <= b)
																									{
																										goto IL_0cc5;
																									}
																									goto IL_0d2c;
																									IL_0cc5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0d05;
																									IL_0d05:
																									array[num6 - 2] = 0;
																									goto IL_0d19;
																									IL_0d19:
																									num6--;
																									goto end_IL_08f8;
																									IL_0d2c:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_0d3a;
																									IL_0d3a:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_1d6f;
																									IL_1d6f:
																									array[num6] = 0;
																									num = 487;
																									goto IL_1d86;
																									IL_1d86:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_1da9;
																									IL_1da9:
																									array2[num6] = null;
																									goto IL_1db3;
																									IL_1db3:
																									num6++;
																									goto IL_1dc1;
																									IL_1dc1:
																									ptr2 += 8;
																									goto end_IL_08f8;
																									IL_0d4d:
																									if (6 < b)
																									{
																										break;
																									}
																									goto IL_0d5b;
																									IL_0d5b:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_1ae1;
																									IL_1ae1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_1b21;
																								}
																								break;
																							}
																							num = 372;
																							goto IL_2425;
																							IL_2439:
																							array2[num6 - 1] = ((delegate*<Component, Transform>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 1]);
																							goto IL_2471;
																							IL_2471:
																							ptr2 += 8;
																							goto end_IL_08f8;
																							IL_2425:
																							array[num6 - 1] = 5;
																							goto IL_2439;
																						}
																						break;
																					}
																					goto IL_0980;
																					IL_0a6e:
																					if (60 > b)
																					{
																						break;
																					}
																					goto IL_137d;
																					IL_0980:
																					if (47 >= b)
																					{
																						goto IL_098b;
																					}
																					goto IL_09b2;
																					IL_098b:
																					if (47 <= b)
																					{
																						goto IL_0999;
																					}
																					goto IL_13ca;
																					IL_0999:
																					array[num6 - 2] = 0;
																					goto IL_1202;
																					IL_1202:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 2], (GorillaRopeSwing)array2[num6 - 1]) ? 1 : 0);
																					goto IL_1254;
																					IL_1254:
																					num6--;
																					goto IL_1262;
																					IL_1262:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_13ca:
																					if (39 >= b)
																					{
																						goto IL_13d8;
																					}
																					goto IL_14c7;
																					IL_13d8:
																					if (39 <= b)
																					{
																						goto IL_13e3;
																					}
																					goto IL_140f;
																					IL_13e3:
																					global::_003CModule_003E.gorillaRopeSwing_0 = (GorillaRopeSwing)array2[num6 - 1];
																					goto IL_13fc;
																					IL_13fc:
																					num6--;
																					goto end_IL_08f8;
																					IL_140f:
																					if (35 >= b)
																					{
																						goto IL_141d;
																					}
																					goto IL_1ee9;
																					IL_141d:
																					if (35 > b)
																					{
																						goto IL_142b;
																					}
																					goto IL_192e;
																					IL_142b:
																					if (33 >= b)
																					{
																						goto IL_1439;
																					}
																					goto IL_1b48;
																					IL_1439:
																					if (33 > b)
																					{
																						goto IL_1447;
																					}
																					goto IL_1862;
																					IL_1447:
																					if (32 < b)
																					{
																						break;
																					}
																					goto IL_1455;
																					IL_1455:
																					if (32 > b)
																					{
																						break;
																					}
																					goto IL_1463;
																					IL_1463:
																					array[num6 - 1] = 4;
																					goto IL_1477;
																					IL_1477:
																					array2[num6 - 1] = ((delegate*<Transform, Vector3>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																					goto IL_14b4;
																					IL_14b4:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_1862:
																					array2[num6] = ((delegate*<GorillaRopeSwing>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																					goto IL_1880;
																					IL_1880:
																					array[num6] = 5;
																					goto IL_188e;
																					IL_188e:
																					num6++;
																					goto IL_189c;
																					IL_189c:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_1b48:
																					if (34 < b)
																					{
																						break;
																					}
																					goto IL_1b56;
																					IL_1b56:
																					if (34 > b)
																					{
																						break;
																					}
																					goto IL_1b64;
																					IL_1b64:
																					array[num6 - 1] = 5;
																					goto IL_1b78;
																					IL_1b78:
																					array2[num6 - 1] = ((delegate*<Component, Transform>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((GorillaRopeSwing)array2[num6 - 1]);
																					goto IL_1bb0;
																					IL_1bb0:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_192e:
																					array[num6 - 1] = 4;
																					num = 193;
																					goto IL_194b;
																					IL_194b:
																					array2[num6 - 1] = ((delegate*<Transform, Vector3>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																					goto IL_1988;
																					IL_1988:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_1ee9:
																					if (37 >= b)
																					{
																						goto IL_1ef7;
																					}
																					goto IL_1fde;
																					IL_1ef7:
																					if (37 > b)
																					{
																						goto IL_1f05;
																					}
																					goto IL_1fb1;
																					IL_1f05:
																					if (36 < b)
																					{
																						break;
																					}
																					goto IL_1f13;
																					IL_1f13:
																					if (36 > b)
																					{
																						break;
																					}
																					goto IL_1f21;
																					IL_1f21:
																					array[num6 - 2] = 3;
																					goto IL_1f35;
																					IL_1f35:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<Vector3, Vector3, float>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_1f87;
																					IL_1f87:
																					num6--;
																					goto IL_1f95;
																					IL_1f95:
																					ptr2 += 8;
																					num = 28;
																					goto end_IL_08f8;
																					IL_1fb1:
																					global::_003CModule_003E.float_39 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1fcb;
																					IL_1fcb:
																					num6--;
																					goto end_IL_08f8;
																					IL_1fde:
																					if (38 < b)
																					{
																						break;
																					}
																					goto IL_1fec;
																					IL_1fec:
																					if (38 > b)
																					{
																						break;
																					}
																					goto IL_1ffa;
																					IL_1ffa:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_203a;
																					IL_203a:
																					array[num6 - 2] = 3;
																					goto IL_204e;
																					IL_204e:
																					num6--;
																					goto end_IL_08f8;
																					IL_14c7:
																					if (43 < b)
																					{
																						goto IL_14d5;
																					}
																					num = 199;
																					goto IL_16ad;
																					IL_14d5:
																					if (45 < b)
																					{
																						goto IL_14e3;
																					}
																					num = 253;
																					goto IL_1579;
																					IL_14e3:
																					if (46 < b)
																					{
																						break;
																					}
																					goto IL_14f1;
																					IL_14f1:
																					if (46 > b)
																					{
																						break;
																					}
																					goto IL_14ff;
																					IL_14ff:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_155d;
																					IL_155d:
																					num6--;
																					goto end_IL_08f8;
																					IL_139b:
																					array[num6] = 5;
																					goto IL_13a9;
																					IL_1579:
																					if (45 <= b)
																					{
																						goto IL_1587;
																					}
																					goto IL_160e;
																					IL_1587:
																					array[num6 - 2] = 0;
																					goto IL_159b;
																					IL_159b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<List<GorillaRopeSwing>, GorillaRopeSwing, bool>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((List<GorillaRopeSwing>)array2[num6 - 2], (GorillaRopeSwing)array2[num6 - 1]) ? 1 : 0);
																					goto IL_15ed;
																					IL_15ed:
																					num6--;
																					goto IL_15fb;
																					IL_15fb:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_160e:
																					if (44 < b)
																					{
																						break;
																					}
																					num = 285;
																					goto IL_1625;
																					IL_13a9:
																					num6++;
																					goto IL_13b7;
																					IL_1625:
																					if (44 > b)
																					{
																						break;
																					}
																					num = 70;
																					goto IL_163c;
																					IL_13b7:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_163c:
																					array2[num6 - 1] = ((delegate*<Class20, List<GorillaRopeSwing>>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Class20)array2[num6 - 1]);
																					goto IL_1674;
																					IL_1674:
																					array[num6 - 1] = 5;
																					num = 352;
																					goto IL_1691;
																					IL_1691:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_137d:
																					array2[num6] = ((delegate*<GorillaRopeSwing>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																					goto IL_139b;
																					IL_16ad:
																					if (43 <= b)
																					{
																						goto IL_16b8;
																					}
																					goto IL_171e;
																					IL_16b8:
																					array[num6 - 1] = 3;
																					goto IL_16cc;
																					IL_16cc:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_170b;
																					IL_170b:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_171e:
																					if (41 >= b)
																					{
																						goto IL_172c;
																					}
																					goto IL_1819;
																					IL_172c:
																					if (41 > b)
																					{
																						goto IL_173a;
																					}
																					num = 291;
																					goto IL_17c6;
																					IL_173a:
																					if (40 < b)
																					{
																						break;
																					}
																					goto IL_1748;
																					IL_1748:
																					if (40 > b)
																					{
																						break;
																					}
																					goto IL_1756;
																					IL_1756:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1796;
																					IL_1796:
																					array[num6 - 2] = 3;
																					goto IL_17aa;
																					IL_17aa:
																					num6--;
																					goto end_IL_08f8;
																					IL_0a81:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_08f8;
																					IL_17c6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																					goto IL_17ea;
																					IL_17ea:
																					array[num6] = 0;
																					goto IL_17f8;
																					IL_17f8:
																					num6++;
																					goto IL_1806;
																					IL_1806:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_1819:
																					if (42 < b)
																					{
																						break;
																					}
																					goto IL_1827;
																					IL_1827:
																					if (42 > b)
																					{
																						break;
																					}
																					goto IL_1835;
																					IL_1835:
																					global::_003CModule_003E.int_60 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_184f;
																					IL_184f:
																					num6--;
																					goto end_IL_08f8;
																					IL_09b2:
																					if (55 < b)
																					{
																						goto IL_0a0d;
																					}
																					goto IL_0e73;
																					IL_0e73:
																					if (55 > b)
																					{
																						goto IL_0e81;
																					}
																					goto IL_130a;
																					IL_0e81:
																					if (51 >= b)
																					{
																						goto IL_0e8f;
																					}
																					goto IL_0fab;
																					IL_0e8f:
																					if (51 <= b)
																					{
																						goto IL_0e9a;
																					}
																					goto IL_0ef2;
																					IL_0e9a:
																					array[num6 - 1] = 3;
																					goto IL_0eae;
																					IL_0eae:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_136a;
																					IL_136a:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_0ef2:
																					if (49 < b)
																					{
																						goto IL_0efd;
																					}
																					goto IL_0f27;
																					IL_0efd:
																					if (50 < b)
																					{
																						break;
																					}
																					num = 348;
																					goto IL_0f14;
																					IL_0bcc:
																					if (62 < b)
																					{
																						break;
																					}
																					goto IL_0bda;
																					IL_0f14:
																					if (50 > b)
																					{
																						break;
																					}
																					goto IL_1058;
																					IL_1058:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																					goto IL_1072;
																					IL_1072:
																					array[num6] = 3;
																					goto IL_1080;
																					IL_1080:
																					num6++;
																					goto IL_108e;
																					IL_108e:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_0f27:
																					if (49 <= b)
																					{
																						goto IL_0f32;
																					}
																					goto IL_0f98;
																					IL_0f32:
																					array[num6 - 1] = 3;
																					goto IL_0f46;
																					IL_0f46:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0f85;
																					IL_0f85:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_0f98:
																					if (48 < b)
																					{
																						break;
																					}
																					goto IL_1907;
																					IL_1907:
																					if (48 > b)
																					{
																						break;
																					}
																					goto IL_1915;
																					IL_1915:
																					array[num6 - 1] = 3;
																					goto IL_1e8e;
																					IL_1e8e:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1ecd;
																					IL_1ecd:
																					ptr2 += 8;
																					num = 50;
																					goto end_IL_08f8;
																					IL_0fab:
																					if (53 >= b)
																					{
																						goto IL_0fb6;
																					}
																					goto IL_102e;
																					IL_0fb6:
																					if (53 <= b)
																					{
																						goto IL_0fc1;
																					}
																					goto IL_100d;
																					IL_0fc1:
																					*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((GorillaRopeSwing[])array2[num6 - 1]).LongLength;
																					goto IL_0feb;
																					IL_0feb:
																					array[num6 - 1] = 2;
																					num = 303;
																					goto end_IL_08f8;
																					IL_100d:
																					if (52 < b)
																					{
																						break;
																					}
																					goto IL_101b;
																					IL_101b:
																					if (52 > b)
																					{
																						break;
																					}
																					goto IL_199b;
																					IL_199b:
																					array2[num6] = ((delegate*<GorillaRopeSwing[]>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])();
																					goto IL_19b9;
																					IL_19b9:
																					array[num6] = 5;
																					goto IL_19c7;
																					IL_19c7:
																					num6++;
																					goto IL_19d5;
																					IL_19d5:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_102e:
																					if (54 < b)
																					{
																						break;
																					}
																					goto IL_103c;
																					IL_103c:
																					if (54 > b)
																					{
																						break;
																					}
																					num = 21;
																					goto IL_1141;
																					IL_0bda:
																					if (62 > b)
																					{
																					}
																					break;
																					IL_1141:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_116c;
																					IL_116c:
																					array[num6 - 1] = 0;
																					goto end_IL_08f8;
																					IL_130a:
																					array2[num6 - 2] = ((GorillaRopeSwing[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_1343;
																					IL_1343:
																					array[num6 - 2] = 5;
																					goto IL_1357;
																					IL_1357:
																					num6--;
																					goto end_IL_08f8;
																					IL_0a0d:
																					if (59 >= b)
																					{
																						goto IL_0a18;
																					}
																					goto IL_0a47;
																					IL_0a18:
																					if (59 > b)
																					{
																						goto IL_0a26;
																					}
																					goto IL_10db;
																					IL_0a26:
																					if (57 < b)
																					{
																						goto IL_0a34;
																					}
																					goto IL_1185;
																					IL_0a34:
																					if (58 < b)
																					{
																						break;
																					}
																					goto IL_12d0;
																					IL_12d0:
																					if (58 > b)
																					{
																						break;
																					}
																					goto IL_12de;
																					IL_12de:
																					global::_003CModule_003E.gorillaRopeSwing_2 = (GorillaRopeSwing[])array2[num6 - 1];
																					goto IL_12f7;
																					IL_12f7:
																					num6--;
																					goto end_IL_08f8;
																					IL_1185:
																					if (57 <= b)
																					{
																						goto IL_1190;
																					}
																					goto IL_11ef;
																					IL_1190:
																					array2[num6 - 1] = ((delegate*<Class20, GorillaRopeSwing[]>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])((Class20)array2[num6 - 1]);
																					goto IL_11c8;
																					IL_11c8:
																					array[num6 - 1] = 5;
																					goto IL_11dc;
																					IL_11dc:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_11ef:
																					if (56 < b)
																					{
																						break;
																					}
																					goto IL_1296;
																					IL_1296:
																					if (56 > b)
																					{
																						break;
																					}
																					goto IL_12a4;
																					IL_12a4:
																					global::_003CModule_003E.gorillaRopeSwing_1 = (GorillaRopeSwing)array2[num6 - 1];
																					goto IL_12bd;
																					IL_12bd:
																					num6--;
																					goto end_IL_08f8;
																					IL_10db:
																					array[num6 - 1] = 3;
																					goto IL_10ef;
																					IL_10ef:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExclusiveTokenRestrictedUserClaimAttributes[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_112e;
																					IL_112e:
																					ptr2 += 8;
																					goto end_IL_08f8;
																					IL_0a47:
																					if (61 >= b)
																					{
																						goto IL_0a55;
																					}
																					goto IL_0bcc;
																					IL_0a55:
																					if (61 > b)
																					{
																						goto IL_0a60;
																					}
																					goto IL_0a81;
																					IL_0a60:
																					if (60 < b)
																					{
																						break;
																					}
																					goto IL_0a6e;
																				}
																				break;
																				IL_08bf:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_08f8;
																		continue;
																		end_IL_08cf:
																		break;
																	}
																	continue;
																	end_IL_08df:
																	break;
																}
																continue;
																end_IL_08f8:
																break;
															}
															continue;
														}
														goto IL_2547;
														IL_2547:
														return (GorillaRopeSwing)array2[num6 - 1];
														continue;
														end_IL_2494:
														break;
													}
													continue;
													end_IL_24a7:
													break;
												}
												continue;
												end_IL_24b1:
												break;
											}
											continue;
											end_IL_24bc:
											break;
										}
										continue;
										end_IL_24cc:
										break;
									}
									continue;
									end_IL_24dc:
									break;
								}
								continue;
								end_IL_24ec:
								break;
							}
							continue;
							end_IL_24fc:
							break;
						}
						continue;
						end_IL_250c:
						break;
					}
					continue;
					end_IL_251c:
					break;
				}
				continue;
				end_IL_252c:
				break;
			}
		}
	}

	public Class20()
	{
		object obj = this;
		List<GorillaRopeSwing> list = new List<GorillaRopeSwing>();
		((Class20)obj).list_0 = list;
	}

	private unsafe static int smethod_0()
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref grfFlagsHeaderName.SystemThreadingThreadLocalDebugViewgetUnmanagedCode);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 41;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_030c:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02ec:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02dc:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02cc:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02bf:
																										if (4 > b)
																										{
																											while (true)
																											{
																												IL_02af:
																												if (2 < b)
																												{
																													while (3 >= b)
																													{
																														while (3 <= b)
																														{
																															num = 151;
																															while (true)
																															{
																																if (num != 151)
																																{
																																	if (num != 1132)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 130:
																																		goto IL_028c;
																																	case 13:
																																	case 45:
																																		goto IL_029f;
																																	case 57:
																																		goto IL_02af;
																																	case 0:
																																		goto IL_02bf;
																																	case 79:
																																	case 124:
																																		goto IL_02cc;
																																	case 116:
																																		goto IL_02dc;
																																	case 109:
																																		goto IL_02ec;
																																	case 74:
																																		goto IL_02fc;
																																	case 6:
																																		goto IL_030c;
																																	case 132:
																																		goto end_IL_030c;
																																	case 41:
																																		goto end_IL_031c;
																																	case 34:
																																		goto end_IL_032c;
																																	case 27:
																																	case 55:
																																		goto IL_0342;
																																	case 51:
																																		goto IL_0360;
																																	case 10:
																																	case 94:
																																		goto IL_0373;
																																	case 23:
																																		goto IL_037e;
																																	case 83:
																																	case 84:
																																		goto IL_038c;
																																	case 75:
																																		goto IL_039a;
																																	case 2:
																																		goto IL_03ad;
																																	case 49:
																																		goto IL_03bb;
																																	case 21:
																																	case 70:
																																		goto IL_03c9;
																																	case 50:
																																		goto IL_03f2;
																																	case 99:
																																		goto IL_0402;
																																	case 102:
																																		goto IL_0415;
																																	case 88:
																																	case 106:
																																		goto IL_0428;
																																	case 61:
																																	case 91:
																																		goto IL_0433;
																																	case 67:
																																		goto IL_0441;
																																	case 73:
																																		goto IL_0454;
																																	case 12:
																																		goto IL_0462;
																																	case 25:
																																	case 96:
																																		goto IL_0470;
																																	case 31:
																																		goto IL_047e;
																																	case 16:
																																	case 53:
																																		goto IL_048c;
																																	case 11:
																																		goto IL_04d0;
																																	case 100:
																																		goto IL_04e4;
																																	case 104:
																																		goto IL_04f7;
																																	case 42:
																																	case 92:
																																		goto IL_0502;
																																	case 60:
																																		goto IL_0512;
																																	case 82:
																																	case 107:
																																		goto IL_0522;
																																	case 64:
																																		goto IL_0562;
																																	case 111:
																																		goto IL_057b;
																																	case 114:
																																		goto IL_058e;
																																	case 19:
																																	case 120:
																																		goto IL_05b3;
																																	case 48:
																																		goto IL_05c1;
																																	case 77:
																																		goto IL_05d9;
																																	case 89:
																																		goto IL_05e7;
																																	case 56:
																																	case 123:
																																		goto IL_05fa;
																																	case 126:
																																		goto IL_0616;
																																	case 39:
																																		goto IL_0620;
																																	case 29:
																																		goto IL_062e;
																																	case 128:
																																		goto IL_0641;
																																	case 17:
																																		goto IL_064f;
																																	case 62:
																																	case 69:
																																		goto IL_065d;
																																	case 37:
																																		goto IL_06bf;
																																	case 134:
																																		goto IL_06d2;
																																	case 121:
																																		goto IL_06e0;
																																	case 137:
																																		goto IL_06f3;
																																	case 139:
																																	case 143:
																																		goto IL_0706;
																																	case 18:
																																		goto IL_0745;
																																	case 103:
																																		goto IL_0758;
																																	case 33:
																																		goto IL_0781;
																																	case 52:
																																		goto IL_079a;
																																	case 90:
																																	case 93:
																																		goto IL_07a5;
																																	case 76:
																																		goto end_IL_0279;
																																	case 35:
																																	case 138:
																																		goto IL_07c1;
																																	case 142:
																																		goto IL_07da;
																																	case 14:
																																		goto IL_07e8;
																																	case 26:
																																		goto IL_07f6;
																																	case 30:
																																	case 108:
																																		goto IL_0812;
																																	case 58:
																																		goto IL_085b;
																																	case 85:
																																		goto IL_086f;
																																	case 36:
																																	case 144:
																																		goto IL_0888;
																																	case 1:
																																	case 22:
																																	case 47:
																																	case 63:
																																	case 65:
																																	case 68:
																																	case 72:
																																	case 80:
																																	case 81:
																																	case 87:
																																	case 95:
																																	case 98:
																																	case 105:
																																	case 113:
																																	case 115:
																																	case 117:
																																	case 118:
																																	case 122:
																																	case 125:
																																	case 127:
																																	case 129:
																																	case 135:
																																	case 136:
																																		goto end_IL_028c;
																																	case 8:
																																	case 9:
																																	case 20:
																																	case 28:
																																	case 32:
																																	case 38:
																																	case 43:
																																	case 44:
																																	case 59:
																																	case 66:
																																	case 71:
																																	case 86:
																																	case 97:
																																	case 101:
																																	case 112:
																																	case 131:
																																	case 133:
																																	case 141:
																																		goto end_IL_0337;
																																	case 140:
																																		goto end_IL_08b0;
																																	case 54:
																																		goto end_IL_08c3;
																																	case 46:
																																		goto end_IL_08cd;
																																	case 15:
																																		goto end_IL_08d8;
																																	case 5:
																																	case 119:
																																		goto end_IL_08e8;
																																	case 110:
																																		goto end_IL_08f8;
																																	case 24:
																																	case 78:
																																		goto end_IL_0908;
																																	case 3:
																																		goto end_IL_0918;
																																	case 4:
																																		goto end_IL_0928;
																																	case 7:
																																	case 40:
																																		goto IL_0943;
																																	}
																																	continue;
																																}
																																goto IL_0758;
																																IL_0758:
																																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																																goto IL_0781;
																																IL_0781:
																																array[num5 - 1] = 5;
																																goto end_IL_0337;
																																continue;
																																end_IL_0279:
																																break;
																															}
																															goto IL_07b3;
																															continue;
																															end_IL_028c:
																															break;
																															IL_028c:;
																														}
																														break;
																														IL_029f:;
																													}
																													break;
																												}
																												goto IL_079a;
																												IL_086f:
																												num5--;
																												num = 8;
																												goto end_IL_0337;
																												IL_079a:
																												if (2 > b)
																												{
																													goto IL_07a5;
																												}
																												goto IL_0812;
																												IL_07a5:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_07b3;
																												IL_07b3:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_07c1;
																												IL_07c1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_07da;
																												IL_07da:
																												array[num5] = 0;
																												goto IL_07e8;
																												IL_07e8:
																												num5++;
																												goto IL_07f6;
																												IL_07f6:
																												ptr2 += 8;
																												num = 32;
																												goto end_IL_0337;
																												IL_0812:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 58;
																												goto IL_085b;
																												IL_085b:
																												array[num5 - 2] = 0;
																												goto IL_086f;
																											}
																											break;
																										}
																										goto IL_0342;
																										IL_0402:
																										num5--;
																										goto end_IL_0337;
																										IL_0342:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_0360;
																										IL_0360:
																										ptr2 += 8;
																										goto IL_0402;
																									}
																									break;
																								}
																								goto IL_0373;
																								IL_0415:
																								num5--;
																								goto end_IL_0337;
																								IL_0373:
																								if (6 >= b)
																								{
																									goto IL_037e;
																								}
																								goto IL_03ad;
																								IL_037e:
																								if (6 > b)
																								{
																									goto IL_038c;
																								}
																								goto IL_0706;
																								IL_038c:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_039a;
																								IL_039a:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_05b3;
																								IL_05b3:
																								array[num5] = 5;
																								goto IL_05c1;
																								IL_05c1:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_05d9;
																								IL_05d9:
																								num5++;
																								goto IL_05e7;
																								IL_05e7:
																								ptr2 += 8;
																								goto end_IL_0337;
																								IL_0706:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0745;
																								IL_0745:
																								num5 -= 3;
																								goto end_IL_0337;
																								IL_03ad:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_03bb;
																								IL_03bb:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_03c9;
																								IL_03c9:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03f2;
																								IL_03f2:
																								ptr2 += 8;
																								goto IL_0415;
																							}
																							break;
																						}
																						goto IL_0888;
																						IL_0888:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0337;
																					}
																					break;
																				}
																				goto IL_0428;
																				IL_06f3:
																				num5--;
																				goto end_IL_0337;
																				IL_0428:
																				if (12 < b)
																				{
																					goto IL_0433;
																				}
																				goto IL_0454;
																				IL_0433:
																				if (14 >= b)
																				{
																					goto IL_0441;
																				}
																				goto IL_06d2;
																				IL_0441:
																				if (14 <= b)
																				{
																					goto IL_05fa;
																				}
																				goto IL_0641;
																				IL_0641:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_064f;
																				IL_064f:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_065d;
																				IL_065d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06bf;
																				IL_06bf:
																				num5 -= 2;
																				goto end_IL_0337;
																				IL_05fa:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0337;
																				IL_06d2:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_06e0;
																				IL_06e0:
																				if (15 > b)
																				{
																				}
																				break;
																				IL_0454:
																				if (12 > b)
																				{
																					goto IL_0462;
																				}
																				goto IL_0522;
																				IL_0462:
																				if (10 < b)
																				{
																					goto IL_0470;
																				}
																				goto IL_04f7;
																				IL_0470:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_047e;
																				IL_047e:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_048c;
																				IL_048c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_04d0;
																				IL_04d0:
																				array[num5 - 2] = 0;
																				goto IL_04e4;
																				IL_04e4:
																				num5--;
																				goto end_IL_0337;
																				IL_04f7:
																				if (10 <= b)
																				{
																					goto IL_0502;
																				}
																				goto IL_0512;
																				IL_0502:
																				array[num5] = 0;
																				goto IL_058e;
																				IL_058e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0616;
																				IL_0616:
																				array2[num5] = null;
																				goto IL_0620;
																				IL_0620:
																				num5++;
																				goto IL_062e;
																				IL_062e:
																				ptr2 += 8;
																				goto end_IL_0337;
																				IL_0512:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_057b;
																				IL_057b:
																				if (9 <= b)
																				{
																					goto end_IL_0337;
																				}
																				break;
																				IL_0522:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0562;
																				IL_0562:
																				array[num5 - 2] = 0;
																				goto IL_06f3;
																			}
																			break;
																			IL_02fc:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0337;
																	continue;
																	end_IL_030c:
																	break;
																}
																continue;
																end_IL_031c:
																break;
															}
															continue;
															end_IL_032c:
															break;
														}
														continue;
														end_IL_0337:
														break;
													}
													continue;
												}
												goto IL_0943;
												IL_0943:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b0:
												break;
											}
											continue;
											end_IL_08c3:
											break;
										}
										continue;
										end_IL_08cd:
										break;
									}
									continue;
									end_IL_08d8:
									break;
								}
								continue;
								end_IL_08e8:
								break;
							}
							continue;
							end_IL_08f8:
							break;
						}
						continue;
						end_IL_0908:
						break;
					}
					continue;
					end_IL_0918:
					break;
				}
				continue;
				end_IL_0928:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 83;
		byte* ptr2 = default(byte*);
		byte b = default(byte);
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNumberNegativePatternPid.DebuggerStepThroughAttributeTYPEFLAGFNONEXTENSIBLE);
										num = 132;
										while (true)
										{
											if (num != 132)
											{
												if (num != 1113)
												{
													goto IL_074e;
												}
												switch (num)
												{
												case 65:
													goto end_IL_021f;
												case 61:
													goto end_IL_0232;
												case 40:
													goto end_IL_0246;
												case 11:
												case 123:
													goto end_IL_025b;
												case 86:
													goto end_IL_026b;
												case 35:
												case 105:
													goto end_IL_027b;
												case 82:
													goto end_IL_028b;
												case 83:
													goto end_IL_029b;
												case 13:
												case 16:
												case 17:
												case 20:
												case 28:
												case 42:
												case 45:
												case 62:
												case 71:
												case 76:
												case 91:
												case 95:
												case 99:
												case 104:
												case 109:
												case 115:
													goto IL_02be;
												case 48:
												case 120:
													goto IL_02ce;
												case 87:
													goto IL_02d7;
												case 31:
													goto IL_02e5;
												case 106:
													goto IL_02f3;
												case 108:
													goto IL_0301;
												case 90:
													goto IL_030f;
												case 12:
												case 84:
													goto IL_031a;
												case 7:
													goto IL_033d;
												case 55:
													goto IL_034b;
												case 118:
													goto IL_0359;
												case 101:
													goto IL_036c;
												case 56:
													goto IL_037a;
												case 96:
													goto IL_0388;
												case 36:
													goto IL_0393;
												case 22:
													goto IL_03a1;
												case 52:
												case 89:
													goto IL_03bd;
												case 44:
													goto IL_03cb;
												case 124:
													goto IL_03ee;
												case 18:
													goto IL_03f8;
												case 70:
													goto IL_0406;
												case 122:
													goto IL_0419;
												case 30:
													goto IL_0427;
												case 21:
												case 23:
													goto IL_0435;
												case 25:
													goto IL_0475;
												case 75:
													goto IL_0489;
												case 102:
													goto IL_04a5;
												case 117:
													goto IL_04b3;
												case 9:
													goto IL_04be;
												case 46:
												case 119:
													goto IL_04cc;
												case 113:
													goto IL_04e5;
												case 37:
													goto IL_04f3;
												case 14:
													goto IL_0501;
												case 0:
													goto IL_0514;
												case 110:
													goto IL_0522;
												case 66:
												case 111:
													goto IL_0530;
												case 112:
													goto IL_0559;
												case 43:
													goto IL_0570;
												case 10:
												case 80:
													goto IL_0583;
												case 64:
												case 114:
													goto IL_059b;
												case 5:
													goto IL_05a9;
												case 27:
												case 74:
													goto IL_05b7;
												case 85:
													goto IL_05c5;
												case 41:
												case 116:
													goto IL_05d3;
												case 72:
													goto IL_0635;
												case 38:
													goto IL_0648;
												case 51:
													goto IL_0656;
												case 1:
												case 78:
													goto IL_0664;
												case 53:
													goto IL_06a4;
												case 88:
													goto IL_06b8;
												case 26:
												case 63:
													goto IL_06cb;
												case 125:
													goto IL_06df;
												case 4:
													goto IL_071e;
												case 2:
												case 81:
													goto IL_0743;
												case 94:
												case 107:
													goto IL_074e;
												case 77:
													goto IL_0759;
												case 50:
													goto IL_0766;
												case 54:
												case 73:
													goto IL_0771;
												case 24:
													goto IL_077c;
												case 68:
												case 121:
													goto IL_0787;
												case 15:
												case 49:
													goto IL_079a;
												case 6:
												case 8:
												case 19:
												case 29:
												case 32:
												case 33:
												case 34:
												case 39:
												case 47:
												case 57:
												case 58:
												case 59:
												case 60:
												case 67:
												case 79:
												case 92:
												case 93:
												case 97:
												case 98:
												case 100:
												case 103:
													goto IL_07b6;
												case 3:
												case 69:
													goto IL_07ce;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_02be;
											IL_0766:
											if (12 > b)
											{
												goto IL_0771;
											}
											goto IL_079a;
											IL_077c:
											if (11 <= b)
											{
												goto IL_0787;
											}
											goto IL_07b6;
											IL_0771:
											if (11 >= b)
											{
												goto IL_077c;
											}
											goto IL_07b6;
											IL_02be:
											if (num4 != 1)
											{
												goto IL_02ce;
											}
											goto IL_07ce;
											IL_07ce:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											IL_02ce:
											b = *ptr2;
											goto IL_02d7;
											IL_02d7:
											ptr2++;
											goto IL_02e5;
											IL_02e5:
											if (b >= 1)
											{
												goto IL_02f3;
											}
											goto IL_07b6;
											IL_02f3:
											if (b <= 13)
											{
												goto IL_0301;
											}
											goto IL_07b6;
											IL_0301:
											if (7 >= b)
											{
												goto IL_030f;
											}
											goto IL_059b;
											IL_030f:
											if (7 <= b)
											{
												goto IL_031a;
											}
											goto IL_036c;
											IL_031a:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
											goto IL_033d;
											IL_033d:
											array[num5] = 0;
											goto IL_034b;
											IL_034b:
											num5++;
											goto IL_0359;
											IL_0359:
											ptr2 += 8;
											goto IL_02be;
											IL_036c:
											if (3 < b)
											{
												goto IL_037a;
											}
											num = 102;
											goto IL_04a5;
											IL_037a:
											if (5 >= b)
											{
												goto IL_0388;
											}
											goto IL_0419;
											IL_0388:
											if (5 > b)
											{
												goto IL_0393;
											}
											num = 89;
											goto IL_03bd;
											IL_0393:
											if (4 >= b)
											{
												goto IL_03a1;
											}
											goto IL_07b6;
											IL_03a1:
											if (4 <= b)
											{
												goto IL_02be;
											}
											goto IL_07b6;
											IL_079a:
											byte* num6 = ptr2;
											num4 = 1;
											ptr2 = num6 + -200;
											goto IL_02be;
											IL_03bd:
											array[num5] = 0;
											goto IL_03cb;
											IL_03cb:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
											goto IL_03ee;
											IL_03ee:
											array2[num5] = null;
											goto IL_03f8;
											IL_03f8:
											num5++;
											goto IL_0406;
											IL_0406:
											ptr2 += 8;
											goto IL_02be;
											IL_0419:
											if (6 >= b)
											{
												goto IL_0427;
											}
											goto IL_07b6;
											IL_0427:
											if (6 <= b)
											{
												goto IL_0435;
											}
											goto IL_07b6;
											IL_0435:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											goto IL_0475;
											IL_0475:
											array[num5 - 2] = 0;
											goto IL_0489;
											IL_0489:
											num5--;
											goto IL_02be;
											IL_0787:
											num5--;
											goto IL_02be;
											IL_04a5:
											if (3 > b)
											{
												goto IL_04b3;
											}
											goto IL_0583;
											IL_04b3:
											if (1 >= b)
											{
												goto IL_04be;
											}
											goto IL_0514;
											IL_04be:
											if (1 <= b)
											{
												goto IL_04cc;
											}
											goto IL_07b6;
											IL_04cc:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
											goto IL_04e5;
											IL_04e5:
											array[num5] = 0;
											goto IL_04f3;
											IL_04f3:
											num5++;
											goto IL_0501;
											IL_0501:
											ptr2 += 8;
											goto IL_02be;
											IL_0514:
											if (2 >= b)
											{
												goto IL_0522;
											}
											goto IL_07b6;
											IL_0522:
											if (2 <= b)
											{
												goto IL_0530;
											}
											goto IL_07b6;
											IL_0530:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											goto IL_0559;
											IL_0559:
											ptr2 += 8;
											num = 43;
											goto IL_0570;
											IL_0570:
											num5--;
											goto IL_02be;
											IL_0583:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_02be;
											IL_059b:
											if (10 >= b)
											{
												goto IL_05a9;
											}
											num = 81;
											goto IL_0743;
											IL_05a9:
											if (10 > b)
											{
												goto IL_05b7;
											}
											goto IL_06cb;
											IL_05b7:
											if (8 >= b)
											{
												goto IL_05c5;
											}
											goto IL_0648;
											IL_05c5:
											if (8 <= b)
											{
												goto IL_05d3;
											}
											goto IL_07b6;
											IL_05d3:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_0635;
											IL_0635:
											num5 -= 2;
											goto IL_02be;
											IL_0648:
											if (9 >= b)
											{
												goto IL_0656;
											}
											goto IL_07b6;
											IL_0656:
											if (9 <= b)
											{
												goto IL_0664;
											}
											goto IL_07b6;
											IL_0664:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											goto IL_06a4;
											IL_06a4:
											array[num5 - 2] = 0;
											goto IL_06b8;
											IL_06b8:
											num5--;
											goto IL_02be;
											IL_06cb:
											array[num5 - 1] = 0;
											goto IL_06df;
											IL_06df:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ProviderTypegetSecurityZone[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
											goto IL_071e;
											IL_071e:
											ptr2 += 8;
											num = 109;
											goto IL_02be;
											IL_07b6:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_02be;
											IL_0743:
											if (12 < b)
											{
												goto IL_074e;
											}
											goto IL_0766;
											IL_074e:
											if (13 >= b)
											{
												goto IL_0759;
											}
											goto IL_07b6;
											IL_0759:
											if (13 > b)
											{
											}
											goto IL_07b6;
											continue;
											end_IL_021f:
											break;
										}
										continue;
										end_IL_0232:
										break;
									}
									continue;
									end_IL_0246:
									break;
								}
								continue;
								end_IL_025b:
								break;
							}
							continue;
							end_IL_026b:
							break;
						}
						continue;
						end_IL_027b:
						break;
					}
					continue;
					end_IL_028b:
					break;
				}
				continue;
				end_IL_029b:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 20;
		int num3 = default(int);
		int num4 = default(int);
		byte[] array = default(byte[]);
		long[] array2 = default(long[]);
		int[] array3 = default(int[]);
		byte* ptr = default(byte*);
		object[] array4 = default(object[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			num = 98;
			while (true)
			{
				if (num != 98)
				{
					if (num != 1079)
					{
						goto IL_0241;
					}
					switch (num)
					{
					case 20:
						goto end_IL_0197;
					case 16:
					case 67:
						goto IL_01c9;
					case 42:
						goto IL_01d7;
					case 41:
					case 45:
						goto IL_01e5;
					case 51:
						goto IL_01f3;
					case 25:
						goto IL_0201;
					case 30:
						goto IL_0214;
					case 71:
						goto IL_0230;
					case 46:
						goto IL_0239;
					case 3:
					case 8:
					case 12:
					case 15:
					case 29:
					case 37:
					case 48:
					case 59:
					case 68:
					case 80:
					case 90:
						goto IL_0241;
					case 5:
					case 85:
						goto IL_0251;
					case 91:
						goto IL_0263;
					case 6:
						goto IL_0271;
					case 72:
						goto IL_027f;
					case 55:
						goto IL_028d;
					case 36:
					case 73:
						goto IL_029b;
					case 70:
						goto IL_02a6;
					case 18:
					case 26:
						goto IL_02b1;
					case 38:
						goto IL_02bf;
					case 23:
					case 78:
						goto IL_02cd;
					case 58:
						goto IL_02e5;
					case 49:
					case 83:
						goto IL_02f0;
					case 2:
						goto IL_02fb;
					case 11:
					case 22:
						goto IL_0309;
					case 28:
						goto IL_0333;
					case 44:
					case 47:
						goto IL_0341;
					case 7:
						goto IL_034f;
					case 27:
						goto IL_037b;
					case 54:
						goto IL_0385;
					case 14:
						goto IL_0393;
					case 57:
						goto IL_03a6;
					case 35:
						goto IL_03b4;
					case 33:
					case 52:
						goto IL_03c2;
					case 74:
						goto IL_03d0;
					case 65:
					case 79:
						goto IL_03de;
					case 0:
						goto IL_041e;
					case 4:
						goto IL_0432;
					case 77:
						goto IL_0445;
					case 1:
					case 10:
						goto IL_0450;
					case 75:
						goto IL_045e;
					case 86:
					case 89:
						goto IL_0471;
					case 13:
						goto IL_04df;
					case 9:
					case 56:
						goto IL_04f2;
					case 61:
						goto IL_0524;
					case 43:
						goto IL_0532;
					case 21:
						goto IL_0545;
					case 32:
						goto IL_0553;
					case 31:
						goto IL_0561;
					case 17:
					case 19:
					case 24:
					case 34:
					case 39:
					case 40:
					case 50:
					case 53:
					case 60:
					case 62:
					case 64:
					case 66:
					case 69:
					case 76:
					case 81:
					case 84:
					case 87:
					case 88:
						goto IL_0574;
					case 63:
					case 82:
						goto IL_05ab;
					}
					continue;
				}
				num3 = num2 * 4;
				goto IL_01c9;
				IL_0532:
				num4--;
				goto IL_0241;
				IL_0545:
				array[num4] = 0;
				goto IL_0553;
				IL_0574:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array3[*(int*)(ptr + num3)];
				num = 21;
				goto IL_0545;
				IL_01c9:
				array = new byte[2];
				goto IL_01d7;
				IL_01d7:
				array4 = new object[2];
				goto IL_01e5;
				IL_01e5:
				array3 = new int[3];
				goto IL_01f3;
				IL_01f3:
				array2 = new long[2];
				goto IL_0201;
				IL_0201:
				array3[0] = int_1;
				goto IL_0214;
				IL_0214:
				array3[1] = int_2;
				num = 71;
				goto IL_0230;
				IL_0230:
				ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetCurrentDirectoryPinDeployment.GetDeclaredNestedTypeDebugFacilityMessage);
				goto IL_0239;
				IL_0239:
				ptr = ptr2;
				goto IL_0241;
				IL_0241:
				if (num5 != 1)
				{
					goto IL_0251;
				}
				num = 82;
				goto IL_05ab;
				IL_0553:
				num4++;
				goto IL_0561;
				IL_05ab:
				return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				IL_0251:
				b = *ptr;
				num = 91;
				goto IL_0263;
				IL_0263:
				ptr++;
				goto IL_0271;
				IL_0271:
				if (b >= 1)
				{
					goto IL_027f;
				}
				goto IL_0574;
				IL_027f:
				if (b <= 8)
				{
					goto IL_028d;
				}
				goto IL_0574;
				IL_028d:
				if (4 < b)
				{
					goto IL_029b;
				}
				goto IL_03a6;
				IL_029b:
				if (6 >= b)
				{
					goto IL_02a6;
				}
				goto IL_02e5;
				IL_02a6:
				if (6 <= b)
				{
					goto IL_0241;
				}
				goto IL_02b1;
				IL_02b1:
				if (5 >= b)
				{
					goto IL_02bf;
				}
				goto IL_0574;
				IL_02bf:
				if (5 <= b)
				{
					goto IL_02cd;
				}
				goto IL_0574;
				IL_02cd:
				ptr = ptr2 + *(int*)(ptr + num3);
				goto IL_0241;
				IL_02e5:
				if (7 < b)
				{
					goto IL_02f0;
				}
				goto IL_0333;
				IL_02f0:
				if (8 >= b)
				{
					goto IL_02fb;
				}
				num = 69;
				goto IL_0574;
				IL_02fb:
				if (8 <= b)
				{
					goto IL_0309;
				}
				goto IL_0574;
				IL_0309:
				byte* num6 = ptr;
				num5 = 1;
				ptr = num6 + -200;
				goto IL_0241;
				IL_0561:
				ptr += 8;
				goto IL_0241;
				IL_0333:
				if (7 <= b)
				{
					goto IL_0341;
				}
				goto IL_0574;
				IL_0341:
				array[num4] = 0;
				goto IL_034f;
				IL_034f:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array3[*(int*)(ptr + num3)];
				num = 27;
				goto IL_037b;
				IL_037b:
				array4[num4] = null;
				goto IL_0385;
				IL_0385:
				num4++;
				goto IL_0393;
				IL_0393:
				ptr += 8;
				goto IL_0241;
				IL_03a6:
				if (4 > b)
				{
					goto IL_03b4;
				}
				goto IL_04f2;
				IL_03b4:
				if (2 < b)
				{
					goto IL_03c2;
				}
				goto IL_0445;
				IL_03c2:
				if (3 >= b)
				{
					goto IL_03d0;
				}
				goto IL_0574;
				IL_03d0:
				if (3 <= b)
				{
					goto IL_03de;
				}
				goto IL_0574;
				IL_03de:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				goto IL_041e;
				IL_041e:
				array[num4 - 2] = 0;
				goto IL_0432;
				IL_0432:
				num4--;
				goto IL_0241;
				IL_0445:
				if (2 > b)
				{
					goto IL_0450;
				}
				goto IL_0471;
				IL_0450:
				if (1 >= b)
				{
					goto IL_045e;
				}
				goto IL_0574;
				IL_045e:
				if (1 <= b)
				{
				}
				goto IL_0574;
				IL_0471:
				ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
				goto IL_04df;
				IL_04df:
				num4 -= 2;
				goto IL_0241;
				IL_04f2:
				ref int reference = ref array3[*(int*)(ptr + num3)];
				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				num = 61;
				goto IL_0524;
				IL_0524:
				ptr += 8;
				goto IL_0532;
				continue;
				end_IL_0197:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 59;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAccessMaskgetThreadingModel.GetSexagenaryYearApplicationUrl);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f0:
														byte b = *ptr2;
														num = 89;
														while (true)
														{
															IL_02e0:
															ptr2++;
															while (true)
															{
																IL_02d0:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02b0:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_02a0:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0293:
																							if (9 <= b)
																							{
																								while (true)
																								{
																									IL_022f:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									while (true)
																									{
																										IL_0216:
																										num5 -= 2;
																										num = 125;
																										while (num != 125)
																										{
																											if (num != 1106)
																											{
																												goto end_IL_02c0;
																											}
																											switch (num)
																											{
																											case 35:
																												goto IL_0216;
																											case 1:
																											case 16:
																												goto IL_022f;
																											case 79:
																												goto IL_0293;
																											case 47:
																											case 93:
																												goto IL_02a0;
																											case 100:
																												goto IL_02b0;
																											case 64:
																												goto IL_02c0;
																											case 82:
																												goto IL_02d0;
																											case 89:
																												goto IL_02e0;
																											case 4:
																											case 73:
																												goto IL_02f0;
																											case 76:
																											case 85:
																												goto IL_030d;
																											case 87:
																												goto IL_0323;
																											case 86:
																												goto IL_0331;
																											case 92:
																											case 98:
																												goto IL_0344;
																											case 17:
																											case 42:
																												goto IL_034f;
																											case 9:
																												goto IL_035d;
																											case 88:
																												goto IL_0370;
																											case 45:
																											case 101:
																												goto IL_037e;
																											case 108:
																												goto IL_039a;
																											case 74:
																											case 114:
																												goto IL_03a8;
																											case 112:
																												goto IL_03e8;
																											case 15:
																												goto IL_03fc;
																											case 32:
																											case 116:
																												goto IL_0418;
																											case 24:
																												goto IL_043b;
																											case 58:
																												goto IL_0449;
																											case 11:
																												goto IL_0457;
																											case 83:
																												goto IL_046a;
																											case 5:
																											case 41:
																												goto IL_0475;
																											case 0:
																												goto IL_04b5;
																											case 106:
																												goto IL_04c9;
																											case 70:
																											case 90:
																												goto IL_04e5;
																											case 49:
																												goto IL_04f3;
																											case 34:
																											case 118:
																												goto IL_04fe;
																											case 110:
																												goto IL_0516;
																											case 2:
																											case 51:
																												goto IL_0521;
																											case 12:
																												goto IL_052f;
																											case 26:
																											case 102:
																												goto IL_053d;
																											case 22:
																												goto IL_0566;
																											case 21:
																												goto IL_0574;
																											case 91:
																												goto IL_0587;
																											case 96:
																											case 103:
																												goto IL_0595;
																											case 52:
																												goto IL_05ae;
																											case 19:
																												goto IL_05bc;
																											case 56:
																												goto IL_05ca;
																											case 66:
																											case 97:
																												goto IL_05dd;
																											case 48:
																											case 84:
																												goto IL_05e8;
																											case 44:
																												goto IL_05f3;
																											case 20:
																											case 115:
																												goto IL_05fe;
																											case 62:
																												goto IL_060c;
																											case 30:
																												goto IL_062f;
																											case 111:
																												goto IL_0639;
																											case 3:
																												goto IL_0647;
																											case 28:
																												goto IL_0660;
																											case 7:
																											case 8:
																											case 10:
																											case 14:
																											case 31:
																											case 33:
																											case 37:
																											case 38:
																											case 50:
																											case 53:
																											case 55:
																											case 60:
																											case 63:
																											case 65:
																											case 69:
																											case 71:
																											case 77:
																											case 78:
																											case 80:
																											case 95:
																											case 99:
																											case 104:
																											case 113:
																												goto end_IL_02c0;
																											case 6:
																											case 13:
																											case 18:
																											case 23:
																											case 29:
																											case 43:
																											case 67:
																											case 68:
																											case 72:
																											case 75:
																											case 81:
																											case 109:
																											case 117:
																												goto end_IL_0203;
																											case 105:
																												goto end_IL_0687;
																											case 25:
																												goto end_IL_069a;
																											case 94:
																												goto end_IL_06a4;
																											case 36:
																												goto end_IL_06af;
																											case 46:
																											case 61:
																												goto end_IL_06c4;
																											case 59:
																												goto end_IL_06d4;
																											case 54:
																											case 57:
																												goto end_IL_06e4;
																											case 39:
																												goto end_IL_06f4;
																											case 40:
																												goto end_IL_070d;
																											case 27:
																											case 107:
																												goto IL_0728;
																											}
																											continue;
																											end_IL_0203:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							num = 76;
																							goto IL_030d;
																							IL_043b:
																							array[num5] = 0;
																							goto IL_0449;
																							IL_0449:
																							num5++;
																							goto IL_0457;
																							IL_030d:
																							if (7 < b)
																							{
																								goto IL_0323;
																							}
																							num = 108;
																							goto IL_039a;
																							IL_0457:
																							ptr2 += 8;
																							break;
																							IL_039a:
																							if (7 > b)
																							{
																								goto end_IL_02c0;
																							}
																							goto IL_03a8;
																							IL_03a8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03e8;
																							IL_03e8:
																							array[num5 - 2] = 0;
																							goto IL_03fc;
																							IL_03fc:
																							num5--;
																							num = 68;
																							break;
																							IL_0323:
																							if (8 < b)
																							{
																								goto end_IL_02c0;
																							}
																							goto IL_0331;
																							IL_0331:
																							if (8 > b)
																							{
																								goto end_IL_02c0;
																							}
																							goto IL_0418;
																							IL_0418:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_043b;
																						}
																						break;
																					}
																					goto IL_0344;
																					IL_037e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0344:
																					if (10 < b)
																					{
																						goto IL_034f;
																					}
																					goto IL_0370;
																					IL_034f:
																					if (11 < b)
																					{
																						goto end_IL_02c0;
																					}
																					goto IL_035d;
																					IL_035d:
																					if (11 > b)
																					{
																					}
																					goto end_IL_02c0;
																					IL_0370:
																					if (10 > b)
																					{
																						goto end_IL_02c0;
																					}
																					goto IL_037e;
																				}
																				break;
																			}
																			goto IL_046a;
																			IL_0647:
																			ptr2 += 8;
																			num = 81;
																			break;
																			IL_046a:
																			if (6 <= b)
																			{
																				goto IL_0475;
																			}
																			num = 70;
																			goto IL_04e5;
																			IL_0475:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b5;
																			IL_04b5:
																			array[num5 - 2] = 0;
																			goto IL_04c9;
																			IL_04c9:
																			num5--;
																			break;
																			IL_0660:
																			if (4 <= b)
																			{
																				break;
																			}
																			goto end_IL_02c0;
																			IL_04e5:
																			if (3 >= b)
																			{
																				goto IL_04f3;
																			}
																			goto IL_05dd;
																			IL_04f3:
																			if (3 <= b)
																			{
																				goto IL_04fe;
																			}
																			goto IL_0516;
																			IL_04fe:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0516:
																			if (1 < b)
																			{
																				goto IL_0521;
																			}
																			goto IL_0587;
																			IL_0521:
																			if (2 < b)
																			{
																				goto end_IL_02c0;
																			}
																			goto IL_052f;
																			IL_052f:
																			if (2 > b)
																			{
																				goto end_IL_02c0;
																			}
																			goto IL_053d;
																			IL_053d:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0566;
																			IL_0566:
																			ptr2 += 8;
																			goto IL_0574;
																			IL_0574:
																			num5--;
																			break;
																			IL_0587:
																			if (1 > b)
																			{
																				goto end_IL_02c0;
																			}
																			goto IL_0595;
																			IL_0595:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05ae;
																			IL_05ae:
																			array[num5] = 0;
																			goto IL_05bc;
																			IL_05bc:
																			num5++;
																			goto IL_05ca;
																			IL_05ca:
																			ptr2 += 8;
																			break;
																			IL_05dd:
																			if (4 < b)
																			{
																				goto IL_05e8;
																			}
																			goto IL_0660;
																			IL_05e8:
																			if (5 < b)
																			{
																				goto end_IL_02c0;
																			}
																			goto IL_05f3;
																			IL_05f3:
																			if (5 > b)
																			{
																				goto end_IL_02c0;
																			}
																			goto IL_05fe;
																			IL_05fe:
																			array[num5] = 0;
																			goto IL_060c;
																			IL_060c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_062f;
																			IL_062f:
																			array2[num5] = null;
																			goto IL_0639;
																			IL_0639:
																			num5++;
																			goto IL_0647;
																		}
																		goto end_IL_02d0;
																		continue;
																		end_IL_02c0:
																		break;
																		IL_02c0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 23;
																break;
																continue;
																end_IL_02d0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0728;
												IL_0728:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0687:
												break;
											}
											continue;
											end_IL_069a:
											break;
										}
										continue;
										end_IL_06a4:
										break;
									}
									continue;
									end_IL_06af:
									break;
								}
								continue;
								end_IL_06c4:
								break;
							}
							continue;
							end_IL_06d4:
							break;
						}
						continue;
						end_IL_06e4:
						break;
					}
					continue;
					end_IL_06f4:
					break;
				}
				continue;
				end_IL_070d:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 18;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										num = 17;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCategoryMembershipDataProcessMessageFinish.AssumeNegativeREDocument);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02ac:
																	if (b >= 1)
																	{
																		while (b <= 13)
																		{
																			while (true)
																			{
																				IL_028f:
																				if (7 < b)
																				{
																					while (true)
																					{
																						IL_027f:
																						if (10 < b)
																						{
																							while (true)
																							{
																								IL_026f:
																								if (12 >= b)
																								{
																									while (true)
																									{
																										IL_025f:
																										if (12 > b)
																										{
																											while (true)
																											{
																												IL_024c:
																												if (11 < b)
																												{
																													num = 135;
																													while (num != 135)
																													{
																														if (num != 1116)
																														{
																															goto IL_06f5;
																														}
																														switch (num)
																														{
																														case 14:
																															goto IL_024c;
																														case 96:
																															goto IL_025f;
																														case 1:
																														case 71:
																															goto IL_026f;
																														case 40:
																															goto IL_027f;
																														case 123:
																															goto IL_028f;
																														case 10:
																															goto IL_029c;
																														case 72:
																															goto IL_02ac;
																														case 112:
																															goto end_IL_02ac;
																														case 2:
																														case 89:
																															goto end_IL_02bc;
																														case 33:
																															goto IL_02d7;
																														case 13:
																														case 39:
																															goto IL_02e2;
																														case 9:
																															goto IL_02ed;
																														case 24:
																														case 54:
																															goto IL_030b;
																														case 61:
																															goto IL_0323;
																														case 0:
																														case 19:
																															goto IL_0331;
																														case 37:
																														case 66:
																															goto IL_034d;
																														case 21:
																															goto IL_0370;
																														case 7:
																															goto IL_037e;
																														case 28:
																														case 85:
																															goto IL_038e;
																														case 86:
																															goto IL_03aa;
																														case 43:
																															goto IL_03b8;
																														case 92:
																															goto IL_03cb;
																														case 76:
																														case 101:
																															goto IL_03de;
																														case 50:
																															goto IL_03e9;
																														case 99:
																															goto IL_03f7;
																														case 75:
																														case 95:
																															goto IL_0402;
																														case 57:
																															goto IL_042b;
																														case 111:
																															goto IL_0449;
																														case 114:
																															goto IL_045c;
																														case 26:
																														case 62:
																															goto IL_046a;
																														case 52:
																															goto IL_0483;
																														case 49:
																															goto IL_0491;
																														case 58:
																															goto IL_049f;
																														case 108:
																														case 119:
																															goto IL_04b2;
																														case 115:
																															goto IL_04c0;
																														case 15:
																														case 94:
																															goto IL_04cb;
																														case 64:
																														case 79:
																															goto IL_04e4;
																														case 80:
																															goto IL_04f2;
																														case 127:
																															goto IL_0505;
																														case 78:
																															goto IL_0528;
																														case 69:
																															goto IL_0532;
																														case 11:
																															goto IL_0540;
																														case 128:
																															goto IL_0553;
																														case 120:
																															goto IL_0561;
																														case 68:
																														case 124:
																															goto IL_0578;
																														case 27:
																															goto IL_05b8;
																														case 46:
																															goto IL_05cc;
																														case 51:
																															goto IL_05df;
																														case 36:
																														case 41:
																															goto IL_05ea;
																														case 45:
																															goto IL_05fe;
																														case 118:
																															goto IL_063d;
																														case 125:
																															goto IL_0650;
																														case 29:
																														case 87:
																															goto IL_065e;
																														case 6:
																															goto IL_066c;
																														case 4:
																														case 47:
																															goto IL_067a;
																														case 103:
																															goto IL_06c3;
																														case 110:
																															goto IL_06d7;
																														case 63:
																															goto IL_06ea;
																														case 3:
																														case 77:
																															goto IL_06f5;
																														case 34:
																															goto IL_0757;
																														case 8:
																														case 16:
																														case 22:
																														case 25:
																														case 31:
																														case 32:
																														case 42:
																														case 59:
																														case 60:
																														case 67:
																														case 73:
																														case 74:
																														case 81:
																														case 84:
																														case 88:
																														case 93:
																														case 97:
																														case 104:
																														case 107:
																														case 113:
																														case 122:
																														case 126:
																															goto end_IL_0239;
																														case 5:
																														case 20:
																														case 38:
																														case 44:
																														case 48:
																														case 53:
																														case 65:
																														case 70:
																														case 82:
																														case 90:
																														case 91:
																														case 98:
																														case 102:
																														case 105:
																														case 109:
																														case 117:
																															goto end_IL_02cc;
																														case 83:
																															goto end_IL_077a;
																														case 17:
																															goto end_IL_078d;
																														case 116:
																															goto end_IL_0797;
																														case 106:
																															goto end_IL_07a2;
																														case 12:
																														case 35:
																															goto end_IL_07c0;
																														case 23:
																															goto end_IL_07d0;
																														case 18:
																															goto end_IL_07e0;
																														case 30:
																															goto end_IL_07f0;
																														case 55:
																															goto end_IL_0800;
																														case 56:
																															goto end_IL_080b;
																														case 100:
																														case 121:
																															goto IL_0826;
																														}
																														continue;
																														end_IL_0239:
																														break;
																													}
																													break;
																												}
																												goto IL_0323;
																												IL_0323:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_0331;
																												IL_0331:
																												num5--;
																												num = 82;
																												goto end_IL_02cc;
																											}
																											break;
																										}
																										goto IL_038e;
																										IL_038e:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										goto end_IL_02cc;
																									}
																									break;
																								}
																								goto IL_03aa;
																								IL_03b8:
																								if (13 > b)
																								{
																								}
																								break;
																								IL_03aa:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_03b8;
																							}
																							break;
																						}
																						goto IL_05df;
																						IL_0757:
																						num5 -= 2;
																						goto end_IL_02cc;
																						IL_05df:
																						if (10 <= b)
																						{
																							goto IL_05ea;
																						}
																						goto IL_0650;
																						IL_05ea:
																						array[num5 - 1] = 0;
																						goto IL_05fe;
																						IL_05fe:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)EventTokengetShortestDayNames[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_063d;
																						IL_063d:
																						ptr2 += 8;
																						goto end_IL_02cc;
																						IL_0650:
																						if (8 < b)
																						{
																							goto IL_065e;
																						}
																						goto IL_06ea;
																						IL_065e:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_066c;
																						IL_066c:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_067a;
																						IL_067a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 103;
																						goto IL_06c3;
																						IL_06c3:
																						array[num5 - 2] = 0;
																						goto IL_06d7;
																						IL_06d7:
																						num5--;
																						goto end_IL_02cc;
																						IL_06ea:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_06f5;
																						IL_06f5:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0757;
																					}
																					break;
																				}
																				goto IL_02d7;
																				IL_05cc:
																				num5--;
																				goto end_IL_02cc;
																				IL_02d7:
																				if (7 > b)
																				{
																					goto IL_02e2;
																				}
																				goto IL_034d;
																				IL_02e2:
																				if (3 >= b)
																				{
																					goto IL_02ed;
																				}
																				num = 119;
																				goto IL_04b2;
																				IL_02ed:
																				if (3 <= b)
																				{
																					goto IL_030b;
																				}
																				goto IL_03de;
																				IL_03de:
																				if (1 < b)
																				{
																					goto IL_03e9;
																				}
																				goto IL_045c;
																				IL_03e9:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_03f7;
																				IL_03f7:
																				if (2 > b)
																				{
																					num = 8;
																					break;
																				}
																				goto IL_0402;
																				IL_0402:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_042b;
																				IL_042b:
																				ptr2 += 8;
																				goto IL_0449;
																				IL_0449:
																				num5--;
																				goto end_IL_02cc;
																				IL_0370:
																				array[num5] = 0;
																				goto IL_037e;
																				IL_045c:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_046a;
																				IL_046a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0483;
																				IL_0483:
																				array[num5] = 0;
																				goto IL_0491;
																				IL_0491:
																				num5++;
																				goto IL_049f;
																				IL_049f:
																				ptr2 += 8;
																				goto end_IL_02cc;
																				IL_030b:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02cc;
																				IL_034d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0370;
																				IL_04b2:
																				if (5 >= b)
																				{
																					goto IL_04c0;
																				}
																				goto IL_0553;
																				IL_04c0:
																				if (5 <= b)
																				{
																					goto IL_04cb;
																				}
																				num = 64;
																				goto IL_04e4;
																				IL_04cb:
																				array[num5] = 0;
																				goto IL_0505;
																				IL_0505:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0528;
																				IL_0528:
																				array2[num5] = null;
																				goto IL_0532;
																				IL_0532:
																				num5++;
																				goto IL_0540;
																				IL_0540:
																				ptr2 += 8;
																				goto end_IL_02cc;
																				IL_037e:
																				num5++;
																				goto IL_03cb;
																				IL_04e4:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_04f2;
																				IL_04f2:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_02cc;
																				IL_0553:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0561;
																				IL_0561:
																				if (6 > b)
																				{
																					break;
																				}
																				num = 124;
																				goto IL_0578;
																				IL_03cb:
																				ptr2 += 8;
																				goto end_IL_02cc;
																				IL_0578:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05b8;
																				IL_05b8:
																				array[num5 - 2] = 0;
																				goto IL_05cc;
																			}
																			break;
																			IL_029c:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02cc;
																	continue;
																	end_IL_02ac:
																	break;
																}
																continue;
																end_IL_02bc:
																break;
															}
															continue;
															end_IL_02cc:
															break;
														}
														continue;
													}
													goto IL_0826;
													IL_0826:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_077a:
													break;
												}
												continue;
												end_IL_078d:
												break;
											}
											continue;
											end_IL_0797:
											break;
										}
										continue;
										end_IL_07a2:
										break;
									}
									continue;
									end_IL_07c0:
									break;
								}
								continue;
								end_IL_07d0:
								break;
							}
							continue;
							end_IL_07e0:
							break;
						}
						continue;
						end_IL_07f0:
						break;
					}
					continue;
					end_IL_0800:
					break;
				}
				continue;
				end_IL_080b:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 75;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct48.IsNetFxTimeSpanLegacyFormatModeStaticIndexRangePartitionForIList);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02bc:
															byte b = *ptr2;
															while (true)
															{
																IL_02ac:
																ptr2++;
																while (true)
																{
																	IL_0299:
																	if (b >= 1)
																	{
																		num = 8;
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0279:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0269:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_025c:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_024c:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_0221:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0211:
																													ptr2 += 8;
																													while (true)
																													{
																														IL_01f8:
																														num5--;
																														num = 114;
																														while (num != 114)
																														{
																															if (num != 1095)
																															{
																																goto IL_068c;
																															}
																															switch (num)
																															{
																															case 61:
																																goto IL_01f8;
																															case 69:
																																goto IL_0211;
																															case 7:
																															case 59:
																																goto IL_0221;
																															case 41:
																																goto IL_024c;
																															case 30:
																															case 39:
																																goto IL_025c;
																															case 21:
																																goto IL_0269;
																															case 14:
																																goto IL_0279;
																															case 8:
																																goto IL_0289;
																															case 12:
																																goto IL_0299;
																															case 74:
																																goto IL_02ac;
																															case 70:
																															case 86:
																																goto IL_02bc;
																															case 32:
																																goto IL_02c7;
																															case 44:
																															case 77:
																																goto IL_02d2;
																															case 82:
																																goto IL_02e0;
																															case 83:
																																goto IL_02f3;
																															case 37:
																															case 55:
																																goto IL_030a;
																															case 50:
																															case 91:
																																goto IL_0322;
																															case 48:
																																goto IL_0330;
																															case 6:
																															case 64:
																																goto IL_033b;
																															case 63:
																																goto IL_0349;
																															case 13:
																															case 76:
																																goto IL_035c;
																															case 72:
																																goto IL_03be;
																															case 95:
																																goto IL_03d1;
																															case 51:
																															case 101:
																																goto IL_03e4;
																															case 100:
																																goto IL_03ef;
																															case 3:
																															case 52:
																																goto IL_03fd;
																															case 28:
																															case 96:
																																goto IL_0422;
																															case 1:
																																goto IL_0430;
																															case 104:
																																goto IL_0443;
																															case 29:
																															case 85:
																																goto IL_0451;
																															case 45:
																																goto IL_0474;
																															case 97:
																																goto IL_0482;
																															case 25:
																																goto IL_0490;
																															case 33:
																															case 107:
																																goto IL_04a3;
																															case 31:
																																goto IL_04e3;
																															case 78:
																																goto IL_04f7;
																															case 11:
																																goto IL_050a;
																															case 92:
																																goto IL_0518;
																															case 26:
																															case 38:
																																goto IL_0526;
																															case 99:
																																goto IL_0548;
																															case 94:
																																goto IL_0556;
																															case 40:
																																goto IL_0564;
																															case 35:
																															case 58:
																																goto IL_0574;
																															case 4:
																																goto IL_0582;
																															case 16:
																																goto IL_05a5;
																															case 90:
																																goto IL_05af;
																															case 42:
																																goto IL_05bd;
																															case 0:
																															case 2:
																															case 5:
																															case 9:
																															case 10:
																															case 20:
																															case 27:
																															case 36:
																															case 46:
																															case 54:
																															case 57:
																															case 62:
																															case 65:
																															case 67:
																															case 71:
																															case 79:
																															case 84:
																															case 87:
																															case 88:
																															case 93:
																															case 106:
																																goto end_IL_0289;
																															case 15:
																															case 17:
																															case 18:
																															case 22:
																															case 23:
																															case 43:
																															case 66:
																															case 68:
																															case 89:
																															case 98:
																															case 103:
																															case 105:
																																goto end_IL_01e5;
																															case 19:
																																goto end_IL_05e9;
																															case 56:
																																goto end_IL_05fc;
																															case 60:
																																goto end_IL_0606;
																															case 73:
																																goto end_IL_0611;
																															case 34:
																															case 49:
																																goto end_IL_0626;
																															case 47:
																																goto end_IL_0636;
																															case 75:
																																goto end_IL_0646;
																															case 24:
																																goto end_IL_0656;
																															case 80:
																																goto end_IL_0666;
																															case 81:
																																goto end_IL_0671;
																															case 53:
																															case 102:
																																goto IL_068c;
																															}
																															continue;
																															end_IL_01e5:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_050a;
																										IL_0564:
																										ptr2 += 8;
																										break;
																										IL_050a:
																										if (1 < b)
																										{
																											goto end_IL_0289;
																										}
																										goto IL_0518;
																										IL_0518:
																										if (1 > b)
																										{
																											goto end_IL_0289;
																										}
																										goto IL_0526;
																										IL_0526:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 99;
																										goto IL_0548;
																										IL_0548:
																										array[num5] = 0;
																										goto IL_0556;
																										IL_0556:
																										num5++;
																										goto IL_0564;
																									}
																									break;
																								}
																								goto IL_02c7;
																								IL_030a:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_02c7:
																								if (3 < b)
																								{
																									goto IL_02d2;
																								}
																								goto IL_02f3;
																								IL_02d2:
																								if (4 < b)
																								{
																									goto end_IL_0289;
																								}
																								goto IL_02e0;
																								IL_02e0:
																								if (4 > b)
																								{
																									goto end_IL_0289;
																								}
																								break;
																								IL_02f3:
																								if (3 > b)
																								{
																									goto end_IL_0289;
																								}
																								num = 55;
																								goto IL_030a;
																							}
																							break;
																						}
																						goto IL_0574;
																						IL_05bd:
																						ptr2 += 8;
																						break;
																						IL_0574:
																						array[num5] = 0;
																						goto IL_0582;
																						IL_0582:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05a5;
																						IL_05a5:
																						array2[num5] = null;
																						goto IL_05af;
																						IL_05af:
																						num5++;
																						goto IL_05bd;
																					}
																					break;
																				}
																				goto IL_0322;
																				IL_0422:
																				if (10 < b)
																				{
																					goto end_IL_0289;
																				}
																				goto IL_0430;
																				IL_0322:
																				if (8 >= b)
																				{
																					goto IL_0330;
																				}
																				goto IL_03e4;
																				IL_0330:
																				if (8 > b)
																				{
																					goto IL_033b;
																				}
																				goto IL_035c;
																				IL_033b:
																				if (6 < b)
																				{
																					goto IL_0349;
																				}
																				goto IL_03d1;
																				IL_0349:
																				if (7 < b)
																				{
																					goto end_IL_0289;
																				}
																				goto IL_0443;
																				IL_0443:
																				if (7 > b)
																				{
																					goto end_IL_0289;
																				}
																				goto IL_0451;
																				IL_0451:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0474;
																				IL_0474:
																				array[num5] = 0;
																				goto IL_0482;
																				IL_0482:
																				num5++;
																				goto IL_0490;
																				IL_0490:
																				ptr2 += 8;
																				break;
																				IL_03d1:
																				if (6 > b)
																				{
																					goto end_IL_0289;
																				}
																				goto IL_04a3;
																				IL_04a3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e3;
																				IL_04e3:
																				array[num5 - 2] = 0;
																				goto IL_04f7;
																				IL_04f7:
																				num5--;
																				break;
																				IL_035c:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03be;
																				IL_03be:
																				num5 -= 2;
																				break;
																				IL_03e4:
																				if (9 >= b)
																				{
																					goto IL_03ef;
																				}
																				num = 28;
																				goto IL_0422;
																				IL_03ef:
																				if (9 > b)
																				{
																					goto end_IL_0289;
																				}
																				goto IL_03fd;
																				IL_03fd:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0430:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0289;
																			}
																			goto end_IL_0299;
																			continue;
																			end_IL_0289:
																			break;
																			IL_0289:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 22;
																	break;
																	continue;
																	end_IL_0299:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_068c;
													IL_068c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05e9:
													break;
												}
												continue;
												end_IL_05fc:
												break;
											}
											continue;
											end_IL_0606:
											break;
										}
										continue;
										end_IL_0611:
										break;
									}
									continue;
									end_IL_0626:
									break;
								}
								continue;
								end_IL_0636:
								break;
							}
							continue;
							end_IL_0646:
							break;
						}
						continue;
						end_IL_0656:
						break;
					}
					continue;
					end_IL_0666:
					break;
				}
				continue;
				end_IL_0671:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 26;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 25;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 5;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MarshalManagedToNativeClaimTypes.GetParameterssetRead);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_024d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 45;
																		while (true)
																		{
																			IL_022a:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_021a:
																					if (6 <= b)
																					{
																						num = 119;
																						while (true)
																						{
																							if (num != 119)
																							{
																								if (num != 1100)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 10:
																									goto IL_021a;
																								case 45:
																									goto IL_022a;
																								case 50:
																									goto end_IL_022a;
																								case 38:
																									goto IL_024d;
																								case 16:
																									goto end_IL_024d;
																								case 32:
																								case 89:
																									goto end_IL_025d;
																								case 6:
																									goto IL_0278;
																								case 8:
																									goto IL_0286;
																								case 0:
																								case 4:
																									goto IL_0291;
																								case 82:
																									goto IL_02a9;
																								case 24:
																									goto IL_02b4;
																								case 66:
																									goto IL_02c2;
																								case 30:
																									goto IL_02db;
																								case 34:
																								case 73:
																									goto IL_02e9;
																								case 61:
																									goto IL_0302;
																								case 72:
																								case 98:
																									goto IL_0312;
																								case 77:
																									goto IL_033b;
																								case 48:
																									goto IL_0349;
																								case 100:
																									goto IL_035c;
																								case 54:
																									goto IL_036a;
																								case 13:
																								case 103:
																									goto IL_037d;
																								case 36:
																									goto IL_038b;
																								case 9:
																									goto IL_0399;
																								case 11:
																									goto IL_03a4;
																								case 46:
																								case 88:
																									goto IL_03b2;
																								case 59:
																									goto IL_03f2;
																								case 99:
																									goto IL_0406;
																								case 96:
																									goto IL_0419;
																								case 7:
																									goto IL_0430;
																								case 1:
																								case 14:
																									goto IL_043e;
																								case 81:
																									goto IL_0461;
																								case 84:
																									goto IL_046f;
																								case 43:
																									goto IL_047d;
																								case 44:
																								case 83:
																									goto end_IL_0207;
																								case 29:
																									goto IL_04f2;
																								case 40:
																									goto IL_0505;
																								case 74:
																									goto IL_0510;
																								case 52:
																									goto IL_0520;
																								case 28:
																									goto IL_052e;
																								case 93:
																								case 110:
																									goto IL_0541;
																								case 85:
																								case 111:
																									goto IL_055d;
																								case 63:
																								case 92:
																									goto IL_0568;
																								case 18:
																									goto IL_0576;
																								case 19:
																								case 62:
																									goto IL_0584;
																								case 56:
																									goto IL_0592;
																								case 108:
																									goto IL_05b5;
																								case 107:
																									goto IL_05bf;
																								case 22:
																									goto IL_05cd;
																								case 23:
																									goto IL_05e0;
																								case 37:
																									goto IL_05ed;
																								case 31:
																									goto IL_062d;
																								case 106:
																									goto IL_0641;
																								case 3:
																								case 12:
																								case 20:
																								case 27:
																								case 39:
																								case 41:
																								case 47:
																								case 49:
																								case 55:
																								case 57:
																								case 58:
																								case 67:
																								case 69:
																								case 70:
																								case 71:
																								case 76:
																								case 79:
																								case 86:
																								case 87:
																								case 91:
																								case 94:
																								case 109:
																									goto end_IL_023a;
																								case 2:
																								case 15:
																								case 17:
																								case 21:
																								case 33:
																								case 51:
																								case 64:
																								case 65:
																								case 68:
																								case 75:
																								case 78:
																								case 101:
																								case 104:
																								case 105:
																									goto end_IL_026d;
																								case 97:
																									goto end_IL_0664;
																								case 95:
																									goto end_IL_0677;
																								case 80:
																									goto end_IL_0681;
																								case 53:
																									goto end_IL_068c;
																								case 5:
																								case 35:
																									goto end_IL_06a1;
																								case 102:
																									goto end_IL_06b1;
																								case 60:
																								case 90:
																									goto end_IL_06c1;
																								case 25:
																									goto end_IL_06da;
																								case 26:
																									goto end_IL_06ea;
																								case 42:
																								case 112:
																									goto IL_0717;
																								}
																								continue;
																							}
																							goto IL_05ed;
																							IL_062d:
																							array[num5 - 2] = 0;
																							goto IL_0641;
																							IL_0641:
																							num5--;
																							goto end_IL_026d;
																							IL_05ed:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_062d;
																							continue;
																							end_IL_0207:
																							break;
																						}
																						break;
																					}
																					goto IL_0278;
																					IL_05bf:
																					num5++;
																					goto IL_05cd;
																					IL_05cd:
																					ptr2 += 8;
																					goto end_IL_026d;
																					IL_0278:
																					if (3 >= b)
																					{
																						goto IL_0286;
																					}
																					goto IL_055d;
																					IL_0286:
																					if (3 <= b)
																					{
																						goto IL_0291;
																					}
																					goto IL_02a9;
																					IL_0291:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_026d;
																					IL_02a9:
																					if (1 < b)
																					{
																						goto IL_02b4;
																					}
																					num = 30;
																					goto IL_02db;
																					IL_02b4:
																					if (2 < b)
																					{
																						goto end_IL_023a;
																					}
																					goto IL_02c2;
																					IL_02c2:
																					if (2 > b)
																					{
																						goto end_IL_023a;
																					}
																					goto IL_0312;
																					IL_0312:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_033b;
																					IL_033b:
																					ptr2 += 8;
																					goto IL_0349;
																					IL_0349:
																					num5--;
																					goto end_IL_026d;
																					IL_05e0:
																					if (4 <= b)
																					{
																						goto end_IL_026d;
																					}
																					goto end_IL_023a;
																					IL_02db:
																					if (1 > b)
																					{
																						goto end_IL_023a;
																					}
																					goto IL_02e9;
																					IL_02e9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0302;
																					IL_0302:
																					array[num5] = 0;
																					goto IL_035c;
																					IL_035c:
																					num5++;
																					goto IL_036a;
																					IL_036a:
																					ptr2 += 8;
																					goto end_IL_026d;
																					IL_055d:
																					if (4 < b)
																					{
																						goto IL_0568;
																					}
																					goto IL_05e0;
																					IL_0568:
																					if (5 < b)
																					{
																						goto end_IL_023a;
																					}
																					goto IL_0576;
																					IL_0576:
																					if (5 > b)
																					{
																						goto end_IL_023a;
																					}
																					goto IL_0584;
																					IL_0584:
																					array[num5] = 0;
																					goto IL_0592;
																					IL_0592:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05b5;
																					IL_05b5:
																					array2[num5] = null;
																					goto IL_05bf;
																				}
																				goto IL_0490;
																			}
																			goto IL_037d;
																			IL_0520:
																			if (11 < b)
																			{
																				goto end_IL_023a;
																			}
																			goto IL_052e;
																			IL_037d:
																			if (9 >= b)
																			{
																				goto IL_038b;
																			}
																			goto IL_0505;
																			IL_038b:
																			if (9 > b)
																			{
																				goto IL_0399;
																			}
																			goto IL_0490;
																			IL_0399:
																			if (7 >= b)
																			{
																				goto IL_03a4;
																			}
																			goto IL_0419;
																			IL_03a4:
																			if (7 > b)
																			{
																				goto end_IL_023a;
																			}
																			goto IL_03b2;
																			IL_03b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03f2;
																			IL_03f2:
																			array[num5 - 2] = 0;
																			goto IL_0406;
																			IL_0406:
																			num5--;
																			goto end_IL_026d;
																			IL_0419:
																			if (8 < b)
																			{
																				goto end_IL_023a;
																			}
																			num = 7;
																			goto IL_0430;
																			IL_052e:
																			if (11 <= b)
																			{
																			}
																			goto end_IL_023a;
																			IL_0430:
																			if (8 > b)
																			{
																				goto end_IL_023a;
																			}
																			goto IL_043e;
																			IL_043e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0461;
																			IL_0461:
																			array[num5] = 0;
																			goto IL_046f;
																			IL_046f:
																			num5++;
																			goto IL_047d;
																			IL_047d:
																			ptr2 += 8;
																			goto end_IL_026d;
																			IL_0490:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04f2;
																			IL_04f2:
																			num5 -= 2;
																			goto end_IL_026d;
																			IL_0505:
																			if (10 >= b)
																			{
																				goto IL_0510;
																			}
																			goto IL_0520;
																			IL_0510:
																			if (10 > b)
																			{
																				goto end_IL_023a;
																			}
																			goto IL_0541;
																			IL_0541:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_026d;
																			continue;
																			end_IL_022a:
																			break;
																		}
																		continue;
																		end_IL_023a:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_026d;
																continue;
																end_IL_024d:
																break;
															}
															continue;
															end_IL_025d:
															break;
														}
														continue;
														end_IL_026d:
														break;
													}
													continue;
												}
												num = 42;
												goto IL_0717;
												IL_0717:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0664:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_0681:
										break;
									}
									continue;
									end_IL_068c:
									break;
								}
								continue;
								end_IL_06a1:
								break;
							}
							continue;
							end_IL_06b1:
							break;
						}
						continue;
						end_IL_06c1:
						break;
					}
					continue;
					end_IL_06da:
					break;
				}
				continue;
				end_IL_06ea:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 150;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumRunningControlPrincipal.GetCustomAttributesEntryPointCommandLineParameters);
										num = 39;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0348:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0328:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0318:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_030b:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02fe:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02ee:
																											if (2 < b)
																											{
																												while (3 >= b)
																												{
																													while (3 <= b)
																													{
																														while (true)
																														{
																															IL_029a:
																															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															num = 158;
																															while (true)
																															{
																																if (num != 158)
																																{
																																	if (num != 1139)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 48:
																																	case 133:
																																		goto IL_029a;
																																	case 56:
																																		goto IL_02ce;
																																	case 62:
																																	case 64:
																																		goto IL_02de;
																																	case 149:
																																		goto IL_02ee;
																																	case 101:
																																		goto IL_02fe;
																																	case 18:
																																		goto IL_030b;
																																	case 117:
																																		goto IL_0318;
																																	case 2:
																																		goto IL_0328;
																																	case 127:
																																		goto IL_0338;
																																	case 71:
																																		goto IL_0348;
																																	case 83:
																																		goto end_IL_0348;
																																	case 35:
																																	case 151:
																																		goto end_IL_0358;
																																	case 33:
																																	case 57:
																																		goto IL_0373;
																																	case 60:
																																	case 70:
																																		goto IL_0383;
																																	case 73:
																																		goto IL_03ac;
																																	case 19:
																																	case 50:
																																		goto IL_03ba;
																																	case 11:
																																		goto IL_03f9;
																																	case 97:
																																		goto IL_040c;
																																	case 80:
																																		goto IL_041a;
																																	case 46:
																																	case 103:
																																		goto IL_042d;
																																	case 123:
																																		goto IL_0445;
																																	case 12:
																																		goto IL_0453;
																																	case 47:
																																	case 84:
																																		goto IL_0461;
																																	case 125:
																																		goto IL_046f;
																																	case 96:
																																		goto IL_0487;
																																	case 106:
																																		goto IL_0495;
																																	case 131:
																																		goto IL_04a8;
																																	case 4:
																																		goto IL_04b6;
																																	case 45:
																																	case 135:
																																		goto IL_04c4;
																																	case 138:
																																		goto IL_04ed;
																																	case 63:
																																		goto IL_04fb;
																																	case 52:
																																	case 141:
																																		goto IL_050e;
																																	case 17:
																																	case 51:
																																		goto IL_0519;
																																	case 78:
																																		goto IL_0527;
																																	case 58:
																																	case 90:
																																		goto IL_0535;
																																	case 72:
																																		goto IL_0548;
																																	case 120:
																																	case 126:
																																		goto IL_0553;
																																	case 76:
																																		goto IL_0593;
																																	case 30:
																																		goto IL_05a7;
																																	case 74:
																																		goto IL_05ba;
																																	case 36:
																																	case 130:
																																		goto IL_05c8;
																																	case 99:
																																		goto IL_05d6;
																																	case 9:
																																	case 95:
																																		goto IL_05e4;
																																	case 98:
																																		goto IL_0628;
																																	case 6:
																																		goto IL_063c;
																																	case 91:
																																		goto IL_064f;
																																	case 21:
																																	case 79:
																																		goto IL_065a;
																																	case 102:
																																		goto IL_0668;
																																	case 31:
																																	case 137:
																																		goto IL_067b;
																																	case 115:
																																		goto IL_0689;
																																	case 89:
																																		goto IL_06ac;
																																	case 32:
																																		goto IL_06b6;
																																	case 16:
																																	case 142:
																																		goto IL_06c9;
																																	case 143:
																																		goto IL_06ee;
																																	case 100:
																																	case 104:
																																		goto IL_06fc;
																																	case 140:
																																		goto IL_075e;
																																	case 146:
																																		goto IL_0771;
																																	case 81:
																																	case 148:
																																		goto IL_0784;
																																	case 1:
																																		goto IL_0792;
																																	case 92:
																																		goto IL_07c7;
																																	case 37:
																																	case 118:
																																		goto end_IL_0287;
																																	case 69:
																																		goto IL_0812;
																																	case 66:
																																		goto IL_0826;
																																	case 111:
																																		goto IL_0836;
																																	case 25:
																																		goto IL_0841;
																																	case 87:
																																	case 116:
																																		goto IL_084c;
																																	case 34:
																																		goto IL_086e;
																																	case 114:
																																		goto IL_087c;
																																	case 15:
																																		goto IL_088a;
																																	case 0:
																																	case 3:
																																	case 5:
																																	case 7:
																																	case 14:
																																	case 20:
																																	case 22:
																																	case 23:
																																	case 24:
																																	case 26:
																																	case 41:
																																	case 42:
																																	case 54:
																																	case 59:
																																	case 75:
																																	case 77:
																																	case 82:
																																	case 85:
																																	case 86:
																																	case 93:
																																	case 94:
																																	case 105:
																																	case 107:
																																	case 113:
																																	case 124:
																																	case 134:
																																	case 139:
																																	case 144:
																																	case 145:
																																	case 147:
																																		goto end_IL_02ce;
																																	case 8:
																																	case 10:
																																	case 13:
																																	case 29:
																																	case 38:
																																	case 43:
																																	case 44:
																																	case 49:
																																	case 53:
																																	case 55:
																																	case 67:
																																	case 68:
																																	case 88:
																																	case 110:
																																	case 119:
																																	case 122:
																																	case 128:
																																	case 136:
																																		goto end_IL_0368;
																																	case 39:
																																		goto end_IL_08ad;
																																	case 112:
																																		goto end_IL_08c0;
																																	case 129:
																																		goto end_IL_08ca;
																																	case 109:
																																		goto end_IL_08de;
																																	case 61:
																																	case 150:
																																		goto end_IL_08ee;
																																	case 65:
																																		goto end_IL_08fe;
																																	case 40:
																																	case 132:
																																		goto end_IL_090e;
																																	case 27:
																																		goto end_IL_0927;
																																	case 28:
																																		goto end_IL_0937;
																																	case 108:
																																	case 121:
																																		goto IL_095b;
																																	}
																																	continue;
																																}
																																array[num5 - 1] = 5;
																																goto end_IL_0368;
																																continue;
																																end_IL_0287:
																																break;
																															}
																															break;
																														}
																														goto IL_07d2;
																														continue;
																														end_IL_02ce:
																														break;
																														IL_02ce:;
																													}
																													break;
																													IL_02de:;
																												}
																												break;
																											}
																											goto IL_07c7;
																											IL_088a:
																											ptr2 += 8;
																											goto end_IL_0368;
																											IL_07c7:
																											if (2 <= b)
																											{
																												goto IL_07d2;
																											}
																											goto IL_0836;
																											IL_07d2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0812;
																											IL_0812:
																											array[num5 - 2] = 0;
																											goto IL_0826;
																											IL_0826:
																											num5--;
																											goto end_IL_0368;
																											IL_0836:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0841;
																											IL_0841:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_084c;
																											IL_084c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 34;
																											goto IL_086e;
																											IL_086e:
																											array[num5] = 0;
																											goto IL_087c;
																											IL_087c:
																											num5++;
																											goto IL_088a;
																										}
																										break;
																									}
																									goto IL_0383;
																									IL_041a:
																									num5--;
																									goto end_IL_0368;
																									IL_0383:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									num = 97;
																									goto IL_040c;
																									IL_040c:
																									ptr2 += 8;
																									goto IL_041a;
																								}
																								break;
																							}
																							goto IL_0373;
																							IL_04fb:
																							num5--;
																							goto end_IL_0368;
																							IL_0373:
																							if (6 >= b)
																							{
																								goto IL_03ac;
																							}
																							goto IL_04a8;
																							IL_03ac:
																							if (6 <= b)
																							{
																								goto IL_03ba;
																							}
																							goto IL_0445;
																							IL_03ba:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03f9;
																							IL_03f9:
																							num5 -= 3;
																							goto end_IL_0368;
																							IL_0445:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0453;
																							IL_0453:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0461;
																							IL_0461:
																							array[num5] = 5;
																							goto IL_046f;
																							IL_046f:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0487;
																							IL_0487:
																							num5++;
																							goto IL_0495;
																							IL_0495:
																							ptr2 += 8;
																							goto end_IL_0368;
																							IL_04a8:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_04b6;
																							IL_04b6:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_04c4;
																							IL_04c4:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04ed;
																							IL_04ed:
																							ptr2 += 8;
																							goto IL_04fb;
																						}
																						break;
																					}
																					goto IL_042d;
																					IL_042d:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0368;
																				}
																				break;
																			}
																			goto IL_050e;
																			IL_06b6:
																			num5++;
																			goto IL_0771;
																			IL_050e:
																			if (12 < b)
																			{
																				goto IL_0519;
																			}
																			goto IL_0548;
																			IL_0519:
																			if (14 >= b)
																			{
																				goto IL_0527;
																			}
																			goto IL_0784;
																			IL_0527:
																			if (14 > b)
																			{
																				goto IL_0535;
																			}
																			goto IL_06c9;
																			IL_0535:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_06ee;
																			IL_06ee:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_06fc;
																			IL_06fc:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_075e;
																			IL_075e:
																			num5 -= 2;
																			goto end_IL_0368;
																			IL_06c9:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 67;
																			goto end_IL_0368;
																			IL_0784:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0792;
																			IL_0792:
																			if (15 <= b)
																			{
																				num = 7;
																			}
																			break;
																			IL_0771:
																			ptr2 += 8;
																			goto end_IL_0368;
																			IL_0548:
																			if (12 <= b)
																			{
																				goto IL_0553;
																			}
																			goto IL_05ba;
																			IL_0553:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0593;
																			IL_0593:
																			array[num5 - 2] = 0;
																			goto IL_05a7;
																			IL_05a7:
																			num5--;
																			goto end_IL_0368;
																			IL_05ba:
																			if (10 < b)
																			{
																				goto IL_05c8;
																			}
																			goto IL_064f;
																			IL_05c8:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_05d6;
																			IL_05d6:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_05e4;
																			IL_05e4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0628;
																			IL_0628:
																			array[num5 - 2] = 0;
																			goto IL_063c;
																			IL_063c:
																			num5--;
																			goto end_IL_0368;
																			IL_064f:
																			if (10 > b)
																			{
																				goto IL_065a;
																			}
																			goto IL_067b;
																			IL_065a:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0668;
																			IL_0668:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0368;
																			IL_067b:
																			array[num5] = 0;
																			goto IL_0689;
																			IL_0689:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06ac;
																			IL_06ac:
																			array2[num5] = null;
																			goto IL_06b6;
																		}
																		break;
																		IL_0338:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0368;
																continue;
																end_IL_0348:
																break;
															}
															continue;
															end_IL_0358:
															break;
														}
														continue;
														end_IL_0368:
														break;
													}
													continue;
												}
												num = 121;
												goto IL_095b;
												IL_095b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ad:
												break;
											}
											continue;
											end_IL_08c0:
											break;
										}
										continue;
										end_IL_08ca:
										break;
									}
									continue;
									end_IL_08de:
									break;
								}
								continue;
								end_IL_08ee:
								break;
							}
							continue;
							end_IL_08fe:
							break;
						}
						continue;
						end_IL_090e:
						break;
					}
					continue;
					end_IL_0927:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	static Class20()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 16;
			while (true)
			{
				if (num != 16)
				{
					if (num != 997)
					{
						return;
					}
					switch (num)
					{
					case 6:
						goto end_IL_0049;
					case 1:
					case 3:
					case 7:
						goto IL_006d;
					case 0:
						return;
					case 2:
						return;
					case 4:
						return;
					case 5:
						return;
					case 8:
						return;
					case 9:
						return;
					}
					continue;
				}
				Class300.smethod_0();
				goto IL_006d;
				IL_006d:
				num = 5;
				return;
				continue;
				end_IL_0049:
				break;
			}
		}
	}
}
