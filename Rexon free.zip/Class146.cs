using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

[HarmonyPatch(typeof(GorillaGuardianManager), "LaunchPlayer")]
internal class Class146
{
	private static int int_0;

	private static float float_0;

	private static int int_1;

	private static int int_2;

	private static float float_1;

	private static IntPtr[] getCspKeyContainerInfoCheckOpenSubKeyWithWritablePermission;

	private static IntPtr[] ContractClassForAttributeSetThrowOnRelative;

	private static IntPtr[] getServicePackCheckKeyReadPermission;

	private static bool Prefix(NetPlayer launcher, Vector3 velocity)
	{
		int num = 92;
		num = 23;
		num = 399;
		num = 57;
		num = 23;
		num = 46;
		num = 63;
		num = 63;
		num = 213;
		num = 71;
		num = 825;
		num = 75;
		num = 71;
		num = 146;
		num = 5215;
		num = 5215;
		num = 5278;
		num = 363;
		num = 121;
		if (Class143.bool_0)
		{
			try
			{
				object obj = launcher;
				VRRig vRRig = GorillaGameManager.StaticFindRigForPlayer((NetPlayer)obj);
				obj = vRRig;
				object obj2 = obj;
				obj = obj2;
				object obj3 = null;
				if ((VRRig)obj == (UnityEngine.Object)obj3)
				{
					num = 0;
					return false;
				}
				obj = obj2;
				GorillaTagger instance = GorillaTagger.Instance;
				obj3 = instance;
				obj3 = ((GorillaTagger)obj3).offlineVRRig;
				if ((VRRig)obj == (VRRig)obj3)
				{
					num = 1;
					return true;
				}
				obj = obj2;
				Transform transform = ((VRRig)obj).transform;
				obj = transform;
				Vector3 position = ((Transform)obj).position;
				obj = position;
				GorillaTagger instance2 = GorillaTagger.Instance;
				obj3 = instance2;
				obj3 = ((GorillaTagger)obj3).offlineVRRig;
				Transform transform2 = ((VRRig)obj3).transform;
				obj3 = transform2;
				Vector3 position2 = ((Transform)obj3).position;
				obj3 = position2;
				float num2 = Vector3.Distance((Vector3)obj, (Vector3)obj3);
				double num3 = num2;
				double num4 = 10.0;
				if (!(num3 <= num4))
				{
					num = 0;
					return false;
				}
				obj = velocity;
				num3 = ((Vector3)obj).x;
				if (float.IsNaN((float)num3))
				{
					goto IL_020a;
				}
				obj = velocity;
				num3 = ((Vector3)obj).y;
				if (float.IsNaN((float)num3))
				{
					goto IL_020a;
				}
				obj = velocity;
				num3 = ((Vector3)obj).z;
				if (float.IsNaN((float)num3))
				{
					goto IL_020a;
				}
				obj = velocity;
				num3 = ((Vector3)obj).x;
				if (float.IsInfinity((float)num3))
				{
					goto IL_0286;
				}
				obj = velocity;
				num3 = ((Vector3)obj).y;
				if (float.IsInfinity((float)num3))
				{
					goto IL_0286;
				}
				obj = velocity;
				num3 = ((Vector3)obj).z;
				if (float.IsInfinity((float)num3))
				{
					goto IL_0286;
				}
				goto end_IL_0076;
				IL_020a:
				num = 0;
				return false;
				IL_0286:
				num = 0;
				return false;
				end_IL_0076:;
			}
			catch
			{
				num = 0;
				return false;
			}
			num = 1;
			return true;
		}
		num = 1;
		return true;
	}

	public Class146()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 97;
		byte b = default(byte);
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ForegroundIntensityIClientResponseChannelSinkStack.NativeNamesetIgnoreCase);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 173;
												while (true)
												{
													if (num == 173)
													{
														goto IL_0361;
													}
													if (num != 1154)
													{
														goto IL_0787;
													}
													switch (num)
													{
													case 35:
														goto end_IL_02c3;
													case 141:
														goto end_IL_02d6;
													case 1:
														goto end_IL_02e1;
													case 6:
														goto end_IL_02eb;
													case 134:
														goto end_IL_02f6;
													case 65:
													case 140:
														goto end_IL_0306;
													case 30:
														goto end_IL_0316;
													case 57:
													case 146:
														goto end_IL_0326;
													case 96:
														goto end_IL_0336;
													case 97:
														goto end_IL_0346;
													case 0:
													case 15:
													case 66:
													case 80:
													case 82:
													case 86:
													case 91:
													case 100:
													case 112:
													case 123:
													case 126:
													case 128:
													case 142:
													case 144:
													case 152:
													case 156:
													case 157:
													case 163:
														goto IL_0361;
													case 92:
													case 155:
														goto IL_0371;
													case 2:
														goto IL_037a;
													case 88:
														goto IL_0388;
													case 164:
														goto IL_0396;
													case 46:
														goto IL_03a4;
													case 132:
														goto IL_03b2;
													case 13:
													case 137:
														goto IL_03bd;
													case 52:
													case 129:
														goto IL_03cb;
													case 93:
														goto IL_03d9;
													case 135:
														goto IL_03e4;
													case 62:
														goto IL_03f2;
													case 53:
													case 75:
														goto IL_03fd;
													case 108:
														goto IL_040b;
													case 67:
														goto IL_0423;
													case 17:
														goto IL_0431;
													case 139:
													case 153:
														goto IL_0452;
													case 32:
														goto IL_0491;
													case 76:
														goto IL_04a4;
													case 133:
														goto IL_04af;
													case 148:
													case 154:
														goto IL_04bd;
													case 5:
														goto IL_04e6;
													case 81:
														goto IL_04f4;
													case 48:
														goto IL_0507;
													case 159:
														goto IL_0515;
													case 78:
													case 98:
														goto IL_0523;
													case 94:
														goto IL_053b;
													case 60:
														goto IL_0549;
													case 22:
													case 61:
														goto IL_0554;
													case 68:
														goto IL_0562;
													case 27:
													case 58:
														goto IL_0570;
													case 8:
														goto IL_0599;
													case 14:
														goto IL_05b2;
													case 101:
													case 105:
														goto IL_05bd;
													case 33:
														goto IL_05c8;
													case 84:
													case 125:
														goto IL_05d6;
													case 70:
														goto IL_05ef;
													case 120:
														goto IL_05fd;
													case 49:
														goto IL_060b;
													case 69:
													case 104:
														goto IL_062c;
													case 47:
														goto IL_066c;
													case 24:
														goto IL_0680;
													case 107:
													case 130:
														goto IL_069c;
													case 7:
														goto IL_06ba;
													case 20:
														goto IL_06c8;
													case 138:
														goto IL_06db;
													case 56:
													case 89:
														goto IL_06e9;
													case 158:
														goto IL_06f7;
													case 115:
														goto IL_0705;
													case 29:
														goto IL_0713;
													case 50:
													case 79:
														goto IL_0721;
													case 10:
														goto IL_0735;
													case 103:
														goto IL_0774;
													case 119:
													case 127:
														goto IL_0787;
													case 36:
														goto IL_079a;
													case 31:
													case 121:
														goto IL_07ae;
													case 45:
														goto IL_07bc;
													case 106:
														goto IL_07d8;
													case 149:
													case 150:
														goto IL_07e6;
													case 87:
														goto IL_0802;
													case 16:
													case 28:
														goto IL_0819;
													case 40:
														goto IL_0827;
													case 71:
													case 77:
														goto IL_0832;
													case 23:
														goto IL_0840;
													case 54:
													case 114:
														goto IL_084e;
													case 131:
														goto IL_085c;
													case 12:
														goto IL_087f;
													case 162:
														goto IL_0889;
													case 109:
														goto IL_0897;
													case 59:
													case 73:
														goto IL_08aa;
													case 63:
														goto IL_08ee;
													case 43:
														goto IL_0902;
													case 34:
														goto IL_0915;
													case 143:
														goto IL_0923;
													case 21:
													case 38:
														goto IL_0931;
													case 19:
														goto IL_097a;
													case 3:
														goto IL_098e;
													case 51:
													case 147:
														goto IL_09a1;
													case 42:
														goto IL_0a0c;
													case 4:
													case 9:
													case 11:
													case 18:
													case 25:
													case 26:
													case 37:
													case 39:
													case 41:
													case 44:
													case 55:
													case 64:
													case 72:
													case 74:
													case 83:
													case 85:
													case 95:
													case 99:
													case 102:
													case 110:
													case 111:
													case 113:
													case 116:
													case 117:
													case 118:
													case 122:
													case 124:
													case 136:
													case 145:
													case 160:
													case 161:
													case 165:
													case 166:
														goto IL_0a1f;
													case 90:
													case 151:
														goto IL_0a37;
													}
													continue;
													IL_0923:
													if (12 <= b)
													{
														goto IL_0931;
													}
													goto IL_0a1f;
													IL_0931:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													num = 19;
													goto IL_097a;
													IL_0361:
													if (num5 != 1)
													{
														goto IL_0371;
													}
													goto IL_0a37;
													IL_0a37:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0371:
													b = *ptr2;
													goto IL_037a;
													IL_037a:
													ptr2++;
													goto IL_0388;
													IL_0388:
													if (b >= 1)
													{
														goto IL_0396;
													}
													goto IL_0a1f;
													IL_0396:
													if (b <= 17)
													{
														goto IL_03a4;
													}
													goto IL_0a1f;
													IL_03a4:
													if (9 >= b)
													{
														goto IL_03b2;
													}
													goto IL_06db;
													IL_03b2:
													if (9 <= b)
													{
														goto IL_0361;
													}
													goto IL_03bd;
													IL_03bd:
													if (4 < b)
													{
														goto IL_03cb;
													}
													goto IL_053b;
													IL_03cb:
													if (6 >= b)
													{
														goto IL_03d9;
													}
													goto IL_04a4;
													IL_03d9:
													if (6 > b)
													{
														goto IL_03e4;
													}
													goto IL_0452;
													IL_03e4:
													if (5 >= b)
													{
														goto IL_03f2;
													}
													goto IL_0a1f;
													IL_03f2:
													if (5 <= b)
													{
														goto IL_03fd;
													}
													num = 37;
													goto IL_0a1f;
													IL_03fd:
													array[num4] = 5;
													goto IL_040b;
													IL_040b:
													array2[num4] = array5[*(int*)(ptr2 + num3)];
													goto IL_0423;
													IL_0423:
													num4++;
													goto IL_0431;
													IL_0431:
													ptr2 += 8;
													goto IL_0361;
													IL_097a:
													array[num4 - 2] = 0;
													goto IL_098e;
													IL_0452:
													((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0491;
													IL_0491:
													num4 -= 3;
													goto IL_0361;
													IL_04a4:
													if (7 >= b)
													{
														goto IL_04af;
													}
													goto IL_0507;
													IL_04af:
													if (7 <= b)
													{
														goto IL_04bd;
													}
													goto IL_0a1f;
													IL_04bd:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_04e6;
													IL_04e6:
													ptr2 += 8;
													goto IL_04f4;
													IL_04f4:
													num4--;
													goto IL_0361;
													IL_0507:
													if (8 >= b)
													{
														goto IL_0515;
													}
													goto IL_0a1f;
													IL_0515:
													if (8 <= b)
													{
														goto IL_0523;
													}
													goto IL_0a1f;
													IL_0523:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0361;
													IL_053b:
													if (4 > b)
													{
														goto IL_0549;
													}
													goto IL_069c;
													IL_0549:
													if (2 < b)
													{
														goto IL_0554;
													}
													goto IL_05b2;
													IL_0554:
													if (3 >= b)
													{
														goto IL_0562;
													}
													goto IL_0a1f;
													IL_0562:
													if (3 <= b)
													{
														goto IL_0570;
													}
													goto IL_0a1f;
													IL_0570:
													array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_0599;
													IL_0599:
													array[num4 - 1] = 5;
													goto IL_0361;
													IL_05b2:
													if (2 > b)
													{
														goto IL_05bd;
													}
													goto IL_062c;
													IL_05bd:
													if (1 >= b)
													{
														goto IL_05c8;
													}
													num = 122;
													goto IL_0a1f;
													IL_05c8:
													if (1 <= b)
													{
														goto IL_05d6;
													}
													goto IL_0a1f;
													IL_05d6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_05ef;
													IL_05ef:
													array[num4] = 0;
													goto IL_05fd;
													IL_05fd:
													num4++;
													goto IL_060b;
													IL_060b:
													ptr2 += 8;
													goto IL_0361;
													IL_098e:
													num4--;
													goto IL_0361;
													IL_062c:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_066c;
													IL_066c:
													array[num4 - 2] = 0;
													goto IL_0680;
													IL_0680:
													num4--;
													num = 126;
													goto IL_0361;
													IL_069c:
													array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
													goto IL_06ba;
													IL_06ba:
													ptr2 += 8;
													goto IL_06c8;
													IL_06c8:
													num4--;
													goto IL_0361;
													IL_06db:
													if (13 < b)
													{
														goto IL_06e9;
													}
													goto IL_0802;
													IL_06e9:
													if (15 >= b)
													{
														goto IL_06f7;
													}
													goto IL_079a;
													IL_06f7:
													if (15 > b)
													{
														goto IL_0705;
													}
													goto IL_0787;
													IL_0705:
													if (14 >= b)
													{
														goto IL_0713;
													}
													goto IL_0a1f;
													IL_0713:
													if (14 <= b)
													{
														goto IL_0721;
													}
													goto IL_0a1f;
													IL_0721:
													array[num4 - 1] = 0;
													goto IL_0735;
													IL_0735:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]) = ((delegate*<int, int>)getCspKeyContainerInfoCheckOpenSubKeyWithWritablePermission[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
													goto IL_0774;
													IL_0774:
													ptr2 += 8;
													goto IL_0361;
													IL_0787:
													num4--;
													goto IL_0361;
													IL_079a:
													if (16 < b)
													{
														num = 121;
														goto IL_07ae;
													}
													goto IL_07d8;
													IL_09a1:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													num = 42;
													goto IL_0a0c;
													IL_07ae:
													if (17 >= b)
													{
														goto IL_07bc;
													}
													goto IL_0a1f;
													IL_07bc:
													if (17 <= b)
													{
														num = 145;
													}
													goto IL_0a1f;
													IL_0a0c:
													num4 -= 2;
													goto IL_0361;
													IL_07d8:
													if (16 <= b)
													{
														goto IL_07e6;
													}
													goto IL_0a1f;
													IL_07e6:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0361;
													IL_0802:
													if (13 > b)
													{
														num = 16;
														goto IL_0819;
													}
													goto IL_09a1;
													IL_0a1f:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0361;
													IL_0819:
													if (11 >= b)
													{
														goto IL_0827;
													}
													goto IL_0915;
													IL_0827:
													if (11 > b)
													{
														goto IL_0832;
													}
													goto IL_08aa;
													IL_0832:
													if (10 >= b)
													{
														goto IL_0840;
													}
													goto IL_0a1f;
													IL_0840:
													if (10 <= b)
													{
														goto IL_084e;
													}
													goto IL_0a1f;
													IL_084e:
													array[num4] = 0;
													goto IL_085c;
													IL_085c:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_087f;
													IL_087f:
													array2[num4] = null;
													goto IL_0889;
													IL_0889:
													num4++;
													goto IL_0897;
													IL_0897:
													ptr2 += 8;
													goto IL_0361;
													IL_08aa:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_08ee;
													IL_08ee:
													array[num4 - 2] = 0;
													goto IL_0902;
													IL_0902:
													num4--;
													goto IL_0361;
													IL_0915:
													if (12 >= b)
													{
														goto IL_0923;
													}
													goto IL_0a1f;
													continue;
													end_IL_02c3:
													break;
												}
												continue;
												end_IL_02d6:
												break;
											}
											continue;
											end_IL_02e1:
											break;
										}
										continue;
										end_IL_02eb:
										break;
									}
									continue;
									end_IL_02f6:
									break;
								}
								continue;
								end_IL_0306:
								break;
							}
							continue;
							end_IL_0316:
							break;
						}
						continue;
						end_IL_0326:
						break;
					}
					continue;
					end_IL_0336:
					break;
				}
				continue;
				end_IL_0346:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									num = 53;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FoundDatePatterngetBinaryLength.ExecutionEngineExceptionCATEGORYINSTANCE);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025b:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_023b:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_022b:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_021b:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_020b:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (true)
																											{
																												IL_01e8:
																												if (1 > b)
																												{
																													num = 110;
																													while (num != 110)
																													{
																														if (num != 1091)
																														{
																															goto IL_05b2;
																														}
																														switch (num)
																														{
																														case 67:
																															goto IL_01e8;
																														case 61:
																															goto IL_01fb;
																														case 52:
																															goto IL_020b;
																														case 60:
																															goto IL_021b;
																														case 93:
																															goto IL_022b;
																														case 47:
																															goto IL_023b;
																														case 16:
																															goto IL_024b;
																														case 68:
																															goto IL_025b;
																														case 95:
																															goto end_IL_025b;
																														case 22:
																														case 41:
																															goto end_IL_026b;
																														case 32:
																														case 33:
																															goto IL_0286;
																														case 27:
																														case 75:
																															goto IL_02a4;
																														case 58:
																															goto IL_02cd;
																														case 87:
																															goto IL_02e0;
																														case 10:
																														case 14:
																															goto IL_02eb;
																														case 71:
																															goto IL_02f6;
																														case 3:
																														case 28:
																															goto IL_0304;
																														case 9:
																														case 57:
																															goto IL_0320;
																														case 77:
																															goto IL_032e;
																														case 12:
																															goto IL_0341;
																														case 11:
																															goto IL_034c;
																														case 79:
																															goto IL_035a;
																														case 15:
																															goto IL_0368;
																														case 7:
																														case 76:
																															goto IL_0376;
																														case 39:
																															goto IL_0399;
																														case 70:
																															goto IL_03a7;
																														case 38:
																															goto IL_03b5;
																														case 46:
																														case 51:
																															goto IL_03c8;
																														case 80:
																															goto IL_0433;
																														case 94:
																															goto IL_0446;
																														case 99:
																															goto IL_0462;
																														case 35:
																															goto IL_0479;
																														case 20:
																															goto IL_0487;
																														case 103:
																															goto IL_049a;
																														case 81:
																														case 96:
																															goto IL_04b3;
																														case 73:
																															goto IL_04fc;
																														case 74:
																															goto IL_0510;
																														case 88:
																															goto IL_052c;
																														case 65:
																															goto IL_0537;
																														case 5:
																														case 29:
																															goto IL_0545;
																														case 21:
																															goto IL_055d;
																														case 72:
																															goto IL_0568;
																														case 37:
																														case 101:
																															goto IL_0581;
																														case 26:
																															goto IL_058f;
																														case 30:
																															goto IL_05b2;
																														case 13:
																															goto IL_05bc;
																														case 83:
																															goto IL_05ca;
																														case 6:
																														case 17:
																														case 18:
																														case 25:
																														case 31:
																														case 44:
																														case 48:
																														case 49:
																														case 50:
																														case 55:
																														case 64:
																														case 66:
																														case 69:
																														case 78:
																														case 86:
																														case 89:
																														case 92:
																														case 97:
																														case 98:
																														case 100:
																															goto end_IL_01d5;
																														case 8:
																														case 19:
																														case 23:
																														case 36:
																														case 42:
																														case 43:
																														case 45:
																														case 54:
																														case 62:
																														case 63:
																														case 82:
																														case 85:
																														case 91:
																															goto end_IL_027b;
																														case 90:
																															goto end_IL_05f6;
																														case 53:
																															goto end_IL_0609;
																														case 24:
																															goto end_IL_0613;
																														case 40:
																															goto end_IL_061e;
																														case 4:
																														case 84:
																															goto end_IL_063c;
																														case 34:
																															goto end_IL_064c;
																														case 56:
																														case 102:
																															goto end_IL_065c;
																														case 0:
																															goto end_IL_066c;
																														case 1:
																															goto end_IL_067c;
																														case 2:
																														case 59:
																															goto IL_0697;
																														}
																														continue;
																														end_IL_01d5:
																														break;
																													}
																													break;
																												}
																												goto IL_0286;
																												IL_0479:
																												num5++;
																												goto IL_0487;
																												IL_0487:
																												ptr2 += 8;
																												goto end_IL_027b;
																												IL_0286:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0462;
																												IL_0462:
																												array[num5] = 0;
																												num = 35;
																												goto IL_0479;
																											}
																											break;
																											IL_01fb:;
																										}
																										break;
																									}
																									goto IL_02a4;
																									IL_0446:
																									num5--;
																									num = 8;
																									goto end_IL_027b;
																									IL_02a4:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_02cd;
																									IL_02cd:
																									ptr2 += 8;
																									goto IL_0446;
																								}
																								break;
																							}
																							goto IL_052c;
																							IL_0568:
																							if (4 <= b)
																							{
																								goto end_IL_027b;
																							}
																							num = 50;
																							break;
																							IL_052c:
																							if (3 >= b)
																							{
																								goto IL_0537;
																							}
																							goto IL_055d;
																							IL_0537:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0545;
																							IL_0545:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_027b;
																							IL_055d:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0568;
																						}
																						break;
																					}
																					goto IL_0581;
																					IL_05ca:
																					ptr2 += 8;
																					goto end_IL_027b;
																					IL_0581:
																					array[num5] = 0;
																					goto IL_058f;
																					IL_058f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05b2;
																					IL_05b2:
																					array2[num5] = null;
																					goto IL_05bc;
																					IL_05bc:
																					num5++;
																					goto IL_05ca;
																				}
																				break;
																			}
																			goto IL_02e0;
																			IL_03c8:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 80;
																			goto IL_0433;
																			IL_02e0:
																			if (8 < b)
																			{
																				goto IL_02eb;
																			}
																			goto IL_0341;
																			IL_02eb:
																			if (9 >= b)
																			{
																				goto IL_02f6;
																			}
																			goto IL_0320;
																			IL_02f6:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0304;
																			IL_0304:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_027b;
																			IL_0320:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_032e;
																			IL_032e:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_0341:
																			if (8 > b)
																			{
																				goto IL_034c;
																			}
																			goto IL_03c8;
																			IL_034c:
																			if (6 < b)
																			{
																				goto IL_035a;
																			}
																			goto IL_049a;
																			IL_035a:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0368;
																			IL_0368:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0376;
																			IL_0376:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0399;
																			IL_0399:
																			array[num5] = 0;
																			goto IL_03a7;
																			IL_03a7:
																			num5++;
																			goto IL_03b5;
																			IL_03b5:
																			ptr2 += 8;
																			goto end_IL_027b;
																			IL_049a:
																			if (6 > b)
																			{
																				num = 17;
																				break;
																			}
																			goto IL_04b3;
																			IL_0433:
																			num5 -= 2;
																			goto end_IL_027b;
																			IL_04b3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 73;
																			goto IL_04fc;
																			IL_04fc:
																			array[num5 - 2] = 0;
																			goto IL_0510;
																			IL_0510:
																			num5--;
																			num = 85;
																			goto end_IL_027b;
																		}
																		break;
																		IL_024b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 54;
																goto end_IL_027b;
																continue;
																end_IL_025b:
																break;
															}
															continue;
															end_IL_026b:
															break;
														}
														continue;
														end_IL_027b:
														break;
													}
													continue;
												}
												goto IL_0697;
												IL_0697:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f6:
												break;
											}
											continue;
											end_IL_0609:
											break;
										}
										continue;
										end_IL_0613:
										break;
									}
									continue;
									end_IL_061e:
									break;
								}
								continue;
								end_IL_063c:
								break;
							}
							continue;
							end_IL_064c:
							break;
						}
						continue;
						end_IL_065c:
						break;
					}
					continue;
					end_IL_066c:
					break;
				}
				continue;
				end_IL_067c:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 87;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 86;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndEventaddContractFailed.CreateValueCallbackGetDayOfWeek);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0371:
														byte b = *ptr2;
														while (true)
														{
															IL_0361:
															ptr2++;
															while (true)
															{
																IL_0351:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0331:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0311:
																						if (4 < b)
																						{
																							num = 7;
																							while (true)
																							{
																								IL_0301:
																								if (6 < b)
																								{
																									while (true)
																									{
																										IL_02f1:
																										if (7 >= b)
																										{
																											while (true)
																											{
																												IL_02de:
																												if (7 > b)
																												{
																													num = 168;
																													while (num != 168 && num == 1149)
																													{
																														switch (num)
																														{
																														case 17:
																															goto IL_02de;
																														case 12:
																															goto IL_02f1;
																														case 7:
																														case 147:
																															goto IL_0301;
																														case 129:
																														case 156:
																															goto IL_0311;
																														case 68:
																															goto IL_0321;
																														case 139:
																															goto IL_0331;
																														case 50:
																															goto IL_0341;
																														case 113:
																															goto IL_0351;
																														case 106:
																															goto IL_0361;
																														case 61:
																														case 94:
																															goto IL_0371;
																														case 80:
																															goto IL_037c;
																														case 63:
																															goto IL_038a;
																														case 5:
																															goto IL_0398;
																														case 97:
																															goto IL_03a8;
																														case 59:
																															goto IL_03b6;
																														case 34:
																															goto IL_03c4;
																														case 91:
																														case 98:
																															goto IL_03d7;
																														case 30:
																															goto IL_0417;
																														case 58:
																															goto IL_042b;
																														case 126:
																														case 128:
																															goto IL_043e;
																														case 103:
																															goto IL_045c;
																														case 114:
																															goto IL_0473;
																														case 108:
																														case 151:
																															goto IL_0486;
																														case 100:
																															goto IL_0494;
																														case 65:
																														case 119:
																															goto IL_04a2;
																														case 127:
																															goto IL_04bb;
																														case 48:
																															goto IL_04c9;
																														case 67:
																															goto IL_04d7;
																														case 44:
																														case 152:
																															goto IL_04ea;
																														case 38:
																															goto IL_04f8;
																														case 149:
																														case 154:
																															goto IL_0512;
																														case 74:
																															goto IL_0551;
																														case 157:
																															goto IL_0564;
																														case 18:
																															goto IL_0572;
																														case 47:
																														case 158:
																															goto IL_0585;
																														case 32:
																															goto IL_0593;
																														case 96:
																														case 104:
																															goto IL_05a1;
																														case 35:
																															goto IL_05ca;
																														case 137:
																														case 153:
																															goto IL_05e3;
																														case 31:
																															goto IL_060c;
																														case 66:
																															goto IL_061a;
																														case 8:
																														case 20:
																															goto IL_0636;
																														case 2:
																															goto IL_0644;
																														case 95:
																														case 117:
																															goto IL_0652;
																														case 13:
																															goto IL_0673;
																														case 42:
																														case 49:
																															goto IL_0681;
																														case 110:
																															goto IL_068f;
																														case 99:
																														case 101:
																															goto IL_069a;
																														case 88:
																															goto IL_06ad;
																														case 132:
																															goto IL_06bb;
																														case 9:
																														case 70:
																															goto IL_06c9;
																														case 84:
																															goto IL_06dd;
																														case 23:
																															goto IL_071c;
																														case 77:
																														case 150:
																															goto IL_0738;
																														case 39:
																															goto IL_0743;
																														case 3:
																														case 122:
																															goto IL_0751;
																														case 82:
																														case 159:
																															goto IL_076d;
																														case 155:
																															goto IL_077b;
																														case 14:
																															goto IL_078e;
																														case 22:
																														case 79:
																															goto IL_079c;
																														case 10:
																														case 29:
																															goto IL_07aa;
																														case 133:
																															goto IL_07b8;
																														case 60:
																														case 64:
																															goto IL_07c6;
																														case 6:
																															goto IL_0806;
																														case 112:
																															goto IL_0823;
																														case 92:
																															goto IL_0836;
																														case 123:
																														case 160:
																															goto IL_0844;
																														case 73:
																															goto IL_0852;
																														case 37:
																														case 54:
																															goto IL_0869;
																														case 75:
																															goto IL_0877;
																														case 71:
																															goto IL_089a;
																														case 81:
																															goto IL_08a4;
																														case 56:
																															goto IL_08b2;
																														case 52:
																														case 145:
																															goto IL_08c5;
																														case 55:
																															goto IL_0909;
																														case 69:
																															goto IL_091d;
																														case 72:
																														case 109:
																															goto IL_0930;
																														case 124:
																															goto IL_0992;
																														case 4:
																														case 11:
																														case 15:
																														case 21:
																														case 25:
																														case 26:
																														case 28:
																														case 40:
																														case 43:
																														case 45:
																														case 51:
																														case 53:
																														case 57:
																														case 89:
																														case 93:
																														case 125:
																														case 130:
																														case 131:
																														case 136:
																														case 138:
																														case 141:
																														case 142:
																														case 144:
																														case 146:
																															goto end_IL_02cb;
																														case 1:
																														case 24:
																														case 33:
																														case 41:
																														case 62:
																														case 76:
																														case 78:
																														case 85:
																														case 90:
																														case 102:
																														case 107:
																														case 111:
																														case 115:
																														case 118:
																														case 120:
																														case 121:
																														case 134:
																														case 140:
																														case 148:
																														case 161:
																															goto end_IL_0321;
																														case 0:
																															goto end_IL_09b5;
																														case 116:
																															goto end_IL_09c8;
																														case 16:
																															goto end_IL_09d2;
																														case 135:
																															goto end_IL_09dd;
																														case 36:
																														case 46:
																															goto end_IL_09ed;
																														case 105:
																															goto end_IL_09fd;
																														case 19:
																														case 27:
																															goto end_IL_0a0d;
																														case 86:
																															goto end_IL_0a1d;
																														case 87:
																															goto end_IL_0a2d;
																														case 83:
																														case 143:
																															goto IL_0a51;
																														}
																														continue;
																														end_IL_02cb:
																														break;
																													}
																													break;
																												}
																												goto IL_05e3;
																												IL_060c:
																												ptr2 += 8;
																												goto IL_061a;
																												IL_061a:
																												num5--;
																												goto end_IL_0321;
																												IL_05e3:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_060c;
																											}
																											break;
																										}
																										num = 8;
																										goto IL_0636;
																										IL_0644:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_0652;
																										IL_0652:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										num = 120;
																										goto end_IL_0321;
																										IL_0636:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0644;
																									}
																									break;
																								}
																								goto IL_03a8;
																								IL_0551:
																								num5 -= 3;
																								goto end_IL_0321;
																								IL_03a8:
																								if (6 > b)
																								{
																									goto IL_03b6;
																								}
																								goto IL_0512;
																								IL_03b6:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_03c4;
																								IL_03c4:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_04ea;
																								IL_04ea:
																								array[num5] = 5;
																								goto IL_04f8;
																								IL_04f8:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0564;
																								IL_0564:
																								num5++;
																								goto IL_0572;
																								IL_0572:
																								ptr2 += 8;
																								goto end_IL_0321;
																								IL_0512:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0551;
																							}
																							break;
																						}
																						goto IL_037c;
																						IL_045c:
																						ptr2 += 8;
																						num = 114;
																						goto IL_0473;
																						IL_0473:
																						num5--;
																						goto end_IL_0321;
																						IL_037c:
																						if (4 > b)
																						{
																							goto IL_038a;
																						}
																						goto IL_043e;
																						IL_038a:
																						if (2 >= b)
																						{
																							goto IL_0398;
																						}
																						goto IL_0585;
																						IL_0398:
																						if (2 <= b)
																						{
																							goto IL_03d7;
																						}
																						goto IL_0486;
																						IL_0486:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0494;
																						IL_0494:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_04a2;
																						IL_04a2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_04bb;
																						IL_04bb:
																						array[num5] = 0;
																						goto IL_04c9;
																						IL_04c9:
																						num5++;
																						goto IL_04d7;
																						IL_04d7:
																						ptr2 += 8;
																						goto end_IL_0321;
																						IL_03d7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0417;
																						IL_0417:
																						array[num5 - 2] = 0;
																						goto IL_042b;
																						IL_042b:
																						num5--;
																						goto end_IL_0321;
																						IL_0585:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_0593;
																						IL_0593:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_05a1;
																						IL_05a1:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_05ca;
																						IL_05ca:
																						array[num5 - 1] = 5;
																						goto end_IL_0321;
																						IL_043e:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_045c;
																					}
																					goto end_IL_0341;
																					continue;
																					end_IL_0321:
																					break;
																					IL_0321:;
																				}
																				break;
																			}
																			goto IL_0673;
																			IL_091d:
																			num5--;
																			break;
																			IL_0673:
																			if (13 < b)
																			{
																				goto IL_0681;
																			}
																			goto IL_078e;
																			IL_0681:
																			if (15 >= b)
																			{
																				goto IL_068f;
																			}
																			num = 150;
																			goto IL_0738;
																			IL_068f:
																			if (15 <= b)
																			{
																				goto IL_069a;
																			}
																			goto IL_06ad;
																			IL_069a:
																			num5--;
																			break;
																			IL_06ad:
																			if (14 < b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_06bb;
																			IL_06bb:
																			if (14 > b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_06c9;
																			IL_06c9:
																			array[num5 - 1] = 0;
																			goto IL_06dd;
																			IL_06dd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ContractClassForAttributeSetThrowOnRelative[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_071c;
																			IL_071c:
																			ptr2 += 8;
																			break;
																			IL_0930:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0992;
																			IL_0738:
																			if (16 >= b)
																			{
																				goto IL_0743;
																			}
																			goto IL_076d;
																			IL_0743:
																			if (16 > b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_0751;
																			IL_0751:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_076d:
																			if (17 < b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_077b;
																			IL_077b:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_0341;
																			IL_078e:
																			if (13 > b)
																			{
																				goto IL_079c;
																			}
																			goto IL_0930;
																			IL_079c:
																			if (11 < b)
																			{
																				goto IL_07aa;
																			}
																			goto IL_0836;
																			IL_07aa:
																			if (12 < b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_07b8;
																			IL_07b8:
																			if (12 > b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_07c6;
																			IL_07c6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0806;
																			IL_0806:
																			array[num5 - 2] = 0;
																			num = 112;
																			goto IL_0823;
																			IL_0823:
																			num5--;
																			break;
																			IL_0836:
																			if (11 > b)
																			{
																				goto IL_0844;
																			}
																			goto IL_08c5;
																			IL_0844:
																			if (10 < b)
																			{
																				goto end_IL_0341;
																			}
																			goto IL_0852;
																			IL_0852:
																			if (10 > b)
																			{
																				goto end_IL_0341;
																			}
																			num = 37;
																			goto IL_0869;
																			IL_0992:
																			num5 -= 2;
																			break;
																			IL_0869:
																			array[num5] = 0;
																			goto IL_0877;
																			IL_0877:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_089a;
																			IL_089a:
																			array2[num5] = null;
																			goto IL_08a4;
																			IL_08a4:
																			num5++;
																			goto IL_08b2;
																			IL_08b2:
																			ptr2 += 8;
																			break;
																			IL_08c5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0909;
																			IL_0909:
																			array[num5 - 2] = 0;
																			goto IL_091d;
																		}
																		goto end_IL_0351;
																		continue;
																		end_IL_0341:
																		break;
																		IL_0341:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0351:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a51;
												IL_0a51:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09b5:
												break;
											}
											continue;
											end_IL_09c8:
											break;
										}
										continue;
										end_IL_09d2:
										break;
									}
									continue;
									end_IL_09dd:
									break;
								}
								continue;
								end_IL_09ed:
								break;
							}
							continue;
							end_IL_09fd:
							break;
						}
						continue;
						end_IL_0a0d:
						break;
					}
					continue;
					end_IL_0a1d:
					break;
				}
				continue;
				end_IL_0a2d:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3)
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			num = 27;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MonthDayPatternSystemThreadingTasksFutureDebugView.InternIStringable);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_06c9:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 127;
												while (true)
												{
													if (num != 127)
													{
														if (num != 1108)
														{
															break;
														}
														switch (num)
														{
														case 32:
														case 76:
															break;
														case 9:
															goto IL_0017;
														case 86:
															goto IL_0025;
														case 34:
															goto IL_0033;
														case 45:
															goto IL_0041;
														case 42:
															goto IL_004f;
														case 57:
														case 71:
															goto IL_005d;
														case 19:
														case 118:
															goto IL_006b;
														case 70:
															goto IL_0076;
														case 0:
															goto IL_0089;
														case 52:
															goto IL_0097;
														case 66:
														case 103:
															goto IL_00a5;
														case 13:
															goto IL_00b3;
														case 112:
															goto IL_00d6;
														case 47:
															goto IL_00e9;
														case 10:
															goto IL_00f7;
														case 87:
															goto IL_010a;
														case 14:
														case 69:
															goto IL_0118;
														case 17:
															goto IL_0123;
														case 82:
															goto IL_0131;
														case 2:
														case 25:
															goto IL_013f;
														case 1:
															goto IL_0168;
														case 37:
															goto IL_0176;
														case 109:
															goto IL_0189;
														case 64:
														case 92:
															goto IL_0197;
														case 4:
															goto IL_01b0;
														case 62:
															goto IL_01be;
														case 49:
															goto IL_01cc;
														case 50:
														case 96:
															goto IL_01df;
														case 100:
														case 110:
															goto IL_0200;
														case 38:
															goto IL_0240;
														case 53:
															goto IL_0254;
														case 68:
															goto IL_0267;
														case 22:
														case 116:
															goto IL_0275;
														case 58:
															goto IL_0280;
														case 39:
														case 119:
															goto IL_028b;
														case 44:
															goto IL_02a7;
														case 59:
															goto IL_02b5;
														case 24:
														case 80:
															goto IL_02c3;
														case 43:
														case 81:
															goto IL_02df;
														case 78:
															goto IL_02ed;
														case 21:
															goto IL_0309;
														case 60:
															goto IL_0317;
														case 11:
														case 88:
															goto IL_0325;
														case 120:
															goto IL_0333;
														case 8:
														case 20:
															goto IL_0341;
														case 35:
															goto IL_03a3;
														case 84:
															goto IL_03bf;
														case 30:
														case 113:
															goto IL_03cd;
														case 29:
															goto IL_03f0;
														case 97:
															goto IL_0407;
														case 46:
															goto IL_041e;
														case 16:
														case 77:
															goto IL_043a;
														case 75:
															goto IL_0448;
														case 61:
															goto IL_046c;
														case 83:
															goto IL_047a;
														case 3:
														case 6:
														case 7:
														case 12:
														case 18:
														case 26:
														case 55:
														case 79:
														case 90:
														case 91:
														case 93:
														case 94:
														case 98:
														case 99:
														case 101:
														case 105:
														case 106:
														case 108:
														case 111:
														case 115:
														case 117:
															goto end_IL_06b6;
														default:
															continue;
														case 5:
														case 23:
														case 36:
														case 40:
														case 41:
														case 54:
														case 63:
														case 67:
														case 72:
														case 73:
														case 85:
														case 89:
														case 102:
														case 104:
														case 114:
															goto IL_06c9;
														case 74:
															goto end_IL_06c9;
														case 31:
															goto end_IL_06dc;
														case 51:
															goto end_IL_06e6;
														case 56:
															goto end_IL_06f1;
														case 15:
														case 48:
															goto end_IL_0706;
														case 107:
															goto end_IL_0716;
														case 65:
														case 95:
															goto end_IL_0726;
														case 27:
															goto end_IL_0736;
														case 28:
															goto end_IL_0746;
														case 33:
															goto IL_076a;
														}
														goto IL_000e;
													}
													goto IL_076a;
													IL_076a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_06b6:
													break;
												}
												goto IL_0496;
												IL_043a:
												array[num5] = 0;
												goto IL_0448;
												IL_0448:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getServicePackCheckKeyReadPermission[*(int*)(ptr2 + num3)])();
												goto IL_046c;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_0496;
												IL_0033:
												if (b <= 12)
												{
													goto IL_0041;
												}
												goto IL_0496;
												IL_0041:
												if (6 >= b)
												{
													goto IL_004f;
												}
												goto IL_0267;
												IL_004f:
												if (6 > b)
												{
													goto IL_005d;
												}
												goto IL_0200;
												IL_005d:
												if (3 < b)
												{
													goto IL_006b;
												}
												goto IL_010a;
												IL_006b:
												if (4 >= b)
												{
													goto IL_0076;
												}
												goto IL_0089;
												IL_0076:
												if (4 <= b)
												{
													continue;
												}
												goto IL_0496;
												IL_0089:
												if (5 >= b)
												{
													goto IL_0097;
												}
												goto IL_0496;
												IL_0097:
												if (5 <= b)
												{
													goto IL_00a5;
												}
												goto IL_0496;
												IL_00a5:
												array[num5] = 0;
												goto IL_00b3;
												IL_00b3:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_00d6;
												IL_00d6:
												array2[num5] = null;
												num = 47;
												goto IL_00e9;
												IL_00e9:
												num5++;
												goto IL_00f7;
												IL_00f7:
												ptr2 += 8;
												continue;
												IL_010a:
												if (3 > b)
												{
													goto IL_0118;
												}
												goto IL_01df;
												IL_0118:
												if (1 < b)
												{
													goto IL_0123;
												}
												goto IL_0189;
												IL_0123:
												if (2 >= b)
												{
													goto IL_0131;
												}
												goto IL_0496;
												IL_0131:
												if (2 <= b)
												{
													goto IL_013f;
												}
												goto IL_0496;
												IL_013f:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0168;
												IL_0168:
												ptr2 += 8;
												goto IL_0176;
												IL_0176:
												num5--;
												continue;
												IL_0189:
												if (1 <= b)
												{
													goto IL_0197;
												}
												goto IL_0496;
												IL_0197:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_01b0;
												IL_01b0:
												array[num5] = 0;
												goto IL_01be;
												IL_01be:
												num5++;
												goto IL_01cc;
												IL_01cc:
												ptr2 += 8;
												continue;
												IL_01df:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 67;
												continue;
												IL_0200:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0240;
												IL_0240:
												array[num5 - 2] = 0;
												goto IL_0254;
												IL_0254:
												num5--;
												continue;
												IL_0267:
												if (9 < b)
												{
													goto IL_0275;
												}
												goto IL_0309;
												IL_0275:
												if (11 >= b)
												{
													goto IL_0280;
												}
												num = 81;
												goto IL_02df;
												IL_0280:
												if (11 <= b)
												{
													goto IL_028b;
												}
												goto IL_02a7;
												IL_028b:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_02a7:
												if (10 >= b)
												{
													goto IL_02b5;
												}
												goto IL_0496;
												IL_02b5:
												if (10 <= b)
												{
													goto IL_02c3;
												}
												goto IL_0496;
												IL_02c3:
												num5--;
												continue;
												IL_046c:
												num5++;
												goto IL_047a;
												IL_02df:
												if (12 >= b)
												{
													goto IL_02ed;
												}
												goto IL_0496;
												IL_02ed:
												if (12 <= b)
												{
													num = 6;
												}
												goto IL_0496;
												IL_047a:
												ptr2 += 8;
												num = 102;
												continue;
												IL_0309:
												if (9 > b)
												{
													goto IL_0317;
												}
												num = 16;
												goto IL_043a;
												IL_0317:
												if (7 < b)
												{
													goto IL_0325;
												}
												goto IL_03bf;
												IL_0325:
												if (8 >= b)
												{
													goto IL_0333;
												}
												goto IL_0496;
												IL_0333:
												if (8 <= b)
												{
													goto IL_0341;
												}
												goto IL_0496;
												IL_0341:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_03a3;
												IL_03a3:
												num5 -= 2;
												num = 54;
												continue;
												IL_03bf:
												if (7 <= b)
												{
													goto IL_03cd;
												}
												goto IL_0496;
												IL_03cd:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_03f0;
												IL_03f0:
												array[num5] = 0;
												num = 97;
												goto IL_0407;
												IL_0407:
												num5++;
												num = 46;
												goto IL_041e;
												IL_041e:
												ptr2 += 8;
												continue;
												IL_0496:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												end_IL_06c9:
												break;
											}
											continue;
											end_IL_06dc:
											break;
										}
										continue;
										end_IL_06e6:
										break;
									}
									continue;
									end_IL_06f1:
									break;
								}
								continue;
								end_IL_0706:
								break;
							}
							continue;
							end_IL_0716:
							break;
						}
						continue;
						end_IL_0726:
						break;
					}
					continue;
					end_IL_0736:
					break;
				}
				continue;
				end_IL_0746:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 65;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PopulateObjectMembersRunClassConstructor.getIsThreadPoolThreadsetExternalProcessMgmt);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d4:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02b4:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02a4:
																					if (8 <= b)
																					{
																						num = 157;
																						while (true)
																						{
																							if (num != 157)
																							{
																								if (num != 1138)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 5:
																									goto IL_02a4;
																								case 68:
																									goto IL_02b4;
																								case 17:
																									goto IL_02c4;
																								case 97:
																									goto IL_02d4;
																								case 12:
																									goto end_IL_02d4;
																								case 90:
																								case 98:
																									goto end_IL_02e4;
																								case 62:
																									goto IL_02ff;
																								case 46:
																									goto IL_030a;
																								case 60:
																									goto IL_0317;
																								case 20:
																								case 81:
																									goto IL_0325;
																								case 94:
																									goto IL_0335;
																								case 34:
																								case 93:
																									goto IL_0343;
																								case 99:
																									goto IL_0356;
																								case 38:
																								case 115:
																									goto IL_0366;
																								case 39:
																									goto IL_0384;
																								case 103:
																									goto IL_0392;
																								case 117:
																									goto IL_03a5;
																								case 18:
																								case 43:
																									goto IL_03b3;
																								case 51:
																								case 118:
																									goto IL_03c6;
																								case 37:
																									goto IL_03ef;
																								case 119:
																									goto IL_0402;
																								case 109:
																								case 112:
																									goto IL_040d;
																								case 7:
																									goto IL_0418;
																								case 63:
																								case 79:
																									goto IL_0436;
																								case 67:
																									goto IL_0476;
																								case 56:
																								case 122:
																									goto IL_048f;
																								case 47:
																									goto IL_04a8;
																								case 130:
																									goto IL_04bb;
																								case 4:
																								case 23:
																									goto IL_04c9;
																								case 131:
																									goto IL_04dc;
																								case 69:
																								case 116:
																									goto IL_04f3;
																								case 16:
																									goto IL_0525;
																								case 137:
																									goto IL_053e;
																								case 91:
																									goto IL_054c;
																								case 140:
																									goto IL_055f;
																								case 75:
																									goto IL_0577;
																								case 85:
																									goto IL_0585;
																								case 142:
																									goto IL_0598;
																								case 146:
																									goto IL_05ab;
																								case 30:
																								case 149:
																									goto IL_05be;
																								case 8:
																									goto IL_05fd;
																								case 113:
																									goto IL_0610;
																								case 105:
																									goto IL_0628;
																								case 86:
																									goto IL_0636;
																								case 0:
																									goto IL_0644;
																								case 11:
																									goto IL_0652;
																								case 2:
																								case 15:
																									goto IL_065d;
																								case 124:
																									goto IL_066b;
																								case 42:
																									goto IL_068e;
																								case 104:
																									goto IL_0698;
																								case 143:
																									goto IL_06a6;
																								case 19:
																									goto IL_06b9;
																								case 45:
																									goto IL_06c7;
																								case 52:
																								case 74:
																									goto IL_06e3;
																								case 83:
																									goto IL_06f1;
																								case 10:
																								case 96:
																									goto IL_070a;
																								case 123:
																									goto IL_074e;
																								case 22:
																									goto IL_0762;
																								case 3:
																								case 145:
																									goto IL_0775;
																								case 27:
																									goto IL_07b5;
																								case 135:
																									goto IL_07c9;
																								case 148:
																									goto IL_07dc;
																								case 13:
																								case 21:
																									goto IL_07e7;
																								case 108:
																									goto IL_07f5;
																								case 111:
																									goto IL_0808;
																								case 14:
																								case 29:
																									goto IL_0816;
																								case 102:
																									goto IL_0824;
																								case 26:
																								case 95:
																									goto IL_0832;
																								case 139:
																									goto IL_0894;
																								case 41:
																								case 127:
																									goto IL_08a4;
																								case 1:
																								case 6:
																								case 9:
																								case 24:
																								case 31:
																								case 35:
																								case 36:
																								case 40:
																								case 44:
																								case 48:
																								case 49:
																								case 55:
																								case 57:
																								case 59:
																								case 66:
																								case 76:
																								case 77:
																								case 80:
																								case 82:
																								case 84:
																								case 89:
																								case 114:
																								case 120:
																								case 121:
																								case 125:
																								case 128:
																								case 133:
																								case 138:
																								case 147:
																								case 150:
																									goto end_IL_0291;
																								case 28:
																								case 32:
																								case 50:
																								case 54:
																								case 58:
																								case 61:
																								case 70:
																								case 72:
																								case 73:
																								case 78:
																								case 92:
																								case 100:
																								case 106:
																								case 129:
																								case 134:
																								case 136:
																								case 141:
																								case 144:
																									goto end_IL_02f4;
																								case 101:
																									goto end_IL_08d0;
																								case 132:
																									goto end_IL_08e3;
																								case 53:
																									goto end_IL_08ed;
																								case 126:
																									goto end_IL_08f8;
																								case 88:
																								case 107:
																									goto end_IL_0908;
																								case 87:
																									goto end_IL_0918;
																								case 25:
																								case 71:
																									goto end_IL_0928;
																								case 64:
																									goto end_IL_0938;
																								case 65:
																									goto end_IL_0948;
																								case 33:
																								case 110:
																									goto IL_0963;
																								}
																								continue;
																							}
																							goto IL_0610;
																							IL_0610:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02f4;
																							continue;
																							end_IL_0291:
																							break;
																						}
																						break;
																					}
																					goto IL_02ff;
																					IL_0577:
																					num5++;
																					goto IL_0585;
																					IL_0585:
																					ptr2 += 8;
																					goto end_IL_02f4;
																					IL_02ff:
																					if (4 >= b)
																					{
																						goto IL_030a;
																					}
																					goto IL_0317;
																					IL_030a:
																					if (4 > b)
																					{
																						goto IL_0335;
																					}
																					goto IL_0366;
																					IL_0335:
																					if (2 < b)
																					{
																						goto IL_0343;
																					}
																					goto IL_0402;
																					IL_0343:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_04dc;
																					IL_04dc:
																					if (3 > b)
																					{
																						break;
																					}
																					num = 69;
																					goto IL_04f3;
																					IL_05be:
																					((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05fd;
																					IL_04f3:
																					array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					num = 16;
																					goto IL_0525;
																					IL_0525:
																					array[num5 - 1] = 5;
																					goto end_IL_02f4;
																					IL_0402:
																					if (2 > b)
																					{
																						goto IL_040d;
																					}
																					goto IL_0436;
																					IL_040d:
																					if (1 < b)
																					{
																						num = 6;
																						break;
																					}
																					goto IL_0418;
																					IL_0418:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_048f;
																					IL_048f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04a8;
																					IL_04a8:
																					array[num5] = 0;
																					goto IL_053e;
																					IL_053e:
																					num5++;
																					goto IL_054c;
																					IL_054c:
																					ptr2 += 8;
																					goto end_IL_02f4;
																					IL_05fd:
																					num5 -= 3;
																					goto end_IL_02f4;
																					IL_0436:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0476;
																					IL_0476:
																					array[num5 - 2] = 0;
																					goto IL_0598;
																					IL_0598:
																					num5--;
																					goto end_IL_02f4;
																					IL_0366:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_0384;
																					IL_0384:
																					ptr2 += 8;
																					goto IL_0392;
																					IL_0392:
																					num5--;
																					goto end_IL_02f4;
																					IL_0317:
																					if (6 < b)
																					{
																						goto IL_0325;
																					}
																					goto IL_03a5;
																					IL_0325:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0356;
																					IL_0356:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03c6;
																					IL_03c6:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03ef;
																					IL_03ef:
																					ptr2 += 8;
																					goto IL_05ab;
																					IL_05ab:
																					num5--;
																					goto end_IL_02f4;
																					IL_03a5:
																					if (6 > b)
																					{
																						goto IL_03b3;
																					}
																					goto IL_05be;
																					IL_03b3:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_04bb;
																					IL_04bb:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_04c9;
																					IL_04c9:
																					array[num5] = 5;
																					goto IL_055f;
																					IL_055f:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0577;
																				}
																				break;
																			}
																			goto IL_0628;
																			IL_0832:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0894;
																			IL_0628:
																			if (12 >= b)
																			{
																				goto IL_0636;
																			}
																			goto IL_07dc;
																			IL_0636:
																			if (12 > b)
																			{
																				goto IL_0644;
																			}
																			goto IL_0775;
																			IL_0644:
																			if (10 >= b)
																			{
																				goto IL_0652;
																			}
																			num = 74;
																			goto IL_06e3;
																			IL_0652:
																			if (10 <= b)
																			{
																				goto IL_065d;
																			}
																			goto IL_06b9;
																			IL_065d:
																			array[num5] = 0;
																			goto IL_066b;
																			IL_066b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_068e;
																			IL_068e:
																			array2[num5] = null;
																			goto IL_0698;
																			IL_0698:
																			num5++;
																			goto IL_06a6;
																			IL_06a6:
																			ptr2 += 8;
																			goto end_IL_02f4;
																			IL_06b9:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06c7;
																			IL_06c7:
																			if (9 <= b)
																			{
																				goto end_IL_02f4;
																			}
																			break;
																			IL_0894:
																			num5 -= 2;
																			goto end_IL_02f4;
																			IL_06e3:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_06f1;
																			IL_06f1:
																			if (11 > b)
																			{
																				num = 49;
																				break;
																			}
																			goto IL_070a;
																			IL_08a4:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02f4;
																			IL_070a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_074e;
																			IL_074e:
																			array[num5 - 2] = 0;
																			goto IL_0762;
																			IL_0762:
																			num5--;
																			goto end_IL_02f4;
																			IL_0775:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07b5;
																			IL_07b5:
																			array[num5 - 2] = 0;
																			goto IL_07c9;
																			IL_07c9:
																			num5--;
																			goto end_IL_02f4;
																			IL_07dc:
																			if (14 < b)
																			{
																				goto IL_07e7;
																			}
																			goto IL_0808;
																			IL_07e7:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_07f5;
																			IL_07f5:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_0808:
																			if (14 > b)
																			{
																				goto IL_0816;
																			}
																			goto IL_08a4;
																			IL_0816:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0824;
																			IL_0824:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0832;
																		}
																		break;
																		IL_02c4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f4;
																continue;
																end_IL_02d4:
																break;
															}
															continue;
															end_IL_02e4:
															break;
														}
														continue;
														end_IL_02f4:
														break;
													}
													continue;
												}
												goto IL_0963;
												IL_0963:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d0:
												break;
											}
											continue;
											end_IL_08e3:
											break;
										}
										continue;
										end_IL_08ed:
										break;
									}
									continue;
									end_IL_08f8:
									break;
								}
								continue;
								end_IL_0908:
								break;
							}
							continue;
							end_IL_0918:
							break;
						}
						continue;
						end_IL_0928:
						break;
					}
					continue;
					end_IL_0938:
					break;
				}
				continue;
				end_IL_0948:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllowExponentDeleteLocalDataStore.CommonAceContinuationTask);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 50;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02c4:
														byte b = *ptr2;
														while (true)
														{
															IL_02b4:
															ptr2++;
															while (true)
															{
																IL_02a4:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0287:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0277:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0267:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0257:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_0205:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01e6:
																													array[num5 - 2] = 0;
																													num = 113;
																													while (true)
																													{
																														if (num != 113)
																														{
																															if (num != 1094)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 94:
																																goto IL_01e6;
																															case 10:
																															case 46:
																																goto IL_0205;
																															case 19:
																																goto IL_0247;
																															case 38:
																																goto IL_0257;
																															case 36:
																																goto IL_0267;
																															case 35:
																															case 104:
																																goto IL_0277;
																															case 9:
																																goto IL_0287;
																															case 13:
																																goto IL_0294;
																															case 37:
																																goto IL_02a4;
																															case 55:
																																goto IL_02b4;
																															case 3:
																															case 103:
																																goto IL_02c4;
																															case 63:
																																goto IL_02cf;
																															case 2:
																															case 26:
																																goto IL_02dd;
																															case 6:
																																goto IL_02e8;
																															case 29:
																															case 48:
																																goto IL_02f6;
																															case 16:
																															case 62:
																																goto IL_0324;
																															case 25:
																															case 45:
																																goto IL_032f;
																															case 18:
																																goto IL_0342;
																															case 68:
																																goto IL_0352;
																															case 24:
																																goto IL_0360;
																															case 66:
																															case 70:
																																goto IL_036e;
																															case 65:
																															case 77:
																																goto IL_038a;
																															case 53:
																															case 79:
																																goto IL_03a2;
																															case 85:
																																goto IL_03b0;
																															case 28:
																																goto IL_03d3;
																															case 44:
																																goto IL_03dd;
																															case 32:
																																goto IL_03eb;
																															case 73:
																															case 87:
																																goto IL_03fe;
																															case 92:
																																goto IL_040e;
																															case 90:
																															case 97:
																																goto IL_0421;
																															case 59:
																																goto IL_042f;
																															case 8:
																															case 91:
																																goto IL_043d;
																															case 20:
																																goto IL_0456;
																															case 82:
																																goto IL_0464;
																															case 81:
																																goto IL_0472;
																															case 100:
																																goto IL_0485;
																															case 101:
																																goto IL_0498;
																															case 69:
																																goto IL_04a6;
																															case 5:
																															case 78:
																																goto IL_04d5;
																															case 52:
																																goto IL_04e3;
																															case 4:
																															case 12:
																																goto IL_04f1;
																															case 43:
																																goto IL_0514;
																															case 17:
																																goto IL_0522;
																															case 64:
																																goto IL_0530;
																															case 71:
																															case 86:
																																goto IL_054c;
																															case 51:
																																goto IL_05ae;
																															case 15:
																															case 22:
																															case 34:
																															case 41:
																															case 42:
																															case 47:
																															case 54:
																															case 56:
																															case 57:
																															case 58:
																															case 67:
																															case 72:
																															case 74:
																															case 75:
																															case 76:
																															case 84:
																															case 88:
																															case 93:
																															case 106:
																																goto end_IL_0247;
																															case 0:
																															case 11:
																															case 14:
																															case 27:
																															case 30:
																															case 31:
																															case 33:
																															case 40:
																															case 49:
																															case 50:
																															case 61:
																															case 80:
																															case 102:
																																goto end_IL_01d3;
																															case 83:
																																goto end_IL_05d1;
																															case 99:
																																goto end_IL_05e4;
																															case 39:
																																goto end_IL_05f7;
																															case 7:
																																goto end_IL_0602;
																															case 60:
																															case 98:
																																goto end_IL_0617;
																															case 89:
																																goto end_IL_0627;
																															case 21:
																															case 105:
																																goto end_IL_0637;
																															case 95:
																																goto end_IL_0647;
																															case 96:
																																goto end_IL_0657;
																															case 1:
																															case 23:
																																goto IL_0672;
																															}
																															continue;
																														}
																														num5--;
																														break;
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_02a4;
																											continue;
																											end_IL_0247:
																											break;
																											IL_0247:;
																										}
																										break;
																									}
																									num = 5;
																									goto IL_04d5;
																									IL_0522:
																									num5++;
																									goto IL_0530;
																									IL_0530:
																									ptr2 += 8;
																									goto end_IL_02a4;
																									IL_04d5:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_04e3;
																									IL_04e3:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_04f1;
																									IL_04f1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0514;
																									IL_0514:
																									array[num5] = 0;
																									goto IL_0522;
																								}
																								break;
																							}
																							num = 86;
																							goto IL_054c;
																							IL_054c:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05ae;
																							IL_05ae:
																							num5 -= 2;
																							goto end_IL_02a4;
																						}
																						break;
																					}
																					goto IL_0352;
																					IL_0485:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_0352:
																					if (9 >= b)
																					{
																						goto IL_0360;
																					}
																					goto IL_03fe;
																					IL_0360:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_036e;
																					IL_036e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a4;
																					IL_03fe:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0485;
																				}
																				break;
																			}
																			goto IL_02cf;
																			IL_03eb:
																			ptr2 += 8;
																			goto end_IL_02a4;
																			IL_02cf:
																			if (5 > b)
																			{
																				goto IL_02dd;
																			}
																			goto IL_03a2;
																			IL_02dd:
																			if (2 >= b)
																			{
																				goto IL_02e8;
																			}
																			goto IL_0324;
																			IL_02e8:
																			if (2 <= b)
																			{
																				goto IL_02f6;
																			}
																			goto IL_0421;
																			IL_02f6:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0498;
																			IL_0498:
																			ptr2 += 8;
																			goto IL_04a6;
																			IL_04a6:
																			num5--;
																			goto end_IL_02a4;
																			IL_0421:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_042f;
																			IL_042f:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_043d;
																			IL_043d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0456;
																			IL_0456:
																			array[num5] = 0;
																			goto IL_0464;
																			IL_0464:
																			num5++;
																			goto IL_0472;
																			IL_0472:
																			ptr2 += 8;
																			goto end_IL_02a4;
																			IL_0324:
																			if (3 < b)
																			{
																				goto IL_032f;
																			}
																			goto IL_0342;
																			IL_032f:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_040e;
																			IL_040e:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a4;
																			IL_0342:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_038a;
																			IL_038a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02a4;
																			IL_03a2:
																			array[num5] = 0;
																			goto IL_03b0;
																			IL_03b0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03d3;
																			IL_03d3:
																			array2[num5] = null;
																			goto IL_03dd;
																			IL_03dd:
																			num5++;
																			goto IL_03eb;
																		}
																		break;
																		IL_0294:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02a4:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0672;
												IL_0672:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d1:
												break;
											}
											continue;
											end_IL_05e4:
											break;
										}
										continue;
										end_IL_05f7:
										break;
									}
									continue;
									end_IL_0602:
									break;
								}
								continue;
								end_IL_0617:
								break;
							}
							continue;
							end_IL_0627:
							break;
						}
						continue;
						end_IL_0637:
						break;
					}
					continue;
					end_IL_0647:
					break;
				}
				continue;
				end_IL_0657:
				break;
			}
		}
	}

	private static int smethod_6(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		num += num2;
		int num3 = num;
		num = int_3;
		num2 = int_4;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 330;
		num2 = 30;
		return num + 30;
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									num = 102;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BindableIterableToEnumerableAdapterSYSMAC.getIsNetFxLegacySecurityPolicygetSHA);
										num = 43;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0242:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 < b)
																			{
																				num = 100;
																				while (true)
																				{
																					if (8 >= b)
																					{
																						while (true)
																						{
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_01f2:
																									if (6 >= b)
																									{
																										num = 109;
																										while (true)
																										{
																											if (num != 109)
																											{
																												if (num != 1090)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 1:
																												case 31:
																													goto IL_01f2;
																												case 67:
																													goto end_IL_01f2;
																												case 55:
																												case 100:
																													goto end_IL_0202;
																												case 70:
																													goto end_IL_0212;
																												case 6:
																													goto end_IL_0222;
																												case 42:
																													goto IL_0242;
																												case 87:
																													goto end_IL_0242;
																												case 47:
																												case 81:
																													goto end_IL_0252;
																												case 38:
																													goto IL_026d;
																												case 14:
																													goto IL_027b;
																												case 62:
																													goto IL_028e;
																												case 5:
																												case 25:
																													goto IL_0299;
																												case 9:
																												case 17:
																													goto IL_02a9;
																												case 40:
																													goto IL_02b7;
																												case 27:
																													goto IL_02da;
																												case 77:
																													goto IL_02e9;
																												case 2:
																												case 52:
																													goto IL_02f4;
																												case 45:
																													goto IL_0302;
																												case 11:
																													goto IL_0315;
																												case 36:
																												case 63:
																													goto IL_0323;
																												case 78:
																													goto IL_033b;
																												case 4:
																												case 22:
																													goto IL_0346;
																												case 21:
																													goto IL_0371;
																												case 80:
																													goto IL_0384;
																												case 20:
																													goto IL_0392;
																												case 83:
																													goto IL_03a5;
																												case 23:
																													goto IL_03b3;
																												case 26:
																												case 84:
																													goto IL_03c6;
																												case 0:
																													goto IL_03d1;
																												case 37:
																												case 76:
																													goto IL_03df;
																												case 51:
																													goto IL_03fb;
																												case 3:
																													goto IL_0409;
																												case 71:
																												case 88:
																													goto end_IL_01df;
																												case 49:
																													goto IL_0451;
																												case 94:
																													goto IL_045f;
																												case 79:
																													goto IL_046d;
																												case 95:
																													goto IL_0480;
																												case 66:
																												case 72:
																													goto IL_048e;
																												case 89:
																													goto IL_04a7;
																												case 75:
																													goto IL_04b5;
																												case 44:
																													goto IL_04c3;
																												case 32:
																												case 96:
																													goto IL_04e4;
																												case 41:
																													goto IL_0524;
																												case 92:
																													goto IL_0538;
																												case 29:
																												case 69:
																													goto IL_054b;
																												case 7:
																													goto IL_05ad;
																												case 10:
																												case 15:
																												case 18:
																												case 19:
																												case 24:
																												case 28:
																												case 30:
																												case 35:
																												case 53:
																												case 57:
																												case 64:
																												case 65:
																												case 73:
																												case 86:
																												case 90:
																												case 97:
																												case 101:
																													goto end_IL_0232;
																												case 12:
																												case 13:
																												case 39:
																												case 46:
																												case 50:
																												case 54:
																												case 58:
																												case 74:
																												case 82:
																												case 85:
																												case 91:
																												case 98:
																												case 99:
																													goto end_IL_0262;
																												case 43:
																													goto end_IL_05d9;
																												case 102:
																													goto end_IL_05ec;
																												case 8:
																													goto end_IL_05f6;
																												case 93:
																													goto end_IL_060a;
																												case 16:
																												case 61:
																													goto end_IL_0628;
																												case 68:
																													goto end_IL_0638;
																												case 48:
																												case 56:
																													goto end_IL_0648;
																												case 33:
																													goto end_IL_0658;
																												case 34:
																													goto end_IL_0668;
																												case 59:
																												case 60:
																													goto IL_0683;
																												}
																												continue;
																											}
																											if (6 > b)
																											{
																												goto end_IL_0232;
																											}
																											goto IL_04e4;
																											IL_04e4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0524;
																											IL_0538:
																											num5--;
																											goto end_IL_0262;
																											IL_0524:
																											array[num5 - 2] = 0;
																											goto IL_0538;
																											continue;
																											end_IL_01df:
																											break;
																										}
																										goto IL_0425;
																									}
																									goto IL_026d;
																									IL_045f:
																									num5++;
																									goto IL_046d;
																									IL_046d:
																									ptr2 += 8;
																									goto end_IL_0262;
																									IL_026d:
																									if (7 < b)
																									{
																										goto end_IL_0232;
																									}
																									goto IL_027b;
																									IL_027b:
																									if (7 > b)
																									{
																										goto end_IL_0232;
																									}
																									goto IL_0425;
																									IL_0425:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									num = 49;
																									goto IL_0451;
																									IL_0451:
																									array[num5] = 0;
																									goto IL_045f;
																									continue;
																									end_IL_01f2:
																									break;
																								}
																								continue;
																							}
																							goto IL_054b;
																							IL_05ad:
																							num5 -= 2;
																							num = 99;
																							goto end_IL_0262;
																							IL_054b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05ad;
																							continue;
																							end_IL_0202:
																							break;
																						}
																						continue;
																					}
																					goto IL_03c6;
																					IL_0409:
																					if (10 <= b)
																					{
																						num = 64;
																					}
																					goto end_IL_0232;
																					IL_03c6:
																					if (9 >= b)
																					{
																						goto IL_03d1;
																					}
																					goto IL_03fb;
																					IL_03d1:
																					if (9 > b)
																					{
																						goto end_IL_0232;
																					}
																					goto IL_03df;
																					IL_03df:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0262;
																					IL_03fb:
																					if (10 < b)
																					{
																						goto end_IL_0232;
																					}
																					goto IL_0409;
																					continue;
																					end_IL_0212:
																					break;
																				}
																				continue;
																			}
																			goto IL_028e;
																			IL_03a5:
																			num5++;
																			goto IL_03b3;
																			IL_03b3:
																			ptr2 += 8;
																			goto end_IL_0262;
																			IL_028e:
																			if (5 > b)
																			{
																				goto IL_0299;
																			}
																			goto IL_02a9;
																			IL_0299:
																			if (2 < b)
																			{
																				goto IL_02e9;
																			}
																			goto IL_033b;
																			IL_033b:
																			if (2 <= b)
																			{
																				goto IL_0346;
																			}
																			goto IL_0371;
																			IL_0346:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0384;
																			IL_0384:
																			ptr2 += 8;
																			goto IL_0392;
																			IL_0392:
																			num5--;
																			goto end_IL_0262;
																			IL_0371:
																			if (1 < b)
																			{
																				goto end_IL_0232;
																			}
																			goto IL_0480;
																			IL_0480:
																			if (1 > b)
																			{
																				goto end_IL_0232;
																			}
																			goto IL_048e;
																			IL_048e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04a7;
																			IL_04a7:
																			array[num5] = 0;
																			goto IL_04b5;
																			IL_04b5:
																			num5++;
																			goto IL_04c3;
																			IL_04c3:
																			ptr2 += 8;
																			goto end_IL_0262;
																			IL_02e9:
																			if (3 < b)
																			{
																				goto IL_02f4;
																			}
																			goto IL_0315;
																			IL_02f4:
																			if (4 < b)
																			{
																				goto end_IL_0232;
																			}
																			goto IL_0302;
																			IL_0302:
																			if (4 > b)
																			{
																				goto end_IL_0232;
																			}
																			goto end_IL_0262;
																			IL_0315:
																			if (3 > b)
																			{
																				goto end_IL_0232;
																			}
																			goto IL_0323;
																			IL_0323:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0262;
																			IL_02a9:
																			array[num5] = 0;
																			goto IL_02b7;
																			IL_02b7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_02da;
																			IL_02da:
																			array2[num5] = null;
																			goto IL_03a5;
																			continue;
																			end_IL_0222:
																			break;
																		}
																		continue;
																		end_IL_0232:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0262;
																continue;
																end_IL_0242:
																break;
															}
															continue;
															end_IL_0252:
															break;
														}
														continue;
														end_IL_0262:
														break;
													}
													continue;
												}
												goto IL_0683;
												IL_0683:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d9:
												break;
											}
											continue;
											end_IL_05ec:
											break;
										}
										continue;
										end_IL_05f6:
										break;
									}
									continue;
									end_IL_060a:
									break;
								}
								continue;
								end_IL_0628:
								break;
							}
							continue;
							end_IL_0638:
							break;
						}
						continue;
						end_IL_0648:
						break;
					}
					continue;
					end_IL_0658:
					break;
				}
				continue;
				end_IL_0668:
				break;
			}
		}
	}

	static Class146()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 13;
			while (true)
			{
				if (num != 13)
				{
					if (num == 994)
					{
						switch (num)
						{
						default:
							continue;
						case 6:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
