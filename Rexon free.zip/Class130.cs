using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;

[Mod("Gun Sound: Off", "Settings", "Toggle gun sound", false, 5, ModType.const_1, false)]
internal class Class130 : MonoBehaviour
{
	private static bool bool_0;

	private static int int_0;

	private static float float_0;

	private static float float_1;

	private static int int_1;

	private static bool bool_1;

	private static double double_0;

	private static IntPtr[] STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated;

	private static IntPtr[] KoreanLunisolarCalendarSizeof;

	private static IntPtr[] getSignatureCreateDefaultTypeInfo;

	public static bool SoundEnabled
	{
		get
		{
			int num = 245;
			num = 49;
			num = 196;
			num = 28;
			num = 49;
			num = 45;
			num = 61;
			num = 61;
			num = 78;
			num = 26;
			num = 897;
			num = 69;
			num = 26;
			num = 95;
			num = 1885;
			num = 1885;
			num = 1946;
			num = 2405;
			num = 185;
			return bool_0;
		}
		set
		{
			int num = 140;
			num = 35;
			num = 473;
			num = 43;
			num = 35;
			num = 8;
			num = 43;
			num = 43;
			num = 140;
			num = 28;
			num = 122;
			num = 61;
			num = 28;
			num = 89;
			num = 1781;
			num = 1781;
			num = 1824;
			num = 1638;
			num = 126;
			num = (value ? 1 : 0);
			bool_0 = (byte)num != 0;
		}
	}

	private void OnEnable()
	{
		int num = 225;
		int num2 = 5;
		num = 45;
		num = 195;
		num2 = 5;
		num = 39;
		num = 45;
		num2 = 39;
		num = 10;
		num2 = 45;
		num2 = 37;
		num = 47;
		num = 47;
		num = 420;
		num2 = 7;
		num = 60;
		num = 69;
		num2 = 3;
		num = 23;
		num = 60;
		num2 = 23;
		num = 83;
		num2 = 60;
		num2 = 1380;
		num = 1335;
		num = 1335;
		num2 = 47;
		num = 1382;
		num = 835;
		num2 = 5;
		num = 167;
		num2 = 3445;
		num2 = 265;
		object obj = "o";
		object obj2 = obj;
		obj = "u";
		object obj3 = obj;
		obj = "f";
		object obj4 = obj;
		obj = " ";
		object obj5 = obj;
		obj = "O";
		object obj6 = obj;
		obj = "G";
		object obj7 = obj;
		obj = "d";
		object obj8 = obj;
		obj = ":";
		object obj9 = obj;
		obj = "n";
		object obj10 = obj;
		obj = "S";
		object obj11 = obj;
		num = 21;
		num2 = 7;
		num = 3;
		obj = new string[3];
		object obj12 = obj;
		object obj13 = obj6;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj4;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj4;
		((string[])obj12)[2] = (string)obj13;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj14 = obj;
		num = 33;
		num2 = 3;
		num = 11;
		obj = new string[11];
		obj12 = obj;
		obj13 = obj7;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj3;
		((string[])obj12)[1] = (string)obj13;
		obj12 = obj;
		obj13 = obj10;
		((string[])obj12)[2] = (string)obj13;
		obj12 = obj;
		obj13 = obj5;
		((string[])obj12)[3] = (string)obj13;
		obj12 = obj;
		obj13 = obj11;
		((string[])obj12)[4] = (string)obj13;
		obj12 = obj;
		obj13 = obj2;
		((string[])obj12)[5] = (string)obj13;
		obj12 = obj;
		obj13 = obj3;
		((string[])obj12)[6] = (string)obj13;
		obj12 = obj;
		obj13 = obj10;
		((string[])obj12)[7] = (string)obj13;
		obj12 = obj;
		obj13 = obj8;
		((string[])obj12)[8] = (string)obj13;
		obj12 = obj;
		obj13 = obj9;
		((string[])obj12)[9] = (string)obj13;
		obj12 = obj;
		obj13 = obj5;
		((string[])obj12)[10] = (string)obj13;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj15 = obj;
		num = 14;
		num2 = 7;
		num = 2;
		obj = new string[2];
		obj12 = obj;
		obj13 = obj6;
		((string[])obj12)[0] = (string)obj13;
		obj12 = obj;
		obj13 = obj10;
		((string[])obj12)[1] = (string)obj13;
		string text3 = string.Concat((string[])obj);
		obj = text3;
		object obj16 = obj;
		num = (bool_0 ? 1 : 0);
		num2 = 0;
		num = ((num == 0) ? 1 : 0);
		bool_0 = (byte)num != 0;
		num = (bool_0 ? 1 : 0);
		Class8.SoundEnabled = (byte)num != 0;
		obj = obj15;
		string text4 = string.Concat(str1: (string)((!bool_0) ? obj14 : obj16), str0: (string)obj);
		obj = text4;
		BundleManager.smethod_113((string)obj);
	}

	public unsafe static void smethod_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0491, IL_04a4, IL_04b4, IL_04c4, IL_04d4, IL_04e4, IL_04f4, IL_0504, IL_050f, IL_051a, IL_0525, IL_0530, IL_053e, IL_0551, IL_055f, IL_056d, IL_057b, IL_0589, IL_0597, IL_05d8, IL_05ec, IL_0608, IL_061b, IL_0629, IL_0641, IL_064f, IL_065d, IL_06af, IL_06c2, IL_06db, IL_06e9, IL_06f7, IL_070a, IL_0718, IL_0726, IL_073a, IL_0772, IL_0785, IL_0793, IL_07c6, IL_07d4, IL_07e7, IL_080b, IL_0819, IL_0827, IL_083a, IL_0853, IL_0861, IL_086f, IL_088b, IL_0899, IL_08a7, IL_08b5, IL_08c3, IL_08d1, IL_08df, IL_08e8, IL_08fc, IL_093b, IL_094e, IL_0997, IL_09ab, IL_09be, IL_09cc, IL_09da, IL_09ee, IL_0a2d, IL_0a40, IL_0a49, IL_0aa7, IL_0aba, IL_0ac8, IL_0ad3, IL_0afc, IL_0b0a, IL_0b26, IL_0b34, IL_0b42, IL_0b56, IL_0ba2, IL_0bb0, IL_0bc3, IL_0bce, IL_0bdc, IL_0be5, IL_0c01, IL_0c0f, IL_0c22, IL_0c2d, IL_0c6b, IL_0c7e, IL_0c8c, IL_0c97, IL_0caa, IL_0cb8, IL_0cc6, IL_0cd4, IL_0cdf, IL_0d1f, IL_0d33, IL_0d46, IL_0d54, IL_0d62, IL_0d7b, IL_0d89, IL_0d97, IL_0daa, IL_0db8, IL_0dc6, IL_0def, IL_0dfd, IL_0e10, IL_0e1e, IL_0e41, IL_0e4b, IL_0e59, IL_0e6c, IL_0e7a, IL_0e85, IL_0ec5, IL_0ed9, IL_0eec, IL_0efa, IL_0f08, IL_0f48, IL_0f5c, IL_0f6f, IL_0f7d, IL_0f8b, IL_0fcb, IL_0fdf, IL_0ff2, IL_1000, IL_100e, IL_102b, IL_107a, IL_1084, IL_10b1, IL_10c5, IL_10d3, IL_10e6, IL_10f4, IL_10ff, IL_1161, IL_1174, IL_1182, IL_118b, IL_1199, IL_11d9, IL_11ed, IL_1200, IL_120e, IL_1221, IL_122f, IL_123a, IL_1263, IL_127c, IL_128a, IL_1298, IL_12b6, IL_12c4, IL_12d7, IL_12e5, IL_12f3, IL_130b, IL_1329, IL_134d, IL_1365, IL_137e, IL_1389, IL_1394, IL_13a2, IL_13ba, IL_13c8, IL_13d8, IL_13eb, IL_13fe, IL_1411, IL_141c, IL_1435, IL_144e, IL_145e, IL_146e, IL_147e, IL_148e, IL_149e, IL_14ae are reachable both inside and outside the pinned region starting at IL_14c3. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 156;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef43 = default(int);
			ref int reference = ref __rxRef43;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_14ae:
					num2 = 1;
					while (true)
					{
						IL_149e:
						num3 = num2 * 4;
						while (true)
						{
							IL_148e:
							num4 = num2 * 8;
							while (true)
							{
								IL_147e:
								array2 = new byte[4];
								while (true)
								{
									IL_146e:
									array3 = new object[4];
									while (true)
									{
										IL_145e:
										array4 = new int[4];
										while (true)
										{
											IL_144e:
											array5 = new int[7];
											while (true)
											{
												IL_1435:
												array6 = new long[4];
												num = 16;
												while (true)
												{
													IL_141c:
													array7 = new object[13];
													num = 86;
													while (true)
													{
														IL_1411:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackCrawlMarkHandleSoapServices.PermissionSetNameOverlappedData);
														while (true)
														{
															IL_13fe:
															ptr2 = ptr;
															num = 212;
															while (true)
															{
																IL_13eb:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_050f:
																	num = 153;
																	while (true)
																	{
																		IL_0504:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_04f4:
																			ptr2++;
																			while (true)
																			{
																				IL_04e4:
																				if (b >= 1)
																				{
																					while (b <= 33)
																					{
																						while (true)
																						{
																							IL_04c4:
																							if (17 < b)
																							{
																								while (true)
																								{
																									IL_04b4:
																									if (25 >= b)
																									{
																										while (true)
																										{
																											IL_04a4:
																											if (25 <= b)
																											{
																												num = 285;
																												while (true)
																												{
																													if (num != 285)
																													{
																														if (num != 1266)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 156:
																															break;
																														default:
																															continue;
																														case 175:
																															goto IL_04a4;
																														case 87:
																															goto IL_04b4;
																														case 91:
																															goto IL_04c4;
																														case 203:
																															goto IL_04d4;
																														case 3:
																															goto IL_04e4;
																														case 199:
																															goto IL_04f4;
																														case 153:
																															goto IL_0504;
																														case 149:
																															goto IL_050f;
																														case 4:
																															goto IL_051a;
																														case 27:
																															goto IL_0525;
																														case 74:
																															goto IL_0530;
																														case 85:
																															goto IL_053e;
																														case 151:
																															goto IL_0551;
																														case 12:
																															goto IL_055f;
																														case 116:
																															goto IL_056d;
																														case 49:
																															goto IL_057b;
																														case 83:
																														case 190:
																															goto IL_0597;
																														case 181:
																															goto IL_05d8;
																														case 77:
																															goto IL_05ec;
																														case 198:
																															goto IL_0608;
																														case 205:
																															goto IL_061b;
																														case 62:
																														case 131:
																															goto IL_0629;
																														case 229:
																															goto IL_0641;
																														case 98:
																														case 235:
																															goto IL_065d;
																														case 162:
																															goto IL_06af;
																														case 136:
																														case 242:
																															goto IL_06c2;
																														case 9:
																															goto IL_06db;
																														case 177:
																															goto IL_06e9;
																														case 219:
																															goto IL_06f7;
																														case 260:
																															goto IL_070a;
																														case 43:
																															goto IL_0718;
																														case 59:
																														case 220:
																															goto IL_0726;
																														case 95:
																															goto IL_073a;
																														case 106:
																															goto IL_0772;
																														case 276:
																															goto IL_0785;
																														case 160:
																														case 268:
																															goto IL_0793;
																														case 97:
																															goto IL_07c6;
																														case 26:
																															goto IL_07d4;
																														case 121:
																														case 278:
																															goto IL_07e7;
																														case 128:
																															goto IL_080b;
																														case 252:
																															goto IL_0819;
																														case 124:
																															goto IL_0827;
																														case 187:
																															goto IL_083a;
																														case 75:
																															goto IL_0853;
																														case 44:
																															goto IL_0861;
																														case 275:
																															goto IL_086f;
																														case 255:
																															goto IL_088b;
																														case 73:
																															goto IL_0899;
																														case 42:
																															goto IL_08a7;
																														case 197:
																															goto IL_08b5;
																														case 148:
																															goto IL_08c3;
																														case 129:
																															goto IL_08d1;
																														case 65:
																														case 117:
																															goto IL_08e8;
																														case 238:
																															goto IL_08fc;
																														case 246:
																															goto IL_093b;
																														case 24:
																														case 79:
																															goto IL_094e;
																														case 200:
																															goto IL_0997;
																														case 32:
																															goto IL_09ab;
																														case 125:
																															goto IL_09be;
																														case 226:
																															goto IL_09cc;
																														case 161:
																														case 224:
																															goto IL_09da;
																														case 176:
																															goto IL_09ee;
																														case 261:
																															goto IL_0a2d;
																														case 45:
																														case 88:
																															goto IL_0a49;
																														case 142:
																															goto IL_0aa7;
																														case 130:
																															goto IL_0aba;
																														case 29:
																															goto IL_0ac8;
																														case 102:
																														case 239:
																															goto IL_0ad3;
																														case 76:
																															goto IL_0afc;
																														case 144:
																															goto IL_0b0a;
																														case 64:
																															goto IL_0b26;
																														case 171:
																															goto IL_0b34;
																														case 63:
																														case 204:
																															goto IL_0b42;
																														case 90:
																															goto IL_0b56;
																														case 267:
																															goto IL_0ba2;
																														case 72:
																															goto IL_0bb0;
																														case 14:
																															goto IL_0bc3;
																														case 241:
																															goto IL_0bce;
																														case 80:
																														case 104:
																															goto IL_0be5;
																														case 58:
																															goto IL_0c01;
																														case 266:
																															goto IL_0c0f;
																														case 20:
																															goto IL_0c22;
																														case 67:
																														case 245:
																															goto IL_0c2d;
																														case 233:
																															goto IL_0c6b;
																														case 50:
																															goto IL_0c7e;
																														case 132:
																															goto IL_0c8c;
																														case 6:
																														case 209:
																															goto IL_0c97;
																														case 214:
																															goto IL_0caa;
																														case 227:
																															goto IL_0cb8;
																														case 28:
																															goto IL_0cc6;
																														case 140:
																															goto IL_0cd4;
																														case 54:
																														case 115:
																															goto IL_0cdf;
																														case 69:
																															goto IL_0d1f;
																														case 146:
																															goto IL_0d33;
																														case 201:
																															goto IL_0d46;
																														case 165:
																															goto IL_0d54;
																														case 145:
																														case 244:
																															goto IL_0d62;
																														case 210:
																															goto IL_0d7b;
																														case 221:
																															goto IL_0d89;
																														case 178:
																															goto IL_0d97;
																														case 228:
																															goto IL_0daa;
																														case 82:
																															goto IL_0db8;
																														case 46:
																														case 96:
																															goto IL_0dc6;
																														case 274:
																															goto IL_0def;
																														case 218:
																															goto IL_0dfd;
																														case 168:
																														case 202:
																															goto IL_0e10;
																														case 99:
																															goto IL_0e1e;
																														case 17:
																															goto IL_0e41;
																														case 101:
																															goto IL_0e4b;
																														case 222:
																															goto IL_0e59;
																														case 206:
																															goto IL_0e6c;
																														case 143:
																															goto IL_0e7a;
																														case 37:
																														case 51:
																															goto IL_0e85;
																														case 8:
																															goto IL_0ec5;
																														case 193:
																															goto IL_0ed9;
																														case 185:
																															goto IL_0eec;
																														case 11:
																															goto IL_0efa;
																														case 92:
																														case 232:
																															goto IL_0f08;
																														case 5:
																															goto IL_0f48;
																														case 147:
																															goto IL_0f5c;
																														case 25:
																															goto IL_0f6f;
																														case 179:
																															goto IL_0f7d;
																														case 223:
																														case 247:
																															goto IL_0f8b;
																														case 123:
																															goto IL_0fcb;
																														case 13:
																															goto IL_0fdf;
																														case 174:
																															goto IL_0ff2;
																														case 141:
																															goto IL_1000;
																														case 18:
																														case 225:
																															goto IL_100e;
																														case 7:
																															goto IL_10c5;
																														case 194:
																															goto IL_10d3;
																														case 111:
																															goto IL_10e6;
																														case 35:
																															goto IL_10f4;
																														case 169:
																														case 254:
																															goto IL_10ff;
																														case 180:
																															goto IL_1161;
																														case 154:
																															goto IL_1174;
																														case 211:
																															goto IL_118b;
																														case 70:
																														case 256:
																															goto IL_1199;
																														case 208:
																															goto IL_11d9;
																														case 263:
																															goto IL_11ed;
																														case 40:
																															goto IL_1200;
																														case 250:
																															goto IL_120e;
																														case 253:
																															goto IL_1221;
																														case 31:
																															goto IL_122f;
																														case 237:
																														case 251:
																															goto IL_123a;
																														case 78:
																															goto IL_1263;
																														case 192:
																															goto IL_127c;
																														case 118:
																															goto IL_128a;
																														case 172:
																														case 248:
																															goto IL_1298;
																														case 138:
																															goto IL_12b6;
																														case 216:
																															goto IL_12c4;
																														case 36:
																															goto IL_12d7;
																														case 120:
																															goto IL_12e5;
																														case 57:
																														case 127:
																															goto IL_12f3;
																														case 34:
																															goto IL_130b;
																														case 113:
																															goto IL_1329;
																														case 15:
																															goto IL_134d;
																														case 157:
																															goto IL_1365;
																														case 112:
																															goto IL_137e;
																														case 122:
																															goto IL_1389;
																														case 207:
																														case 215:
																															goto IL_1394;
																														case 150:
																															goto IL_13a2;
																														case 94:
																															goto IL_13ba;
																														case 10:
																															goto IL_13c8;
																														case 0:
																														case 19:
																														case 22:
																														case 23:
																														case 30:
																														case 60:
																														case 66:
																														case 68:
																														case 84:
																														case 89:
																														case 100:
																														case 105:
																														case 109:
																														case 110:
																														case 119:
																														case 126:
																														case 135:
																														case 139:
																														case 152:
																														case 159:
																														case 163:
																														case 170:
																														case 173:
																														case 183:
																														case 188:
																														case 189:
																														case 191:
																														case 217:
																														case 234:
																														case 236:
																														case 243:
																														case 257:
																														case 262:
																														case 264:
																														case 265:
																														case 270:
																															goto end_IL_0491;
																														case 2:
																														case 21:
																														case 33:
																														case 38:
																														case 41:
																														case 47:
																														case 48:
																														case 52:
																														case 53:
																														case 55:
																														case 56:
																														case 61:
																														case 71:
																														case 93:
																														case 103:
																														case 107:
																														case 108:
																														case 114:
																														case 134:
																														case 166:
																														case 167:
																														case 186:
																														case 195:
																														case 196:
																														case 212:
																														case 213:
																														case 230:
																														case 231:
																														case 240:
																														case 249:
																														case 258:
																														case 259:
																														case 269:
																														case 271:
																														case 272:
																														case 273:
																															goto IL_13eb;
																														case 39:
																															goto IL_13fe;
																														case 86:
																															goto IL_1411;
																														case 16:
																															goto IL_141c;
																														case 81:
																															goto IL_1435;
																														case 158:
																															goto IL_144e;
																														case 133:
																															goto IL_145e;
																														case 182:
																															goto IL_146e;
																														case 137:
																															goto IL_147e;
																														case 277:
																															goto IL_148e;
																														case 1:
																															goto IL_149e;
																														case 155:
																															goto IL_14ae;
																														case 164:
																														case 184:
																															return;
																														}
																														goto end_IL_04e4;
																													}
																													goto IL_083a;
																													IL_0861:
																													num6++;
																													goto IL_086f;
																													IL_086f:
																													ptr2 += 16;
																													num = 55;
																													goto IL_13eb;
																													IL_083a:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																													goto IL_0853;
																													IL_0853:
																													array2[num6] = 3;
																													goto IL_0861;
																													continue;
																													end_IL_0491:
																													break;
																												}
																												break;
																											}
																											goto IL_051a;
																											IL_0785:
																											if (24 > b)
																											{
																												break;
																											}
																											goto IL_0793;
																											IL_0793:
																											((delegate*<bool, void>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																											num = 97;
																											goto IL_07c6;
																											IL_051a:
																											if (21 >= b)
																											{
																												goto IL_0525;
																											}
																											goto IL_0551;
																											IL_0525:
																											if (21 > b)
																											{
																												goto IL_0530;
																											}
																											goto IL_0597;
																											IL_0530:
																											if (19 < b)
																											{
																												goto IL_053e;
																											}
																											goto IL_0608;
																											IL_053e:
																											if (20 < b)
																											{
																												break;
																											}
																											goto IL_061b;
																											IL_061b:
																											if (20 > b)
																											{
																												break;
																											}
																											goto IL_0629;
																											IL_0629:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_13eb;
																											IL_0608:
																											if (19 <= b)
																											{
																												goto IL_06c2;
																											}
																											goto IL_070a;
																											IL_06c2:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											goto IL_06db;
																											IL_06db:
																											array2[num6] = 1;
																											goto IL_06e9;
																											IL_06e9:
																											num6++;
																											goto IL_06f7;
																											IL_06f7:
																											ptr2 += 16;
																											goto IL_13eb;
																											IL_070a:
																											if (18 < b)
																											{
																												break;
																											}
																											goto IL_0718;
																											IL_0718:
																											if (18 > b)
																											{
																												break;
																											}
																											goto IL_0726;
																											IL_0726:
																											array2[num6 - 1] = 5;
																											goto IL_073a;
																											IL_073a:
																											array3[num6 - 1] = ((delegate*<string[], string>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																											goto IL_0772;
																											IL_0772:
																											ptr2 += 8;
																											goto IL_13eb;
																											IL_0597:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																											goto IL_05d8;
																											IL_05d8:
																											array2[num6 - 2] = 0;
																											goto IL_05ec;
																											IL_05ec:
																											num6--;
																											num = 93;
																											goto IL_13eb;
																											IL_0551:
																											if (23 >= b)
																											{
																												goto IL_055f;
																											}
																											goto IL_0641;
																											IL_055f:
																											if (23 > b)
																											{
																												goto IL_056d;
																											}
																											goto IL_07e7;
																											IL_056d:
																											if (22 < b)
																											{
																												break;
																											}
																											goto IL_057b;
																											IL_057b:
																											if (22 > b)
																											{
																												break;
																											}
																											num = 98;
																											goto IL_065d;
																											IL_07c6:
																											num6--;
																											goto IL_07d4;
																											IL_065d:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_06af;
																											IL_06af:
																											num6--;
																											goto IL_13eb;
																											IL_07e7:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])() ? 1 : 0);
																											goto IL_080b;
																											IL_080b:
																											array2[num6] = 0;
																											goto IL_0819;
																											IL_0819:
																											num6++;
																											goto IL_0827;
																											IL_0827:
																											ptr2 += 8;
																											goto IL_13eb;
																											IL_0641:
																											if (24 < b)
																											{
																												break;
																											}
																											num = 276;
																											goto IL_0785;
																											IL_07d4:
																											ptr2 += 8;
																											goto IL_13eb;
																										}
																										break;
																									}
																									goto IL_088b;
																									IL_0c0f:
																									if (33 > b)
																									{
																									}
																									break;
																									IL_088b:
																									if (29 >= b)
																									{
																										goto IL_0899;
																									}
																									goto IL_0aba;
																									IL_0899:
																									if (29 > b)
																									{
																										goto IL_08a7;
																									}
																									num = 88;
																									goto IL_0a49;
																									IL_08a7:
																									if (27 >= b)
																									{
																										goto IL_08b5;
																									}
																									goto IL_09be;
																									IL_08b5:
																									if (27 > b)
																									{
																										goto IL_08c3;
																									}
																									goto IL_094e;
																									IL_08c3:
																									if (26 < b)
																									{
																										break;
																									}
																									goto IL_08d1;
																									IL_08d1:
																									if (26 > b)
																									{
																										break;
																									}
																									num = 65;
																									goto IL_08e8;
																									IL_0c01:
																									if (33 < b)
																									{
																										break;
																									}
																									goto IL_0c0f;
																									IL_08e8:
																									array2[num6 - 1] = 3;
																									goto IL_08fc;
																									IL_08fc:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_093b;
																									IL_093b:
																									ptr2 += 8;
																									goto IL_13eb;
																									IL_094e:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									num = 200;
																									goto IL_0997;
																									IL_0997:
																									array2[num6 - 2] = 3;
																									goto IL_09ab;
																									IL_09ab:
																									num6--;
																									goto IL_13eb;
																									IL_09be:
																									if (28 < b)
																									{
																										break;
																									}
																									goto IL_09cc;
																									IL_09cc:
																									if (28 > b)
																									{
																										break;
																									}
																									goto IL_09da;
																									IL_09da:
																									array2[num6 - 1] = 0;
																									goto IL_09ee;
																									IL_09ee:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_0a2d;
																									IL_0a2d:
																									ptr2 += 8;
																									goto IL_13eb;
																									IL_0be5:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto IL_13eb;
																									IL_0a49:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0aa7;
																									IL_0aa7:
																									num6--;
																									goto IL_13eb;
																									IL_0aba:
																									if (31 >= b)
																									{
																										goto IL_0ac8;
																									}
																									goto IL_0bc3;
																									IL_0ac8:
																									if (31 <= b)
																									{
																										goto IL_0ad3;
																									}
																									goto IL_0b26;
																									IL_0ad3:
																									((delegate*<string, void>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																									goto IL_0afc;
																									IL_0afc:
																									num6--;
																									goto IL_0b0a;
																									IL_0b0a:
																									ptr2 += 8;
																									num = 271;
																									goto IL_13eb;
																									IL_0b26:
																									if (30 < b)
																									{
																										break;
																									}
																									goto IL_0b34;
																									IL_0b34:
																									if (30 > b)
																									{
																										break;
																									}
																									goto IL_0b42;
																									IL_0b42:
																									array2[num6 - 2] = 5;
																									goto IL_0b56;
																									IL_0b56:
																									array3[num6 - 2] = ((delegate*<string, string, string>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																									goto IL_0ba2;
																									IL_0ba2:
																									num6--;
																									goto IL_0bb0;
																									IL_0bb0:
																									ptr2 += 8;
																									goto IL_13eb;
																									IL_0bc3:
																									if (32 >= b)
																									{
																										goto IL_0bce;
																									}
																									goto IL_0c01;
																									IL_0bce:
																									if (32 > b)
																									{
																										break;
																									}
																									num = 80;
																									goto IL_0be5;
																								}
																								break;
																							}
																							goto IL_0c22;
																							IL_1389:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_1394;
																							IL_0c22:
																							if (17 <= b)
																							{
																								goto IL_0c2d;
																							}
																							goto IL_0c7e;
																							IL_0c2d:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_0c6b;
																							IL_0c6b:
																							num6 -= 3;
																							goto IL_13eb;
																							IL_0c7e:
																							if (8 >= b)
																							{
																								goto IL_0c8c;
																							}
																							goto IL_0ff2;
																							IL_0c8c:
																							if (8 <= b)
																							{
																								goto IL_0c97;
																							}
																							goto IL_0caa;
																							IL_0c97:
																							num6--;
																							goto IL_13eb;
																							IL_0caa:
																							if (4 >= b)
																							{
																								goto IL_0cb8;
																							}
																							goto IL_0e6c;
																							IL_0cb8:
																							if (4 > b)
																							{
																								goto IL_0cc6;
																							}
																							goto IL_0e10;
																							IL_0cc6:
																							if (2 >= b)
																							{
																								goto IL_0cd4;
																							}
																							goto IL_0daa;
																							IL_0cd4:
																							if (2 <= b)
																							{
																								goto IL_0cdf;
																							}
																							goto IL_0d46;
																							IL_0cdf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d1f;
																							IL_0d1f:
																							array2[num6 - 2] = 0;
																							goto IL_0d33;
																							IL_0d33:
																							num6--;
																							goto IL_13eb;
																							IL_0d46:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0d54;
																							IL_0d54:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0d62;
																							IL_0d62:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0d7b;
																							IL_0d7b:
																							array2[num6] = 0;
																							goto IL_0d89;
																							IL_0d89:
																							num6++;
																							goto IL_0d97;
																							IL_0d97:
																							ptr2 += 8;
																							goto IL_13eb;
																							IL_0daa:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0db8;
																							IL_0db8:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0dc6;
																							IL_0dc6:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0def;
																							IL_0def:
																							ptr2 += 8;
																							goto IL_0dfd;
																							IL_0dfd:
																							num6--;
																							goto IL_13eb;
																							IL_0e10:
																							array2[num6] = 0;
																							goto IL_0e1e;
																							IL_0e1e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0e41;
																							IL_0e41:
																							array3[num6] = null;
																							goto IL_0e4b;
																							IL_0e4b:
																							num6++;
																							goto IL_0e59;
																							IL_0e59:
																							ptr2 += 8;
																							goto IL_13eb;
																							IL_0e6c:
																							if (6 >= b)
																							{
																								goto IL_0e7a;
																							}
																							goto IL_0f6f;
																							IL_0e7a:
																							if (6 <= b)
																							{
																								goto IL_0e85;
																							}
																							goto IL_0eec;
																							IL_0e85:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0ec5;
																							IL_0ec5:
																							array2[num6 - 2] = 0;
																							goto IL_0ed9;
																							IL_0ed9:
																							num6--;
																							goto IL_13eb;
																							IL_0eec:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0efa;
																							IL_0efa:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0f08;
																							IL_0f08:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0f48;
																							IL_0f48:
																							array2[num6 - 2] = 0;
																							goto IL_0f5c;
																							IL_0f5c:
																							num6--;
																							goto IL_13eb;
																							IL_0f6f:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0f7d;
																							IL_0f7d:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0f8b;
																							IL_0f8b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0fcb;
																							IL_0fcb:
																							array2[num6 - 2] = 0;
																							goto IL_0fdf;
																							IL_0fdf:
																							num6--;
																							goto IL_13eb;
																							IL_0ff2:
																							if (12 >= b)
																							{
																								goto IL_1000;
																							}
																							goto IL_1221;
																							IL_1000:
																							if (12 <= b)
																							{
																								goto IL_100e;
																							}
																							goto IL_10e6;
																							IL_100e:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_101d;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_10c5;
																							IL_1394:
																							array2[num6] = 5;
																							goto IL_13a2;
																							IL_13a2:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_13ba;
																							IL_13ba:
																							num6++;
																							goto IL_13c8;
																							IL_10c5:
																							array2[num6] = 5;
																							goto IL_10d3;
																							IL_10d3:
																							num6++;
																							goto IL_13eb;
																							IL_10e6:
																							if (10 >= b)
																							{
																								goto IL_10f4;
																							}
																							goto IL_1200;
																							IL_10f4:
																							if (10 <= b)
																							{
																								goto IL_10ff;
																							}
																							goto IL_1174;
																							IL_10ff:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1161;
																							IL_1161:
																							num6 -= 2;
																							goto IL_13eb;
																							IL_1174:
																							if (9 < b)
																							{
																								break;
																							}
																							num = 211;
																							goto IL_118b;
																							IL_13c8:
																							ptr2 += 8;
																							goto IL_13eb;
																							IL_118b:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_1199;
																							IL_1199:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_11d9;
																							IL_11d9:
																							array2[num6 - 2] = 0;
																							goto IL_11ed;
																							IL_11ed:
																							num6--;
																							goto IL_13eb;
																							IL_1200:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_120e;
																							IL_120e:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_13eb;
																							IL_1221:
																							if (14 >= b)
																							{
																								goto IL_122f;
																							}
																							goto IL_12d7;
																							IL_122f:
																							if (14 <= b)
																							{
																								goto IL_123a;
																							}
																							goto IL_127c;
																							IL_123a:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1263;
																							IL_1263:
																							array2[num6 - 1] = 5;
																							goto IL_13eb;
																							IL_127c:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_128a;
																							IL_128a:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_1298;
																							IL_1298:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_12b6;
																							IL_12b6:
																							ptr2 += 8;
																							goto IL_12c4;
																							IL_12c4:
																							num6--;
																							goto IL_13eb;
																							IL_12d7:
																							if (15 >= b)
																							{
																								goto IL_12e5;
																							}
																							goto IL_137e;
																							IL_12e5:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_12f3;
																							IL_12f3:
																							array2[num6] = array2[num6 - 1];
																							goto IL_130b;
																							IL_130b:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_1329;
																							IL_1329:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_134d;
																							IL_134d:
																							array3[num6] = array3[num6 - 1];
																							goto IL_1365;
																							IL_1365:
																							num6++;
																							num = 33;
																							goto IL_13eb;
																							IL_137e:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_1389;
																						}
																						break;
																						IL_04d4:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_13eb;
																				continue;
																				end_IL_04e4:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_101d:
			while (true)
			{
				IL_101d_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_10c5_2:
						array2[num6] = 5;
						while (true)
						{
							IL_10d3_2:
							num6++;
							while (true)
							{
								IL_13eb_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									num = 153;
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_04e4_2:
												if (b >= 1)
												{
													while (b <= 33)
													{
														while (true)
														{
															IL_04c4_2:
															if (17 < b)
															{
																while (true)
																{
																	IL_04b4_2:
																	if (25 >= b)
																	{
																		while (true)
																		{
																			IL_04a4_2:
																			if (25 <= b)
																			{
																				num = 285;
																				while (true)
																				{
																					if (num != 285)
																					{
																						if (num != 1266)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 175:
																							goto IL_04a4_2;
																						case 87:
																							goto IL_04b4_2;
																						case 91:
																							goto IL_04c4_2;
																						case 203:
																							goto IL_04d4_2;
																						case 3:
																							goto IL_04e4_2;
																						case 199:
																							goto end_IL_04e4_2;
																						case 153:
																							goto end_IL_04f4;
																						case 149:
																							goto end_IL_0504;
																						case 4:
																							goto IL_051a_2;
																						case 27:
																							goto IL_0525_2;
																						case 74:
																							goto IL_0530_2;
																						case 85:
																							goto IL_053e_2;
																						case 151:
																							goto IL_0551_2;
																						case 12:
																							goto IL_055f_2;
																						case 116:
																							goto IL_056d_2;
																						case 49:
																							goto IL_057b_2;
																						case 83:
																						case 190:
																							goto IL_0597_2;
																						case 181:
																							goto IL_05d8_2;
																						case 77:
																							goto IL_05ec_2;
																						case 198:
																							goto IL_0608_2;
																						case 205:
																							goto IL_061b_2;
																						case 62:
																						case 131:
																							goto IL_0629_2;
																						case 229:
																							goto IL_0641_2;
																						case 98:
																						case 235:
																							goto IL_065d_2;
																						case 162:
																							goto IL_06af_2;
																						case 136:
																						case 242:
																							goto IL_06c2_2;
																						case 9:
																							goto IL_06db_2;
																						case 177:
																							goto IL_06e9_2;
																						case 219:
																							goto IL_06f7_2;
																						case 260:
																							goto IL_070a_2;
																						case 43:
																							goto IL_0718_2;
																						case 59:
																						case 220:
																							goto IL_0726_2;
																						case 95:
																							goto IL_073a_2;
																						case 106:
																							goto IL_0772_2;
																						case 276:
																							goto IL_0785_2;
																						case 160:
																						case 268:
																							goto IL_0793_2;
																						case 97:
																							goto IL_07c6_2;
																						case 26:
																							goto IL_07d4_2;
																						case 121:
																						case 278:
																							goto IL_07e7_2;
																						case 128:
																							goto IL_080b_2;
																						case 252:
																							goto IL_0819_2;
																						case 124:
																							goto IL_0827_2;
																						case 187:
																							goto IL_083a_2;
																						case 75:
																							goto IL_0853_2;
																						case 44:
																							goto IL_0861_2;
																						case 275:
																							goto IL_086f_2;
																						case 255:
																							goto IL_088b_2;
																						case 73:
																							goto IL_0899_2;
																						case 42:
																							goto IL_08a7_2;
																						case 197:
																							goto IL_08b5_2;
																						case 148:
																							goto IL_08c3_2;
																						case 129:
																							goto IL_08d1_2;
																						case 65:
																						case 117:
																							goto IL_08e8_2;
																						case 238:
																							goto IL_08fc_2;
																						case 246:
																							goto IL_093b_2;
																						case 24:
																						case 79:
																							goto IL_094e_2;
																						case 200:
																							goto IL_0997_2;
																						case 32:
																							goto IL_09ab_2;
																						case 125:
																							goto IL_09be_2;
																						case 226:
																							goto IL_09cc_2;
																						case 161:
																						case 224:
																							goto IL_09da_2;
																						case 176:
																							goto IL_09ee_2;
																						case 261:
																							goto IL_0a2d_2;
																						case 45:
																						case 88:
																							goto IL_0a49_2;
																						case 142:
																							goto IL_0aa7_2;
																						case 130:
																							goto IL_0aba_2;
																						case 29:
																							goto IL_0ac8_2;
																						case 102:
																						case 239:
																							goto IL_0ad3_2;
																						case 76:
																							goto IL_0afc_2;
																						case 144:
																							goto IL_0b0a_2;
																						case 64:
																							goto IL_0b26_2;
																						case 171:
																							goto IL_0b34_2;
																						case 63:
																						case 204:
																							goto IL_0b42_2;
																						case 90:
																							goto IL_0b56_2;
																						case 267:
																							goto IL_0ba2_2;
																						case 72:
																							goto IL_0bb0_2;
																						case 14:
																							goto IL_0bc3_2;
																						case 241:
																							goto IL_0bce_2;
																						case 80:
																						case 104:
																							goto IL_0be5_2;
																						case 58:
																							goto IL_0c01_2;
																						case 266:
																							goto IL_0c0f_2;
																						case 20:
																							goto IL_0c22_2;
																						case 67:
																						case 245:
																							goto IL_0c2d_2;
																						case 233:
																							goto IL_0c6b_2;
																						case 50:
																							goto IL_0c7e_2;
																						case 132:
																							goto IL_0c8c_2;
																						case 6:
																						case 209:
																							goto IL_0c97_2;
																						case 214:
																							goto IL_0caa_2;
																						case 227:
																							goto IL_0cb8_2;
																						case 28:
																							goto IL_0cc6_2;
																						case 140:
																							goto IL_0cd4_2;
																						case 54:
																						case 115:
																							goto IL_0cdf_2;
																						case 69:
																							goto IL_0d1f_2;
																						case 146:
																							goto IL_0d33_2;
																						case 201:
																							goto IL_0d46_2;
																						case 165:
																							goto IL_0d54_2;
																						case 145:
																						case 244:
																							goto IL_0d62_2;
																						case 210:
																							goto IL_0d7b_2;
																						case 221:
																							goto IL_0d89_2;
																						case 178:
																							goto IL_0d97_2;
																						case 228:
																							goto IL_0daa_2;
																						case 82:
																							goto IL_0db8_2;
																						case 46:
																						case 96:
																							goto IL_0dc6_2;
																						case 274:
																							goto IL_0def_2;
																						case 218:
																							goto IL_0dfd_2;
																						case 168:
																						case 202:
																							goto IL_0e10_2;
																						case 99:
																							goto IL_0e1e_2;
																						case 17:
																							goto IL_0e41_2;
																						case 101:
																							goto IL_0e4b_2;
																						case 222:
																							goto IL_0e59_2;
																						case 206:
																							goto IL_0e6c_2;
																						case 143:
																							goto IL_0e7a_2;
																						case 37:
																						case 51:
																							goto IL_0e85_2;
																						case 8:
																							goto IL_0ec5_2;
																						case 193:
																							goto IL_0ed9_2;
																						case 185:
																							goto IL_0eec_2;
																						case 11:
																							goto IL_0efa_2;
																						case 92:
																						case 232:
																							goto IL_0f08_2;
																						case 5:
																							goto IL_0f48_2;
																						case 147:
																							goto IL_0f5c_2;
																						case 25:
																							goto IL_0f6f_2;
																						case 179:
																							goto IL_0f7d_2;
																						case 223:
																						case 247:
																							goto IL_0f8b_2;
																						case 123:
																							goto IL_0fcb_2;
																						case 13:
																							goto IL_0fdf_2;
																						case 174:
																							goto IL_0ff2_2;
																						case 141:
																							goto IL_1000_2;
																						case 18:
																						case 225:
																							goto end_IL_050f;
																						case 7:
																							goto IL_10c5_2;
																						case 194:
																							goto IL_10d3_2;
																						case 111:
																							goto IL_10e6_2;
																						case 35:
																							goto IL_10f4_2;
																						case 169:
																						case 254:
																							goto IL_10ff_2;
																						case 180:
																							goto IL_1161_2;
																						case 154:
																							goto IL_1174_2;
																						case 211:
																							goto IL_118b_2;
																						case 70:
																						case 256:
																							goto IL_1199_2;
																						case 208:
																							goto IL_11d9_2;
																						case 263:
																							goto IL_11ed_2;
																						case 40:
																							goto IL_1200_2;
																						case 250:
																							goto IL_120e_2;
																						case 253:
																							goto IL_1221_2;
																						case 31:
																							goto IL_122f_2;
																						case 237:
																						case 251:
																							goto IL_123a_2;
																						case 78:
																							goto IL_1263_2;
																						case 192:
																							goto IL_127c_2;
																						case 118:
																							goto IL_128a_2;
																						case 172:
																						case 248:
																							goto IL_1298_2;
																						case 138:
																							goto IL_12b6_2;
																						case 216:
																							goto IL_12c4_2;
																						case 36:
																							goto IL_12d7_2;
																						case 120:
																							goto IL_12e5_2;
																						case 57:
																						case 127:
																							goto IL_12f3_2;
																						case 34:
																							goto IL_130b_2;
																						case 113:
																							goto IL_1329_2;
																						case 15:
																							goto IL_134d_2;
																						case 157:
																							goto IL_1365_2;
																						case 112:
																							goto IL_137e_2;
																						case 122:
																							goto IL_1389_2;
																						case 207:
																						case 215:
																							goto IL_1394_2;
																						case 150:
																							goto IL_13a2_2;
																						case 94:
																							goto IL_13ba_2;
																						case 10:
																							goto IL_13c8_2;
																						case 0:
																						case 19:
																						case 22:
																						case 23:
																						case 30:
																						case 60:
																						case 66:
																						case 68:
																						case 84:
																						case 89:
																						case 100:
																						case 105:
																						case 109:
																						case 110:
																						case 119:
																						case 126:
																						case 135:
																						case 139:
																						case 152:
																						case 159:
																						case 163:
																						case 170:
																						case 173:
																						case 183:
																						case 188:
																						case 189:
																						case 191:
																						case 217:
																						case 234:
																						case 236:
																						case 243:
																						case 257:
																						case 262:
																						case 264:
																						case 265:
																						case 270:
																							goto end_IL_0491_2;
																						case 2:
																						case 21:
																						case 33:
																						case 38:
																						case 41:
																						case 47:
																						case 48:
																						case 52:
																						case 53:
																						case 55:
																						case 56:
																						case 61:
																						case 71:
																						case 93:
																						case 103:
																						case 107:
																						case 108:
																						case 114:
																						case 134:
																						case 166:
																						case 167:
																						case 186:
																						case 195:
																						case 196:
																						case 212:
																						case 213:
																						case 230:
																						case 231:
																						case 240:
																						case 249:
																						case 258:
																						case 259:
																						case 269:
																						case 271:
																						case 272:
																						case 273:
																							goto IL_13eb_2;
																						case 39:
																							ptr2 = ptr;
																							num = 212;
																							goto IL_13eb_2;
																						case 86:
																							ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackCrawlMarkHandleSoapServices.PermissionSetNameOverlappedData);
																							goto case 39;
																						case 16:
																							array7 = new object[13];
																							num = 86;
																							goto case 86;
																						case 81:
																							array6 = new long[4];
																							num = 16;
																							goto case 16;
																						case 158:
																							array5 = new int[7];
																							goto case 81;
																						case 133:
																							array4 = new int[4];
																							goto case 158;
																						case 182:
																							array3 = new object[4];
																							goto case 133;
																						case 137:
																							array2 = new byte[4];
																							goto case 182;
																						case 277:
																							num4 = num2 * 8;
																							goto case 137;
																						case 1:
																							num3 = num2 * 4;
																							goto case 277;
																						case 155:
																							num2 = 1;
																							goto case 1;
																						case 156:
																							goto end_IL_102b;
																						case 164:
																						case 184:
																							return;
																						}
																						continue;
																					}
																					goto IL_083a_2;
																					IL_0861_2:
																					num6++;
																					goto IL_086f_2;
																					IL_086f_2:
																					ptr2 += 16;
																					num = 55;
																					goto IL_13eb_2;
																					IL_083a_2:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																					goto IL_0853_2;
																					IL_0853_2:
																					array2[num6] = 3;
																					goto IL_0861_2;
																					continue;
																					end_IL_0491_2:
																					break;
																				}
																				break;
																			}
																			goto IL_051a_2;
																			IL_0785_2:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_0793_2;
																			IL_0793_2:
																			((delegate*<bool, void>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																			num = 97;
																			goto IL_07c6_2;
																			IL_051a_2:
																			if (21 >= b)
																			{
																				goto IL_0525_2;
																			}
																			goto IL_0551_2;
																			IL_0525_2:
																			if (21 > b)
																			{
																				goto IL_0530_2;
																			}
																			goto IL_0597_2;
																			IL_0530_2:
																			if (19 < b)
																			{
																				goto IL_053e_2;
																			}
																			goto IL_0608_2;
																			IL_053e_2:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_061b_2;
																			IL_061b_2:
																			if (20 > b)
																			{
																				break;
																			}
																			goto IL_0629_2;
																			IL_0629_2:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_13eb_2;
																			IL_0608_2:
																			if (19 <= b)
																			{
																				goto IL_06c2_2;
																			}
																			goto IL_070a_2;
																			IL_06c2_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																			goto IL_06db_2;
																			IL_06db_2:
																			array2[num6] = 1;
																			goto IL_06e9_2;
																			IL_06e9_2:
																			num6++;
																			goto IL_06f7_2;
																			IL_06f7_2:
																			ptr2 += 16;
																			goto IL_13eb_2;
																			IL_070a_2:
																			if (18 < b)
																			{
																				break;
																			}
																			goto IL_0718_2;
																			IL_0718_2:
																			if (18 > b)
																			{
																				break;
																			}
																			goto IL_0726_2;
																			IL_0726_2:
																			array2[num6 - 1] = 5;
																			goto IL_073a_2;
																			IL_073a_2:
																			array3[num6 - 1] = ((delegate*<string[], string>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																			goto IL_0772_2;
																			IL_0772_2:
																			ptr2 += 8;
																			goto IL_13eb_2;
																			IL_0597_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																			goto IL_05d8_2;
																			IL_05d8_2:
																			array2[num6 - 2] = 0;
																			goto IL_05ec_2;
																			IL_05ec_2:
																			num6--;
																			num = 93;
																			goto IL_13eb_2;
																			IL_0551_2:
																			if (23 >= b)
																			{
																				goto IL_055f_2;
																			}
																			goto IL_0641_2;
																			IL_055f_2:
																			if (23 > b)
																			{
																				goto IL_056d_2;
																			}
																			goto IL_07e7_2;
																			IL_056d_2:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_057b_2;
																			IL_057b_2:
																			if (22 > b)
																			{
																				break;
																			}
																			num = 98;
																			goto IL_065d_2;
																			IL_07c6_2:
																			num6--;
																			goto IL_07d4_2;
																			IL_065d_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06af_2;
																			IL_06af_2:
																			num6--;
																			goto IL_13eb_2;
																			IL_07e7_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])() ? 1 : 0);
																			goto IL_080b_2;
																			IL_080b_2:
																			array2[num6] = 0;
																			goto IL_0819_2;
																			IL_0819_2:
																			num6++;
																			goto IL_0827_2;
																			IL_0827_2:
																			ptr2 += 8;
																			goto IL_13eb_2;
																			IL_0641_2:
																			if (24 < b)
																			{
																				break;
																			}
																			num = 276;
																			goto IL_0785_2;
																			IL_07d4_2:
																			ptr2 += 8;
																			goto IL_13eb_2;
																		}
																		break;
																	}
																	goto IL_088b_2;
																	IL_0c0f_2:
																	if (33 > b)
																	{
																	}
																	break;
																	IL_088b_2:
																	if (29 >= b)
																	{
																		goto IL_0899_2;
																	}
																	goto IL_0aba_2;
																	IL_0899_2:
																	if (29 > b)
																	{
																		goto IL_08a7_2;
																	}
																	num = 88;
																	goto IL_0a49_2;
																	IL_08a7_2:
																	if (27 >= b)
																	{
																		goto IL_08b5_2;
																	}
																	goto IL_09be_2;
																	IL_08b5_2:
																	if (27 > b)
																	{
																		goto IL_08c3_2;
																	}
																	goto IL_094e_2;
																	IL_08c3_2:
																	if (26 < b)
																	{
																		break;
																	}
																	goto IL_08d1_2;
																	IL_08d1_2:
																	if (26 > b)
																	{
																		break;
																	}
																	num = 65;
																	goto IL_08e8_2;
																	IL_0c01_2:
																	if (33 < b)
																	{
																		break;
																	}
																	goto IL_0c0f_2;
																	IL_08e8_2:
																	array2[num6 - 1] = 3;
																	goto IL_08fc_2;
																	IL_08fc_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_093b_2;
																	IL_093b_2:
																	ptr2 += 8;
																	goto IL_13eb_2;
																	IL_094e_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	num = 200;
																	goto IL_0997_2;
																	IL_0997_2:
																	array2[num6 - 2] = 3;
																	goto IL_09ab_2;
																	IL_09ab_2:
																	num6--;
																	goto IL_13eb_2;
																	IL_09be_2:
																	if (28 < b)
																	{
																		break;
																	}
																	goto IL_09cc_2;
																	IL_09cc_2:
																	if (28 > b)
																	{
																		break;
																	}
																	goto IL_09da_2;
																	IL_09da_2:
																	array2[num6 - 1] = 0;
																	goto IL_09ee_2;
																	IL_09ee_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0a2d_2;
																	IL_0a2d_2:
																	ptr2 += 8;
																	goto IL_13eb_2;
																	IL_0be5_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto IL_13eb_2;
																	IL_0a49_2:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0aa7_2;
																	IL_0aa7_2:
																	num6--;
																	goto IL_13eb_2;
																	IL_0aba_2:
																	if (31 >= b)
																	{
																		goto IL_0ac8_2;
																	}
																	goto IL_0bc3_2;
																	IL_0ac8_2:
																	if (31 <= b)
																	{
																		goto IL_0ad3_2;
																	}
																	goto IL_0b26_2;
																	IL_0ad3_2:
																	((delegate*<string, void>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																	goto IL_0afc_2;
																	IL_0afc_2:
																	num6--;
																	goto IL_0b0a_2;
																	IL_0b0a_2:
																	ptr2 += 8;
																	num = 271;
																	goto IL_13eb_2;
																	IL_0b26_2:
																	if (30 < b)
																	{
																		break;
																	}
																	goto IL_0b34_2;
																	IL_0b34_2:
																	if (30 > b)
																	{
																		break;
																	}
																	goto IL_0b42_2;
																	IL_0b42_2:
																	array2[num6 - 2] = 5;
																	goto IL_0b56_2;
																	IL_0b56_2:
																	array3[num6 - 2] = ((delegate*<string, string, string>)STOREASSEMBLYSTATUSPARTIALINSTALLEvidenceTypeGenerated[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																	goto IL_0ba2_2;
																	IL_0ba2_2:
																	num6--;
																	goto IL_0bb0_2;
																	IL_0bb0_2:
																	ptr2 += 8;
																	goto IL_13eb_2;
																	IL_0bc3_2:
																	if (32 >= b)
																	{
																		goto IL_0bce_2;
																	}
																	goto IL_0c01_2;
																	IL_0bce_2:
																	if (32 > b)
																	{
																		break;
																	}
																	num = 80;
																	goto IL_0be5_2;
																}
																break;
															}
															goto IL_0c22_2;
															IL_13ba_2:
															num6++;
															goto IL_13c8_2;
															IL_0c22_2:
															if (17 <= b)
															{
																goto IL_0c2d_2;
															}
															goto IL_0c7e_2;
															IL_0c2d_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_0c6b_2;
															IL_0c6b_2:
															num6 -= 3;
															goto IL_13eb_2;
															IL_0c7e_2:
															if (8 >= b)
															{
																goto IL_0c8c_2;
															}
															goto IL_0ff2_2;
															IL_0c8c_2:
															if (8 <= b)
															{
																goto IL_0c97_2;
															}
															goto IL_0caa_2;
															IL_0c97_2:
															num6--;
															goto IL_13eb_2;
															IL_0caa_2:
															if (4 >= b)
															{
																goto IL_0cb8_2;
															}
															goto IL_0e6c_2;
															IL_0cb8_2:
															if (4 > b)
															{
																goto IL_0cc6_2;
															}
															goto IL_0e10_2;
															IL_0cc6_2:
															if (2 >= b)
															{
																goto IL_0cd4_2;
															}
															goto IL_0daa_2;
															IL_0cd4_2:
															if (2 <= b)
															{
																goto IL_0cdf_2;
															}
															goto IL_0d46_2;
															IL_0cdf_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0d1f_2;
															IL_0d1f_2:
															array2[num6 - 2] = 0;
															goto IL_0d33_2;
															IL_0d33_2:
															num6--;
															goto IL_13eb_2;
															IL_0d46_2:
															if (1 < b)
															{
																break;
															}
															goto IL_0d54_2;
															IL_0d54_2:
															if (1 > b)
															{
																break;
															}
															goto IL_0d62_2;
															IL_0d62_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_0d7b_2;
															IL_0d7b_2:
															array2[num6] = 0;
															goto IL_0d89_2;
															IL_0d89_2:
															num6++;
															goto IL_0d97_2;
															IL_0d97_2:
															ptr2 += 8;
															goto IL_13eb_2;
															IL_0daa_2:
															if (3 < b)
															{
																break;
															}
															goto IL_0db8_2;
															IL_0db8_2:
															if (3 > b)
															{
																break;
															}
															goto IL_0dc6_2;
															IL_0dc6_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0def_2;
															IL_0def_2:
															ptr2 += 8;
															goto IL_0dfd_2;
															IL_0dfd_2:
															num6--;
															goto IL_13eb_2;
															IL_0e10_2:
															array2[num6] = 0;
															goto IL_0e1e_2;
															IL_0e1e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0e41_2;
															IL_0e41_2:
															array3[num6] = null;
															goto IL_0e4b_2;
															IL_0e4b_2:
															num6++;
															goto IL_0e59_2;
															IL_0e59_2:
															ptr2 += 8;
															goto IL_13eb_2;
															IL_0e6c_2:
															if (6 >= b)
															{
																goto IL_0e7a_2;
															}
															goto IL_0f6f_2;
															IL_0e7a_2:
															if (6 <= b)
															{
																goto IL_0e85_2;
															}
															goto IL_0eec_2;
															IL_0e85_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0ec5_2;
															IL_0ec5_2:
															array2[num6 - 2] = 0;
															goto IL_0ed9_2;
															IL_0ed9_2:
															num6--;
															goto IL_13eb_2;
															IL_0eec_2:
															if (5 < b)
															{
																break;
															}
															goto IL_0efa_2;
															IL_0efa_2:
															if (5 > b)
															{
																break;
															}
															goto IL_0f08_2;
															IL_0f08_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0f48_2;
															IL_0f48_2:
															array2[num6 - 2] = 0;
															goto IL_0f5c_2;
															IL_0f5c_2:
															num6--;
															goto IL_13eb_2;
															IL_0f6f_2:
															if (7 < b)
															{
																break;
															}
															goto IL_0f7d_2;
															IL_0f7d_2:
															if (7 > b)
															{
																break;
															}
															goto IL_0f8b_2;
															IL_0f8b_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0fcb_2;
															IL_0fcb_2:
															array2[num6 - 2] = 0;
															goto IL_0fdf_2;
															IL_0fdf_2:
															num6--;
															goto IL_13eb_2;
															IL_0ff2_2:
															if (12 >= b)
															{
																goto IL_1000_2;
															}
															goto IL_1221_2;
															IL_1000_2:
															if (12 <= b)
															{
																goto end_IL_050f;
															}
															goto IL_10e6_2;
															IL_10e6_2:
															if (10 >= b)
															{
																goto IL_10f4_2;
															}
															goto IL_1200_2;
															IL_10f4_2:
															if (10 <= b)
															{
																goto IL_10ff_2;
															}
															goto IL_1174_2;
															IL_10ff_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_1161_2;
															IL_1161_2:
															num6 -= 2;
															goto IL_13eb_2;
															IL_1174_2:
															if (9 < b)
															{
																break;
															}
															num = 211;
															goto IL_118b_2;
															IL_13c8_2:
															ptr2 += 8;
															goto IL_13eb_2;
															IL_118b_2:
															if (9 > b)
															{
																break;
															}
															goto IL_1199_2;
															IL_1199_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_11d9_2;
															IL_11d9_2:
															array2[num6 - 2] = 0;
															goto IL_11ed_2;
															IL_11ed_2:
															num6--;
															goto IL_13eb_2;
															IL_1200_2:
															if (11 < b)
															{
																break;
															}
															goto IL_120e_2;
															IL_120e_2:
															if (11 > b)
															{
																break;
															}
															goto IL_13eb_2;
															IL_1221_2:
															if (14 >= b)
															{
																goto IL_122f_2;
															}
															goto IL_12d7_2;
															IL_122f_2:
															if (14 <= b)
															{
																goto IL_123a_2;
															}
															goto IL_127c_2;
															IL_123a_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_1263_2;
															IL_1263_2:
															array2[num6 - 1] = 5;
															goto IL_13eb_2;
															IL_127c_2:
															if (13 < b)
															{
																break;
															}
															goto IL_128a_2;
															IL_128a_2:
															if (13 > b)
															{
																break;
															}
															goto IL_1298_2;
															IL_1298_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_12b6_2;
															IL_12b6_2:
															ptr2 += 8;
															goto IL_12c4_2;
															IL_12c4_2:
															num6--;
															goto IL_13eb_2;
															IL_12d7_2:
															if (15 >= b)
															{
																goto IL_12e5_2;
															}
															goto IL_137e_2;
															IL_12e5_2:
															if (15 > b)
															{
																break;
															}
															goto IL_12f3_2;
															IL_12f3_2:
															array2[num6] = array2[num6 - 1];
															goto IL_130b_2;
															IL_130b_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_1329_2;
															IL_1329_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_134d_2;
															IL_134d_2:
															array3[num6] = array3[num6 - 1];
															goto IL_1365_2;
															IL_1365_2:
															num6++;
															num = 33;
															goto IL_13eb_2;
															IL_137e_2:
															if (16 < b)
															{
																break;
															}
															goto IL_1389_2;
															IL_1389_2:
															if (16 > b)
															{
																break;
															}
															goto IL_1394_2;
															IL_1394_2:
															array2[num6] = 5;
															goto IL_13a2_2;
															IL_13a2_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_13ba_2;
														}
														break;
														IL_04d4_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_13eb_2;
												continue;
												end_IL_04e4_2:
												break;
											}
											continue;
											end_IL_04f4:
											break;
										}
										continue;
										end_IL_0504:
										break;
									}
									continue;
									end_IL_050f:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_101d_2;
					}
					continue;
					end_IL_102b:
					break;
				}
				break;
			}
		}
	}

	public Class130()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnsafeLoadFromTimerCallback.IidParameterIndexDynamicPartitionerForIEnumerable);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0322:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0302:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f2:
																					if (7 > b)
																					{
																						num = 84;
																						while (true)
																						{
																							IL_02e2:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02d2:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_02bf:
																											if (1 < b)
																											{
																												num = 86;
																												while (2 >= b)
																												{
																													while (true)
																													{
																														IL_029c:
																														if (2 > b)
																														{
																															num = 148;
																															while (num != 148 && num == 1129)
																															{
																																switch (num)
																																{
																																case 52:
																																	goto IL_029c;
																																case 27:
																																case 86:
																																	goto IL_02af;
																																case 85:
																																case 93:
																																	goto IL_02bf;
																																case 68:
																																	goto IL_02d2;
																																case 79:
																																case 84:
																																	goto IL_02e2;
																																case 60:
																																	goto IL_02f2;
																																case 107:
																																	goto IL_0302;
																																case 108:
																																	goto IL_0312;
																																case 103:
																																	goto IL_0322;
																																case 64:
																																	goto end_IL_0322;
																																case 2:
																																case 82:
																																	goto end_IL_0332;
																																case 19:
																																case 30:
																																	goto IL_034d;
																																case 1:
																																case 35:
																																	goto IL_0378;
																																case 62:
																																	goto IL_03b8;
																																case 75:
																																	goto IL_03d1;
																																case 36:
																																	goto IL_03df;
																																case 78:
																																	goto IL_03f2;
																																case 11:
																																case 100:
																																	goto IL_0400;
																																case 47:
																																	goto IL_0419;
																																case 76:
																																	goto IL_0427;
																																case 12:
																																	goto IL_043e;
																																case 118:
																																	goto IL_0451;
																																case 45:
																																case 117:
																																	goto IL_0464;
																																case 14:
																																case 138:
																																	goto IL_047c;
																																case 74:
																																case 129:
																																	goto IL_048a;
																																case 88:
																																	goto IL_0498;
																																case 56:
																																case 92:
																																	goto IL_04af;
																																case 22:
																																	goto IL_04ef;
																																case 40:
																																	goto IL_0503;
																																case 137:
																																	goto IL_051f;
																																case 50:
																																	goto IL_052a;
																																case 73:
																																	goto IL_0538;
																																case 54:
																																case 59:
																																	goto IL_054b;
																																case 51:
																																	goto IL_0559;
																																case 26:
																																	goto IL_057c;
																																case 23:
																																	goto IL_0586;
																																case 77:
																																	goto IL_0594;
																																case 71:
																																	goto IL_05b0;
																																case 31:
																																	goto IL_05be;
																																case 105:
																																case 120:
																																	goto IL_05c9;
																																case 122:
																																	goto IL_05d7;
																																case 134:
																																	goto IL_05ea;
																																case 17:
																																case 43:
																																	goto IL_05f5;
																																case 104:
																																	goto IL_0603;
																																case 109:
																																case 112:
																																	goto IL_061c;
																																case 7:
																																case 65:
																																	goto IL_062f;
																																case 24:
																																	goto IL_065d;
																																case 38:
																																case 55:
																																	goto IL_066b;
																																case 69:
																																	goto IL_067f;
																																case 136:
																																	goto IL_06d3;
																																case 80:
																																	goto IL_06ea;
																																case 127:
																																	goto IL_06fd;
																																case 58:
																																case 116:
																																	goto IL_070b;
																																case 83:
																																	goto IL_0719;
																																case 28:
																																case 121:
																																	goto IL_0727;
																																case 46:
																																	goto IL_0767;
																																case 16:
																																	goto IL_077b;
																																case 97:
																																	goto IL_078e;
																																case 42:
																																case 98:
																																	goto IL_079c;
																																case 66:
																																	goto IL_07b0;
																																case 99:
																																case 102:
																																	goto IL_07bb;
																																case 106:
																																	goto IL_07de;
																																case 133:
																																	goto IL_07ec;
																																case 126:
																																	goto IL_07fa;
																																case 0:
																																case 8:
																																case 13:
																																case 15:
																																case 18:
																																case 25:
																																case 34:
																																case 37:
																																case 39:
																																case 57:
																																case 67:
																																case 72:
																																case 87:
																																case 89:
																																case 90:
																																case 94:
																																case 95:
																																case 101:
																																case 111:
																																case 123:
																																case 124:
																																case 128:
																																case 130:
																																case 140:
																																	goto end_IL_0289;
																																case 114:
																																case 132:
																																	goto IL_0822;
																																case 119:
																																	goto IL_0884;
																																case 6:
																																case 10:
																																case 21:
																																case 32:
																																case 33:
																																case 44:
																																case 49:
																																case 53:
																																case 63:
																																case 70:
																																case 81:
																																case 96:
																																case 113:
																																case 125:
																																case 135:
																																case 139:
																																case 141:
																																	goto end_IL_0342;
																																case 61:
																																	goto end_IL_0892;
																																case 110:
																																	goto end_IL_08a5;
																																case 5:
																																	goto end_IL_08af;
																																case 48:
																																	goto end_IL_08ba;
																																case 9:
																																case 20:
																																	goto end_IL_08cf;
																																case 91:
																																	goto end_IL_08df;
																																case 115:
																																case 131:
																																	goto end_IL_08ef;
																																case 3:
																																	goto end_IL_08ff;
																																case 4:
																																	goto end_IL_090f;
																																case 29:
																																case 41:
																																	goto IL_0933;
																																}
																																continue;
																																end_IL_0289:
																																break;
																															}
																															break;
																														}
																														goto IL_034d;
																														IL_03d1:
																														ptr2 += 8;
																														goto IL_03df;
																														IL_03df:
																														num5--;
																														goto end_IL_0342;
																														IL_034d:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_03d1;
																													}
																													break;
																													IL_02af:;
																												}
																												break;
																											}
																											goto IL_03f2;
																											IL_0427:
																											num5++;
																											num = 12;
																											goto IL_043e;
																											IL_043e:
																											ptr2 += 8;
																											goto end_IL_0342;
																											IL_03f2:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0400;
																											IL_0400:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0419;
																											IL_0419:
																											array[num5] = 0;
																											goto IL_0427;
																										}
																										break;
																									}
																									goto IL_0464;
																									IL_0464:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0342;
																								}
																								break;
																							}
																							goto IL_047c;
																							IL_0586:
																							num5++;
																							goto IL_0594;
																							IL_047c:
																							if (5 < b)
																							{
																								goto IL_048a;
																							}
																							goto IL_051f;
																							IL_048a:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0498;
																							IL_0498:
																							if (6 > b)
																							{
																								break;
																							}
																							num = 92;
																							goto IL_04af;
																							IL_0594:
																							ptr2 += 8;
																							num = 63;
																							goto end_IL_0342;
																							IL_04af:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04ef;
																							IL_04ef:
																							array[num5 - 2] = 0;
																							goto IL_0503;
																							IL_0503:
																							num5--;
																							num = 96;
																							goto end_IL_0342;
																							IL_051f:
																							if (5 > b)
																							{
																								goto IL_052a;
																							}
																							goto IL_054b;
																							IL_052a:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0538;
																							IL_0538:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_0342;
																							IL_054b:
																							array[num5] = 0;
																							goto IL_0559;
																							IL_0559:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_057c;
																							IL_057c:
																							array2[num5] = null;
																							goto IL_0586;
																						}
																						break;
																					}
																					goto IL_0378;
																					IL_03b8:
																					array[num5 - 2] = 0;
																					goto IL_0451;
																					IL_0451:
																					num5--;
																					goto end_IL_0342;
																					IL_0378:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03b8;
																				}
																				break;
																			}
																			goto IL_05b0;
																			IL_07ec:
																			num5++;
																			goto IL_07fa;
																			IL_05b0:
																			if (11 < b)
																			{
																				goto IL_05be;
																			}
																			num = 24;
																			goto IL_065d;
																			IL_05be:
																			if (13 < b)
																			{
																				goto IL_05c9;
																			}
																			goto IL_05ea;
																			IL_05c9:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_05d7;
																			IL_05d7:
																			if (14 > b)
																			{
																			}
																			break;
																			IL_05ea:
																			if (13 > b)
																			{
																				goto IL_05f5;
																			}
																			goto IL_062f;
																			IL_05f5:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_0603;
																			IL_0603:
																			if (12 > b)
																			{
																				num = 128;
																				break;
																			}
																			goto IL_061c;
																			IL_0822:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0884;
																			IL_061c:
																			num5--;
																			goto end_IL_0342;
																			IL_062f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 70;
																			goto end_IL_0342;
																			IL_07fa:
																			ptr2 += 8;
																			goto end_IL_0342;
																			IL_065d:
																			if (11 <= b)
																			{
																				goto IL_066b;
																			}
																			goto IL_06fd;
																			IL_066b:
																			array[num5 - 2] = 0;
																			goto IL_067f;
																			IL_067f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)KoreanLunisolarCalendarSizeof[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_06d3;
																			IL_06d3:
																			num5--;
																			num = 80;
																			goto IL_06ea;
																			IL_06ea:
																			ptr2 += 8;
																			goto end_IL_0342;
																			IL_06fd:
																			if (9 < b)
																			{
																				goto IL_070b;
																			}
																			goto IL_078e;
																			IL_070b:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0719;
																			IL_0719:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0727;
																			IL_0727:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0767;
																			IL_0767:
																			array[num5 - 2] = 0;
																			goto IL_077b;
																			IL_077b:
																			num5--;
																			goto end_IL_0342;
																			IL_078e:
																			if (9 > b)
																			{
																				goto IL_079c;
																			}
																			goto IL_0822;
																			IL_079c:
																			if (8 < b)
																			{
																				break;
																			}
																			num = 66;
																			goto IL_07b0;
																			IL_0884:
																			num5 -= 2;
																			goto end_IL_0342;
																			IL_07b0:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_07bb;
																			IL_07bb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_07de;
																			IL_07de:
																			array[num5] = 0;
																			goto IL_07ec;
																		}
																		break;
																		IL_0312:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0342;
																continue;
																end_IL_0322:
																break;
															}
															continue;
															end_IL_0332:
															break;
														}
														continue;
														end_IL_0342:
														break;
													}
													continue;
												}
												num = 29;
												goto IL_0933;
												IL_0933:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0892:
												break;
											}
											continue;
											end_IL_08a5:
											break;
										}
										continue;
										end_IL_08af:
										break;
									}
									continue;
									end_IL_08ba:
									break;
								}
								continue;
								end_IL_08cf:
								break;
							}
							continue;
							end_IL_08df:
							break;
						}
						continue;
						end_IL_08ef:
						break;
					}
					continue;
					end_IL_08ff:
					break;
				}
				continue;
				end_IL_090f:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 39;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 7;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 41;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConfiguredTaskAwaitablePMDesignator.EnableCountTwoLevelFileEnumerator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f0:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02d0:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02c3:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02b3:
																							if (14 < b)
																							{
																								while (true)
																								{
																									IL_02a0:
																									if (15 < b)
																									{
																										num = 156;
																										while (num != 156)
																										{
																											if (num != 1137)
																											{
																												goto IL_0803;
																											}
																											switch (num)
																											{
																											case 8:
																											case 128:
																												goto IL_02a0;
																											case 71:
																											case 80:
																												goto IL_02b3;
																											case 35:
																											case 90:
																												goto IL_02c3;
																											case 40:
																												goto IL_02d0;
																											case 9:
																												goto IL_02e0;
																											case 51:
																												goto IL_02f0;
																											case 110:
																												goto end_IL_02f0;
																											case 28:
																											case 139:
																												goto end_IL_0300;
																											case 42:
																												goto IL_031b;
																											case 120:
																												goto IL_0329;
																											case 37:
																											case 118:
																												goto IL_0334;
																											case 4:
																												goto IL_0342;
																											case 62:
																											case 91:
																												goto IL_0350;
																											case 96:
																												goto IL_0396;
																											case 15:
																											case 44:
																												goto IL_03a4;
																											case 113:
																												goto IL_03bb;
																											case 89:
																												goto IL_03de;
																											case 16:
																												goto IL_03e8;
																											case 14:
																												goto IL_03f6;
																											case 142:
																												goto IL_0409;
																											case 81:
																												goto IL_041d;
																											case 68:
																											case 144:
																												goto IL_0430;
																											case 32:
																												goto IL_043e;
																											case 121:
																											case 149:
																												goto IL_0451;
																											case 22:
																												goto IL_0491;
																											case 26:
																												goto IL_04a5;
																											case 143:
																												goto IL_04b8;
																											case 31:
																												goto IL_04cb;
																											case 136:
																											case 148:
																												goto IL_04d9;
																											case 3:
																												goto IL_04e7;
																											case 66:
																											case 141:
																												goto IL_04f5;
																											case 112:
																												goto IL_0560;
																											case 0:
																											case 107:
																												goto IL_0573;
																											case 74:
																												goto IL_058f;
																											case 50:
																											case 94:
																												goto IL_059a;
																											case 1:
																												goto IL_05b2;
																											case 64:
																											case 86:
																												goto IL_05c0;
																											case 20:
																											case 82:
																												goto IL_05cb;
																											case 105:
																												goto IL_05d9;
																											case 85:
																											case 106:
																												goto IL_05e7;
																											case 140:
																												goto IL_0610;
																											case 84:
																												goto IL_061e;
																											case 119:
																												goto IL_063a;
																											case 76:
																												goto IL_0645;
																											case 87:
																												goto IL_0653;
																											case 11:
																											case 99:
																												goto IL_065e;
																											case 33:
																												goto IL_066c;
																											case 72:
																												goto IL_0684;
																											case 57:
																												goto IL_0692;
																											case 36:
																											case 104:
																												goto IL_06c5;
																											case 145:
																												goto IL_0704;
																											case 116:
																												goto IL_0720;
																											case 54:
																											case 146:
																												goto IL_072e;
																											case 131:
																												goto IL_073c;
																											case 24:
																											case 97:
																												goto IL_0747;
																											case 92:
																												goto IL_0787;
																											case 101:
																												goto IL_079b;
																											case 63:
																												goto IL_07b7;
																											case 135:
																												goto IL_07ce;
																											case 130:
																											case 138:
																												goto IL_07dc;
																											case 122:
																												goto IL_07f5;
																											case 46:
																												goto IL_0803;
																											case 18:
																												goto IL_0811;
																											case 67:
																												goto IL_0824;
																											case 69:
																												goto IL_0832;
																											case 65:
																											case 79:
																												goto IL_083d;
																											case 95:
																												goto IL_0866;
																											case 78:
																											case 117:
																												goto IL_087c;
																											case 25:
																												goto IL_089a;
																											case 59:
																												goto IL_08a8;
																											case 2:
																											case 5:
																											case 6:
																											case 12:
																											case 17:
																											case 19:
																											case 21:
																											case 29:
																											case 30:
																											case 34:
																											case 47:
																											case 55:
																											case 58:
																											case 60:
																											case 70:
																											case 73:
																											case 77:
																											case 88:
																											case 93:
																											case 100:
																											case 102:
																											case 109:
																											case 125:
																											case 126:
																											case 129:
																											case 132:
																												goto end_IL_028d;
																											case 13:
																											case 23:
																											case 43:
																											case 52:
																											case 53:
																											case 56:
																											case 61:
																											case 75:
																											case 83:
																											case 98:
																											case 103:
																											case 111:
																											case 114:
																											case 115:
																											case 127:
																											case 133:
																											case 134:
																											case 147:
																												goto end_IL_0310;
																											case 10:
																												goto end_IL_08cb;
																											case 41:
																												goto end_IL_08de;
																											case 108:
																												goto end_IL_08e8;
																											case 124:
																												goto end_IL_08f3;
																											case 27:
																											case 48:
																												goto end_IL_090c;
																											case 7:
																												goto end_IL_091c;
																											case 45:
																											case 137:
																												goto end_IL_092c;
																											case 38:
																												goto end_IL_093c;
																											case 39:
																												goto end_IL_0955;
																											case 49:
																											case 123:
																												goto IL_0970;
																											}
																											continue;
																											end_IL_028d:
																											break;
																										}
																										break;
																									}
																									goto IL_04b8;
																									IL_04b8:
																									if (15 > b)
																									{
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_04cb;
																							IL_0573:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_0310;
																							IL_04cb:
																							if (14 > b)
																							{
																								goto IL_04d9;
																							}
																							goto IL_0573;
																							IL_04d9:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_04e7;
																							IL_04e7:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_04f5;
																							IL_04f5:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 112;
																							goto IL_0560;
																							IL_0560:
																							num6 -= 2;
																							goto end_IL_0310;
																						}
																						break;
																					}
																					goto IL_031b;
																					IL_04a5:
																					num6--;
																					goto end_IL_0310;
																					IL_031b:
																					if (12 > b)
																					{
																						goto IL_0329;
																					}
																					goto IL_0451;
																					IL_0329:
																					if (10 < b)
																					{
																						goto IL_0334;
																					}
																					goto IL_0396;
																					IL_0334:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0342;
																					IL_0342:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0350;
																					IL_0350:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_0409;
																					IL_0409:
																					array[num6 - 2] = 0;
																					goto IL_041d;
																					IL_041d:
																					num6--;
																					goto end_IL_0310;
																					IL_0396:
																					if (10 <= b)
																					{
																						goto IL_03a4;
																					}
																					goto IL_0430;
																					IL_03a4:
																					array[num6] = 0;
																					num = 113;
																					goto IL_03bb;
																					IL_03bb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03de;
																					IL_03de:
																					array2[num6] = null;
																					goto IL_03e8;
																					IL_03e8:
																					num6++;
																					goto IL_03f6;
																					IL_03f6:
																					ptr2 += 8;
																					goto end_IL_0310;
																					IL_0430:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_043e;
																					IL_043e:
																					if (9 <= b)
																					{
																						goto end_IL_0310;
																					}
																					break;
																					IL_0451:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0491;
																					IL_0491:
																					array[num6 - 2] = 0;
																					goto IL_04a5;
																				}
																				break;
																			}
																			goto IL_058f;
																			IL_0866:
																			array[num6 - 1] = 5;
																			goto end_IL_0310;
																			IL_058f:
																			if (8 <= b)
																			{
																				goto IL_059a;
																			}
																			goto IL_05b2;
																			IL_059a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0310;
																			IL_05b2:
																			if (4 < b)
																			{
																				goto IL_05c0;
																			}
																			goto IL_0720;
																			IL_05c0:
																			if (6 < b)
																			{
																				goto IL_05cb;
																			}
																			goto IL_063a;
																			IL_05cb:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_05d9;
																			IL_05d9:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05e7;
																			IL_05e7:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0610;
																			IL_0610:
																			ptr2 += 8;
																			goto IL_061e;
																			IL_061e:
																			num6--;
																			num = 52;
																			goto end_IL_0310;
																			IL_063a:
																			if (6 > b)
																			{
																				goto IL_0645;
																			}
																			num = 36;
																			goto IL_06c5;
																			IL_0645:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0653;
																			IL_0653:
																			if (5 > b)
																			{
																				num = 17;
																				break;
																			}
																			goto IL_065e;
																			IL_065e:
																			array[num6] = 5;
																			goto IL_066c;
																			IL_066c:
																			array2[num6] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0684;
																			IL_0684:
																			num6++;
																			goto IL_0692;
																			IL_0692:
																			ptr2 += 8;
																			num = 83;
																			goto end_IL_0310;
																			IL_089a:
																			ptr2 += 8;
																			goto IL_08a8;
																			IL_087c:
																			array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																			goto IL_089a;
																			IL_06c5:
																			((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0704;
																			IL_0704:
																			num6 -= 3;
																			num = 127;
																			goto end_IL_0310;
																			IL_0720:
																			if (4 > b)
																			{
																				goto IL_072e;
																			}
																			goto IL_087c;
																			IL_072e:
																			if (2 >= b)
																			{
																				goto IL_073c;
																			}
																			goto IL_0824;
																			IL_073c:
																			if (2 <= b)
																			{
																				goto IL_0747;
																			}
																			goto IL_07b7;
																			IL_0747:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0787;
																			IL_0787:
																			array[num6 - 2] = 0;
																			goto IL_079b;
																			IL_079b:
																			num6--;
																			num = 75;
																			goto end_IL_0310;
																			IL_07b7:
																			if (1 < b)
																			{
																				break;
																			}
																			num = 135;
																			goto IL_07ce;
																			IL_08a8:
																			num6--;
																			goto end_IL_0310;
																			IL_07ce:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_07dc;
																			IL_07dc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_07f5;
																			IL_07f5:
																			array[num6] = 0;
																			goto IL_0803;
																			IL_0803:
																			num6++;
																			goto IL_0811;
																			IL_0811:
																			ptr2 += 8;
																			goto end_IL_0310;
																			IL_0824:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0832;
																			IL_0832:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_083d;
																			IL_083d:
																			array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																			goto IL_0866;
																		}
																		break;
																		IL_02e0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0310;
																continue;
																end_IL_02f0:
																break;
															}
															continue;
															end_IL_0300:
															break;
														}
														continue;
														end_IL_0310:
														break;
													}
													continue;
												}
												goto IL_0970;
												IL_0970:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_08cb:
												break;
											}
											continue;
											end_IL_08de:
											break;
										}
										continue;
										end_IL_08e8:
										break;
									}
									continue;
									end_IL_08f3:
									break;
								}
								continue;
								end_IL_090c:
								break;
							}
							continue;
							end_IL_091c:
							break;
						}
						continue;
						end_IL_092c:
						break;
					}
					continue;
					end_IL_093c:
					break;
				}
				continue;
				end_IL_0955:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 112;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HandleProcessCorruptedStateExceptionsAttributeHostSecurityManager.InfoSoapCatchType);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 16;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_031f:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02ff:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02ef:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_02e2:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_02d2:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_02c2:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															while (true)
																															{
																																IL_026e:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																num = 147;
																																while (true)
																																{
																																	if (num != 147)
																																	{
																																		if (num != 1128)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 9:
																																		case 137:
																																			goto IL_026e;
																																		case 45:
																																			goto IL_02a2;
																																		case 24:
																																		case 43:
																																			goto IL_02b2;
																																		case 2:
																																		case 119:
																																			goto IL_02c2;
																																		case 123:
																																			goto IL_02d2;
																																		case 1:
																																			goto IL_02e2;
																																		case 79:
																																			goto IL_02ef;
																																		case 59:
																																			goto IL_02ff;
																																		case 32:
																																			goto IL_030f;
																																		case 95:
																																			goto IL_031f;
																																		case 36:
																																			goto end_IL_031f;
																																		case 16:
																																			goto end_IL_032f;
																																		case 131:
																																			goto end_IL_033f;
																																		case 22:
																																			goto IL_0355;
																																		case 30:
																																			goto IL_0360;
																																		case 103:
																																			goto IL_0373;
																																		case 60:
																																		case 74:
																																			goto IL_0381;
																																		case 35:
																																			goto IL_038f;
																																		case 26:
																																			goto IL_03b2;
																																		case 34:
																																			goto IL_03bc;
																																		case 65:
																																			goto IL_03d3;
																																		case 110:
																																			goto IL_03ef;
																																		case 64:
																																		case 101:
																																			goto IL_03fd;
																																		case 7:
																																			goto IL_043d;
																																		case 90:
																																			goto IL_0451;
																																		case 107:
																																		case 130:
																																			goto IL_046d;
																																		case 55:
																																			goto IL_04ad;
																																		case 69:
																																			goto IL_04ca;
																																		case 3:
																																		case 135:
																																			goto IL_04dd;
																																		case 4:
																																			goto IL_04eb;
																																		case 88:
																																			goto IL_050c;
																																		case 120:
																																			goto IL_051f;
																																		case 134:
																																		case 140:
																																			goto IL_052d;
																																		case 86:
																																			goto IL_0546;
																																		case 125:
																																			goto IL_0554;
																																		case 91:
																																			goto IL_0562;
																																		case 62:
																																		case 70:
																																			goto IL_0575;
																																		case 127:
																																			goto IL_0596;
																																		case 0:
																																			goto IL_05a4;
																																		case 20:
																																			goto IL_05b2;
																																		case 106:
																																			goto IL_05c0;
																																		case 23:
																																		case 39:
																																			goto IL_05cb;
																																		case 108:
																																			goto IL_062d;
																																		case 92:
																																			goto IL_0640;
																																		case 54:
																																			goto IL_064e;
																																		case 5:
																																		case 83:
																																			goto end_IL_025b;
																																		case 96:
																																			goto IL_067f;
																																		case 37:
																																			goto IL_068d;
																																		case 49:
																																			goto IL_069b;
																																		case 105:
																																			goto IL_06ae;
																																		case 17:
																																			goto IL_06bc;
																																		case 10:
																																		case 85:
																																			goto IL_06ca;
																																		case 68:
																																			goto IL_070a;
																																		case 38:
																																			goto IL_071e;
																																		case 21:
																																		case 53:
																																			goto IL_073a;
																																		case 11:
																																			goto IL_074e;
																																		case 104:
																																			goto IL_07a2;
																																		case 15:
																																			goto IL_07b0;
																																		case 14:
																																			goto IL_07c3;
																																		case 8:
																																		case 114:
																																			goto IL_07ce;
																																		case 33:
																																			goto IL_07d9;
																																		case 132:
																																			goto IL_07e6;
																																		case 84:
																																		case 115:
																																			goto IL_07f1;
																																		case 19:
																																			goto IL_080a;
																																		case 78:
																																			goto IL_0815;
																																		case 66:
																																		case 102:
																																			goto IL_0820;
																																		case 6:
																																		case 12:
																																		case 27:
																																		case 29:
																																		case 31:
																																		case 41:
																																		case 42:
																																		case 47:
																																		case 50:
																																		case 61:
																																		case 63:
																																		case 67:
																																		case 72:
																																		case 73:
																																		case 80:
																																		case 81:
																																		case 87:
																																		case 89:
																																		case 93:
																																		case 97:
																																		case 98:
																																		case 100:
																																		case 111:
																																		case 116:
																																		case 118:
																																		case 121:
																																		case 122:
																																		case 126:
																																		case 136:
																																			goto end_IL_02a2;
																																		case 13:
																																		case 40:
																																		case 44:
																																		case 46:
																																		case 48:
																																		case 51:
																																		case 52:
																																		case 58:
																																		case 77:
																																		case 82:
																																		case 94:
																																		case 109:
																																		case 117:
																																		case 124:
																																		case 129:
																																		case 133:
																																		case 138:
																																			goto end_IL_034a;
																																		case 139:
																																			goto end_IL_0843;
																																		case 25:
																																			goto end_IL_0856;
																																		case 99:
																																			goto end_IL_0860;
																																		case 76:
																																			goto end_IL_086b;
																																		case 28:
																																		case 71:
																																			goto end_IL_0880;
																																		case 112:
																																			goto end_IL_0890;
																																		case 75:
																																		case 128:
																																			goto end_IL_08a0;
																																		case 56:
																																			goto end_IL_08b0;
																																		case 57:
																																			goto end_IL_08c9;
																																		case 18:
																																		case 113:
																																			goto IL_08e4;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto IL_050c;
																																	IL_050c:
																																	num5--;
																																	goto end_IL_034a;
																																	continue;
																																	end_IL_025b:
																																	break;
																																}
																																break;
																															}
																															goto IL_065c;
																															continue;
																															end_IL_02a2:
																															break;
																															IL_02a2:;
																														}
																														break;
																														IL_02b2:;
																													}
																													break;
																												}
																												goto IL_051f;
																												IL_0562:
																												ptr2 += 8;
																												goto end_IL_034a;
																												IL_051f:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_052d;
																												IL_052d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0546;
																												IL_0546:
																												array[num5] = 0;
																												goto IL_0554;
																												IL_0554:
																												num5++;
																												goto IL_0562;
																											}
																											break;
																										}
																										goto IL_0575;
																										IL_0575:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										num = 133;
																										goto end_IL_034a;
																									}
																									break;
																								}
																								goto IL_0355;
																								IL_04eb:
																								if (4 <= b)
																								{
																									goto end_IL_034a;
																								}
																								break;
																								IL_0355:
																								if (5 < b)
																								{
																									goto IL_0360;
																								}
																								goto IL_0373;
																								IL_0360:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_03ef;
																								IL_03ef:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_03fd;
																								IL_03fd:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_043d;
																								IL_043d:
																								array[num5 - 2] = 0;
																								goto IL_0451;
																								IL_0451:
																								num5--;
																								num = 51;
																								goto end_IL_034a;
																								IL_0373:
																								if (5 <= b)
																								{
																									goto IL_0381;
																								}
																								goto IL_04dd;
																								IL_0381:
																								array[num5] = 0;
																								goto IL_038f;
																								IL_038f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03b2;
																								IL_03b2:
																								array2[num5] = null;
																								goto IL_03bc;
																								IL_03bc:
																								num5++;
																								num = 65;
																								goto IL_03d3;
																								IL_03d3:
																								ptr2 += 8;
																								num = 124;
																								goto end_IL_034a;
																								IL_04dd:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_04eb;
																							}
																							break;
																						}
																						goto IL_046d;
																						IL_04ca:
																						num5--;
																						goto end_IL_034a;
																						IL_046d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04ad;
																						IL_04ad:
																						array[num5 - 2] = 0;
																						num = 69;
																						goto IL_04ca;
																					}
																					break;
																				}
																				goto IL_0596;
																				IL_0815:
																				if (12 > b)
																				{
																					break;
																				}
																				goto IL_0820;
																				IL_0596:
																				if (11 >= b)
																				{
																					goto IL_05a4;
																				}
																				goto IL_07c3;
																				IL_05a4:
																				if (11 > b)
																				{
																					goto IL_05b2;
																				}
																				num = 53;
																				goto IL_073a;
																				IL_05b2:
																				if (9 >= b)
																				{
																					goto IL_05c0;
																				}
																				goto IL_06ae;
																				IL_05c0:
																				if (9 <= b)
																				{
																					goto IL_05cb;
																				}
																				goto IL_0640;
																				IL_05cb:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_062d;
																				IL_062d:
																				num5 -= 2;
																				goto end_IL_034a;
																				IL_0640:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_064e;
																				IL_064e:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_065c;
																				IL_065c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_067f;
																				IL_067f:
																				array[num5] = 0;
																				goto IL_068d;
																				IL_068d:
																				num5++;
																				goto IL_069b;
																				IL_069b:
																				ptr2 += 8;
																				goto end_IL_034a;
																				IL_06ae:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_06bc;
																				IL_06bc:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_06ca;
																				IL_06ca:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_070a;
																				IL_070a:
																				array[num5 - 2] = 0;
																				goto IL_071e;
																				IL_071e:
																				num5--;
																				goto end_IL_034a;
																				IL_0820:
																				num5--;
																				goto end_IL_034a;
																				IL_073a:
																				array[num5 - 2] = 0;
																				goto IL_074e;
																				IL_074e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getSignatureCreateDefaultTypeInfo[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_07a2;
																				IL_07a2:
																				num5--;
																				goto IL_07b0;
																				IL_07b0:
																				ptr2 += 8;
																				goto end_IL_034a;
																				IL_07c3:
																				if (13 < b)
																				{
																					goto IL_07ce;
																				}
																				goto IL_07e6;
																				IL_07ce:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_07d9;
																				IL_07d9:
																				if (14 <= b)
																				{
																				}
																				break;
																				IL_07e6:
																				if (13 <= b)
																				{
																					goto IL_07f1;
																				}
																				goto IL_080a;
																				IL_07f1:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_034a;
																				IL_080a:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_0815;
																			}
																			break;
																			IL_030f:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_034a;
																	continue;
																	end_IL_031f:
																	break;
																}
																continue;
																end_IL_032f:
																break;
															}
															continue;
															end_IL_033f:
															break;
														}
														continue;
														end_IL_034a:
														break;
													}
													continue;
												}
												goto IL_08e4;
												IL_08e4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0843:
												break;
											}
											continue;
											end_IL_0856:
											break;
										}
										continue;
										end_IL_0860:
										break;
									}
									continue;
									end_IL_086b:
									break;
								}
								continue;
								end_IL_0880:
								break;
							}
							continue;
							end_IL_0890:
							break;
						}
						continue;
						end_IL_08a0:
						break;
					}
					continue;
					end_IL_08b0:
					break;
				}
				continue;
				end_IL_08c9:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SyncIListStandardDate.AddArgumentsReleaseApplicationPath);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 18;
																while (true)
																{
																	IL_0285:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						if (5 > b)
																						{
																							while (true)
																							{
																								if (2 >= b)
																								{
																									while (true)
																									{
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01f9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01da:
																													array[num5 - 2] = 0;
																													num = 110;
																													while (true)
																													{
																														if (num != 110)
																														{
																															if (num != 1091)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 51:
																																goto IL_01da;
																															case 15:
																															case 68:
																																goto IL_01f9;
																															case 45:
																																goto end_IL_01c7;
																															case 96:
																																goto end_IL_023b;
																															case 72:
																																goto end_IL_0248;
																															case 29:
																																goto end_IL_0258;
																															case 70:
																																goto end_IL_0265;
																															case 18:
																																goto IL_0285;
																															case 58:
																																goto end_IL_0285;
																															case 54:
																															case 67:
																																goto end_IL_0295;
																															case 4:
																															case 49:
																																goto IL_02b9;
																															case 16:
																															case 69:
																																goto IL_02c9;
																															case 12:
																																goto IL_02d7;
																															case 40:
																																goto IL_02fa;
																															case 21:
																																goto IL_0304;
																															case 24:
																																goto IL_0312;
																															case 71:
																																goto IL_0325;
																															case 99:
																																goto IL_034b;
																															case 63:
																																goto IL_0356;
																															case 10:
																															case 93:
																																goto IL_0364;
																															case 90:
																																goto IL_038d;
																															case 6:
																																goto IL_039b;
																															case 89:
																																goto IL_03ae;
																															case 77:
																																goto IL_03bc;
																															case 0:
																															case 38:
																																goto IL_03ca;
																															case 92:
																																goto IL_040a;
																															case 97:
																																goto IL_041e;
																															case 61:
																																goto IL_0431;
																															case 22:
																															case 34:
																																goto IL_043f;
																															case 47:
																																goto IL_044a;
																															case 19:
																															case 37:
																																goto IL_0458;
																															case 1:
																																goto IL_0498;
																															case 85:
																																goto IL_04ac;
																															case 39:
																																goto IL_04bf;
																															case 9:
																																goto IL_04d8;
																															case 2:
																															case 13:
																																goto IL_04e6;
																															case 52:
																																goto IL_0502;
																															case 26:
																															case 57:
																																goto IL_050d;
																															case 87:
																																goto IL_0526;
																															case 98:
																																goto IL_0534;
																															case 100:
																																goto IL_054b;
																															case 3:
																															case 25:
																																goto IL_055e;
																															case 60:
																																goto IL_0569;
																															case 36:
																															case 65:
																																goto IL_0574;
																															case 59:
																																goto IL_05b4;
																															case 55:
																																goto IL_05c8;
																															case 11:
																															case 14:
																															case 17:
																															case 30:
																															case 31:
																															case 35:
																															case 46:
																															case 53:
																															case 56:
																															case 62:
																															case 74:
																															case 79:
																															case 80:
																															case 84:
																															case 86:
																															case 88:
																															case 94:
																															case 102:
																																goto end_IL_0275;
																															case 78:
																																goto IL_05fb;
																															case 64:
																																goto IL_0612;
																															case 75:
																																goto IL_0620;
																															case 5:
																															case 7:
																															case 8:
																															case 23:
																															case 27:
																															case 28:
																															case 50:
																															case 66:
																															case 81:
																															case 95:
																															case 101:
																																goto end_IL_02ae;
																															case 73:
																																goto end_IL_062e;
																															case 44:
																																goto end_IL_0641;
																															case 91:
																																goto end_IL_064b;
																															case 48:
																																goto end_IL_0656;
																															case 83:
																																goto end_IL_066b;
																															case 32:
																															case 33:
																																goto end_IL_0680;
																															case 43:
																																goto end_IL_0690;
																															case 76:
																															case 103:
																																goto end_IL_06a0;
																															case 41:
																																goto end_IL_06b0;
																															case 42:
																																goto end_IL_06c0;
																															case 20:
																															case 82:
																																goto IL_06db;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02ae;
																														continue;
																														end_IL_01c7:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											continue;
																										}
																										goto IL_02b9;
																										IL_0325:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_0275;
																										IL_02b9:
																										if (1 < b)
																										{
																											goto end_IL_0275;
																										}
																										goto IL_0325;
																										continue;
																										end_IL_023b:
																										break;
																									}
																									continue;
																								}
																								goto IL_034b;
																								IL_041e:
																								num5--;
																								goto end_IL_02ae;
																								IL_034b:
																								if (3 >= b)
																								{
																									goto IL_0356;
																								}
																								goto IL_03ae;
																								IL_0356:
																								if (3 > b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_0364;
																								IL_0364:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_038d;
																								IL_038d:
																								ptr2 += 8;
																								goto IL_039b;
																								IL_039b:
																								num5--;
																								goto end_IL_02ae;
																								IL_03ae:
																								if (4 < b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_03bc;
																								IL_03bc:
																								if (4 > b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_03ca;
																								IL_03ca:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_040a;
																								IL_040a:
																								array[num5 - 2] = 0;
																								goto IL_041e;
																								continue;
																								end_IL_0248:
																								break;
																							}
																							continue;
																						}
																						goto IL_02c9;
																						IL_0312:
																						ptr2 += 8;
																						goto end_IL_02ae;
																						IL_02c9:
																						array[num5] = 0;
																						goto IL_02d7;
																						IL_02d7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02fa;
																						IL_02fa:
																						array2[num5] = null;
																						goto IL_0304;
																						IL_0304:
																						num5++;
																						goto IL_0312;
																						continue;
																						end_IL_0258:
																						break;
																					}
																					continue;
																				}
																				goto IL_0431;
																				IL_05b4:
																				array[num5 - 2] = 0;
																				goto IL_05c8;
																				IL_0431:
																				if (7 < b)
																				{
																					goto IL_043f;
																				}
																				goto IL_0502;
																				IL_043f:
																				if (8 >= b)
																				{
																					goto IL_044a;
																				}
																				goto IL_04bf;
																				IL_044a:
																				if (8 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_0458;
																				IL_0458:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0498;
																				IL_0498:
																				array[num5 - 2] = 0;
																				goto IL_04ac;
																				IL_04ac:
																				num5--;
																				goto end_IL_02ae;
																				IL_04bf:
																				if (9 < b)
																				{
																					num = 35;
																					goto end_IL_0275;
																				}
																				goto IL_04d8;
																				IL_05c8:
																				num5--;
																				goto end_IL_02ae;
																				IL_04d8:
																				if (9 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_04e6;
																				IL_04e6:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ae;
																				IL_0502:
																				if (7 <= b)
																				{
																					goto IL_050d;
																				}
																				goto IL_055e;
																				IL_050d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0526;
																				IL_0526:
																				array[num5] = 0;
																				goto IL_0534;
																				IL_0534:
																				num5++;
																				num = 100;
																				goto IL_054b;
																				IL_054b:
																				ptr2 += 8;
																				goto end_IL_02ae;
																				IL_055e:
																				if (6 < b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_0569;
																				IL_0569:
																				if (6 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_0574;
																				IL_0574:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05b4;
																				continue;
																				end_IL_0265:
																				break;
																			}
																			continue;
																			end_IL_0275:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05fb;
																	IL_0620:
																	ptr2 += 8;
																	goto end_IL_02ae;
																	IL_0612:
																	num5++;
																	goto IL_0620;
																	IL_05fb:
																	array[num5] = 0;
																	num = 64;
																	goto IL_0612;
																	continue;
																	end_IL_0285:
																	break;
																}
																continue;
																end_IL_0295:
																break;
															}
															continue;
															end_IL_02ae:
															break;
														}
														continue;
													}
													goto IL_06db;
													IL_06db:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_064b:
											break;
										}
										continue;
										end_IL_0656:
										break;
									}
									continue;
									end_IL_066b:
									break;
								}
								continue;
								end_IL_0680:
								break;
							}
							continue;
							end_IL_0690:
							break;
						}
						continue;
						end_IL_06a0:
						break;
					}
					continue;
					end_IL_06b0:
					break;
				}
				continue;
				end_IL_06c0:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 106;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 72;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCurrentTimeZoneIteratorToEnumeratorAdapter.HashDefinitionEventFieldTags);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c8:
															byte b = *ptr2;
															while (true)
															{
																IL_02b8:
																ptr2++;
																while (true)
																{
																	IL_02a8:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_028b:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_027b:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_026b:
																								if (8 >= b)
																								{
																									while (8 <= b)
																									{
																										while (true)
																										{
																											IL_0219:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_0203:
																												array[num5 - 2] = 0;
																												while (true)
																												{
																													IL_01ea:
																													num5--;
																													num = 114;
																													while (num != 114)
																													{
																														if (num != 1095)
																														{
																															goto end_IL_025b;
																														}
																														switch (num)
																														{
																														case 24:
																															goto IL_01ea;
																														case 41:
																															goto IL_0203;
																														case 43:
																														case 55:
																															goto IL_0219;
																														case 3:
																															goto IL_025b;
																														case 52:
																														case 54:
																															goto IL_026b;
																														case 73:
																															goto IL_027b;
																														case 35:
																															goto IL_028b;
																														case 4:
																															goto IL_0298;
																														case 82:
																															goto IL_02a8;
																														case 1:
																															goto IL_02b8;
																														case 61:
																														case 103:
																															goto IL_02c8;
																														case 30:
																															goto IL_02d3;
																														case 5:
																														case 90:
																															goto IL_02e1;
																														case 77:
																															goto IL_02ec;
																														case 7:
																														case 15:
																															goto IL_02fa;
																														case 13:
																															goto IL_0308;
																														case 16:
																														case 31:
																															goto IL_0324;
																														case 11:
																															goto IL_032f;
																														case 58:
																															goto IL_0342;
																														case 68:
																															goto IL_0350;
																														case 65:
																														case 91:
																															goto IL_0367;
																														case 53:
																															goto IL_03a7;
																														case 33:
																															goto IL_03bb;
																														case 39:
																														case 93:
																															goto IL_03ce;
																														case 78:
																															goto IL_03dc;
																														case 44:
																														case 96:
																															goto IL_0401;
																														case 40:
																															goto IL_0441;
																														case 17:
																															goto IL_0455;
																														case 101:
																															goto IL_0468;
																														case 38:
																															goto IL_047b;
																														case 57:
																															goto IL_0489;
																														case 81:
																														case 102:
																															goto IL_049c;
																														case 9:
																															goto IL_04c5;
																														case 20:
																															goto IL_04d3;
																														case 76:
																															goto IL_04e6;
																														case 88:
																															goto IL_04f4;
																														case 27:
																														case 85:
																															goto IL_0502;
																														case 48:
																															goto IL_051e;
																														case 56:
																														case 64:
																															goto IL_052c;
																														case 104:
																															goto IL_053a;
																														case 18:
																														case 92:
																															goto IL_0548;
																														case 28:
																															goto IL_0588;
																														case 89:
																															goto IL_05a5;
																														case 2:
																														case 59:
																															goto IL_05b8;
																														case 22:
																															goto IL_05d1;
																														case 29:
																															goto IL_05df;
																														case 75:
																															goto IL_05ed;
																														case 0:
																														case 10:
																														case 12:
																														case 25:
																														case 26:
																														case 37:
																														case 46:
																														case 50:
																														case 51:
																														case 60:
																														case 63:
																														case 74:
																														case 80:
																														case 83:
																														case 86:
																														case 87:
																														case 94:
																														case 98:
																														case 100:
																														case 105:
																															goto end_IL_025b;
																														case 23:
																															goto IL_0629;
																														case 84:
																															goto IL_0637;
																														case 6:
																															goto IL_0645;
																														case 8:
																														case 21:
																														case 42:
																														case 45:
																														case 47:
																														case 49:
																														case 62:
																														case 66:
																														case 95:
																														case 97:
																															goto end_IL_01d7;
																														case 99:
																															goto end_IL_0653;
																														case 19:
																															goto end_IL_0666;
																														case 14:
																															goto end_IL_0670;
																														case 79:
																															goto end_IL_067b;
																														case 71:
																															goto end_IL_0690;
																														case 32:
																														case 36:
																															goto end_IL_06a5;
																														case 72:
																															goto end_IL_06b5;
																														case 67:
																														case 69:
																															goto end_IL_06c5;
																														case 106:
																															goto end_IL_06d5;
																														case 107:
																															goto end_IL_06ee;
																														case 34:
																														case 70:
																															goto IL_0712;
																														}
																														continue;
																														end_IL_01d7:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_02a8;
																										continue;
																										end_IL_025b:
																										break;
																										IL_025b:;
																									}
																									break;
																								}
																								goto IL_04e6;
																								IL_0502:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_02a8;
																								IL_04e6:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_04f4;
																								IL_04f4:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0502;
																							}
																							break;
																						}
																						goto IL_051e;
																						IL_05ed:
																						ptr2 += 8;
																						goto end_IL_02a8;
																						IL_051e:
																						if (7 > b)
																						{
																							goto IL_052c;
																						}
																						goto IL_05b8;
																						IL_052c:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_053a;
																						IL_053a:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0548;
																						IL_0548:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0588;
																						IL_0588:
																						array[num5 - 2] = 0;
																						num = 89;
																						goto IL_05a5;
																						IL_05a5:
																						num5--;
																						goto end_IL_02a8;
																						IL_05b8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_05d1;
																						IL_05d1:
																						array[num5] = 0;
																						goto IL_05df;
																						IL_05df:
																						num5++;
																						goto IL_05ed;
																					}
																					break;
																				}
																				goto IL_02d3;
																				IL_0468:
																				array2[num5] = null;
																				num = 38;
																				goto IL_047b;
																				IL_02d3:
																				if (5 > b)
																				{
																					goto IL_02e1;
																				}
																				goto IL_03ce;
																				IL_02e1:
																				if (2 >= b)
																				{
																					goto IL_02ec;
																				}
																				num = 16;
																				goto IL_0324;
																				IL_02ec:
																				if (2 > b)
																				{
																					goto IL_02fa;
																				}
																				goto IL_0401;
																				IL_02fa:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0308;
																				IL_0308:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0401:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0441;
																				IL_0441:
																				array[num5 - 2] = 0;
																				goto IL_0455;
																				IL_0455:
																				num5--;
																				goto end_IL_02a8;
																				IL_047b:
																				num5++;
																				goto IL_0489;
																				IL_0324:
																				if (3 >= b)
																				{
																					goto IL_032f;
																				}
																				goto IL_0342;
																				IL_032f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_049c;
																				IL_049c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c5;
																				IL_04c5:
																				ptr2 += 8;
																				goto IL_04d3;
																				IL_04d3:
																				num5--;
																				goto end_IL_02a8;
																				IL_0342:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0350;
																				IL_0350:
																				if (4 > b)
																				{
																					break;
																				}
																				num = 91;
																				goto IL_0367;
																				IL_0489:
																				ptr2 += 8;
																				goto end_IL_02a8;
																				IL_0367:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03a7;
																				IL_03a7:
																				array[num5 - 2] = 0;
																				goto IL_03bb;
																				IL_03bb:
																				num5--;
																				goto end_IL_02a8;
																				IL_03ce:
																				array[num5] = 0;
																				goto IL_03dc;
																				IL_03dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0468;
																			}
																			break;
																			IL_0298:;
																		}
																	}
																	else
																	{
																		num = 83;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0629;
																	IL_0637:
																	num5++;
																	goto IL_0645;
																	IL_0645:
																	ptr2 += 8;
																	break;
																	IL_0629:
																	array[num5] = 0;
																	goto IL_0637;
																	continue;
																	end_IL_02a8:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0712;
													IL_0712:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0653:
													break;
												}
												continue;
												end_IL_0666:
												break;
											}
											continue;
											end_IL_0670:
											break;
										}
										continue;
										end_IL_067b:
										break;
									}
									continue;
									end_IL_0690:
									break;
								}
								continue;
								end_IL_06a5:
								break;
							}
							continue;
							end_IL_06b5:
							break;
						}
						continue;
						end_IL_06c5:
						break;
					}
					continue;
					end_IL_06d5:
					break;
				}
				continue;
				end_IL_06ee:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 40;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisteredChannelSEPTime.CompressedStackSwitcherCSharp);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0324:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0307:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02f7:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02e7:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02da:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02ca:
																											if (2 < b)
																											{
																												while (3 >= b)
																												{
																													while (3 <= b)
																													{
																														while (true)
																														{
																															IL_0276:
																															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															num = 149;
																															while (true)
																															{
																																if (num != 149)
																																{
																																	if (num != 1130)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 53:
																																	case 124:
																																		goto IL_0276;
																																	case 125:
																																		goto IL_02aa;
																																	case 9:
																																		goto IL_02ba;
																																	case 72:
																																		goto IL_02ca;
																																	case 10:
																																		goto IL_02da;
																																	case 12:
																																	case 23:
																																		goto IL_02e7;
																																	case 30:
																																		goto IL_02f7;
																																	case 74:
																																		goto IL_0307;
																																	case 142:
																																		goto IL_0314;
																																	case 56:
																																		goto IL_0324;
																																	case 92:
																																		goto end_IL_0324;
																																	case 11:
																																	case 62:
																																		goto end_IL_0334;
																																	case 6:
																																	case 103:
																																		goto IL_034f;
																																	case 35:
																																		goto IL_036d;
																																	case 76:
																																		goto IL_037b;
																																	case 28:
																																	case 130:
																																		goto IL_038e;
																																	case 80:
																																	case 120:
																																		goto IL_039c;
																																	case 22:
																																		goto IL_03a7;
																																	case 38:
																																		goto IL_03b5;
																																	case 99:
																																		goto IL_03c8;
																																	case 84:
																																	case 96:
																																		goto IL_03d6;
																																	case 90:
																																		goto IL_03e4;
																																	case 70:
																																	case 106:
																																		goto IL_03f2;
																																	case 33:
																																		goto IL_0454;
																																	case 61:
																																	case 91:
																																		goto IL_0470;
																																	case 2:
																																		goto IL_048c;
																																	case 0:
																																		goto IL_049a;
																																	case 43:
																																		goto IL_04a8;
																																	case 27:
																																	case 69:
																																		goto IL_04b3;
																																	case 85:
																																		goto IL_04c1;
																																	case 67:
																																		goto IL_04e4;
																																	case 107:
																																		goto IL_04ee;
																																	case 36:
																																		goto IL_0505;
																																	case 77:
																																		goto IL_0518;
																																	case 112:
																																		goto IL_0526;
																																	case 105:
																																		goto IL_0539;
																																	case 41:
																																		goto IL_0547;
																																	case 94:
																																	case 119:
																																		goto IL_0555;
																																	case 24:
																																		goto IL_0599;
																																	case 122:
																																		goto IL_05ad;
																																	case 16:
																																	case 139:
																																		goto IL_05c0;
																																	case 93:
																																		goto IL_0600;
																																	case 44:
																																		goto IL_0614;
																																	case 118:
																																		goto IL_0640;
																																	case 89:
																																	case 95:
																																		goto IL_064b;
																																	case 65:
																																		goto IL_068b;
																																	case 113:
																																		goto IL_069f;
																																	case 101:
																																		goto IL_06b2;
																																	case 104:
																																		goto IL_06c0;
																																	case 121:
																																	case 123:
																																		goto IL_06ce;
																																	case 1:
																																		goto IL_06e7;
																																	case 108:
																																		goto end_IL_0263;
																																	case 42:
																																		goto IL_0703;
																																	case 137:
																																		goto IL_0716;
																																	case 4:
																																		goto IL_0724;
																																	case 5:
																																	case 19:
																																		goto IL_072f;
																																	case 129:
																																		goto IL_0777;
																																	case 115:
																																		goto IL_078a;
																																	case 32:
																																		goto IL_0795;
																																	case 55:
																																	case 81:
																																		goto IL_07a3;
																																	case 140:
																																		goto IL_07b1;
																																	case 59:
																																		goto IL_07c9;
																																	case 114:
																																		goto IL_07d7;
																																	case 117:
																																		goto IL_07f5;
																																	case 31:
																																		goto IL_0800;
																																	case 111:
																																	case 128:
																																		goto IL_080b;
																																	case 135:
																																		goto IL_0834;
																																	case 127:
																																		goto IL_0842;
																																	case 25:
																																	case 126:
																																		goto IL_0852;
																																	case 3:
																																	case 8:
																																	case 13:
																																	case 14:
																																	case 17:
																																	case 18:
																																	case 26:
																																	case 34:
																																	case 37:
																																	case 45:
																																	case 46:
																																	case 51:
																																	case 52:
																																	case 58:
																																	case 60:
																																	case 63:
																																	case 64:
																																	case 73:
																																	case 75:
																																	case 97:
																																	case 109:
																																	case 131:
																																	case 132:
																																	case 133:
																																	case 141:
																																		goto end_IL_02aa;
																																	case 7:
																																	case 15:
																																	case 20:
																																	case 21:
																																	case 29:
																																	case 47:
																																	case 49:
																																	case 50:
																																	case 54:
																																	case 57:
																																	case 71:
																																	case 82:
																																	case 83:
																																	case 86:
																																	case 87:
																																	case 110:
																																	case 116:
																																	case 136:
																																		goto end_IL_0344;
																																	case 39:
																																		goto end_IL_087a;
																																	case 68:
																																		goto end_IL_088d;
																																	case 40:
																																		goto end_IL_0897;
																																	case 66:
																																		goto end_IL_08a2;
																																	case 48:
																																	case 138:
																																		goto end_IL_08b2;
																																	case 102:
																																		goto end_IL_08cb;
																																	case 88:
																																	case 100:
																																		goto end_IL_08db;
																																	case 78:
																																		goto end_IL_08eb;
																																	case 79:
																																		goto end_IL_08fb;
																																	case 98:
																																	case 134:
																																		goto IL_0916;
																																	}
																																	continue;
																																}
																																array[num5 - 1] = 5;
																																goto end_IL_0344;
																																continue;
																																end_IL_0263:
																																break;
																															}
																															break;
																														}
																														goto IL_06f5;
																														continue;
																														end_IL_02aa:
																														break;
																														IL_02aa:;
																													}
																													break;
																													IL_02ba:;
																												}
																												break;
																											}
																											goto IL_0640;
																											IL_0703:
																											ptr2 += 8;
																											goto end_IL_0344;
																											IL_0640:
																											if (2 <= b)
																											{
																												goto IL_064b;
																											}
																											goto IL_06b2;
																											IL_064b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_068b;
																											IL_068b:
																											array[num5 - 2] = 0;
																											goto IL_069f;
																											IL_069f:
																											num5--;
																											goto end_IL_0344;
																											IL_06b2:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_06c0;
																											IL_06c0:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_06ce;
																											IL_06ce:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_06e7;
																											IL_06e7:
																											array[num5] = 0;
																											goto IL_06f5;
																											IL_06f5:
																											num5++;
																											goto IL_0703;
																										}
																										break;
																									}
																									goto IL_034f;
																									IL_037b:
																									num5--;
																									goto end_IL_0344;
																									IL_034f:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_036d;
																									IL_036d:
																									ptr2 += 8;
																									goto IL_037b;
																								}
																								break;
																							}
																							goto IL_0716;
																							IL_0834:
																							ptr2 += 8;
																							goto IL_0842;
																							IL_0716:
																							if (6 >= b)
																							{
																								goto IL_0724;
																							}
																							goto IL_07f5;
																							IL_0724:
																							if (6 <= b)
																							{
																								goto IL_072f;
																							}
																							goto IL_078a;
																							IL_072f:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 129;
																							goto IL_0777;
																							IL_0777:
																							num5 -= 3;
																							goto end_IL_0344;
																							IL_078a:
																							if (5 < b)
																							{
																								num = 13;
																								break;
																							}
																							goto IL_0795;
																							IL_0795:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_07a3;
																							IL_07a3:
																							array[num5] = 5;
																							goto IL_07b1;
																							IL_07b1:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_07c9;
																							IL_07c9:
																							num5++;
																							goto IL_07d7;
																							IL_07d7:
																							ptr2 += 8;
																							goto end_IL_0344;
																							IL_0842:
																							num5--;
																							goto end_IL_0344;
																							IL_07f5:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0800;
																							IL_0800:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_080b;
																							IL_080b:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0834;
																						}
																						break;
																					}
																					goto IL_0852;
																					IL_0852:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0344;
																				}
																				break;
																			}
																			goto IL_038e;
																			IL_0614:
																			num5--;
																			goto end_IL_0344;
																			IL_038e:
																			if (12 < b)
																			{
																				goto IL_039c;
																			}
																			goto IL_048c;
																			IL_039c:
																			if (14 < b)
																			{
																				goto IL_03a7;
																			}
																			goto IL_03c8;
																			IL_03a7:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_03b5;
																			IL_03b5:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_03c8:
																			if (14 > b)
																			{
																				goto IL_03d6;
																			}
																			goto IL_0470;
																			IL_03d6:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_03e4;
																			IL_03e4:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_03f2;
																			IL_03f2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0454;
																			IL_0454:
																			num5 -= 2;
																			num = 7;
																			goto end_IL_0344;
																			IL_0470:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0344;
																			IL_048c:
																			if (12 > b)
																			{
																				goto IL_049a;
																			}
																			goto IL_05c0;
																			IL_049a:
																			if (10 >= b)
																			{
																				goto IL_04a8;
																			}
																			goto IL_0539;
																			IL_04a8:
																			if (10 <= b)
																			{
																				goto IL_04b3;
																			}
																			goto IL_0518;
																			IL_04b3:
																			array[num5] = 0;
																			goto IL_04c1;
																			IL_04c1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04e4;
																			IL_04e4:
																			array2[num5] = null;
																			goto IL_04ee;
																			IL_04ee:
																			num5++;
																			num = 36;
																			goto IL_0505;
																			IL_0505:
																			ptr2 += 8;
																			goto end_IL_0344;
																			IL_0518:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0526;
																			IL_0526:
																			if (9 <= b)
																			{
																				goto end_IL_0344;
																			}
																			break;
																			IL_0539:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0547;
																			IL_0547:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0555;
																			IL_0555:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0599;
																			IL_0599:
																			array[num5 - 2] = 0;
																			goto IL_05ad;
																			IL_05ad:
																			num5--;
																			goto end_IL_0344;
																			IL_05c0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0600;
																			IL_0600:
																			array[num5 - 2] = 0;
																			goto IL_0614;
																		}
																		break;
																		IL_0314:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0344;
																continue;
																end_IL_0324:
																break;
															}
															continue;
															end_IL_0334:
															break;
														}
														continue;
														end_IL_0344:
														break;
													}
													continue;
												}
												goto IL_0916;
												IL_0916:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_087a:
												break;
											}
											continue;
											end_IL_088d:
											break;
										}
										continue;
										end_IL_0897:
										break;
									}
									continue;
									end_IL_08a2:
									break;
								}
								continue;
								end_IL_08b2:
								break;
							}
							continue;
							end_IL_08cb:
							break;
						}
						continue;
						end_IL_08db:
						break;
					}
					continue;
					end_IL_08eb:
					break;
				}
				continue;
				end_IL_08fb:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 33;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ETWSafeWaitHandle.WriteIntPtrgetBuffer);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02bd:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_029a:
																				if (5 < b)
																				{
																					num = 13;
																					while (true)
																					{
																						IL_028d:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_027d:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_021b:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01fc:
																													array[num5 - 2] = 0;
																													num = 115;
																													while (true)
																													{
																														if (num != 115)
																														{
																															if (num != 1096)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 82:
																																goto IL_01fc;
																															case 65:
																															case 98:
																																goto IL_021b;
																															case 62:
																																goto IL_025d;
																															case 18:
																																goto IL_026d;
																															case 78:
																																goto IL_027d;
																															case 13:
																															case 41:
																																goto IL_028d;
																															case 24:
																																goto IL_029a;
																															case 35:
																																goto IL_02ad;
																															case 37:
																																goto IL_02bd;
																															case 63:
																																goto end_IL_02bd;
																															case 92:
																															case 105:
																																goto end_IL_02cd;
																															case 1:
																															case 39:
																																goto IL_02e8;
																															case 71:
																																goto IL_02f6;
																															case 25:
																															case 29:
																																goto IL_0304;
																															case 16:
																																goto IL_0344;
																															case 57:
																																goto IL_0358;
																															case 83:
																																goto IL_036b;
																															case 8:
																															case 79:
																																goto IL_0379;
																															case 48:
																																goto IL_0387;
																															case 7:
																																goto IL_03aa;
																															case 55:
																																goto IL_03b4;
																															case 26:
																															case 96:
																																goto IL_03c4;
																															case 9:
																																goto IL_03d2;
																															case 23:
																															case 38:
																																goto IL_03e0;
																															case 97:
																																goto IL_03fc;
																															case 61:
																															case 100:
																																goto IL_040f;
																															case 15:
																															case 51:
																																goto IL_041a;
																															case 49:
																															case 54:
																																goto IL_0431;
																															case 94:
																																goto IL_043f;
																															case 12:
																															case 31:
																																goto IL_044d;
																															case 6:
																																goto IL_048f;
																															case 30:
																															case 80:
																																goto IL_049d;
																															case 103:
																																goto end_IL_01e9;
																															case 87:
																																goto IL_04ff;
																															case 106:
																																goto IL_0512;
																															case 91:
																															case 95:
																																goto IL_0520;
																															case 60:
																																goto IL_0552;
																															case 4:
																																goto IL_0560;
																															case 22:
																															case 107:
																																goto IL_0573;
																															case 44:
																																goto IL_0581;
																															case 108:
																																goto IL_0594;
																															case 28:
																																goto IL_05a8;
																															case 19:
																															case 104:
																																goto IL_05d7;
																															case 64:
																																goto IL_05f0;
																															case 93:
																																goto IL_05fe;
																															case 59:
																																goto IL_060c;
																															case 3:
																															case 5:
																															case 17:
																															case 27:
																															case 32:
																															case 43:
																															case 45:
																															case 53:
																															case 58:
																															case 67:
																															case 69:
																															case 72:
																															case 73:
																															case 74:
																															case 76:
																															case 81:
																															case 86:
																															case 89:
																															case 102:
																																goto end_IL_025d;
																															case 11:
																																goto IL_0648;
																															case 2:
																																goto IL_0656;
																															case 10:
																																goto IL_066d;
																															case 0:
																															case 20:
																															case 21:
																															case 36:
																															case 68:
																															case 84:
																															case 85:
																															case 88:
																															case 90:
																															case 99:
																															case 101:
																																goto end_IL_02dd;
																															case 47:
																																goto end_IL_067b;
																															case 77:
																																goto end_IL_068e;
																															case 52:
																																goto end_IL_0698;
																															case 46:
																																goto end_IL_06a3;
																															case 66:
																																goto end_IL_06b8;
																															case 50:
																															case 75:
																																goto end_IL_06cd;
																															case 56:
																																goto end_IL_06dd;
																															case 40:
																															case 42:
																																goto end_IL_06ed;
																															case 33:
																																goto end_IL_06fd;
																															case 34:
																																goto end_IL_070d;
																															case 14:
																															case 70:
																																goto IL_0731;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02dd;
																														continue;
																														end_IL_01e9:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_04eb;
																											continue;
																											end_IL_025d:
																											break;
																											IL_025d:;
																										}
																										break;
																										IL_026d:;
																									}
																									break;
																								}
																								goto IL_05d7;
																								IL_060c:
																								ptr2 += 8;
																								num = 99;
																								goto end_IL_02dd;
																								IL_05d7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_05f0;
																								IL_05f0:
																								array[num5] = 0;
																								goto IL_05fe;
																								IL_05fe:
																								num5++;
																								goto IL_060c;
																							}
																							break;
																						}
																						goto IL_02e8;
																						IL_03e0:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02dd;
																						IL_02e8:
																						if (8 >= b)
																						{
																							goto IL_02f6;
																						}
																						goto IL_03c4;
																						IL_02f6:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0304;
																						IL_0304:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0344;
																						IL_0344:
																						array[num5 - 2] = 0;
																						goto IL_0358;
																						IL_0358:
																						num5--;
																						goto end_IL_02dd;
																						IL_03c4:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_03d2;
																						IL_03d2:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_03e0;
																					}
																					break;
																				}
																				goto IL_036b;
																				IL_05a8:
																				num5--;
																				num = 68;
																				goto end_IL_02dd;
																				IL_0573:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0581;
																				IL_036b:
																				if (5 <= b)
																				{
																					goto IL_0379;
																				}
																				goto IL_040f;
																				IL_0379:
																				array[num5] = 0;
																				goto IL_0387;
																				IL_0387:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03aa;
																				IL_03aa:
																				array2[num5] = null;
																				goto IL_03b4;
																				IL_03b4:
																				num5++;
																				goto IL_03fc;
																				IL_03fc:
																				ptr2 += 8;
																				goto end_IL_02dd;
																				IL_040f:
																				if (2 < b)
																				{
																					goto IL_041a;
																				}
																				goto IL_048f;
																				IL_041a:
																				if (3 < b)
																				{
																					num = 54;
																					goto IL_0431;
																				}
																				goto IL_0512;
																				IL_0581:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0431:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_043f;
																				IL_043f:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_044d;
																				IL_044d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04eb;
																				IL_04eb:
																				array[num5 - 2] = 0;
																				goto IL_04ff;
																				IL_04ff:
																				num5--;
																				goto end_IL_02dd;
																				IL_0512:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0520;
																				IL_0520:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 60;
																				goto IL_0552;
																				IL_0552:
																				ptr2 += 8;
																				goto IL_0560;
																				IL_0560:
																				num5--;
																				goto end_IL_02dd;
																				IL_048f:
																				if (2 <= b)
																				{
																					goto IL_049d;
																				}
																				goto IL_0573;
																				IL_049d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 108;
																				goto IL_0594;
																				IL_0594:
																				array[num5 - 2] = 0;
																				goto IL_05a8;
																			}
																			break;
																			IL_02ad:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0648;
																	IL_066d:
																	ptr2 += 8;
																	goto end_IL_02dd;
																	IL_0656:
																	num5++;
																	num = 10;
																	goto IL_066d;
																	IL_0648:
																	array[num5] = 0;
																	goto IL_0656;
																	continue;
																	end_IL_02bd:
																	break;
																}
																continue;
																end_IL_02cd:
																break;
															}
															continue;
															end_IL_02dd:
															break;
														}
														continue;
													}
													goto IL_0731;
													IL_0731:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_067b:
													break;
												}
												continue;
												end_IL_068e:
												break;
											}
											continue;
											end_IL_0698:
											break;
										}
										continue;
										end_IL_06a3:
										break;
									}
									continue;
									end_IL_06b8:
									break;
								}
								continue;
								end_IL_06cd:
								break;
							}
							continue;
							end_IL_06dd:
							break;
						}
						continue;
						end_IL_06ed:
						break;
					}
					continue;
					end_IL_06fd:
					break;
				}
				continue;
				end_IL_070d:
				break;
			}
		}
	}

	private static int smethod_8()
	{
		int num = 20;
		int num2 = 5;
		num = 4;
		object obj = new int[4];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 140;
		num3 = 20;
		((int[])obj)[0] = 20;
		obj = obj2;
		num2 = 1;
		num3 = 38;
		num3 = 19;
		((int[])obj)[1] = 19;
		obj = obj2;
		num2 = 8;
		num3 = 4;
		num2 = 2;
		num3 = 200;
		num3 = 40;
		((int[])obj)[2] = 40;
		obj = obj2;
		num2 = 15;
		num3 = 5;
		num2 = 3;
		num3 = 25;
		num3 = 5;
		((int[])obj)[3] = 5;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 12;
			num3 = 3;
			num2 = 4;
			if (num >= 4)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		num = num4;
		num2 = 473;
		num3 = 11;
		num2 = 43;
		num3 = 105;
		num3 = 21;
		int num6 = smethod_4(43, 21);
		num2 = num6;
		return num;
	}

	static Class130()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 16;
					while (true)
					{
						if (num != 16)
						{
							if (num != 997)
							{
								break;
							}
							switch (num)
							{
							case 7:
								goto end_IL_0049;
							case 4:
								goto end_IL_0056;
							case 5:
								goto end_IL_0062;
							case 0:
								return;
							case 1:
								return;
							case 2:
								return;
							case 3:
								return;
							case 6:
								return;
							case 8:
								return;
							case 9:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0049:
						break;
					}
					continue;
					end_IL_0056:
					break;
				}
				continue;
				end_IL_0062:
				break;
			}
		}
	}
}
