using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1)]
internal struct AwaitTaskContinuationCryptoStream
{
	internal static AwaitTaskContinuationCryptoStream MakeStringRSAParameters/* Not supported: data(01) */;
}
