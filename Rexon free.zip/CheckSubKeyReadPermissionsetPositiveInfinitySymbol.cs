using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 84)]
internal struct CheckSubKeyReadPermissionsetPositiveInfinitySymbol
{
	internal static CheckSubKeyReadPermissionsetPositiveInfinitySymbol MVarObjectString/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 00 00 00 00 00 03 3E 99 99 9A 9A 99 99 3E 04 01 00 00 00 00 00 00 00 00 05 00 00 00 01 01 00 00 00 01 00 00 00 00 00 00 00 00 06 00 00 00 02 02 00 00 00 03 3E 99 99 9A 9A 99 99 3E 04 07 00 00 00 03 03 00 00 00 08) */;
}
