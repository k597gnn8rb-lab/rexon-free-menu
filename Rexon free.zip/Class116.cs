using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Hollow Sphere Small", "Super Infection/Casual [MASTERCLIENT]", "Spawns small hollow sphere.", true, 27, ModType.const_1, false)]
internal class Class116 : MonoBehaviour
{
	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static bool bool_0;

	private static bool bool_1;

	private static int int_3;

	private static Vector3 getNamespaceStartNew;

	private static Quaternion HaveSecondGREGORIANMEFRENCH;

	private static GameEntityCreateData getIsAllocatedAccessRule;

	private static IntPtr[] WaitTimeoutAnsiCharMarshaler;

	private static IntPtr[] AppendFormatSetSafeWaitHandle;

	private unsafe void OnEnable()
	{
		int num = 163;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								int[] array4 = new int[9];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										while (true)
										{
											array6[0] = this;
											while (true)
											{
												array6[1] = getNamespaceStartNew;
												while (true)
												{
													array6[5] = getNamespaceStartNew;
													num = 29;
													while (true)
													{
														array6[6] = HaveSecondGREGORIANMEFRENCH;
														while (true)
														{
															array6[7] = getNamespaceStartNew;
															while (true)
															{
																array6[8] = getIsAllocatedAccessRule;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setSharedStateR.KgetArgCount);
																	while (true)
																	{
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			if (num4 == 1)
																			{
																				return;
																			}
																			while (true)
																			{
																				byte b = *ptr2;
																				while (true)
																				{
																					ptr2++;
																					while (true)
																					{
																						IL_09f0:
																						if (b >= 1)
																						{
																							num = 477;
																							while (b <= 66)
																							{
																								while (true)
																								{
																									IL_09d0:
																									if (33 >= b)
																									{
																										while (true)
																										{
																											IL_09c0:
																											if (33 > b)
																											{
																												while (true)
																												{
																													IL_09b0:
																													if (16 < b)
																													{
																														while (true)
																														{
																															IL_09a0:
																															if (24 >= b)
																															{
																																num = 380;
																																while (true)
																																{
																																	IL_0990:
																																	if (24 > b)
																																	{
																																		while (true)
																																		{
																																			IL_0980:
																																			if (20 < b)
																																			{
																																				while (true)
																																				{
																																					IL_096d:
																																					if (22 >= b)
																																					{
																																						num = 529;
																																						while (true)
																																						{
																																							IL_095d:
																																							if (22 > b)
																																							{
																																								while (21 >= b)
																																								{
																																									while (21 <= b)
																																									{
																																										while (true)
																																										{
																																											IL_0924:
																																											array[num5] = 5;
																																											num = 566;
																																											while (true)
																																											{
																																												if (num != 566)
																																												{
																																													if (num != 1547)
																																													{
																																														break;
																																													}
																																													switch (num)
																																													{
																																													case 136:
																																													case 221:
																																														goto IL_0924;
																																													case 118:
																																														goto IL_093d;
																																													case 183:
																																														goto IL_094d;
																																													case 529:
																																														goto IL_095d;
																																													case 26:
																																														goto IL_096d;
																																													case 519:
																																														goto IL_0980;
																																													case 380:
																																														goto IL_0990;
																																													case 328:
																																														goto IL_09a0;
																																													case 92:
																																														goto IL_09b0;
																																													case 101:
																																														goto IL_09c0;
																																													case 85:
																																														goto IL_09d0;
																																													case 477:
																																														goto IL_09e0;
																																													case 484:
																																														goto IL_09f0;
																																													case 202:
																																														goto end_IL_09f0;
																																													case 13:
																																													case 102:
																																														goto end_IL_0a03;
																																													case 21:
																																														goto IL_0a1e;
																																													case 190:
																																														goto IL_0a3a;
																																													case 215:
																																														goto IL_0a4a;
																																													case 264:
																																														goto IL_0a5d;
																																													case 10:
																																													case 268:
																																														goto IL_0a70;
																																													case 156:
																																														goto IL_0a84;
																																													case 65:
																																														goto IL_0ac1;
																																													case 152:
																																													case 340:
																																														goto IL_0ad4;
																																													case 60:
																																														goto IL_0b0c;
																																													case 3:
																																													case 404:
																																														goto IL_0b25;
																																													case 214:
																																														goto IL_0b39;
																																													case 396:
																																														goto IL_0b71;
																																													case 416:
																																														goto IL_0b84;
																																													case 18:
																																														goto IL_0b92;
																																													case 146:
																																													case 256:
																																														goto IL_0b9d;
																																													case 83:
																																														goto IL_0bb6;
																																													case 445:
																																														goto IL_0bc9;
																																													case 401:
																																														goto IL_0bd7;
																																													case 443:
																																														goto IL_0be5;
																																													case 2:
																																													case 450:
																																														goto IL_0bf3;
																																													case 131:
																																													case 452:
																																														goto IL_0c0f;
																																													case 455:
																																														goto IL_0c29;
																																													case 67:
																																														goto IL_0c37;
																																													case 308:
																																														goto IL_0c45;
																																													case 378:
																																													case 451:
																																														goto IL_0c50;
																																													case 332:
																																														goto IL_0c6d;
																																													case 122:
																																														goto IL_0ca5;
																																													case 333:
																																														goto IL_0cb8;
																																													case 374:
																																														goto IL_0cc6;
																																													case 411:
																																														goto IL_0cd9;
																																													case 173:
																																														goto IL_0ce7;
																																													case 243:
																																													case 431:
																																														goto IL_0cf5;
																																													case 191:
																																														goto IL_0d09;
																																													case 185:
																																														goto IL_0d46;
																																													case 359:
																																													case 459:
																																														goto IL_0d59;
																																													case 399:
																																														goto IL_0d67;
																																													case 330:
																																														goto IL_0d85;
																																													case 442:
																																														goto IL_0d93;
																																													case 478:
																																														goto IL_0da6;
																																													case 481:
																																														goto IL_0db9;
																																													case 105:
																																													case 115:
																																														goto IL_0dc7;
																																													case 1:
																																														goto IL_0ddb;
																																													case 74:
																																														goto IL_0e2d;
																																													case 73:
																																														goto IL_0e3b;
																																													case 480:
																																													case 485:
																																														goto IL_0e4e;
																																													case 325:
																																														goto IL_0e68;
																																													case 277:
																																														goto IL_0e76;
																																													case 213:
																																														goto IL_0e84;
																																													case 493:
																																														goto IL_0e97;
																																													case 209:
																																														goto IL_0ea2;
																																													case 274:
																																													case 492:
																																														goto IL_0eb0;
																																													case 306:
																																														goto IL_0ed8;
																																													case 133:
																																														goto IL_0ee6;
																																													case 119:
																																														goto IL_0ef9;
																																													case 273:
																																														goto IL_0f07;
																																													case 4:
																																													case 440:
																																														goto IL_0f15;
																																													case 528:
																																														goto IL_0f25;
																																													case 534:
																																														goto IL_0f38;
																																													case 535:
																																														goto IL_0f56;
																																													case 137:
																																														goto IL_0f64;
																																													case 552:
																																														goto IL_0f80;
																																													case 143:
																																													case 429:
																																														goto IL_0f8b;
																																													case 294:
																																														goto IL_0fb4;
																																													case 341:
																																														goto IL_0fc2;
																																													case 263:
																																														goto IL_0fd5;
																																													case 30:
																																														goto IL_0fe3;
																																													case 309:
																																													case 342:
																																														goto IL_0ff1;
																																													case 506:
																																														goto IL_1009;
																																													case 438:
																																														goto IL_1017;
																																													case 241:
																																														goto IL_1025;
																																													case 554:
																																														goto IL_1038;
																																													case 548:
																																														goto IL_1089;
																																													case 79:
																																														goto IL_1097;
																																													case 117:
																																														goto IL_10c8;
																																													case 51:
																																														goto IL_10d6;
																																													case 323:
																																														goto IL_10e9;
																																													case 427:
																																													case 503:
																																														goto IL_10f4;
																																													case 259:
																																														goto IL_1152;
																																													case 498:
																																														goto IL_1165;
																																													case 470:
																																														goto IL_117c;
																																													case 15:
																																													case 50:
																																														goto IL_1187;
																																													case 271:
																																														goto IL_119a;
																																													case 428:
																																														goto IL_11a8;
																																													case 31:
																																														goto IL_11b6;
																																													case 194:
																																														goto IL_11c4;
																																													case 307:
																																													case 413:
																																														goto IL_11cf;
																																													case 0:
																																														goto IL_120f;
																																													case 526:
																																														goto IL_1223;
																																													case 419:
																																														goto IL_1236;
																																													case 296:
																																														goto IL_1244;
																																													case 435:
																																													case 475:
																																														goto IL_1252;
																																													case 300:
																																														goto IL_126b;
																																													case 44:
																																														goto IL_1279;
																																													case 310:
																																														goto IL_1287;
																																													case 168:
																																														goto IL_129a;
																																													case 379:
																																														goto IL_12a8;
																																													case 76:
																																													case 324:
																																														goto end_IL_0911;
																																													case 536:
																																														goto IL_12e8;
																																													case 99:
																																														goto IL_12f6;
																																													case 293:
																																													case 362:
																																														goto IL_1309;
																																													case 360:
																																														goto IL_1317;
																																													case 48:
																																														goto IL_133a;
																																													case 497:
																																														goto IL_1344;
																																													case 454:
																																														goto IL_1352;
																																													case 391:
																																														goto IL_1365;
																																													case 251:
																																														goto IL_1373;
																																													case 354:
																																														goto IL_1381;
																																													case 207:
																																													case 476:
																																														goto IL_138f;
																																													case 248:
																																														goto IL_13cf;
																																													case 199:
																																														goto IL_13e3;
																																													case 474:
																																														goto IL_13f6;
																																													case 267:
																																													case 393:
																																														goto IL_140a;
																																													case 222:
																																														goto IL_144a;
																																													case 269:
																																														goto IL_145e;
																																													case 33:
																																														goto IL_1471;
																																													case 538:
																																														goto IL_147f;
																																													case 109:
																																													case 402:
																																														goto IL_148d;
																																													case 458:
																																														goto IL_14cd;
																																													case 490:
																																														goto IL_14e1;
																																													case 527:
																																														goto IL_14f4;
																																													case 295:
																																														goto IL_1502;
																																													case 223:
																																													case 314:
																																														goto IL_150d;
																																													case 8:
																																														goto IL_151b;
																																													case 217:
																																														goto IL_153f;
																																													case 522:
																																														goto IL_154d;
																																													case 186:
																																														goto IL_1560;
																																													case 486:
																																														goto IL_156e;
																																													case 179:
																																														goto IL_157c;
																																													case 49:
																																														goto IL_1593;
																																													case 208:
																																													case 301:
																																														goto IL_15a1;
																																													case 216:
																																														goto IL_15e1;
																																													case 551:
																																														goto IL_15f5;
																																													case 543:
																																													case 547:
																																														goto IL_1608;
																																													case 279:
																																														goto IL_166a;
																																													case 110:
																																														goto IL_167d;
																																													case 421:
																																														goto IL_168b;
																																													case 184:
																																														goto IL_169e;
																																													case 376:
																																														goto IL_16ac;
																																													case 45:
																																													case 54:
																																														goto IL_16b7;
																																													case 57:
																																														goto IL_16c5;
																																													case 377:
																																														goto IL_16e9;
																																													case 71:
																																														goto IL_16f7;
																																													case 239:
																																														goto IL_170a;
																																													case 247:
																																														goto IL_1718;
																																													case 38:
																																													case 270:
																																														goto IL_1726;
																																													case 55:
																																														goto IL_1778;
																																													case 24:
																																														goto IL_178b;
																																													case 337:
																																														goto IL_1799;
																																													case 266:
																																													case 517:
																																														goto IL_17a7;
																																													case 289:
																																														goto IL_17b5;
																																													case 200:
																																														goto IL_17d9;
																																													case 336:
																																														goto IL_17e7;
																																													case 218:
																																													case 513:
																																														goto IL_1803;
																																													case 242:
																																														goto IL_1821;
																																													case 232:
																																														goto IL_182f;
																																													case 84:
																																														goto IL_1842;
																																													case 512:
																																														goto IL_1850;
																																													case 417:
																																														goto IL_185e;
																																													case 511:
																																														goto IL_186c;
																																													case 32:
																																														goto IL_187a;
																																													case 231:
																																														goto IL_1888;
																																													case 278:
																																														goto IL_1896;
																																													case 138:
																																													case 465:
																																														goto IL_18a4;
																																													case 282:
																																														goto IL_18b8;
																																													case 352:
																																														goto IL_1927;
																																													case 395:
																																														goto IL_193a;
																																													case 226:
																																														goto IL_1948;
																																													case 63:
																																													case 276:
																																														goto IL_1956;
																																													case 166:
																																														goto IL_196a;
																																													case 298:
																																														goto IL_19b0;
																																													case 280:
																																														goto IL_19c3;
																																													case 344:
																																														goto IL_19d1;
																																													case 521:
																																														goto IL_19df;
																																													case 39:
																																													case 368:
																																														goto IL_19ed;
																																													case 157:
																																														goto IL_1a0a;
																																													case 244:
																																														goto IL_1a5b;
																																													case 176:
																																														goto IL_1a69;
																																													case 36:
																																													case 128:
																																														goto IL_1a7c;
																																													case 353:
																																														goto IL_1a8a;
																																													case 555:
																																														goto IL_1aa3;
																																													case 170:
																																														goto IL_1ac2;
																																													case 530:
																																														goto IL_1ad0;
																																													case 210:
																																														goto IL_1ae3;
																																													case 317:
																																													case 510:
																																														goto IL_1aee;
																																													case 77:
																																														goto IL_1afc;
																																													case 16:
																																														goto IL_1b1f;
																																													case 542:
																																														goto IL_1b2d;
																																													case 64:
																																														goto IL_1b40;
																																													case 187:
																																														goto IL_1b4b;
																																													case 12:
																																														goto IL_1b59;
																																													case 130:
																																													case 434:
																																														goto IL_1b67;
																																													case 313:
																																														goto IL_1b75;
																																													case 469:
																																														goto IL_1b97;
																																													case 410:
																																														goto IL_1ba5;
																																													case 398:
																																														goto IL_1bb8;
																																													case 206:
																																													case 507:
																																														goto IL_1bc6;
																																													case 96:
																																														goto IL_1bda;
																																													case 540:
																																														goto IL_1c2c;
																																													case 335:
																																														goto IL_1c43;
																																													case 318:
																																														goto IL_1c56;
																																													case 420:
																																														goto IL_1c64;
																																													case 236:
																																													case 505:
																																														goto IL_1c72;
																																													case 178:
																																														goto IL_1c8f;
																																													case 496:
																																														goto IL_1ce1;
																																													case 151:
																																														goto IL_1cef;
																																													case 155:
																																														goto IL_1d02;
																																													case 80:
																																													case 501:
																																														goto IL_1d0d;
																																													case 373:
																																														goto IL_1d1b;
																																													case 103:
																																														goto IL_1d33;
																																													case 40:
																																														goto IL_1d41;
																																													case 160:
																																														goto IL_1d54;
																																													case 456:
																																														goto IL_1d62;
																																													case 28:
																																														goto IL_1d70;
																																													case 559:
																																														goto IL_1d7e;
																																													case 141:
																																													case 491:
																																														goto IL_1d89;
																																													case 72:
																																														goto IL_1da7;
																																													case 329:
																																														goto IL_1db5;
																																													case 311:
																																														goto IL_1dc8;
																																													case 518:
																																														goto IL_1dd6;
																																													case 422:
																																													case 449:
																																														goto IL_1de4;
																																													case 211:
																																														goto IL_1e02;
																																													case 302:
																																														goto IL_1e10;
																																													case 345:
																																														goto IL_1e1e;
																																													case 405:
																																														goto IL_1e31;
																																													case 125:
																																														goto IL_1e3f;
																																													case 126:
																																													case 387:
																																														goto IL_1e4d;
																																													case 111:
																																													case 343:
																																														goto IL_1e65;
																																													case 23:
																																														goto IL_1e73;
																																													case 285:
																																														goto IL_1e8b;
																																													case 339:
																																														goto IL_1e99;
																																													case 363:
																																														goto IL_1eac;
																																													case 533:
																																														goto IL_1eba;
																																													case 460:
																																													case 482:
																																														goto IL_1ec5;
																																													case 364:
																																														goto IL_1ee3;
																																													case 203:
																																														goto IL_1efa;
																																													case 150:
																																														goto IL_1f0d;
																																													case 69:
																																														goto IL_1f1b;
																																													case 120:
																																													case 366:
																																														goto IL_1f29;
																																													case 531:
																																														goto IL_1f62;
																																													case 539:
																																														goto IL_1f76;
																																													case 193:
																																														goto IL_1f89;
																																													case 46:
																																														goto IL_1f97;
																																													case 100:
																																													case 139:
																																														goto IL_1fa5;
																																													case 514:
																																														goto IL_1fc3;
																																													case 153:
																																														goto IL_1fd1;
																																													case 106:
																																														goto IL_1fdf;
																																													case 219:
																																													case 303:
																																														goto IL_1ff2;
																																													case 47:
																																														goto IL_201a;
																																													case 154:
																																														goto IL_2028;
																																													case 235:
																																														goto IL_203b;
																																													case 466:
																																														goto IL_2049;
																																													case 93:
																																													case 287:
																																														goto IL_2054;
																																													case 22:
																																														goto IL_207f;
																																													case 254:
																																														goto IL_2098;
																																													case 495:
																																														goto IL_20a6;
																																													case 436:
																																														goto IL_20b4;
																																													case 415:
																																														goto IL_20c2;
																																													case 94:
																																													case 114:
																																														goto IL_20d0;
																																													case 229:
																																														goto IL_212f;
																																													case 261:
																																														goto IL_214b;
																																													case 149:
																																														goto IL_2159;
																																													case 172:
																																														goto IL_2167;
																																													case 34:
																																													case 228:
																																														goto IL_2175;
																																													case 104:
																																														goto IL_21d4;
																																													case 59:
																																													case 504:
																																														goto IL_21f0;
																																													case 201:
																																														goto IL_21fe;
																																													case 361:
																																														goto IL_2220;
																																													case 224:
																																														goto IL_2237;
																																													case 524:
																																														goto IL_2253;
																																													case 148:
																																													case 464:
																																														goto IL_225e;
																																													case 220:
																																														goto IL_22be;
																																													case 453:
																																														goto IL_22d1;
																																													case 520:
																																														goto IL_22df;
																																													case 88:
																																													case 348:
																																														goto IL_22ea;
																																													case 356:
																																														goto IL_22f8;
																																													case 27:
																																														goto IL_2311;
																																													case 424:
																																														goto IL_2330;
																																													case 121:
																																														goto IL_233e;
																																													case 432:
																																														goto IL_2351;
																																													case 147:
																																														goto IL_235f;
																																													case 158:
																																													case 237:
																																														goto IL_236d;
																																													case 144:
																																														goto IL_237b;
																																													case 305:
																																														goto IL_2393;
																																													case 124:
																																														goto IL_23a1;
																																													case 473:
																																														goto IL_23b4;
																																													case 192:
																																														goto IL_23c2;
																																													case 7:
																																													case 375:
																																														goto IL_23d0;
																																													case 249:
																																														goto IL_241c;
																																													case 439:
																																														goto IL_242f;
																																													case 250:
																																														goto IL_243d;
																																													case 462:
																																														goto IL_244b;
																																													case 107:
																																														goto IL_2459;
																																													case 41:
																																													case 161:
																																														goto IL_2464;
																																													case 230:
																																														goto IL_2472;
																																													case 346:
																																														goto IL_2494;
																																													case 441:
																																														goto IL_24a2;
																																													case 556:
																																														goto IL_24b5;
																																													case 255:
																																														goto IL_24c3;
																																													case 75:
																																													case 369:
																																														goto IL_24d1;
																																													case 286:
																																														goto IL_253a;
																																													case 272:
																																														goto IL_254d;
																																													case 365:
																																														goto IL_255b;
																																													case 140:
																																													case 233:
																																														goto IL_2572;
																																													case 425:
																																														goto IL_25af;
																																													case 240:
																																														goto IL_25c6;
																																													case 350:
																																													case 483:
																																														goto IL_25e2;
																																													case 407:
																																														goto IL_2615;
																																													case 430:
																																														goto IL_262e;
																																													case 196:
																																														goto IL_263c;
																																													case 167:
																																													case 327:
																																														goto IL_2647;
																																													case 319:
																																														goto IL_2651;
																																													case 246:
																																														goto IL_265f;
																																													case 546:
																																														goto IL_2672;
																																													case 371:
																																														goto IL_2689;
																																													case 68:
																																													case 320:
																																														goto IL_2697;
																																													case 321:
																																														goto IL_26c2;
																																													case 347:
																																														goto IL_26db;
																																													case 334:
																																														goto IL_26e6;
																																													case 97:
																																													case 245:
																																														goto IL_26f4;
																																													case 487:
																																														goto IL_2741;
																																													case 541:
																																														goto IL_274f;
																																													case 418:
																																														goto IL_275f;
																																													case 260:
																																														goto IL_276a;
																																													case 6:
																																													case 9:
																																													case 11:
																																													case 14:
																																													case 20:
																																													case 35:
																																													case 43:
																																													case 52:
																																													case 58:
																																													case 78:
																																													case 95:
																																													case 113:
																																													case 159:
																																													case 165:
																																													case 169:
																																													case 171:
																																													case 174:
																																													case 175:
																																													case 180:
																																													case 188:
																																													case 189:
																																													case 195:
																																													case 197:
																																													case 204:
																																													case 225:
																																													case 234:
																																													case 252:
																																													case 265:
																																													case 297:
																																													case 304:
																																													case 312:
																																													case 315:
																																													case 316:
																																													case 326:
																																													case 331:
																																													case 351:
																																													case 355:
																																													case 358:
																																													case 367:
																																													case 370:
																																													case 383:
																																													case 384:
																																													case 386:
																																													case 392:
																																													case 400:
																																													case 403:
																																													case 408:
																																													case 409:
																																													case 412:
																																													case 414:
																																													case 426:
																																													case 433:
																																													case 444:
																																													case 446:
																																													case 447:
																																													case 448:
																																													case 461:
																																													case 463:
																																													case 468:
																																													case 489:
																																													case 494:
																																													case 499:
																																													case 500:
																																													case 502:
																																													case 515:
																																													case 523:
																																													case 525:
																																													case 537:
																																													case 557:
																																														goto end_IL_093d;
																																													case 5:
																																													case 17:
																																													case 19:
																																													case 25:
																																													case 37:
																																													case 42:
																																													case 53:
																																													case 56:
																																													case 61:
																																													case 62:
																																													case 66:
																																													case 70:
																																													case 81:
																																													case 87:
																																													case 89:
																																													case 91:
																																													case 98:
																																													case 108:
																																													case 112:
																																													case 127:
																																													case 129:
																																													case 132:
																																													case 134:
																																													case 135:
																																													case 142:
																																													case 145:
																																													case 164:
																																													case 177:
																																													case 182:
																																													case 198:
																																													case 205:
																																													case 212:
																																													case 227:
																																													case 238:
																																													case 253:
																																													case 257:
																																													case 258:
																																													case 262:
																																													case 275:
																																													case 281:
																																													case 283:
																																													case 284:
																																													case 290:
																																													case 291:
																																													case 292:
																																													case 299:
																																													case 322:
																																													case 349:
																																													case 357:
																																													case 372:
																																													case 381:
																																													case 382:
																																													case 385:
																																													case 388:
																																													case 397:
																																													case 406:
																																													case 423:
																																													case 437:
																																													case 457:
																																													case 467:
																																													case 479:
																																													case 488:
																																													case 508:
																																													case 509:
																																													case 544:
																																													case 545:
																																													case 549:
																																													case 550:
																																													case 558:
																																														goto end_IL_0a13;
																																													case 338:
																																														goto end_IL_2788;
																																													case 394:
																																														goto end_IL_279b;
																																													case 288:
																																														goto end_IL_27a5;
																																													case 390:
																																														goto end_IL_27b0;
																																													case 29:
																																														goto end_IL_27c6;
																																													case 471:
																																														goto end_IL_27dc;
																																													case 472:
																																														goto end_IL_27f2;
																																													case 389:
																																														goto end_IL_2811;
																																													case 181:
																																														goto end_IL_2827;
																																													case 553:
																																														goto end_IL_2837;
																																													case 123:
																																														goto end_IL_2847;
																																													case 516:
																																														goto end_IL_2857;
																																													case 90:
																																														goto end_IL_2867;
																																													case 116:
																																													case 532:
																																														goto end_IL_2877;
																																													case 162:
																																														goto end_IL_2887;
																																													case 163:
																																														goto end_IL_2897;
																																													case 82:
																																													case 86:
																																														return;
																																													}
																																													continue;
																																												}
																																												array2[num5] = ((delegate*<GTPlayer>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																																												goto IL_10c8;
																																												IL_10c8:
																																												num5++;
																																												goto IL_10d6;
																																												IL_10d6:
																																												ptr2 += 8;
																																												goto end_IL_0a13;
																																												continue;
																																												end_IL_0911:
																																												break;
																																											}
																																											break;
																																										}
																																										goto IL_12bf;
																																										continue;
																																										end_IL_093d:
																																										break;
																																										IL_093d:;
																																									}
																																									break;
																																									IL_094d:;
																																								}
																																								break;
																																							}
																																							goto IL_0ad4;
																																							IL_0f25:
																																							ptr2 += 8;
																																							goto end_IL_0a13;
																																							IL_0ad4:
																																							array2[num5 - 1] = ((delegate*<GTPlayer, SphereCollider>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																																							goto IL_0b0c;
																																							IL_0b0c:
																																							array[num5 - 1] = 5;
																																							goto IL_0f25;
																																						}
																																						break;
																																					}
																																					goto IL_0a3a;
																																					IL_0b39:
																																					array2[num5 - 1] = ((delegate*<Component, Transform>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																																					goto IL_0b71;
																																					IL_0b71:
																																					ptr2 += 8;
																																					goto end_IL_0a13;
																																					IL_0a3a:
																																					if (23 < b)
																																					{
																																						break;
																																					}
																																					goto IL_0a5d;
																																					IL_0a5d:
																																					if (23 > b)
																																					{
																																						break;
																																					}
																																					goto IL_0b25;
																																					IL_0b25:
																																					array[num5 - 1] = 5;
																																					goto IL_0b39;
																																				}
																																				break;
																																			}
																																			goto IL_0a4a;
																																			IL_1025:
																																			ptr2 += 8;
																																			goto end_IL_0a13;
																																			IL_0a4a:
																																			if (20 > b)
																																			{
																																				goto IL_0bc9;
																																			}
																																			goto IL_0c0f;
																																			IL_0c0f:
																																			((delegate*<void>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																																			goto IL_0da6;
																																			IL_0da6:
																																			ptr2 += 8;
																																			goto end_IL_0a13;
																																			IL_0bc9:
																																			if (18 < b)
																																			{
																																				goto IL_0bd7;
																																			}
																																			goto IL_0f80;
																																			IL_0bd7:
																																			if (19 < b)
																																			{
																																				break;
																																			}
																																			goto IL_0be5;
																																			IL_0be5:
																																			if (19 > b)
																																			{
																																				break;
																																			}
																																			goto IL_0bf3;
																																			IL_0bf3:
																																			byte* num6 = ptr2;
																																			num4 = 1;
																																			ptr2 = num6 + -200;
																																			goto end_IL_0a13;
																																			IL_0f80:
																																			if (18 <= b)
																																			{
																																				goto IL_0f8b;
																																			}
																																			goto IL_0fd5;
																																			IL_0f8b:
																																			((delegate*<UnityEngine.Object, void>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Class116)array2[num5 - 1]);
																																			goto IL_0fb4;
																																			IL_0fb4:
																																			num5--;
																																			goto IL_0fc2;
																																			IL_0fc2:
																																			ptr2 += 8;
																																			goto end_IL_0a13;
																																			IL_0fd5:
																																			if (17 < b)
																																			{
																																				break;
																																			}
																																			goto IL_0fe3;
																																			IL_0fe3:
																																			if (17 > b)
																																			{
																																				break;
																																			}
																																			goto IL_0ff1;
																																			IL_0ff1:
																																			array2[num5] = array6[*(int*)(ptr2 + num3)];
																																			goto IL_1009;
																																			IL_1009:
																																			array[num5] = 5;
																																			goto IL_1017;
																																			IL_1017:
																																			num5++;
																																			goto IL_1025;
																																		}
																																		break;
																																	}
																																	goto IL_0a70;
																																	IL_0ac1:
																																	ptr2 += 8;
																																	goto end_IL_0a13;
																																	IL_0a70:
																																	array[num5 - 1] = 4;
																																	goto IL_0a84;
																																	IL_0a84:
																																	array2[num5 - 1] = ((delegate*<Transform, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																																	goto IL_0ac1;
																																}
																																break;
																															}
																															goto IL_0a1e;
																															IL_0f38:
																															array2[num5] = ((delegate*<List<GameEntityCreateData>>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																															goto IL_0f56;
																															IL_0f56:
																															num5++;
																															goto IL_0f64;
																															IL_0a1e:
																															if (28 < b)
																															{
																																goto IL_0b84;
																															}
																															num = 455;
																															goto IL_0c29;
																															IL_0f64:
																															ptr2 += 8;
																															num = 423;
																															goto end_IL_0a13;
																															IL_0c29:
																															if (28 > b)
																															{
																																goto IL_0c37;
																															}
																															goto IL_0e4e;
																															IL_0c37:
																															if (26 >= b)
																															{
																																goto IL_0c45;
																															}
																															goto IL_0cd9;
																															IL_0c45:
																															if (26 <= b)
																															{
																																goto IL_0c50;
																															}
																															goto IL_0cb8;
																															IL_0c50:
																															array[num5 - 1] = 5;
																															num = 332;
																															goto IL_0c6d;
																															IL_0c6d:
																															array2[num5 - 1] = ((delegate*<Component, Transform>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																															goto IL_0ca5;
																															IL_0ca5:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0cb8:
																															if (25 < b)
																															{
																																break;
																															}
																															goto IL_0cc6;
																															IL_0cc6:
																															if (25 > b)
																															{
																																break;
																															}
																															goto IL_0d59;
																															IL_0d59:
																															array[num5] = 5;
																															goto IL_0d67;
																															IL_0d67:
																															array2[num5] = ((delegate*<GTPlayer>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																															goto IL_0d85;
																															IL_0d85:
																															num5++;
																															goto IL_0d93;
																															IL_0d93:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0cd9:
																															if (27 < b)
																															{
																																break;
																															}
																															goto IL_0ce7;
																															IL_0ce7:
																															if (27 > b)
																															{
																																break;
																															}
																															goto IL_0cf5;
																															IL_0cf5:
																															array[num5 - 1] = 4;
																															goto IL_0d09;
																															IL_0d09:
																															array2[num5 - 1] = ((delegate*<Transform, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																															goto IL_0d46;
																															IL_0d46:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0e4e:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																															goto IL_0e68;
																															IL_0e68:
																															array[num5] = 3;
																															goto IL_0e76;
																															IL_0e76:
																															num5++;
																															goto IL_0e84;
																															IL_0e84:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0b84:
																															if (30 >= b)
																															{
																																goto IL_0b92;
																															}
																															goto IL_0e97;
																															IL_0b92:
																															if (30 <= b)
																															{
																																goto IL_0b9d;
																															}
																															goto IL_0bb6;
																															IL_0b9d:
																															array[num5 - 2] = 4;
																															goto IL_1038;
																															IL_1038:
																															array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																															goto IL_1089;
																															IL_1089:
																															num5--;
																															goto IL_1097;
																															IL_1097:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0bb6:
																															if (29 < b)
																															{
																																break;
																															}
																															goto IL_0db9;
																															IL_0db9:
																															if (29 > b)
																															{
																																break;
																															}
																															goto IL_0dc7;
																															IL_0dc7:
																															array[num5 - 2] = 4;
																															goto IL_0ddb;
																															IL_0ddb:
																															array2[num5 - 2] = ((delegate*<Vector3, float, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																															goto IL_0e2d;
																															IL_0e2d:
																															num5--;
																															goto IL_0e3b;
																															IL_0e3b:
																															ptr2 += 8;
																															goto end_IL_0a13;
																															IL_0e97:
																															if (31 >= b)
																															{
																																goto IL_0ea2;
																															}
																															goto IL_0ef9;
																															IL_0ea2:
																															if (31 > b)
																															{
																																break;
																															}
																															goto IL_0eb0;
																															IL_0eb0:
																															array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num5 - 1];
																															goto IL_0ed8;
																															IL_0ed8:
																															ptr2 += 8;
																															goto IL_0ee6;
																															IL_0ee6:
																															num5--;
																															goto end_IL_0a13;
																															IL_0ef9:
																															if (32 < b)
																															{
																																break;
																															}
																															goto IL_0f07;
																															IL_0f07:
																															if (32 > b)
																															{
																																break;
																															}
																															goto IL_0f15;
																															IL_0f15:
																															array[num5] = 5;
																															goto IL_0f38;
																														}
																														break;
																													}
																													goto IL_10e9;
																													IL_1799:
																													if (15 > b)
																													{
																														break;
																													}
																													goto IL_17a7;
																													IL_10e9:
																													if (16 <= b)
																													{
																														goto IL_10f4;
																													}
																													goto IL_1165;
																													IL_10f4:
																													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_1152;
																													IL_1152:
																													num5--;
																													goto end_IL_0a13;
																													IL_1165:
																													if (8 >= b)
																													{
																														num = 470;
																														goto IL_117c;
																													}
																													goto IL_14f4;
																													IL_17a7:
																													array[num5] = 0;
																													goto IL_17b5;
																													IL_117c:
																													if (8 <= b)
																													{
																														goto IL_1187;
																													}
																													goto IL_119a;
																													IL_1187:
																													num5--;
																													goto end_IL_0a13;
																													IL_119a:
																													if (4 >= b)
																													{
																														goto IL_11a8;
																													}
																													goto IL_1365;
																													IL_11a8:
																													if (4 > b)
																													{
																														goto IL_11b6;
																													}
																													goto IL_1309;
																													IL_11b6:
																													if (2 >= b)
																													{
																														goto IL_11c4;
																													}
																													goto IL_129a;
																													IL_11c4:
																													if (2 <= b)
																													{
																														goto IL_11cf;
																													}
																													goto IL_1236;
																													IL_11cf:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_120f;
																													IL_120f:
																													array[num5 - 2] = 0;
																													goto IL_1223;
																													IL_1223:
																													num5--;
																													goto end_IL_0a13;
																													IL_1236:
																													if (1 < b)
																													{
																														break;
																													}
																													goto IL_1244;
																													IL_1244:
																													if (1 > b)
																													{
																														break;
																													}
																													goto IL_1252;
																													IL_1252:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																													goto IL_126b;
																													IL_126b:
																													array[num5] = 0;
																													goto IL_1279;
																													IL_1279:
																													num5++;
																													goto IL_1287;
																													IL_1287:
																													ptr2 += 8;
																													goto end_IL_0a13;
																													IL_129a:
																													if (3 < b)
																													{
																														break;
																													}
																													goto IL_12a8;
																													IL_12a8:
																													if (3 > b)
																													{
																														break;
																													}
																													num = 76;
																													goto IL_12bf;
																													IL_17b5:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])() ? 1 : 0);
																													goto IL_17d9;
																													IL_12bf:
																													ref int reference = ref array4[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_12e8;
																													IL_12e8:
																													ptr2 += 8;
																													goto IL_12f6;
																													IL_12f6:
																													num5--;
																													goto end_IL_0a13;
																													IL_1309:
																													array[num5] = 0;
																													goto IL_1317;
																													IL_1317:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																													goto IL_133a;
																													IL_133a:
																													array2[num5] = null;
																													goto IL_1344;
																													IL_1344:
																													num5++;
																													goto IL_1352;
																													IL_1352:
																													ptr2 += 8;
																													goto end_IL_0a13;
																													IL_1365:
																													if (6 < b)
																													{
																														goto IL_1373;
																													}
																													goto IL_13f6;
																													IL_1373:
																													if (7 < b)
																													{
																														break;
																													}
																													goto IL_1381;
																													IL_1381:
																													if (7 > b)
																													{
																														break;
																													}
																													goto IL_138f;
																													IL_138f:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_13cf;
																													IL_13cf:
																													array[num5 - 2] = 0;
																													goto IL_13e3;
																													IL_13e3:
																													num5--;
																													goto end_IL_0a13;
																													IL_13f6:
																													if (6 <= b)
																													{
																														num = 267;
																														goto IL_140a;
																													}
																													goto IL_1471;
																													IL_17d9:
																													num5++;
																													goto IL_17e7;
																													IL_140a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_144a;
																													IL_144a:
																													array[num5 - 2] = 0;
																													goto IL_145e;
																													IL_145e:
																													num5--;
																													goto end_IL_0a13;
																													IL_1471:
																													if (5 < b)
																													{
																														break;
																													}
																													goto IL_147f;
																													IL_147f:
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_148d;
																													IL_148d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_14cd;
																													IL_14cd:
																													array[num5 - 2] = 0;
																													goto IL_14e1;
																													IL_14e1:
																													num5--;
																													goto end_IL_0a13;
																													IL_14f4:
																													if (12 >= b)
																													{
																														goto IL_1502;
																													}
																													goto IL_169e;
																													IL_1502:
																													if (12 <= b)
																													{
																														goto IL_150d;
																													}
																													goto IL_1560;
																													IL_150d:
																													array[num5] = 0;
																													goto IL_151b;
																													IL_151b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])() ? 1 : 0);
																													goto IL_153f;
																													IL_153f:
																													num5++;
																													goto IL_154d;
																													IL_154d:
																													ptr2 += 8;
																													goto end_IL_0a13;
																													IL_1560:
																													if (10 >= b)
																													{
																														goto IL_156e;
																													}
																													goto IL_167d;
																													IL_156e:
																													if (10 > b)
																													{
																														goto IL_157c;
																													}
																													goto IL_1608;
																													IL_157c:
																													if (9 < b)
																													{
																														break;
																													}
																													num = 49;
																													goto IL_1593;
																													IL_17e7:
																													ptr2 += 8;
																													num = 129;
																													goto end_IL_0a13;
																													IL_1593:
																													if (9 > b)
																													{
																														break;
																													}
																													goto IL_15a1;
																													IL_15a1:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_15e1;
																													IL_15e1:
																													array[num5 - 2] = 0;
																													goto IL_15f5;
																													IL_15f5:
																													num5--;
																													goto end_IL_0a13;
																													IL_1608:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_166a;
																													IL_166a:
																													num5 -= 2;
																													goto end_IL_0a13;
																													IL_167d:
																													if (11 < b)
																													{
																														break;
																													}
																													goto IL_168b;
																													IL_168b:
																													if (11 > b)
																													{
																														break;
																													}
																													goto end_IL_0a13;
																													IL_169e:
																													if (14 >= b)
																													{
																														goto IL_16ac;
																													}
																													goto IL_178b;
																													IL_16ac:
																													if (14 <= b)
																													{
																														goto IL_16b7;
																													}
																													goto IL_170a;
																													IL_16b7:
																													array[num5] = 0;
																													goto IL_16c5;
																													IL_16c5:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])() ? 1 : 0);
																													goto IL_16e9;
																													IL_16e9:
																													num5++;
																													goto IL_16f7;
																													IL_16f7:
																													ptr2 += 8;
																													goto end_IL_0a13;
																													IL_170a:
																													if (13 < b)
																													{
																														break;
																													}
																													goto IL_1718;
																													IL_1718:
																													if (13 > b)
																													{
																														break;
																													}
																													goto IL_1726;
																													IL_1726:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_1778;
																													IL_1778:
																													num5--;
																													goto end_IL_0a13;
																													IL_178b:
																													if (15 < b)
																													{
																														break;
																													}
																													goto IL_1799;
																												}
																												break;
																											}
																											goto IL_1803;
																											IL_182f:
																											num5--;
																											goto end_IL_0a13;
																											IL_1803:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_1821;
																											IL_1821:
																											ptr2 += 8;
																											goto IL_182f;
																										}
																										break;
																									}
																									goto IL_1842;
																									IL_26db:
																									if (65 >= b)
																									{
																										goto IL_26e6;
																									}
																									goto IL_275f;
																									IL_1842:
																									if (50 >= b)
																									{
																										goto IL_1850;
																									}
																									goto IL_203b;
																									IL_1850:
																									if (50 > b)
																									{
																										goto IL_185e;
																									}
																									goto IL_1ff2;
																									IL_185e:
																									if (41 < b)
																									{
																										goto IL_186c;
																									}
																									goto IL_1d02;
																									IL_186c:
																									if (45 < b)
																									{
																										goto IL_187a;
																									}
																									goto IL_1ae3;
																									IL_187a:
																									if (47 < b)
																									{
																										goto IL_1888;
																									}
																									goto IL_19c3;
																									IL_1888:
																									if (48 >= b)
																									{
																										goto IL_1896;
																									}
																									goto IL_193a;
																									IL_1896:
																									if (48 > b)
																									{
																										break;
																									}
																									goto IL_18a4;
																									IL_18a4:
																									array[num5 - 1] = 4;
																									goto IL_18b8;
																									IL_18b8:
																									array2[num5 - 1] = ((delegate*<ref Vector3, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4));
																									goto IL_1927;
																									IL_1927:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_193a:
																									if (49 < b)
																									{
																										break;
																									}
																									goto IL_1948;
																									IL_1948:
																									if (49 > b)
																									{
																										break;
																									}
																									goto IL_1956;
																									IL_1956:
																									array[num5 - 1] = 4;
																									goto IL_196a;
																									IL_196a:
																									array2[num5 - 1] = ((delegate*<Vector3, Quaternion>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																									num = 298;
																									goto IL_19b0;
																									IL_19b0:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_19c3:
																									if (47 > b)
																									{
																										goto IL_19d1;
																									}
																									goto IL_1a7c;
																									IL_19d1:
																									if (46 < b)
																									{
																										break;
																									}
																									goto IL_19df;
																									IL_19df:
																									if (46 > b)
																									{
																										break;
																									}
																									goto IL_19ed;
																									IL_19ed:
																									array[num5 - 2] = 4;
																									num = 157;
																									goto IL_1a0a;
																									IL_1a0a:
																									array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																									goto IL_1a5b;
																									IL_1a5b:
																									num5--;
																									goto IL_1a69;
																									IL_1a69:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1a7c:
																									array[num5] = 13;
																									goto IL_1a8a;
																									IL_1a8a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_1aa3;
																									IL_1aa3:
																									array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																									goto IL_1ac2;
																									IL_1ac2:
																									num5++;
																									goto IL_1ad0;
																									IL_1ad0:
																									ptr2 += 16;
																									goto end_IL_0a13;
																									IL_1ae3:
																									if (45 <= b)
																									{
																										goto IL_1aee;
																									}
																									goto IL_1b40;
																									IL_1aee:
																									array[num5] = 4;
																									goto IL_1afc;
																									IL_1afc:
																									array2[num5] = ((delegate*<Vector3>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																									goto IL_1b1f;
																									IL_1b1f:
																									num5++;
																									goto IL_1b2d;
																									IL_1b2d:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1b40:
																									if (43 < b)
																									{
																										goto IL_1b4b;
																									}
																									goto IL_1bb8;
																									IL_1b4b:
																									if (44 < b)
																									{
																										break;
																									}
																									goto IL_1b59;
																									IL_1b59:
																									if (44 > b)
																									{
																										break;
																									}
																									goto IL_1b67;
																									IL_1b67:
																									array[num5] = 4;
																									goto IL_1b75;
																									IL_1b75:
																									array2[num5] = (Vector3)array6[*(int*)(ptr2 + num3)];
																									goto IL_1b97;
																									IL_1b97:
																									num5++;
																									goto IL_1ba5;
																									IL_1ba5:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1bb8:
																									if (43 <= b)
																									{
																										goto IL_1bc6;
																									}
																									goto IL_1c56;
																									IL_1bc6:
																									array[num5 - 2] = 0;
																									goto IL_1bda;
																									IL_1bda:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]);
																									goto IL_1c2c;
																									IL_1c2c:
																									num5--;
																									num = 335;
																									goto IL_1c43;
																									IL_1c43:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1c56:
																									if (42 < b)
																									{
																										break;
																									}
																									goto IL_1c64;
																									IL_1c64:
																									if (42 > b)
																									{
																										break;
																									}
																									goto IL_1c72;
																									IL_1c72:
																									array[num5 - 2] = 0;
																									num = 178;
																									goto IL_1c8f;
																									IL_1c8f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]) ? 1 : 0);
																									goto IL_1ce1;
																									IL_1ce1:
																									num5--;
																									goto IL_1cef;
																									IL_1cef:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1d02:
																									if (41 <= b)
																									{
																										goto IL_1d0d;
																									}
																									goto IL_1d54;
																									IL_1d0d:
																									array[num5] = 5;
																									goto IL_1d1b;
																									IL_1d1b:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_1d33;
																									IL_1d33:
																									num5++;
																									goto IL_1d41;
																									IL_1d41:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1d54:
																									if (37 >= b)
																									{
																										goto IL_1d62;
																									}
																									goto IL_1eac;
																									IL_1d62:
																									if (37 > b)
																									{
																										goto IL_1d70;
																									}
																									goto IL_1e65;
																									IL_1d70:
																									if (35 >= b)
																									{
																										goto IL_1d7e;
																									}
																									goto IL_1e31;
																									IL_1d7e:
																									if (35 <= b)
																									{
																										goto IL_1d89;
																									}
																									goto IL_1dc8;
																									IL_1d89:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_1da7;
																									IL_1da7:
																									ptr2 += 8;
																									goto IL_1db5;
																									IL_1db5:
																									num5--;
																									goto end_IL_0a13;
																									IL_1dc8:
																									if (34 < b)
																									{
																										break;
																									}
																									goto IL_1dd6;
																									IL_1dd6:
																									if (34 > b)
																									{
																										break;
																									}
																									goto IL_1de4;
																									IL_1de4:
																									array2[num5] = ((delegate*<string[]>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																									goto IL_1e02;
																									IL_1e02:
																									array[num5] = 5;
																									goto IL_1e10;
																									IL_1e10:
																									num5++;
																									goto IL_1e1e;
																									IL_1e1e:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1e31:
																									if (36 < b)
																									{
																										break;
																									}
																									goto IL_1e3f;
																									IL_1e3f:
																									if (36 > b)
																									{
																										break;
																									}
																									goto IL_1e4d;
																									IL_1e4d:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0a13;
																									IL_1e65:
																									array[num5] = 5;
																									goto IL_1e73;
																									IL_1e73:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_1e8b;
																									IL_1e8b:
																									num5++;
																									goto IL_1e99;
																									IL_1e99:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1eac:
																									if (39 >= b)
																									{
																										goto IL_1eba;
																									}
																									goto IL_1f89;
																									IL_1eba:
																									if (39 <= b)
																									{
																										goto IL_1ec5;
																									}
																									goto IL_1f0d;
																									IL_1ec5:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_1ee3;
																									IL_1ee3:
																									ptr2 += 8;
																									num = 203;
																									goto IL_1efa;
																									IL_1efa:
																									num5--;
																									goto end_IL_0a13;
																									IL_1f0d:
																									if (38 < b)
																									{
																										break;
																									}
																									goto IL_1f1b;
																									IL_1f1b:
																									if (38 > b)
																									{
																										break;
																									}
																									goto IL_1f29;
																									IL_1f29:
																									array2[num5 - 2] = ((string[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																									goto IL_1f62;
																									IL_1f62:
																									array[num5 - 2] = 5;
																									goto IL_1f76;
																									IL_1f76:
																									num5--;
																									goto end_IL_0a13;
																									IL_1f89:
																									if (40 < b)
																									{
																										break;
																									}
																									goto IL_1f97;
																									IL_1f97:
																									if (40 > b)
																									{
																										break;
																									}
																									goto IL_1fa5;
																									IL_1fa5:
																									array2[num5] = ((delegate*<Dictionary<string, int>>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])();
																									goto IL_1fc3;
																									IL_1fc3:
																									array[num5] = 5;
																									goto IL_1fd1;
																									IL_1fd1:
																									num5++;
																									goto IL_1fdf;
																									IL_1fdf:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_1ff2:
																									array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num5 - 1];
																									goto IL_201a;
																									IL_201a:
																									ptr2 += 8;
																									goto IL_2028;
																									IL_2028:
																									num5--;
																									goto end_IL_0a13;
																									IL_203b:
																									if (58 >= b)
																									{
																										goto IL_2049;
																									}
																									goto IL_242f;
																									IL_2049:
																									if (58 <= b)
																									{
																										goto IL_2054;
																									}
																									goto IL_2098;
																									IL_2054:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_207f;
																									IL_207f:
																									array[num5 - 1] = 1;
																									goto end_IL_0a13;
																									IL_2098:
																									if (54 < b)
																									{
																										goto IL_20a6;
																									}
																									num = 524;
																									goto IL_2253;
																									IL_20a6:
																									if (56 < b)
																									{
																										goto IL_20b4;
																									}
																									num = 261;
																									goto IL_214b;
																									IL_20b4:
																									if (57 < b)
																									{
																										break;
																									}
																									goto IL_20c2;
																									IL_20c2:
																									if (57 > b)
																									{
																										break;
																									}
																									goto IL_20d0;
																									IL_20d0:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).rotation = (Quaternion)array2[num5 - 1];
																									goto IL_212f;
																									IL_212f:
																									num5 -= 2;
																									goto end_IL_0a13;
																									IL_26f4:
																									((delegate*<List<GameEntityCreateData>, Player, bool, void>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 3], (Player)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0);
																									goto IL_2741;
																									IL_214b:
																									if (56 > b)
																									{
																										goto IL_2159;
																									}
																									num = 504;
																									goto IL_21f0;
																									IL_2159:
																									if (55 < b)
																									{
																										break;
																									}
																									goto IL_2167;
																									IL_2167:
																									if (55 > b)
																									{
																										break;
																									}
																									goto IL_2175;
																									IL_2175:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).position = (Vector3)array2[num5 - 1];
																									goto IL_21d4;
																									IL_21d4:
																									num5 -= 2;
																									goto end_IL_0a13;
																									IL_2741:
																									num5 -= 3;
																									goto IL_274f;
																									IL_21f0:
																									array[num5] = 4;
																									goto IL_21fe;
																									IL_21fe:
																									array2[num5] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																									goto IL_2220;
																									IL_2220:
																									num5++;
																									num = 224;
																									goto IL_2237;
																									IL_2237:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_26e6:
																									if (65 > b)
																									{
																										break;
																									}
																									goto IL_26f4;
																									IL_2253:
																									if (54 <= b)
																									{
																										goto IL_225e;
																									}
																									goto IL_22d1;
																									IL_225e:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_22be;
																									IL_22be:
																									num5 -= 2;
																									goto end_IL_0a13;
																									IL_22d1:
																									if (52 >= b)
																									{
																										goto IL_22df;
																									}
																									goto IL_23b4;
																									IL_22df:
																									if (52 <= b)
																									{
																										goto IL_22ea;
																									}
																									goto IL_2351;
																									IL_22ea:
																									array[num5] = 13;
																									goto IL_22f8;
																									IL_22f8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_2311;
																									IL_2311:
																									array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																									goto IL_2330;
																									IL_2330:
																									num5++;
																									goto IL_233e;
																									IL_233e:
																									ptr2 += 16;
																									goto end_IL_0a13;
																									IL_2351:
																									if (51 < b)
																									{
																										break;
																									}
																									goto IL_235f;
																									IL_235f:
																									if (51 > b)
																									{
																										break;
																									}
																									goto IL_236d;
																									IL_236d:
																									array[num5] = 5;
																									goto IL_237b;
																									IL_237b:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_2393;
																									IL_2393:
																									num5++;
																									goto IL_23a1;
																									IL_23a1:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_23b4:
																									if (53 < b)
																									{
																										break;
																									}
																									goto IL_23c2;
																									IL_23c2:
																									if (53 > b)
																									{
																										break;
																									}
																									goto IL_23d0;
																									IL_23d0:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4) = default(GameEntityCreateData);
																									goto IL_241c;
																									IL_241c:
																									num5--;
																									goto end_IL_0a13;
																									IL_242f:
																									if (62 >= b)
																									{
																										goto IL_243d;
																									}
																									goto IL_262e;
																									IL_243d:
																									if (62 > b)
																									{
																										goto IL_244b;
																									}
																									num = 483;
																									goto IL_25e2;
																									IL_244b:
																									if (60 >= b)
																									{
																										goto IL_2459;
																									}
																									goto IL_254d;
																									IL_2459:
																									if (60 <= b)
																									{
																										goto IL_2464;
																									}
																									goto IL_24b5;
																									IL_2464:
																									array[num5] = 4;
																									goto IL_2472;
																									IL_2472:
																									array2[num5] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																									goto IL_2494;
																									IL_2494:
																									num5++;
																									goto IL_24a2;
																									IL_24a2:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_24b5:
																									if (59 < b)
																									{
																										break;
																									}
																									goto IL_24c3;
																									IL_24c3:
																									if (59 > b)
																									{
																										break;
																									}
																									goto IL_24d1;
																									IL_24d1:
																									((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)WaitTimeoutAnsiCharMarshaler[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									num = 286;
																									goto IL_253a;
																									IL_253a:
																									num5 -= 2;
																									goto end_IL_0a13;
																									IL_254d:
																									if (61 < b)
																									{
																										break;
																									}
																									goto IL_255b;
																									IL_255b:
																									if (61 > b)
																									{
																										break;
																									}
																									num = 233;
																									goto IL_2572;
																									IL_275f:
																									if (66 < b)
																									{
																										break;
																									}
																									goto IL_276a;
																									IL_2572:
																									((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)WaitTimeoutAnsiCharMarshaler[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 2], (GameEntityCreateData)array2[num5 - 1]);
																									goto IL_25af;
																									IL_25af:
																									num5 -= 2;
																									num = 240;
																									goto IL_25c6;
																									IL_25c6:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_274f:
																									ptr2 += 8;
																									goto end_IL_0a13;
																									IL_25e2:
																									*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
																									num = 407;
																									goto IL_2615;
																									IL_2615:
																									array[num5 - 1] = 2;
																									goto end_IL_0a13;
																									IL_262e:
																									if (64 >= b)
																									{
																										goto IL_263c;
																									}
																									goto IL_26db;
																									IL_263c:
																									if (64 <= b)
																									{
																										goto IL_2647;
																									}
																									goto IL_2672;
																									IL_2647:
																									array2[num5] = null;
																									goto IL_2651;
																									IL_2651:
																									array[num5] = 5;
																									goto IL_265f;
																									IL_265f:
																									num5++;
																									goto end_IL_0a13;
																									IL_2672:
																									if (63 < b)
																									{
																										break;
																									}
																									num = 371;
																									goto IL_2689;
																									IL_276a:
																									if (66 <= b)
																									{
																									}
																									break;
																									IL_2689:
																									if (63 > b)
																									{
																										break;
																									}
																									goto IL_2697;
																									IL_2697:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																									goto IL_26c2;
																									IL_26c2:
																									array[num5 - 1] = 0;
																									goto end_IL_0a13;
																								}
																								break;
																								IL_09e0:;
																							}
																						}
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0a13;
																						continue;
																						end_IL_09f0:
																						break;
																					}
																					continue;
																					end_IL_0a03:
																					break;
																				}
																				continue;
																				end_IL_0a13:
																				break;
																			}
																			continue;
																			end_IL_2788:
																			break;
																		}
																		continue;
																		end_IL_279b:
																		break;
																	}
																	continue;
																	end_IL_27a5:
																	break;
																}
																continue;
																end_IL_27b0:
																break;
															}
															continue;
															end_IL_27c6:
															break;
														}
														continue;
														end_IL_27dc:
														break;
													}
													continue;
													end_IL_27f2:
													break;
												}
												continue;
												end_IL_2811:
												break;
											}
											continue;
											end_IL_2827:
											break;
										}
										continue;
										end_IL_2837:
										break;
									}
									continue;
									end_IL_2847:
									break;
								}
								continue;
								end_IL_2857:
								break;
							}
							continue;
							end_IL_2867:
							break;
						}
						continue;
						end_IL_2877:
						break;
					}
					continue;
					end_IL_2887:
					break;
				}
				continue;
				end_IL_2897:
				break;
			}
		}
	}

	public Class116()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_4)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDllEntryDisable.BindToMethodC);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_033f:
														byte b = *ptr2;
														while (true)
														{
															IL_032f:
															ptr2++;
															while (true)
															{
																IL_031f:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02ff:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02ef:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02e2:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_02d2:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_02bf:
																											if (5 <= b)
																											{
																												num = 104;
																												while (true)
																												{
																													IL_02af:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_028a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_027e:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_0265:
																																num5++;
																																num = 99;
																																while (true)
																																{
																																	IL_024c:
																																	ptr2 += 8;
																																	num = 135;
																																	while (num != 135)
																																	{
																																		if (num != 1116)
																																		{
																																			goto IL_0355;
																																		}
																																		switch (num)
																																		{
																																		case 99:
																																			goto IL_024c;
																																		case 84:
																																			goto IL_0265;
																																		case 112:
																																			goto IL_027e;
																																		case 74:
																																			goto IL_028a;
																																		case 104:
																																		case 114:
																																			goto IL_02af;
																																		case 19:
																																			goto IL_02bf;
																																		case 121:
																																			goto IL_02d2;
																																		case 42:
																																		case 96:
																																			goto IL_02e2;
																																		case 46:
																																			goto IL_02ef;
																																		case 15:
																																			goto IL_02ff;
																																		case 110:
																																			goto IL_030f;
																																		case 54:
																																			goto IL_031f;
																																		case 64:
																																			goto IL_032f;
																																		case 124:
																																		case 128:
																																			goto IL_033f;
																																		case 10:
																																			goto IL_034a;
																																		case 12:
																																		case 18:
																																			goto IL_0355;
																																		case 39:
																																			goto IL_036d;
																																		case 85:
																																		case 89:
																																			goto IL_0378;
																																		case 52:
																																			goto IL_0386;
																																		case 95:
																																			goto IL_0396;
																																		case 22:
																																		case 93:
																																			goto IL_03a4;
																																		case 80:
																																			goto IL_03bd;
																																		case 59:
																																		case 109:
																																			goto IL_03cd;
																																		case 14:
																																			goto IL_03ff;
																																		case 4:
																																			goto IL_040d;
																																		case 122:
																																			goto IL_0420;
																																		case 13:
																																			goto IL_042e;
																																		case 123:
																																			goto IL_0441;
																																		case 6:
																																			goto IL_044f;
																																		case 83:
																																			goto IL_0462;
																																		case 65:
																																			goto IL_0470;
																																		case 38:
																																		case 97:
																																			goto IL_047e;
																																		case 43:
																																			goto IL_04c7;
																																		case 1:
																																			goto IL_04db;
																																		case 0:
																																		case 102:
																																			goto IL_04ee;
																																		case 50:
																																			goto IL_0511;
																																		case 116:
																																			goto IL_051f;
																																		case 51:
																																			goto IL_052d;
																																		case 63:
																																			goto IL_0540;
																																		case 24:
																																		case 33:
																																			goto IL_054e;
																																		case 32:
																																			goto IL_0559;
																																		case 61:
																																		case 81:
																																			goto IL_0564;
																																		case 106:
																																			goto IL_0580;
																																		case 16:
																																			goto IL_058e;
																																		case 17:
																																		case 28:
																																			goto IL_059c;
																																		case 82:
																																			goto IL_05af;
																																		case 88:
																																			goto IL_05ba;
																																		case 90:
																																			goto IL_05db;
																																		case 49:
																																		case 108:
																																			goto IL_05e9;
																																		case 48:
																																		case 127:
																																			goto IL_05f7;
																																		case 34:
																																			goto IL_060e;
																																		case 25:
																																		case 37:
																																			goto IL_061c;
																																		case 91:
																																			goto IL_065c;
																																		case 27:
																																			goto IL_0670;
																																		case 98:
																																			goto IL_0683;
																																		case 31:
																																		case 53:
																																			goto IL_0691;
																																		case 29:
																																			goto IL_06f3;
																																		case 55:
																																		case 87:
																																			goto IL_0706;
																																		case 115:
																																			goto IL_071a;
																																		case 71:
																																			goto IL_0777;
																																		case 103:
																																			goto IL_0785;
																																		case 3:
																																		case 5:
																																		case 8:
																																		case 9:
																																		case 11:
																																		case 20:
																																		case 23:
																																		case 30:
																																		case 40:
																																		case 44:
																																		case 45:
																																		case 58:
																																		case 66:
																																		case 68:
																																		case 69:
																																		case 70:
																																		case 75:
																																		case 76:
																																		case 94:
																																		case 107:
																																		case 111:
																																		case 117:
																																		case 125:
																																			goto end_IL_030f;
																																		case 2:
																																		case 7:
																																		case 26:
																																		case 41:
																																		case 57:
																																		case 62:
																																		case 67:
																																		case 72:
																																		case 79:
																																		case 86:
																																		case 92:
																																		case 101:
																																		case 118:
																																		case 119:
																																		case 120:
																																			goto end_IL_0239;
																																		case 21:
																																			goto end_IL_07a8;
																																		case 126:
																																			goto end_IL_07bb;
																																		case 100:
																																			goto end_IL_07c5;
																																		case 105:
																																			goto end_IL_07d0;
																																		case 56:
																																		case 60:
																																			goto end_IL_07e5;
																																		case 35:
																																			goto end_IL_07f5;
																																		case 36:
																																		case 73:
																																			goto end_IL_0805;
																																		case 77:
																																			goto end_IL_0815;
																																		case 78:
																																			goto end_IL_0825;
																																		case 47:
																																		case 113:
																																			goto IL_0840;
																																		}
																																		continue;
																																		end_IL_0239:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0441;
																											IL_0441:
																											if (4 < b)
																											{
																												goto end_IL_030f;
																											}
																											goto IL_044f;
																											IL_044f:
																											if (4 <= b)
																											{
																												break;
																											}
																											goto end_IL_030f;
																										}
																										break;
																									}
																									goto IL_0462;
																									IL_04db:
																									num5--;
																									break;
																									IL_0462:
																									if (6 < b)
																									{
																										goto end_IL_030f;
																									}
																									goto IL_0470;
																									IL_0470:
																									if (6 > b)
																									{
																										goto end_IL_030f;
																									}
																									goto IL_047e;
																									IL_047e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 43;
																									goto IL_04c7;
																									IL_04c7:
																									array[num5 - 2] = 0;
																									goto IL_04db;
																								}
																								break;
																							}
																							goto IL_034a;
																							IL_042e:
																							ptr2 += 8;
																							break;
																							IL_034a:
																							if (3 <= b)
																							{
																								goto IL_0355;
																							}
																							goto IL_036d;
																							IL_0355:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_036d:
																							if (1 < b)
																							{
																								goto IL_0378;
																							}
																							goto IL_0396;
																							IL_0378:
																							if (2 < b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_0386;
																							IL_0386:
																							if (2 > b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_03cd;
																							IL_03cd:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 14;
																							goto IL_03ff;
																							IL_03ff:
																							ptr2 += 8;
																							goto IL_040d;
																							IL_040d:
																							num5--;
																							break;
																							IL_0396:
																							if (1 > b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_03a4;
																							IL_03a4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03bd;
																							IL_03bd:
																							array[num5] = 0;
																							goto IL_0420;
																							IL_0420:
																							num5++;
																							goto IL_042e;
																						}
																						break;
																					}
																					goto IL_04ee;
																					IL_052d:
																					ptr2 += 8;
																					break;
																					IL_04ee:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0511;
																					IL_0511:
																					array[num5] = 0;
																					goto IL_051f;
																					IL_051f:
																					num5++;
																					goto IL_052d;
																				}
																				break;
																			}
																			goto IL_0540;
																			IL_071a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AppendFormatSetSafeWaitHandle[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			num = 71;
																			goto IL_0777;
																			IL_0540:
																			if (10 < b)
																			{
																				goto IL_054e;
																			}
																			goto IL_05db;
																			IL_054e:
																			if (12 >= b)
																			{
																				goto IL_0559;
																			}
																			goto IL_05af;
																			IL_0559:
																			if (12 <= b)
																			{
																				goto IL_0564;
																			}
																			goto IL_0580;
																			IL_0564:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0580:
																			if (11 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_058e;
																			IL_058e:
																			if (11 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_059c;
																			IL_059c:
																			num5--;
																			break;
																			IL_05af:
																			if (13 < b)
																			{
																				num = 66;
																				goto end_IL_030f;
																			}
																			goto IL_05ba;
																			IL_05ba:
																			if (13 > b)
																			{
																			}
																			goto end_IL_030f;
																			IL_0777:
																			num5--;
																			goto IL_0785;
																			IL_05db:
																			if (10 > b)
																			{
																				goto IL_05e9;
																			}
																			goto IL_0706;
																			IL_05e9:
																			if (8 < b)
																			{
																				goto IL_05f7;
																			}
																			goto IL_0683;
																			IL_05f7:
																			if (9 < b)
																			{
																				goto end_IL_030f;
																			}
																			num = 34;
																			goto IL_060e;
																			IL_0785:
																			ptr2 += 8;
																			break;
																			IL_060e:
																			if (9 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_061c;
																			IL_061c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_065c;
																			IL_065c:
																			array[num5 - 2] = 0;
																			goto IL_0670;
																			IL_0670:
																			num5--;
																			break;
																			IL_0683:
																			if (8 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_0691;
																			IL_0691:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06f3;
																			IL_06f3:
																			num5 -= 2;
																			break;
																			IL_0706:
																			array[num5 - 2] = 0;
																			goto IL_071a;
																		}
																		goto end_IL_031f;
																		continue;
																		end_IL_030f:
																		break;
																		IL_030f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_031f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0840;
												IL_0840:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07a8:
												break;
											}
											continue;
											end_IL_07bb:
											break;
										}
										continue;
										end_IL_07c5:
										break;
									}
									continue;
									end_IL_07d0:
									break;
								}
								continue;
								end_IL_07e5:
								break;
							}
							continue;
							end_IL_07f5:
							break;
						}
						continue;
						end_IL_0805:
						break;
					}
					continue;
					end_IL_0815:
					break;
				}
				continue;
				end_IL_0825:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_4)
	{
		int num = 105;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DecimalDigitNumberToValueTuple.endFunctionResolvedAssemblies);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_0277:
															ptr2++;
															while (true)
															{
																IL_0267:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024a:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_023a:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_022a:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_021a:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_01e6:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 113;
																											while (true)
																											{
																												if (num != 113)
																												{
																													if (num != 1094)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 0:
																													case 11:
																														goto IL_01e6;
																													case 34:
																														goto IL_021a;
																													case 28:
																													case 46:
																														goto IL_022a;
																													case 96:
																														goto IL_023a;
																													case 42:
																														goto IL_024a;
																													case 9:
																														goto IL_0257;
																													case 68:
																														goto IL_0267;
																													case 97:
																														goto IL_0277;
																													case 60:
																													case 100:
																														goto end_IL_01d3;
																													case 15:
																													case 55:
																														goto IL_0292;
																													case 26:
																														goto IL_029d;
																													case 21:
																														goto IL_02a8;
																													case 31:
																													case 63:
																														goto IL_02bb;
																													case 74:
																														goto IL_02ce;
																													case 12:
																													case 16:
																														goto IL_02d9;
																													case 3:
																														goto IL_033d;
																													case 17:
																													case 32:
																														goto IL_0354;
																													case 23:
																													case 75:
																														goto IL_0364;
																													case 2:
																														goto IL_0372;
																													case 78:
																														goto IL_0382;
																													case 87:
																														goto IL_0395;
																													case 88:
																														goto IL_03a8;
																													case 1:
																													case 33:
																														goto IL_03b6;
																													case 81:
																													case 91:
																														goto IL_03e4;
																													case 54:
																														goto IL_03fd;
																													case 73:
																														goto IL_040b;
																													case 49:
																														goto IL_0419;
																													case 92:
																														goto IL_042c;
																													case 77:
																														goto IL_043a;
																													case 19:
																														goto IL_0448;
																													case 86:
																													case 94:
																														goto IL_045b;
																													case 95:
																														goto IL_0477;
																													case 7:
																													case 52:
																														goto IL_0485;
																													case 93:
																														goto IL_04c5;
																													case 24:
																														goto IL_04d9;
																													case 71:
																														goto IL_04fa;
																													case 27:
																													case 64:
																														goto IL_050d;
																													case 18:
																													case 79:
																														goto IL_0518;
																													case 89:
																														goto IL_0526;
																													case 45:
																														goto IL_0539;
																													case 72:
																													case 80:
																														goto IL_0550;
																													case 38:
																													case 106:
																														goto IL_0565;
																													case 58:
																														goto IL_0573;
																													case 51:
																														goto IL_059f;
																													case 37:
																														goto IL_05a9;
																													case 61:
																														goto IL_05b7;
																													case 5:
																													case 13:
																													case 25:
																													case 29:
																													case 43:
																													case 44:
																													case 48:
																													case 50:
																													case 53:
																													case 59:
																													case 62:
																													case 67:
																													case 69:
																													case 82:
																													case 83:
																													case 84:
																													case 85:
																													case 101:
																													case 103:
																														goto end_IL_0257;
																													case 4:
																													case 6:
																													case 10:
																													case 20:
																													case 22:
																													case 36:
																													case 40:
																													case 41:
																													case 56:
																													case 57:
																													case 70:
																													case 76:
																													case 98:
																														goto end_IL_0287;
																													case 35:
																														goto end_IL_05da;
																													case 102:
																														goto end_IL_05ed;
																													case 65:
																														goto end_IL_05f7;
																													case 8:
																														goto end_IL_0602;
																													case 30:
																													case 39:
																														goto end_IL_0617;
																													case 47:
																														goto end_IL_0627;
																													case 14:
																													case 90:
																														goto end_IL_0637;
																													case 104:
																														goto end_IL_0647;
																													case 105:
																														goto end_IL_0657;
																													case 66:
																													case 99:
																														goto IL_0672;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto IL_04fa;
																												IL_04fa:
																												num5--;
																												goto end_IL_0287;
																												continue;
																												end_IL_01d3:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0364;
																									IL_0419:
																									ptr2 += 8;
																									goto end_IL_0287;
																									IL_0364:
																									if (1 < b)
																									{
																										goto end_IL_0257;
																									}
																									goto IL_0372;
																									IL_0372:
																									if (1 > b)
																									{
																										goto end_IL_0257;
																									}
																									goto IL_03e4;
																									IL_03e4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_03fd;
																									IL_03fd:
																									array[num5] = 0;
																									goto IL_040b;
																									IL_040b:
																									num5++;
																									goto IL_0419;
																								}
																								break;
																							}
																							goto IL_050d;
																							IL_0550:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0287;
																							IL_050d:
																							if (3 < b)
																							{
																								goto IL_0518;
																							}
																							goto IL_0539;
																							IL_0518:
																							if (4 < b)
																							{
																								goto end_IL_0257;
																							}
																							goto IL_0526;
																							IL_0526:
																							if (4 > b)
																							{
																								goto end_IL_0257;
																							}
																							goto end_IL_0287;
																							IL_0539:
																							if (3 > b)
																							{
																								goto end_IL_0257;
																							}
																							num = 80;
																							goto IL_0550;
																						}
																						break;
																					}
																					goto IL_0565;
																					IL_05b7:
																					ptr2 += 8;
																					goto end_IL_0287;
																					IL_0565:
																					array[num5] = 0;
																					goto IL_0573;
																					IL_0573:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 51;
																					goto IL_059f;
																					IL_059f:
																					array2[num5] = null;
																					goto IL_05a9;
																					IL_05a9:
																					num5++;
																					goto IL_05b7;
																				}
																				break;
																			}
																			goto IL_0292;
																			IL_04c5:
																			array[num5 - 2] = 0;
																			goto IL_04d9;
																			IL_0292:
																			if (8 < b)
																			{
																				goto IL_029d;
																			}
																			goto IL_02ce;
																			IL_029d:
																			if (9 >= b)
																			{
																				goto IL_02a8;
																			}
																			goto IL_02bb;
																			IL_02a8:
																			if (9 > b)
																			{
																				goto end_IL_0257;
																			}
																			goto IL_045b;
																			IL_045b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0287;
																			IL_02bb:
																			if (10 < b)
																			{
																				goto end_IL_0257;
																			}
																			goto IL_0395;
																			IL_0395:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_0257;
																			IL_02ce:
																			if (8 <= b)
																			{
																				goto IL_02d9;
																			}
																			goto IL_033d;
																			IL_02d9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0382;
																			IL_0382:
																			num5 -= 2;
																			goto end_IL_0287;
																			IL_033d:
																			if (6 < b)
																			{
																				num = 17;
																				goto IL_0354;
																			}
																			goto IL_0477;
																			IL_04d9:
																			num5--;
																			goto end_IL_0287;
																			IL_0354:
																			if (7 < b)
																			{
																				goto end_IL_0257;
																			}
																			goto IL_03a8;
																			IL_03a8:
																			if (7 > b)
																			{
																				goto end_IL_0257;
																			}
																			goto IL_03b6;
																			IL_03b6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 92;
																			goto IL_042c;
																			IL_042c:
																			array[num5] = 0;
																			goto IL_043a;
																			IL_043a:
																			num5++;
																			goto IL_0448;
																			IL_0448:
																			ptr2 += 8;
																			goto end_IL_0287;
																			IL_0477:
																			if (6 > b)
																			{
																				goto end_IL_0257;
																			}
																			goto IL_0485;
																			IL_0485:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04c5;
																		}
																		goto end_IL_0267;
																		continue;
																		end_IL_0257:
																		break;
																		IL_0257:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0287;
																continue;
																end_IL_0267:
																break;
															}
															break;
														}
														continue;
														end_IL_0287:
														break;
													}
													continue;
												}
												goto IL_0672;
												IL_0672:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05da:
												break;
											}
											continue;
											end_IL_05ed:
											break;
										}
										continue;
										end_IL_05f7:
										break;
									}
									continue;
									end_IL_0602:
									break;
								}
								continue;
								end_IL_0617:
								break;
							}
							continue;
							end_IL_0627:
							break;
						}
						continue;
						end_IL_0637:
						break;
					}
					continue;
					end_IL_0647:
					break;
				}
				continue;
				end_IL_0657:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_4)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 110;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MediaStopISectionWithReferenceIdentityKey.SoapAttributeTypeMethodResponse);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 28;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a4:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0284:
																				if (6 >= b)
																				{
																					goto IL_0450;
																				}
																				while (true)
																				{
																					IL_0277:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0267:
																							if (9 <= b)
																							{
																								while (true)
																								{
																									IL_01fa:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 118;
																									while (true)
																									{
																										if (num != 118)
																										{
																											if (num != 1099)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 34:
																											case 79:
																												goto IL_01fa;
																											case 23:
																												goto IL_0267;
																											case 11:
																											case 100:
																												goto IL_0277;
																											case 0:
																												goto IL_0284;
																											case 77:
																												goto end_IL_0284;
																											case 98:
																												goto IL_02a4;
																											case 2:
																												goto end_IL_02a4;
																											case 28:
																												goto end_IL_02b4;
																											case 99:
																												goto end_IL_02c4;
																											case 24:
																											case 30:
																												goto IL_02da;
																											case 21:
																												goto IL_02e5;
																											case 64:
																												goto IL_02fe;
																											case 75:
																												goto IL_030e;
																											case 17:
																											case 111:
																												goto IL_032a;
																											case 80:
																												goto IL_0359;
																											case 89:
																												goto IL_0364;
																											case 9:
																											case 50:
																												goto IL_0372;
																											case 52:
																												goto IL_03b2;
																											case 32:
																												goto IL_03c6;
																											case 39:
																											case 58:
																												goto IL_03d9;
																											case 35:
																												goto IL_03f0;
																											case 60:
																											case 95:
																												goto IL_03fe;
																											case 45:
																												goto IL_0421;
																											case 43:
																												goto IL_042f;
																											case 15:
																												goto IL_043d;
																											case 105:
																												goto IL_0450;
																											case 46:
																											case 81:
																												goto IL_045e;
																											case 69:
																												goto IL_046c;
																											case 70:
																											case 87:
																												goto end_IL_01e7;
																											case 101:
																												goto IL_0485;
																											case 37:
																											case 55:
																												goto IL_0493;
																											case 33:
																												goto IL_04ac;
																											case 54:
																												goto IL_04c3;
																											case 104:
																												goto IL_04d1;
																											case 78:
																												goto IL_04e4;
																											case 90:
																												goto IL_04f2;
																											case 47:
																											case 49:
																												goto IL_0500;
																											case 82:
																												goto IL_0529;
																											case 68:
																												goto IL_0537;
																											case 88:
																											case 103:
																												goto IL_054a;
																											case 40:
																												goto IL_0562;
																											case 8:
																												goto IL_056d;
																											case 106:
																												goto IL_0580;
																											case 86:
																												goto IL_058e;
																											case 59:
																											case 61:
																												goto IL_059c;
																											case 76:
																												goto IL_05aa;
																											case 93:
																												goto IL_05cd;
																											case 94:
																												goto IL_05d7;
																											case 108:
																												goto IL_05e5;
																											case 13:
																											case 96:
																												goto IL_05f5;
																											case 74:
																												goto IL_0635;
																											case 22:
																												goto IL_0649;
																											case 1:
																											case 14:
																											case 18:
																											case 19:
																											case 27:
																											case 44:
																											case 53:
																											case 57:
																											case 63:
																											case 66:
																											case 67:
																											case 71:
																											case 73:
																											case 83:
																											case 84:
																											case 91:
																											case 102:
																											case 107:
																											case 109:
																												goto end_IL_0294;
																											case 3:
																											case 12:
																											case 20:
																											case 25:
																											case 26:
																											case 29:
																											case 36:
																											case 38:
																											case 41:
																											case 42:
																											case 48:
																											case 65:
																											case 72:
																											case 97:
																												goto end_IL_02cf;
																											case 56:
																												goto end_IL_066c;
																											case 85:
																												goto end_IL_067f;
																											case 51:
																												goto end_IL_0689;
																											case 16:
																												goto end_IL_0694;
																											case 5:
																											case 31:
																												goto end_IL_06a9;
																											case 10:
																												goto end_IL_06b9;
																											case 4:
																											case 110:
																												goto end_IL_06c9;
																											case 6:
																												goto end_IL_06d9;
																											case 7:
																												goto end_IL_06e9;
																											case 62:
																											case 92:
																												goto IL_070d;
																											}
																											continue;
																										}
																										num5 -= 2;
																										goto end_IL_02cf;
																										continue;
																										end_IL_01e7:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0359;
																							IL_042f:
																							num5++;
																							goto IL_043d;
																							IL_0359:
																							if (7 >= b)
																							{
																								goto IL_0364;
																							}
																							goto IL_03d9;
																							IL_0364:
																							if (7 > b)
																							{
																								goto end_IL_0294;
																							}
																							goto IL_0372;
																							IL_0372:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03b2;
																							IL_03b2:
																							array[num5 - 2] = 0;
																							goto IL_03c6;
																							IL_03c6:
																							num5--;
																							goto end_IL_02cf;
																							IL_03d9:
																							if (8 < b)
																							{
																								goto end_IL_0294;
																							}
																							num = 35;
																							goto IL_03f0;
																							IL_043d:
																							ptr2 += 8;
																							goto end_IL_02cf;
																							IL_03f0:
																							if (8 > b)
																							{
																								goto end_IL_0294;
																							}
																							goto IL_03fe;
																							IL_03fe:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0421;
																							IL_0421:
																							array[num5] = 0;
																							goto IL_042f;
																						}
																						break;
																					}
																					goto IL_02da;
																					IL_032a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02cf;
																					IL_02da:
																					if (10 < b)
																					{
																						goto IL_02e5;
																					}
																					goto IL_02fe;
																					IL_02e5:
																					if (11 < b)
																					{
																						goto end_IL_0294;
																					}
																					num = 75;
																					goto IL_030e;
																					IL_02fe:
																					if (10 > b)
																					{
																						goto end_IL_0294;
																					}
																					goto IL_032a;
																					IL_030e:
																					if (11 <= b)
																					{
																						num = 73;
																					}
																					goto end_IL_0294;
																				}
																				goto IL_047a;
																				IL_0649:
																				num5--;
																				goto end_IL_02cf;
																				IL_0450:
																				if (6 > b)
																				{
																					goto IL_045e;
																				}
																				goto IL_05f5;
																				IL_045e:
																				if (3 >= b)
																				{
																					goto IL_046c;
																				}
																				goto IL_0562;
																				IL_046c:
																				if (3 > b)
																				{
																					goto IL_047a;
																				}
																				goto IL_054a;
																				IL_047a:
																				if (1 >= b)
																				{
																					goto IL_0485;
																				}
																				goto IL_04e4;
																				IL_0485:
																				if (1 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_0493;
																				IL_0493:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04ac;
																				IL_04ac:
																				array[num5] = 0;
																				num = 54;
																				goto IL_04c3;
																				IL_04c3:
																				num5++;
																				goto IL_04d1;
																				IL_04d1:
																				ptr2 += 8;
																				goto end_IL_02cf;
																				IL_04e4:
																				if (2 < b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_04f2;
																				IL_04f2:
																				if (2 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_0500;
																				IL_0500:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0529;
																				IL_0529:
																				ptr2 += 8;
																				goto IL_0537;
																				IL_0537:
																				num5--;
																				goto end_IL_02cf;
																				IL_054a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02cf;
																				IL_0562:
																				if (4 >= b)
																				{
																					goto IL_056d;
																				}
																				goto IL_0580;
																				IL_056d:
																				if (4 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto end_IL_02cf;
																				IL_0580:
																				if (5 < b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_058e;
																				IL_058e:
																				if (5 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_059c;
																				IL_059c:
																				array[num5] = 0;
																				goto IL_05aa;
																				IL_05aa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05cd;
																				IL_05cd:
																				array2[num5] = null;
																				goto IL_05d7;
																				IL_05d7:
																				num5++;
																				goto IL_05e5;
																				IL_05e5:
																				ptr2 += 8;
																				goto end_IL_02cf;
																				IL_05f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0635;
																				IL_0635:
																				array[num5 - 2] = 0;
																				goto IL_0649;
																				continue;
																				end_IL_0284:
																				break;
																			}
																			continue;
																			end_IL_0294:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02cf;
																	continue;
																	end_IL_02a4:
																	break;
																}
																continue;
																end_IL_02b4:
																break;
															}
															continue;
															end_IL_02c4:
															break;
														}
														continue;
														end_IL_02cf:
														break;
													}
													continue;
												}
												goto IL_070d;
												IL_070d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_066c:
												break;
											}
											continue;
											end_IL_067f:
											break;
										}
										continue;
										end_IL_0689:
										break;
									}
									continue;
									end_IL_0694:
									break;
								}
								continue;
								end_IL_06a9:
								break;
							}
							continue;
							end_IL_06b9:
							break;
						}
						continue;
						end_IL_06c9:
						break;
					}
					continue;
					end_IL_06d9:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private static int smethod_3(int int_4, int int_5)
	{
		int num = int_4;
		int num2 = int_5;
		num += num2;
		int num3 = num;
		num = int_4;
		num2 = int_5;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 198;
		num2 = 18;
		return num + 18;
	}

	private unsafe static int smethod_4(int int_4)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 88;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									num = 64;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetByteExceptionState.GetRuntimePropertiesStindR);
										num = 6;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 94;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0244:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0224:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0214:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0207:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_01f7:
																										if (6 >= b)
																										{
																											while (6 <= b)
																											{
																												num = 109;
																												while (true)
																												{
																													if (num != 109)
																													{
																														if (num != 1090)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 72:
																															goto IL_01e4;
																														case 92:
																															goto IL_01f7;
																														case 24:
																															goto IL_0207;
																														case 50:
																															goto IL_0214;
																														case 25:
																															goto IL_0224;
																														case 36:
																															goto IL_0234;
																														case 57:
																															goto IL_0244;
																														case 77:
																															goto end_IL_0244;
																														case 40:
																														case 48:
																															goto end_IL_0254;
																														case 47:
																														case 65:
																															goto IL_026f;
																														case 59:
																															goto IL_02d1;
																														case 78:
																															goto IL_02e4;
																														case 20:
																														case 37:
																															goto IL_02ef;
																														case 45:
																															goto IL_02fd;
																														case 80:
																															goto IL_0325;
																														case 2:
																														case 26:
																															goto end_IL_01d1;
																														case 56:
																														case 60:
																															goto IL_033b;
																														case 67:
																															goto IL_0349;
																														case 70:
																															goto IL_035c;
																														case 17:
																														case 52:
																															goto IL_036a;
																														case 53:
																															goto IL_0382;
																														case 44:
																															goto IL_038d;
																														case 7:
																														case 76:
																															goto IL_03a9;
																														case 62:
																															goto IL_03d2;
																														case 32:
																															goto IL_03e0;
																														case 81:
																														case 91:
																															goto IL_03f3;
																														case 93:
																															goto IL_0401;
																														case 18:
																														case 19:
																															goto IL_040f;
																														case 90:
																															goto IL_0432;
																														case 12:
																															goto IL_0440;
																														case 43:
																															goto IL_044e;
																														case 98:
																															goto IL_0461;
																														case 11:
																														case 74:
																															goto IL_046f;
																														case 58:
																															goto IL_0488;
																														case 99:
																															goto IL_04a1;
																														case 34:
																															goto IL_04ab;
																														case 68:
																															goto IL_04b9;
																														case 101:
																															goto IL_04cc;
																														case 89:
																															goto IL_04e3;
																														case 84:
																															goto IL_04f6;
																														case 87:
																															goto IL_0536;
																														case 31:
																															goto IL_054a;
																														case 83:
																															goto IL_055a;
																														case 5:
																															goto IL_0565;
																														case 63:
																														case 71:
																															goto IL_0570;
																														case 46:
																														case 97:
																															goto IL_0589;
																														case 42:
																															goto IL_0594;
																														case 1:
																														case 4:
																														case 10:
																														case 16:
																														case 21:
																														case 28:
																														case 33:
																														case 35:
																														case 41:
																														case 49:
																														case 54:
																														case 55:
																														case 66:
																														case 69:
																														case 73:
																														case 79:
																														case 100:
																														case 102:
																															goto end_IL_01e4;
																														case 0:
																														case 13:
																														case 14:
																														case 15:
																														case 29:
																														case 30:
																														case 38:
																														case 51:
																														case 61:
																														case 85:
																														case 86:
																														case 94:
																															goto end_IL_0264;
																														case 3:
																															goto end_IL_05bb;
																														case 6:
																															goto end_IL_05ce;
																														case 64:
																															goto end_IL_05d9;
																														case 95:
																															goto end_IL_05e3;
																														case 39:
																															goto end_IL_05f7;
																														case 22:
																														case 75:
																															goto end_IL_0615;
																														case 82:
																															goto end_IL_0625;
																														case 27:
																														case 88:
																															goto end_IL_0635;
																														case 8:
																															goto end_IL_0645;
																														case 9:
																															goto end_IL_0655;
																														case 23:
																														case 96:
																															goto IL_0679;
																														}
																														continue;
																													}
																													goto IL_04f6;
																													IL_0536:
																													array[num5 - 2] = 0;
																													goto IL_054a;
																													IL_054a:
																													num5--;
																													goto end_IL_0264;
																													IL_04f6:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0536;
																													continue;
																													end_IL_01d1:
																													break;
																												}
																												goto IL_0330;
																												continue;
																												end_IL_01e4:
																												break;
																												IL_01e4:;
																											}
																											break;
																										}
																										goto IL_03f3;
																										IL_044e:
																										ptr2 += 8;
																										goto end_IL_0264;
																										IL_03f3:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0401;
																										IL_0401:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_040f;
																										IL_040f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0432;
																										IL_0432:
																										array[num5] = 0;
																										goto IL_0440;
																										IL_0440:
																										num5++;
																										goto IL_044e;
																									}
																									break;
																								}
																								goto IL_026f;
																								IL_02d1:
																								num5 -= 2;
																								goto end_IL_0264;
																								IL_026f:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_02d1;
																							}
																							break;
																						}
																						goto IL_055a;
																						IL_0594:
																						if (10 <= b)
																						{
																							num = 16;
																						}
																						break;
																						IL_055a:
																						if (9 >= b)
																						{
																							goto IL_0565;
																						}
																						goto IL_0589;
																						IL_0565:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0570;
																						IL_0570:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0264;
																						IL_0589:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0594;
																					}
																					break;
																				}
																				goto IL_02e4;
																				IL_03d2:
																				ptr2 += 8;
																				goto IL_03e0;
																				IL_02e4:
																				if (5 <= b)
																				{
																					goto IL_02ef;
																				}
																				goto IL_0325;
																				IL_02ef:
																				array[num5] = 0;
																				goto IL_02fd;
																				IL_02fd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04a1;
																				IL_04a1:
																				array2[num5] = null;
																				goto IL_04ab;
																				IL_04ab:
																				num5++;
																				goto IL_04b9;
																				IL_04b9:
																				ptr2 += 8;
																				goto end_IL_0264;
																				IL_0325:
																				if (2 < b)
																				{
																					goto IL_0330;
																				}
																				goto IL_0382;
																				IL_0330:
																				if (3 < b)
																				{
																					goto IL_033b;
																				}
																				goto IL_035c;
																				IL_033b:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0349;
																				IL_0349:
																				if (4 <= b)
																				{
																					goto end_IL_0264;
																				}
																				break;
																				IL_035c:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_036a;
																				IL_036a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0264;
																				IL_0382:
																				if (2 > b)
																				{
																					goto IL_038d;
																				}
																				num = 76;
																				goto IL_03a9;
																				IL_038d:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0461;
																				IL_0461:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_046f;
																				IL_046f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0488;
																				IL_0488:
																				array[num5] = 0;
																				num = 101;
																				goto IL_04cc;
																				IL_04cc:
																				num5++;
																				num = 89;
																				goto IL_04e3;
																				IL_04e3:
																				ptr2 += 8;
																				goto end_IL_0264;
																				IL_03e0:
																				num5--;
																				goto end_IL_0264;
																				IL_03a9:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03d2;
																			}
																			break;
																			IL_0234:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0264;
																	continue;
																	end_IL_0244:
																	break;
																}
																continue;
																end_IL_0254:
																break;
															}
															continue;
															end_IL_0264:
															break;
														}
														continue;
													}
													goto IL_0679;
													IL_0679:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05bb:
													break;
												}
												continue;
												end_IL_05ce:
												break;
											}
											continue;
											end_IL_05d9:
											break;
										}
										continue;
										end_IL_05e3:
										break;
									}
									continue;
									end_IL_05f7:
									break;
								}
								continue;
								end_IL_0615:
								break;
							}
							continue;
							end_IL_0625:
							break;
						}
						continue;
						end_IL_0635:
						break;
					}
					continue;
					end_IL_0645:
					break;
				}
				continue;
				end_IL_0655:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_4)
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									num = 25;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExecuteAssemblyCrossProcess.LoadPolicyLevelFromFilegetTargetTypeName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02a1:
														num = 14;
														while (true)
														{
															IL_0296:
															byte b = *ptr2;
															while (true)
															{
																IL_0286:
																ptr2++;
																while (true)
																{
																	IL_0276:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0259:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0249:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_023c:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_022c:
																										if (3 <= b)
																										{
																											while (true)
																											{
																												IL_020e:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												num = 123;
																												while (num != 123)
																												{
																													if (num != 1104)
																													{
																														goto IL_03b7;
																													}
																													switch (num)
																													{
																													case 17:
																													case 75:
																														goto IL_020e;
																													case 48:
																														goto IL_022c;
																													case 64:
																													case 106:
																														goto IL_023c;
																													case 59:
																														goto IL_0249;
																													case 69:
																														goto IL_0259;
																													case 12:
																														goto IL_0266;
																													case 82:
																														goto IL_0276;
																													case 8:
																														goto IL_0286;
																													case 14:
																														goto IL_0296;
																													case 114:
																														goto IL_02a1;
																													case 4:
																													case 7:
																														goto IL_02ac;
																													case 6:
																													case 39:
																														goto IL_02bc;
																													case 5:
																														goto IL_02ca;
																													case 36:
																														goto IL_02d5;
																													case 0:
																														goto IL_02e5;
																													case 2:
																													case 62:
																														goto IL_02f5;
																													case 63:
																														goto IL_0311;
																													case 78:
																														goto IL_0324;
																													case 51:
																													case 87:
																														goto IL_0337;
																													case 55:
																														goto IL_0345;
																													case 56:
																													case 90:
																														goto IL_0361;
																													case 32:
																														goto IL_036f;
																													case 33:
																													case 58:
																														goto IL_0386;
																													case 9:
																														goto IL_0394;
																													case 49:
																														goto IL_03b7;
																													case 66:
																														goto IL_03c1;
																													case 3:
																														goto IL_03cf;
																													case 100:
																														goto IL_03e2;
																													case 73:
																													case 79:
																														goto IL_03f0;
																													case 27:
																														goto IL_0419;
																													case 38:
																														goto IL_0430;
																													case 101:
																														goto IL_0443;
																													case 37:
																													case 68:
																														goto IL_0451;
																													case 71:
																														goto IL_046a;
																													case 44:
																														goto IL_0478;
																													case 52:
																														goto IL_0486;
																													case 112:
																														goto IL_0499;
																													case 30:
																														goto IL_04a7;
																													case 15:
																													case 111:
																														goto IL_04b2;
																													case 99:
																														goto IL_04c0;
																													case 53:
																													case 91:
																														goto IL_04ce;
																													case 86:
																														goto IL_04f6;
																													case 72:
																													case 74:
																														goto IL_0501;
																													case 40:
																														goto IL_0541;
																													case 23:
																														goto IL_0555;
																													case 10:
																													case 16:
																													case 20:
																													case 24:
																													case 26:
																													case 28:
																													case 35:
																													case 46:
																													case 50:
																													case 57:
																													case 61:
																													case 76:
																													case 77:
																													case 81:
																													case 85:
																													case 92:
																													case 93:
																													case 95:
																													case 98:
																													case 103:
																													case 104:
																													case 105:
																													case 109:
																														goto end_IL_0266;
																													case 18:
																													case 42:
																														goto IL_0580;
																													case 108:
																														goto IL_05e2;
																													case 115:
																														goto IL_05f5;
																													case 113:
																														goto IL_0603;
																													case 70:
																														goto IL_0611;
																													case 1:
																													case 45:
																														goto IL_0621;
																													case 21:
																														goto IL_0661;
																													case 84:
																														goto IL_0675;
																													case 13:
																													case 31:
																													case 41:
																													case 43:
																													case 47:
																													case 65:
																													case 80:
																													case 83:
																													case 94:
																													case 96:
																													case 97:
																													case 102:
																													case 107:
																														goto end_IL_01fb;
																													case 110:
																														goto end_IL_0683;
																													case 25:
																														goto end_IL_0696;
																													case 11:
																														goto end_IL_06a0;
																													case 19:
																														goto end_IL_06ab;
																													case 60:
																													case 116:
																														goto end_IL_06c9;
																													case 67:
																														goto end_IL_06d9;
																													case 34:
																													case 54:
																														goto end_IL_06e9;
																													case 88:
																														goto end_IL_06f9;
																													case 89:
																														goto end_IL_0709;
																													case 22:
																													case 29:
																														goto IL_072d;
																													}
																													continue;
																													end_IL_01fb:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0337;
																										IL_0478:
																										num5++;
																										goto IL_0486;
																										IL_0337:
																										if (1 < b)
																										{
																											goto IL_0345;
																										}
																										goto IL_0443;
																										IL_0345:
																										if (2 < b)
																										{
																											num = 35;
																											goto end_IL_0266;
																										}
																										goto IL_03e2;
																										IL_0486:
																										ptr2 += 8;
																										break;
																										IL_03e2:
																										if (2 > b)
																										{
																											goto end_IL_0266;
																										}
																										goto IL_03f0;
																										IL_03f0:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0419;
																										IL_0419:
																										ptr2 += 8;
																										num = 38;
																										goto IL_0430;
																										IL_0430:
																										num5--;
																										break;
																										IL_0443:
																										if (1 > b)
																										{
																											goto end_IL_0266;
																										}
																										goto IL_0451;
																										IL_0451:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_046a;
																										IL_046a:
																										array[num5] = 0;
																										goto IL_0478;
																									}
																									break;
																								}
																								goto IL_02ac;
																								IL_03cf:
																								ptr2 += 8;
																								break;
																								IL_02ac:
																								if (4 >= b)
																								{
																									goto IL_0311;
																								}
																								goto IL_0361;
																								IL_0361:
																								if (5 < b)
																								{
																									goto end_IL_0266;
																								}
																								goto IL_036f;
																								IL_036f:
																								if (5 > b)
																								{
																									goto end_IL_0266;
																								}
																								num = 58;
																								goto IL_0386;
																								IL_0311:
																								if (4 > b)
																								{
																									goto end_IL_0266;
																								}
																								break;
																								IL_0386:
																								array[num5] = 0;
																								goto IL_0394;
																								IL_0394:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03b7;
																								IL_03b7:
																								array2[num5] = null;
																								goto IL_03c1;
																								IL_03c1:
																								num5++;
																								goto IL_03cf;
																							}
																							break;
																						}
																						goto IL_0621;
																						IL_0675:
																						num5--;
																						break;
																						IL_0621:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0661;
																						IL_0661:
																						array[num5 - 2] = 0;
																						goto IL_0675;
																					}
																					break;
																				}
																				goto IL_02bc;
																				IL_05e2:
																				num5 -= 2;
																				break;
																				IL_02bc:
																				if (9 < b)
																				{
																					goto IL_02ca;
																				}
																				goto IL_0499;
																				IL_02ca:
																				if (10 >= b)
																				{
																					goto IL_02d5;
																				}
																				goto IL_02e5;
																				IL_02d5:
																				if (10 > b)
																				{
																					goto end_IL_0266;
																				}
																				goto IL_02f5;
																				IL_02f5:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_02e5:
																				if (11 < b)
																				{
																					goto end_IL_0266;
																				}
																				goto IL_0324;
																				IL_0324:
																				if (11 > b)
																				{
																				}
																				goto end_IL_0266;
																				IL_0499:
																				if (9 > b)
																				{
																					goto IL_04a7;
																				}
																				goto IL_0580;
																				IL_04a7:
																				if (7 < b)
																				{
																					goto IL_04b2;
																				}
																				goto IL_04f6;
																				IL_04b2:
																				if (8 < b)
																				{
																					goto end_IL_0266;
																				}
																				goto IL_04c0;
																				IL_04c0:
																				if (8 > b)
																				{
																					goto end_IL_0266;
																				}
																				goto IL_04ce;
																				IL_04ce:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05f5;
																				IL_05f5:
																				array[num5] = 0;
																				goto IL_0603;
																				IL_0603:
																				num5++;
																				goto IL_0611;
																				IL_0611:
																				ptr2 += 8;
																				break;
																				IL_04f6:
																				if (7 > b)
																				{
																					goto end_IL_0266;
																				}
																				goto IL_0501;
																				IL_0501:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0541;
																				IL_0541:
																				array[num5 - 2] = 0;
																				goto IL_0555;
																				IL_0555:
																				num5--;
																				break;
																				IL_0580:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05e2;
																			}
																			goto end_IL_0276;
																			continue;
																			end_IL_0266:
																			break;
																			IL_0266:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0276:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 29;
												goto IL_072d;
												IL_072d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0683:
												break;
											}
											continue;
											end_IL_0696:
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c9:
								break;
							}
							continue;
							end_IL_06d9:
							break;
						}
						continue;
						end_IL_06e9:
						break;
					}
					continue;
					end_IL_06f9:
					break;
				}
				continue;
				end_IL_0709:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_4, int int_5)
	{
		int num = 15;
		int num4 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClassInterfaceAttributeSEPAm.getIsAttachedcount);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_019b:
															num = 95;
															while (true)
															{
																if (num != 95)
																{
																	if (num != 1076)
																	{
																		break;
																	}
																	switch (num)
																	{
																	case 41:
																		goto IL_019b;
																	case 57:
																		goto IL_01af;
																	case 82:
																		goto IL_01bd;
																	case 64:
																		goto IL_01cb;
																	case 54:
																		goto IL_01d9;
																	case 25:
																		goto IL_01e7;
																	case 0:
																	case 1:
																		goto IL_01f2;
																	case 3:
																		goto IL_021b;
																	case 7:
																		goto IL_0229;
																	case 53:
																		goto IL_023c;
																	case 10:
																		goto IL_024a;
																	case 45:
																	case 46:
																		goto IL_0255;
																	case 19:
																		goto IL_0263;
																	case 2:
																	case 43:
																		goto IL_0276;
																	case 39:
																		goto IL_02e4;
																	case 38:
																		goto IL_02f7;
																	case 6:
																		goto IL_0305;
																	case 40:
																	case 84:
																		goto IL_0313;
																	case 52:
																		goto IL_0353;
																	case 16:
																		goto IL_0367;
																	case 22:
																	case 61:
																		goto IL_037a;
																	case 42:
																		goto IL_0385;
																	case 24:
																		goto IL_0393;
																	case 33:
																		goto IL_03a1;
																	case 49:
																	case 86:
																		goto IL_03af;
																	case 37:
																	case 85:
																		goto IL_03d0;
																	case 62:
																		goto IL_03db;
																	case 60:
																	case 88:
																		goto IL_03f2;
																	case 44:
																		goto IL_0400;
																	case 67:
																		goto IL_0423;
																	case 77:
																		goto IL_042d;
																	case 56:
																		goto IL_043b;
																	case 18:
																		goto IL_044b;
																	case 35:
																		goto IL_0456;
																	case 23:
																	case 79:
																		goto IL_0461;
																	case 5:
																	case 8:
																	case 11:
																	case 12:
																	case 17:
																	case 20:
																	case 26:
																	case 29:
																	case 30:
																	case 48:
																	case 58:
																	case 66:
																	case 68:
																	case 69:
																	case 73:
																	case 76:
																	case 81:
																		goto IL_047a;
																	case 65:
																		goto IL_049d;
																	case 27:
																		goto IL_04ab;
																	case 75:
																		goto IL_04b9;
																	case 9:
																	case 13:
																	case 21:
																	case 28:
																	case 47:
																	case 50:
																	case 59:
																	case 70:
																	case 71:
																	case 78:
																	case 80:
																		goto end_IL_018b;
																	case 36:
																		goto end_IL_04c7;
																	case 87:
																		goto end_IL_04da;
																	case 72:
																		goto end_IL_04e4;
																	case 4:
																		goto end_IL_04ef;
																	case 83:
																		goto end_IL_0504;
																	case 34:
																	case 74:
																		goto end_IL_0519;
																	case 51:
																		goto end_IL_0529;
																	case 31:
																	case 32:
																		goto end_IL_0539;
																	case 14:
																		goto end_IL_0549;
																	case 15:
																		goto end_IL_0559;
																	case 55:
																	case 63:
																		goto IL_057d;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_01af;
																IL_0461:
																byte* num5 = ptr2;
																num4 = 1;
																ptr2 = num5 + -200;
																break;
																IL_049d:
																array[num6] = 0;
																goto IL_04ab;
																IL_047a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_049d;
																IL_01af:
																ptr2++;
																goto IL_01bd;
																IL_01bd:
																if (b >= 1)
																{
																	goto IL_01cb;
																}
																goto IL_047a;
																IL_01cb:
																if (b <= 8)
																{
																	goto IL_01d9;
																}
																goto IL_047a;
																IL_01d9:
																if (4 >= b)
																{
																	goto IL_01e7;
																}
																goto IL_037a;
																IL_01e7:
																if (4 <= b)
																{
																	goto IL_01f2;
																}
																goto IL_023c;
																IL_01f2:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_021b;
																IL_021b:
																ptr2 += 8;
																goto IL_0229;
																IL_0229:
																num6--;
																break;
																IL_023c:
																if (2 >= b)
																{
																	goto IL_024a;
																}
																goto IL_02f7;
																IL_024a:
																if (2 > b)
																{
																	goto IL_0255;
																}
																goto IL_0276;
																IL_0255:
																if (1 >= b)
																{
																	goto IL_0263;
																}
																goto IL_047a;
																IL_0263:
																if (1 <= b)
																{
																}
																goto IL_047a;
																IL_0276:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_02e4;
																IL_02e4:
																num6 -= 2;
																break;
																IL_02f7:
																if (3 >= b)
																{
																	goto IL_0305;
																}
																goto IL_047a;
																IL_0305:
																if (3 <= b)
																{
																	goto IL_0313;
																}
																goto IL_047a;
																IL_0313:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0353;
																IL_0353:
																array[num6 - 2] = 0;
																goto IL_0367;
																IL_0367:
																num6--;
																break;
																IL_037a:
																if (6 >= b)
																{
																	goto IL_0385;
																}
																num = 85;
																goto IL_03d0;
																IL_0385:
																if (6 <= b)
																{
																	break;
																}
																goto IL_0393;
																IL_0393:
																if (5 >= b)
																{
																	goto IL_03a1;
																}
																goto IL_047a;
																IL_03a1:
																if (5 <= b)
																{
																	goto IL_03af;
																}
																goto IL_047a;
																IL_03af:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_04ab:
																num6++;
																goto IL_04b9;
																IL_03d0:
																if (7 >= b)
																{
																	goto IL_03db;
																}
																goto IL_044b;
																IL_03db:
																if (7 <= b)
																{
																	num = 60;
																	goto IL_03f2;
																}
																goto IL_047a;
																IL_04b9:
																ptr2 += 8;
																break;
																IL_03f2:
																array[num6] = 0;
																goto IL_0400;
																IL_0400:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0423;
																IL_0423:
																array2[num6] = null;
																goto IL_042d;
																IL_042d:
																num6++;
																goto IL_043b;
																IL_043b:
																ptr2 += 8;
																break;
																IL_044b:
																if (8 >= b)
																{
																	goto IL_0456;
																}
																goto IL_047a;
																IL_0456:
																if (8 <= b)
																{
																	goto IL_0461;
																}
																goto IL_047a;
																continue;
																end_IL_018b:
																break;
															}
															break;
														}
														continue;
													}
													num = 55;
													goto IL_057d;
													IL_057d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04c7:
													break;
												}
												continue;
												end_IL_04da:
												break;
											}
											continue;
											end_IL_04e4:
											break;
										}
										continue;
										end_IL_04ef:
										break;
									}
									continue;
									end_IL_0504:
									break;
								}
								continue;
								end_IL_0519:
								break;
							}
							continue;
							end_IL_0529:
							break;
						}
						continue;
						end_IL_0539:
						break;
					}
					continue;
					end_IL_0549:
					break;
				}
				continue;
				end_IL_0559:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_4, int int_5)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 48;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 73;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										num = 72;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ManagedIsPinvokeImpl.TupleExtensionsTokenListCount);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 96;
																while (true)
																{
																	if (num != 96)
																	{
																		if (num == 1077)
																		{
																			switch (num)
																			{
																			case 16:
																				goto end_IL_018f;
																			case 4:
																			case 22:
																				goto end_IL_019f;
																			case 5:
																				goto IL_01d1;
																			case 61:
																				goto IL_01df;
																			case 19:
																			case 35:
																				goto IL_01ed;
																			case 58:
																				goto IL_01f8;
																			case 67:
																				goto IL_0206;
																			case 64:
																				goto IL_0214;
																			case 13:
																			case 25:
																				goto IL_0222;
																			case 29:
																				goto IL_023a;
																			case 6:
																			case 68:
																				goto IL_0245;
																			case 81:
																				goto IL_0253;
																			case 14:
																			case 32:
																				goto IL_0261;
																			case 87:
																				goto IL_027d;
																			case 9:
																			case 23:
																				goto IL_0294;
																			case 42:
																				goto IL_02a2;
																			case 65:
																				goto IL_02c5;
																			case 11:
																				goto IL_02cf;
																			case 20:
																				goto IL_02dd;
																			case 8:
																				goto IL_02f0;
																			case 12:
																			case 15:
																				goto IL_02fb;
																			case 71:
																				goto IL_0324;
																			case 46:
																				goto IL_0332;
																			case 31:
																				goto IL_0345;
																			case 0:
																				goto IL_0353;
																			case 47:
																			case 79:
																				goto IL_035e;
																			case 63:
																				goto IL_036c;
																			case 55:
																			case 75:
																				goto IL_037f;
																			case 74:
																				goto IL_03ed;
																			case 76:
																				goto IL_0400;
																			case 78:
																				goto IL_040b;
																			case 36:
																			case 62:
																				goto IL_0416;
																			case 82:
																				goto IL_0456;
																			case 57:
																				goto IL_046a;
																			case 2:
																			case 7:
																			case 10:
																			case 17:
																			case 28:
																			case 33:
																			case 34:
																			case 39:
																			case 41:
																			case 43:
																			case 50:
																			case 51:
																			case 52:
																			case 56:
																			case 59:
																			case 60:
																			case 80:
																			case 83:
																				goto IL_047a;
																			case 38:
																				goto IL_049d;
																			case 69:
																				goto IL_04b4;
																			case 37:
																				goto IL_04c2;
																			case 1:
																			case 18:
																			case 24:
																			case 26:
																			case 27:
																			case 40:
																			case 54:
																			case 66:
																			case 85:
																			case 88:
																			case 89:
																				goto end_IL_01b8;
																			case 86:
																				goto end_IL_04d9;
																			case 72:
																				goto end_IL_04ec;
																			case 21:
																				goto end_IL_04f6;
																			case 30:
																				goto end_IL_0501;
																			case 73:
																				goto end_IL_051f;
																			case 53:
																			case 77:
																				goto end_IL_0534;
																			case 70:
																				goto end_IL_0544;
																			case 45:
																			case 84:
																				goto end_IL_055d;
																			case 48:
																				goto end_IL_056d;
																			case 49:
																				goto end_IL_057d;
																			case 3:
																			case 44:
																				goto IL_05a1;
																			}
																			continue;
																		}
																	}
																	else if (b >= 1)
																	{
																		goto IL_01d1;
																	}
																	goto IL_047a;
																	IL_047a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_049d;
																	IL_04b4:
																	num5++;
																	goto IL_04c2;
																	IL_049d:
																	array[num5] = 0;
																	num = 69;
																	goto IL_04b4;
																	IL_01d1:
																	if (b <= 8)
																	{
																		goto IL_01df;
																	}
																	goto IL_047a;
																	IL_01df:
																	if (4 < b)
																	{
																		goto IL_01ed;
																	}
																	goto IL_02f0;
																	IL_01ed:
																	if (6 >= b)
																	{
																		goto IL_01f8;
																	}
																	goto IL_023a;
																	IL_01f8:
																	if (6 <= b)
																	{
																		goto end_IL_01b8;
																	}
																	goto IL_0206;
																	IL_0206:
																	if (5 >= b)
																	{
																		goto IL_0214;
																	}
																	goto IL_047a;
																	IL_0214:
																	if (5 <= b)
																	{
																		goto IL_0222;
																	}
																	goto IL_047a;
																	IL_0222:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_01b8;
																	IL_023a:
																	if (7 < b)
																	{
																		goto IL_0245;
																	}
																	goto IL_027d;
																	IL_0245:
																	if (8 >= b)
																	{
																		goto IL_0253;
																	}
																	goto IL_047a;
																	IL_0253:
																	if (8 <= b)
																	{
																		goto IL_0261;
																	}
																	goto IL_047a;
																	IL_0261:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_01b8;
																	IL_027d:
																	if (7 <= b)
																	{
																		num = 23;
																		goto IL_0294;
																	}
																	goto IL_047a;
																	IL_04c2:
																	ptr2 += 8;
																	num = 26;
																	goto end_IL_01b8;
																	IL_0294:
																	array[num5] = 0;
																	goto IL_02a2;
																	IL_02a2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_02c5;
																	IL_02c5:
																	array2[num5] = null;
																	goto IL_02cf;
																	IL_02cf:
																	num5++;
																	goto IL_02dd;
																	IL_02dd:
																	ptr2 += 8;
																	goto end_IL_01b8;
																	IL_02f0:
																	if (4 <= b)
																	{
																		goto IL_02fb;
																	}
																	goto IL_0345;
																	IL_02fb:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0324;
																	IL_0324:
																	ptr2 += 8;
																	goto IL_0332;
																	IL_0332:
																	num5--;
																	goto end_IL_01b8;
																	IL_0345:
																	if (2 >= b)
																	{
																		goto IL_0353;
																	}
																	goto IL_0400;
																	IL_0353:
																	if (2 > b)
																	{
																		goto IL_035e;
																	}
																	goto IL_037f;
																	IL_035e:
																	if (1 >= b)
																	{
																		goto IL_036c;
																	}
																	goto IL_047a;
																	IL_036c:
																	if (1 <= b)
																	{
																	}
																	goto IL_047a;
																	IL_037f:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_03ed;
																	IL_03ed:
																	num5 -= 2;
																	goto end_IL_01b8;
																	IL_0400:
																	if (3 >= b)
																	{
																		goto IL_040b;
																	}
																	goto IL_047a;
																	IL_040b:
																	if (3 <= b)
																	{
																		goto IL_0416;
																	}
																	goto IL_047a;
																	IL_0416:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0456;
																	IL_0456:
																	array[num5 - 2] = 0;
																	goto IL_046a;
																	IL_046a:
																	num5--;
																	goto end_IL_01b8;
																	continue;
																	end_IL_018f:
																	break;
																}
																continue;
																end_IL_019f:
																break;
															}
															continue;
															end_IL_01b8:
															break;
														}
														continue;
													}
													goto IL_05a1;
													IL_05a1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d9:
													break;
												}
												continue;
												end_IL_04ec:
												break;
											}
											continue;
											end_IL_04f6:
											break;
										}
										continue;
										end_IL_0501:
										break;
									}
									continue;
									end_IL_051f:
									break;
								}
								continue;
								end_IL_0534:
								break;
							}
							continue;
							end_IL_0544:
							break;
						}
						continue;
						end_IL_055d:
						break;
					}
					continue;
					end_IL_056d:
					break;
				}
				continue;
				end_IL_057d:
				break;
			}
		}
	}

	static Class116()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 11;
			while (true)
			{
				if (num != 11)
				{
					if (num == 992)
					{
						switch (num)
						{
						default:
							continue;
						case 4:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 3:
							return;
						}
					}
					break;
				}
				Class300.smethod_0();
				return;
			}
		}
	}
}
