using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Hand Tap Spam", "World", "Spams hand tap sounds.", false, 23, ModType.const_0, false)]
internal class Class17 : MonoBehaviour
{
	private float float_0;

	private bool bool_0;

	private static bool bool_1;

	private static float float_1;

	private static bool bool_2;

	private static bool bool_3;

	private static double double_0;

	private static IntPtr[] TransformDispRetValsHostResolvePolicy;

	private static IntPtr[] RetLdloca;

	private static IntPtr[] EventSourceAttributeRegistryPermission;

	private static IntPtr[] DictionaryEnumeratorNumberBuffer;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_0773, IL_0786, IL_079f, IL_07f3, IL_0803, IL_0813, IL_0823, IL_0833, IL_0843, IL_0853, IL_0860, IL_086d, IL_087d, IL_088d, IL_089d, IL_08ad, IL_08bd, IL_08c8, IL_08db, IL_08e9, IL_08f7, IL_0905, IL_0910, IL_0920, IL_092e, IL_0937, IL_094f, IL_0972, IL_0985, IL_0993, IL_09a1, IL_09ac, IL_09ba, IL_09c5, IL_09d3, IL_09e6, IL_09f4, IL_09ff, IL_0a0d, IL_0a20, IL_0a2e, IL_0a41, IL_0a6f, IL_0aaf, IL_0ac8, IL_0ad3, IL_0ae1, IL_0aef, IL_0b02, IL_0b10, IL_0b1e, IL_0b31, IL_0b6f, IL_0b82, IL_0b95, IL_0bc0, IL_0bce, IL_0be6, IL_0bf4, IL_0c07, IL_0c15, IL_0c28, IL_0c3b, IL_0c52, IL_0c75, IL_0c7f, IL_0c8d, IL_0ca0, IL_0d02, IL_0d15, IL_0d3e, IL_0d7e, IL_0d92, IL_0dae, IL_0dbc, IL_0dd9, IL_0e28, IL_0e32, IL_0e5f, IL_0e7c, IL_0e8a, IL_0e9d, IL_0eab, IL_0ebe, IL_0ecc, IL_0ee5, IL_0ef3, IL_0f01, IL_0f14, IL_0f1f, IL_0f2a, IL_0f3d, IL_0f4b, IL_0f59, IL_0f71, IL_0f8a, IL_0f98, IL_0fab, IL_0ff9, IL_1011, IL_1024, IL_1065, IL_1079, IL_108c, IL_109a, IL_10ae, IL_10e6, IL_10f9, IL_110d, IL_1120, IL_1133, IL_114c, IL_115a, IL_1168, IL_1184, IL_11a2, IL_11b9, IL_11cc, IL_120c, IL_1220, IL_1233, IL_1246, IL_1268, IL_1276, IL_127f, IL_128d, IL_12cd, IL_12e1, IL_12f4, IL_12fd, IL_130b, IL_132f, IL_133d, IL_1350, IL_135e, IL_136c, IL_1384, IL_1392, IL_13a0, IL_13b3, IL_13bc, IL_13fa, IL_140e, IL_1421, IL_142f, IL_143a, IL_147a, IL_148e, IL_14a1, IL_14af, IL_14bd, IL_14d7, IL_14e5, IL_14f3, IL_1506, IL_1514, IL_1522, IL_152b, IL_1599, IL_15b5, IL_15c3, IL_15ce, IL_160e, IL_1622, IL_1635, IL_1643, IL_164e, IL_165c, IL_1680, IL_168e, IL_16a1, IL_16af, IL_16ba, IL_16c8, IL_16ec, IL_1703, IL_1716, IL_1721, IL_172f, IL_1743, IL_1782, IL_1795, IL_17a3, IL_17b1, IL_17c5, IL_1804, IL_1817, IL_1825, IL_1830, IL_1844, IL_1883, IL_1896, IL_18a4, IL_18b2, IL_1910, IL_1923, IL_1931, IL_193f, IL_197f, IL_1993, IL_19a6, IL_19b4, IL_19bf, IL_19d4, IL_19e7, IL_19f2, IL_1a00, IL_1a09, IL_1a37, IL_1a4a, IL_1a58, IL_1a66, IL_1a91, IL_1aaa, IL_1ab8, IL_1ac3, IL_1b01, IL_1b1e, IL_1b31, IL_1b3f, IL_1b4d, IL_1b61, IL_1ba0, IL_1bb3, IL_1bc1, IL_1bcf, IL_1bfd, IL_1c10, IL_1c1e, IL_1c29, IL_1c3d, IL_1c7c, IL_1c8f, IL_1c9d, IL_1ca8, IL_1cbc, IL_1cf4, IL_1d07, IL_1d12, IL_1d20, IL_1d2e, IL_1d4c, IL_1d5a, IL_1d6d, IL_1d7b, IL_1d89, IL_1d9d, IL_1dd5, IL_1de8, IL_1df6, IL_1e01, IL_1e15, IL_1e54, IL_1e67, IL_1e75, IL_1e7e, IL_1e8c, IL_1ecc, IL_1ee0, IL_1ef3, IL_1f01, IL_1f0f, IL_1f38, IL_1f51, IL_1f5f, IL_1f6d, IL_1f78, IL_1f94, IL_1fa2, IL_1fb0, IL_1fc4, IL_203f, IL_204d, IL_2060, IL_206e, IL_2081, IL_208c, IL_20b5, IL_20ce, IL_20dc, IL_20e7, IL_20f5, IL_2103, IL_212c, IL_2145, IL_217e, IL_2197, IL_21a2, IL_21ad, IL_21d6, IL_21ec, IL_21ff, IL_2212, IL_221c, IL_2227, IL_2237, IL_2247, IL_2257, IL_2267, IL_2277, IL_2287, IL_22a0, IL_22b0, IL_22c9 are reachable both inside and outside the pinned region starting at IL_22de. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 22;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef76 = default(int);
			ref int reference = ref __rxRef76;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_22c9:
					num2 = 1;
					while (true)
					{
						IL_22b0:
						num3 = num2 * 4;
						num = 135;
						while (true)
						{
							IL_22a0:
							num4 = num2 * 8;
							while (true)
							{
								IL_2287:
								array2 = new byte[8];
								num = 178;
								while (true)
								{
									IL_2277:
									array3 = new object[8];
									while (true)
									{
										IL_2267:
										array4 = new int[8];
										while (true)
										{
											IL_2257:
											array5 = new int[7];
											while (true)
											{
												IL_2247:
												array6 = new long[8];
												while (true)
												{
													IL_2237:
													array7 = new object[14];
													while (true)
													{
														IL_2227:
														array7[0] = this;
														while (true)
														{
															IL_221c:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HasLabelUndefined.hasLabelUndefined_0);
															while (true)
															{
																IL_2212:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_08bd:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_08ad:
																			ptr2++;
																			while (true)
																			{
																				IL_089d:
																				if (b >= 1)
																				{
																					while (b <= 57)
																					{
																						while (true)
																						{
																							IL_087d:
																							if (29 >= b)
																							{
																								while (true)
																								{
																									IL_086d:
																									if (29 > b)
																									{
																										while (true)
																										{
																											IL_0860:
																											if (14 < b)
																											{
																												while (true)
																												{
																													IL_0853:
																													if (21 < b)
																													{
																														while (true)
																														{
																															IL_0843:
																															if (25 >= b)
																															{
																																while (true)
																																{
																																	IL_0833:
																																	if (25 > b)
																																	{
																																		while (true)
																																		{
																																			IL_0823:
																																			if (23 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_0813:
																																					if (23 > b)
																																					{
																																						while (22 >= b)
																																						{
																																							while (22 <= b)
																																							{
																																								while (true)
																																								{
																																									IL_079f:
																																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																									while (true)
																																									{
																																										IL_0786:
																																										num6--;
																																										num = 473;
																																										while (num != 473)
																																										{
																																											if (num != 1454)
																																											{
																																												goto IL_1721;
																																											}
																																											switch (num)
																																											{
																																											case 22:
																																												break;
																																											default:
																																												continue;
																																											case 64:
																																												goto IL_0786;
																																											case 269:
																																											case 381:
																																												goto IL_079f;
																																											case 26:
																																												goto IL_07f3;
																																											case 217:
																																												goto IL_0803;
																																											case 417:
																																												goto IL_0813;
																																											case 267:
																																												goto IL_0823;
																																											case 346:
																																												goto IL_0833;
																																											case 121:
																																												goto IL_0843;
																																											case 363:
																																												goto IL_0853;
																																											case 170:
																																												goto IL_0860;
																																											case 45:
																																												goto IL_086d;
																																											case 88:
																																												goto IL_087d;
																																											case 277:
																																												goto IL_088d;
																																											case 335:
																																												goto IL_089d;
																																											case 175:
																																												goto IL_08ad;
																																											case 185:
																																											case 209:
																																												goto IL_08bd;
																																											case 57:
																																												goto IL_08c8;
																																											case 216:
																																												goto IL_08db;
																																											case 114:
																																												goto IL_08e9;
																																											case 75:
																																												goto IL_08f7;
																																											case 86:
																																												goto IL_0905;
																																											case 74:
																																												goto IL_0910;
																																											case 247:
																																												goto IL_0920;
																																											case 9:
																																											case 179:
																																												goto IL_0937;
																																											case 54:
																																												goto IL_094f;
																																											case 248:
																																												goto IL_0972;
																																											case 276:
																																												goto IL_0985;
																																											case 39:
																																												goto IL_0993;
																																											case 256:
																																												goto IL_09a1;
																																											case 13:
																																												goto IL_09ac;
																																											case 139:
																																												goto IL_09ba;
																																											case 242:
																																												goto IL_09c5;
																																											case 271:
																																												goto IL_09d3;
																																											case 43:
																																												goto IL_09f4;
																																											case 236:
																																												goto IL_09ff;
																																											case 115:
																																												goto IL_0a0d;
																																											case 24:
																																												goto IL_0a20;
																																											case 84:
																																												goto IL_0a2e;
																																											case 134:
																																											case 280:
																																												goto IL_0a41;
																																											case 47:
																																											case 293:
																																												goto IL_0a6f;
																																											case 132:
																																												goto IL_0aaf;
																																											case 299:
																																												goto IL_0ac8;
																																											case 162:
																																												goto IL_0ad3;
																																											case 0:
																																												goto IL_0ae1;
																																											case 127:
																																												goto IL_0aef;
																																											case 309:
																																												goto IL_0b02;
																																											case 110:
																																												goto IL_0b10;
																																											case 244:
																																												goto IL_0b1e;
																																											case 164:
																																											case 313:
																																												goto IL_0b31;
																																											case 158:
																																												goto IL_0b6f;
																																											case 314:
																																												goto IL_0b82;
																																											case 283:
																																											case 327:
																																												goto IL_0b95;
																																											case 167:
																																											case 339:
																																												goto IL_0bc0;
																																											case 36:
																																												goto IL_0bce;
																																											case 42:
																																												goto IL_0be6;
																																											case 344:
																																												goto IL_0bf4;
																																											case 360:
																																												goto IL_0c07;
																																											case 190:
																																												goto IL_0c15;
																																											case 272:
																																											case 365:
																																												goto IL_0c28;
																																											case 250:
																																											case 366:
																																												goto IL_0c3b;
																																											case 214:
																																												goto IL_0c52;
																																											case 91:
																																												goto IL_0c75;
																																											case 340:
																																												goto IL_0c7f;
																																											case 34:
																																												goto IL_0c8d;
																																											case 58:
																																											case 372:
																																												goto IL_0ca0;
																																											case 189:
																																												goto IL_0d02;
																																											case 373:
																																												goto IL_0d15;
																																											case 208:
																																											case 376:
																																												goto IL_0d3e;
																																											case 263:
																																												goto IL_0d7e;
																																											case 378:
																																												goto IL_0d92;
																																											case 395:
																																												goto IL_0dae;
																																											case 29:
																																											case 270:
																																												goto IL_0dbc;
																																											case 165:
																																												goto IL_0e7c;
																																											case 153:
																																												goto IL_0e8a;
																																											case 186:
																																												goto IL_0e9d;
																																											case 52:
																																												goto IL_0eab;
																																											case 397:
																																												goto IL_0ebe;
																																											case 258:
																																											case 292:
																																												goto IL_0ecc;
																																											case 291:
																																												goto IL_0ee5;
																																											case 341:
																																												goto IL_0ef3;
																																											case 385:
																																												goto IL_0f01;
																																											case 404:
																																												goto IL_0f14;
																																											case 329:
																																												goto IL_0f1f;
																																											case 218:
																																												goto IL_0f2a;
																																											case 384:
																																												goto IL_0f3d;
																																											case 412:
																																												goto IL_0f4b;
																																											case 70:
																																											case 330:
																																												goto IL_0f59;
																																											case 28:
																																											case 413:
																																												goto IL_0f71;
																																											case 281:
																																												goto IL_0f8a;
																																											case 409:
																																												goto IL_0f98;
																																											case 157:
																																											case 419:
																																												goto IL_0fab;
																																											case 421:
																																												goto IL_0ff9;
																																											case 403:
																																												goto IL_1011;
																																											case 94:
																																											case 424:
																																												goto IL_1024;
																																											case 125:
																																												goto IL_1065;
																																											case 422:
																																												goto IL_1079;
																																											case 425:
																																												goto IL_108c;
																																											case 93:
																																											case 151:
																																												goto IL_109a;
																																											case 259:
																																												goto IL_10ae;
																																											case 8:
																																												goto IL_10e6;
																																											case 432:
																																												goto IL_10f9;
																																											case 440:
																																												goto IL_110d;
																																											case 442:
																																												goto IL_1120;
																																											case 111:
																																											case 446:
																																												goto IL_1133;
																																											case 391:
																																												goto IL_114c;
																																											case 120:
																																												goto IL_115a;
																																											case 398:
																																												goto IL_1168;
																																											case 81:
																																											case 449:
																																												goto IL_1184;
																																											case 320:
																																												goto IL_11a2;
																																											case 12:
																																												goto IL_11b9;
																																											case 356:
																																											case 452:
																																												goto IL_11cc;
																																											case 11:
																																												goto IL_120c;
																																											case 196:
																																												goto IL_1220;
																																											case 453:
																																												goto IL_1233;
																																											case 458:
																																												goto IL_1246;
																																											case 461:
																																												goto IL_1268;
																																											case 174:
																																												goto IL_127f;
																																											case 37:
																																											case 282:
																																												goto IL_128d;
																																											case 212:
																																												goto IL_12cd;
																																											case 215:
																																												goto IL_12e1;
																																											case 234:
																																											case 317:
																																												goto IL_12fd;
																																											case 169:
																																												goto IL_130b;
																																											case 321:
																																												goto IL_132f;
																																											case 4:
																																												goto IL_133d;
																																											case 264:
																																												goto IL_1350;
																																											case 246:
																																												goto IL_135e;
																																											case 10:
																																											case 211:
																																												goto IL_136c;
																																											case 405:
																																												goto IL_1384;
																																											case 161:
																																												goto IL_1392;
																																											case 316:
																																												goto IL_13a0;
																																											case 224:
																																											case 240:
																																												goto IL_13bc;
																																											case 315:
																																												goto IL_13fa;
																																											case 109:
																																												goto IL_140e;
																																											case 464:
																																												goto IL_1421;
																																											case 300:
																																												goto IL_142f;
																																											case 5:
																																											case 437:
																																												goto IL_143a;
																																											case 221:
																																												goto IL_147a;
																																											case 71:
																																												goto IL_148e;
																																											case 286:
																																												goto IL_14a1;
																																											case 386:
																																												goto IL_14af;
																																											case 195:
																																											case 290:
																																												goto IL_14bd;
																																											case 198:
																																												goto IL_14d7;
																																											case 331:
																																												goto IL_14e5;
																																											case 423:
																																												goto IL_14f3;
																																											case 439:
																																												goto IL_1506;
																																											case 441:
																																												goto IL_1514;
																																											case 60:
																																											case 338:
																																												goto IL_152b;
																																											case 142:
																																												goto IL_1599;
																																											case 101:
																																												goto IL_15b5;
																																											case 393:
																																												goto IL_15c3;
																																											case 27:
																																											case 428:
																																												goto IL_15ce;
																																											case 140:
																																												goto IL_160e;
																																											case 32:
																																												goto IL_1622;
																																											case 349:
																																												goto IL_1635;
																																											case 82:
																																												goto IL_1643;
																																											case 25:
																																											case 116:
																																												goto IL_164e;
																																											case 160:
																																												goto IL_165c;
																																											case 229:
																																												goto IL_1680;
																																											case 206:
																																												goto IL_168e;
																																											case 155:
																																												goto IL_16a1;
																																											case 18:
																																												goto IL_16af;
																																											case 56:
																																											case 362:
																																												goto IL_16ba;
																																											case 400:
																																												goto IL_16c8;
																																											case 96:
																																												goto IL_16ec;
																																											case 33:
																																												goto IL_1703;
																																											case 455:
																																												goto IL_1716;
																																											case 131:
																																												goto IL_1721;
																																											case 205:
																																											case 379:
																																												goto IL_172f;
																																											case 463:
																																												goto IL_1743;
																																											case 112:
																																												goto IL_1782;
																																											case 304:
																																												goto IL_1795;
																																											case 336:
																																												goto IL_17a3;
																																											case 375:
																																											case 420:
																																												goto IL_17b1;
																																											case 343:
																																												goto IL_17c5;
																																											case 130:
																																												goto IL_1804;
																																											case 307:
																																												goto IL_1817;
																																											case 357:
																																												goto IL_1825;
																																											case 129:
																																											case 310:
																																												goto IL_1830;
																																											case 435:
																																												goto IL_1844;
																																											case 73:
																																												goto IL_1883;
																																											case 44:
																																												goto IL_1896;
																																											case 318:
																																												goto IL_18a4;
																																											case 213:
																																											case 226:
																																												goto IL_18b2;
																																											case 382:
																																												goto IL_1910;
																																											case 222:
																																												goto IL_1923;
																																											case 312:
																																												goto IL_1931;
																																											case 7:
																																											case 194:
																																												goto IL_193f;
																																											case 133:
																																												goto IL_197f;
																																											case 149:
																																												goto IL_1993;
																																											case 76:
																																												goto IL_19a6;
																																											case 123:
																																												goto IL_19b4;
																																											case 159:
																																											case 448:
																																												goto IL_19bf;
																																											case 144:
																																												goto IL_19d4;
																																											case 389:
																																												goto IL_19e7;
																																											case 117:
																																												goto IL_19f2;
																																											case 275:
																																											case 443:
																																												goto IL_1a09;
																																											case 173:
																																												goto IL_1a37;
																																											case 447:
																																												goto IL_1a4a;
																																											case 223:
																																												goto IL_1a58;
																																											case 141:
																																											case 239:
																																												goto IL_1a66;
																																											case 451:
																																												goto IL_1a91;
																																											case 436:
																																												goto IL_1aaa;
																																											case 41:
																																												goto IL_1ab8;
																																											case 445:
																																											case 462:
																																												goto IL_1ac3;
																																											case 126:
																																												goto IL_1b01;
																																											case 295:
																																												goto IL_1b1e;
																																											case 337:
																																												goto IL_1b31;
																																											case 319:
																																												goto IL_1b3f;
																																											case 67:
																																											case 266:
																																												goto IL_1b4d;
																																											case 69:
																																												goto IL_1b61;
																																											case 146:
																																												goto IL_1ba0;
																																											case 152:
																																												goto IL_1bb3;
																																											case 232:
																																												goto IL_1bc1;
																																											case 148:
																																											case 180:
																																												goto IL_1bcf;
																																											case 369:
																																												goto IL_1bfd;
																																											case 392:
																																												goto IL_1c10;
																																											case 351:
																																												goto IL_1c1e;
																																											case 1:
																																											case 6:
																																												goto IL_1c29;
																																											case 66:
																																												goto IL_1c3d;
																																											case 199:
																																												goto IL_1c7c;
																																											case 306:
																																												goto IL_1c8f;
																																											case 408:
																																												goto IL_1c9d;
																																											case 332:
																																											case 361:
																																												goto IL_1ca8;
																																											case 50:
																																												goto IL_1cbc;
																																											case 51:
																																												goto IL_1cf4;
																																											case 92:
																																												goto IL_1d07;
																																											case 285:
																																												goto IL_1d12;
																																											case 352:
																																											case 433:
																																												goto IL_1d20;
																																											case 31:
																																												goto IL_1d2e;
																																											case 294:
																																												goto IL_1d4c;
																																											case 230:
																																												goto IL_1d5a;
																																											case 278:
																																												goto IL_1d6d;
																																											case 465:
																																												goto IL_1d7b;
																																											case 78:
																																											case 354:
																																												goto IL_1d89;
																																											case 53:
																																												goto IL_1d9d;
																																											case 326:
																																												goto IL_1dd5;
																																											case 201:
																																												goto IL_1de8;
																																											case 301:
																																												goto IL_1df6;
																																											case 19:
																																											case 308:
																																												goto IL_1e01;
																																											case 355:
																																												goto IL_1e15;
																																											case 145:
																																												goto IL_1e54;
																																											case 333:
																																												goto IL_1e67;
																																											case 297:
																																												goto IL_1e7e;
																																											case 200:
																																											case 279:
																																												goto IL_1e8c;
																																											case 105:
																																												goto IL_1ecc;
																																											case 394:
																																												goto IL_1ee0;
																																											case 427:
																																												goto IL_1ef3;
																																											case 390:
																																												goto IL_1f01;
																																											case 128:
																																											case 311:
																																												goto IL_1f0f;
																																											case 113:
																																												goto IL_1f38;
																																											case 284:
																																												goto IL_1f51;
																																											case 328:
																																												goto IL_1f5f;
																																											case 202:
																																												goto IL_1f6d;
																																											case 38:
																																											case 203:
																																												goto IL_1f78;
																																											case 163:
																																												goto IL_1f94;
																																											case 138:
																																												goto IL_1fa2;
																																											case 176:
																																											case 192:
																																												goto IL_1fb0;
																																											case 191:
																																												goto IL_1fc4;
																																											case 188:
																																												goto IL_203f;
																																											case 106:
																																												goto IL_204d;
																																											case 416:
																																												goto IL_2060;
																																											case 63:
																																												goto IL_206e;
																																											case 124:
																																												goto IL_2081;
																																											case 322:
																																											case 342:
																																												goto IL_208c;
																																											case 388:
																																												goto IL_20b5;
																																											case 220:
																																												goto IL_20ce;
																																											case 103:
																																												goto IL_20dc;
																																											case 79:
																																												goto IL_20e7;
																																											case 204:
																																												goto IL_20f5;
																																											case 177:
																																											case 251:
																																												goto IL_2103;
																																											case 166:
																																												goto IL_212c;
																																											case 377:
																																											case 459:
																																												goto IL_2145;
																																											case 228:
																																												goto IL_217e;
																																											case 55:
																																												goto IL_2197;
																																											case 235:
																																												goto IL_21a2;
																																											case 233:
																																											case 261:
																																												goto IL_21ad;
																																											case 108:
																																												goto IL_21d6;
																																											case 3:
																																											case 15:
																																											case 17:
																																											case 35:
																																											case 48:
																																											case 49:
																																											case 65:
																																											case 68:
																																											case 72:
																																											case 77:
																																											case 85:
																																											case 87:
																																											case 89:
																																											case 90:
																																											case 95:
																																											case 98:
																																											case 118:
																																											case 122:
																																											case 137:
																																											case 143:
																																											case 147:
																																											case 150:
																																											case 154:
																																											case 156:
																																											case 168:
																																											case 187:
																																											case 197:
																																											case 207:
																																											case 238:
																																											case 253:
																																											case 254:
																																											case 260:
																																											case 262:
																																											case 265:
																																											case 268:
																																											case 298:
																																											case 302:
																																											case 305:
																																											case 323:
																																											case 324:
																																											case 334:
																																											case 347:
																																											case 353:
																																											case 364:
																																											case 367:
																																											case 371:
																																											case 374:
																																											case 387:
																																											case 396:
																																											case 401:
																																											case 406:
																																											case 410:
																																											case 411:
																																											case 426:
																																											case 430:
																																											case 431:
																																											case 434:
																																											case 450:
																																											case 456:
																																											case 466:
																																												goto end_IL_07f3;
																																											case 2:
																																											case 14:
																																											case 16:
																																											case 20:
																																											case 23:
																																											case 30:
																																											case 40:
																																											case 46:
																																											case 59:
																																											case 61:
																																											case 62:
																																											case 83:
																																											case 97:
																																											case 99:
																																											case 100:
																																											case 102:
																																											case 104:
																																											case 107:
																																											case 119:
																																											case 136:
																																											case 171:
																																											case 172:
																																											case 181:
																																											case 183:
																																											case 184:
																																											case 193:
																																											case 210:
																																											case 225:
																																											case 227:
																																											case 231:
																																											case 237:
																																											case 241:
																																											case 243:
																																											case 249:
																																											case 252:
																																											case 255:
																																											case 257:
																																											case 273:
																																											case 287:
																																											case 288:
																																											case 296:
																																											case 303:
																																											case 345:
																																											case 348:
																																											case 350:
																																											case 358:
																																											case 359:
																																											case 368:
																																											case 370:
																																											case 380:
																																											case 383:
																																											case 414:
																																											case 415:
																																											case 418:
																																											case 429:
																																											case 438:
																																											case 454:
																																											case 457:
																																											case 460:
																																												goto end_IL_0773;
																																											case 274:
																																												goto IL_2212;
																																											case 407:
																																												goto IL_221c;
																																											case 219:
																																												goto IL_2227;
																																											case 444:
																																												goto IL_2237;
																																											case 325:
																																												goto IL_2247;
																																											case 289:
																																												goto IL_2257;
																																											case 245:
																																												goto IL_2267;
																																											case 178:
																																												goto IL_2277;
																																											case 80:
																																												goto IL_2287;
																																											case 135:
																																												goto IL_22a0;
																																											case 399:
																																												goto IL_22b0;
																																											case 21:
																																												goto IL_22c9;
																																											case 182:
																																											case 402:
																																												return;
																																											}
																																											goto end_IL_21ff;
																																											continue;
																																											end_IL_0773:
																																											break;
																																										}
																																										break;
																																									}
																																									break;
																																								}
																																								goto end_IL_089d;
																																								continue;
																																								end_IL_07f3:
																																								break;
																																								IL_07f3:;
																																							}
																																							break;
																																							IL_0803:;
																																						}
																																						break;
																																					}
																																					num = 234;
																																					goto IL_12fd;
																																					IL_132f:
																																					num6++;
																																					goto IL_133d;
																																					IL_133d:
																																					ptr2 += 8;
																																					goto end_IL_089d;
																																					IL_12fd:
																																					array2[num6] = 3;
																																					goto IL_130b;
																																					IL_130b:
																																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
																																					goto IL_132f;
																																				}
																																				break;
																																			}
																																			goto IL_1350;
																																			IL_13a0:
																																			ptr2 += 8;
																																			goto end_IL_089d;
																																			IL_1350:
																																			if (24 < b)
																																			{
																																				break;
																																			}
																																			goto IL_135e;
																																			IL_135e:
																																			if (24 > b)
																																			{
																																				break;
																																			}
																																			goto IL_136c;
																																			IL_136c:
																																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																																			goto IL_1384;
																																			IL_1384:
																																			array2[num6] = 5;
																																			goto IL_1392;
																																			IL_1392:
																																			num6++;
																																			goto IL_13a0;
																																		}
																																		break;
																																	}
																																	num = 240;
																																	goto IL_13bc;
																																	IL_13fa:
																																	array2[num6 - 1] = 3;
																																	goto IL_140e;
																																	IL_140e:
																																	ptr2 += 8;
																																	goto end_IL_089d;
																																	IL_13bc:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class17, float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((Class17)array3[num6 - 1]);
																																	goto IL_13fa;
																																}
																																break;
																															}
																															goto IL_1421;
																															IL_152b:
																															ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_1599;
																															IL_1421:
																															if (27 >= b)
																															{
																																goto IL_142f;
																															}
																															goto IL_1506;
																															IL_142f:
																															if (27 <= b)
																															{
																																goto IL_143a;
																															}
																															goto IL_14a1;
																															IL_143a:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_147a;
																															IL_147a:
																															array2[num6 - 2] = 3;
																															goto IL_148e;
																															IL_148e:
																															num6--;
																															goto end_IL_089d;
																															IL_14a1:
																															if (26 < b)
																															{
																																break;
																															}
																															goto IL_14af;
																															IL_14af:
																															if (26 > b)
																															{
																																break;
																															}
																															goto IL_14bd;
																															IL_14bd:
																															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																															goto IL_14d7;
																															IL_14d7:
																															array2[num6] = 3;
																															goto IL_14e5;
																															IL_14e5:
																															num6++;
																															goto IL_14f3;
																															IL_14f3:
																															ptr2 += 8;
																															goto end_IL_089d;
																															IL_1506:
																															if (28 < b)
																															{
																																break;
																															}
																															goto IL_1514;
																															IL_1514:
																															if (28 > b)
																															{
																																break;
																															}
																															num = 60;
																															goto IL_152b;
																															IL_1599:
																															num6 -= 2;
																															num = 100;
																															goto end_IL_089d;
																														}
																														break;
																													}
																													goto IL_08db;
																													IL_1065:
																													array2[num6 - 2] = 0;
																													goto IL_1079;
																													IL_08db:
																													if (21 > b)
																													{
																														goto IL_08e9;
																													}
																													goto IL_1024;
																													IL_08e9:
																													if (17 >= b)
																													{
																														goto IL_08f7;
																													}
																													goto IL_0f14;
																													IL_08f7:
																													if (17 > b)
																													{
																														goto IL_0905;
																													}
																													goto IL_0b31;
																													IL_0905:
																													if (15 < b)
																													{
																														goto IL_0910;
																													}
																													goto IL_0920;
																													IL_0910:
																													if (16 < b)
																													{
																														break;
																													}
																													goto IL_0972;
																													IL_0972:
																													if (16 > b)
																													{
																														break;
																													}
																													goto IL_0bc0;
																													IL_0bc0:
																													array2[num6] = 5;
																													goto IL_0bce;
																													IL_0bce:
																													array3[num6] = array7[*(int*)(ptr2 + num3)];
																													goto IL_0be6;
																													IL_0be6:
																													num6++;
																													goto IL_0bf4;
																													IL_0bf4:
																													ptr2 += 8;
																													goto end_IL_089d;
																													IL_0920:
																													if (15 > b)
																													{
																														break;
																													}
																													num = 9;
																													goto IL_0937;
																													IL_1079:
																													num6--;
																													goto end_IL_089d;
																													IL_0937:
																													array2[num6] = array2[num6 - 1];
																													goto IL_094f;
																													IL_094f:
																													array4[num6 - 0] = array4[num6 - 1];
																													goto IL_0d15;
																													IL_0d15:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0ff9;
																													IL_0ff9:
																													array3[num6] = array3[num6 - 1];
																													goto IL_1011;
																													IL_1011:
																													num6++;
																													goto end_IL_089d;
																													IL_0b31:
																													((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																													goto IL_0b6f;
																													IL_0b6f:
																													num6 -= 3;
																													goto end_IL_089d;
																													IL_0f14:
																													if (19 >= b)
																													{
																														goto IL_0f1f;
																													}
																													goto IL_0f3d;
																													IL_0f1f:
																													if (19 > b)
																													{
																														goto IL_0f2a;
																													}
																													goto IL_0f71;
																													IL_0f2a:
																													if (18 < b)
																													{
																														break;
																													}
																													goto IL_108c;
																													IL_108c:
																													if (18 > b)
																													{
																														break;
																													}
																													goto IL_109a;
																													IL_109a:
																													array2[num6 - 1] = 5;
																													goto IL_10ae;
																													IL_10ae:
																													array3[num6 - 1] = ((delegate*<string[], string>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																													goto IL_10e6;
																													IL_10e6:
																													ptr2 += 8;
																													goto end_IL_089d;
																													IL_0f71:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																													goto IL_0f8a;
																													IL_0f8a:
																													array2[num6] = 1;
																													goto IL_0f98;
																													IL_0f98:
																													num6++;
																													goto IL_1233;
																													IL_1233:
																													ptr2 += 16;
																													goto end_IL_089d;
																													IL_0f3d:
																													if (20 < b)
																													{
																														break;
																													}
																													goto IL_0f4b;
																													IL_0f4b:
																													if (20 > b)
																													{
																														break;
																													}
																													goto IL_0f59;
																													IL_0f59:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto end_IL_089d;
																													IL_1024:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																													goto IL_1065;
																												}
																												break;
																											}
																											goto IL_08c8;
																											IL_0e7c:
																											array2[num6] = 5;
																											goto IL_0e8a;
																											IL_08c8:
																											if (14 > b)
																											{
																												goto IL_0985;
																											}
																											goto IL_0a41;
																											IL_0985:
																											if (7 >= b)
																											{
																												goto IL_0993;
																											}
																											goto IL_0ac8;
																											IL_0993:
																											if (7 > b)
																											{
																												goto IL_09a1;
																											}
																											goto IL_0a6f;
																											IL_09a1:
																											if (3 >= b)
																											{
																												goto IL_09ac;
																											}
																											goto IL_09f4;
																											IL_09ac:
																											if (3 > b)
																											{
																												goto IL_09ba;
																											}
																											goto IL_0b95;
																											IL_09ba:
																											if (1 < b)
																											{
																												goto IL_09c5;
																											}
																											num = 397;
																											goto IL_0ebe;
																											IL_09c5:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_09d3;
																											IL_09d3:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0fab;
																											IL_0fab:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 432;
																											goto IL_10f9;
																											IL_10f9:
																											array2[num6 - 2] = 0;
																											goto IL_110d;
																											IL_110d:
																											num6--;
																											goto end_IL_089d;
																											IL_0e8a:
																											num6++;
																											goto end_IL_089d;
																											IL_0ebe:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0ecc;
																											IL_0ecc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											goto IL_0ee5;
																											IL_0ee5:
																											array2[num6] = 0;
																											goto IL_0ef3;
																											IL_0ef3:
																											num6++;
																											goto IL_0f01;
																											IL_0f01:
																											ptr2 += 8;
																											goto end_IL_089d;
																											IL_0b95:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0c07;
																											IL_0c07:
																											ptr2 += 8;
																											goto IL_0c15;
																											IL_0c15:
																											num6--;
																											goto end_IL_089d;
																											IL_09f4:
																											if (5 >= b)
																											{
																												goto IL_09ff;
																											}
																											goto IL_0a20;
																											IL_09ff:
																											if (5 > b)
																											{
																												goto IL_0a0d;
																											}
																											goto IL_11cc;
																											IL_0a0d:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0b82;
																											IL_0b82:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_0c3b;
																											IL_0c3b:
																											array2[num6] = 0;
																											num = 214;
																											goto IL_0c52;
																											IL_0c52:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_0c75;
																											IL_0c75:
																											array3[num6] = null;
																											goto IL_0c7f;
																											IL_0c7f:
																											num6++;
																											goto IL_0c8d;
																											IL_0c8d:
																											ptr2 += 8;
																											goto end_IL_089d;
																											IL_11cc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_120c;
																											IL_120c:
																											array2[num6 - 2] = 0;
																											goto IL_1220;
																											IL_1220:
																											num6--;
																											goto end_IL_089d;
																											IL_0a20:
																											if (6 < b)
																											{
																												break;
																											}
																											goto IL_0a2e;
																											IL_0a2e:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_0d3e;
																											IL_0d3e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0d7e;
																											IL_0d7e:
																											array2[num6 - 2] = 0;
																											goto IL_0d92;
																											IL_0d92:
																											num6--;
																											num = 136;
																											goto end_IL_089d;
																											IL_0a6f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0aaf;
																											IL_0aaf:
																											array2[num6 - 2] = 0;
																											goto IL_1120;
																											IL_1120:
																											num6--;
																											goto end_IL_089d;
																											IL_0ac8:
																											if (10 >= b)
																											{
																												goto IL_0ad3;
																											}
																											goto IL_0b02;
																											IL_0ad3:
																											if (10 > b)
																											{
																												goto IL_0ae1;
																											}
																											goto IL_0ca0;
																											IL_0ae1:
																											if (8 >= b)
																											{
																												goto IL_0aef;
																											}
																											goto IL_1268;
																											IL_0aef:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_0c28;
																											IL_0c28:
																											num6--;
																											goto end_IL_089d;
																											IL_1268:
																											if (9 < b)
																											{
																												break;
																											}
																											num = 174;
																											goto IL_127f;
																											IL_0e9d:
																											if (11 < b)
																											{
																												break;
																											}
																											goto IL_0eab;
																											IL_127f:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_128d;
																											IL_128d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_12cd;
																											IL_12cd:
																											array2[num6 - 2] = 0;
																											goto IL_12e1;
																											IL_12e1:
																											num6--;
																											goto end_IL_089d;
																											IL_0ca0:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0d02;
																											IL_0d02:
																											num6 -= 2;
																											goto end_IL_089d;
																											IL_0b02:
																											if (12 < b)
																											{
																												goto IL_0b10;
																											}
																											goto IL_0dae;
																											IL_0b10:
																											if (13 < b)
																											{
																												break;
																											}
																											goto IL_0b1e;
																											IL_0b1e:
																											if (13 > b)
																											{
																												break;
																											}
																											goto IL_1184;
																											IL_1184:
																											array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																											goto IL_11a2;
																											IL_11a2:
																											ptr2 += 8;
																											num = 12;
																											goto IL_11b9;
																											IL_11b9:
																											num6--;
																											goto end_IL_089d;
																											IL_0dae:
																											if (12 <= b)
																											{
																												goto IL_0dbc;
																											}
																											goto IL_0e9d;
																											IL_0dbc:
																											array8 = array3;
																											num7 = num6;
																											if (array == null)
																											{
																												goto IL_0dcb;
																											}
																											num8 = ptr2;
																											byte b2 = *num8;
																											ptr2 = num8 + 4;
																											int num9 = *(int*)(ptr2 + num3);
																											ptr2 += 8;
																											byte* ptr3 = ptr2 + num9;
																											byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																											while (ptr2 != ptr3)
																											{
																												*ptr4 = (byte)(*ptr2 ^ b2);
																												ptr2++;
																												ptr4++;
																											}
																											array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																											num = 165;
																											goto IL_0e7c;
																											IL_0eab:
																											if (11 > b)
																											{
																												break;
																											}
																											goto end_IL_089d;
																											IL_0a41:
																											array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																											goto IL_1246;
																											IL_1246:
																											array2[num6 - 1] = 5;
																											num = 20;
																											goto end_IL_089d;
																										}
																										break;
																									}
																									goto IL_1133;
																									IL_1168:
																									ptr2 += 16;
																									num = 380;
																									goto end_IL_089d;
																									IL_1133:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																									goto IL_114c;
																									IL_114c:
																									array2[num6] = 3;
																									goto IL_115a;
																									IL_115a:
																									num6++;
																									goto IL_1168;
																								}
																								break;
																							}
																							goto IL_15b5;
																							IL_21a2:
																							if (53 > b)
																							{
																								break;
																							}
																							goto IL_21ad;
																							IL_15b5:
																							if (43 >= b)
																							{
																								goto IL_15c3;
																							}
																							goto IL_1c10;
																							IL_15c3:
																							if (43 <= b)
																							{
																								goto IL_15ce;
																							}
																							goto IL_1635;
																							IL_15ce:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_160e;
																							IL_160e:
																							array2[num6 - 2] = 3;
																							goto IL_1622;
																							IL_1622:
																							num6--;
																							goto end_IL_089d;
																							IL_1635:
																							if (36 >= b)
																							{
																								goto IL_1643;
																							}
																							goto IL_19a6;
																							IL_1643:
																							if (36 <= b)
																							{
																								goto IL_164e;
																							}
																							goto IL_16a1;
																							IL_164e:
																							array2[num6] = 3;
																							goto IL_165c;
																							IL_165c:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
																							goto IL_1680;
																							IL_1680:
																							num6++;
																							goto IL_168e;
																							IL_168e:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_16a1:
																							if (32 >= b)
																							{
																								goto IL_16af;
																							}
																							goto IL_1817;
																							IL_16af:
																							if (32 <= b)
																							{
																								goto IL_16ba;
																							}
																							goto IL_1716;
																							IL_16ba:
																							array2[num6] = 0;
																							goto IL_16c8;
																							IL_16c8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_16ec;
																							IL_16ec:
																							num6++;
																							num = 33;
																							goto IL_1703;
																							IL_1703:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1716:
																							if (30 >= b)
																							{
																								goto IL_1721;
																							}
																							goto IL_1795;
																							IL_1721:
																							if (30 > b)
																							{
																								break;
																							}
																							goto IL_172f;
																							IL_172f:
																							array2[num6 - 1] = 3;
																							goto IL_1743;
																							IL_1743:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1782;
																							IL_1782:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1795:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_17a3;
																							IL_17a3:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_17b1;
																							IL_17b1:
																							array2[num6 - 1] = 0;
																							goto IL_17c5;
																							IL_17c5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1804;
																							IL_1804:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1817:
																							if (34 >= b)
																							{
																								goto IL_1825;
																							}
																							goto IL_1923;
																							IL_1825:
																							if (34 <= b)
																							{
																								goto IL_1830;
																							}
																							goto IL_1896;
																							IL_1830:
																							array2[num6 - 1] = 3;
																							goto IL_1844;
																							IL_1844:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1883;
																							IL_1883:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1896:
																							if (33 < b)
																							{
																								break;
																							}
																							goto IL_18a4;
																							IL_18a4:
																							if (33 > b)
																							{
																								break;
																							}
																							goto IL_18b2;
																							IL_18b2:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1910;
																							IL_1910:
																							num6--;
																							goto end_IL_089d;
																							IL_1923:
																							if (35 < b)
																							{
																								break;
																							}
																							goto IL_1931;
																							IL_1931:
																							if (35 > b)
																							{
																								break;
																							}
																							goto IL_193f;
																							IL_193f:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_197f;
																							IL_197f:
																							array2[num6 - 2] = 3;
																							goto IL_1993;
																							IL_1993:
																							num6--;
																							goto end_IL_089d;
																							IL_19a6:
																							if (39 >= b)
																							{
																								goto IL_19b4;
																							}
																							goto IL_1aaa;
																							IL_19b4:
																							if (39 <= b)
																							{
																								goto IL_19bf;
																							}
																							goto IL_19e7;
																							IL_19bf:
																							((delegate*<void>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
																							goto IL_19d4;
																							IL_19d4:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_19e7:
																							if (37 >= b)
																							{
																								goto IL_19f2;
																							}
																							goto IL_1a4a;
																							IL_19f2:
																							if (37 > b)
																							{
																								break;
																							}
																							num = 275;
																							goto IL_1a09;
																							IL_21ad:
																							array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																							goto IL_21d6;
																							IL_1a09:
																							((Class17)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1a37;
																							IL_1a37:
																							num6 -= 2;
																							goto end_IL_089d;
																							IL_1a4a:
																							if (38 < b)
																							{
																								break;
																							}
																							goto IL_1a58;
																							IL_1a58:
																							if (38 > b)
																							{
																								break;
																							}
																							goto IL_1a66;
																							IL_1a66:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1a91;
																							IL_1a91:
																							array2[num6 - 1] = 0;
																							goto end_IL_089d;
																							IL_1aaa:
																							if (41 >= b)
																							{
																								goto IL_1ab8;
																							}
																							goto IL_1bb3;
																							IL_1ab8:
																							if (41 <= b)
																							{
																								goto IL_1ac3;
																							}
																							goto IL_1b31;
																							IL_1ac3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class17, bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((Class17)array3[num6 - 1]) ? 1 : 0);
																							goto IL_1b01;
																							IL_1b01:
																							array2[num6 - 1] = 0;
																							num = 295;
																							goto IL_1b1e;
																							IL_1b1e:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1b31:
																							if (40 < b)
																							{
																								break;
																							}
																							goto IL_1b3f;
																							IL_1b3f:
																							if (40 > b)
																							{
																								break;
																							}
																							goto IL_1b4d;
																							IL_1b4d:
																							array2[num6 - 1] = 3;
																							goto IL_1b61;
																							IL_1b61:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1ba0;
																							IL_1ba0:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1bb3:
																							if (42 < b)
																							{
																								break;
																							}
																							goto IL_1bc1;
																							IL_1bc1:
																							if (42 > b)
																							{
																								break;
																							}
																							goto IL_1bcf;
																							IL_1bcf:
																							((Class17)array3[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																							goto IL_1bfd;
																							IL_1bfd:
																							num6 -= 2;
																							goto end_IL_089d;
																							IL_1c10:
																							if (50 >= b)
																							{
																								goto IL_1c1e;
																							}
																							goto IL_1f51;
																							IL_1c1e:
																							if (50 <= b)
																							{
																								goto IL_1c29;
																							}
																							goto IL_1c8f;
																							IL_1c29:
																							array2[num6 - 1] = 0;
																							goto IL_1c3d;
																							IL_1c3d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1c7c;
																							IL_1c7c:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1c8f:
																							if (46 >= b)
																							{
																								goto IL_1c9d;
																							}
																							goto IL_1de8;
																							IL_1c9d:
																							if (46 <= b)
																							{
																								goto IL_1ca8;
																							}
																							goto IL_1d07;
																							IL_1ca8:
																							array2[num6 - 1] = 5;
																							goto IL_1cbc;
																							IL_1cbc:
																							array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																							goto IL_1cf4;
																							IL_1cf4:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1d07:
																							if (44 >= b)
																							{
																								goto IL_1d12;
																							}
																							goto IL_1d6d;
																							IL_1d12:
																							if (44 > b)
																							{
																								break;
																							}
																							goto IL_1d20;
																							IL_1d20:
																							array2[num6] = 5;
																							goto IL_1d2e;
																							IL_1d2e:
																							array3[num6] = ((delegate*<GorillaTagger>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
																							goto IL_1d4c;
																							IL_1d4c:
																							num6++;
																							goto IL_1d5a;
																							IL_1d5a:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1d6d:
																							if (45 < b)
																							{
																								break;
																							}
																							goto IL_1d7b;
																							IL_1d7b:
																							if (45 > b)
																							{
																								break;
																							}
																							goto IL_1d89;
																							IL_1d89:
																							array2[num6 - 1] = 5;
																							goto IL_1d9d;
																							IL_1d9d:
																							array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																							goto IL_1dd5;
																							IL_1dd5:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1de8:
																							if (48 >= b)
																							{
																								goto IL_1df6;
																							}
																							goto IL_1ef3;
																							IL_1df6:
																							if (48 <= b)
																							{
																								goto IL_1e01;
																							}
																							goto IL_1e67;
																							IL_1e01:
																							array2[num6 - 1] = 0;
																							goto IL_1e15;
																							IL_1e15:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1e54;
																							IL_1e54:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_1e67:
																							if (47 < b)
																							{
																								break;
																							}
																							num = 297;
																							goto IL_1e7e;
																							IL_21d6:
																							array2[num6 - 1] = 5;
																							goto end_IL_089d;
																							IL_1e7e:
																							if (47 > b)
																							{
																								break;
																							}
																							goto IL_1e8c;
																							IL_1e8c:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1ecc;
																							IL_1ecc:
																							array2[num6 - 2] = 3;
																							goto IL_1ee0;
																							IL_1ee0:
																							num6--;
																							goto end_IL_089d;
																							IL_1ef3:
																							if (49 < b)
																							{
																								break;
																							}
																							goto IL_1f01;
																							IL_1f01:
																							if (49 > b)
																							{
																								break;
																							}
																							goto IL_1f0f;
																							IL_1f0f:
																							array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1f38;
																							IL_1f38:
																							array2[num6 - 1] = 5;
																							goto end_IL_089d;
																							IL_1f51:
																							if (54 < b)
																							{
																								goto IL_1f5f;
																							}
																							goto IL_2081;
																							IL_1f5f:
																							if (56 >= b)
																							{
																								goto IL_1f6d;
																							}
																							goto IL_2060;
																							IL_1f6d:
																							if (56 <= b)
																							{
																								goto IL_1f78;
																							}
																							goto IL_1f94;
																							IL_1f78:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto end_IL_089d;
																							IL_1f94:
																							if (55 < b)
																							{
																								break;
																							}
																							goto IL_1fa2;
																							IL_1fa2:
																							if (55 > b)
																							{
																								break;
																							}
																							goto IL_1fb0;
																							IL_1fb0:
																							array2[num6 - 4] = 0;
																							goto IL_1fc4;
																							IL_1fc4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																							goto IL_203f;
																							IL_203f:
																							num6 -= 3;
																							goto IL_204d;
																							IL_204d:
																							ptr2 += 8;
																							goto end_IL_089d;
																							IL_2060:
																							if (57 < b)
																							{
																								break;
																							}
																							goto IL_206e;
																							IL_206e:
																							if (57 > b)
																							{
																							}
																							break;
																							IL_2081:
																							if (54 <= b)
																							{
																								goto IL_208c;
																							}
																							goto IL_20ce;
																							IL_208c:
																							array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_20b5;
																							IL_20b5:
																							array2[num6 - 1] = 5;
																							goto end_IL_089d;
																							IL_20ce:
																							if (52 >= b)
																							{
																								goto IL_20dc;
																							}
																							goto IL_2197;
																							IL_20dc:
																							if (52 > b)
																							{
																								goto IL_20e7;
																							}
																							goto IL_2145;
																							IL_20e7:
																							if (51 < b)
																							{
																								break;
																							}
																							goto IL_20f5;
																							IL_20f5:
																							if (51 > b)
																							{
																								break;
																							}
																							goto IL_2103;
																							IL_2103:
																							array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_212c;
																							IL_212c:
																							array2[num6 - 1] = 5;
																							goto end_IL_089d;
																							IL_2145:
																							((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																							goto IL_217e;
																							IL_217e:
																							num6 -= 3;
																							num = 257;
																							goto end_IL_089d;
																							IL_2197:
																							if (53 < b)
																							{
																								break;
																							}
																							goto IL_21a2;
																						}
																						break;
																						IL_088d:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				continue;
																				end_IL_089d:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_21ff:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0dcb:
			while (true)
			{
				IL_0dcb_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					num = 165;
					while (true)
					{
						IL_0e7c_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0e8a_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_08bd_2:
									byte b = *ptr2;
									while (true)
									{
										IL_08ad_2:
										ptr2++;
										while (true)
										{
											IL_089d_2:
											if (b >= 1)
											{
												while (b <= 57)
												{
													while (true)
													{
														IL_087d_2:
														if (29 >= b)
														{
															while (true)
															{
																IL_086d_2:
																if (29 > b)
																{
																	while (true)
																	{
																		IL_0860_2:
																		if (14 < b)
																		{
																			while (true)
																			{
																				IL_0853_2:
																				if (21 < b)
																				{
																					while (true)
																					{
																						IL_0843_2:
																						if (25 >= b)
																						{
																							while (true)
																							{
																								IL_0833_2:
																								if (25 > b)
																								{
																									while (true)
																									{
																										IL_0823_2:
																										if (23 >= b)
																										{
																											while (true)
																											{
																												IL_0813_2:
																												if (23 > b)
																												{
																													while (22 >= b)
																													{
																														while (22 <= b)
																														{
																															while (true)
																															{
																																IL_079f_2:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																while (true)
																																{
																																	IL_0786_2:
																																	num6--;
																																	num = 473;
																																	while (num != 473)
																																	{
																																		if (num != 1454)
																																		{
																																			goto IL_1721_2;
																																		}
																																		switch (num)
																																		{
																																		case 64:
																																			goto IL_0786_2;
																																		case 269:
																																		case 381:
																																			goto IL_079f_2;
																																		case 26:
																																			goto IL_07f3_2;
																																		case 217:
																																			goto IL_0803_2;
																																		case 417:
																																			goto IL_0813_2;
																																		case 267:
																																			goto IL_0823_2;
																																		case 346:
																																			goto IL_0833_2;
																																		case 121:
																																			goto IL_0843_2;
																																		case 363:
																																			goto IL_0853_2;
																																		case 170:
																																			goto IL_0860_2;
																																		case 45:
																																			goto IL_086d_2;
																																		case 88:
																																			goto IL_087d_2;
																																		case 277:
																																			goto IL_088d_2;
																																		case 335:
																																			goto IL_089d_2;
																																		case 175:
																																			goto IL_08ad_2;
																																		case 185:
																																		case 209:
																																			goto IL_08bd_2;
																																		case 57:
																																			goto IL_08c8_2;
																																		case 216:
																																			goto IL_08db_2;
																																		case 114:
																																			goto IL_08e9_2;
																																		case 75:
																																			goto IL_08f7_2;
																																		case 86:
																																			goto IL_0905_2;
																																		case 74:
																																			goto IL_0910_2;
																																		case 247:
																																			goto IL_0920_2;
																																		case 9:
																																		case 179:
																																			goto IL_0937_2;
																																		case 54:
																																			goto IL_094f_2;
																																		case 248:
																																			goto IL_0972_2;
																																		case 276:
																																			goto IL_0985_2;
																																		case 39:
																																			goto IL_0993_2;
																																		case 256:
																																			goto IL_09a1_2;
																																		case 13:
																																			goto IL_09ac_2;
																																		case 139:
																																			goto IL_09ba_2;
																																		case 242:
																																			goto IL_09c5_2;
																																		case 271:
																																			goto IL_09d3_2;
																																		case 43:
																																			goto IL_09f4_2;
																																		case 236:
																																			goto IL_09ff_2;
																																		case 115:
																																			goto IL_0a0d_2;
																																		case 24:
																																			goto IL_0a20_2;
																																		case 84:
																																			goto IL_0a2e_2;
																																		case 134:
																																		case 280:
																																			goto IL_0a41_2;
																																		case 47:
																																		case 293:
																																			goto IL_0a6f_2;
																																		case 132:
																																			goto IL_0aaf_2;
																																		case 299:
																																			goto IL_0ac8_2;
																																		case 162:
																																			goto IL_0ad3_2;
																																		case 0:
																																			goto IL_0ae1_2;
																																		case 127:
																																			goto IL_0aef_2;
																																		case 309:
																																			goto IL_0b02_2;
																																		case 110:
																																			goto IL_0b10_2;
																																		case 244:
																																			goto IL_0b1e_2;
																																		case 164:
																																		case 313:
																																			goto IL_0b31_2;
																																		case 158:
																																			goto IL_0b6f_2;
																																		case 314:
																																			goto IL_0b82_2;
																																		case 283:
																																		case 327:
																																			goto IL_0b95_2;
																																		case 167:
																																		case 339:
																																			goto IL_0bc0_2;
																																		case 36:
																																			goto IL_0bce_2;
																																		case 42:
																																			goto IL_0be6_2;
																																		case 344:
																																			goto IL_0bf4_2;
																																		case 360:
																																			goto IL_0c07_2;
																																		case 190:
																																			goto IL_0c15_2;
																																		case 272:
																																		case 365:
																																			goto IL_0c28_2;
																																		case 250:
																																		case 366:
																																			goto IL_0c3b_2;
																																		case 214:
																																			goto IL_0c52_2;
																																		case 91:
																																			goto IL_0c75_2;
																																		case 340:
																																			goto IL_0c7f_2;
																																		case 34:
																																			goto IL_0c8d_2;
																																		case 58:
																																		case 372:
																																			goto IL_0ca0_2;
																																		case 189:
																																			goto IL_0d02_2;
																																		case 373:
																																			goto IL_0d15_2;
																																		case 208:
																																		case 376:
																																			goto IL_0d3e_2;
																																		case 263:
																																			goto IL_0d7e_2;
																																		case 378:
																																			goto IL_0d92_2;
																																		case 395:
																																			goto IL_0dae_2;
																																		case 29:
																																		case 270:
																																			goto end_IL_21ff_2;
																																		case 165:
																																			goto IL_0e7c_2;
																																		case 153:
																																			goto IL_0e8a_2;
																																		case 186:
																																			goto IL_0e9d_2;
																																		case 52:
																																			goto IL_0eab_2;
																																		case 397:
																																			goto IL_0ebe_2;
																																		case 258:
																																		case 292:
																																			goto IL_0ecc_2;
																																		case 291:
																																			goto IL_0ee5_2;
																																		case 341:
																																			goto IL_0ef3_2;
																																		case 385:
																																			goto IL_0f01_2;
																																		case 404:
																																			goto IL_0f14_2;
																																		case 329:
																																			goto IL_0f1f_2;
																																		case 218:
																																			goto IL_0f2a_2;
																																		case 384:
																																			goto IL_0f3d_2;
																																		case 412:
																																			goto IL_0f4b_2;
																																		case 70:
																																		case 330:
																																			goto IL_0f59_2;
																																		case 28:
																																		case 413:
																																			goto IL_0f71_2;
																																		case 281:
																																			goto IL_0f8a_2;
																																		case 409:
																																			goto IL_0f98_2;
																																		case 157:
																																		case 419:
																																			goto IL_0fab_2;
																																		case 421:
																																			goto IL_0ff9_2;
																																		case 403:
																																			goto IL_1011_2;
																																		case 94:
																																		case 424:
																																			goto IL_1024_2;
																																		case 125:
																																			goto IL_1065_2;
																																		case 422:
																																			goto IL_1079_2;
																																		case 425:
																																			goto IL_108c_2;
																																		case 93:
																																		case 151:
																																			goto IL_109a_2;
																																		case 259:
																																			goto IL_10ae_2;
																																		case 8:
																																			goto IL_10e6_2;
																																		case 432:
																																			goto IL_10f9_2;
																																		case 440:
																																			goto IL_110d_2;
																																		case 442:
																																			goto IL_1120_2;
																																		case 111:
																																		case 446:
																																			goto IL_1133_2;
																																		case 391:
																																			goto IL_114c_2;
																																		case 120:
																																			goto IL_115a_2;
																																		case 398:
																																			goto IL_1168_2;
																																		case 81:
																																		case 449:
																																			goto IL_1184_2;
																																		case 320:
																																			goto IL_11a2_2;
																																		case 12:
																																			goto IL_11b9_2;
																																		case 356:
																																		case 452:
																																			goto IL_11cc_2;
																																		case 11:
																																			goto IL_120c_2;
																																		case 196:
																																			goto IL_1220_2;
																																		case 453:
																																			goto IL_1233_2;
																																		case 458:
																																			goto IL_1246_2;
																																		case 461:
																																			goto IL_1268_2;
																																		case 174:
																																			goto IL_127f_2;
																																		case 37:
																																		case 282:
																																			goto IL_128d_2;
																																		case 212:
																																			goto IL_12cd_2;
																																		case 215:
																																			goto IL_12e1_2;
																																		case 234:
																																		case 317:
																																			goto IL_12fd_2;
																																		case 169:
																																			goto IL_130b_2;
																																		case 321:
																																			goto IL_132f_2;
																																		case 4:
																																			goto IL_133d_2;
																																		case 264:
																																			goto IL_1350_2;
																																		case 246:
																																			goto IL_135e_2;
																																		case 10:
																																		case 211:
																																			goto IL_136c_2;
																																		case 405:
																																			goto IL_1384_2;
																																		case 161:
																																			goto IL_1392_2;
																																		case 316:
																																			goto IL_13a0_2;
																																		case 224:
																																		case 240:
																																			goto IL_13bc_2;
																																		case 315:
																																			goto IL_13fa_2;
																																		case 109:
																																			goto IL_140e_2;
																																		case 464:
																																			goto IL_1421_2;
																																		case 300:
																																			goto IL_142f_2;
																																		case 5:
																																		case 437:
																																			goto IL_143a_2;
																																		case 221:
																																			goto IL_147a_2;
																																		case 71:
																																			goto IL_148e_2;
																																		case 286:
																																			goto IL_14a1_2;
																																		case 386:
																																			goto IL_14af_2;
																																		case 195:
																																		case 290:
																																			goto IL_14bd_2;
																																		case 198:
																																			goto IL_14d7_2;
																																		case 331:
																																			goto IL_14e5_2;
																																		case 423:
																																			goto IL_14f3_2;
																																		case 439:
																																			goto IL_1506_2;
																																		case 441:
																																			goto IL_1514_2;
																																		case 60:
																																		case 338:
																																			goto IL_152b_2;
																																		case 142:
																																			goto IL_1599_2;
																																		case 101:
																																			goto IL_15b5_2;
																																		case 393:
																																			goto IL_15c3_2;
																																		case 27:
																																		case 428:
																																			goto IL_15ce_2;
																																		case 140:
																																			goto IL_160e_2;
																																		case 32:
																																			goto IL_1622_2;
																																		case 349:
																																			goto IL_1635_2;
																																		case 82:
																																			goto IL_1643_2;
																																		case 25:
																																		case 116:
																																			goto IL_164e_2;
																																		case 160:
																																			goto IL_165c_2;
																																		case 229:
																																			goto IL_1680_2;
																																		case 206:
																																			goto IL_168e_2;
																																		case 155:
																																			goto IL_16a1_2;
																																		case 18:
																																			goto IL_16af_2;
																																		case 56:
																																		case 362:
																																			goto IL_16ba_2;
																																		case 400:
																																			goto IL_16c8_2;
																																		case 96:
																																			goto IL_16ec_2;
																																		case 33:
																																			goto IL_1703_2;
																																		case 455:
																																			goto IL_1716_2;
																																		case 131:
																																			goto IL_1721_2;
																																		case 205:
																																		case 379:
																																			goto IL_172f_2;
																																		case 463:
																																			goto IL_1743_2;
																																		case 112:
																																			goto IL_1782_2;
																																		case 304:
																																			goto IL_1795_2;
																																		case 336:
																																			goto IL_17a3_2;
																																		case 375:
																																		case 420:
																																			goto IL_17b1_2;
																																		case 343:
																																			goto IL_17c5_2;
																																		case 130:
																																			goto IL_1804_2;
																																		case 307:
																																			goto IL_1817_2;
																																		case 357:
																																			goto IL_1825_2;
																																		case 129:
																																		case 310:
																																			goto IL_1830_2;
																																		case 435:
																																			goto IL_1844_2;
																																		case 73:
																																			goto IL_1883_2;
																																		case 44:
																																			goto IL_1896_2;
																																		case 318:
																																			goto IL_18a4_2;
																																		case 213:
																																		case 226:
																																			goto IL_18b2_2;
																																		case 382:
																																			goto IL_1910_2;
																																		case 222:
																																			goto IL_1923_2;
																																		case 312:
																																			goto IL_1931_2;
																																		case 7:
																																		case 194:
																																			goto IL_193f_2;
																																		case 133:
																																			goto IL_197f_2;
																																		case 149:
																																			goto IL_1993_2;
																																		case 76:
																																			goto IL_19a6_2;
																																		case 123:
																																			goto IL_19b4_2;
																																		case 159:
																																		case 448:
																																			goto IL_19bf_2;
																																		case 144:
																																			goto IL_19d4_2;
																																		case 389:
																																			goto IL_19e7_2;
																																		case 117:
																																			goto IL_19f2_2;
																																		case 275:
																																		case 443:
																																			goto IL_1a09_2;
																																		case 173:
																																			goto IL_1a37_2;
																																		case 447:
																																			goto IL_1a4a_2;
																																		case 223:
																																			goto IL_1a58_2;
																																		case 141:
																																		case 239:
																																			goto IL_1a66_2;
																																		case 451:
																																			goto IL_1a91_2;
																																		case 436:
																																			goto IL_1aaa_2;
																																		case 41:
																																			goto IL_1ab8_2;
																																		case 445:
																																		case 462:
																																			goto IL_1ac3_2;
																																		case 126:
																																			goto IL_1b01_2;
																																		case 295:
																																			goto IL_1b1e_2;
																																		case 337:
																																			goto IL_1b31_2;
																																		case 319:
																																			goto IL_1b3f_2;
																																		case 67:
																																		case 266:
																																			goto IL_1b4d_2;
																																		case 69:
																																			goto IL_1b61_2;
																																		case 146:
																																			goto IL_1ba0_2;
																																		case 152:
																																			goto IL_1bb3_2;
																																		case 232:
																																			goto IL_1bc1_2;
																																		case 148:
																																		case 180:
																																			goto IL_1bcf_2;
																																		case 369:
																																			goto IL_1bfd_2;
																																		case 392:
																																			goto IL_1c10_2;
																																		case 351:
																																			goto IL_1c1e_2;
																																		case 1:
																																		case 6:
																																			goto IL_1c29_2;
																																		case 66:
																																			goto IL_1c3d_2;
																																		case 199:
																																			goto IL_1c7c_2;
																																		case 306:
																																			goto IL_1c8f_2;
																																		case 408:
																																			goto IL_1c9d_2;
																																		case 332:
																																		case 361:
																																			goto IL_1ca8_2;
																																		case 50:
																																			goto IL_1cbc_2;
																																		case 51:
																																			goto IL_1cf4_2;
																																		case 92:
																																			goto IL_1d07_2;
																																		case 285:
																																			goto IL_1d12_2;
																																		case 352:
																																		case 433:
																																			goto IL_1d20_2;
																																		case 31:
																																			goto IL_1d2e_2;
																																		case 294:
																																			goto IL_1d4c_2;
																																		case 230:
																																			goto IL_1d5a_2;
																																		case 278:
																																			goto IL_1d6d_2;
																																		case 465:
																																			goto IL_1d7b_2;
																																		case 78:
																																		case 354:
																																			goto IL_1d89_2;
																																		case 53:
																																			goto IL_1d9d_2;
																																		case 326:
																																			goto IL_1dd5_2;
																																		case 201:
																																			goto IL_1de8_2;
																																		case 301:
																																			goto IL_1df6_2;
																																		case 19:
																																		case 308:
																																			goto IL_1e01_2;
																																		case 355:
																																			goto IL_1e15_2;
																																		case 145:
																																			goto IL_1e54_2;
																																		case 333:
																																			goto IL_1e67_2;
																																		case 297:
																																			goto IL_1e7e_2;
																																		case 200:
																																		case 279:
																																			goto IL_1e8c_2;
																																		case 105:
																																			goto IL_1ecc_2;
																																		case 394:
																																			goto IL_1ee0_2;
																																		case 427:
																																			goto IL_1ef3_2;
																																		case 390:
																																			goto IL_1f01_2;
																																		case 128:
																																		case 311:
																																			goto IL_1f0f_2;
																																		case 113:
																																			goto IL_1f38_2;
																																		case 284:
																																			goto IL_1f51_2;
																																		case 328:
																																			goto IL_1f5f_2;
																																		case 202:
																																			goto IL_1f6d_2;
																																		case 38:
																																		case 203:
																																			goto IL_1f78_2;
																																		case 163:
																																			goto IL_1f94_2;
																																		case 138:
																																			goto IL_1fa2_2;
																																		case 176:
																																		case 192:
																																			goto IL_1fb0_2;
																																		case 191:
																																			goto IL_1fc4_2;
																																		case 188:
																																			goto IL_203f_2;
																																		case 106:
																																			goto IL_204d_2;
																																		case 416:
																																			goto IL_2060_2;
																																		case 63:
																																			goto IL_206e_2;
																																		case 124:
																																			goto IL_2081_2;
																																		case 322:
																																		case 342:
																																			goto IL_208c_2;
																																		case 388:
																																			goto IL_20b5_2;
																																		case 220:
																																			goto IL_20ce_2;
																																		case 103:
																																			goto IL_20dc_2;
																																		case 79:
																																			goto IL_20e7_2;
																																		case 204:
																																			goto IL_20f5_2;
																																		case 177:
																																		case 251:
																																			goto IL_2103_2;
																																		case 166:
																																			goto IL_212c_2;
																																		case 377:
																																		case 459:
																																			goto IL_2145_2;
																																		case 228:
																																			goto IL_217e_2;
																																		case 55:
																																			goto IL_2197_2;
																																		case 235:
																																			goto IL_21a2_2;
																																		case 233:
																																		case 261:
																																			goto IL_21ad_2;
																																		case 108:
																																			goto IL_21d6_2;
																																		case 3:
																																		case 15:
																																		case 17:
																																		case 35:
																																		case 48:
																																		case 49:
																																		case 65:
																																		case 68:
																																		case 72:
																																		case 77:
																																		case 85:
																																		case 87:
																																		case 89:
																																		case 90:
																																		case 95:
																																		case 98:
																																		case 118:
																																		case 122:
																																		case 137:
																																		case 143:
																																		case 147:
																																		case 150:
																																		case 154:
																																		case 156:
																																		case 168:
																																		case 187:
																																		case 197:
																																		case 207:
																																		case 238:
																																		case 253:
																																		case 254:
																																		case 260:
																																		case 262:
																																		case 265:
																																		case 268:
																																		case 298:
																																		case 302:
																																		case 305:
																																		case 323:
																																		case 324:
																																		case 334:
																																		case 347:
																																		case 353:
																																		case 364:
																																		case 367:
																																		case 371:
																																		case 374:
																																		case 387:
																																		case 396:
																																		case 401:
																																		case 406:
																																		case 410:
																																		case 411:
																																		case 426:
																																		case 430:
																																		case 431:
																																		case 434:
																																		case 450:
																																		case 456:
																																		case 466:
																																			goto end_IL_07f3_2;
																																		case 2:
																																		case 14:
																																		case 16:
																																		case 20:
																																		case 23:
																																		case 30:
																																		case 40:
																																		case 46:
																																		case 59:
																																		case 61:
																																		case 62:
																																		case 83:
																																		case 97:
																																		case 99:
																																		case 100:
																																		case 102:
																																		case 104:
																																		case 107:
																																		case 119:
																																		case 136:
																																		case 171:
																																		case 172:
																																		case 181:
																																		case 183:
																																		case 184:
																																		case 193:
																																		case 210:
																																		case 225:
																																		case 227:
																																		case 231:
																																		case 237:
																																		case 241:
																																		case 243:
																																		case 249:
																																		case 252:
																																		case 255:
																																		case 257:
																																		case 273:
																																		case 287:
																																		case 288:
																																		case 296:
																																		case 303:
																																		case 345:
																																		case 348:
																																		case 350:
																																		case 358:
																																		case 359:
																																		case 368:
																																		case 370:
																																		case 380:
																																		case 383:
																																		case 414:
																																		case 415:
																																		case 418:
																																		case 429:
																																		case 438:
																																		case 454:
																																		case 457:
																																		case 460:
																																			goto end_IL_0773_2;
																																		case 274:
																																			ptr2 = ptr;
																																			goto end_IL_0773_2;
																																		case 407:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HasLabelUndefined.hasLabelUndefined_0);
																																			goto case 274;
																																		case 219:
																																			array7[0] = this;
																																			goto case 407;
																																		case 444:
																																			array7 = new object[14];
																																			goto case 219;
																																		case 325:
																																			array6 = new long[8];
																																			goto case 444;
																																		case 289:
																																			array5 = new int[7];
																																			goto case 325;
																																		case 245:
																																			array4 = new int[8];
																																			goto case 289;
																																		case 178:
																																			array3 = new object[8];
																																			goto case 245;
																																		case 80:
																																			array2 = new byte[8];
																																			num = 178;
																																			goto case 178;
																																		case 135:
																																			num4 = num2 * 8;
																																			goto case 80;
																																		case 399:
																																			num3 = num2 * 4;
																																			num = 135;
																																			goto case 135;
																																		case 21:
																																			num2 = 1;
																																			goto case 399;
																																		case 22:
																																			goto end_IL_0dd9;
																																		case 182:
																																		case 402:
																																			return;
																																		}
																																		continue;
																																		end_IL_0773_2:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_089d_2;
																															continue;
																															end_IL_07f3_2:
																															break;
																															IL_07f3_2:;
																														}
																														break;
																														IL_0803_2:;
																													}
																													break;
																												}
																												num = 234;
																												goto IL_12fd_2;
																												IL_132f_2:
																												num6++;
																												goto IL_133d_2;
																												IL_133d_2:
																												ptr2 += 8;
																												goto end_IL_089d_2;
																												IL_12fd_2:
																												array2[num6] = 3;
																												goto IL_130b_2;
																												IL_130b_2:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
																												goto IL_132f_2;
																											}
																											break;
																										}
																										goto IL_1350_2;
																										IL_13a0_2:
																										ptr2 += 8;
																										goto end_IL_089d_2;
																										IL_1350_2:
																										if (24 < b)
																										{
																											break;
																										}
																										goto IL_135e_2;
																										IL_135e_2:
																										if (24 > b)
																										{
																											break;
																										}
																										goto IL_136c_2;
																										IL_136c_2:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_1384_2;
																										IL_1384_2:
																										array2[num6] = 5;
																										goto IL_1392_2;
																										IL_1392_2:
																										num6++;
																										goto IL_13a0_2;
																									}
																									break;
																								}
																								num = 240;
																								goto IL_13bc_2;
																								IL_13fa_2:
																								array2[num6 - 1] = 3;
																								goto IL_140e_2;
																								IL_140e_2:
																								ptr2 += 8;
																								goto end_IL_089d_2;
																								IL_13bc_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class17, float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((Class17)array3[num6 - 1]);
																								goto IL_13fa_2;
																							}
																							break;
																						}
																						goto IL_1421_2;
																						IL_152b_2:
																						ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1599_2;
																						IL_1421_2:
																						if (27 >= b)
																						{
																							goto IL_142f_2;
																						}
																						goto IL_1506_2;
																						IL_142f_2:
																						if (27 <= b)
																						{
																							goto IL_143a_2;
																						}
																						goto IL_14a1_2;
																						IL_143a_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_147a_2;
																						IL_147a_2:
																						array2[num6 - 2] = 3;
																						goto IL_148e_2;
																						IL_148e_2:
																						num6--;
																						goto end_IL_089d_2;
																						IL_14a1_2:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_14af_2;
																						IL_14af_2:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_14bd_2;
																						IL_14bd_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																						goto IL_14d7_2;
																						IL_14d7_2:
																						array2[num6] = 3;
																						goto IL_14e5_2;
																						IL_14e5_2:
																						num6++;
																						goto IL_14f3_2;
																						IL_14f3_2:
																						ptr2 += 8;
																						goto end_IL_089d_2;
																						IL_1506_2:
																						if (28 < b)
																						{
																							break;
																						}
																						goto IL_1514_2;
																						IL_1514_2:
																						if (28 > b)
																						{
																							break;
																						}
																						num = 60;
																						goto IL_152b_2;
																						IL_1599_2:
																						num6 -= 2;
																						num = 100;
																						goto end_IL_089d_2;
																					}
																					break;
																				}
																				goto IL_08db_2;
																				IL_1065_2:
																				array2[num6 - 2] = 0;
																				goto IL_1079_2;
																				IL_08db_2:
																				if (21 > b)
																				{
																					goto IL_08e9_2;
																				}
																				goto IL_1024_2;
																				IL_08e9_2:
																				if (17 >= b)
																				{
																					goto IL_08f7_2;
																				}
																				goto IL_0f14_2;
																				IL_08f7_2:
																				if (17 > b)
																				{
																					goto IL_0905_2;
																				}
																				goto IL_0b31_2;
																				IL_0905_2:
																				if (15 < b)
																				{
																					goto IL_0910_2;
																				}
																				goto IL_0920_2;
																				IL_0910_2:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_0972_2;
																				IL_0972_2:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_0bc0_2;
																				IL_0bc0_2:
																				array2[num6] = 5;
																				goto IL_0bce_2;
																				IL_0bce_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0be6_2;
																				IL_0be6_2:
																				num6++;
																				goto IL_0bf4_2;
																				IL_0bf4_2:
																				ptr2 += 8;
																				goto end_IL_089d_2;
																				IL_0920_2:
																				if (15 > b)
																				{
																					break;
																				}
																				num = 9;
																				goto IL_0937_2;
																				IL_1079_2:
																				num6--;
																				goto end_IL_089d_2;
																				IL_0937_2:
																				array2[num6] = array2[num6 - 1];
																				goto IL_094f_2;
																				IL_094f_2:
																				array4[num6 - 0] = array4[num6 - 1];
																				goto IL_0d15_2;
																				IL_0d15_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0ff9_2;
																				IL_0ff9_2:
																				array3[num6] = array3[num6 - 1];
																				goto IL_1011_2;
																				IL_1011_2:
																				num6++;
																				goto end_IL_089d_2;
																				IL_0b31_2:
																				((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																				goto IL_0b6f_2;
																				IL_0b6f_2:
																				num6 -= 3;
																				goto end_IL_089d_2;
																				IL_0f14_2:
																				if (19 >= b)
																				{
																					goto IL_0f1f_2;
																				}
																				goto IL_0f3d_2;
																				IL_0f1f_2:
																				if (19 > b)
																				{
																					goto IL_0f2a_2;
																				}
																				goto IL_0f71_2;
																				IL_0f2a_2:
																				if (18 < b)
																				{
																					break;
																				}
																				goto IL_108c_2;
																				IL_108c_2:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_109a_2;
																				IL_109a_2:
																				array2[num6 - 1] = 5;
																				goto IL_10ae_2;
																				IL_10ae_2:
																				array3[num6 - 1] = ((delegate*<string[], string>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																				goto IL_10e6_2;
																				IL_10e6_2:
																				ptr2 += 8;
																				goto end_IL_089d_2;
																				IL_0f71_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0f8a_2;
																				IL_0f8a_2:
																				array2[num6] = 1;
																				goto IL_0f98_2;
																				IL_0f98_2:
																				num6++;
																				goto IL_1233_2;
																				IL_1233_2:
																				ptr2 += 16;
																				goto end_IL_089d_2;
																				IL_0f3d_2:
																				if (20 < b)
																				{
																					break;
																				}
																				goto IL_0f4b_2;
																				IL_0f4b_2:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_0f59_2;
																				IL_0f59_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_089d_2;
																				IL_1024_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																				goto IL_1065_2;
																			}
																			break;
																		}
																		goto IL_08c8_2;
																		IL_0eab_2:
																		if (11 > b)
																		{
																			break;
																		}
																		goto end_IL_089d_2;
																		IL_08c8_2:
																		if (14 > b)
																		{
																			goto IL_0985_2;
																		}
																		goto IL_0a41_2;
																		IL_0985_2:
																		if (7 >= b)
																		{
																			goto IL_0993_2;
																		}
																		goto IL_0ac8_2;
																		IL_0993_2:
																		if (7 > b)
																		{
																			goto IL_09a1_2;
																		}
																		goto IL_0a6f_2;
																		IL_09a1_2:
																		if (3 >= b)
																		{
																			goto IL_09ac_2;
																		}
																		goto IL_09f4_2;
																		IL_09ac_2:
																		if (3 > b)
																		{
																			goto IL_09ba_2;
																		}
																		goto IL_0b95_2;
																		IL_09ba_2:
																		if (1 < b)
																		{
																			goto IL_09c5_2;
																		}
																		num = 397;
																		goto IL_0ebe_2;
																		IL_09c5_2:
																		if (2 < b)
																		{
																			break;
																		}
																		goto IL_09d3_2;
																		IL_09d3_2:
																		if (2 > b)
																		{
																			break;
																		}
																		goto IL_0fab_2;
																		IL_0fab_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 432;
																		goto IL_10f9_2;
																		IL_10f9_2:
																		array2[num6 - 2] = 0;
																		goto IL_110d_2;
																		IL_110d_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_0a41_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_1246_2;
																		IL_0ebe_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0ecc_2;
																		IL_0ecc_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0ee5_2;
																		IL_0ee5_2:
																		array2[num6] = 0;
																		goto IL_0ef3_2;
																		IL_0ef3_2:
																		num6++;
																		goto IL_0f01_2;
																		IL_0f01_2:
																		ptr2 += 8;
																		goto end_IL_089d_2;
																		IL_0b95_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0c07_2;
																		IL_0c07_2:
																		ptr2 += 8;
																		goto IL_0c15_2;
																		IL_0c15_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_09f4_2:
																		if (5 >= b)
																		{
																			goto IL_09ff_2;
																		}
																		goto IL_0a20_2;
																		IL_09ff_2:
																		if (5 > b)
																		{
																			goto IL_0a0d_2;
																		}
																		goto IL_11cc_2;
																		IL_0a0d_2:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_0b82_2;
																		IL_0b82_2:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_0c3b_2;
																		IL_0c3b_2:
																		array2[num6] = 0;
																		num = 214;
																		goto IL_0c52_2;
																		IL_0c52_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_0c75_2;
																		IL_0c75_2:
																		array3[num6] = null;
																		goto IL_0c7f_2;
																		IL_0c7f_2:
																		num6++;
																		goto IL_0c8d_2;
																		IL_0c8d_2:
																		ptr2 += 8;
																		goto end_IL_089d_2;
																		IL_11cc_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_120c_2;
																		IL_120c_2:
																		array2[num6 - 2] = 0;
																		goto IL_1220_2;
																		IL_1220_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_0a20_2:
																		if (6 < b)
																		{
																			break;
																		}
																		goto IL_0a2e_2;
																		IL_0a2e_2:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_0d3e_2;
																		IL_0d3e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0d7e_2;
																		IL_0d7e_2:
																		array2[num6 - 2] = 0;
																		goto IL_0d92_2;
																		IL_0d92_2:
																		num6--;
																		num = 136;
																		goto end_IL_089d_2;
																		IL_0a6f_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0aaf_2;
																		IL_0aaf_2:
																		array2[num6 - 2] = 0;
																		goto IL_1120_2;
																		IL_1120_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_0ac8_2:
																		if (10 >= b)
																		{
																			goto IL_0ad3_2;
																		}
																		goto IL_0b02_2;
																		IL_0ad3_2:
																		if (10 > b)
																		{
																			goto IL_0ae1_2;
																		}
																		goto IL_0ca0_2;
																		IL_0ae1_2:
																		if (8 >= b)
																		{
																			goto IL_0aef_2;
																		}
																		goto IL_1268_2;
																		IL_0aef_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0c28_2;
																		IL_0c28_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_1268_2:
																		if (9 < b)
																		{
																			break;
																		}
																		num = 174;
																		goto IL_127f_2;
																		IL_1246_2:
																		array2[num6 - 1] = 5;
																		num = 20;
																		goto end_IL_089d_2;
																		IL_127f_2:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_128d_2;
																		IL_128d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_12cd_2;
																		IL_12cd_2:
																		array2[num6 - 2] = 0;
																		goto IL_12e1_2;
																		IL_12e1_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_0ca0_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0d02_2;
																		IL_0d02_2:
																		num6 -= 2;
																		goto end_IL_089d_2;
																		IL_0b02_2:
																		if (12 < b)
																		{
																			goto IL_0b10_2;
																		}
																		goto IL_0dae_2;
																		IL_0b10_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_0b1e_2;
																		IL_0b1e_2:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_1184_2;
																		IL_1184_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_11a2_2;
																		IL_11a2_2:
																		ptr2 += 8;
																		num = 12;
																		goto IL_11b9_2;
																		IL_11b9_2:
																		num6--;
																		goto end_IL_089d_2;
																		IL_0dae_2:
																		if (12 <= b)
																		{
																			goto end_IL_21ff_2;
																		}
																		goto IL_0e9d_2;
																		IL_0e9d_2:
																		if (11 < b)
																		{
																			break;
																		}
																		goto IL_0eab_2;
																	}
																	break;
																}
																goto IL_1133_2;
																IL_1168_2:
																ptr2 += 16;
																num = 380;
																goto end_IL_089d_2;
																IL_1133_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																goto IL_114c_2;
																IL_114c_2:
																array2[num6] = 3;
																goto IL_115a_2;
																IL_115a_2:
																num6++;
																goto IL_1168_2;
															}
															break;
														}
														goto IL_15b5_2;
														IL_21a2_2:
														if (53 > b)
														{
															break;
														}
														goto IL_21ad_2;
														IL_15b5_2:
														if (43 >= b)
														{
															goto IL_15c3_2;
														}
														goto IL_1c10_2;
														IL_15c3_2:
														if (43 <= b)
														{
															goto IL_15ce_2;
														}
														goto IL_1635_2;
														IL_15ce_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_160e_2;
														IL_160e_2:
														array2[num6 - 2] = 3;
														goto IL_1622_2;
														IL_1622_2:
														num6--;
														goto end_IL_089d_2;
														IL_1635_2:
														if (36 >= b)
														{
															goto IL_1643_2;
														}
														goto IL_19a6_2;
														IL_1643_2:
														if (36 <= b)
														{
															goto IL_164e_2;
														}
														goto IL_16a1_2;
														IL_164e_2:
														array2[num6] = 3;
														goto IL_165c_2;
														IL_165c_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
														goto IL_1680_2;
														IL_1680_2:
														num6++;
														goto IL_168e_2;
														IL_168e_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_16a1_2:
														if (32 >= b)
														{
															goto IL_16af_2;
														}
														goto IL_1817_2;
														IL_16af_2:
														if (32 <= b)
														{
															goto IL_16ba_2;
														}
														goto IL_1716_2;
														IL_16ba_2:
														array2[num6] = 0;
														goto IL_16c8_2;
														IL_16c8_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_16ec_2;
														IL_16ec_2:
														num6++;
														num = 33;
														goto IL_1703_2;
														IL_1703_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1716_2:
														if (30 >= b)
														{
															goto IL_1721_2;
														}
														goto IL_1795_2;
														IL_1721_2:
														if (30 > b)
														{
															break;
														}
														goto IL_172f_2;
														IL_172f_2:
														array2[num6 - 1] = 3;
														goto IL_1743_2;
														IL_1743_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1782_2;
														IL_1782_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1795_2:
														if (31 < b)
														{
															break;
														}
														goto IL_17a3_2;
														IL_17a3_2:
														if (31 > b)
														{
															break;
														}
														goto IL_17b1_2;
														IL_17b1_2:
														array2[num6 - 1] = 0;
														goto IL_17c5_2;
														IL_17c5_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1804_2;
														IL_1804_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1817_2:
														if (34 >= b)
														{
															goto IL_1825_2;
														}
														goto IL_1923_2;
														IL_1825_2:
														if (34 <= b)
														{
															goto IL_1830_2;
														}
														goto IL_1896_2;
														IL_1830_2:
														array2[num6 - 1] = 3;
														goto IL_1844_2;
														IL_1844_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1883_2;
														IL_1883_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1896_2:
														if (33 < b)
														{
															break;
														}
														goto IL_18a4_2;
														IL_18a4_2:
														if (33 > b)
														{
															break;
														}
														goto IL_18b2_2;
														IL_18b2_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1910_2;
														IL_1910_2:
														num6--;
														goto end_IL_089d_2;
														IL_1923_2:
														if (35 < b)
														{
															break;
														}
														goto IL_1931_2;
														IL_1931_2:
														if (35 > b)
														{
															break;
														}
														goto IL_193f_2;
														IL_193f_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_197f_2;
														IL_197f_2:
														array2[num6 - 2] = 3;
														goto IL_1993_2;
														IL_1993_2:
														num6--;
														goto end_IL_089d_2;
														IL_19a6_2:
														if (39 >= b)
														{
															goto IL_19b4_2;
														}
														goto IL_1aaa_2;
														IL_19b4_2:
														if (39 <= b)
														{
															goto IL_19bf_2;
														}
														goto IL_19e7_2;
														IL_19bf_2:
														((delegate*<void>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
														goto IL_19d4_2;
														IL_19d4_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_19e7_2:
														if (37 >= b)
														{
															goto IL_19f2_2;
														}
														goto IL_1a4a_2;
														IL_19f2_2:
														if (37 > b)
														{
															break;
														}
														num = 275;
														goto IL_1a09_2;
														IL_21ad_2:
														array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
														goto IL_21d6_2;
														IL_1a09_2:
														((Class17)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1a37_2;
														IL_1a37_2:
														num6 -= 2;
														goto end_IL_089d_2;
														IL_1a4a_2:
														if (38 < b)
														{
															break;
														}
														goto IL_1a58_2;
														IL_1a58_2:
														if (38 > b)
														{
															break;
														}
														goto IL_1a66_2;
														IL_1a66_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1a91_2;
														IL_1a91_2:
														array2[num6 - 1] = 0;
														goto end_IL_089d_2;
														IL_1aaa_2:
														if (41 >= b)
														{
															goto IL_1ab8_2;
														}
														goto IL_1bb3_2;
														IL_1ab8_2:
														if (41 <= b)
														{
															goto IL_1ac3_2;
														}
														goto IL_1b31_2;
														IL_1ac3_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class17, bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((Class17)array3[num6 - 1]) ? 1 : 0);
														goto IL_1b01_2;
														IL_1b01_2:
														array2[num6 - 1] = 0;
														num = 295;
														goto IL_1b1e_2;
														IL_1b1e_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1b31_2:
														if (40 < b)
														{
															break;
														}
														goto IL_1b3f_2;
														IL_1b3f_2:
														if (40 > b)
														{
															break;
														}
														goto IL_1b4d_2;
														IL_1b4d_2:
														array2[num6 - 1] = 3;
														goto IL_1b61_2;
														IL_1b61_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1ba0_2;
														IL_1ba0_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1bb3_2:
														if (42 < b)
														{
															break;
														}
														goto IL_1bc1_2;
														IL_1bc1_2:
														if (42 > b)
														{
															break;
														}
														goto IL_1bcf_2;
														IL_1bcf_2:
														((Class17)array3[num6 - 2]).bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
														goto IL_1bfd_2;
														IL_1bfd_2:
														num6 -= 2;
														goto end_IL_089d_2;
														IL_1c10_2:
														if (50 >= b)
														{
															goto IL_1c1e_2;
														}
														goto IL_1f51_2;
														IL_1c1e_2:
														if (50 <= b)
														{
															goto IL_1c29_2;
														}
														goto IL_1c8f_2;
														IL_1c29_2:
														array2[num6 - 1] = 0;
														goto IL_1c3d_2;
														IL_1c3d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1c7c_2;
														IL_1c7c_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1c8f_2:
														if (46 >= b)
														{
															goto IL_1c9d_2;
														}
														goto IL_1de8_2;
														IL_1c9d_2:
														if (46 <= b)
														{
															goto IL_1ca8_2;
														}
														goto IL_1d07_2;
														IL_1ca8_2:
														array2[num6 - 1] = 5;
														goto IL_1cbc_2;
														IL_1cbc_2:
														array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
														goto IL_1cf4_2;
														IL_1cf4_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1d07_2:
														if (44 >= b)
														{
															goto IL_1d12_2;
														}
														goto IL_1d6d_2;
														IL_1d12_2:
														if (44 > b)
														{
															break;
														}
														goto IL_1d20_2;
														IL_1d20_2:
														array2[num6] = 5;
														goto IL_1d2e_2;
														IL_1d2e_2:
														array3[num6] = ((delegate*<GorillaTagger>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])();
														goto IL_1d4c_2;
														IL_1d4c_2:
														num6++;
														goto IL_1d5a_2;
														IL_1d5a_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1d6d_2:
														if (45 < b)
														{
															break;
														}
														goto IL_1d7b_2;
														IL_1d7b_2:
														if (45 > b)
														{
															break;
														}
														goto IL_1d89_2;
														IL_1d89_2:
														array2[num6 - 1] = 5;
														goto IL_1d9d_2;
														IL_1d9d_2:
														array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_1dd5_2;
														IL_1dd5_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1de8_2:
														if (48 >= b)
														{
															goto IL_1df6_2;
														}
														goto IL_1ef3_2;
														IL_1df6_2:
														if (48 <= b)
														{
															goto IL_1e01_2;
														}
														goto IL_1e67_2;
														IL_1e01_2:
														array2[num6 - 1] = 0;
														goto IL_1e15_2;
														IL_1e15_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1e54_2;
														IL_1e54_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_1e67_2:
														if (47 < b)
														{
															break;
														}
														num = 297;
														goto IL_1e7e_2;
														IL_21d6_2:
														array2[num6 - 1] = 5;
														goto end_IL_089d_2;
														IL_1e7e_2:
														if (47 > b)
														{
															break;
														}
														goto IL_1e8c_2;
														IL_1e8c_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1ecc_2;
														IL_1ecc_2:
														array2[num6 - 2] = 3;
														goto IL_1ee0_2;
														IL_1ee0_2:
														num6--;
														goto end_IL_089d_2;
														IL_1ef3_2:
														if (49 < b)
														{
															break;
														}
														goto IL_1f01_2;
														IL_1f01_2:
														if (49 > b)
														{
															break;
														}
														goto IL_1f0f_2;
														IL_1f0f_2:
														array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1f38_2;
														IL_1f38_2:
														array2[num6 - 1] = 5;
														goto end_IL_089d_2;
														IL_1f51_2:
														if (54 < b)
														{
															goto IL_1f5f_2;
														}
														goto IL_2081_2;
														IL_1f5f_2:
														if (56 >= b)
														{
															goto IL_1f6d_2;
														}
														goto IL_2060_2;
														IL_1f6d_2:
														if (56 <= b)
														{
															goto IL_1f78_2;
														}
														goto IL_1f94_2;
														IL_1f78_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto end_IL_089d_2;
														IL_1f94_2:
														if (55 < b)
														{
															break;
														}
														goto IL_1fa2_2;
														IL_1fa2_2:
														if (55 > b)
														{
															break;
														}
														goto IL_1fb0_2;
														IL_1fb0_2:
														array2[num6 - 4] = 0;
														goto IL_1fc4_2;
														IL_1fc4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)TransformDispRetValsHostResolvePolicy[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
														goto IL_203f_2;
														IL_203f_2:
														num6 -= 3;
														goto IL_204d_2;
														IL_204d_2:
														ptr2 += 8;
														goto end_IL_089d_2;
														IL_2060_2:
														if (57 < b)
														{
															break;
														}
														goto IL_206e_2;
														IL_206e_2:
														if (57 > b)
														{
														}
														break;
														IL_2081_2:
														if (54 <= b)
														{
															goto IL_208c_2;
														}
														goto IL_20ce_2;
														IL_208c_2:
														array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_20b5_2;
														IL_20b5_2:
														array2[num6 - 1] = 5;
														goto end_IL_089d_2;
														IL_20ce_2:
														if (52 >= b)
														{
															goto IL_20dc_2;
														}
														goto IL_2197_2;
														IL_20dc_2:
														if (52 > b)
														{
															goto IL_20e7_2;
														}
														goto IL_2145_2;
														IL_20e7_2:
														if (51 < b)
														{
															break;
														}
														goto IL_20f5_2;
														IL_20f5_2:
														if (51 > b)
														{
															break;
														}
														goto IL_2103_2;
														IL_2103_2:
														array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_212c_2;
														IL_212c_2:
														array2[num6 - 1] = 5;
														goto end_IL_089d_2;
														IL_2145_2:
														((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
														goto IL_217e_2;
														IL_217e_2:
														num6 -= 3;
														num = 257;
														goto end_IL_089d_2;
														IL_2197_2:
														if (53 < b)
														{
															break;
														}
														goto IL_21a2_2;
													}
													break;
													IL_088d_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											break;
											continue;
											end_IL_089d_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_21ff_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0dcb_2;
					}
					continue;
					end_IL_0dd9:
					break;
				}
				break;
			}
		}
	}

	public Class17()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		int num3;
		if (num <= num2)
		{
			num = int_1;
			num2 = int_0;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_0;
			num2 = int_1;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 252;
		num2 = 36;
		int num4 = smethod_3(36, 41);
		num2 = num4;
		return num;
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 102;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 101;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetAddMethodConfigurationBytesValue.FullFrameworkCultures);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 117;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_030e:
																byte b = *ptr2;
																while (true)
																{
																	IL_02fe:
																	ptr2++;
																	while (true)
																	{
																		IL_02ee:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_02cb:
																					if (6 < b)
																					{
																						num = 14;
																						while (true)
																						{
																							IL_02be:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_02b1:
																									if (9 <= b)
																									{
																										while (true)
																										{
																											IL_026f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_0259:
																												array[num5 - 2] = 0;
																												while (true)
																												{
																													IL_0240:
																													num5--;
																													num = 132;
																													while (num != 132)
																													{
																														if (num != 1113)
																														{
																															goto IL_0668;
																														}
																														switch (num)
																														{
																														case 55:
																															goto IL_0240;
																														case 93:
																															goto IL_0259;
																														case 77:
																														case 98:
																															goto IL_026f;
																														case 42:
																															goto IL_02b1;
																														case 14:
																														case 104:
																															goto IL_02be;
																														case 80:
																															goto IL_02cb;
																														case 24:
																															goto IL_02de;
																														case 83:
																															goto IL_02ee;
																														case 57:
																															goto IL_02fe;
																														case 37:
																														case 109:
																															goto IL_030e;
																														case 12:
																															goto IL_0319;
																														case 21:
																															goto IL_0327;
																														case 56:
																														case 74:
																															goto IL_033a;
																														case 33:
																															goto IL_0348;
																														case 3:
																															goto IL_0356;
																														case 95:
																															goto IL_0369;
																														case 64:
																															goto IL_0377;
																														case 13:
																															goto IL_0385;
																														case 4:
																															goto IL_0393;
																														case 31:
																															goto IL_039e;
																														case 85:
																															goto IL_03b1;
																														case 18:
																															goto IL_03bf;
																														case 53:
																														case 90:
																															goto IL_03cd;
																														case 30:
																															goto IL_043b;
																														case 96:
																															goto IL_044e;
																														case 100:
																															goto IL_0461;
																														case 72:
																														case 79:
																															goto IL_046f;
																														case 2:
																															goto IL_0483;
																														case 75:
																															goto IL_04d7;
																														case 69:
																															goto IL_04e5;
																														case 27:
																														case 107:
																															goto IL_04f8;
																														case 46:
																														case 112:
																															goto IL_050b;
																														case 92:
																															goto IL_0516;
																														case 63:
																														case 81:
																															goto IL_0524;
																														case 50:
																															goto IL_054d;
																														case 61:
																															goto IL_0560;
																														case 97:
																															goto IL_056e;
																														case 47:
																														case 54:
																															goto IL_057c;
																														case 65:
																														case 114:
																															goto IL_0594;
																														case 67:
																															goto IL_05d4;
																														case 16:
																															goto IL_05e8;
																														case 106:
																														case 116:
																															goto IL_05fb;
																														case 86:
																															goto IL_061d;
																														case 111:
																															goto IL_062b;
																														case 34:
																															goto IL_0639;
																														case 119:
																															goto IL_064c;
																														case 28:
																														case 94:
																															goto IL_065a;
																														case 60:
																															goto IL_0668;
																														case 5:
																															goto IL_068b;
																														case 110:
																															goto IL_0695;
																														case 99:
																															goto IL_06a3;
																														case 121:
																															goto IL_06bf;
																														case 62:
																														case 122:
																															goto IL_06cf;
																														case 36:
																															goto IL_06da;
																														case 11:
																														case 59:
																															goto IL_06e5;
																														case 0:
																														case 6:
																														case 9:
																														case 15:
																														case 19:
																														case 22:
																														case 25:
																														case 29:
																														case 35:
																														case 41:
																														case 44:
																														case 45:
																														case 49:
																														case 66:
																														case 76:
																														case 84:
																														case 88:
																														case 89:
																														case 103:
																														case 105:
																														case 108:
																														case 113:
																														case 118:
																														case 120:
																														case 123:
																															goto end_IL_02de;
																														case 26:
																															goto IL_0721;
																														case 82:
																															goto IL_072f;
																														case 58:
																															goto IL_073d;
																														case 1:
																														case 7:
																														case 10:
																														case 17:
																														case 43:
																														case 52:
																														case 70:
																														case 73:
																														case 78:
																														case 87:
																														case 117:
																														case 124:
																														case 125:
																															goto end_IL_022d;
																														case 8:
																															goto end_IL_074b;
																														case 20:
																															goto end_IL_075e;
																														case 39:
																															goto end_IL_0769;
																														case 51:
																															goto end_IL_0773;
																														case 23:
																															goto end_IL_077e;
																														case 91:
																															goto end_IL_0793;
																														case 32:
																														case 115:
																															goto end_IL_07a8;
																														case 71:
																															goto end_IL_07b8;
																														case 40:
																														case 68:
																															goto end_IL_07c8;
																														case 101:
																															goto end_IL_07d8;
																														case 102:
																															goto end_IL_07e8;
																														case 38:
																														case 48:
																															goto IL_080c;
																														}
																														continue;
																														end_IL_022d:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0319;
																									IL_06a3:
																									ptr2 += 8;
																									num = 7;
																									break;
																									IL_0319:
																									if (7 < b)
																									{
																										goto IL_0327;
																									}
																									goto IL_064c;
																									IL_0327:
																									if (8 < b)
																									{
																										goto end_IL_02de;
																									}
																									goto IL_044e;
																									IL_044e:
																									if (8 > b)
																									{
																										goto end_IL_02de;
																									}
																									goto IL_05fb;
																									IL_05fb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									num = 86;
																									goto IL_061d;
																									IL_061d:
																									array[num5] = 0;
																									goto IL_062b;
																									IL_062b:
																									num5++;
																									goto IL_0639;
																									IL_0639:
																									ptr2 += 8;
																									break;
																									IL_064c:
																									if (7 > b)
																									{
																										goto end_IL_02de;
																									}
																									goto IL_065a;
																									IL_065a:
																									array[num5] = 0;
																									goto IL_0668;
																									IL_0668:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_068b;
																									IL_068b:
																									array2[num5] = null;
																									goto IL_0695;
																									IL_0695:
																									num5++;
																									goto IL_06a3;
																								}
																								break;
																							}
																							goto IL_033a;
																							IL_06e5:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_033a:
																							if (11 >= b)
																							{
																								goto IL_0348;
																							}
																							goto IL_06cf;
																							IL_0348:
																							if (11 > b)
																							{
																								goto IL_0356;
																							}
																							goto IL_04f8;
																							IL_0356:
																							if (10 < b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_0461;
																							IL_0461:
																							if (10 > b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_046f;
																							IL_046f:
																							array[num5 - 2] = 0;
																							goto IL_0483;
																							IL_0483:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)RetLdloca[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_04d7;
																							IL_04d7:
																							num5--;
																							goto IL_04e5;
																							IL_04e5:
																							ptr2 += 8;
																							break;
																							IL_04f8:
																							num5--;
																							break;
																							IL_06cf:
																							if (12 < b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_06da;
																							IL_06da:
																							if (12 > b)
																							{
																								goto end_IL_02de;
																							}
																							goto IL_06e5;
																						}
																						break;
																					}
																					goto IL_0369;
																					IL_056e:
																					if (5 > b)
																					{
																						goto end_IL_02de;
																					}
																					goto IL_057c;
																					IL_057c:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_0369:
																					if (6 <= b)
																					{
																						break;
																					}
																					goto IL_0377;
																					IL_0377:
																					if (3 >= b)
																					{
																						goto IL_0385;
																					}
																					goto IL_050b;
																					IL_0385:
																					if (3 > b)
																					{
																						goto IL_0393;
																					}
																					goto IL_0594;
																					IL_0393:
																					if (1 >= b)
																					{
																						goto IL_039e;
																					}
																					goto IL_03b1;
																					IL_039e:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_02de;
																					IL_03b1:
																					if (2 < b)
																					{
																						goto end_IL_02de;
																					}
																					goto IL_03bf;
																					IL_03bf:
																					if (2 > b)
																					{
																						goto end_IL_02de;
																					}
																					goto IL_03cd;
																					IL_03cd:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_043b;
																					IL_043b:
																					num5 -= 2;
																					break;
																					IL_0594:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05d4;
																					IL_05d4:
																					array[num5 - 2] = 0;
																					goto IL_05e8;
																					IL_05e8:
																					num5--;
																					break;
																					IL_050b:
																					if (4 >= b)
																					{
																						goto IL_0516;
																					}
																					goto IL_0560;
																					IL_0516:
																					if (4 > b)
																					{
																						goto end_IL_02de;
																					}
																					goto IL_0524;
																					IL_0524:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_054d;
																					IL_054d:
																					ptr2 += 8;
																					goto IL_06bf;
																					IL_06bf:
																					num5--;
																					break;
																					IL_0560:
																					if (5 < b)
																					{
																						goto end_IL_02de;
																					}
																					goto IL_056e;
																				}
																				goto end_IL_02ee;
																				continue;
																				end_IL_02de:
																				break;
																				IL_02de:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0721;
																		IL_073d:
																		ptr2 += 8;
																		break;
																		IL_072f:
																		num5++;
																		goto IL_073d;
																		IL_0721:
																		array[num5] = 0;
																		goto IL_072f;
																		continue;
																		end_IL_02ee:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_080c;
														IL_080c:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_074b:
														break;
													}
													continue;
													end_IL_075e:
													break;
												}
												continue;
												end_IL_0769:
												break;
											}
											continue;
											end_IL_0773:
											break;
										}
										continue;
										end_IL_077e:
										break;
									}
									continue;
									end_IL_0793:
									break;
								}
								continue;
								end_IL_07a8:
								break;
							}
							continue;
							end_IL_07b8:
							break;
						}
						continue;
						end_IL_07c8:
						break;
					}
					continue;
					end_IL_07d8:
					break;
				}
				continue;
				end_IL_07e8:
				break;
			}
		}
	}

	private static int smethod_2(int int_0)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_0;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_0;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_3(int int_0, int int_1)
	{
		int num = 121;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getParentFieldLoggingLevels.CallerLineNumberAttributeAddAccessRule);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a4:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0284:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0274:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0264:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0257:
																										if (7 < b)
																										{
																											while (true)
																											{
																												IL_0247:
																												if (8 >= b)
																												{
																													while (8 <= b)
																													{
																														num = 129;
																														while (true)
																														{
																															if (num != 129)
																															{
																																if (num != 1110)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 11:
																																	goto end_IL_0221;
																																case 1:
																																	goto IL_0247;
																																case 102:
																																case 117:
																																	goto IL_0257;
																																case 55:
																																	goto IL_0264;
																																case 3:
																																	goto IL_0274;
																																case 60:
																																	goto IL_0284;
																																case 77:
																																	goto IL_0294;
																																case 39:
																																	goto IL_02a4;
																																case 24:
																																	goto end_IL_02a4;
																																case 56:
																																case 111:
																																	goto end_IL_02b1;
																																case 48:
																																	goto IL_02da;
																																case 7:
																																case 90:
																																	goto IL_02e8;
																																case 107:
																																	goto IL_030a;
																																case 68:
																																	goto IL_0318;
																																case 97:
																																	goto IL_0326;
																																case 23:
																																	goto IL_0339;
																																case 16:
																																	goto IL_0379;
																																case 104:
																																	goto IL_038d;
																																case 61:
																																case 93:
																																	goto IL_03ae;
																																case 26:
																																	goto IL_03c2;
																																case 21:
																																	goto IL_0416;
																																case 114:
																																	goto IL_0424;
																																case 65:
																																case 91:
																																	goto IL_0440;
																																case 88:
																																	goto IL_044b;
																																case 30:
																																	goto IL_0459;
																																case 32:
																																case 112:
																																	goto IL_0467;
																																case 96:
																																	goto IL_0483;
																																case 35:
																																case 106:
																																	goto IL_0491;
																																case 37:
																																	goto IL_04ad;
																																case 40:
																																case 73:
																																	goto IL_04b8;
																																case 79:
																																	goto IL_04f8;
																																case 49:
																																	goto IL_050c;
																																case 92:
																																	goto IL_051f;
																																case 89:
																																	goto IL_052d;
																																case 33:
																																case 69:
																																	goto IL_053b;
																																case 81:
																																	goto IL_0546;
																																case 27:
																																case 94:
																																	goto IL_0559;
																																case 109:
																																	goto IL_0572;
																																case 78:
																																case 103:
																																	goto IL_0589;
																																case 43:
																																	goto IL_05c9;
																																case 122:
																																	goto IL_05dd;
																																case 45:
																																case 72:
																																	goto IL_05f0;
																																case 17:
																																	goto IL_0619;
																																case 82:
																																	goto IL_0627;
																																case 44:
																																case 98:
																																	goto IL_063a;
																																case 53:
																																	goto IL_0645;
																																case 46:
																																case 83:
																																	goto IL_0653;
																																case 41:
																																	goto IL_0693;
																																case 22:
																																	goto IL_06a7;
																																case 105:
																																	goto IL_06ba;
																																case 58:
																																	goto IL_06c5;
																																case 66:
																																case 113:
																																	goto IL_06d0;
																																case 8:
																																	goto IL_06de;
																																case 119:
																																	goto IL_0701;
																																case 5:
																																	goto IL_070b;
																																case 67:
																																	goto IL_0722;
																																case 0:
																																case 6:
																																case 15:
																																case 18:
																																case 20:
																																case 28:
																																case 29:
																																case 38:
																																case 50:
																																case 54:
																																case 57:
																																case 59:
																																case 74:
																																case 75:
																																case 76:
																																case 86:
																																case 99:
																																case 100:
																																case 108:
																																case 115:
																																case 116:
																																case 118:
																																	goto end_IL_0234;
																																case 63:
																																	goto IL_0755;
																																case 25:
																																	goto IL_0763;
																																case 110:
																																	goto IL_0771;
																																case 2:
																																case 4:
																																case 9:
																																case 12:
																																case 36:
																																case 47:
																																case 51:
																																case 52:
																																case 62:
																																case 71:
																																case 80:
																																case 84:
																																case 101:
																																	goto end_IL_02c1;
																																case 10:
																																	goto end_IL_077f;
																																case 19:
																																	goto end_IL_0792;
																																case 34:
																																	goto end_IL_079c;
																																case 70:
																																	goto end_IL_07a7;
																																case 42:
																																	goto end_IL_07bc;
																																case 14:
																																case 87:
																																	goto end_IL_07d1;
																																case 13:
																																	goto end_IL_07e1;
																																case 85:
																																case 95:
																																	goto end_IL_07f1;
																																case 120:
																																	goto end_IL_0801;
																																case 121:
																																	goto end_IL_0811;
																																case 31:
																																case 64:
																																	goto IL_082c;
																																}
																																continue;
																															}
																															goto IL_0339;
																															IL_0379:
																															array[num5 - 2] = 0;
																															goto IL_038d;
																															IL_038d:
																															num5--;
																															goto end_IL_02c1;
																															IL_0339:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_0379;
																															continue;
																															end_IL_0221:
																															break;
																														}
																														continue;
																														end_IL_0234:
																														break;
																													}
																												}
																												else
																												{
																													num = 118;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02da;
																										IL_0326:
																										ptr2 += 8;
																										goto end_IL_02c1;
																										IL_02da:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_02e8;
																										IL_02e8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 107;
																										goto IL_030a;
																										IL_030a:
																										array[num5] = 0;
																										goto IL_0318;
																										IL_0318:
																										num5++;
																										goto IL_0326;
																									}
																									break;
																								}
																								goto IL_03ae;
																								IL_0424:
																								ptr2 += 8;
																								goto end_IL_02c1;
																								IL_03ae:
																								array[num5 - 2] = 0;
																								goto IL_03c2;
																								IL_03c2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)EventSourceAttributeRegistryPermission[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_0416;
																								IL_0416:
																								num5--;
																								goto IL_0424;
																							}
																							break;
																						}
																						num = 91;
																						goto IL_0440;
																						IL_0483:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0491;
																						IL_0491:
																						num5--;
																						goto end_IL_02c1;
																						IL_0440:
																						if (10 < b)
																						{
																							goto IL_044b;
																						}
																						goto IL_0483;
																						IL_044b:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_0459;
																						IL_0459:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_0467;
																						IL_0467:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02c1;
																					}
																					break;
																				}
																				num = 37;
																				goto IL_04ad;
																				IL_06de:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0701;
																				IL_0701:
																				array2[num5] = null;
																				goto IL_070b;
																				IL_04ad:
																				if (6 <= b)
																				{
																					goto IL_04b8;
																				}
																				goto IL_051f;
																				IL_04b8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f8;
																				IL_04f8:
																				array[num5 - 2] = 0;
																				goto IL_050c;
																				IL_050c:
																				num5--;
																				goto end_IL_02c1;
																				IL_051f:
																				if (3 >= b)
																				{
																					goto IL_052d;
																				}
																				goto IL_063a;
																				IL_052d:
																				if (3 > b)
																				{
																					goto IL_053b;
																				}
																				goto IL_05f0;
																				IL_053b:
																				if (1 >= b)
																				{
																					goto IL_0546;
																				}
																				goto IL_0559;
																				IL_0546:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0559:
																				if (2 < b)
																				{
																					num = 100;
																					break;
																				}
																				goto IL_0572;
																				IL_070b:
																				num5++;
																				num = 67;
																				goto IL_0722;
																				IL_0572:
																				if (2 > b)
																				{
																					break;
																				}
																				num = 103;
																				goto IL_0589;
																				IL_0722:
																				ptr2 += 8;
																				goto end_IL_02c1;
																				IL_0589:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05c9;
																				IL_05c9:
																				array[num5 - 2] = 0;
																				goto IL_05dd;
																				IL_05dd:
																				num5--;
																				goto end_IL_02c1;
																				IL_05f0:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0619;
																				IL_0619:
																				ptr2 += 8;
																				goto IL_0627;
																				IL_0627:
																				num5--;
																				goto end_IL_02c1;
																				IL_063a:
																				if (4 >= b)
																				{
																					goto IL_0645;
																				}
																				goto IL_06ba;
																				IL_0645:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0653;
																				IL_0653:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0693;
																				IL_0693:
																				array[num5 - 2] = 0;
																				goto IL_06a7;
																				IL_06a7:
																				num5--;
																				goto end_IL_02c1;
																				IL_06ba:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_06c5;
																				IL_06c5:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_06d0;
																				IL_06d0:
																				array[num5] = 0;
																				goto IL_06de;
																			}
																			break;
																			IL_0294:;
																		}
																	}
																	else
																	{
																		num = 20;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0755;
																	IL_0763:
																	num5++;
																	goto IL_0771;
																	IL_0771:
																	ptr2 += 8;
																	goto end_IL_02c1;
																	IL_0755:
																	array[num5] = 0;
																	goto IL_0763;
																	continue;
																	end_IL_02a4:
																	break;
																}
																continue;
																end_IL_02b1:
																break;
															}
															continue;
															end_IL_02c1:
															break;
														}
														continue;
													}
													goto IL_082c;
													IL_082c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_077f:
													break;
												}
												continue;
												end_IL_0792:
												break;
											}
											continue;
											end_IL_079c:
											break;
										}
										continue;
										end_IL_07a7:
										break;
									}
									continue;
									end_IL_07bc:
									break;
								}
								continue;
								end_IL_07d1:
								break;
							}
							continue;
							end_IL_07e1:
							break;
						}
						continue;
						end_IL_07f1:
						break;
					}
					continue;
					end_IL_0801:
					break;
				}
				continue;
				end_IL_0811:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0)
	{
		int num = 92;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 64;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNextChannelSinkRegistryView.setRootCodeGroupBgeS);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0260:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0243:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0233:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0223:
																							if (10 >= b)
																							{
																								while (10 <= b)
																								{
																									num = 120;
																									while (true)
																									{
																										if (num != 120)
																										{
																											if (num != 1101)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 4:
																												goto IL_0210;
																											case 29:
																												goto IL_0223;
																											case 22:
																											case 77:
																												goto IL_0233;
																											case 28:
																												goto IL_0243;
																											case 112:
																												goto IL_0250;
																											case 84:
																												goto IL_0260;
																											case 2:
																												goto end_IL_0260;
																											case 45:
																											case 85:
																												goto end_IL_0270;
																											case 54:
																												goto IL_028b;
																											case 17:
																												goto IL_0296;
																											case 39:
																											case 55:
																												goto IL_02a4;
																											case 12:
																												goto IL_02af;
																											case 9:
																												goto IL_02c2;
																											case 53:
																											case 61:
																												goto IL_02d2;
																											case 65:
																												goto IL_0317;
																											case 66:
																												goto IL_0327;
																											case 15:
																											case 60:
																												goto IL_0332;
																											case 40:
																												goto IL_034a;
																											case 14:
																											case 58:
																												goto IL_0355;
																											case 51:
																											case 69:
																												goto IL_0368;
																											case 70:
																												goto IL_037b;
																											case 6:
																											case 67:
																												goto IL_0389;
																											case 43:
																												goto IL_03a2;
																											case 33:
																												goto IL_03b9;
																											case 59:
																												goto IL_03c7;
																											case 13:
																											case 73:
																												goto IL_03da;
																											case 76:
																												goto IL_03ed;
																											case 26:
																											case 78:
																												goto IL_03fb;
																											case 31:
																												goto IL_0424;
																											case 8:
																												goto IL_0432;
																											case 81:
																												goto IL_0445;
																											case 23:
																												goto IL_0468;
																											case 93:
																												goto IL_0474;
																											case 97:
																												goto IL_048d;
																											case 90:
																												goto IL_049b;
																											case 98:
																												goto IL_04ae;
																											case 79:
																												goto IL_04bc;
																											case 96:
																												goto IL_04c7;
																											case 18:
																											case 82:
																												goto IL_04d5;
																											case 56:
																											case 95:
																												goto end_IL_01fd;
																											case 36:
																												goto IL_0525;
																											case 1:
																											case 50:
																												goto IL_0533;
																											case 24:
																												goto IL_0556;
																											case 11:
																												goto IL_0564;
																											case 7:
																											case 10:
																												goto IL_0585;
																											case 44:
																												goto IL_05f0;
																											case 99:
																												goto IL_0603;
																											case 105:
																												goto IL_061c;
																											case 106:
																												goto IL_062c;
																											case 111:
																												goto IL_0639;
																											case 108:
																												goto IL_064d;
																											case 21:
																												goto IL_065d;
																											case 0:
																											case 3:
																											case 5:
																											case 16:
																											case 34:
																											case 37:
																											case 46:
																											case 47:
																											case 48:
																											case 52:
																											case 62:
																											case 63:
																											case 75:
																											case 87:
																											case 88:
																											case 94:
																											case 100:
																											case 101:
																											case 104:
																											case 109:
																											case 113:
																												goto end_IL_0210;
																											case 20:
																											case 25:
																											case 38:
																											case 49:
																											case 57:
																											case 68:
																											case 71:
																											case 72:
																											case 74:
																											case 80:
																											case 83:
																											case 102:
																											case 103:
																											case 110:
																												goto end_IL_0280;
																											case 89:
																												goto end_IL_0689;
																											case 41:
																												goto end_IL_069c;
																											case 27:
																												goto end_IL_06a6;
																											case 19:
																												goto end_IL_06b1;
																											case 35:
																											case 64:
																												goto end_IL_06c6;
																											case 42:
																												goto end_IL_06d6;
																											case 32:
																											case 107:
																												goto end_IL_06e6;
																											case 91:
																												goto end_IL_06ff;
																											case 92:
																												goto end_IL_070f;
																											case 30:
																											case 86:
																												goto IL_072a;
																											}
																											continue;
																										}
																										goto IL_065d;
																										IL_065d:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0280;
																										continue;
																										end_IL_01fd:
																										break;
																									}
																									goto IL_051a;
																									continue;
																									end_IL_0210:
																									break;
																									IL_0210:;
																								}
																								break;
																							}
																							goto IL_03da;
																							IL_062c:
																							if (11 <= b)
																							{
																							}
																							break;
																							IL_03da:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_062c;
																						}
																						break;
																					}
																					goto IL_04ae;
																					IL_0585:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 44;
																					goto IL_05f0;
																					IL_04ae:
																					if (9 > b)
																					{
																						goto IL_04bc;
																					}
																					goto IL_0585;
																					IL_04bc:
																					if (7 >= b)
																					{
																						goto IL_04c7;
																					}
																					goto IL_051a;
																					IL_04c7:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_04d5;
																					IL_04d5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0639;
																					IL_0639:
																					array[num6 - 2] = 0;
																					goto IL_064d;
																					IL_064d:
																					num6--;
																					goto end_IL_0280;
																					IL_051a:
																					if (8 < b)
																					{
																						num = 62;
																						break;
																					}
																					goto IL_0525;
																					IL_0525:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0533;
																					IL_0533:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0556;
																					IL_0556:
																					array[num6] = 0;
																					goto IL_0564;
																					IL_0564:
																					num6++;
																					goto IL_0603;
																					IL_0603:
																					ptr2 += 8;
																					num = 83;
																					goto end_IL_0280;
																					IL_05f0:
																					num6 -= 2;
																					goto end_IL_0280;
																				}
																				break;
																			}
																			goto IL_028b;
																			IL_061c:
																			num6--;
																			goto end_IL_0280;
																			IL_028b:
																			if (6 > b)
																			{
																				goto IL_0296;
																			}
																			goto IL_02d2;
																			IL_0296:
																			if (3 < b)
																			{
																				goto IL_02a4;
																			}
																			goto IL_0327;
																			IL_02a4:
																			if (4 >= b)
																			{
																				goto IL_02af;
																			}
																			goto IL_02c2;
																			IL_02af:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0280;
																			IL_02c2:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0317;
																			IL_0317:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0368;
																			IL_0368:
																			array[num6] = 0;
																			goto IL_0445;
																			IL_0445:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0468;
																			IL_0468:
																			array2[num6] = null;
																			goto IL_048d;
																			IL_048d:
																			num6++;
																			goto IL_049b;
																			IL_049b:
																			ptr2 += 8;
																			goto end_IL_0280;
																			IL_0327:
																			if (3 <= b)
																			{
																				goto IL_0332;
																			}
																			goto IL_034a;
																			IL_0332:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0280;
																			IL_034a:
																			if (1 < b)
																			{
																				goto IL_0355;
																			}
																			goto IL_037b;
																			IL_0355:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_03ed;
																			IL_03ed:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_03fb;
																			IL_03fb:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0424;
																			IL_0424:
																			ptr2 += 8;
																			goto IL_0432;
																			IL_0432:
																			num6--;
																			goto end_IL_0280;
																			IL_037b:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0389;
																			IL_0389:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_03a2;
																			IL_03a2:
																			array[num6] = 0;
																			num = 33;
																			goto IL_03b9;
																			IL_03b9:
																			num6++;
																			goto IL_03c7;
																			IL_03c7:
																			ptr2 += 8;
																			goto end_IL_0280;
																			IL_02d2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0474;
																			IL_0474:
																			array[num6 - 2] = 0;
																			goto IL_061c;
																		}
																		break;
																		IL_0250:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0280;
																continue;
																end_IL_0260:
																break;
															}
															continue;
															end_IL_0270:
															break;
														}
														continue;
														end_IL_0280:
														break;
													}
													continue;
												}
												goto IL_072a;
												IL_072a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0689:
												break;
											}
											continue;
											end_IL_069c:
											break;
										}
										continue;
										end_IL_06a6:
										break;
									}
									continue;
									end_IL_06b1:
									break;
								}
								continue;
								end_IL_06c6:
								break;
							}
							continue;
							end_IL_06d6:
							break;
						}
						continue;
						end_IL_06e6:
						break;
					}
					continue;
					end_IL_06ff:
					break;
				}
				continue;
				end_IL_070f:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0, int int_1)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 30;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetRangegetDigestAlgorithm.HandleToInfoGetRange);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 48;
																	while (true)
																	{
																		IL_0289:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				num = 31;
																				while (true)
																				{
																					IL_0269:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0259:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0249:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_0239:
																											if (3 >= b)
																											{
																												while (3 <= b)
																												{
																													while (true)
																													{
																														IL_01f5:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 94;
																														while (true)
																														{
																															IL_01dc:
																															ptr2 += 8;
																															num = 107;
																															while (true)
																															{
																																if (num != 107)
																																{
																																	if (num != 1088)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 94:
																																		goto IL_01dc;
																																	case 25:
																																	case 97:
																																		goto IL_01f5;
																																	case 9:
																																		goto IL_0229;
																																	case 3:
																																		goto IL_0239;
																																	case 10:
																																	case 50:
																																		goto IL_0249;
																																	case 55:
																																		goto IL_0259;
																																	case 31:
																																		goto IL_0269;
																																	case 38:
																																		goto IL_0276;
																																	case 48:
																																		goto IL_0289;
																																	case 37:
																																		goto end_IL_0289;
																																	case 41:
																																	case 72:
																																		goto end_IL_0299;
																																	case 2:
																																		goto IL_02bd;
																																	case 16:
																																		goto IL_02c8;
																																	case 15:
																																		goto IL_02d6;
																																	case 33:
																																		goto IL_02e4;
																																	case 40:
																																		goto IL_02f7;
																																	case 8:
																																		goto IL_0305;
																																	case 49:
																																		goto IL_0318;
																																	case 6:
																																		goto IL_0323;
																																	case 29:
																																		goto IL_0331;
																																	case 34:
																																	case 45:
																																		goto IL_033f;
																																	case 0:
																																	case 67:
																																		goto IL_035b;
																																	case 79:
																																		goto IL_0379;
																																	case 5:
																																	case 69:
																																		goto IL_0387;
																																	case 78:
																																		goto IL_03c7;
																																	case 66:
																																		goto IL_03db;
																																	case 36:
																																	case 86:
																																		goto IL_03f7;
																																	case 84:
																																		goto IL_0437;
																																	case 18:
																																		goto IL_044b;
																																	case 89:
																																		goto IL_0467;
																																	case 68:
																																		goto IL_0475;
																																	case 77:
																																	case 92:
																																		goto IL_0488;
																																	case 87:
																																		goto IL_04c8;
																																	case 43:
																																		goto IL_04e5;
																																	case 98:
																																		goto IL_04f8;
																																	case 99:
																																		goto IL_050b;
																																	case 58:
																																		goto IL_0531;
																																	case 81:
																																		goto IL_053f;
																																	case 44:
																																	case 54:
																																		goto IL_054d;
																																	case 93:
																																		goto IL_058d;
																																	case 82:
																																		goto IL_05a1;
																																	case 63:
																																	case 74:
																																		goto IL_05bd;
																																	case 65:
																																		goto IL_05cb;
																																	case 61:
																																		goto IL_05ee;
																																	case 17:
																																		goto IL_05f8;
																																	case 64:
																																		goto IL_0606;
																																	case 7:
																																	case 11:
																																	case 22:
																																	case 24:
																																	case 28:
																																	case 32:
																																	case 35:
																																	case 39:
																																	case 51:
																																	case 56:
																																	case 57:
																																	case 59:
																																	case 60:
																																	case 70:
																																	case 80:
																																	case 91:
																																	case 100:
																																		goto end_IL_01c9;
																																	case 90:
																																		goto IL_0642;
																																	case 19:
																																		goto IL_0650;
																																	case 46:
																																		goto IL_065e;
																																	case 1:
																																	case 4:
																																	case 14:
																																	case 21:
																																	case 23:
																																	case 27:
																																	case 52:
																																	case 71:
																																	case 85:
																																	case 88:
																																	case 96:
																																		goto end_IL_02b2;
																																	case 73:
																																		goto end_IL_066c;
																																	case 20:
																																		goto end_IL_067f;
																																	case 83:
																																		goto end_IL_0689;
																																	case 95:
																																		goto end_IL_0694;
																																	case 13:
																																		goto end_IL_06a9;
																																	case 30:
																																		goto end_IL_06be;
																																	case 47:
																																		goto end_IL_06ce;
																																	case 12:
																																		goto end_IL_06de;
																																	case 42:
																																	case 62:
																																		goto end_IL_06e9;
																																	case 75:
																																		goto end_IL_06f9;
																																	case 76:
																																		goto end_IL_0709;
																																	case 26:
																																	case 53:
																																		goto IL_0724;
																																	}
																																	continue;
																																}
																																num5--;
																																goto end_IL_02b2;
																																continue;
																																end_IL_01c9:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_0229:;
																												}
																												break;
																											}
																											goto IL_0531;
																											IL_05a1:
																											num5--;
																											num = 4;
																											goto end_IL_02b2;
																											IL_0531:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_053f;
																											IL_053f:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_054d;
																											IL_054d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_058d;
																											IL_058d:
																											array[num5 - 2] = 0;
																											goto IL_05a1;
																										}
																										break;
																									}
																									goto IL_02f7;
																									IL_04e5:
																									num5--;
																									goto end_IL_02b2;
																									IL_02f7:
																									if (2 > b)
																									{
																										goto IL_0305;
																									}
																									goto IL_0488;
																									IL_0305:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_04f8;
																									IL_04f8:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_0488:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04c8;
																									IL_04c8:
																									array[num5 - 2] = 0;
																									num = 43;
																									goto IL_04e5;
																								}
																								break;
																							}
																							goto IL_05bd;
																							IL_0606:
																							ptr2 += 8;
																							goto end_IL_02b2;
																							IL_05bd:
																							array[num5] = 0;
																							goto IL_05cb;
																							IL_05cb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05ee;
																							IL_05ee:
																							array2[num5] = null;
																							goto IL_05f8;
																							IL_05f8:
																							num5++;
																							goto IL_0606;
																						}
																						break;
																					}
																					goto IL_02bd;
																					IL_03db:
																					num5--;
																					num = 14;
																					goto end_IL_02b2;
																					IL_02bd:
																					if (7 >= b)
																					{
																						goto IL_02c8;
																					}
																					goto IL_0318;
																					IL_02c8:
																					if (7 > b)
																					{
																						goto IL_02d6;
																					}
																					goto IL_035b;
																					IL_02d6:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_02e4;
																					IL_02e4:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_03f7;
																					IL_03f7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0437;
																					IL_0437:
																					array[num5 - 2] = 0;
																					goto IL_044b;
																					IL_044b:
																					num5--;
																					num = 71;
																					goto end_IL_02b2;
																					IL_035b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0467;
																					IL_0467:
																					array[num5] = 0;
																					goto IL_0475;
																					IL_0475:
																					num5++;
																					goto IL_050b;
																					IL_050b:
																					ptr2 += 8;
																					goto end_IL_02b2;
																					IL_0318:
																					if (8 < b)
																					{
																						goto IL_0323;
																					}
																					goto IL_0379;
																					IL_0323:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0331;
																					IL_0331:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_033f;
																					IL_033f:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02b2;
																					IL_0379:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0387;
																					IL_0387:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c7;
																					IL_03c7:
																					array[num5 - 2] = 0;
																					goto IL_03db;
																				}
																				break;
																				IL_0276:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 90;
																		goto IL_0642;
																		IL_065e:
																		ptr2 += 8;
																		goto end_IL_02b2;
																		IL_0650:
																		num5++;
																		goto IL_065e;
																		IL_0642:
																		array[num5] = 0;
																		goto IL_0650;
																		continue;
																		end_IL_0289:
																		break;
																	}
																	continue;
																	end_IL_0299:
																	break;
																}
																continue;
																end_IL_02b2:
																break;
															}
															continue;
														}
														goto IL_0724;
														IL_0724:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_066c:
														break;
													}
													continue;
													end_IL_067f:
													break;
												}
												continue;
												end_IL_0689:
												break;
											}
											continue;
											end_IL_0694:
											break;
										}
										continue;
										end_IL_06a9:
										break;
									}
									continue;
									end_IL_06be:
									break;
								}
								continue;
								end_IL_06ce:
								break;
							}
							continue;
							end_IL_06de:
							break;
						}
						continue;
						end_IL_06e9:
						break;
					}
					continue;
					end_IL_06f9:
					break;
				}
				continue;
				end_IL_0709:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 24;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 132;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndOfStreamEnforceJapaneseEraYearRanges.ArgRegKeyStrLenBugStrongNameErrorInfo);
											num = 64;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0327:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0307:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02f7:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02e7:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02d7:
																										if (4 > b)
																										{
																											while (true)
																											{
																												IL_02ca:
																												if (2 < b)
																												{
																													while (3 >= b)
																													{
																														while (3 <= b)
																														{
																															while (true)
																															{
																																IL_0276:
																																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																																num = 149;
																																while (true)
																																{
																																	if (num != 149)
																																	{
																																		if (num != 1130)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 134:
																																		case 136:
																																			goto IL_0276;
																																		case 129:
																																			goto IL_02aa;
																																		case 45:
																																			goto IL_02ba;
																																		case 98:
																																			goto IL_02ca;
																																		case 70:
																																			goto IL_02d7;
																																		case 84:
																																		case 108:
																																			goto IL_02e7;
																																		case 72:
																																			goto IL_02f7;
																																		case 49:
																																			goto IL_0307;
																																		case 137:
																																			goto IL_0317;
																																		case 47:
																																			goto IL_0327;
																																		case 95:
																																			goto end_IL_0327;
																																		case 96:
																																		case 107:
																																			goto end_IL_0337;
																																		case 50:
																																			goto IL_0352;
																																		case 13:
																																			goto IL_0360;
																																		case 46:
																																			goto IL_036e;
																																		case 39:
																																		case 58:
																																			goto IL_037e;
																																		case 51:
																																		case 68:
																																			goto IL_039e;
																																		case 30:
																																		case 82:
																																			goto IL_03b6;
																																		case 33:
																																			goto IL_03cf;
																																		case 115:
																																			goto IL_03df;
																																		case 103:
																																			goto IL_03ed;
																																		case 116:
																																			goto IL_0400;
																																		case 80:
																																			goto IL_040e;
																																		case 123:
																																		case 125:
																																			goto IL_0421;
																																		case 6:
																																			goto end_IL_0263;
																																		case 78:
																																			goto IL_0475;
																																		case 118:
																																		case 138:
																																			goto IL_04a1;
																																		case 0:
																																		case 99:
																																			goto IL_04ac;
																																		case 12:
																																			goto IL_04ba;
																																		case 25:
																																		case 67:
																																			goto IL_04d1;
																																		case 36:
																																			goto IL_04fa;
																																		case 88:
																																			goto IL_0508;
																																		case 117:
																																			goto IL_051b;
																																		case 59:
																																		case 75:
																																			goto IL_0526;
																																		case 44:
																																			goto IL_0531;
																																		case 31:
																																		case 112:
																																			goto IL_053f;
																																		case 120:
																																			goto IL_054d;
																																		case 74:
																																			goto IL_056e;
																																		case 1:
																																			goto IL_057c;
																																		case 3:
																																		case 48:
																																			goto IL_059d;
																																		case 61:
																																			goto IL_05dc;
																																		case 38:
																																			goto IL_05ef;
																																		case 29:
																																		case 102:
																																			goto IL_05fd;
																																		case 57:
																																			goto IL_060b;
																																		case 15:
																																			goto IL_0619;
																																		case 130:
																																			goto IL_0627;
																																		case 40:
																																		case 131:
																																			goto IL_0635;
																																		case 135:
																																			goto IL_0697;
																																		case 4:
																																		case 122:
																																			goto IL_06aa;
																																		case 100:
																																			goto IL_06c6;
																																		case 97:
																																			goto IL_06d4;
																																		case 81:
																																			goto IL_06f0;
																																		case 62:
																																		case 92:
																																			goto IL_06fe;
																																		case 105:
																																			goto IL_070c;
																																		case 27:
																																		case 90:
																																			goto IL_0717;
																																		case 139:
																																			goto IL_0725;
																																		case 9:
																																			goto IL_0748;
																																		case 17:
																																			goto IL_0752;
																																		case 141:
																																			goto IL_0760;
																																		case 60:
																																			goto IL_0773;
																																		case 26:
																																			goto IL_0781;
																																		case 65:
																																			goto IL_0794;
																																		case 52:
																																			goto IL_07a2;
																																		case 2:
																																		case 14:
																																			goto IL_07b0;
																																		case 43:
																																			goto IL_07f4;
																																		case 11:
																																			goto IL_0808;
																																		case 34:
																																		case 111:
																																			goto IL_081b;
																																		case 113:
																																			goto IL_085b;
																																		case 5:
																																			goto IL_0878;
																																		case 19:
																																		case 22:
																																		case 28:
																																		case 35:
																																		case 37:
																																		case 41:
																																		case 55:
																																		case 56:
																																		case 71:
																																		case 76:
																																		case 77:
																																		case 79:
																																		case 85:
																																		case 89:
																																		case 93:
																																		case 94:
																																		case 101:
																																		case 114:
																																		case 124:
																																		case 126:
																																		case 133:
																																		case 140:
																																		case 142:
																																			goto end_IL_02aa;
																																		case 7:
																																		case 8:
																																		case 16:
																																		case 18:
																																		case 20:
																																		case 21:
																																		case 32:
																																		case 53:
																																		case 54:
																																		case 63:
																																		case 83:
																																		case 86:
																																		case 87:
																																		case 91:
																																		case 106:
																																		case 109:
																																		case 110:
																																		case 121:
																																			goto end_IL_0347;
																																		case 64:
																																			goto end_IL_08a4;
																																		case 127:
																																			goto end_IL_08b7;
																																		case 104:
																																			goto end_IL_08c1;
																																		case 119:
																																			goto end_IL_08d5;
																																		case 42:
																																		case 66:
																																			goto end_IL_08e5;
																																		case 69:
																																			goto end_IL_08f5;
																																		case 132:
																																			goto end_IL_0905;
																																		case 10:
																																			goto end_IL_0915;
																																		case 23:
																																			goto end_IL_0925;
																																		case 24:
																																			goto end_IL_0930;
																																		case 73:
																																		case 128:
																																			goto IL_094b;
																																		}
																																		continue;
																																	}
																																	array[num5 - 1] = 5;
																																	goto end_IL_0347;
																																	continue;
																																	end_IL_0263:
																																	break;
																																}
																																break;
																															}
																															goto IL_0461;
																															continue;
																															end_IL_02aa:
																															break;
																															IL_02aa:;
																														}
																														break;
																														IL_02ba:;
																													}
																													break;
																												}
																												goto IL_0352;
																												IL_0475:
																												num5--;
																												goto end_IL_0347;
																												IL_0352:
																												if (2 > b)
																												{
																													goto IL_0360;
																												}
																												goto IL_0421;
																												IL_0360:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_036e;
																												IL_036e:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_03b6;
																												IL_03b6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_03cf;
																												IL_03cf:
																												array[num5] = 0;
																												goto IL_0400;
																												IL_0400:
																												num5++;
																												goto IL_040e;
																												IL_040e:
																												ptr2 += 8;
																												goto end_IL_0347;
																												IL_0421:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0461;
																												IL_0461:
																												array[num5 - 2] = 0;
																												goto IL_0475;
																											}
																											break;
																										}
																										goto IL_037e;
																										IL_03ed:
																										num5--;
																										goto end_IL_0347;
																										IL_037e:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_03df;
																										IL_03df:
																										ptr2 += 8;
																										goto IL_03ed;
																									}
																									break;
																								}
																								goto IL_04a1;
																								IL_05dc:
																								num5 -= 3;
																								goto end_IL_0347;
																								IL_04a1:
																								if (6 < b)
																								{
																									goto IL_04ac;
																								}
																								goto IL_051b;
																								IL_04ac:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_04ba;
																								IL_04ba:
																								if (7 > b)
																								{
																									break;
																								}
																								num = 67;
																								goto IL_04d1;
																								IL_059d:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05dc;
																								IL_04d1:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04fa;
																								IL_04fa:
																								ptr2 += 8;
																								goto IL_0508;
																								IL_0508:
																								num5--;
																								goto end_IL_0347;
																								IL_051b:
																								if (6 > b)
																								{
																									goto IL_0526;
																								}
																								goto IL_059d;
																								IL_0526:
																								if (5 < b)
																								{
																									num = 28;
																									break;
																								}
																								goto IL_0531;
																								IL_0531:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_053f;
																								IL_053f:
																								array[num5] = 5;
																								goto IL_054d;
																								IL_054d:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								num = 74;
																								goto IL_056e;
																								IL_056e:
																								num5++;
																								goto IL_057c;
																								IL_057c:
																								ptr2 += 8;
																								goto end_IL_0347;
																							}
																							break;
																						}
																						goto IL_039e;
																						IL_039e:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0347;
																					}
																					break;
																				}
																				goto IL_05ef;
																				IL_085b:
																				array[num5 - 2] = 0;
																				num = 5;
																				goto IL_0878;
																				IL_05ef:
																				if (12 < b)
																				{
																					goto IL_05fd;
																				}
																				goto IL_06f0;
																				IL_05fd:
																				if (14 >= b)
																				{
																					goto IL_060b;
																				}
																				goto IL_06c6;
																				IL_060b:
																				if (14 > b)
																				{
																					goto IL_0619;
																				}
																				goto IL_06aa;
																				IL_0619:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0627;
																				IL_0627:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0635;
																				IL_0635:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0697;
																				IL_0697:
																				num5 -= 2;
																				goto end_IL_0347;
																				IL_06aa:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0347;
																				IL_06c6:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_06d4;
																				IL_06d4:
																				if (15 <= b)
																				{
																					num = 71;
																				}
																				break;
																				IL_0878:
																				num5--;
																				goto end_IL_0347;
																				IL_06f0:
																				if (12 > b)
																				{
																					goto IL_06fe;
																				}
																				goto IL_081b;
																				IL_06fe:
																				if (10 >= b)
																				{
																					goto IL_070c;
																				}
																				goto IL_0794;
																				IL_070c:
																				if (10 <= b)
																				{
																					goto IL_0717;
																				}
																				goto IL_0773;
																				IL_0717:
																				array[num5] = 0;
																				goto IL_0725;
																				IL_0725:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0748;
																				IL_0748:
																				array2[num5] = null;
																				goto IL_0752;
																				IL_0752:
																				num5++;
																				goto IL_0760;
																				IL_0760:
																				ptr2 += 8;
																				goto end_IL_0347;
																				IL_0773:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0781;
																				IL_0781:
																				if (9 <= b)
																				{
																					goto end_IL_0347;
																				}
																				break;
																				IL_0794:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_07a2;
																				IL_07a2:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_07b0;
																				IL_07b0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_07f4;
																				IL_07f4:
																				array[num5 - 2] = 0;
																				goto IL_0808;
																				IL_0808:
																				num5--;
																				goto end_IL_0347;
																				IL_081b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_085b;
																			}
																			break;
																			IL_0317:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 106;
																	goto end_IL_0347;
																	continue;
																	end_IL_0327:
																	break;
																}
																continue;
																end_IL_0337:
																break;
															}
															continue;
															end_IL_0347:
															break;
														}
														continue;
													}
													goto IL_094b;
													IL_094b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a4:
													break;
												}
												continue;
												end_IL_08b7:
												break;
											}
											continue;
											end_IL_08c1:
											break;
										}
										continue;
										end_IL_08d5:
										break;
									}
									continue;
									end_IL_08e5:
									break;
								}
								continue;
								end_IL_08f5:
								break;
							}
							continue;
							end_IL_0905:
							break;
						}
						continue;
						end_IL_0915:
						break;
					}
					continue;
					end_IL_0925:
					break;
				}
				continue;
				end_IL_0930:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0, int int_1)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 82;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									num = 13;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConsoleColorCodeGroup.CalendarHijrigetCancellationToken);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 69;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_02d3:
																byte b = *ptr2;
																num = 93;
																while (true)
																{
																	IL_02c3:
																	ptr2++;
																	while (true)
																	{
																		IL_02b3:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0293:
																					if (6 >= b)
																					{
																						while (6 > b)
																						{
																							while (true)
																							{
																								IL_0276:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0266:
																										if (4 >= b)
																										{
																											while (4 <= b)
																											{
																												while (true)
																												{
																													IL_0222:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 128;
																													while (true)
																													{
																														if (num != 128)
																														{
																															if (num != 1109)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 38:
																															case 59:
																																goto IL_0222;
																															case 88:
																																goto IL_0256;
																															case 70:
																																goto IL_0266;
																															case 55:
																															case 77:
																																goto IL_0276;
																															case 114:
																																goto IL_0283;
																															case 39:
																																goto IL_0293;
																															case 121:
																																goto IL_02a3;
																															case 29:
																																goto IL_02b3;
																															case 93:
																																goto IL_02c3;
																															case 30:
																															case 98:
																																goto IL_02d3;
																															case 3:
																																goto IL_02e7;
																															case 27:
																																goto IL_02f5;
																															case 10:
																																goto IL_0300;
																															case 46:
																																goto IL_0313;
																															case 72:
																																goto IL_0321;
																															case 18:
																															case 95:
																																goto IL_0331;
																															case 107:
																																goto IL_033f;
																															case 71:
																															case 100:
																																goto IL_034d;
																															case 12:
																															case 109:
																																goto IL_0365;
																															case 54:
																																goto IL_03d3;
																															case 89:
																															case 118:
																																goto IL_03e6;
																															case 49:
																																goto end_IL_020f;
																															case 9:
																																goto IL_043a;
																															case 57:
																																goto IL_045b;
																															case 21:
																																goto IL_046e;
																															case 64:
																																goto IL_047c;
																															case 101:
																															case 120:
																																goto IL_048a;
																															case 31:
																																goto IL_0495;
																															case 81:
																															case 113:
																																goto IL_04a3;
																															case 106:
																																goto IL_04b1;
																															case 36:
																																goto IL_04d4;
																															case 85:
																																goto IL_04de;
																															case 32:
																																goto IL_04ec;
																															case 87:
																																goto IL_04ff;
																															case 28:
																																goto IL_050d;
																															case 14:
																															case 24:
																																goto IL_051b;
																															case 102:
																																goto IL_0534;
																															case 7:
																																goto IL_0542;
																															case 73:
																																goto IL_0550;
																															case 63:
																															case 94:
																																goto IL_0563;
																															case 91:
																																goto IL_05a3;
																															case 53:
																																goto IL_05b7;
																															case 34:
																																goto IL_05ca;
																															case 23:
																															case 25:
																																goto IL_05d5;
																															case 56:
																																goto IL_05e3;
																															case 19:
																															case 74:
																																goto IL_05f1;
																															case 17:
																																goto IL_060d;
																															case 47:
																															case 92:
																																goto IL_061b;
																															case 42:
																																goto IL_0629;
																															case 35:
																															case 78:
																																goto IL_0634;
																															case 50:
																																goto IL_0648;
																															case 90:
																																goto IL_0687;
																															case 11:
																															case 79:
																																goto IL_06a0;
																															case 2:
																															case 6:
																															case 22:
																															case 37:
																															case 43:
																															case 48:
																															case 58:
																															case 60:
																															case 65:
																															case 66:
																															case 68:
																															case 75:
																															case 76:
																															case 84:
																															case 103:
																															case 104:
																															case 105:
																															case 108:
																															case 115:
																															case 117:
																															case 119:
																																goto end_IL_0256;
																															case 15:
																																goto IL_06d3;
																															case 112:
																																goto IL_06e1;
																															case 99:
																																goto IL_06ef;
																															case 4:
																															case 8:
																															case 16:
																															case 33:
																															case 40:
																															case 41:
																															case 52:
																															case 61:
																															case 69:
																															case 80:
																															case 86:
																															case 96:
																															case 110:
																															case 116:
																																goto end_IL_0283;
																															case 44:
																																goto end_IL_06fd;
																															case 51:
																																goto end_IL_0710;
																															case 20:
																																goto end_IL_071b;
																															case 13:
																																goto end_IL_0725;
																															case 97:
																																goto end_IL_0730;
																															case 26:
																																goto end_IL_0745;
																															case 62:
																															case 82:
																																goto end_IL_0763;
																															case 67:
																																goto end_IL_0773;
																															case 45:
																															case 111:
																																goto end_IL_0783;
																															case 0:
																																goto end_IL_079c;
																															case 1:
																																goto end_IL_07ac;
																															case 5:
																															case 83:
																																goto IL_07c7;
																															}
																															continue;
																														}
																														ptr2 += 8;
																														goto IL_045b;
																														IL_045b:
																														num5--;
																														goto end_IL_0283;
																														continue;
																														end_IL_020f:
																														break;
																													}
																													break;
																												}
																												goto IL_0426;
																												continue;
																												end_IL_0256:
																												break;
																												IL_0256:;
																											}
																											break;
																										}
																										goto IL_0331;
																										IL_034d:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0283;
																										IL_0331:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_033f;
																										IL_033f:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_034d;
																									}
																									break;
																								}
																								goto IL_02e7;
																								IL_043a:
																								num5--;
																								goto end_IL_0283;
																								IL_02e7:
																								if (3 > b)
																								{
																									goto IL_02f5;
																								}
																								goto IL_03e6;
																								IL_02f5:
																								if (1 >= b)
																								{
																									goto IL_0300;
																								}
																								goto IL_0313;
																								IL_0300:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0313:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0321;
																								IL_0321:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0365;
																								IL_0365:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_03d3;
																								IL_03d3:
																								num5 -= 2;
																								goto end_IL_0283;
																								IL_03e6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0426;
																								IL_0426:
																								array[num5 - 2] = 0;
																								goto IL_043a;
																							}
																							goto end_IL_02a3;
																							continue;
																							end_IL_0283:
																							break;
																							IL_0283:;
																						}
																						break;
																					}
																					goto IL_046e;
																					IL_06a0:
																					num5--;
																					break;
																					IL_046e:
																					if (9 >= b)
																					{
																						goto IL_047c;
																					}
																					goto IL_05ca;
																					IL_047c:
																					if (9 > b)
																					{
																						goto IL_048a;
																					}
																					goto IL_0563;
																					IL_048a:
																					if (7 >= b)
																					{
																						goto IL_0495;
																					}
																					goto IL_04ff;
																					IL_0495:
																					if (7 > b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_04a3;
																					IL_04a3:
																					array[num5] = 0;
																					goto IL_04b1;
																					IL_04b1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04d4;
																					IL_04d4:
																					array2[num5] = null;
																					goto IL_04de;
																					IL_04de:
																					num5++;
																					goto IL_04ec;
																					IL_04ec:
																					ptr2 += 8;
																					break;
																					IL_04ff:
																					if (8 < b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_050d;
																					IL_050d:
																					if (8 > b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_051b;
																					IL_051b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0534;
																					IL_0534:
																					array[num5] = 0;
																					goto IL_0542;
																					IL_0542:
																					num5++;
																					goto IL_0550;
																					IL_0550:
																					ptr2 += 8;
																					break;
																					IL_0563:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05a3;
																					IL_05a3:
																					array[num5 - 2] = 0;
																					goto IL_05b7;
																					IL_05b7:
																					num5--;
																					break;
																					IL_05ca:
																					if (11 < b)
																					{
																						goto IL_05d5;
																					}
																					goto IL_060d;
																					IL_05d5:
																					if (12 < b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_05e3;
																					IL_05e3:
																					if (12 > b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_05f1;
																					IL_05f1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_060d:
																					if (11 > b)
																					{
																						goto IL_061b;
																					}
																					goto IL_06a0;
																					IL_061b:
																					if (10 < b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_0629;
																					IL_0629:
																					if (10 > b)
																					{
																						goto end_IL_02a3;
																					}
																					goto IL_0634;
																					IL_0634:
																					array[num5 - 1] = 0;
																					goto IL_0648;
																					IL_0648:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)DictionaryEnumeratorNumberBuffer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0687;
																					IL_0687:
																					ptr2 += 8;
																					num = 116;
																					break;
																				}
																				goto end_IL_02b3;
																				continue;
																				end_IL_02a3:
																				break;
																				IL_02a3:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06d3;
																		IL_06ef:
																		ptr2 += 8;
																		break;
																		IL_06e1:
																		num5++;
																		goto IL_06ef;
																		IL_06d3:
																		array[num5] = 0;
																		goto IL_06e1;
																		continue;
																		end_IL_02b3:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_07c7;
														IL_07c7:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_06fd:
														break;
													}
													continue;
													end_IL_0710:
													break;
												}
												continue;
												end_IL_071b:
												break;
											}
											continue;
											end_IL_0725:
											break;
										}
										continue;
										end_IL_0730:
										break;
									}
									continue;
									end_IL_0745:
									break;
								}
								continue;
								end_IL_0763:
								break;
							}
							continue;
							end_IL_0773:
							break;
						}
						continue;
						end_IL_0783:
						break;
					}
					continue;
					end_IL_079c:
					break;
				}
				continue;
				end_IL_07ac:
				break;
			}
		}
	}

	static Class17()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 4;
					while (true)
					{
						IL_0051:
						num = 14;
						while (true)
						{
							if (num != 14)
							{
								if (num != 995)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 1:
								case 4:
								case 6:
									goto IL_0051;
								case 5:
								case 7:
									goto end_IL_0044;
								case 2:
									goto end_IL_0066;
								case 3:
									goto end_IL_0075;
								}
								continue;
							}
							return;
							continue;
							end_IL_0044:
							break;
						}
						break;
					}
					continue;
					end_IL_0066:
					break;
				}
				continue;
				end_IL_0075:
				break;
			}
		}
	}
}
