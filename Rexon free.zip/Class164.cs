using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Disconnect", "Room", "Leaves the current lobby.", false, 0, ModType.const_1, false)]
internal class Class164 : MonoBehaviour
{
	private static float float_0;

	private static double double_0;

	private static int int_0;

	private static float float_1;

	private static IntPtr[] ContractHelperUserApplicationTrusts;

	private static IntPtr[] TaskWrapperAsyncResultsearchOption;

	private static IntPtr[] PtrToStructureSerializable;

	private static IntPtr[] getTypeHandleGetUserString;

	private static IntPtr[] ImportParametersPush;

	private unsafe void OnEnable()
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MoreDatagetIsNeutralCulture.DenyOnlyPrimarySidCharSetAnsi);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_0320:
														if (b >= 1)
														{
															while (b <= 17)
															{
																while (true)
																{
																	IL_0300:
																	if (9 >= b)
																	{
																		goto IL_0612;
																	}
																	while (true)
																	{
																		IL_02f0:
																		if (13 >= b)
																		{
																			while (true)
																			{
																				IL_02e0:
																				if (13 > b)
																				{
																					num = 172;
																					while (true)
																					{
																						if (num != 172)
																						{
																							if (num != 1153)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 36:
																								goto IL_02e0;
																							case 111:
																							case 113:
																								goto IL_02f0;
																							case 72:
																								goto IL_0300;
																							case 48:
																								goto end_IL_0300;
																							case 49:
																								goto IL_0320;
																							case 82:
																								goto end_IL_0320;
																							case 87:
																							case 91:
																								goto end_IL_0330;
																							case 106:
																							case 140:
																								goto IL_034b;
																							case 139:
																								goto IL_039d;
																							case 131:
																								goto IL_03b0;
																							case 15:
																							case 47:
																								goto IL_03bb;
																							case 29:
																								goto IL_03d2;
																							case 33:
																							case 124:
																								goto IL_03e0;
																							case 39:
																								goto IL_03ee;
																							case 99:
																								goto IL_0412;
																							case 52:
																								goto IL_0420;
																							case 134:
																								goto IL_0433;
																							case 66:
																								goto IL_0441;
																							case 64:
																								goto IL_044f;
																							case 75:
																							case 86:
																								goto IL_045d;
																							case 38:
																								goto IL_04bf;
																							case 130:
																								goto IL_04d2;
																							case 16:
																								goto IL_04e0;
																							case 104:
																							case 152:
																								goto IL_04eb;
																							case 164:
																								goto IL_0508;
																							case 96:
																								goto IL_0540;
																							case 163:
																								goto IL_0553;
																							case 26:
																								goto IL_0561;
																							case 20:
																							case 93:
																								goto IL_056f;
																							case 5:
																								goto IL_058d;
																							case 21:
																								goto IL_059b;
																							case 23:
																								goto IL_05a9;
																							case 85:
																								goto IL_05bc;
																							case 151:
																								goto IL_05c7;
																							case 11:
																							case 119:
																								goto IL_05d5;
																							case 149:
																								goto IL_05f1;
																							case 41:
																								goto IL_05ff;
																							case 3:
																								goto IL_0612;
																							case 25:
																							case 63:
																								goto IL_0620;
																							case 42:
																							case 146:
																								goto IL_062e;
																							case 51:
																							case 94:
																								goto IL_063c;
																							case 4:
																							case 31:
																								goto IL_0647;
																							case 129:
																								goto IL_0655;
																							case 24:
																							case 157:
																								goto IL_0663;
																							case 154:
																								goto IL_0676;
																							case 57:
																							case 135:
																								goto IL_0684;
																							case 161:
																								goto IL_06cd;
																							case 132:
																								goto IL_06e1;
																							case 56:
																								goto IL_06f4;
																							case 46:
																							case 126:
																								goto IL_0702;
																							case 155:
																								goto IL_0710;
																							case 67:
																							case 137:
																								goto IL_071e;
																							case 61:
																								goto IL_075e;
																							case 8:
																								goto IL_0772;
																							case 97:
																							case 122:
																								goto IL_0785;
																							case 121:
																								goto IL_07c5;
																							case 160:
																								goto IL_07d9;
																							case 162:
																								goto IL_07ec;
																							case 92:
																								goto IL_07fa;
																							case 79:
																								goto IL_0808;
																							case 102:
																							case 144:
																								goto IL_0813;
																							case 9:
																								goto IL_0853;
																							case 34:
																								goto IL_0867;
																							case 44:
																								goto IL_087a;
																							case 109:
																								goto IL_0888;
																							case 10:
																							case 30:
																								goto IL_0896;
																							case 18:
																								goto IL_08af;
																							case 68:
																								goto IL_08bd;
																							case 19:
																								goto IL_08cb;
																							case 40:
																								goto IL_08de;
																							case 58:
																								goto IL_08ec;
																							case 55:
																							case 78:
																								goto IL_08fa;
																							case 142:
																								goto IL_0923;
																							case 0:
																								goto IL_0931;
																							case 120:
																							case 159:
																								goto IL_0944;
																							case 105:
																								goto end_IL_02cd;
																							case 62:
																								goto IL_0975;
																							case 141:
																								goto IL_097f;
																							case 54:
																								goto IL_098d;
																							case 70:
																							case 158:
																								goto IL_099d;
																							case 148:
																								goto IL_09dd;
																							case 112:
																								goto IL_09f1;
																							case 6:
																							case 13:
																							case 17:
																							case 35:
																							case 37:
																							case 50:
																							case 53:
																							case 60:
																							case 73:
																							case 76:
																							case 77:
																							case 83:
																							case 84:
																							case 90:
																							case 95:
																							case 101:
																							case 107:
																							case 110:
																							case 114:
																							case 115:
																							case 127:
																							case 128:
																							case 133:
																							case 138:
																							case 143:
																							case 147:
																							case 150:
																							case 153:
																							case 165:
																								goto end_IL_0310;
																							case 2:
																							case 12:
																							case 27:
																							case 28:
																							case 32:
																							case 65:
																							case 69:
																							case 71:
																							case 80:
																							case 81:
																							case 98:
																							case 100:
																							case 103:
																							case 116:
																							case 117:
																							case 118:
																							case 123:
																							case 125:
																							case 145:
																							case 156:
																								goto end_IL_0340;
																							case 14:
																								goto end_IL_0a14;
																							case 7:
																								goto end_IL_0a24;
																							case 45:
																								goto end_IL_0a2e;
																							case 22:
																							case 74:
																								goto end_IL_0a39;
																							case 59:
																								goto end_IL_0a49;
																							case 108:
																							case 136:
																								goto end_IL_0a59;
																							case 88:
																								goto end_IL_0a69;
																							case 89:
																								goto end_IL_0a79;
																							case 1:
																							case 43:
																								return;
																							}
																							continue;
																						}
																						goto IL_03b0;
																						IL_044f:
																						if (10 > b)
																						{
																							goto end_IL_0310;
																						}
																						goto IL_045d;
																						IL_045d:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_04bf;
																						IL_03b0:
																						if (11 < b)
																						{
																							goto IL_03bb;
																						}
																						goto IL_0433;
																						IL_03bb:
																						if (12 < b)
																						{
																							goto end_IL_0310;
																						}
																						num = 29;
																						goto IL_03d2;
																						IL_04bf:
																						num5 -= 2;
																						goto end_IL_0340;
																						IL_03d2:
																						if (12 > b)
																						{
																							goto end_IL_0310;
																						}
																						goto IL_03e0;
																						IL_03e0:
																						array[num5] = 0;
																						goto IL_03ee;
																						IL_03ee:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)ContractHelperUserApplicationTrusts[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_0412;
																						IL_0412:
																						num5++;
																						goto IL_0420;
																						IL_0420:
																						ptr2 += 8;
																						goto end_IL_0340;
																						IL_0433:
																						if (11 <= b)
																						{
																							goto end_IL_0340;
																						}
																						goto IL_0441;
																						IL_0441:
																						if (10 < b)
																						{
																							goto end_IL_0310;
																						}
																						goto IL_044f;
																						continue;
																						end_IL_02cd:
																						break;
																					}
																					break;
																				}
																				goto IL_034b;
																				IL_034b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_039d;
																				IL_039d:
																				num5--;
																				goto end_IL_0340;
																			}
																			break;
																		}
																		goto IL_04d2;
																		IL_05ff:
																		if (17 > b)
																		{
																		}
																		goto end_IL_0310;
																		IL_04d2:
																		if (15 >= b)
																		{
																			goto IL_04e0;
																		}
																		goto IL_05bc;
																		IL_04e0:
																		if (15 <= b)
																		{
																			goto IL_04eb;
																		}
																		goto IL_0553;
																		IL_04eb:
																		array[num5 - 1] = 5;
																		num = 164;
																		goto IL_0508;
																		IL_0508:
																		array2[num5 - 1] = ((delegate*<NetworkSystem, Task>)ContractHelperUserApplicationTrusts[*(int*)(ptr2 + num3)])((NetworkSystem)array2[num5 - 1]);
																		goto IL_0540;
																		IL_0540:
																		ptr2 += 8;
																		goto end_IL_0340;
																		IL_0553:
																		if (14 < b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_0561;
																		IL_0561:
																		if (14 > b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_056f;
																		IL_056f:
																		array2[num5] = ((delegate*<NetworkSystem>)ContractHelperUserApplicationTrusts[*(int*)(ptr2 + num3)])();
																		goto IL_058d;
																		IL_058d:
																		array[num5] = 5;
																		goto IL_059b;
																		IL_059b:
																		num5++;
																		goto IL_05a9;
																		IL_05a9:
																		ptr2 += 8;
																		goto end_IL_0340;
																		IL_05bc:
																		if (16 >= b)
																		{
																			goto IL_05c7;
																		}
																		goto IL_05f1;
																		IL_05c7:
																		if (16 > b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_05d5;
																		IL_05d5:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_0340;
																		IL_05f1:
																		if (17 < b)
																		{
																			goto end_IL_0310;
																		}
																		goto IL_05ff;
																	}
																	goto IL_0952;
																	IL_09f1:
																	num5--;
																	goto end_IL_0340;
																	IL_0612:
																	if (9 > b)
																	{
																		goto IL_0620;
																	}
																	goto IL_099d;
																	IL_0620:
																	if (4 < b)
																	{
																		goto IL_062e;
																	}
																	goto IL_07ec;
																	IL_062e:
																	if (6 < b)
																	{
																		goto IL_063c;
																	}
																	goto IL_06f4;
																	IL_063c:
																	if (7 < b)
																	{
																		goto IL_0647;
																	}
																	goto IL_0676;
																	IL_0647:
																	if (8 < b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0655;
																	IL_0655:
																	if (8 > b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0663;
																	IL_0663:
																	num5--;
																	goto end_IL_0340;
																	IL_0676:
																	if (7 > b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0684;
																	IL_0684:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 161;
																	goto IL_06cd;
																	IL_06cd:
																	array[num5 - 2] = 0;
																	goto IL_06e1;
																	IL_06e1:
																	num5--;
																	goto end_IL_0340;
																	IL_06f4:
																	if (6 > b)
																	{
																		goto IL_0702;
																	}
																	goto IL_0785;
																	IL_0702:
																	if (5 < b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0710;
																	IL_0710:
																	if (5 > b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_071e;
																	IL_071e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_075e;
																	IL_075e:
																	array[num5 - 2] = 0;
																	goto IL_0772;
																	IL_0772:
																	num5--;
																	goto end_IL_0340;
																	IL_0785:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_07c5;
																	IL_07c5:
																	array[num5 - 2] = 0;
																	goto IL_07d9;
																	IL_07d9:
																	num5--;
																	goto end_IL_0340;
																	IL_07ec:
																	if (4 > b)
																	{
																		goto IL_07fa;
																	}
																	goto IL_0944;
																	IL_07fa:
																	if (2 >= b)
																	{
																		goto IL_0808;
																	}
																	goto IL_08de;
																	IL_0808:
																	if (2 <= b)
																	{
																		goto IL_0813;
																	}
																	goto IL_087a;
																	IL_0813:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0853;
																	IL_0853:
																	array[num5 - 2] = 0;
																	goto IL_0867;
																	IL_0867:
																	num5--;
																	goto end_IL_0340;
																	IL_087a:
																	if (1 < b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0888;
																	IL_0888:
																	if (1 > b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_0896;
																	IL_0896:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_08af;
																	IL_08af:
																	array[num5] = 0;
																	goto IL_08bd;
																	IL_08bd:
																	num5++;
																	goto IL_08cb;
																	IL_08cb:
																	ptr2 += 8;
																	goto end_IL_0340;
																	IL_08de:
																	if (3 < b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_08ec;
																	IL_08ec:
																	if (3 > b)
																	{
																		goto end_IL_0310;
																	}
																	goto IL_08fa;
																	IL_08fa:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0923;
																	IL_0923:
																	ptr2 += 8;
																	goto IL_0931;
																	IL_0931:
																	num5--;
																	goto end_IL_0340;
																	IL_0944:
																	array[num5] = 0;
																	goto IL_0952;
																	IL_0952:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0975;
																	IL_0975:
																	array2[num5] = null;
																	goto IL_097f;
																	IL_097f:
																	num5++;
																	goto IL_098d;
																	IL_098d:
																	ptr2 += 8;
																	goto end_IL_0340;
																	IL_099d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_09dd;
																	IL_09dd:
																	array[num5 - 2] = 0;
																	goto IL_09f1;
																	continue;
																	end_IL_0300:
																	break;
																}
																continue;
																end_IL_0310:
																break;
															}
														}
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto end_IL_0340;
														continue;
														end_IL_0320:
														break;
													}
													continue;
													end_IL_0330:
													break;
												}
												continue;
												end_IL_0340:
												break;
											}
											continue;
											end_IL_0a14:
											break;
										}
										continue;
										end_IL_0a24:
										break;
									}
									continue;
									end_IL_0a2e:
									break;
								}
								continue;
								end_IL_0a39:
								break;
							}
							continue;
							end_IL_0a49:
							break;
						}
						continue;
						end_IL_0a59:
						break;
					}
					continue;
					end_IL_0a69:
					break;
				}
				continue;
				end_IL_0a79:
				break;
			}
		}
	}

	public Class164()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 56;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMaximumSizePolicyException.setRngGetBaseException);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 43;
															while (true)
															{
																IL_036d:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		num = 104;
																		while (true)
																		{
																			IL_034d:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_033d:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_032d:
																							if (13 > b)
																							{
																								while (true)
																								{
																									IL_031d:
																									if (11 < b)
																									{
																										while (12 >= b)
																										{
																											while (true)
																											{
																												IL_02fa:
																												if (12 > b)
																												{
																													num = 175;
																													while (num != 175)
																													{
																														if (num != 1156)
																														{
																															goto IL_07e0;
																														}
																														switch (num)
																														{
																														case 11:
																															goto IL_02fa;
																														case 54:
																															goto IL_030d;
																														case 13:
																														case 25:
																															goto IL_031d;
																														case 1:
																															goto IL_032d;
																														case 6:
																														case 137:
																															goto IL_033d;
																														case 104:
																															goto IL_034d;
																														case 26:
																															goto IL_035a;
																														case 43:
																															goto IL_036d;
																														case 30:
																															goto end_IL_036d;
																														case 27:
																														case 85:
																															goto end_IL_037d;
																														case 19:
																															goto IL_03a1;
																														case 29:
																															goto IL_03b1;
																														case 32:
																															goto IL_03c4;
																														case 16:
																														case 63:
																															goto IL_03d7;
																														case 81:
																															goto IL_0417;
																														case 84:
																															goto IL_042b;
																														case 61:
																														case 90:
																															goto IL_043e;
																														case 24:
																															goto IL_044c;
																														case 22:
																															goto IL_0457;
																														case 52:
																														case 96:
																															goto IL_0467;
																														case 101:
																															goto IL_047a;
																														case 51:
																														case 103:
																															goto IL_048d;
																														case 92:
																														case 107:
																															goto IL_04a0;
																														case 18:
																														case 110:
																															goto IL_04e9;
																														case 41:
																															goto IL_04f7;
																														case 78:
																														case 117:
																															goto IL_050a;
																														case 98:
																															goto IL_051e;
																														case 129:
																															goto IL_0562;
																														case 140:
																															goto IL_0570;
																														case 123:
																														case 125:
																															goto IL_057b;
																														case 115:
																															goto IL_0589;
																														case 53:
																														case 97:
																															goto IL_0597;
																														case 3:
																															goto IL_05c0;
																														case 95:
																															goto IL_05d9;
																														case 62:
																														case 99:
																															goto IL_05e4;
																														case 133:
																															goto IL_0629;
																														case 46:
																														case 144:
																															goto IL_063c;
																														case 105:
																															goto IL_0647;
																														case 67:
																															goto IL_0652;
																														case 49:
																															goto IL_0665;
																														case 88:
																															goto IL_0673;
																														case 21:
																														case 109:
																															goto IL_0681;
																														case 31:
																															goto IL_06a2;
																														case 70:
																														case 79:
																															goto IL_06ad;
																														case 47:
																														case 91:
																															goto IL_06c0;
																														case 17:
																															goto IL_06ff;
																														case 36:
																														case 145:
																															goto IL_0712;
																														case 147:
																															goto IL_072e;
																														case 148:
																															goto IL_0747;
																														case 151:
																															goto IL_075a;
																														case 34:
																														case 130:
																															goto IL_0768;
																														case 73:
																															goto IL_0781;
																														case 136:
																															goto IL_078f;
																														case 87:
																															goto IL_07a6;
																														case 152:
																															goto IL_07b9;
																														case 94:
																															goto IL_07cd;
																														case 135:
																														case 155:
																															goto IL_07e0;
																														case 35:
																															goto IL_07fe;
																														case 33:
																															goto IL_080c;
																														case 48:
																														case 159:
																															goto IL_081f;
																														case 77:
																															goto IL_082d;
																														case 12:
																															goto IL_0850;
																														case 134:
																															goto IL_085a;
																														case 74:
																															goto IL_0868;
																														case 160:
																															goto IL_087b;
																														case 153:
																															goto IL_0889;
																														case 161:
																															goto IL_089c;
																														case 113:
																														case 156:
																															goto IL_08aa;
																														case 93:
																															goto IL_08b8;
																														case 139:
																															goto IL_08d0;
																														case 44:
																															goto IL_08de;
																														case 163:
																															goto IL_08f1;
																														case 146:
																														case 165:
																															goto IL_0904;
																														case 132:
																															goto IL_092d;
																														case 75:
																															goto IL_093b;
																														case 167:
																															goto IL_094e;
																														case 0:
																														case 28:
																															goto IL_0961;
																														case 72:
																															goto IL_09c3;
																														case 2:
																														case 5:
																														case 7:
																														case 10:
																														case 14:
																														case 15:
																														case 20:
																														case 38:
																														case 45:
																														case 55:
																														case 60:
																														case 69:
																														case 71:
																														case 76:
																														case 80:
																														case 89:
																														case 100:
																														case 102:
																														case 112:
																														case 114:
																														case 116:
																														case 120:
																														case 121:
																														case 131:
																														case 138:
																														case 141:
																														case 142:
																														case 143:
																														case 149:
																														case 150:
																														case 154:
																														case 157:
																														case 158:
																														case 164:
																															goto end_IL_02e7;
																														case 4:
																														case 8:
																														case 9:
																														case 42:
																														case 50:
																														case 57:
																														case 59:
																														case 64:
																														case 68:
																														case 82:
																														case 86:
																														case 106:
																														case 108:
																														case 111:
																														case 118:
																														case 126:
																														case 127:
																														case 162:
																														case 166:
																														case 168:
																															goto end_IL_0396;
																														case 58:
																															goto end_IL_09e6;
																														case 65:
																															goto end_IL_09f9;
																														case 83:
																															goto end_IL_0a03;
																														case 23:
																															goto end_IL_0a0e;
																														case 56:
																														case 122:
																															goto end_IL_0a1e;
																														case 66:
																															goto end_IL_0a2e;
																														case 37:
																														case 124:
																															goto end_IL_0a3e;
																														case 39:
																															goto end_IL_0a57;
																														case 40:
																															goto end_IL_0a67;
																														case 119:
																														case 128:
																															goto IL_0a82;
																														}
																														continue;
																														end_IL_02e7:
																														break;
																													}
																													break;
																												}
																												goto IL_03d7;
																												IL_0417:
																												array[num5 - 2] = 0;
																												goto IL_042b;
																												IL_042b:
																												num5--;
																												goto end_IL_0396;
																												IL_03d7:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0417;
																											}
																											break;
																											IL_030d:;
																										}
																										break;
																									}
																									goto IL_03b1;
																									IL_07cd:
																									num5--;
																									goto end_IL_0396;
																									IL_03b1:
																									if (11 > b)
																									{
																										goto IL_0467;
																									}
																									goto IL_04a0;
																									IL_0467:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_0747;
																									IL_0747:
																									if (10 > b)
																									{
																										break;
																									}
																									goto IL_081f;
																									IL_081f:
																									array[num5] = 0;
																									goto IL_082d;
																									IL_082d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0850;
																									IL_0850:
																									array2[num5] = null;
																									goto IL_085a;
																									IL_085a:
																									num5++;
																									goto IL_0868;
																									IL_0868:
																									ptr2 += 8;
																									goto end_IL_0396;
																									IL_04a0:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_07b9;
																									IL_07b9:
																									array[num5 - 2] = 0;
																									goto IL_07cd;
																								}
																								break;
																							}
																							goto IL_0961;
																							IL_09c3:
																							num5 -= 2;
																							goto end_IL_0396;
																							IL_0961:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_09c3;
																						}
																						break;
																					}
																					goto IL_043e;
																					IL_0889:
																					if (17 <= b)
																					{
																					}
																					break;
																					IL_043e:
																					if (15 >= b)
																					{
																						goto IL_044c;
																					}
																					goto IL_04e9;
																					IL_044c:
																					if (15 > b)
																					{
																						goto IL_0457;
																					}
																					goto IL_048d;
																					IL_0457:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_047a;
																					IL_047a:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_050a;
																					IL_050a:
																					array[num5 - 1] = 0;
																					goto IL_051e;
																					IL_051e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)TaskWrapperAsyncResultsearchOption[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_094e;
																					IL_094e:
																					ptr2 += 8;
																					goto end_IL_0396;
																					IL_048d:
																					num5--;
																					goto end_IL_0396;
																					IL_04e9:
																					if (16 >= b)
																					{
																						goto IL_04f7;
																					}
																					goto IL_087b;
																					IL_04f7:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0712;
																					IL_0712:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0396;
																					IL_087b:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_0889;
																				}
																				break;
																			}
																			goto IL_03a1;
																			IL_080c:
																			num5--;
																			goto end_IL_0396;
																			IL_03a1:
																			if (9 <= b)
																			{
																				goto end_IL_0396;
																			}
																			goto IL_03c4;
																			IL_03c4:
																			if (4 >= b)
																			{
																				goto IL_0562;
																			}
																			goto IL_063c;
																			IL_063c:
																			if (6 < b)
																			{
																				goto IL_0647;
																			}
																			goto IL_06a2;
																			IL_0647:
																			if (7 >= b)
																			{
																				goto IL_0652;
																			}
																			goto IL_0665;
																			IL_0652:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0904;
																			IL_0904:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_092d;
																			IL_092d:
																			ptr2 += 8;
																			goto IL_093b;
																			IL_093b:
																			num5--;
																			goto end_IL_0396;
																			IL_0665:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0673;
																			IL_0673:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0681;
																			IL_0681:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 106;
																			goto end_IL_0396;
																			IL_06a2:
																			if (6 > b)
																			{
																				goto IL_06ad;
																			}
																			goto IL_06c0;
																			IL_06ad:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_089c;
																			IL_089c:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_08aa;
																			IL_08aa:
																			array[num5] = 5;
																			goto IL_08b8;
																			IL_08b8:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_08d0;
																			IL_08d0:
																			num5++;
																			goto IL_08de;
																			IL_08de:
																			ptr2 += 8;
																			goto end_IL_0396;
																			IL_06c0:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06ff;
																			IL_06ff:
																			num5 -= 3;
																			goto end_IL_0396;
																			IL_0562:
																			if (4 > b)
																			{
																				goto IL_0570;
																			}
																			goto IL_07e0;
																			IL_0570:
																			if (2 < b)
																			{
																				goto IL_057b;
																			}
																			goto IL_05d9;
																			IL_057b:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0589;
																			IL_0589:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0597;
																			IL_0597:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_05c0;
																			IL_05c0:
																			array[num5 - 1] = 5;
																			goto end_IL_0396;
																			IL_05d9:
																			if (2 <= b)
																			{
																				goto IL_05e4;
																			}
																			goto IL_0629;
																			IL_05e4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_072e;
																			IL_072e:
																			array[num5 - 2] = 0;
																			goto IL_08f1;
																			IL_08f1:
																			num5--;
																			goto end_IL_0396;
																			IL_0629:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_075a;
																			IL_075a:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0768;
																			IL_0768:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0781;
																			IL_0781:
																			array[num5] = 0;
																			goto IL_078f;
																			IL_078f:
																			num5++;
																			num = 87;
																			goto IL_07a6;
																			IL_07a6:
																			ptr2 += 8;
																			goto end_IL_0396;
																			IL_07e0:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_07fe;
																			IL_07fe:
																			ptr2 += 8;
																			goto IL_080c;
																		}
																		break;
																		IL_035a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0396;
																continue;
																end_IL_036d:
																break;
															}
															continue;
															end_IL_037d:
															break;
														}
														continue;
														end_IL_0396:
														break;
													}
													continue;
												}
												goto IL_0a82;
												IL_0a82:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09e6:
												break;
											}
											continue;
											end_IL_09f9:
											break;
										}
										continue;
										end_IL_0a03:
										break;
									}
									continue;
									end_IL_0a0e:
									break;
								}
								continue;
								end_IL_0a1e:
								break;
							}
							continue;
							end_IL_0a2e:
							break;
						}
						continue;
						end_IL_0a3e:
						break;
					}
					continue;
					end_IL_0a57:
					break;
				}
				continue;
				end_IL_0a67:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1, int int_2)
	{
		int num = 53;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 23;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NativeVariantSoapNmtokens.RegisterInteropXmlTypeTM);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 34;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01f0:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01d0:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01c0:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_01b3:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											num = 92;
																											while (true)
																											{
																												if (num != 92)
																												{
																													if (num != 1073)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 5:
																														goto IL_01a0;
																													case 3:
																													case 46:
																														goto IL_01b3;
																													case 70:
																														goto IL_01c0;
																													case 30:
																														goto IL_01d0;
																													case 45:
																														goto IL_01e0;
																													case 22:
																														goto IL_01f0;
																													case 80:
																														goto end_IL_01f0;
																													case 34:
																														goto end_IL_0200;
																													case 41:
																														goto end_IL_0210;
																													case 66:
																														goto IL_0226;
																													case 49:
																													case 60:
																														goto IL_0234;
																													case 64:
																														goto IL_0242;
																													case 9:
																														goto IL_0265;
																													case 74:
																														goto IL_0271;
																													case 61:
																													case 73:
																														goto IL_027c;
																													case 27:
																														goto end_IL_018d;
																													case 71:
																														goto IL_02bc;
																													case 75:
																														goto IL_02cf;
																													case 14:
																														goto IL_02dd;
																													case 79:
																														goto IL_02f0;
																													case 15:
																														goto IL_02fe;
																													case 62:
																														goto IL_0309;
																													case 12:
																														goto IL_0317;
																													case 28:
																													case 50:
																														goto IL_032a;
																													case 65:
																														goto IL_039d;
																													case 42:
																														goto IL_03ab;
																													case 47:
																													case 54:
																														goto IL_03c2;
																													case 35:
																														goto IL_0402;
																													case 67:
																														goto IL_0416;
																													case 81:
																														goto IL_0429;
																													case 26:
																													case 44:
																														goto IL_0447;
																													case 1:
																														goto IL_0463;
																													case 7:
																														goto IL_046e;
																													case 85:
																														goto IL_0479;
																													case 4:
																													case 69:
																														goto IL_0484;
																													case 10:
																													case 11:
																													case 20:
																													case 21:
																													case 29:
																													case 31:
																													case 33:
																													case 37:
																													case 38:
																													case 39:
																													case 56:
																													case 63:
																													case 68:
																													case 78:
																													case 82:
																													case 83:
																														goto end_IL_01a0;
																													case 13:
																														goto IL_04bc;
																													case 59:
																														goto IL_04ca;
																													case 18:
																														goto IL_04d8;
																													case 16:
																													case 17:
																													case 24:
																													case 25:
																													case 32:
																													case 36:
																													case 40:
																													case 43:
																													case 55:
																													case 57:
																													case 58:
																														goto end_IL_021b;
																													case 8:
																														goto end_IL_04e6;
																													case 2:
																														goto end_IL_04f9;
																													case 19:
																														goto end_IL_0503;
																													case 48:
																														goto end_IL_050e;
																													case 6:
																														goto end_IL_0523;
																													case 23:
																													case 76:
																														goto end_IL_0538;
																													case 72:
																														goto end_IL_0548;
																													case 51:
																													case 84:
																														goto end_IL_0558;
																													case 52:
																														goto end_IL_0571;
																													case 53:
																														goto end_IL_0581;
																													case 0:
																													case 77:
																														goto IL_059c;
																													}
																													continue;
																												}
																												if (8 > b)
																												{
																													goto end_IL_01a0;
																												}
																												goto IL_0447;
																												IL_0447:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												goto end_IL_021b;
																												continue;
																												end_IL_018d:
																												break;
																											}
																											goto IL_02ae;
																											continue;
																											end_IL_01a0:
																											break;
																											IL_01a0:;
																										}
																										break;
																									}
																									goto IL_0226;
																									IL_02dd:
																									ptr2 += 8;
																									goto end_IL_021b;
																									IL_0226:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0234;
																									IL_0234:
																									array[num6] = 0;
																									goto IL_0242;
																									IL_0242:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0265;
																									IL_0265:
																									array2[num6] = null;
																									goto IL_02cf;
																									IL_02cf:
																									num6++;
																									goto IL_02dd;
																								}
																								break;
																							}
																							goto IL_0463;
																							IL_0484:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_021b;
																							IL_0463:
																							if (6 <= b)
																							{
																								goto end_IL_021b;
																							}
																							goto IL_046e;
																							IL_046e:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0479;
																							IL_0479:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0484;
																						}
																						break;
																					}
																					goto IL_0271;
																					IL_0402:
																					array[num6 - 2] = 0;
																					goto IL_0416;
																					IL_0271:
																					if (4 <= b)
																					{
																						goto IL_027c;
																					}
																					goto IL_02f0;
																					IL_027c:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 27;
																					goto IL_02ae;
																					IL_02ae:
																					ptr2 += 8;
																					goto IL_02bc;
																					IL_02bc:
																					num6--;
																					goto end_IL_021b;
																					IL_02f0:
																					if (2 >= b)
																					{
																						goto IL_02fe;
																					}
																					goto IL_039d;
																					IL_02fe:
																					if (2 > b)
																					{
																						goto IL_0309;
																					}
																					goto IL_032a;
																					IL_0309:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0317;
																					IL_0317:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_032a:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0429;
																					IL_0429:
																					num6 -= 2;
																					goto end_IL_021b;
																					IL_039d:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_03ab;
																					IL_03ab:
																					if (3 > b)
																					{
																						break;
																					}
																					num = 54;
																					goto IL_03c2;
																					IL_0416:
																					num6--;
																					goto end_IL_021b;
																					IL_03c2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0402;
																				}
																				break;
																				IL_01e0:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04bc;
																		IL_04d8:
																		ptr2 += 8;
																		goto end_IL_021b;
																		IL_04ca:
																		num6++;
																		goto IL_04d8;
																		IL_04bc:
																		array[num6] = 0;
																		goto IL_04ca;
																		continue;
																		end_IL_01f0:
																		break;
																	}
																	continue;
																	end_IL_0200:
																	break;
																}
																continue;
																end_IL_0210:
																break;
															}
															continue;
															end_IL_021b:
															break;
														}
														continue;
													}
													goto IL_059c;
													IL_059c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04e6:
													break;
												}
												continue;
												end_IL_04f9:
												break;
											}
											continue;
											end_IL_0503:
											break;
										}
										continue;
										end_IL_050e:
										break;
									}
									continue;
									end_IL_0523:
									break;
								}
								continue;
								end_IL_0538:
								break;
							}
							continue;
							end_IL_0548:
							break;
						}
						continue;
						end_IL_0558:
						break;
					}
					continue;
					end_IL_0571:
					break;
				}
				continue;
				end_IL_0581:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 98;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileLoadFromgetMustFlush.PaddingHelpersgetNumberDecimalSeparator);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0240:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0213:
																						if (5 <= b)
																						{
																							goto IL_05ac;
																						}
																						while (true)
																						{
																							IL_0203:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01f0:
																									if (3 < b)
																									{
																										num = 112;
																										while (true)
																										{
																											if (num != 112)
																											{
																												if (num != 1093)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 54:
																												case 102:
																													goto IL_01f0;
																												case 3:
																												case 8:
																													goto IL_0203;
																												case 26:
																													goto IL_0213;
																												case 25:
																													goto end_IL_0213;
																												case 27:
																													goto end_IL_0223;
																												case 12:
																													goto IL_0240;
																												case 60:
																													goto end_IL_0240;
																												case 13:
																												case 45:
																													goto end_IL_0250;
																												case 10:
																													goto IL_026b;
																												case 38:
																													goto IL_0276;
																												case 41:
																													goto IL_0286;
																												case 64:
																													goto IL_02a2;
																												case 55:
																												case 67:
																													goto IL_02b0;
																												case 48:
																													goto IL_02f0;
																												case 75:
																													goto IL_0306;
																												case 33:
																												case 51:
																													goto IL_0314;
																												case 77:
																													goto IL_033f;
																												case 80:
																													goto IL_0352;
																												case 57:
																													goto IL_0360;
																												case 44:
																												case 63:
																													goto IL_036e;
																												case 83:
																													goto IL_038a;
																												case 87:
																													goto IL_039d;
																												case 85:
																													goto IL_03ab;
																												case 24:
																												case 49:
																													goto IL_03b9;
																												case 66:
																													goto IL_03f9;
																												case 73:
																													goto IL_040d;
																												case 56:
																												case 89:
																													goto IL_0420;
																												case 65:
																													goto IL_0439;
																												case 78:
																													goto IL_0447;
																												case 31:
																													goto IL_0455;
																												case 91:
																													goto IL_0468;
																												case 99:
																													goto IL_047b;
																												case 15:
																													goto IL_0489;
																												case 32:
																												case 95:
																													goto IL_0497;
																												case 88:
																													goto IL_04d7;
																												case 46:
																													goto IL_04f4;
																												case 105:
																													goto IL_0507;
																												case 28:
																													goto IL_0512;
																												case 72:
																													goto IL_0520;
																												case 29:
																												case 35:
																													goto IL_0533;
																												case 39:
																													goto IL_057c;
																												case 16:
																													goto IL_0590;
																												case 36:
																												case 70:
																													goto IL_05ac;
																												case 22:
																													goto IL_05ba;
																												case 82:
																													goto IL_05dd;
																												case 53:
																													goto end_IL_01dd;
																												case 2:
																													goto IL_05f5;
																												case 0:
																												case 1:
																												case 6:
																												case 7:
																												case 11:
																												case 18:
																												case 40:
																												case 43:
																												case 47:
																												case 58:
																												case 59:
																												case 69:
																												case 74:
																												case 81:
																												case 84:
																												case 86:
																												case 90:
																												case 101:
																												case 103:
																												case 104:
																													goto end_IL_0230;
																												case 62:
																													goto IL_0628;
																												case 92:
																													goto IL_063f;
																												case 17:
																													goto IL_064d;
																												case 14:
																												case 21:
																												case 23:
																												case 30:
																												case 37:
																												case 42:
																												case 71:
																												case 76:
																												case 79:
																												case 93:
																												case 94:
																													goto end_IL_0260;
																												case 5:
																													goto end_IL_065b;
																												case 96:
																													goto end_IL_066e;
																												case 4:
																													goto end_IL_0678;
																												case 20:
																													goto end_IL_0683;
																												case 9:
																													goto end_IL_0698;
																												case 34:
																												case 50:
																													goto end_IL_06ad;
																												case 100:
																													goto end_IL_06bd;
																												case 19:
																												case 52:
																													goto end_IL_06cd;
																												case 97:
																													goto end_IL_06dd;
																												case 98:
																													goto end_IL_06ed;
																												case 61:
																												case 68:
																													goto IL_0708;
																												}
																												continue;
																											}
																											goto IL_047b;
																											IL_04d7:
																											array[num5 - 2] = 0;
																											num = 46;
																											goto IL_04f4;
																											IL_04f4:
																											num5--;
																											goto end_IL_0260;
																											IL_047b:
																											if (4 < b)
																											{
																												goto end_IL_0230;
																											}
																											goto IL_0489;
																											IL_0489:
																											if (4 > b)
																											{
																												goto end_IL_0230;
																											}
																											goto IL_0497;
																											IL_0497:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_04d7;
																											continue;
																											end_IL_01dd:
																											break;
																										}
																										break;
																									}
																									goto IL_0306;
																									IL_038a:
																									ptr2 += 8;
																									goto IL_0468;
																									IL_0468:
																									num5--;
																									goto end_IL_0260;
																									IL_0306:
																									if (3 > b)
																									{
																										goto end_IL_0230;
																									}
																									goto IL_0314;
																									IL_0314:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_038a;
																								}
																								break;
																							}
																							goto IL_0507;
																							IL_0590:
																							num5--;
																							num = 71;
																							goto end_IL_0260;
																							IL_0507:
																							if (2 > b)
																							{
																								goto IL_0512;
																							}
																							goto IL_0533;
																							IL_0512:
																							if (1 < b)
																							{
																								goto end_IL_0230;
																							}
																							goto IL_0520;
																							IL_0520:
																							if (1 <= b)
																							{
																							}
																							goto end_IL_0230;
																							IL_0533:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 39;
																							goto IL_057c;
																							IL_057c:
																							array[num5 - 2] = 0;
																							goto IL_0590;
																						}
																						goto IL_05e7;
																						IL_05f5:
																						ptr2 += 8;
																						goto end_IL_0260;
																						IL_05ac:
																						array[num5] = 0;
																						goto IL_05ba;
																						IL_05ba:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05dd;
																						IL_05dd:
																						array2[num5] = null;
																						goto IL_05e7;
																						IL_05e7:
																						num5++;
																						goto IL_05f5;
																						continue;
																						end_IL_0213:
																						break;
																					}
																					continue;
																				}
																				goto IL_026b;
																				IL_03f9:
																				array[num5 - 2] = 0;
																				goto IL_040d;
																				IL_026b:
																				if (7 < b)
																				{
																					goto IL_0276;
																				}
																				goto IL_0286;
																				IL_0276:
																				if (8 >= b)
																				{
																					goto IL_02a2;
																				}
																				goto IL_0352;
																				IL_02a2:
																				if (8 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_02b0;
																				IL_02b0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02f0;
																				IL_02f0:
																				array[num5 - 2] = 0;
																				goto IL_033f;
																				IL_033f:
																				num5--;
																				goto end_IL_0260;
																				IL_0352:
																				if (9 < b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_0360;
																				IL_0360:
																				if (9 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_036e;
																				IL_036e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0260;
																				IL_0286:
																				if (7 > b)
																				{
																					goto IL_039d;
																				}
																				num = 56;
																				goto IL_0420;
																				IL_040d:
																				num5--;
																				goto end_IL_0260;
																				IL_0420:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0439;
																				IL_0439:
																				array[num5] = 0;
																				goto IL_0447;
																				IL_0447:
																				num5++;
																				goto IL_0455;
																				IL_0455:
																				ptr2 += 8;
																				goto end_IL_0260;
																				IL_039d:
																				if (6 < b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_03ab;
																				IL_03ab:
																				if (6 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_03b9;
																				IL_03b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03f9;
																				continue;
																				end_IL_0223:
																				break;
																			}
																			continue;
																			end_IL_0230:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0628;
																	IL_064d:
																	ptr2 += 8;
																	goto end_IL_0260;
																	IL_063f:
																	num5++;
																	goto IL_064d;
																	IL_0628:
																	array[num5] = 0;
																	num = 92;
																	goto IL_063f;
																	continue;
																	end_IL_0240:
																	break;
																}
																continue;
																end_IL_0250:
																break;
															}
															continue;
															end_IL_0260:
															break;
														}
														continue;
													}
													goto IL_0708;
													IL_0708:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065b:
													break;
												}
												continue;
												end_IL_066e:
												break;
											}
											continue;
											end_IL_0678:
											break;
										}
										continue;
										end_IL_0683:
										break;
									}
									continue;
									end_IL_0698:
									break;
								}
								continue;
								end_IL_06ad:
								break;
							}
							continue;
							end_IL_06bd:
							break;
						}
						continue;
						end_IL_06cd:
						break;
					}
					continue;
					end_IL_06dd:
					break;
				}
				continue;
				end_IL_06ed:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 112;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 106;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentUserIsolatedStorageFileStream.BodyEndFreeBufferNull);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_029f:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_027f:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_026f:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_025f:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0252:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0242:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_0217:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_01fe:
																															array[num5] = 0;
																															num = 119;
																															while (true)
																															{
																																if (num != 119)
																																{
																																	if (num != 1100)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 50:
																																		goto IL_01fe;
																																	case 56:
																																	case 104:
																																		goto IL_0217;
																																	case 69:
																																		goto IL_0232;
																																	case 42:
																																		goto IL_0242;
																																	case 66:
																																		goto IL_0252;
																																	case 62:
																																		goto IL_025f;
																																	case 99:
																																		goto IL_026f;
																																	case 105:
																																		goto IL_027f;
																																	case 100:
																																		goto IL_028f;
																																	case 36:
																																		goto IL_029f;
																																	case 9:
																																		goto end_IL_029f;
																																	case 4:
																																	case 6:
																																		goto end_IL_02af;
																																	case 1:
																																	case 49:
																																		goto IL_02ca;
																																	case 47:
																																		goto IL_02f9;
																																	case 29:
																																		goto IL_030c;
																																	case 5:
																																		goto IL_031a;
																																	case 26:
																																	case 70:
																																		goto IL_0328;
																																	case 8:
																																		goto IL_0351;
																																	case 40:
																																		goto IL_035f;
																																	case 108:
																																		goto IL_0372;
																																	case 53:
																																	case 58:
																																		goto IL_0380;
																																	case 95:
																																		goto IL_038e;
																																	case 59:
																																	case 88:
																																		goto IL_039c;
																																	case 37:
																																		goto IL_03aa;
																																	case 73:
																																		goto IL_03cd;
																																	case 85:
																																		goto IL_03e0;
																																	case 31:
																																		goto IL_03ee;
																																	case 27:
																																		goto IL_0401;
																																	case 57:
																																	case 72:
																																		goto IL_0414;
																																	case 15:
																																		goto IL_0454;
																																	case 7:
																																		goto IL_0471;
																																	case 61:
																																		goto IL_0484;
																																	case 107:
																																	case 110:
																																		goto IL_048f;
																																	case 20:
																																		goto IL_049a;
																																	case 101:
																																	case 103:
																																		goto IL_04a8;
																																	case 83:
																																		goto IL_04c4;
																																	case 89:
																																		goto IL_04d2;
																																	case 22:
																																		goto IL_04ee;
																																	case 28:
																																	case 98:
																																		goto IL_04f9;
																																	case 54:
																																		goto IL_055b;
																																	case 81:
																																	case 87:
																																		goto IL_0577;
																																	case 19:
																																		goto IL_0582;
																																	case 10:
																																	case 71:
																																		goto IL_0590;
																																	case 84:
																																		goto IL_05d0;
																																	case 90:
																																		goto IL_05e4;
																																	case 35:
																																		goto IL_05f7;
																																	case 93:
																																		goto IL_0602;
																																	case 21:
																																	case 45:
																																		goto IL_060d;
																																	case 94:
																																		goto IL_0630;
																																	case 82:
																																		goto IL_0647;
																																	case 34:
																																		goto IL_065e;
																																	case 0:
																																	case 12:
																																	case 13:
																																	case 18:
																																	case 23:
																																	case 24:
																																	case 38:
																																	case 46:
																																	case 48:
																																	case 51:
																																	case 52:
																																	case 64:
																																	case 67:
																																	case 74:
																																	case 75:
																																	case 76:
																																	case 78:
																																	case 80:
																																	case 92:
																																	case 96:
																																	case 102:
																																	case 109:
																																		goto end_IL_01eb;
																																	case 3:
																																	case 14:
																																	case 16:
																																	case 30:
																																	case 32:
																																	case 33:
																																	case 39:
																																	case 41:
																																	case 44:
																																	case 60:
																																	case 77:
																																	case 86:
																																	case 91:
																																	case 97:
																																		goto end_IL_02bf;
																																	case 17:
																																		goto end_IL_068a;
																																	case 25:
																																		goto end_IL_069d;
																																	case 65:
																																		goto end_IL_06a7;
																																	case 106:
																																		goto end_IL_06b2;
																																	case 55:
																																	case 63:
																																		goto end_IL_06c7;
																																	case 11:
																																		goto end_IL_06d7;
																																	case 2:
																																	case 79:
																																		goto end_IL_06f0;
																																	case 111:
																																		goto end_IL_0700;
																																	case 112:
																																		goto end_IL_0710;
																																	case 43:
																																	case 68:
																																		goto IL_072b;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_02f9;
																																IL_02f9:
																																ptr2 += 8;
																																goto end_IL_02bf;
																																continue;
																																end_IL_01eb:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_0232:;
																												}
																												break;
																											}
																											goto IL_030c;
																											IL_035f:
																											num5--;
																											goto end_IL_02bf;
																											IL_030c:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_031a;
																											IL_031a:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0328;
																											IL_0328:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0351;
																											IL_0351:
																											ptr2 += 8;
																											goto IL_035f;
																										}
																										break;
																									}
																									goto IL_02ca;
																									IL_02ca:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									num = 32;
																									goto end_IL_02bf;
																								}
																								break;
																							}
																							goto IL_0372;
																							IL_0401:
																							if (4 <= b)
																							{
																								goto end_IL_02bf;
																							}
																							break;
																							IL_0372:
																							if (4 < b)
																							{
																								goto IL_0380;
																							}
																							goto IL_0401;
																							IL_0380:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_038e;
																							IL_038e:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_039c;
																							IL_039c:
																							array[num5] = 0;
																							goto IL_03aa;
																							IL_03aa:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03cd;
																							IL_03cd:
																							array2[num5] = null;
																							num = 85;
																							goto IL_03e0;
																							IL_03e0:
																							num5++;
																							goto IL_03ee;
																							IL_03ee:
																							ptr2 += 8;
																							goto end_IL_02bf;
																						}
																						break;
																					}
																					goto IL_0414;
																					IL_0471:
																					num5--;
																					goto end_IL_02bf;
																					IL_0414:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0454;
																					IL_0454:
																					array[num5 - 2] = 0;
																					num = 7;
																					goto IL_0471;
																				}
																				break;
																			}
																			goto IL_0484;
																			IL_0630:
																			array[num5] = 0;
																			num = 82;
																			goto IL_0647;
																			IL_0484:
																			if (9 < b)
																			{
																				goto IL_048f;
																			}
																			goto IL_04ee;
																			IL_048f:
																			if (10 >= b)
																			{
																				goto IL_049a;
																			}
																			goto IL_04c4;
																			IL_049a:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04a8;
																			IL_04a8:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02bf;
																			IL_04c4:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04d2;
																			IL_04d2:
																			if (11 > b)
																			{
																				num = 52;
																			}
																			break;
																			IL_0647:
																			num5++;
																			num = 34;
																			goto IL_065e;
																			IL_04ee:
																			if (9 <= b)
																			{
																				goto IL_04f9;
																			}
																			num = 81;
																			goto IL_0577;
																			IL_04f9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_055b;
																			IL_055b:
																			num5 -= 2;
																			goto end_IL_02bf;
																			IL_065e:
																			ptr2 += 8;
																			num = 3;
																			goto end_IL_02bf;
																			IL_0577:
																			if (7 >= b)
																			{
																				goto IL_0582;
																			}
																			goto IL_05f7;
																			IL_0582:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0590;
																			IL_0590:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05d0;
																			IL_05d0:
																			array[num5 - 2] = 0;
																			goto IL_05e4;
																			IL_05e4:
																			num5--;
																			goto end_IL_02bf;
																			IL_05f7:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0602;
																			IL_0602:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_060d;
																			IL_060d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0630;
																		}
																		break;
																		IL_028f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02bf;
																continue;
																end_IL_029f:
																break;
															}
															continue;
															end_IL_02af:
															break;
														}
														continue;
														end_IL_02bf:
														break;
													}
													continue;
												}
												goto IL_072b;
												IL_072b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068a:
												break;
											}
											continue;
											end_IL_069d:
											break;
										}
										continue;
										end_IL_06a7:
										break;
									}
									continue;
									end_IL_06b2:
									break;
								}
								continue;
								end_IL_06c7:
								break;
							}
							continue;
							end_IL_06d7:
							break;
						}
						continue;
						end_IL_06f0:
						break;
					}
					continue;
					end_IL_0700:
					break;
				}
				continue;
				end_IL_0710:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 12;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HandleToInfoTYPEFLAGFCANCREATE.PopDirectionIsolateGetEnvironmentVariables);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 69;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0345:
														byte b = *ptr2;
														while (true)
														{
															IL_0335:
															ptr2++;
															while (true)
															{
																IL_0322:
																if (b >= 1)
																{
																	num = 54;
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0305:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f5:
																					if (7 <= b)
																					{
																						while (true)
																						{
																							IL_02b3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							while (true)
																							{
																								IL_029d:
																								array[num5 - 2] = 0;
																								while (true)
																								{
																									IL_0284:
																									num5--;
																									num = 149;
																									while (num != 149)
																									{
																										if (num != 1130)
																										{
																											goto IL_0567;
																										}
																										switch (num)
																										{
																										case 61:
																											goto IL_0284;
																										case 137:
																											goto IL_029d;
																										case 99:
																										case 124:
																											goto IL_02b3;
																										case 142:
																											goto IL_02f5;
																										case 131:
																											goto IL_0305;
																										case 54:
																											goto IL_0312;
																										case 87:
																											goto IL_0322;
																										case 8:
																											goto IL_0335;
																										case 28:
																										case 53:
																											goto IL_0345;
																										case 23:
																										case 74:
																											goto IL_0350;
																										case 75:
																											goto IL_035e;
																										case 7:
																										case 45:
																											goto IL_036c;
																										case 72:
																											goto IL_0377;
																										case 2:
																										case 62:
																											goto IL_0385;
																										case 33:
																											goto IL_03f2;
																										case 80:
																										case 84:
																											goto IL_0405;
																										case 91:
																											goto IL_041b;
																										case 103:
																											goto IL_0437;
																										case 51:
																										case 106:
																											goto IL_0490;
																										case 68:
																										case 90:
																											goto IL_049b;
																										case 50:
																										case 58:
																											goto IL_04a6;
																										case 73:
																											goto IL_04b9;
																										case 60:
																										case 102:
																											goto IL_04c7;
																										case 35:
																											goto IL_04d5;
																										case 4:
																											goto IL_04f8;
																										case 22:
																											goto IL_0502;
																										case 77:
																											goto IL_0515;
																										case 40:
																										case 44:
																											goto IL_0520;
																										case 0:
																										case 117:
																											goto IL_0538;
																										case 64:
																										case 76:
																											goto IL_0546;
																										case 19:
																											goto IL_0554;
																										case 48:
																										case 121:
																											goto IL_0567;
																										case 15:
																											goto IL_0575;
																										case 112:
																										case 123:
																											goto IL_0588;
																										case 116:
																											goto IL_0593;
																										case 46:
																											goto IL_05aa;
																										case 85:
																										case 119:
																											goto IL_05b8;
																										case 41:
																											goto IL_05e1;
																										case 26:
																											goto IL_05ef;
																										case 70:
																											goto IL_060b;
																										case 27:
																										case 31:
																											goto IL_0619;
																										case 79:
																											goto IL_0632;
																										case 20:
																											goto IL_0640;
																										case 59:
																											goto IL_0657;
																										case 25:
																										case 126:
																											goto IL_066a;
																										case 6:
																											goto IL_0678;
																										case 38:
																										case 107:
																											goto IL_0686;
																										case 82:
																											goto IL_06a9;
																										case 129:
																											goto IL_06bc;
																										case 78:
																										case 127:
																											goto IL_06c7;
																										case 37:
																											goto IL_06d5;
																										case 109:
																										case 113:
																											goto IL_06e3;
																										case 65:
																										case 118:
																											goto IL_06f6;
																										case 130:
																											goto IL_0712;
																										case 122:
																											goto IL_0720;
																										case 132:
																											goto IL_0733;
																										case 36:
																										case 97:
																											goto IL_0741;
																										case 96:
																											goto IL_0781;
																										case 63:
																											goto IL_0795;
																										case 133:
																											goto IL_07a8;
																										case 30:
																										case 56:
																											goto IL_07b6;
																										case 111:
																											goto IL_07f6;
																										case 114:
																											goto IL_080a;
																										case 134:
																											goto IL_081a;
																										case 83:
																											goto IL_0828;
																										case 1:
																										case 5:
																										case 13:
																										case 17:
																										case 18:
																										case 24:
																										case 32:
																										case 42:
																										case 52:
																										case 55:
																										case 71:
																										case 93:
																										case 95:
																										case 98:
																										case 100:
																										case 101:
																										case 105:
																										case 110:
																										case 120:
																										case 125:
																										case 128:
																										case 138:
																										case 139:
																										case 140:
																											goto end_IL_0312;
																										case 141:
																											goto IL_084d;
																										case 3:
																										case 9:
																										case 14:
																										case 16:
																										case 29:
																										case 39:
																										case 49:
																										case 57:
																										case 66:
																										case 67:
																										case 69:
																										case 88:
																										case 89:
																										case 104:
																										case 115:
																										case 136:
																											goto end_IL_0271;
																										case 10:
																											goto end_IL_085b;
																										case 108:
																											goto end_IL_086e;
																										case 94:
																											goto end_IL_0881;
																										case 86:
																											goto end_IL_088c;
																										case 21:
																										case 47:
																											goto end_IL_08a1;
																										case 43:
																											goto end_IL_08b1;
																										case 81:
																										case 135:
																											goto end_IL_08c1;
																										case 11:
																											goto end_IL_08d1;
																										case 12:
																											goto end_IL_08e1;
																										case 34:
																										case 92:
																											goto IL_08fc;
																										}
																										continue;
																										end_IL_0271:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0490;
																					IL_0632:
																					array[num5] = 0;
																					goto IL_0640;
																					IL_0490:
																					if (3 < b)
																					{
																						goto IL_049b;
																					}
																					goto IL_0515;
																					IL_049b:
																					if (5 < b)
																					{
																						goto IL_04a6;
																					}
																					goto IL_04b9;
																					IL_04a6:
																					if (6 < b)
																					{
																						goto end_IL_0312;
																					}
																					goto IL_07a8;
																					IL_07a8:
																					if (6 > b)
																					{
																						goto end_IL_0312;
																					}
																					goto IL_07b6;
																					IL_07b6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_07f6;
																					IL_07f6:
																					array[num5 - 2] = 0;
																					goto IL_080a;
																					IL_080a:
																					num5--;
																					break;
																					IL_04b9:
																					if (5 <= b)
																					{
																						goto IL_04c7;
																					}
																					goto IL_0567;
																					IL_04c7:
																					array[num5] = 0;
																					goto IL_04d5;
																					IL_04d5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04f8;
																					IL_04f8:
																					array2[num5] = null;
																					goto IL_0502;
																					IL_0502:
																					num5++;
																					goto IL_084d;
																					IL_084d:
																					ptr2 += 8;
																					break;
																					IL_0567:
																					if (4 < b)
																					{
																						goto end_IL_0312;
																					}
																					goto IL_0575;
																					IL_0575:
																					if (4 <= b)
																					{
																						break;
																					}
																					goto end_IL_0312;
																					IL_0515:
																					if (3 <= b)
																					{
																						goto IL_0520;
																					}
																					goto IL_0588;
																					IL_0520:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_0588:
																					if (1 < b)
																					{
																						goto IL_0593;
																					}
																					num = 70;
																					goto IL_060b;
																					IL_0593:
																					if (2 < b)
																					{
																						goto end_IL_0312;
																					}
																					num = 46;
																					goto IL_05aa;
																					IL_0657:
																					ptr2 += 8;
																					break;
																					IL_05aa:
																					if (2 > b)
																					{
																						goto end_IL_0312;
																					}
																					goto IL_05b8;
																					IL_05b8:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05e1;
																					IL_05e1:
																					ptr2 += 8;
																					goto IL_05ef;
																					IL_05ef:
																					num5--;
																					break;
																					IL_0640:
																					num5++;
																					num = 59;
																					goto IL_0657;
																					IL_060b:
																					if (1 > b)
																					{
																						goto end_IL_0312;
																					}
																					goto IL_0619;
																					IL_0619:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0632;
																				}
																				break;
																			}
																			goto IL_0350;
																			IL_06f6:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0350:
																			if (11 >= b)
																			{
																				goto IL_035e;
																			}
																			goto IL_0538;
																			IL_035e:
																			if (11 > b)
																			{
																				goto IL_036c;
																			}
																			goto IL_0405;
																			IL_036c:
																			if (9 >= b)
																			{
																				goto IL_0377;
																			}
																			goto IL_03f2;
																			IL_0377:
																			if (9 <= b)
																			{
																				goto IL_0385;
																			}
																			goto IL_066a;
																			IL_0385:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 91;
																			goto IL_041b;
																			IL_041b:
																			num5 -= 2;
																			num = 16;
																			break;
																			IL_066a:
																			if (8 < b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_0678;
																			IL_0678:
																			if (8 > b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_0686;
																			IL_0686:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06a9;
																			IL_06a9:
																			array[num5] = 0;
																			goto IL_081a;
																			IL_081a:
																			num5++;
																			goto IL_0828;
																			IL_0828:
																			ptr2 += 8;
																			break;
																			IL_03f2:
																			if (10 < b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_0733;
																			IL_0733:
																			if (10 > b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_0741;
																			IL_0741:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0781;
																			IL_0781:
																			array[num5 - 2] = 0;
																			goto IL_0795;
																			IL_0795:
																			num5--;
																			break;
																			IL_0405:
																			array[num5 - 2] = 0;
																			goto IL_0437;
																			IL_0437:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)PtrToStructureSerializable[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0712;
																			IL_0712:
																			num5--;
																			goto IL_0720;
																			IL_0720:
																			ptr2 += 8;
																			break;
																			IL_0538:
																			if (13 < b)
																			{
																				goto IL_0546;
																			}
																			goto IL_06bc;
																			IL_0546:
																			if (14 < b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_0554;
																			IL_0554:
																			if (14 > b)
																			{
																			}
																			goto end_IL_0312;
																			IL_06bc:
																			if (13 > b)
																			{
																				goto IL_06c7;
																			}
																			goto IL_06f6;
																			IL_06c7:
																			if (12 < b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_06d5;
																			IL_06d5:
																			if (12 > b)
																			{
																				goto end_IL_0312;
																			}
																			goto IL_06e3;
																			IL_06e3:
																			num5--;
																			break;
																		}
																		goto end_IL_0322;
																		continue;
																		end_IL_0312:
																		break;
																		IL_0312:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0322:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08fc;
												IL_08fc:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_085b:
												break;
											}
											continue;
											end_IL_086e:
											break;
										}
										continue;
										end_IL_0881:
										break;
									}
									continue;
									end_IL_088c:
									break;
								}
								continue;
								end_IL_08a1:
								break;
							}
							continue;
							end_IL_08b1:
							break;
						}
						continue;
						end_IL_08c1:
						break;
					}
					continue;
					end_IL_08d1:
					break;
				}
				continue;
				end_IL_08e1:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 35;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 77;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IRemotingFormatterTrackingServices.setNumberGroupSeparatorCurrencyDecimalSeparator);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 96;
																while (true)
																{
																	if (num != 96)
																	{
																		if (num != 1077)
																		{
																			goto IL_0411;
																		}
																		switch (num)
																		{
																		case 46:
																			goto end_IL_018f;
																		case 57:
																			goto IL_01b3;
																		case 32:
																			goto IL_01c1;
																		case 85:
																			goto IL_01cf;
																		case 4:
																			goto IL_01dd;
																		case 26:
																			goto IL_01eb;
																		case 50:
																			goto IL_01f6;
																		case 65:
																		case 74:
																			goto IL_0204;
																		case 29:
																			goto IL_0212;
																		case 12:
																		case 23:
																			goto IL_0220;
																		case 33:
																			goto IL_0238;
																		case 31:
																			goto IL_0243;
																		case 28:
																		case 67:
																			goto IL_0251;
																		case 52:
																			goto IL_025f;
																		case 83:
																			goto IL_0282;
																		case 0:
																			goto IL_028c;
																		case 20:
																			goto IL_029a;
																		case 71:
																			goto IL_02ad;
																		case 30:
																			goto IL_02bb;
																		case 5:
																		case 64:
																			goto IL_02c9;
																		case 80:
																			goto IL_02ee;
																		case 3:
																		case 69:
																			goto IL_02f9;
																		case 81:
																			goto IL_0322;
																		case 49:
																			goto IL_0330;
																		case 89:
																			goto IL_0343;
																		case 47:
																			goto IL_0351;
																		case 25:
																		case 61:
																			goto IL_035f;
																		case 39:
																			goto IL_03cd;
																		case 86:
																			goto IL_03e0;
																		case 38:
																			goto IL_03ee;
																		case 42:
																			goto IL_03fb;
																		case 54:
																			goto IL_0406;
																		case 55:
																		case 66:
																			goto IL_0411;
																		case 21:
																			goto IL_0451;
																		case 48:
																			goto IL_0465;
																		case 2:
																		case 8:
																		case 13:
																		case 14:
																		case 16:
																		case 18:
																		case 19:
																		case 22:
																		case 24:
																		case 40:
																		case 45:
																		case 53:
																		case 60:
																		case 63:
																		case 68:
																		case 70:
																		case 75:
																		case 79:
																		case 82:
																		case 84:
																			goto IL_0475;
																		case 36:
																			goto IL_0498;
																		case 76:
																			goto IL_04a6;
																		case 11:
																			goto IL_04b4;
																		case 1:
																		case 6:
																		case 7:
																		case 10:
																		case 27:
																		case 37:
																		case 41:
																		case 43:
																		case 62:
																		case 73:
																		case 87:
																			goto end_IL_019f;
																		case 56:
																			goto end_IL_04c2;
																		case 44:
																			goto end_IL_04d5;
																		case 72:
																			goto end_IL_04df;
																		case 58:
																			goto end_IL_04ea;
																		case 17:
																			goto end_IL_04ff;
																		case 77:
																			goto end_IL_0514;
																		case 59:
																			goto end_IL_0524;
																		case 15:
																			goto end_IL_0534;
																		case 9:
																		case 51:
																			goto end_IL_053f;
																		case 34:
																			goto end_IL_054f;
																		case 35:
																			goto end_IL_055f;
																		case 78:
																		case 88:
																			goto IL_0583;
																		}
																		continue;
																	}
																	b = *ptr2;
																	goto IL_01b3;
																	IL_0475:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0498;
																	IL_04a6:
																	num5++;
																	goto IL_04b4;
																	IL_0498:
																	array[num5] = 0;
																	goto IL_04a6;
																	IL_01b3:
																	ptr2++;
																	goto IL_01c1;
																	IL_01c1:
																	if (b >= 1)
																	{
																		goto IL_01cf;
																	}
																	goto IL_0475;
																	IL_01cf:
																	if (b <= 8)
																	{
																		goto IL_01dd;
																	}
																	goto IL_0475;
																	IL_01dd:
																	if (4 < b)
																	{
																		goto IL_01eb;
																	}
																	num = 80;
																	goto IL_02ee;
																	IL_01eb:
																	if (6 >= b)
																	{
																		goto IL_01f6;
																	}
																	goto IL_0238;
																	IL_01f6:
																	if (6 <= b)
																	{
																		goto end_IL_019f;
																	}
																	goto IL_0204;
																	IL_0204:
																	if (5 >= b)
																	{
																		goto IL_0212;
																	}
																	goto IL_0475;
																	IL_0212:
																	if (5 <= b)
																	{
																		goto IL_0220;
																	}
																	goto IL_0475;
																	IL_0220:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_019f;
																	IL_0238:
																	if (7 >= b)
																	{
																		goto IL_0243;
																	}
																	goto IL_02ad;
																	IL_0243:
																	if (7 <= b)
																	{
																		goto IL_0251;
																	}
																	goto IL_0475;
																	IL_0251:
																	array[num5] = 0;
																	goto IL_025f;
																	IL_025f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0282;
																	IL_0282:
																	array2[num5] = null;
																	goto IL_028c;
																	IL_028c:
																	num5++;
																	goto IL_029a;
																	IL_029a:
																	ptr2 += 8;
																	goto end_IL_019f;
																	IL_02ad:
																	if (8 >= b)
																	{
																		goto IL_02bb;
																	}
																	goto IL_0475;
																	IL_02bb:
																	if (8 <= b)
																	{
																		goto IL_02c9;
																	}
																	goto IL_0475;
																	IL_02c9:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_019f;
																	IL_04b4:
																	ptr2 += 8;
																	goto end_IL_019f;
																	IL_02ee:
																	if (4 <= b)
																	{
																		goto IL_02f9;
																	}
																	goto IL_0343;
																	IL_02f9:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0322;
																	IL_0322:
																	ptr2 += 8;
																	goto IL_0330;
																	IL_0330:
																	num5--;
																	goto end_IL_019f;
																	IL_0343:
																	if (2 >= b)
																	{
																		goto IL_0351;
																	}
																	goto IL_03fb;
																	IL_0351:
																	if (2 <= b)
																	{
																		goto IL_035f;
																	}
																	goto IL_03e0;
																	IL_035f:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_03cd;
																	IL_03cd:
																	num5 -= 2;
																	goto end_IL_019f;
																	IL_03e0:
																	if (1 >= b)
																	{
																		goto IL_03ee;
																	}
																	goto IL_0475;
																	IL_03ee:
																	if (1 <= b)
																	{
																	}
																	goto IL_0475;
																	IL_03fb:
																	if (3 >= b)
																	{
																		goto IL_0406;
																	}
																	goto IL_0475;
																	IL_0406:
																	if (3 <= b)
																	{
																		goto IL_0411;
																	}
																	goto IL_0475;
																	IL_0411:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0451;
																	IL_0451:
																	array[num5 - 2] = 0;
																	goto IL_0465;
																	IL_0465:
																	num5--;
																	goto end_IL_019f;
																	continue;
																	end_IL_018f:
																	break;
																}
																continue;
																end_IL_019f:
																break;
															}
															continue;
														}
														num = 78;
														goto IL_0583;
														IL_0583:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04c2:
														break;
													}
													continue;
													end_IL_04d5:
													break;
												}
												continue;
												end_IL_04df:
												break;
											}
											continue;
											end_IL_04ea:
											break;
										}
										continue;
										end_IL_04ff:
										break;
									}
									continue;
									end_IL_0514:
									break;
								}
								continue;
								end_IL_0524:
								break;
							}
							continue;
							end_IL_0534:
							break;
						}
						continue;
						end_IL_053f:
						break;
					}
					continue;
					end_IL_054f:
					break;
				}
				continue;
				end_IL_055f:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 124;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 64;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 80;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetErrorDomainIsolationByRoamingUser.FormatDecimalCreateDefinition);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0385:
														num = 76;
														while (true)
														{
															IL_037a:
															byte b = *ptr2;
															while (true)
															{
																IL_0361:
																ptr2++;
																num = 85;
																while (true)
																{
																	IL_0351:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_0331:
																				if (7 < b)
																				{
																					while (true)
																					{
																						IL_0321:
																						if (11 >= b)
																						{
																							while (true)
																							{
																								IL_0311:
																								if (11 > b)
																								{
																									while (true)
																									{
																										IL_0304:
																										if (9 >= b)
																										{
																											while (true)
																											{
																												IL_02f4:
																												if (9 > b)
																												{
																													while (8 >= b)
																													{
																														while (8 <= b)
																														{
																															while (true)
																															{
																																IL_02af:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																while (true)
																																{
																																	IL_029f:
																																	array[num5] = 0;
																																	while (true)
																																	{
																																		IL_028f:
																																		num5++;
																																		while (true)
																																		{
																																			IL_0276:
																																			ptr2 += 8;
																																			num = 149;
																																			while (num != 149)
																																			{
																																				if (num != 1130)
																																				{
																																					goto IL_0341;
																																				}
																																				switch (num)
																																				{
																																				case 141:
																																					goto IL_0276;
																																				case 4:
																																					goto IL_028f;
																																				case 134:
																																					goto IL_029f;
																																				case 96:
																																				case 99:
																																					goto IL_02af;
																																				case 9:
																																					goto IL_02d4;
																																				case 111:
																																					goto IL_02e4;
																																				case 10:
																																					goto IL_02f4;
																																				case 46:
																																				case 81:
																																					goto IL_0304;
																																				case 19:
																																					goto IL_0311;
																																				case 62:
																																					goto IL_0321;
																																				case 138:
																																					goto IL_0331;
																																				case 16:
																																					goto IL_0341;
																																				case 85:
																																					goto IL_0351;
																																				case 140:
																																					goto IL_0361;
																																				case 76:
																																					goto IL_037a;
																																				case 139:
																																					goto IL_0385;
																																				case 12:
																																				case 92:
																																					goto IL_0390;
																																				case 5:
																																					goto IL_039e;
																																				case 0:
																																				case 52:
																																					goto IL_03ac;
																																				case 94:
																																					goto IL_03f1;
																																				case 63:
																																				case 107:
																																					goto IL_03fc;
																																				case 82:
																																					goto IL_043c;
																																				case 117:
																																					goto IL_0459;
																																				case 126:
																																					goto IL_046c;
																																				case 11:
																																					goto IL_047a;
																																				case 29:
																																					goto IL_0488;
																																				case 36:
																																				case 79:
																																					goto IL_0493;
																																				case 73:
																																					goto IL_04a1;
																																				case 20:
																																					goto IL_04c4;
																																				case 31:
																																					goto IL_04ce;
																																				case 44:
																																					goto IL_04dc;
																																				case 26:
																																					goto IL_04ef;
																																				case 84:
																																					goto IL_04fd;
																																				case 58:
																																				case 115:
																																					goto IL_0510;
																																				case 39:
																																					goto IL_051e;
																																				case 17:
																																				case 93:
																																					goto IL_052c;
																																				case 114:
																																					goto IL_056c;
																																				case 112:
																																					goto IL_0589;
																																				case 127:
																																					goto IL_05a5;
																																				case 33:
																																					goto IL_05b9;
																																				case 132:
																																					goto IL_05cc;
																																				case 27:
																																					goto IL_05da;
																																				case 55:
																																					goto IL_05e5;
																																				case 7:
																																				case 71:
																																					goto IL_05f3;
																																				case 22:
																																					goto IL_060c;
																																				case 14:
																																					goto IL_061a;
																																				case 72:
																																					goto IL_0628;
																																				case 49:
																																					goto IL_063b;
																																				case 56:
																																					goto IL_0649;
																																				case 38:
																																				case 103:
																																					goto IL_0657;
																																				case 87:
																																					goto IL_0680;
																																				case 88:
																																					goto IL_068e;
																																				case 91:
																																				case 104:
																																					goto IL_06a1;
																																				case 15:
																																				case 32:
																																					goto IL_06b9;
																																				case 121:
																																					goto IL_071b;
																																				case 77:
																																				case 119:
																																					goto IL_072e;
																																				case 60:
																																					goto IL_0742;
																																				case 98:
																																					goto IL_0781;
																																				case 135:
																																					goto IL_0794;
																																				case 120:
																																					goto IL_079f;
																																				case 40:
																																					goto IL_07aa;
																																				case 35:
																																					goto IL_07c0;
																																				case 13:
																																				case 97:
																																					goto IL_07cb;
																																				case 109:
																																					goto IL_07d6;
																																				case 53:
																																				case 136:
																																					goto IL_07e1;
																																				case 21:
																																				case 34:
																																					goto IL_07f1;
																																				case 3:
																																				case 6:
																																				case 8:
																																				case 23:
																																				case 25:
																																				case 28:
																																				case 30:
																																				case 37:
																																				case 41:
																																				case 42:
																																				case 43:
																																				case 45:
																																				case 48:
																																				case 61:
																																				case 68:
																																				case 69:
																																				case 70:
																																				case 74:
																																				case 83:
																																				case 90:
																																				case 95:
																																				case 100:
																																				case 101:
																																				case 105:
																																				case 108:
																																				case 113:
																																				case 118:
																																				case 122:
																																				case 125:
																																				case 130:
																																				case 133:
																																				case 137:
																																					goto end_IL_02d4;
																																				case 1:
																																				case 2:
																																				case 18:
																																				case 54:
																																				case 57:
																																				case 59:
																																				case 65:
																																				case 75:
																																				case 78:
																																				case 89:
																																				case 106:
																																				case 116:
																																				case 128:
																																				case 129:
																																				case 131:
																																				case 142:
																																					goto end_IL_0263;
																																				case 50:
																																					goto end_IL_0826;
																																				case 67:
																																					goto end_IL_0839;
																																				case 80:
																																					goto end_IL_0843;
																																				case 110:
																																					goto end_IL_084e;
																																				case 51:
																																				case 66:
																																					goto end_IL_0863;
																																				case 86:
																																					goto end_IL_087c;
																																				case 24:
																																				case 64:
																																					goto end_IL_088c;
																																				case 123:
																																					goto end_IL_089c;
																																				case 124:
																																					goto end_IL_08ac;
																																				case 47:
																																				case 102:
																																					goto IL_08d0;
																																				}
																																				continue;
																																				end_IL_0263:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_0351;
																															continue;
																															end_IL_02d4:
																															break;
																															IL_02d4:;
																														}
																														break;
																														IL_02e4:;
																													}
																													break;
																												}
																												goto IL_06b9;
																												IL_071b:
																												num5 -= 2;
																												goto end_IL_0351;
																												IL_06b9:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_071b;
																											}
																											break;
																										}
																										goto IL_0390;
																										IL_05b9:
																										num5--;
																										goto end_IL_0351;
																										IL_0390:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_039e;
																										IL_039e:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_03ac;
																										IL_03ac:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_05a5;
																										IL_05a5:
																										array[num5 - 2] = 0;
																										goto IL_05b9;
																									}
																									break;
																								}
																								goto IL_072e;
																								IL_0781:
																								ptr2 += 8;
																								goto end_IL_0351;
																								IL_072e:
																								array[num5 - 1] = 0;
																								goto IL_0742;
																								IL_0742:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getTypeHandleGetUserString[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_0781;
																							}
																							break;
																						}
																						goto IL_0794;
																						IL_07e1:
																						num5--;
																						goto end_IL_0351;
																						IL_0794:
																						if (13 < b)
																						{
																							goto IL_079f;
																						}
																						num = 35;
																						goto IL_07c0;
																						IL_079f:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_07aa;
																						IL_07aa:
																						if (14 <= b)
																						{
																						}
																						break;
																						IL_07f1:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						num = 142;
																						goto end_IL_0351;
																						IL_07c0:
																						if (13 > b)
																						{
																							goto IL_07cb;
																						}
																						goto IL_07f1;
																						IL_07cb:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_07d6;
																						IL_07d6:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_07e1;
																					}
																					break;
																				}
																				goto IL_03f1;
																				IL_06a1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0351;
																				IL_03f1:
																				if (7 <= b)
																				{
																					goto IL_03fc;
																				}
																				goto IL_046c;
																				IL_03fc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_043c;
																				IL_043c:
																				array[num5 - 2] = 0;
																				num = 117;
																				goto IL_0459;
																				IL_0459:
																				num5--;
																				goto end_IL_0351;
																				IL_046c:
																				if (3 < b)
																				{
																					goto IL_047a;
																				}
																				goto IL_05cc;
																				IL_047a:
																				if (5 >= b)
																				{
																					goto IL_0488;
																				}
																				goto IL_0510;
																				IL_0488:
																				if (5 <= b)
																				{
																					goto IL_0493;
																				}
																				goto IL_04ef;
																				IL_0493:
																				array[num5] = 0;
																				goto IL_04a1;
																				IL_04a1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04c4;
																				IL_04c4:
																				array2[num5] = null;
																				goto IL_04ce;
																				IL_04ce:
																				num5++;
																				goto IL_04dc;
																				IL_04dc:
																				ptr2 += 8;
																				goto end_IL_0351;
																				IL_04ef:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_04fd;
																				IL_04fd:
																				if (4 <= b)
																				{
																					goto end_IL_0351;
																				}
																				break;
																				IL_0510:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_051e;
																				IL_051e:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_052c;
																				IL_052c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_056c;
																				IL_056c:
																				array[num5 - 2] = 0;
																				num = 112;
																				goto IL_0589;
																				IL_0589:
																				num5--;
																				num = 57;
																				goto end_IL_0351;
																				IL_05cc:
																				if (3 > b)
																				{
																					goto IL_05da;
																				}
																				goto IL_06a1;
																				IL_05da:
																				if (1 >= b)
																				{
																					goto IL_05e5;
																				}
																				goto IL_063b;
																				IL_05e5:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_05f3;
																				IL_05f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_060c;
																				IL_060c:
																				array[num5] = 0;
																				goto IL_061a;
																				IL_061a:
																				num5++;
																				goto IL_0628;
																				IL_0628:
																				ptr2 += 8;
																				goto end_IL_0351;
																				IL_063b:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0649;
																				IL_0649:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0657;
																				IL_0657:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0680;
																				IL_0680:
																				ptr2 += 8;
																				goto IL_068e;
																				IL_068e:
																				num5--;
																				goto end_IL_0351;
																			}
																			break;
																			IL_0341:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0351:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08d0;
												IL_08d0:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0826:
												break;
											}
											continue;
											end_IL_0839:
											break;
										}
										continue;
										end_IL_0843:
										break;
									}
									continue;
									end_IL_084e:
									break;
								}
								continue;
								end_IL_0863:
								break;
							}
							continue;
							end_IL_087c:
							break;
						}
						continue;
						end_IL_088c:
						break;
					}
					continue;
					end_IL_089c:
					break;
				}
				continue;
				end_IL_08ac:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 109;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct90.IApplicationContextEuropeanNumber);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0299:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_027c:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_026f:
																					if (10 < b)
																					{
																						while (true)
																						{
																							IL_025f:
																							if (12 >= b)
																							{
																								while (true)
																								{
																									IL_024c:
																									if (12 > b)
																									{
																										num = 135;
																										while (true)
																										{
																											if (num != 135)
																											{
																												if (num != 1116)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 44:
																													goto IL_024c;
																												case 31:
																													goto IL_025f;
																												case 38:
																													goto IL_026f;
																												case 98:
																													goto IL_027c;
																												case 65:
																													goto end_IL_027c;
																												case 125:
																													goto IL_0299;
																												case 78:
																													goto end_IL_0299;
																												case 50:
																												case 70:
																													goto end_IL_02a9;
																												case 49:
																													goto IL_02c4;
																												case 79:
																													goto IL_02d4;
																												case 82:
																													goto IL_02e7;
																												case 35:
																												case 75:
																													goto IL_02f2;
																												case 20:
																													goto IL_0300;
																												case 29:
																													goto IL_0310;
																												case 71:
																												case 90:
																													goto IL_0320;
																												case 7:
																												case 91:
																													goto IL_0333;
																												case 10:
																													goto IL_0341;
																												case 45:
																												case 67:
																													goto IL_034f;
																												case 5:
																													goto IL_0368;
																												case 36:
																													goto IL_0376;
																												case 13:
																													goto IL_0384;
																												case 77:
																												case 94:
																													goto IL_0397;
																												case 51:
																													goto IL_03b4;
																												case 85:
																													goto IL_03f3;
																												case 12:
																												case 99:
																													goto IL_040f;
																												case 54:
																													goto IL_041a;
																												case 84:
																													goto IL_042d;
																												case 11:
																												case 101:
																													goto IL_0449;
																												case 19:
																													goto IL_0457;
																												case 42:
																													goto IL_047a;
																												case 56:
																													goto IL_0484;
																												case 52:
																													goto IL_0492;
																												case 76:
																												case 106:
																													goto IL_04a5;
																												case 22:
																													goto IL_04b3;
																												case 30:
																												case 33:
																													goto IL_04c1;
																												case 57:
																													goto IL_050a;
																												case 37:
																													goto IL_051e;
																												case 39:
																												case 107:
																													goto IL_0531;
																												case 41:
																													goto IL_0593;
																												case 62:
																												case 110:
																													goto IL_05a6;
																												case 2:
																													goto IL_05c9;
																												case 34:
																													goto IL_05d7;
																												case 58:
																													goto end_IL_0239;
																												case 80:
																												case 112:
																													goto IL_0601;
																												case 113:
																													goto IL_0619;
																												case 103:
																												case 105:
																													goto IL_0627;
																												case 87:
																													goto IL_0667;
																												case 28:
																													goto IL_067b;
																												case 114:
																													goto IL_068e;
																												case 16:
																													goto IL_069c;
																												case 119:
																													goto IL_06af;
																												case 53:
																												case 121:
																													goto IL_06c2;
																												case 128:
																													goto IL_06d0;
																												case 14:
																												case 55:
																													goto IL_06de;
																												case 17:
																													goto IL_0707;
																												case 6:
																													goto IL_0715;
																												case 61:
																													goto IL_0725;
																												case 27:
																													goto IL_0730;
																												case 86:
																												case 124:
																													goto IL_073b;
																												case 32:
																												case 81:
																													goto IL_074b;
																												case 0:
																												case 3:
																												case 15:
																												case 18:
																												case 24:
																												case 40:
																												case 43:
																												case 46:
																												case 60:
																												case 69:
																												case 72:
																												case 73:
																												case 74:
																												case 89:
																												case 93:
																												case 100:
																												case 104:
																												case 111:
																												case 116:
																												case 117:
																												case 122:
																												case 126:
																													goto end_IL_0289;
																												case 8:
																												case 21:
																												case 25:
																												case 26:
																												case 48:
																												case 59:
																												case 63:
																												case 64:
																												case 66:
																												case 68:
																												case 83:
																												case 88:
																												case 92:
																												case 115:
																												case 123:
																												case 127:
																													goto end_IL_02b9;
																												case 4:
																													goto end_IL_0780;
																												case 109:
																													goto end_IL_0793;
																												case 118:
																													goto end_IL_079d;
																												case 120:
																													goto end_IL_07a8;
																												case 97:
																												case 102:
																													goto end_IL_07c6;
																												case 47:
																													goto end_IL_07d6;
																												case 9:
																												case 23:
																													goto end_IL_07e6;
																												case 95:
																													goto end_IL_07f6;
																												case 96:
																													goto end_IL_0806;
																												case 1:
																												case 108:
																													goto IL_0821;
																												}
																												continue;
																											}
																											goto IL_0725;
																											IL_0730:
																											if (11 > b)
																											{
																												goto end_IL_0289;
																											}
																											goto IL_073b;
																											IL_073b:
																											num5--;
																											goto end_IL_02b9;
																											IL_0725:
																											if (11 < b)
																											{
																												goto end_IL_0289;
																											}
																											goto IL_0730;
																											continue;
																											end_IL_0239:
																											break;
																										}
																										break;
																									}
																									goto IL_074b;
																									IL_074b:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									num = 68;
																									goto end_IL_02b9;
																								}
																								break;
																							}
																							goto IL_068e;
																							IL_069c:
																							if (13 > b)
																							{
																							}
																							goto end_IL_0289;
																							IL_068e:
																							if (13 < b)
																							{
																								goto end_IL_0289;
																							}
																							goto IL_069c;
																						}
																						break;
																					}
																					goto IL_02d4;
																					IL_03b4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ImportParametersPush[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_03f3;
																					IL_02d4:
																					if (10 <= b)
																					{
																						goto IL_0397;
																					}
																					goto IL_040f;
																					IL_040f:
																					if (8 >= b)
																					{
																						goto IL_041a;
																					}
																					goto IL_042d;
																					IL_041a:
																					if (8 > b)
																					{
																						goto end_IL_0289;
																					}
																					goto IL_0531;
																					IL_0531:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0593;
																					IL_0593:
																					num5 -= 2;
																					goto end_IL_02b9;
																					IL_042d:
																					if (9 < b)
																					{
																						goto end_IL_0289;
																					}
																					num = 113;
																					goto IL_0619;
																					IL_03f3:
																					ptr2 += 8;
																					num = 92;
																					goto end_IL_02b9;
																					IL_0619:
																					if (9 > b)
																					{
																						goto end_IL_0289;
																					}
																					goto IL_0627;
																					IL_0627:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0667;
																					IL_0667:
																					array[num5 - 2] = 0;
																					goto IL_067b;
																					IL_067b:
																					num5--;
																					goto end_IL_02b9;
																					IL_0397:
																					array[num5 - 1] = 0;
																					num = 51;
																					goto IL_03b4;
																				}
																				goto IL_05e5;
																			}
																			goto IL_02c4;
																			IL_05e5:
																			ptr2 += 8;
																			num = 26;
																			goto end_IL_02b9;
																			IL_02c4:
																			if (7 > b)
																			{
																				goto IL_02e7;
																			}
																			goto IL_05a6;
																			IL_02e7:
																			if (3 < b)
																			{
																				goto IL_02f2;
																			}
																			goto IL_0310;
																			IL_02f2:
																			if (5 >= b)
																			{
																				goto IL_0300;
																			}
																			goto IL_04a5;
																			IL_0300:
																			if (5 > b)
																			{
																				goto IL_0320;
																			}
																			goto IL_0449;
																			IL_0449:
																			array[num5] = 0;
																			goto IL_0457;
																			IL_0457:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_047a;
																			IL_047a:
																			array2[num5] = null;
																			goto IL_0484;
																			IL_0484:
																			num5++;
																			goto IL_0492;
																			IL_0492:
																			ptr2 += 8;
																			goto end_IL_02b9;
																			IL_0320:
																			if (4 < b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_06af;
																			IL_06af:
																			if (4 <= b)
																			{
																				goto end_IL_02b9;
																			}
																			goto end_IL_0289;
																			IL_04a5:
																			if (6 < b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_04b3;
																			IL_04b3:
																			if (6 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_04c1;
																			IL_04c1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 57;
																			goto IL_050a;
																			IL_050a:
																			array[num5 - 2] = 0;
																			goto IL_051e;
																			IL_051e:
																			num5--;
																			goto end_IL_02b9;
																			IL_0310:
																			if (3 > b)
																			{
																				goto IL_0333;
																			}
																			goto IL_0601;
																			IL_0601:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02b9;
																			IL_0333:
																			if (1 >= b)
																			{
																				goto IL_0341;
																			}
																			goto IL_06c2;
																			IL_0341:
																			if (1 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_034f;
																			IL_034f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0368;
																			IL_0368:
																			array[num5] = 0;
																			goto IL_0376;
																			IL_0376:
																			num5++;
																			goto IL_0384;
																			IL_0384:
																			ptr2 += 8;
																			goto end_IL_02b9;
																			IL_06c2:
																			if (2 < b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_06d0;
																			IL_06d0:
																			if (2 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_06de;
																			IL_06de:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0707;
																			IL_0707:
																			ptr2 += 8;
																			goto IL_0715;
																			IL_0715:
																			num5--;
																			goto end_IL_02b9;
																			IL_05a6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05c9;
																			IL_05c9:
																			array[num5] = 0;
																			goto IL_05d7;
																			IL_05d7:
																			num5++;
																			goto IL_05e5;
																			continue;
																			end_IL_027c:
																			break;
																		}
																		continue;
																		end_IL_0289:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02b9;
																continue;
																end_IL_0299:
																break;
															}
															continue;
															end_IL_02a9:
															break;
														}
														continue;
														end_IL_02b9:
														break;
													}
													continue;
												}
												goto IL_0821;
												IL_0821:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0780:
												break;
											}
											continue;
											end_IL_0793:
											break;
										}
										continue;
										end_IL_079d:
										break;
									}
									continue;
									end_IL_07a8:
									break;
								}
								continue;
								end_IL_07c6:
								break;
							}
							continue;
							end_IL_07d6:
							break;
						}
						continue;
						end_IL_07e6:
						break;
					}
					continue;
					end_IL_07f6:
					break;
				}
				continue;
				end_IL_0806:
				break;
			}
		}
	}

	static Class164()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 14;
				while (true)
				{
					if (num == 14 || num != 995)
					{
						return;
					}
					switch (num)
					{
					case 2:
						goto end_IL_0041;
					case 3:
						goto end_IL_004e;
					case 0:
						return;
					case 1:
						return;
					case 4:
						return;
					case 5:
						return;
					case 6:
						return;
					case 7:
						return;
					}
					continue;
					end_IL_0041:
					break;
				}
				continue;
				end_IL_004e:
				break;
			}
		}
	}
}
