using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Visual Theme: Original", "Settings", "Theme for visual mods", false, 9, ModType.const_1, false)]
internal class Class140 : MonoBehaviour
{
	private static int int_0;

	private static string[] string_0;

	private static Color[] color_0;

	private static double double_0;

	private static bool bool_0;

	private static bool bool_1;

	private static double double_1;

	private static int int_1;

	private static int int_2;

	private static IntPtr[] LUNARETOROKUYOUgetCultureInfo;

	private static IntPtr[] CharGetStringArray;

	private static IntPtr[] ThreadTransferReceiveHandledCgtUn;

	private static IntPtr[] DecoderExceptionFallbackOnDeserialization;

	private static IntPtr[] FormatJapaneseFirstYearAsANumbergetXsdType;

	private static IntPtr[] RectArrayVARFLAGFRESTRICTED;

	private static IntPtr[] getExportablegetOut;

	private static IntPtr[] PaddingHelpersDispatchWrapperType;

	private static IntPtr[] IServiceProviderEncodingProvider;

	public unsafe static int CurrentIndex
	{
		get
		{
			int num = 41;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NoPrincipalPopipopi.getInLicenseFile);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															IL_0340:
															byte b = *ptr2;
															while (true)
															{
																IL_0330:
																ptr2++;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0300:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02f0:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02e0:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02d3:
																										if (10 < b)
																										{
																											while (11 >= b)
																											{
																												while (11 > b)
																												{
																													num = 160;
																													while (num != 160)
																													{
																														if (num != 1141)
																														{
																															goto IL_0594;
																														}
																														switch (num)
																														{
																														case 20:
																															goto IL_02b0;
																														case 15:
																														case 100:
																															goto IL_02c3;
																														case 109:
																														case 131:
																															goto IL_02d3;
																														case 153:
																															goto IL_02e0;
																														case 45:
																														case 76:
																															goto IL_02f0;
																														case 39:
																															goto IL_0300;
																														case 152:
																															goto IL_0310;
																														case 25:
																															goto IL_0320;
																														case 118:
																															goto IL_0330;
																														case 35:
																														case 138:
																															goto IL_0340;
																														case 97:
																															goto IL_034b;
																														case 8:
																														case 86:
																															goto IL_0359;
																														case 106:
																															goto IL_0367;
																														case 24:
																														case 116:
																															goto IL_0375;
																														case 57:
																															goto IL_03be;
																														case 103:
																															goto IL_03d2;
																														case 132:
																														case 145:
																															goto IL_03e5;
																														case 71:
																															goto IL_0447;
																														case 77:
																														case 137:
																															goto IL_045a;
																														case 133:
																															goto IL_0473;
																														case 33:
																															goto IL_0481;
																														case 30:
																															goto IL_048f;
																														case 108:
																															goto IL_04a2;
																														case 54:
																														case 139:
																															goto IL_04ad;
																														case 50:
																															goto IL_04bb;
																														case 0:
																														case 69:
																															goto IL_04c9;
																														case 105:
																															goto IL_04e5;
																														case 37:
																														case 60:
																															goto IL_04f0;
																														case 18:
																															goto IL_0509;
																														case 130:
																														case 148:
																															goto IL_0517;
																														case 122:
																														case 136:
																															goto IL_0538;
																														case 66:
																															goto IL_0565;
																														case 90:
																															goto IL_0573;
																														case 16:
																															goto IL_0581;
																														case 75:
																															goto IL_0594;
																														case 83:
																														case 142:
																															goto IL_059f;
																														case 102:
																															goto IL_05b2;
																														case 115:
																															goto IL_05c0;
																														case 7:
																														case 104:
																															goto IL_05cb;
																														case 65:
																															goto IL_05d9;
																														case 42:
																															goto IL_05fc;
																														case 135:
																															goto IL_0606;
																														case 134:
																															goto IL_0614;
																														case 112:
																															goto IL_0627;
																														case 6:
																														case 84:
																															goto IL_0632;
																														case 94:
																															goto IL_0640;
																														case 52:
																														case 111:
																															goto IL_064e;
																														case 29:
																															goto IL_0677;
																														case 26:
																															goto IL_0685;
																														case 5:
																															goto IL_0698;
																														case 36:
																														case 63:
																															goto IL_06a3;
																														case 27:
																															goto IL_06b1;
																														case 47:
																														case 51:
																															goto IL_06c4;
																														case 12:
																															goto IL_070d;
																														case 2:
																															goto IL_0721;
																														case 110:
																															goto IL_073d;
																														case 9:
																															goto IL_074b;
																														case 123:
																															goto IL_0759;
																														case 128:
																														case 151:
																															goto IL_0767;
																														case 88:
																															goto IL_07a7;
																														case 146:
																															goto IL_07bb;
																														case 114:
																															goto IL_07ce;
																														case 126:
																														case 144:
																															goto IL_07dc;
																														case 143:
																															goto IL_07ea;
																														case 31:
																														case 46:
																															goto IL_07f8;
																														case 117:
																															goto IL_0838;
																														case 93:
																															goto IL_084c;
																														case 74:
																														case 124:
																															goto IL_085f;
																														case 147:
																															goto IL_089f;
																														case 82:
																															goto IL_08b3;
																														case 1:
																														case 10:
																														case 11:
																														case 13:
																														case 19:
																														case 21:
																														case 22:
																														case 28:
																														case 32:
																														case 49:
																														case 53:
																														case 55:
																														case 59:
																														case 64:
																														case 67:
																														case 80:
																														case 89:
																														case 91:
																														case 92:
																														case 98:
																														case 99:
																														case 101:
																														case 107:
																														case 119:
																														case 129:
																														case 141:
																														case 149:
																														case 150:
																															goto end_IL_029d;
																														case 3:
																															goto IL_08e5;
																														case 96:
																															goto IL_08f3;
																														case 17:
																															goto IL_0901;
																														case 4:
																														case 14:
																														case 23:
																														case 34:
																														case 38:
																														case 44:
																														case 48:
																														case 56:
																														case 58:
																														case 61:
																														case 62:
																														case 72:
																														case 81:
																														case 85:
																														case 87:
																														case 121:
																														case 125:
																														case 140:
																															goto end_IL_02b0;
																														case 68:
																															goto end_IL_090f;
																														case 127:
																															goto end_IL_0922;
																														case 120:
																															goto end_IL_092c;
																														case 95:
																														case 113:
																															goto end_IL_0937;
																														case 79:
																															goto end_IL_0947;
																														case 43:
																															goto end_IL_0957;
																														case 73:
																															goto end_IL_0967;
																														case 40:
																															goto end_IL_0977;
																														case 41:
																															goto end_IL_0987;
																														case 70:
																														case 78:
																															goto IL_09a2;
																														}
																														continue;
																														end_IL_029d:
																														break;
																													}
																													goto end_IL_02c3;
																													continue;
																													end_IL_02b0:
																													break;
																													IL_02b0:;
																												}
																												goto end_IL_0320;
																												continue;
																												end_IL_02c3:
																												break;
																												IL_02c3:;
																											}
																											break;
																										}
																										goto IL_034b;
																										IL_0447:
																										num6 -= 2;
																										goto end_IL_0320;
																										IL_034b:
																										if (10 > b)
																										{
																											goto IL_0359;
																										}
																										goto IL_03e5;
																										IL_0359:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_0367;
																										IL_0367:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_0375;
																										IL_0375:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 57;
																										goto IL_03be;
																										IL_03be:
																										array[num6 - 2] = 0;
																										goto IL_03d2;
																										IL_03d2:
																										num6--;
																										goto end_IL_0320;
																										IL_03e5:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0447;
																									}
																									break;
																								}
																								goto IL_045a;
																								IL_048f:
																								ptr2 += 16;
																								goto end_IL_0320;
																								IL_045a:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0473;
																								IL_0473:
																								array[num6] = 1;
																								goto IL_0481;
																								IL_0481:
																								num6++;
																								goto IL_048f;
																							}
																							break;
																						}
																						goto IL_04a2;
																						IL_0573:
																						num6++;
																						goto IL_0581;
																						IL_04a2:
																						if (14 < b)
																						{
																							goto IL_04ad;
																						}
																						goto IL_04e5;
																						IL_04ad:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_04bb;
																						IL_04bb:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_04c9;
																						IL_04c9:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_0320;
																						IL_04e5:
																						if (14 > b)
																						{
																							goto IL_04f0;
																						}
																						goto IL_0538;
																						IL_04f0:
																						if (13 < b)
																						{
																							num = 55;
																							break;
																						}
																						goto IL_0509;
																						IL_0581:
																						ptr2 += 8;
																						goto end_IL_0320;
																						IL_0509:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_0517;
																						IL_0517:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						num = 4;
																						goto end_IL_0320;
																						IL_0538:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)LUNARETOROKUYOUgetCultureInfo[*(int*)(ptr2 + num3)])();
																						num = 66;
																						goto IL_0565;
																						IL_0565:
																						array[num6] = 0;
																						goto IL_0573;
																					}
																					break;
																				}
																				goto IL_0594;
																				IL_08b3:
																				num6--;
																				goto end_IL_0320;
																				IL_0594:
																				if (8 <= b)
																				{
																					goto IL_059f;
																				}
																				goto IL_05b2;
																				IL_059f:
																				num6--;
																				goto end_IL_0320;
																				IL_05b2:
																				if (4 >= b)
																				{
																					goto IL_05c0;
																				}
																				goto IL_073d;
																				IL_05c0:
																				if (4 <= b)
																				{
																					goto IL_05cb;
																				}
																				goto IL_0627;
																				IL_05cb:
																				array[num6] = 0;
																				goto IL_05d9;
																				IL_05d9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05fc;
																				IL_05fc:
																				array2[num6] = null;
																				goto IL_0606;
																				IL_0606:
																				num6++;
																				goto IL_0614;
																				IL_0614:
																				ptr2 += 8;
																				goto end_IL_0320;
																				IL_0627:
																				if (2 < b)
																				{
																					goto IL_0632;
																				}
																				goto IL_0698;
																				IL_0632:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0640;
																				IL_0640:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_064e;
																				IL_064e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0677;
																				IL_0677:
																				ptr2 += 8;
																				goto IL_0685;
																				IL_0685:
																				num6--;
																				goto end_IL_0320;
																				IL_0698:
																				if (2 > b)
																				{
																					goto IL_06a3;
																				}
																				goto IL_06c4;
																				IL_06a3:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_06b1;
																				IL_06b1:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_06c4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 12;
																				goto IL_070d;
																				IL_070d:
																				array[num6 - 2] = 0;
																				goto IL_0721;
																				IL_0721:
																				num6--;
																				num = 125;
																				goto end_IL_0320;
																				IL_073d:
																				if (6 < b)
																				{
																					goto IL_074b;
																				}
																				goto IL_07ce;
																				IL_074b:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0759;
																				IL_0759:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0767;
																				IL_0767:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_07a7;
																				IL_07a7:
																				array[num6 - 2] = 0;
																				goto IL_07bb;
																				IL_07bb:
																				num6--;
																				goto end_IL_0320;
																				IL_07ce:
																				if (6 > b)
																				{
																					goto IL_07dc;
																				}
																				goto IL_085f;
																				IL_07dc:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_07ea;
																				IL_07ea:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_07f8;
																				IL_07f8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0838;
																				IL_0838:
																				array[num6 - 2] = 0;
																				goto IL_084c;
																				IL_084c:
																				num6--;
																				goto end_IL_0320;
																				IL_085f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_089f;
																				IL_089f:
																				array[num6 - 2] = 0;
																				goto IL_08b3;
																			}
																			break;
																			IL_0310:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	num = 3;
																	goto IL_08e5;
																	IL_0901:
																	ptr2 += 8;
																	break;
																	IL_08f3:
																	num6++;
																	goto IL_0901;
																	IL_08e5:
																	array[num6] = 0;
																	goto IL_08f3;
																	continue;
																	end_IL_0320:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_09a2;
													IL_09a2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_090f:
													break;
												}
												continue;
												end_IL_0922:
												break;
											}
											continue;
											end_IL_092c:
											break;
										}
										continue;
										end_IL_0937:
										break;
									}
									continue;
									end_IL_0947:
									break;
								}
								continue;
								end_IL_0957:
								break;
							}
							continue;
							end_IL_0967:
							break;
						}
						continue;
						end_IL_0977:
						break;
					}
					continue;
					end_IL_0987:
					break;
				}
			}
		}
		set
		{
			int num = 8;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				num = 7;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											array3[0] = value;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaskGenerationMethodPopulateObjectMembers.IFormatProvidergetdefaultPermissionSetID);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_034f:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				if (9 < b)
																				{
																					while (true)
																					{
																						IL_031f:
																						if (13 >= b)
																						{
																							while (true)
																							{
																								IL_0312:
																								if (13 <= b)
																								{
																									while (true)
																									{
																										IL_02f7:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																										while (true)
																										{
																											IL_02de:
																											array[num6] = 1;
																											num = 175;
																											while (true)
																											{
																												if (num != 175)
																												{
																													if (num != 1156)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 126:
																														goto IL_02de;
																													case 124:
																													case 153:
																														goto IL_02f7;
																													case 130:
																														goto IL_0312;
																													case 54:
																													case 108:
																														goto IL_031f;
																													case 9:
																														goto end_IL_02cb;
																													case 109:
																														goto end_IL_032f;
																													case 49:
																														goto IL_034f;
																													case 62:
																														goto end_IL_034f;
																													case 80:
																													case 95:
																														goto end_IL_035f;
																													case 101:
																														goto IL_037a;
																													case 50:
																														goto IL_0385;
																													case 145:
																														goto IL_03a1;
																													case 15:
																													case 116:
																														goto IL_03ac;
																													case 19:
																														goto IL_03c5;
																													case 154:
																														goto IL_03d3;
																													case 38:
																													case 41:
																														goto IL_03e1;
																													case 113:
																														goto IL_0443;
																													case 159:
																														goto IL_0456;
																													case 128:
																														goto IL_04aa;
																													case 122:
																														goto IL_04b8;
																													case 165:
																														goto IL_04cb;
																													case 103:
																														goto IL_04f5;
																													case 83:
																														goto IL_0508;
																													case 42:
																														goto IL_0516;
																													case 66:
																													case 132:
																														goto IL_0521;
																													case 164:
																														goto IL_0544;
																													case 148:
																														goto IL_0552;
																													case 5:
																														goto IL_0560;
																													case 125:
																														goto IL_0573;
																													case 27:
																														goto IL_0581;
																													case 91:
																													case 150:
																														goto IL_058f;
																													case 141:
																														goto IL_05a7;
																													case 135:
																														goto IL_05b2;
																													case 40:
																													case 75:
																														goto IL_05bd;
																													case 168:
																														goto IL_05d7;
																													case 84:
																														goto IL_05f8;
																													case 120:
																														goto IL_0606;
																													case 0:
																													case 106:
																														goto IL_0614;
																													case 142:
																														goto IL_0630;
																													case 112:
																													case 131:
																														goto IL_063b;
																													case 105:
																														goto IL_067b;
																													case 156:
																														goto IL_068f;
																													case 78:
																														goto IL_06a2;
																													case 44:
																													case 76:
																														goto IL_06b0;
																													case 35:
																													case 155:
																														goto IL_06be;
																													case 86:
																														goto IL_06c9;
																													case 110:
																													case 115:
																														goto IL_06d7;
																													case 81:
																														goto IL_0717;
																													case 160:
																														goto IL_072b;
																													case 87:
																														goto IL_073e;
																													case 97:
																														goto IL_074c;
																													case 20:
																													case 68:
																														goto IL_075a;
																													case 45:
																														goto IL_076d;
																													case 55:
																													case 123:
																														goto IL_0778;
																													case 28:
																														goto IL_07b8;
																													case 22:
																														goto IL_07cc;
																													case 52:
																													case 158:
																														goto IL_07df;
																													case 31:
																														goto IL_07ed;
																													case 59:
																													case 157:
																														goto IL_0804;
																													case 33:
																														goto IL_0844;
																													case 23:
																														goto IL_0858;
																													case 107:
																														goto IL_086b;
																													case 3:
																													case 21:
																														goto IL_0879;
																													case 114:
																														goto IL_0887;
																													case 34:
																													case 151:
																														goto IL_0892;
																													case 77:
																														goto IL_08d2;
																													case 71:
																														goto IL_08e6;
																													case 140:
																														goto IL_08f9;
																													case 104:
																														goto IL_0907;
																													case 100:
																														goto IL_0923;
																													case 79:
																														goto IL_0931;
																													case 118:
																													case 133:
																														goto IL_0948;
																													case 13:
																														goto IL_0971;
																													case 4:
																														goto IL_097f;
																													case 92:
																													case 162:
																														goto IL_0992;
																													case 119:
																														goto IL_09a0;
																													case 2:
																														goto IL_09c3;
																													case 144:
																														goto IL_09cd;
																													case 143:
																														goto IL_09db;
																													case 1:
																													case 10:
																													case 14:
																													case 17:
																													case 18:
																													case 26:
																													case 29:
																													case 30:
																													case 36:
																													case 51:
																													case 53:
																													case 56:
																													case 57:
																													case 60:
																													case 65:
																													case 69:
																													case 70:
																													case 72:
																													case 74:
																													case 89:
																													case 90:
																													case 94:
																													case 98:
																													case 102:
																													case 117:
																													case 127:
																													case 134:
																													case 146:
																													case 147:
																													case 161:
																													case 163:
																													case 166:
																													case 167:
																														goto end_IL_033f;
																													case 149:
																														goto IL_0a04;
																													case 129:
																														goto IL_0a12;
																													case 46:
																														goto IL_0a20;
																													case 6:
																													case 11:
																													case 12:
																													case 16:
																													case 24:
																													case 32:
																													case 37:
																													case 43:
																													case 47:
																													case 61:
																													case 64:
																													case 67:
																													case 73:
																													case 82:
																													case 88:
																													case 99:
																													case 111:
																													case 137:
																													case 138:
																													case 152:
																														goto end_IL_036f;
																													case 48:
																														goto end_IL_0a2e;
																													case 58:
																														goto end_IL_0a41;
																													case 136:
																														goto end_IL_0a4b;
																													case 139:
																														goto end_IL_0a56;
																													case 39:
																													case 121:
																														goto end_IL_0a6b;
																													case 96:
																														goto end_IL_0a7b;
																													case 85:
																														goto end_IL_0a8b;
																													case 63:
																														goto end_IL_0a9b;
																													case 7:
																														goto end_IL_0aab;
																													case 8:
																														goto end_IL_0abb;
																													case 25:
																													case 93:
																														return;
																													}
																													continue;
																												}
																												num6++;
																												num = 103;
																												goto IL_04f5;
																												IL_04f5:
																												ptr2 += 16;
																												goto end_IL_036f;
																												continue;
																												end_IL_02cb:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_037a;
																								IL_03e1:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0443;
																								IL_037a:
																								if (11 < b)
																								{
																									goto IL_0385;
																								}
																								goto IL_03a1;
																								IL_0385:
																								if (12 < b)
																								{
																									num = 57;
																									goto end_IL_033f;
																								}
																								goto IL_04cb;
																								IL_0443:
																								num6 -= 2;
																								goto end_IL_036f;
																								IL_04cb:
																								if (12 <= b)
																								{
																									goto end_IL_036f;
																								}
																								goto end_IL_033f;
																								IL_03a1:
																								if (11 <= b)
																								{
																									goto IL_03ac;
																								}
																								goto IL_03c5;
																								IL_03ac:
																								array[num6 - 2] = 0;
																								goto IL_0456;
																								IL_0456:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)CharGetStringArray[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_04aa;
																								IL_04aa:
																								num6--;
																								goto IL_04b8;
																								IL_04b8:
																								ptr2 += 8;
																								goto end_IL_036f;
																								IL_03c5:
																								if (10 < b)
																								{
																									goto end_IL_033f;
																								}
																								goto IL_03d3;
																								IL_03d3:
																								if (10 > b)
																								{
																									goto end_IL_033f;
																								}
																								goto IL_03e1;
																							}
																							break;
																						}
																						goto IL_0508;
																						IL_0606:
																						if (17 > b)
																						{
																							goto end_IL_033f;
																						}
																						goto IL_0614;
																						IL_0508:
																						if (15 >= b)
																						{
																							goto IL_0516;
																						}
																						goto IL_05a7;
																						IL_0516:
																						if (15 <= b)
																						{
																							goto IL_0521;
																						}
																						goto IL_0573;
																						IL_0521:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0544;
																						IL_0544:
																						array[num6] = 0;
																						goto IL_0552;
																						IL_0552:
																						num6++;
																						goto IL_0560;
																						IL_0560:
																						ptr2 += 8;
																						goto end_IL_036f;
																						IL_0573:
																						if (14 < b)
																						{
																							goto end_IL_033f;
																						}
																						goto IL_0581;
																						IL_0581:
																						if (14 > b)
																						{
																							goto end_IL_033f;
																						}
																						goto IL_058f;
																						IL_058f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_036f;
																						IL_05a7:
																						if (16 >= b)
																						{
																							goto IL_05b2;
																						}
																						goto IL_05f8;
																						IL_05b2:
																						if (16 > b)
																						{
																							num = 29;
																							goto end_IL_033f;
																						}
																						goto IL_05bd;
																						IL_05bd:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_05d7;
																						IL_05d7:
																						num6--;
																						goto end_IL_036f;
																						IL_0614:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_036f;
																						IL_05f8:
																						if (17 < b)
																						{
																							goto end_IL_033f;
																						}
																						goto IL_0606;
																					}
																					continue;
																				}
																				goto IL_0630;
																				IL_09a0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_09c3;
																				IL_0630:
																				if (9 <= b)
																				{
																					goto IL_063b;
																				}
																				goto IL_06a2;
																				IL_063b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_067b;
																				IL_067b:
																				array[num6 - 2] = 0;
																				goto IL_068f;
																				IL_068f:
																				num6--;
																				goto end_IL_036f;
																				IL_06a2:
																				if (4 < b)
																				{
																					goto IL_06b0;
																				}
																				goto IL_086b;
																				IL_06b0:
																				if (6 < b)
																				{
																					goto IL_06be;
																				}
																				goto IL_076d;
																				IL_06be:
																				if (7 >= b)
																				{
																					goto IL_06c9;
																				}
																				goto IL_073e;
																				IL_06c9:
																				if (7 > b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_06d7;
																				IL_06d7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0717;
																				IL_0717:
																				array[num6 - 2] = 0;
																				goto IL_072b;
																				IL_072b:
																				num6--;
																				goto end_IL_036f;
																				IL_073e:
																				if (8 < b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_074c;
																				IL_074c:
																				if (8 > b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_075a;
																				IL_075a:
																				num6--;
																				goto end_IL_036f;
																				IL_076d:
																				if (6 <= b)
																				{
																					goto IL_0778;
																				}
																				goto IL_07df;
																				IL_0778:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_07b8;
																				IL_07b8:
																				array[num6 - 2] = 0;
																				goto IL_07cc;
																				IL_07cc:
																				num6--;
																				goto end_IL_036f;
																				IL_07df:
																				if (5 < b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_07ed;
																				IL_07ed:
																				if (5 > b)
																				{
																					goto end_IL_033f;
																				}
																				num = 157;
																				goto IL_0804;
																				IL_09c3:
																				array2[num6] = null;
																				goto IL_09cd;
																				IL_0804:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0844;
																				IL_0844:
																				array[num6 - 2] = 0;
																				goto IL_0858;
																				IL_0858:
																				num6--;
																				goto end_IL_036f;
																				IL_086b:
																				if (4 > b)
																				{
																					goto IL_0879;
																				}
																				goto IL_0992;
																				IL_0879:
																				if (2 >= b)
																				{
																					goto IL_0887;
																				}
																				goto IL_0923;
																				IL_0887:
																				if (2 <= b)
																				{
																					goto IL_0892;
																				}
																				goto IL_08f9;
																				IL_0892:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_08d2;
																				IL_08d2:
																				array[num6 - 2] = 0;
																				goto IL_08e6;
																				IL_08e6:
																				num6--;
																				goto end_IL_036f;
																				IL_08f9:
																				if (1 < b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_0907;
																				IL_0907:
																				if (1 <= b)
																				{
																					num = 146;
																				}
																				goto end_IL_033f;
																				IL_09cd:
																				num6++;
																				goto IL_09db;
																				IL_0923:
																				if (3 < b)
																				{
																					goto end_IL_033f;
																				}
																				goto IL_0931;
																				IL_0931:
																				if (3 > b)
																				{
																					goto end_IL_033f;
																				}
																				num = 118;
																				goto IL_0948;
																				IL_09db:
																				ptr2 += 8;
																				goto end_IL_036f;
																				IL_0948:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0971;
																				IL_0971:
																				ptr2 += 8;
																				goto IL_097f;
																				IL_097f:
																				num6--;
																				goto end_IL_036f;
																				IL_0992:
																				array[num6] = 0;
																				goto IL_09a0;
																				continue;
																				end_IL_032f:
																				break;
																			}
																			continue;
																			end_IL_033f:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0a04;
																	IL_0a20:
																	ptr2 += 8;
																	goto end_IL_036f;
																	IL_0a12:
																	num6++;
																	goto IL_0a20;
																	IL_0a04:
																	array[num6] = 0;
																	goto IL_0a12;
																	continue;
																	end_IL_034f:
																	break;
																}
																continue;
																end_IL_035f:
																break;
															}
															continue;
															end_IL_036f:
															break;
														}
														continue;
														end_IL_0a2e:
														break;
													}
													continue;
													end_IL_0a41:
													break;
												}
												continue;
												end_IL_0a4b:
												break;
											}
											continue;
											end_IL_0a56:
											break;
										}
										continue;
										end_IL_0a6b:
										break;
									}
									continue;
									end_IL_0a7b:
									break;
								}
								continue;
								end_IL_0a8b:
								break;
							}
							continue;
							end_IL_0a9b:
							break;
						}
						continue;
						end_IL_0aab:
						break;
					}
					continue;
					end_IL_0abb:
					break;
				}
			}
		}
	}

	public unsafe static string CurrentTheme
	{
		get
		{
			int num = 164;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									num = 131;
									while (true)
									{
										int[] array3 = new int[6];
										while (true)
										{
											long[] array4 = new long[3];
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddAuditRuleComparison.setFormatgetKeyHandle);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		if (b >= 1)
																		{
																			while (true)
																			{
																				if (b <= 17)
																				{
																					while (true)
																					{
																						if (9 >= b)
																						{
																							while (true)
																							{
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0304:
																										if (4 < b)
																										{
																											while (true)
																											{
																												IL_02f4:
																												if (6 >= b)
																												{
																													while (true)
																													{
																														IL_02e4:
																														if (6 <= b)
																														{
																															num = 173;
																															while (true)
																															{
																																if (num != 173)
																																{
																																	if (num != 1154)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 29:
																																		goto IL_02e4;
																																	case 13:
																																		goto IL_02f4;
																																	case 26:
																																		goto IL_0304;
																																	case 4:
																																		goto end_IL_0304;
																																	case 42:
																																		goto end_IL_0311;
																																	case 107:
																																		goto end_IL_0321;
																																	case 144:
																																		goto end_IL_0331;
																																	case 32:
																																		goto end_IL_0341;
																																	case 82:
																																	case 123:
																																		goto end_IL_0351;
																																	case 8:
																																		goto IL_036c;
																																	case 35:
																																		goto IL_037c;
																																	case 49:
																																		goto IL_038c;
																																	case 67:
																																	case 74:
																																		goto IL_039a;
																																	case 22:
																																		goto IL_03da;
																																	case 111:
																																		goto IL_03f3;
																																	case 125:
																																		goto end_IL_02d1;
																																	case 52:
																																	case 97:
																																		goto IL_040c;
																																	case 69:
																																		goto IL_0423;
																																	case 25:
																																	case 133:
																																		goto IL_0436;
																																	case 58:
																																		goto IL_0476;
																																	case 109:
																																		goto IL_048a;
																																	case 61:
																																	case 142:
																																		goto IL_04a6;
																																	case 1:
																																		goto IL_04b4;
																																	case 14:
																																	case 129:
																																		goto IL_04bf;
																																	case 40:
																																	case 110:
																																		goto IL_04e0;
																																	case 38:
																																		goto IL_04ee;
																																	case 39:
																																	case 79:
																																		goto IL_04fc;
																																	case 0:
																																		goto IL_050a;
																																	case 54:
																																	case 63:
																																		goto IL_0518;
																																	case 17:
																																		goto IL_057a;
																																	case 21:
																																	case 121:
																																		goto IL_058d;
																																	case 62:
																																		goto IL_059b;
																																	case 10:
																																	case 145:
																																		goto IL_05ae;
																																	case 149:
																																		goto IL_05be;
																																	case 65:
																																		goto IL_05cc;
																																	case 46:
																																	case 147:
																																		goto IL_05da;
																																	case 96:
																																		goto IL_0603;
																																	case 89:
																																		goto IL_0611;
																																	case 151:
																																		goto IL_0624;
																																	case 72:
																																		goto IL_0632;
																																	case 47:
																																		goto IL_0640;
																																	case 18:
																																	case 150:
																																		goto IL_064e;
																																	case 148:
																																	case 153:
																																		goto IL_067a;
																																	case 31:
																																		goto IL_0688;
																																	case 120:
																																		goto IL_06ab;
																																	case 50:
																																		goto IL_06b5;
																																	case 100:
																																		goto IL_06cc;
																																	case 119:
																																	case 154:
																																		goto IL_06df;
																																	case 122:
																																		goto IL_06ea;
																																	case 6:
																																	case 93:
																																		goto IL_06f8;
																																	case 88:
																																		goto IL_0731;
																																	case 138:
																																		goto IL_0745;
																																	case 15:
																																		goto IL_0758;
																																	case 5:
																																		goto IL_0766;
																																	case 11:
																																	case 33:
																																		goto IL_077f;
																																	case 80:
																																	case 156:
																																		goto IL_079b;
																																	case 157:
																																		goto IL_07b4;
																																	case 104:
																																		goto IL_07c2;
																																	case 66:
																																		goto IL_07d0;
																																	case 161:
																																		goto IL_07e3;
																																	case 137:
																																		goto IL_07f1;
																																	case 83:
																																		goto IL_07ff;
																																	case 12:
																																	case 162:
																																		goto IL_0812;
																																	case 56:
																																		goto IL_0852;
																																	case 108:
																																		goto IL_086f;
																																	case 140:
																																	case 165:
																																		goto IL_0882;
																																	case 53:
																																		goto IL_08a6;
																																	case 92:
																																		goto IL_08b4;
																																	case 20:
																																		goto IL_08c2;
																																	case 166:
																																		goto IL_08d5;
																																	case 45:
																																		goto IL_08e8;
																																	case 75:
																																		goto IL_0928;
																																	case 78:
																																		goto IL_093c;
																																	case 146:
																																		goto IL_0958;
																																	case 90:
																																	case 116:
																																		goto IL_0963;
																																	case 117:
																																		goto IL_097a;
																																	case 81:
																																	case 135:
																																		goto IL_0988;
																																	case 159:
																																		goto IL_099b;
																																	case 84:
																																	case 130:
																																		goto IL_09a6;
																																	case 3:
																																		goto IL_09e6;
																																	case 95:
																																		goto IL_09fa;
																																	case 9:
																																	case 16:
																																	case 19:
																																	case 23:
																																	case 24:
																																	case 28:
																																	case 30:
																																	case 34:
																																	case 36:
																																	case 37:
																																	case 43:
																																	case 44:
																																	case 59:
																																	case 60:
																																	case 70:
																																	case 71:
																																	case 73:
																																	case 76:
																																	case 99:
																																	case 103:
																																	case 105:
																																	case 113:
																																	case 114:
																																	case 115:
																																	case 118:
																																	case 136:
																																	case 141:
																																	case 143:
																																		goto IL_0a13;
																																	case 139:
																																		goto IL_0a2c;
																																	case 7:
																																		goto IL_0a3a;
																																	case 94:
																																		goto IL_0a48;
																																	case 2:
																																	case 27:
																																	case 41:
																																	case 48:
																																	case 51:
																																	case 55:
																																	case 57:
																																	case 77:
																																	case 85:
																																	case 91:
																																	case 98:
																																	case 101:
																																	case 112:
																																	case 124:
																																	case 128:
																																	case 132:
																																	case 134:
																																	case 152:
																																	case 155:
																																	case 158:
																																		goto end_IL_0361;
																																	case 160:
																																		goto end_IL_0a56;
																																	case 127:
																																		goto end_IL_0a69;
																																	case 68:
																																		goto end_IL_0a73;
																																	case 131:
																																		goto end_IL_0a7e;
																																	case 126:
																																		goto end_IL_0a8e;
																																	case 64:
																																		goto end_IL_0a9e;
																																	case 87:
																																		goto end_IL_0aa9;
																																	case 106:
																																		goto end_IL_0ab9;
																																	case 163:
																																		goto end_IL_0ac9;
																																	case 164:
																																		goto end_IL_0ad9;
																																	case 86:
																																	case 102:
																																		goto IL_0af4;
																																	}
																																	continue;
																																}
																																goto IL_08e8;
																																IL_0928:
																																array[num6 - 2] = 0;
																																goto IL_093c;
																																IL_093c:
																																num6--;
																																num = 124;
																																goto end_IL_0361;
																																IL_08e8:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																goto IL_0928;
																																continue;
																																end_IL_02d1:
																																break;
																															}
																															break;
																														}
																														goto IL_036c;
																														IL_03da:
																														array[num6 - 2] = 0;
																														goto IL_08d5;
																														IL_08d5:
																														num6--;
																														goto end_IL_0361;
																														IL_036c:
																														if (5 >= b)
																														{
																															goto IL_038c;
																														}
																														goto IL_0a13;
																														IL_038c:
																														if (5 <= b)
																														{
																															goto IL_039a;
																														}
																														goto IL_0a13;
																														IL_039a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_03da;
																													}
																													break;
																												}
																												goto IL_0958;
																												IL_09e6:
																												array[num6 - 2] = 0;
																												goto IL_09fa;
																												IL_0958:
																												if (7 < b)
																												{
																													goto IL_0963;
																												}
																												goto IL_099b;
																												IL_0963:
																												if (8 >= b)
																												{
																													num = 117;
																													goto IL_097a;
																												}
																												goto IL_0a13;
																												IL_09fa:
																												num6--;
																												goto end_IL_0361;
																												IL_097a:
																												if (8 <= b)
																												{
																													goto IL_0988;
																												}
																												goto IL_0a13;
																												IL_0988:
																												num6--;
																												goto end_IL_0361;
																												IL_099b:
																												if (7 <= b)
																												{
																													goto IL_09a6;
																												}
																												goto IL_0a13;
																												IL_09a6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_09e6;
																											}
																											goto IL_0401;
																										}
																										goto IL_037c;
																										IL_06b5:
																										num6++;
																										num = 100;
																										goto IL_06cc;
																										IL_037c:
																										if (4 > b)
																										{
																											goto IL_03f3;
																										}
																										goto IL_067a;
																										IL_03f3:
																										if (2 >= b)
																										{
																											goto IL_0401;
																										}
																										goto IL_05be;
																										IL_0401:
																										if (2 > b)
																										{
																											goto IL_040c;
																										}
																										goto IL_0436;
																										IL_040c:
																										if (1 >= b)
																										{
																											num = 69;
																											goto IL_0423;
																										}
																										goto IL_0a13;
																										IL_06cc:
																										ptr2 += 8;
																										goto end_IL_0361;
																										IL_0423:
																										if (1 <= b)
																										{
																										}
																										goto IL_0a13;
																										IL_0436:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0476;
																										IL_0476:
																										array[num6 - 2] = 0;
																										goto IL_048a;
																										IL_048a:
																										num6--;
																										num = 152;
																										goto end_IL_0361;
																										IL_05be:
																										if (3 >= b)
																										{
																											goto IL_05cc;
																										}
																										goto IL_0a13;
																										IL_05cc:
																										if (3 <= b)
																										{
																											goto IL_05da;
																										}
																										goto IL_0a13;
																										IL_05da:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0603;
																										IL_0603:
																										ptr2 += 8;
																										goto IL_0611;
																										IL_0611:
																										num6--;
																										goto end_IL_0361;
																										IL_067a:
																										array[num6] = 0;
																										goto IL_0688;
																										IL_0688:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_06ab;
																										IL_06ab:
																										array2[num6] = null;
																										goto IL_06b5;
																										continue;
																										end_IL_0304:
																										break;
																									}
																									continue;
																								}
																								goto IL_0812;
																								IL_086f:
																								num6--;
																								goto end_IL_0361;
																								IL_0812:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0852;
																								IL_0852:
																								array[num6 - 2] = 0;
																								num = 108;
																								goto IL_086f;
																								continue;
																								end_IL_0311:
																								break;
																							}
																							continue;
																						}
																						goto IL_04a6;
																						IL_08a6:
																						array[num6] = 0;
																						goto IL_08b4;
																						IL_04a6:
																						if (13 >= b)
																						{
																							goto IL_04b4;
																						}
																						goto IL_05ae;
																						IL_04b4:
																						if (13 <= b)
																						{
																							goto IL_04bf;
																						}
																						num = 110;
																						goto IL_04e0;
																						IL_04bf:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0361;
																						IL_08b4:
																						num6++;
																						goto IL_08c2;
																						IL_04e0:
																						if (11 >= b)
																						{
																							goto IL_04ee;
																						}
																						goto IL_058d;
																						IL_04ee:
																						if (11 <= b)
																						{
																							goto end_IL_0361;
																						}
																						goto IL_04fc;
																						IL_04fc:
																						if (10 >= b)
																						{
																							goto IL_050a;
																						}
																						goto IL_0a13;
																						IL_050a:
																						if (10 <= b)
																						{
																							goto IL_0518;
																						}
																						goto IL_0a13;
																						IL_0518:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_057a;
																						IL_057a:
																						num6 -= 2;
																						goto end_IL_0361;
																						IL_058d:
																						if (12 >= b)
																						{
																							goto IL_059b;
																						}
																						goto IL_0a13;
																						IL_059b:
																						if (12 <= b)
																						{
																							goto IL_079b;
																						}
																						goto IL_0a13;
																						IL_079b:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_07b4;
																						IL_07b4:
																						array[num6] = 1;
																						goto IL_07c2;
																						IL_07c2:
																						num6++;
																						goto IL_07d0;
																						IL_07d0:
																						ptr2 += 16;
																						goto end_IL_0361;
																						IL_05ae:
																						if (15 >= b)
																						{
																							goto IL_0624;
																						}
																						goto IL_06df;
																						IL_06df:
																						if (16 >= b)
																						{
																							goto IL_06ea;
																						}
																						goto IL_0758;
																						IL_06ea:
																						if (16 <= b)
																						{
																							goto IL_06f8;
																						}
																						goto IL_0a13;
																						IL_06f8:
																						array2[num6 - 2] = ((string[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																						goto IL_0731;
																						IL_0731:
																						array[num6 - 2] = 5;
																						goto IL_0745;
																						IL_0745:
																						num6--;
																						goto end_IL_0361;
																						IL_0758:
																						if (17 >= b)
																						{
																							goto IL_0766;
																						}
																						goto IL_0a13;
																						IL_0766:
																						if (17 <= b)
																						{
																							goto IL_077f;
																						}
																						num = 103;
																						goto IL_0a13;
																						IL_08c2:
																						ptr2 += 8;
																						goto end_IL_0361;
																						IL_077f:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_0361;
																						IL_0624:
																						if (15 > b)
																						{
																							goto IL_0632;
																						}
																						goto IL_0882;
																						IL_0632:
																						if (14 >= b)
																						{
																							goto IL_0640;
																						}
																						goto IL_0a13;
																						IL_0640:
																						if (14 <= b)
																						{
																							goto IL_064e;
																						}
																						goto IL_0a13;
																						IL_064e:
																						array2[num6] = ((delegate*<string[]>)RectArrayVARFLAGFRESTRICTED[*(int*)(ptr2 + num3)])();
																						num = 161;
																						goto IL_07e3;
																						IL_07e3:
																						array[num6] = 5;
																						goto IL_07f1;
																						IL_07f1:
																						num6++;
																						goto IL_07ff;
																						IL_07ff:
																						ptr2 += 8;
																						goto end_IL_0361;
																						IL_0882:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)RectArrayVARFLAGFRESTRICTED[*(int*)(ptr2 + num3)])();
																						goto IL_08a6;
																						continue;
																						end_IL_0321:
																						break;
																					}
																					continue;
																				}
																				num = 118;
																				goto IL_0a13;
																				continue;
																				end_IL_0331:
																				break;
																			}
																			continue;
																		}
																		goto IL_0a13;
																		IL_0a48:
																		ptr2 += 8;
																		goto end_IL_0361;
																		IL_0a13:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a2c;
																		IL_0a2c:
																		array[num6] = 0;
																		goto IL_0a3a;
																		IL_0a3a:
																		num6++;
																		goto IL_0a48;
																		continue;
																		end_IL_0341:
																		break;
																	}
																	continue;
																	end_IL_0351:
																	break;
																}
																continue;
																end_IL_0361:
																break;
															}
															continue;
														}
														goto IL_0af4;
														IL_0af4:
														return (string)array2[num6 - 1];
														continue;
														end_IL_0a56:
														break;
													}
													continue;
													end_IL_0a69:
													break;
												}
												continue;
												end_IL_0a73:
												break;
											}
											continue;
											end_IL_0a7e:
											break;
										}
										continue;
										end_IL_0a8e:
										break;
									}
									continue;
									end_IL_0a9e:
									break;
								}
								continue;
								end_IL_0aa9:
								break;
							}
							continue;
							end_IL_0ab9:
							break;
						}
						continue;
						end_IL_0ac9:
						break;
					}
					continue;
					end_IL_0ad9:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_04bd, IL_04d0, IL_051b, IL_052b, IL_053e, IL_054e, IL_055e, IL_056e, IL_057b, IL_058b, IL_059b, IL_05ab, IL_05bb, IL_05cb, IL_05db, IL_05e6, IL_05f4, IL_0639, IL_064c, IL_065f, IL_0688, IL_0696, IL_06a9, IL_06bc, IL_06c7, IL_06d2, IL_06e0, IL_06ee, IL_0701, IL_0746, IL_0754, IL_075f, IL_079f, IL_07b8, IL_07c6, IL_07d1, IL_07df, IL_07ed, IL_07fb, IL_0809, IL_081c, IL_082a, IL_0838, IL_084b, IL_085e, IL_0869, IL_087d, IL_08bc, IL_08cf, IL_08da, IL_08ed, IL_08fb, IL_0909, IL_0917, IL_093a, IL_0944, IL_0952, IL_0965, IL_0973, IL_099e, IL_09b7, IL_09d3, IL_09e1, IL_09ec, IL_09fa, IL_0a0d, IL_0a2a, IL_0a79, IL_0a83, IL_0ab0, IL_0ac9, IL_0b09, IL_0b1d, IL_0b30, IL_0b3e, IL_0b4c, IL_0b61, IL_0b74, IL_0b8b, IL_0ba7, IL_0bb5, IL_0bc3, IL_0bd6, IL_0c38, IL_0c4b, IL_0c59, IL_0c67, IL_0c72, IL_0c80, IL_0c89, IL_0c97, IL_0cd5, IL_0ce8, IL_0cf3, IL_0d06, IL_0d14, IL_0d35, IL_0d43, IL_0d56, IL_0d73, IL_0dab, IL_0dbe, IL_0dc9, IL_0dd7, IL_0df5, IL_0e03, IL_0e11, IL_0e24, IL_0e32, IL_0e40, IL_0e6a, IL_0e83, IL_0e91, IL_0e9f, IL_0ebd, IL_0ecb, IL_0ede, IL_0ef8, IL_0f0b, IL_0f44, IL_0f58, IL_0f74, IL_0f82, IL_0f90, IL_0f9e, IL_0fb2, IL_0ffe, IL_100c, IL_101f, IL_1048, IL_1056, IL_1069, IL_1077, IL_1085, IL_10a9, IL_10b7, IL_10c5, IL_10d8, IL_1118, IL_112c, IL_113f, IL_1153, IL_116f, IL_117d, IL_1195, IL_11b3, IL_11d7, IL_11ef, IL_1202, IL_1216, IL_1229, IL_1246, IL_1259, IL_1282, IL_1298, IL_12a1, IL_12ba, IL_12c8, IL_12d6, IL_12e4, IL_12f7, IL_1301, IL_130c, IL_131c, IL_132c, IL_1345, IL_1355, IL_1365, IL_1375, IL_1385 are reachable both inside and outside the pinned region starting at IL_139a. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef57 = default(int);
			ref int reference = ref __rxRef57;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1385:
					num2 = 1;
					while (true)
					{
						IL_1375:
						num3 = num2 * 4;
						while (true)
						{
							IL_1365:
							array2 = new byte[4];
							while (true)
							{
								IL_1355:
								array3 = new object[4];
								while (true)
								{
									IL_1345:
									array4 = new int[4];
									while (true)
									{
										IL_132c:
										array5 = new int[6];
										num = 4;
										while (true)
										{
											IL_131c:
											array6 = new long[4];
											while (true)
											{
												IL_130c:
												array7 = new object[13];
												while (true)
												{
													IL_1301:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefineByValTStrEventActivityOptions.defineByValTStrEventActivityOptions_0);
													while (true)
													{
														IL_12f7:
														ptr2 = ptr;
														while (true)
														{
															IL_12e4:
															if (num4 == 1)
															{
																return;
															}
															while (true)
															{
																IL_05db:
																byte b = *ptr2;
																while (true)
																{
																	IL_05cb:
																	ptr2++;
																	while (true)
																	{
																		IL_05bb:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_05ab:
																				if (b <= 30)
																				{
																					while (true)
																					{
																						IL_059b:
																						if (15 >= b)
																						{
																							while (true)
																							{
																								IL_058b:
																								if (15 > b)
																								{
																									while (true)
																									{
																										IL_057b:
																										if (7 >= b)
																										{
																											while (true)
																											{
																												IL_056e:
																												if (7 > b)
																												{
																													while (true)
																													{
																														IL_055e:
																														if (3 >= b)
																														{
																															while (true)
																															{
																																IL_054e:
																																if (3 > b)
																																{
																																	while (true)
																																	{
																																		IL_053e:
																																		if (1 < b)
																																		{
																																			while (2 >= b)
																																			{
																																				num = 54;
																																				while (true)
																																				{
																																					IL_051b:
																																					if (2 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_04d0:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																							num = 296;
																																							while (true)
																																							{
																																								if (num != 296)
																																								{
																																									if (num != 1277)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 77:
																																										break;
																																									default:
																																										continue;
																																									case 118:
																																									case 203:
																																										goto IL_04d0;
																																									case 54:
																																										goto IL_051b;
																																									case 13:
																																										goto IL_052b;
																																									case 36:
																																										goto IL_053e;
																																									case 114:
																																										goto IL_054e;
																																									case 29:
																																										goto IL_055e;
																																									case 102:
																																										goto IL_056e;
																																									case 56:
																																									case 233:
																																										goto IL_057b;
																																									case 171:
																																										goto IL_058b;
																																									case 162:
																																										goto IL_059b;
																																									case 226:
																																										goto IL_05ab;
																																									case 181:
																																										goto IL_05bb;
																																									case 272:
																																										goto IL_05cb;
																																									case 44:
																																									case 80:
																																										goto IL_05db;
																																									case 5:
																																									case 34:
																																										goto end_IL_04bd;
																																									case 27:
																																									case 131:
																																										goto IL_0639;
																																									case 12:
																																									case 133:
																																										goto IL_064c;
																																									case 3:
																																									case 151:
																																										goto IL_065f;
																																									case 70:
																																										goto IL_0688;
																																									case 134:
																																										goto IL_0696;
																																									case 176:
																																										goto IL_06a9;
																																									case 109:
																																									case 212:
																																										goto IL_06bc;
																																									case 78:
																																										goto IL_06c7;
																																									case 164:
																																										goto IL_06d2;
																																									case 71:
																																										goto IL_06e0;
																																									case 40:
																																									case 113:
																																										goto IL_06ee;
																																									case 103:
																																									case 211:
																																										goto IL_0701;
																																									case 8:
																																										goto IL_0746;
																																									case 91:
																																										goto IL_0754;
																																									case 105:
																																									case 150:
																																										goto IL_075f;
																																									case 123:
																																										goto IL_079f;
																																									case 182:
																																									case 217:
																																										goto IL_07c6;
																																									case 63:
																																										goto IL_07d1;
																																									case 85:
																																									case 92:
																																										goto IL_07df;
																																									case 45:
																																										goto IL_07ed;
																																									case 157:
																																									case 210:
																																										goto IL_07fb;
																																									case 1:
																																										goto IL_0809;
																																									case 167:
																																										goto IL_081c;
																																									case 67:
																																									case 116:
																																										goto IL_082a;
																																									case 216:
																																										goto IL_0838;
																																									case 218:
																																										goto IL_084b;
																																									case 222:
																																										goto IL_085e;
																																									case 156:
																																									case 163:
																																										goto IL_0869;
																																									case 6:
																																										goto IL_087d;
																																									case 209:
																																										goto IL_08bc;
																																									case 37:
																																									case 225:
																																										goto IL_08cf;
																																									case 127:
																																										goto IL_08da;
																																									case 160:
																																										goto IL_08ed;
																																									case 168:
																																										goto IL_08fb;
																																									case 234:
																																										goto IL_0917;
																																									case 7:
																																										goto IL_093a;
																																									case 58:
																																										goto IL_0944;
																																									case 94:
																																										goto IL_0952;
																																									case 239:
																																										goto IL_0965;
																																									case 21:
																																									case 59:
																																										goto IL_0973;
																																									case 60:
																																										goto IL_099e;
																																									case 235:
																																									case 241:
																																										goto IL_09b7;
																																									case 101:
																																									case 243:
																																										goto IL_09d3;
																																									case 170:
																																										goto IL_09e1;
																																									case 83:
																																									case 186:
																																										goto IL_09ec;
																																									case 72:
																																										goto IL_09fa;
																																									case 178:
																																									case 236:
																																										goto IL_0a0d;
																																									case 125:
																																									case 246:
																																										goto IL_0ac9;
																																									case 220:
																																										goto IL_0b09;
																																									case 198:
																																										goto IL_0b1d;
																																									case 221:
																																									case 253:
																																										goto IL_0b30;
																																									case 142:
																																										goto IL_0b3e;
																																									case 23:
																																									case 33:
																																										goto IL_0b4c;
																																									case 53:
																																										goto IL_0b61;
																																									case 255:
																																										goto IL_0b74;
																																									case 227:
																																										goto IL_0b8b;
																																									case 260:
																																										goto IL_0ba7;
																																									case 228:
																																										goto IL_0bb5;
																																									case 31:
																																									case 250:
																																										goto IL_0bc3;
																																									case 79:
																																									case 263:
																																										goto IL_0bd6;
																																									case 174:
																																										goto IL_0c38;
																																									case 18:
																																									case 265:
																																										goto IL_0c4b;
																																									case 249:
																																										goto IL_0c59;
																																									case 191:
																																										goto IL_0c67;
																																									case 75:
																																									case 187:
																																										goto IL_0c72;
																																									case 126:
																																										goto IL_0c89;
																																									case 208:
																																									case 247:
																																										goto IL_0c97;
																																									case 248:
																																										goto IL_0cd5;
																																									case 144:
																																										goto IL_0ce8;
																																									case 119:
																																									case 213:
																																										goto IL_0cf3;
																																									case 86:
																																									case 124:
																																										goto IL_0d06;
																																									case 128:
																																										goto IL_0d14;
																																									case 74:
																																										goto IL_0d35;
																																									case 55:
																																										goto IL_0d43;
																																									case 132:
																																									case 137:
																																										goto IL_0d56;
																																									case 245:
																																										goto IL_0d73;
																																									case 88:
																																										goto IL_0dab;
																																									case 251:
																																										goto IL_0dbe;
																																									case 143:
																																										goto IL_0dc9;
																																									case 19:
																																									case 230:
																																										goto IL_0dd7;
																																									case 180:
																																										goto IL_0df5;
																																									case 244:
																																										goto IL_0e03;
																																									case 214:
																																										goto IL_0e11;
																																									case 219:
																																										goto IL_0e24;
																																									case 193:
																																										goto IL_0e32;
																																									case 107:
																																									case 139:
																																										goto IL_0e40;
																																									case 258:
																																										goto IL_0e6a;
																																									case 232:
																																									case 267:
																																										goto IL_0e83;
																																									case 197:
																																										goto IL_0e91;
																																									case 192:
																																									case 261:
																																										goto IL_0e9f;
																																									case 148:
																																										goto IL_0ebd;
																																									case 38:
																																										goto IL_0ecb;
																																									case 28:
																																									case 271:
																																										goto IL_0ede;
																																									case 15:
																																										goto IL_0ef8;
																																									case 238:
																																									case 278:
																																										goto IL_0f0b;
																																									case 51:
																																										goto IL_0f44;
																																									case 154:
																																										goto IL_0f58;
																																									case 282:
																																										goto IL_0f74;
																																									case 32:
																																									case 93:
																																										goto IL_0f82;
																																									case 112:
																																										goto IL_0f90;
																																									case 122:
																																									case 177:
																																										goto IL_0f9e;
																																									case 66:
																																										goto IL_0fb2;
																																									case 184:
																																										goto IL_0ffe;
																																									case 155:
																																										goto IL_100c;
																																									case 269:
																																									case 276:
																																										goto IL_101f;
																																									case 202:
																																										goto IL_1048;
																																									case 199:
																																										goto IL_1056;
																																									case 283:
																																										goto IL_1069;
																																									case 24:
																																										goto IL_1077;
																																									case 26:
																																									case 270:
																																										goto IL_1085;
																																									case 9:
																																										goto IL_10a9;
																																									case 190:
																																										goto IL_10b7;
																																									case 120:
																																										goto IL_10c5;
																																									case 277:
																																									case 284:
																																										goto IL_10d8;
																																									case 140:
																																										goto IL_1118;
																																									case 25:
																																										goto IL_112c;
																																									case 286:
																																										goto IL_113f;
																																									case 62:
																																										goto IL_1153;
																																									case 287:
																																										goto IL_116f;
																																									case 16:
																																									case 98:
																																										goto IL_117d;
																																									case 17:
																																										goto IL_1195;
																																									case 224:
																																										goto IL_11b3;
																																									case 22:
																																										goto IL_11d7;
																																									case 69:
																																										goto IL_11ef;
																																									case 289:
																																										goto IL_1202;
																																									case 129:
																																										goto IL_1216;
																																									case 149:
																																										goto IL_1246;
																																									case 136:
																																									case 194:
																																										goto IL_1259;
																																									case 65:
																																										goto IL_1282;
																																									case 0:
																																									case 2:
																																									case 10:
																																									case 30:
																																									case 35:
																																									case 43:
																																									case 46:
																																									case 49:
																																									case 50:
																																									case 52:
																																									case 57:
																																									case 87:
																																									case 89:
																																									case 96:
																																									case 100:
																																									case 104:
																																									case 106:
																																									case 117:
																																									case 121:
																																									case 130:
																																									case 138:
																																									case 146:
																																									case 152:
																																									case 158:
																																									case 159:
																																									case 166:
																																									case 169:
																																									case 179:
																																									case 183:
																																									case 185:
																																									case 188:
																																									case 195:
																																									case 200:
																																									case 201:
																																									case 206:
																																									case 207:
																																									case 223:
																																									case 229:
																																									case 240:
																																									case 252:
																																									case 254:
																																									case 257:
																																									case 264:
																																									case 266:
																																									case 268:
																																									case 273:
																																									case 280:
																																									case 281:
																																									case 285:
																																									case 288:
																																										goto end_IL_051b;
																																									case 141:
																																										goto IL_12ba;
																																									case 262:
																																										goto IL_12c8;
																																									case 135:
																																										goto IL_12d6;
																																									case 11:
																																									case 14:
																																									case 20:
																																									case 39:
																																									case 41:
																																									case 42:
																																									case 47:
																																									case 61:
																																									case 64:
																																									case 68:
																																									case 73:
																																									case 82:
																																									case 90:
																																									case 95:
																																									case 97:
																																									case 108:
																																									case 111:
																																									case 115:
																																									case 147:
																																									case 165:
																																									case 172:
																																									case 173:
																																									case 175:
																																									case 189:
																																									case 196:
																																									case 204:
																																									case 205:
																																									case 237:
																																									case 242:
																																									case 256:
																																									case 274:
																																									case 275:
																																									case 279:
																																										goto IL_12e4;
																																									case 161:
																																										goto IL_12f7;
																																									case 215:
																																										goto IL_1301;
																																									case 110:
																																										goto IL_130c;
																																									case 4:
																																										goto IL_131c;
																																									case 81:
																																										goto IL_132c;
																																									case 145:
																																										goto IL_1345;
																																									case 231:
																																										goto IL_1355;
																																									case 48:
																																									case 99:
																																										goto IL_1365;
																																									case 153:
																																										goto IL_1375;
																																									case 76:
																																										goto IL_1385;
																																									case 84:
																																									case 259:
																																										return;
																																									}
																																									goto end_IL_05bb;
																																								}
																																								array2[num5 - 2] = 0;
																																								num = 149;
																																								goto IL_1246;
																																								IL_1246:
																																								num5--;
																																								goto IL_12e4;
																																								continue;
																																								end_IL_04bd:
																																								break;
																																							}
																																							break;
																																						}
																																						goto IL_05f4;
																																					}
																																					num = 30;
																																					break;
																																					continue;
																																					end_IL_051b:
																																					break;
																																				}
																																				break;
																																				IL_052b:;
																																			}
																																			break;
																																		}
																																		goto IL_06a9;
																																		IL_06a9:
																																		if (1 > b)
																																		{
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_065f;
																																IL_0696:
																																num5--;
																																goto IL_12e4;
																																IL_065f:
																																reference = ref array5[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_0688;
																																IL_0688:
																																ptr2 += 8;
																																goto IL_0696;
																															}
																															break;
																														}
																														goto IL_06bc;
																														IL_084b:
																														num5--;
																														goto IL_12e4;
																														IL_06bc:
																														if (5 >= b)
																														{
																															goto IL_06c7;
																														}
																														goto IL_0746;
																														IL_06c7:
																														if (5 > b)
																														{
																															goto IL_06d2;
																														}
																														goto IL_0701;
																														IL_06d2:
																														if (4 < b)
																														{
																															break;
																														}
																														goto IL_06e0;
																														IL_06e0:
																														if (4 > b)
																														{
																															break;
																														}
																														goto IL_06ee;
																														IL_06ee:
																														array2[num5] = 0;
																														goto IL_0917;
																														IL_0917:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																														goto IL_093a;
																														IL_093a:
																														array3[num5] = null;
																														goto IL_0944;
																														IL_0944:
																														num5++;
																														goto IL_0952;
																														IL_0952:
																														ptr2 += 8;
																														goto IL_12e4;
																														IL_0701:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_113f;
																														IL_113f:
																														array2[num5 - 2] = 0;
																														goto IL_1153;
																														IL_1153:
																														num5--;
																														num = 42;
																														goto IL_12e4;
																														IL_0746:
																														if (6 < b)
																														{
																															break;
																														}
																														goto IL_0754;
																														IL_0754:
																														if (6 > b)
																														{
																															num = 146;
																															break;
																														}
																														goto IL_075f;
																														IL_075f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_079f;
																														IL_079f:
																														array2[num5 - 2] = 0;
																														goto IL_084b;
																													}
																													break;
																												}
																												goto IL_05f4;
																												IL_1216:
																												num5--;
																												goto IL_12e4;
																												IL_05f4:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																												goto IL_1202;
																												IL_1202:
																												array2[num5 - 2] = 0;
																												goto IL_1216;
																											}
																											break;
																										}
																										goto IL_064c;
																										IL_08ed:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_08fb;
																										IL_064c:
																										if (11 >= b)
																										{
																											goto IL_085e;
																										}
																										goto IL_09d3;
																										IL_09d3:
																										if (13 >= b)
																										{
																											goto IL_09e1;
																										}
																										goto IL_0e83;
																										IL_09e1:
																										if (13 > b)
																										{
																											goto IL_09ec;
																										}
																										goto IL_0a0d;
																										IL_09ec:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_09fa;
																										IL_09fa:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_12e4;
																										IL_0a0d:
																										array8 = array3;
																										num6 = num5;
																										if (array == null)
																										{
																											goto IL_0a1c;
																										}
																										num7 = ptr2;
																										byte b2 = *num7;
																										ptr2 = num7 + 4;
																										int num8 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num8;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0b74;
																										IL_08fb:
																										if (10 > b)
																										{
																											break;
																										}
																										num = 263;
																										goto IL_0bd6;
																										IL_0c38:
																										num5 -= 2;
																										goto IL_12e4;
																										IL_0bd6:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0c38;
																										IL_0b74:
																										array2[num5] = 5;
																										num = 227;
																										goto IL_0b8b;
																										IL_0b8b:
																										num5++;
																										num = 95;
																										goto IL_12e4;
																										IL_0e83:
																										if (14 < b)
																										{
																											break;
																										}
																										goto IL_0e91;
																										IL_0e91:
																										if (14 > b)
																										{
																											break;
																										}
																										goto IL_0e9f;
																										IL_0e9f:
																										array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																										goto IL_0ebd;
																										IL_0ebd:
																										ptr2 += 8;
																										goto IL_0ecb;
																										IL_0ecb:
																										num5--;
																										goto IL_12e4;
																										IL_085e:
																										if (11 <= b)
																										{
																											goto IL_0869;
																										}
																										goto IL_08cf;
																										IL_0869:
																										array2[num5 - 1] = 0;
																										goto IL_087d;
																										IL_087d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																										goto IL_08bc;
																										IL_08bc:
																										ptr2 += 8;
																										goto IL_12e4;
																										IL_08cf:
																										if (9 >= b)
																										{
																											goto IL_08da;
																										}
																										goto IL_08ed;
																										IL_08da:
																										if (9 > b)
																										{
																											goto IL_0ba7;
																										}
																										goto IL_10d8;
																										IL_0ba7:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0bb5;
																										IL_0bb5:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_0bc3;
																										IL_0bc3:
																										num5--;
																										goto IL_12e4;
																										IL_10d8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_1118;
																										IL_1118:
																										array2[num5 - 2] = 0;
																										goto IL_112c;
																										IL_112c:
																										num5--;
																										goto IL_12e4;
																									}
																									break;
																								}
																								goto IL_1259;
																								IL_1282:
																								array2[num5 - 1] = 5;
																								goto IL_12e4;
																								IL_1259:
																								array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																								goto IL_1282;
																							}
																							break;
																						}
																						goto IL_0639;
																						IL_0e40:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
																						goto IL_0e6a;
																						IL_0639:
																						if (23 < b)
																						{
																							goto IL_07c6;
																						}
																						goto IL_0965;
																						IL_07c6:
																						if (27 >= b)
																						{
																							goto IL_07d1;
																						}
																						goto IL_081c;
																						IL_07d1:
																						if (27 > b)
																						{
																							goto IL_07df;
																						}
																						goto IL_0f0b;
																						IL_07df:
																						if (25 >= b)
																						{
																							goto IL_07ed;
																						}
																						goto IL_0b30;
																						IL_07ed:
																						if (25 > b)
																						{
																							goto IL_07fb;
																						}
																						goto IL_0ede;
																						IL_07fb:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_0809;
																						IL_0809:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_0ac9;
																						IL_0ac9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0b09;
																						IL_0b09:
																						array2[num5 - 2] = 0;
																						goto IL_0b1d;
																						IL_0b1d:
																						num5--;
																						goto IL_12e4;
																						IL_0ede:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0ef8;
																						IL_0ef8:
																						num5--;
																						goto IL_12e4;
																						IL_0b30:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0b3e;
																						IL_0b3e:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_0b4c;
																						IL_0b4c:
																						((delegate*<void>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
																						goto IL_0b61;
																						IL_0b61:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_0f0b:
																						array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0f44;
																						IL_0f44:
																						array2[num5 - 2] = 5;
																						goto IL_0f58;
																						IL_0f58:
																						num5--;
																						num = 205;
																						goto IL_12e4;
																						IL_081c:
																						if (29 < b)
																						{
																							goto IL_082a;
																						}
																						goto IL_0f74;
																						IL_082a:
																						if (30 < b)
																						{
																							break;
																						}
																						goto IL_0838;
																						IL_0838:
																						if (30 > b)
																						{
																							break;
																						}
																						goto IL_09b7;
																						IL_09b7:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						goto IL_12e4;
																						IL_0f74:
																						if (29 > b)
																						{
																							goto IL_0f82;
																						}
																						goto IL_101f;
																						IL_0f82:
																						if (28 < b)
																						{
																							break;
																						}
																						goto IL_0f90;
																						IL_0f90:
																						if (28 > b)
																						{
																							break;
																						}
																						goto IL_0f9e;
																						IL_0f9e:
																						array2[num5 - 2] = 5;
																						goto IL_0fb2;
																						IL_0fb2:
																						array3[num5 - 2] = ((delegate*<string, string, string>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																						goto IL_0ffe;
																						IL_0ffe:
																						num5--;
																						goto IL_100c;
																						IL_100c:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_101f:
																						((delegate*<string, void>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_1048;
																						IL_1048:
																						num5--;
																						goto IL_1056;
																						IL_1056:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_0965:
																						if (23 <= b)
																						{
																							goto IL_0973;
																						}
																						goto IL_0c4b;
																						IL_0973:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_099e;
																						IL_099e:
																						array2[num5 - 1] = 0;
																						goto IL_12e4;
																						IL_0c4b:
																						if (19 >= b)
																						{
																							goto IL_0c59;
																						}
																						goto IL_0dbe;
																						IL_0c59:
																						if (19 > b)
																						{
																							goto IL_0c67;
																						}
																						goto IL_0d56;
																						IL_0c67:
																						if (17 < b)
																						{
																							goto IL_0c72;
																						}
																						goto IL_0ce8;
																						IL_0c72:
																						if (18 < b)
																						{
																							break;
																						}
																						num = 126;
																						goto IL_0c89;
																						IL_0e6a:
																						array2[num5 - 1] = 2;
																						goto IL_12e4;
																						IL_0c89:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0c97;
																						IL_0c97:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_0cd5;
																						IL_0cd5:
																						num5 -= 3;
																						goto IL_12e4;
																						IL_0ce8:
																						if (17 > b)
																						{
																							goto IL_0cf3;
																						}
																						goto IL_0d06;
																						IL_0cf3:
																						if (16 < b)
																						{
																							break;
																						}
																						goto IL_116f;
																						IL_116f:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_117d;
																						IL_117d:
																						array2[num5] = array2[num5 - 1];
																						goto IL_1195;
																						IL_1195:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_11b3;
																						IL_11b3:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_11d7;
																						IL_11d7:
																						array3[num5] = array3[num5 - 1];
																						goto IL_11ef;
																						IL_11ef:
																						num5++;
																						goto IL_12e4;
																						IL_0d06:
																						array2[num5] = 5;
																						goto IL_0d14;
																						IL_0d14:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						num = 74;
																						goto IL_0d35;
																						IL_0d35:
																						num5++;
																						goto IL_0d43;
																						IL_0d43:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_0d56:
																						array2[num5 - 1] = 5;
																						num = 245;
																						goto IL_0d73;
																						IL_0d73:
																						array3[num5 - 1] = ((delegate*<string[], string>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0dab;
																						IL_0dab:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_0dbe:
																						if (21 >= b)
																						{
																							goto IL_0dc9;
																						}
																						goto IL_0e24;
																						IL_0dc9:
																						if (21 <= b)
																						{
																							goto IL_0dd7;
																						}
																						goto IL_1069;
																						IL_0dd7:
																						array3[num5] = ((delegate*<string[]>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
																						goto IL_0df5;
																						IL_0df5:
																						array2[num5] = 5;
																						goto IL_0e03;
																						IL_0e03:
																						num5++;
																						goto IL_0e11;
																						IL_0e11:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_1069:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_1077;
																						IL_1077:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_1085;
																						IL_1085:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
																						goto IL_10a9;
																						IL_10a9:
																						array2[num5] = 0;
																						goto IL_10b7;
																						IL_10b7:
																						num5++;
																						goto IL_10c5;
																						IL_10c5:
																						ptr2 += 8;
																						goto IL_12e4;
																						IL_0e24:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_0e32;
																						IL_0e32:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0e40;
																					}
																				}
																				else
																				{
																					num = 285;
																				}
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																		goto IL_12ba;
																		IL_12d6:
																		ptr2 += 8;
																		goto IL_12e4;
																		IL_12c8:
																		num5++;
																		goto IL_12d6;
																		IL_12ba:
																		array2[num5] = 0;
																		goto IL_12c8;
																		continue;
																		end_IL_05bb:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0a1c:
			while (true)
			{
				IL_0a1c_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0b74_2:
						array2[num5] = 5;
						num = 227;
						while (true)
						{
							IL_0b8b_2:
							num5++;
							num = 95;
							while (true)
							{
								IL_12e4_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_05bb_2:
											if (b >= 1)
											{
												while (true)
												{
													IL_05ab_2:
													if (b <= 30)
													{
														while (true)
														{
															IL_059b_2:
															if (15 >= b)
															{
																while (true)
																{
																	IL_058b_2:
																	if (15 > b)
																	{
																		while (true)
																		{
																			IL_057b_2:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_056e_2:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_055e_2:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_054e_2:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_053e_2:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													num = 54;
																													while (true)
																													{
																														IL_051b_2:
																														if (2 <= b)
																														{
																															while (true)
																															{
																																IL_04d0_2:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																num = 296;
																																while (true)
																																{
																																	if (num != 296)
																																	{
																																		if (num != 1277)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 118:
																																		case 203:
																																			goto IL_04d0_2;
																																		case 54:
																																			goto IL_051b_2;
																																		case 13:
																																			goto IL_052b_2;
																																		case 36:
																																			goto IL_053e_2;
																																		case 114:
																																			goto IL_054e_2;
																																		case 29:
																																			goto IL_055e_2;
																																		case 102:
																																			goto IL_056e_2;
																																		case 56:
																																		case 233:
																																			goto IL_057b_2;
																																		case 171:
																																			goto IL_058b_2;
																																		case 162:
																																			goto IL_059b_2;
																																		case 226:
																																			goto IL_05ab_2;
																																		case 181:
																																			goto IL_05bb_2;
																																		case 272:
																																			goto end_IL_05bb_2;
																																		case 44:
																																		case 80:
																																			goto end_IL_05cb;
																																		case 5:
																																		case 34:
																																			goto end_IL_04bd_2;
																																		case 27:
																																		case 131:
																																			goto IL_0639_2;
																																		case 12:
																																		case 133:
																																			goto IL_064c_2;
																																		case 3:
																																		case 151:
																																			goto IL_065f_2;
																																		case 70:
																																			goto IL_0688_2;
																																		case 134:
																																			goto IL_0696_2;
																																		case 176:
																																			goto IL_06a9_2;
																																		case 109:
																																		case 212:
																																			goto IL_06bc_2;
																																		case 78:
																																			goto IL_06c7_2;
																																		case 164:
																																			goto IL_06d2_2;
																																		case 71:
																																			goto IL_06e0_2;
																																		case 40:
																																		case 113:
																																			goto IL_06ee_2;
																																		case 103:
																																		case 211:
																																			goto IL_0701_2;
																																		case 8:
																																			goto IL_0746_2;
																																		case 91:
																																			goto IL_0754_2;
																																		case 105:
																																		case 150:
																																			goto IL_075f_2;
																																		case 123:
																																			goto IL_079f_2;
																																		case 182:
																																		case 217:
																																			goto IL_07c6_2;
																																		case 63:
																																			goto IL_07d1_2;
																																		case 85:
																																		case 92:
																																			goto IL_07df_2;
																																		case 45:
																																			goto IL_07ed_2;
																																		case 157:
																																		case 210:
																																			goto IL_07fb_2;
																																		case 1:
																																			goto IL_0809_2;
																																		case 167:
																																			goto IL_081c_2;
																																		case 67:
																																		case 116:
																																			goto IL_082a_2;
																																		case 216:
																																			goto IL_0838_2;
																																		case 218:
																																			goto IL_084b_2;
																																		case 222:
																																			goto IL_085e_2;
																																		case 156:
																																		case 163:
																																			goto IL_0869_2;
																																		case 6:
																																			goto IL_087d_2;
																																		case 209:
																																			goto IL_08bc_2;
																																		case 37:
																																		case 225:
																																			goto IL_08cf_2;
																																		case 127:
																																			goto IL_08da_2;
																																		case 160:
																																			goto IL_08ed_2;
																																		case 168:
																																			goto IL_08fb_2;
																																		case 234:
																																			goto IL_0917_2;
																																		case 7:
																																			goto IL_093a_2;
																																		case 58:
																																			goto IL_0944_2;
																																		case 94:
																																			goto IL_0952_2;
																																		case 239:
																																			goto IL_0965_2;
																																		case 21:
																																		case 59:
																																			goto IL_0973_2;
																																		case 60:
																																			goto IL_099e_2;
																																		case 235:
																																		case 241:
																																			goto IL_09b7_2;
																																		case 101:
																																		case 243:
																																			goto IL_09d3_2;
																																		case 170:
																																			goto IL_09e1_2;
																																		case 83:
																																		case 186:
																																			goto IL_09ec_2;
																																		case 72:
																																			goto IL_09fa_2;
																																		case 178:
																																		case 236:
																																			goto end_IL_05db;
																																		case 125:
																																		case 246:
																																			goto IL_0ac9_2;
																																		case 220:
																																			goto IL_0b09_2;
																																		case 198:
																																			goto IL_0b1d_2;
																																		case 221:
																																		case 253:
																																			goto IL_0b30_2;
																																		case 142:
																																			goto IL_0b3e_2;
																																		case 23:
																																		case 33:
																																			goto IL_0b4c_2;
																																		case 53:
																																			goto IL_0b61_2;
																																		case 255:
																																			goto IL_0b74_2;
																																		case 227:
																																			goto IL_0b8b_2;
																																		case 260:
																																			goto IL_0ba7_2;
																																		case 228:
																																			goto IL_0bb5_2;
																																		case 31:
																																		case 250:
																																			goto IL_0bc3_2;
																																		case 79:
																																		case 263:
																																			goto IL_0bd6_2;
																																		case 174:
																																			goto IL_0c38_2;
																																		case 18:
																																		case 265:
																																			goto IL_0c4b_2;
																																		case 249:
																																			goto IL_0c59_2;
																																		case 191:
																																			goto IL_0c67_2;
																																		case 75:
																																		case 187:
																																			goto IL_0c72_2;
																																		case 126:
																																			goto IL_0c89_2;
																																		case 208:
																																		case 247:
																																			goto IL_0c97_2;
																																		case 248:
																																			goto IL_0cd5_2;
																																		case 144:
																																			goto IL_0ce8_2;
																																		case 119:
																																		case 213:
																																			goto IL_0cf3_2;
																																		case 86:
																																		case 124:
																																			goto IL_0d06_2;
																																		case 128:
																																			goto IL_0d14_2;
																																		case 74:
																																			goto IL_0d35_2;
																																		case 55:
																																			goto IL_0d43_2;
																																		case 132:
																																		case 137:
																																			goto IL_0d56_2;
																																		case 245:
																																			goto IL_0d73_2;
																																		case 88:
																																			goto IL_0dab_2;
																																		case 251:
																																			goto IL_0dbe_2;
																																		case 143:
																																			goto IL_0dc9_2;
																																		case 19:
																																		case 230:
																																			goto IL_0dd7_2;
																																		case 180:
																																			goto IL_0df5_2;
																																		case 244:
																																			goto IL_0e03_2;
																																		case 214:
																																			goto IL_0e11_2;
																																		case 219:
																																			goto IL_0e24_2;
																																		case 193:
																																			goto IL_0e32_2;
																																		case 107:
																																		case 139:
																																			goto IL_0e40_2;
																																		case 258:
																																			goto IL_0e6a_2;
																																		case 232:
																																		case 267:
																																			goto IL_0e83_2;
																																		case 197:
																																			goto IL_0e91_2;
																																		case 192:
																																		case 261:
																																			goto IL_0e9f_2;
																																		case 148:
																																			goto IL_0ebd_2;
																																		case 38:
																																			goto IL_0ecb_2;
																																		case 28:
																																		case 271:
																																			goto IL_0ede_2;
																																		case 15:
																																			goto IL_0ef8_2;
																																		case 238:
																																		case 278:
																																			goto IL_0f0b_2;
																																		case 51:
																																			goto IL_0f44_2;
																																		case 154:
																																			goto IL_0f58_2;
																																		case 282:
																																			goto IL_0f74_2;
																																		case 32:
																																		case 93:
																																			goto IL_0f82_2;
																																		case 112:
																																			goto IL_0f90_2;
																																		case 122:
																																		case 177:
																																			goto IL_0f9e_2;
																																		case 66:
																																			goto IL_0fb2_2;
																																		case 184:
																																			goto IL_0ffe_2;
																																		case 155:
																																			goto IL_100c_2;
																																		case 269:
																																		case 276:
																																			goto IL_101f_2;
																																		case 202:
																																			goto IL_1048_2;
																																		case 199:
																																			goto IL_1056_2;
																																		case 283:
																																			goto IL_1069_2;
																																		case 24:
																																			goto IL_1077_2;
																																		case 26:
																																		case 270:
																																			goto IL_1085_2;
																																		case 9:
																																			goto IL_10a9_2;
																																		case 190:
																																			goto IL_10b7_2;
																																		case 120:
																																			goto IL_10c5_2;
																																		case 277:
																																		case 284:
																																			goto IL_10d8_2;
																																		case 140:
																																			goto IL_1118_2;
																																		case 25:
																																			goto IL_112c_2;
																																		case 286:
																																			goto IL_113f_2;
																																		case 62:
																																			goto IL_1153_2;
																																		case 287:
																																			goto IL_116f_2;
																																		case 16:
																																		case 98:
																																			goto IL_117d_2;
																																		case 17:
																																			goto IL_1195_2;
																																		case 224:
																																			goto IL_11b3_2;
																																		case 22:
																																			goto IL_11d7_2;
																																		case 69:
																																			goto IL_11ef_2;
																																		case 289:
																																			goto IL_1202_2;
																																		case 129:
																																			goto IL_1216_2;
																																		case 149:
																																			goto IL_1246_2;
																																		case 136:
																																		case 194:
																																			goto IL_1259_2;
																																		case 65:
																																			goto IL_1282_2;
																																		case 0:
																																		case 2:
																																		case 10:
																																		case 30:
																																		case 35:
																																		case 43:
																																		case 46:
																																		case 49:
																																		case 50:
																																		case 52:
																																		case 57:
																																		case 87:
																																		case 89:
																																		case 96:
																																		case 100:
																																		case 104:
																																		case 106:
																																		case 117:
																																		case 121:
																																		case 130:
																																		case 138:
																																		case 146:
																																		case 152:
																																		case 158:
																																		case 159:
																																		case 166:
																																		case 169:
																																		case 179:
																																		case 183:
																																		case 185:
																																		case 188:
																																		case 195:
																																		case 200:
																																		case 201:
																																		case 206:
																																		case 207:
																																		case 223:
																																		case 229:
																																		case 240:
																																		case 252:
																																		case 254:
																																		case 257:
																																		case 264:
																																		case 266:
																																		case 268:
																																		case 273:
																																		case 280:
																																		case 281:
																																		case 285:
																																		case 288:
																																			goto end_IL_051b_2;
																																		case 141:
																																			goto IL_12ba_2;
																																		case 262:
																																			goto IL_12c8_2;
																																		case 135:
																																			goto IL_12d6_2;
																																		case 11:
																																		case 14:
																																		case 20:
																																		case 39:
																																		case 41:
																																		case 42:
																																		case 47:
																																		case 61:
																																		case 64:
																																		case 68:
																																		case 73:
																																		case 82:
																																		case 90:
																																		case 95:
																																		case 97:
																																		case 108:
																																		case 111:
																																		case 115:
																																		case 147:
																																		case 165:
																																		case 172:
																																		case 173:
																																		case 175:
																																		case 189:
																																		case 196:
																																		case 204:
																																		case 205:
																																		case 237:
																																		case 242:
																																		case 256:
																																		case 274:
																																		case 275:
																																		case 279:
																																			goto IL_12e4_2;
																																		case 161:
																																			ptr2 = ptr;
																																			goto IL_12e4_2;
																																		case 215:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefineByValTStrEventActivityOptions.defineByValTStrEventActivityOptions_0);
																																			goto case 161;
																																		case 110:
																																			array7 = new object[13];
																																			goto case 215;
																																		case 4:
																																			array6 = new long[4];
																																			goto case 110;
																																		case 81:
																																			array5 = new int[6];
																																			num = 4;
																																			goto case 4;
																																		case 145:
																																			array4 = new int[4];
																																			goto case 81;
																																		case 231:
																																			array3 = new object[4];
																																			goto case 145;
																																		case 48:
																																		case 99:
																																			array2 = new byte[4];
																																			goto case 231;
																																		case 153:
																																			num3 = num2 * 4;
																																			goto case 48;
																																		case 76:
																																			num2 = 1;
																																			goto case 153;
																																		case 77:
																																			goto end_IL_0a2a;
																																		case 84:
																																		case 259:
																																			return;
																																		}
																																		continue;
																																	}
																																	array2[num5 - 2] = 0;
																																	num = 149;
																																	goto IL_1246_2;
																																	IL_1246_2:
																																	num5--;
																																	goto IL_12e4_2;
																																	continue;
																																	end_IL_04bd_2:
																																	break;
																																}
																																break;
																															}
																															goto IL_05f4_2;
																														}
																														num = 30;
																														break;
																														continue;
																														end_IL_051b_2:
																														break;
																													}
																													break;
																													IL_052b_2:;
																												}
																												break;
																											}
																											goto IL_06a9_2;
																											IL_06a9_2:
																											if (1 > b)
																											{
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_065f_2;
																									IL_0696_2:
																									num5--;
																									goto IL_12e4_2;
																									IL_065f_2:
																									reference = ref array5[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0688_2;
																									IL_0688_2:
																									ptr2 += 8;
																									goto IL_0696_2;
																								}
																								break;
																							}
																							goto IL_06bc_2;
																							IL_084b_2:
																							num5--;
																							goto IL_12e4_2;
																							IL_06bc_2:
																							if (5 >= b)
																							{
																								goto IL_06c7_2;
																							}
																							goto IL_0746_2;
																							IL_06c7_2:
																							if (5 > b)
																							{
																								goto IL_06d2_2;
																							}
																							goto IL_0701_2;
																							IL_06d2_2:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_06e0_2;
																							IL_06e0_2:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_06ee_2;
																							IL_06ee_2:
																							array2[num5] = 0;
																							goto IL_0917_2;
																							IL_0917_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_093a_2;
																							IL_093a_2:
																							array3[num5] = null;
																							goto IL_0944_2;
																							IL_0944_2:
																							num5++;
																							goto IL_0952_2;
																							IL_0952_2:
																							ptr2 += 8;
																							goto IL_12e4_2;
																							IL_0701_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_113f_2;
																							IL_113f_2:
																							array2[num5 - 2] = 0;
																							goto IL_1153_2;
																							IL_1153_2:
																							num5--;
																							num = 42;
																							goto IL_12e4_2;
																							IL_0746_2:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0754_2;
																							IL_0754_2:
																							if (6 > b)
																							{
																								num = 146;
																								break;
																							}
																							goto IL_075f_2;
																							IL_075f_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_079f_2;
																							IL_079f_2:
																							array2[num5 - 2] = 0;
																							goto IL_084b_2;
																						}
																						break;
																					}
																					goto IL_05f4_2;
																					IL_1216_2:
																					num5--;
																					goto IL_12e4_2;
																					IL_05f4_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_1202_2;
																					IL_1202_2:
																					array2[num5 - 2] = 0;
																					goto IL_1216_2;
																				}
																				break;
																			}
																			goto IL_064c_2;
																			IL_0bd6_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0c38_2;
																			IL_064c_2:
																			if (11 >= b)
																			{
																				goto IL_085e_2;
																			}
																			goto IL_09d3_2;
																			IL_09d3_2:
																			if (13 >= b)
																			{
																				goto IL_09e1_2;
																			}
																			goto IL_0e83_2;
																			IL_09e1_2:
																			if (13 <= b)
																			{
																				goto end_IL_05db;
																			}
																			goto IL_09ec_2;
																			IL_09ec_2:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_09fa_2;
																			IL_09fa_2:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_12e4_2;
																			IL_0e83_2:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_0e91_2;
																			IL_0e91_2:
																			if (14 > b)
																			{
																				break;
																			}
																			goto IL_0e9f_2;
																			IL_0e9f_2:
																			array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																			goto IL_0ebd_2;
																			IL_0ebd_2:
																			ptr2 += 8;
																			goto IL_0ecb_2;
																			IL_0ecb_2:
																			num5--;
																			goto IL_12e4_2;
																			IL_085e_2:
																			if (11 <= b)
																			{
																				goto IL_0869_2;
																			}
																			goto IL_08cf_2;
																			IL_0869_2:
																			array2[num5 - 1] = 0;
																			goto IL_087d_2;
																			IL_087d_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																			goto IL_08bc_2;
																			IL_08bc_2:
																			ptr2 += 8;
																			goto IL_12e4_2;
																			IL_08cf_2:
																			if (9 >= b)
																			{
																				goto IL_08da_2;
																			}
																			goto IL_08ed_2;
																			IL_08da_2:
																			if (9 > b)
																			{
																				goto IL_0ba7_2;
																			}
																			goto IL_10d8_2;
																			IL_0ba7_2:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0bb5_2;
																			IL_0bb5_2:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0bc3_2;
																			IL_0bc3_2:
																			num5--;
																			goto IL_12e4_2;
																			IL_10d8_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_1118_2;
																			IL_1118_2:
																			array2[num5 - 2] = 0;
																			goto IL_112c_2;
																			IL_112c_2:
																			num5--;
																			goto IL_12e4_2;
																			IL_08ed_2:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_08fb_2;
																			IL_08fb_2:
																			if (10 > b)
																			{
																				break;
																			}
																			num = 263;
																			goto IL_0bd6_2;
																			IL_0c38_2:
																			num5 -= 2;
																			goto IL_12e4_2;
																		}
																		break;
																	}
																	goto IL_1259_2;
																	IL_1282_2:
																	array2[num5 - 1] = 5;
																	goto IL_12e4_2;
																	IL_1259_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																	goto IL_1282_2;
																}
																break;
															}
															goto IL_0639_2;
															IL_0e40_2:
															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
															goto IL_0e6a_2;
															IL_0639_2:
															if (23 < b)
															{
																goto IL_07c6_2;
															}
															goto IL_0965_2;
															IL_07c6_2:
															if (27 >= b)
															{
																goto IL_07d1_2;
															}
															goto IL_081c_2;
															IL_07d1_2:
															if (27 > b)
															{
																goto IL_07df_2;
															}
															goto IL_0f0b_2;
															IL_07df_2:
															if (25 >= b)
															{
																goto IL_07ed_2;
															}
															goto IL_0b30_2;
															IL_07ed_2:
															if (25 > b)
															{
																goto IL_07fb_2;
															}
															goto IL_0ede_2;
															IL_07fb_2:
															if (24 < b)
															{
																break;
															}
															goto IL_0809_2;
															IL_0809_2:
															if (24 > b)
															{
																break;
															}
															goto IL_0ac9_2;
															IL_0ac9_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0b09_2;
															IL_0b09_2:
															array2[num5 - 2] = 0;
															goto IL_0b1d_2;
															IL_0b1d_2:
															num5--;
															goto IL_12e4_2;
															IL_0ede_2:
															int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0ef8_2;
															IL_0ef8_2:
															num5--;
															goto IL_12e4_2;
															IL_0b30_2:
															if (26 < b)
															{
																break;
															}
															goto IL_0b3e_2;
															IL_0b3e_2:
															if (26 > b)
															{
																break;
															}
															goto IL_0b4c_2;
															IL_0b4c_2:
															((delegate*<void>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
															goto IL_0b61_2;
															IL_0b61_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_0f0b_2:
															array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
															goto IL_0f44_2;
															IL_0f44_2:
															array2[num5 - 2] = 5;
															goto IL_0f58_2;
															IL_0f58_2:
															num5--;
															num = 205;
															goto IL_12e4_2;
															IL_081c_2:
															if (29 < b)
															{
																goto IL_082a_2;
															}
															goto IL_0f74_2;
															IL_082a_2:
															if (30 < b)
															{
																break;
															}
															goto IL_0838_2;
															IL_0838_2:
															if (30 > b)
															{
																break;
															}
															goto IL_09b7_2;
															IL_09b7_2:
															num9 = ptr2;
															num10 = -200;
															num4 = 1;
															ptr2 = num9 + num10;
															goto IL_12e4_2;
															IL_0f74_2:
															if (29 > b)
															{
																goto IL_0f82_2;
															}
															goto IL_101f_2;
															IL_0f82_2:
															if (28 < b)
															{
																break;
															}
															goto IL_0f90_2;
															IL_0f90_2:
															if (28 > b)
															{
																break;
															}
															goto IL_0f9e_2;
															IL_0f9e_2:
															array2[num5 - 2] = 5;
															goto IL_0fb2_2;
															IL_0fb2_2:
															array3[num5 - 2] = ((delegate*<string, string, string>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
															goto IL_0ffe_2;
															IL_0ffe_2:
															num5--;
															goto IL_100c_2;
															IL_100c_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_101f_2:
															((delegate*<string, void>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
															goto IL_1048_2;
															IL_1048_2:
															num5--;
															goto IL_1056_2;
															IL_1056_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_0965_2:
															if (23 <= b)
															{
																goto IL_0973_2;
															}
															goto IL_0c4b_2;
															IL_0973_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
															goto IL_099e_2;
															IL_099e_2:
															array2[num5 - 1] = 0;
															goto IL_12e4_2;
															IL_0c4b_2:
															if (19 >= b)
															{
																goto IL_0c59_2;
															}
															goto IL_0dbe_2;
															IL_0c59_2:
															if (19 > b)
															{
																goto IL_0c67_2;
															}
															goto IL_0d56_2;
															IL_0c67_2:
															if (17 < b)
															{
																goto IL_0c72_2;
															}
															goto IL_0ce8_2;
															IL_0c72_2:
															if (18 < b)
															{
																break;
															}
															num = 126;
															goto IL_0c89_2;
															IL_0e6a_2:
															array2[num5 - 1] = 2;
															goto IL_12e4_2;
															IL_0c89_2:
															if (18 > b)
															{
																break;
															}
															goto IL_0c97_2;
															IL_0c97_2:
															((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
															goto IL_0cd5_2;
															IL_0cd5_2:
															num5 -= 3;
															goto IL_12e4_2;
															IL_0ce8_2:
															if (17 > b)
															{
																goto IL_0cf3_2;
															}
															goto IL_0d06_2;
															IL_0cf3_2:
															if (16 < b)
															{
																break;
															}
															goto IL_116f_2;
															IL_116f_2:
															if (16 > b)
															{
																break;
															}
															goto IL_117d_2;
															IL_117d_2:
															array2[num5] = array2[num5 - 1];
															goto IL_1195_2;
															IL_1195_2:
															array4[num5 - 0] = array4[num5 - 1];
															goto IL_11b3_2;
															IL_11b3_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_11d7_2;
															IL_11d7_2:
															array3[num5] = array3[num5 - 1];
															goto IL_11ef_2;
															IL_11ef_2:
															num5++;
															goto IL_12e4_2;
															IL_0d06_2:
															array2[num5] = 5;
															goto IL_0d14_2;
															IL_0d14_2:
															array3[num5] = array7[*(int*)(ptr2 + num3)];
															num = 74;
															goto IL_0d35_2;
															IL_0d35_2:
															num5++;
															goto IL_0d43_2;
															IL_0d43_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_0d56_2:
															array2[num5 - 1] = 5;
															num = 245;
															goto IL_0d73_2;
															IL_0d73_2:
															array3[num5 - 1] = ((delegate*<string[], string>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															goto IL_0dab_2;
															IL_0dab_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_0dbe_2:
															if (21 >= b)
															{
																goto IL_0dc9_2;
															}
															goto IL_0e24_2;
															IL_0dc9_2:
															if (21 <= b)
															{
																goto IL_0dd7_2;
															}
															goto IL_1069_2;
															IL_0dd7_2:
															array3[num5] = ((delegate*<string[]>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
															goto IL_0df5_2;
															IL_0df5_2:
															array2[num5] = 5;
															goto IL_0e03_2;
															IL_0e03_2:
															num5++;
															goto IL_0e11_2;
															IL_0e11_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_1069_2:
															if (20 < b)
															{
																break;
															}
															goto IL_1077_2;
															IL_1077_2:
															if (20 > b)
															{
																break;
															}
															goto IL_1085_2;
															IL_1085_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)ThreadTransferReceiveHandledCgtUn[*(int*)(ptr2 + num3)])();
															goto IL_10a9_2;
															IL_10a9_2:
															array2[num5] = 0;
															goto IL_10b7_2;
															IL_10b7_2:
															num5++;
															goto IL_10c5_2;
															IL_10c5_2:
															ptr2 += 8;
															goto IL_12e4_2;
															IL_0e24_2:
															if (22 < b)
															{
																break;
															}
															goto IL_0e32_2;
															IL_0e32_2:
															if (22 > b)
															{
																break;
															}
															goto IL_0e40_2;
														}
													}
													else
													{
														num = 285;
													}
													break;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_12ba_2;
											IL_12d6_2:
											ptr2 += 8;
											goto IL_12e4_2;
											IL_12c8_2:
											num5++;
											goto IL_12d6_2;
											IL_12ba_2:
											array2[num5] = 0;
											goto IL_12c8_2;
											continue;
											end_IL_05bb_2:
											break;
										}
										continue;
										end_IL_05cb:
										break;
									}
									continue;
									end_IL_05db:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0a1c_2;
					}
					continue;
					end_IL_0a2a:
					break;
				}
				break;
			}
		}
	}

	public unsafe static void smethod_0()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_0487, IL_049a, IL_04ad, IL_04bd, IL_04cd, IL_04e0, IL_04ed, IL_04fd, IL_050d, IL_051d, IL_052d, IL_053d, IL_054d, IL_0558, IL_0563, IL_056e, IL_0581, IL_0594, IL_05b1, IL_0600, IL_060a, IL_0637, IL_064b, IL_0667, IL_067a, IL_0688, IL_0696, IL_06ae, IL_06cc, IL_06f9, IL_0716, IL_0732, IL_0745, IL_0753, IL_0793, IL_07a7, IL_07ba, IL_07cd, IL_07f6, IL_080f, IL_081d, IL_0835, IL_0843, IL_0856, IL_08b8, IL_08cb, IL_08e9, IL_08f7, IL_090a, IL_0913, IL_091e, IL_0931, IL_093f, IL_094a, IL_0958, IL_097b, IL_0985, IL_0993, IL_09a6, IL_09b4, IL_09bf, IL_09ff, IL_0a13, IL_0a2f, IL_0a3d, IL_0a4b, IL_0a64, IL_0a72, IL_0a80, IL_0a93, IL_0aa1, IL_0aaf, IL_0ad8, IL_0ae6, IL_0af9, IL_0b07, IL_0b12, IL_0b52, IL_0b66, IL_0b79, IL_0b87, IL_0b95, IL_0bd5, IL_0bf2, IL_0c05, IL_0c13, IL_0c21, IL_0c61, IL_0c75, IL_0c88, IL_0c96, IL_0ca1, IL_0cc5, IL_0cd3, IL_0ce1, IL_0cf4, IL_0d02, IL_0d0d, IL_0d25, IL_0d33, IL_0d3e, IL_0d52, IL_0d8a, IL_0d9d, IL_0dab, IL_0db9, IL_0df7, IL_0e0a, IL_0e18, IL_0e26, IL_0e3f, IL_0e4d, IL_0e5b, IL_0e6e, IL_0e7c, IL_0e87, IL_0ed9, IL_0eec, IL_0efa, IL_0f08, IL_0f49, IL_0f5d, IL_0f70, IL_0f7e, IL_0f8c, IL_0faa, IL_0fb8, IL_0fc6, IL_0fd9, IL_0fe7, IL_0ff2, IL_100b, IL_1019, IL_1027, IL_103a, IL_1048, IL_1056, IL_106a, IL_10b6, IL_10c4, IL_10d7, IL_10e5, IL_10f3, IL_1135, IL_1149, IL_115c, IL_116a, IL_1173, IL_1181, IL_11aa, IL_11b8, IL_11cb, IL_11d9, IL_11e7, IL_11f5, IL_1203, IL_1243, IL_1257, IL_126a, IL_127e, IL_12bd, IL_12cd, IL_12d8, IL_12e3, IL_12fc, IL_1307, IL_1310, IL_131b, IL_1337, IL_134a, IL_1354, IL_135f, IL_136f, IL_137f, IL_138f, IL_139f, IL_13af, IL_13bf, IL_13cf, IL_13df are reachable both inside and outside the pinned region starting at IL_13f4. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 65;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef58 = default(int);
			ref int reference = ref __rxRef58;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_13df:
					num2 = 1;
					while (true)
					{
						IL_13cf:
						num3 = num2 * 4;
						while (true)
						{
							IL_13bf:
							num4 = num2 * 8;
							while (true)
							{
								IL_13af:
								array2 = new byte[4];
								while (true)
								{
									IL_139f:
									array3 = new object[4];
									while (true)
									{
										IL_138f:
										array4 = new int[4];
										while (true)
										{
											IL_137f:
											array5 = new int[7];
											while (true)
											{
												IL_136f:
												array6 = new long[4];
												while (true)
												{
													IL_135f:
													array7 = new object[13];
													while (true)
													{
														IL_1354:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRealProxygetChannelSinkChain.NotContentIndexedTryUpdate);
														while (true)
														{
															IL_134a:
															ptr2 = ptr;
															while (true)
															{
																IL_1337:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_054d:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_053d:
																		ptr2++;
																		while (true)
																		{
																			IL_052d:
																			if (b >= 1)
																			{
																				while (b <= 32)
																				{
																					while (true)
																					{
																						IL_050d:
																						if (16 >= b)
																						{
																							while (true)
																							{
																								IL_04fd:
																								if (16 > b)
																								{
																									while (true)
																									{
																										IL_04ed:
																										if (8 < b)
																										{
																											while (true)
																											{
																												IL_04e0:
																												if (12 < b)
																												{
																													while (true)
																													{
																														IL_04cd:
																														if (14 >= b)
																														{
																															num = 267;
																															while (true)
																															{
																																IL_04bd:
																																if (14 > b)
																																{
																																	while (13 >= b)
																																	{
																																		while (13 <= b)
																																		{
																																			num = 279;
																																			while (true)
																																			{
																																				if (num != 279)
																																				{
																																					if (num != 1260)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 65:
																																						break;
																																					default:
																																						continue;
																																					case 14:
																																						goto IL_049a;
																																					case 29:
																																						goto IL_04ad;
																																					case 267:
																																						goto IL_04bd;
																																					case 20:
																																						goto IL_04cd;
																																					case 234:
																																						goto IL_04e0;
																																					case 213:
																																						goto IL_04ed;
																																					case 207:
																																						goto IL_04fd;
																																					case 269:
																																						goto IL_050d;
																																					case 100:
																																						goto IL_051d;
																																					case 102:
																																						goto IL_052d;
																																					case 155:
																																						goto IL_053d;
																																					case 59:
																																					case 238:
																																						goto IL_054d;
																																					case 62:
																																						goto IL_0558;
																																					case 43:
																																						goto IL_0563;
																																					case 16:
																																						goto IL_056e;
																																					case 25:
																																						goto IL_0581;
																																					case 47:
																																					case 101:
																																						goto IL_0594;
																																					case 110:
																																						goto IL_064b;
																																					case 117:
																																						goto IL_0667;
																																					case 139:
																																						goto IL_067a;
																																					case 70:
																																						goto IL_0688;
																																					case 53:
																																					case 108:
																																						goto IL_0696;
																																					case 36:
																																						goto IL_06ae;
																																					case 39:
																																						goto IL_06cc;
																																					case 96:
																																						goto IL_06f9;
																																					case 169:
																																						goto IL_0716;
																																					case 194:
																																						goto IL_0732;
																																					case 228:
																																						goto IL_0745;
																																					case 48:
																																					case 177:
																																						goto IL_0753;
																																					case 167:
																																						goto IL_0793;
																																					case 126:
																																						goto IL_07a7;
																																					case 230:
																																						goto IL_07ba;
																																					case 81:
																																					case 240:
																																						goto IL_07cd;
																																					case 93:
																																						goto IL_07f6;
																																					case 217:
																																					case 244:
																																						goto IL_080f;
																																					case 67:
																																						goto IL_081d;
																																					case 251:
																																						goto IL_0835;
																																					case 26:
																																						goto IL_0843;
																																					case 130:
																																					case 252:
																																						goto IL_0856;
																																					case 254:
																																						goto IL_08b8;
																																					case 172:
																																						goto IL_08cb;
																																					case 235:
																																						goto IL_08e9;
																																					case 44:
																																						goto IL_08f7;
																																					case 127:
																																						goto IL_0913;
																																					case 156:
																																					case 176:
																																						goto IL_091e;
																																					case 28:
																																						goto IL_0931;
																																					case 173:
																																						goto IL_093f;
																																					case 87:
																																					case 152:
																																						goto IL_094a;
																																					case 92:
																																						goto IL_0958;
																																					case 263:
																																						goto IL_097b;
																																					case 15:
																																						goto IL_0985;
																																					case 103:
																																						goto IL_0993;
																																					case 42:
																																						goto IL_09a6;
																																					case 203:
																																						goto IL_09b4;
																																					case 86:
																																					case 175:
																																						goto IL_09bf;
																																					case 242:
																																						goto IL_09ff;
																																					case 88:
																																						goto IL_0a13;
																																					case 45:
																																						goto IL_0a2f;
																																					case 89:
																																						goto IL_0a3d;
																																					case 111:
																																					case 259:
																																						goto IL_0a4b;
																																					case 264:
																																						goto IL_0a64;
																																					case 60:
																																						goto IL_0a72;
																																					case 196:
																																						goto IL_0a80;
																																					case 34:
																																						goto IL_0a93;
																																					case 215:
																																						goto IL_0aa1;
																																					case 129:
																																					case 212:
																																						goto IL_0aaf;
																																					case 201:
																																						goto IL_0ad8;
																																					case 94:
																																						goto IL_0ae6;
																																					case 38:
																																						goto IL_0af9;
																																					case 83:
																																						goto IL_0b07;
																																					case 138:
																																					case 233:
																																						goto IL_0b12;
																																					case 72:
																																						goto IL_0b52;
																																					case 159:
																																						goto IL_0b66;
																																					case 270:
																																						goto IL_0b79;
																																					case 197:
																																						goto IL_0b87;
																																					case 91:
																																					case 115:
																																						goto IL_0b95;
																																					case 257:
																																						goto IL_0bd5;
																																					case 171:
																																						goto IL_0bf2;
																																					case 222:
																																						goto IL_0c05;
																																					case 5:
																																						goto IL_0c13;
																																					case 74:
																																					case 205:
																																						goto IL_0c21;
																																					case 146:
																																						goto IL_0c61;
																																					case 221:
																																						goto IL_0c75;
																																					case 192:
																																						goto IL_0c88;
																																					case 239:
																																						goto IL_0c96;
																																					case 0:
																																					case 11:
																																						goto IL_0ca1;
																																					case 17:
																																						goto IL_0cc5;
																																					case 199:
																																						goto IL_0cd3;
																																					case 30:
																																						goto IL_0ce1;
																																					case 249:
																																						goto IL_0cf4;
																																					case 69:
																																						goto IL_0d02;
																																					case 32:
																																					case 63:
																																						goto IL_0d0d;
																																					case 143:
																																						goto IL_0d25;
																																					case 220:
																																						goto IL_0d33;
																																					case 61:
																																					case 161:
																																						goto IL_0d3e;
																																					case 82:
																																						goto IL_0d52;
																																					case 78:
																																						goto IL_0d8a;
																																					case 198:
																																						goto IL_0d9d;
																																					case 23:
																																						goto IL_0dab;
																																					case 9:
																																					case 135:
																																						goto end_IL_0487;
																																					case 144:
																																						goto IL_0df7;
																																					case 223:
																																						goto IL_0e0a;
																																					case 180:
																																						goto IL_0e18;
																																					case 164:
																																					case 165:
																																						goto IL_0e26;
																																					case 71:
																																						goto IL_0e3f;
																																					case 219:
																																						goto IL_0e4d;
																																					case 140:
																																						goto IL_0e5b;
																																					case 214:
																																						goto IL_0e6e;
																																					case 210:
																																						goto IL_0e7c;
																																					case 33:
																																					case 123:
																																						goto IL_0e87;
																																					case 105:
																																						goto IL_0ed9;
																																					case 168:
																																						goto IL_0eec;
																																					case 121:
																																						goto IL_0efa;
																																					case 120:
																																					case 226:
																																						goto IL_0f08;
																																					case 119:
																																						goto IL_0f49;
																																					case 90:
																																						goto IL_0f5d;
																																					case 191:
																																						goto IL_0f70;
																																					case 195:
																																						goto IL_0f7e;
																																					case 122:
																																					case 132:
																																						goto IL_0f8c;
																																					case 200:
																																						goto IL_0faa;
																																					case 149:
																																						goto IL_0fb8;
																																					case 133:
																																						goto IL_0fc6;
																																					case 12:
																																						goto IL_0fd9;
																																					case 268:
																																						goto IL_0fe7;
																																					case 112:
																																					case 193:
																																						goto IL_0ff2;
																																					case 224:
																																						goto IL_100b;
																																					case 128:
																																						goto IL_1019;
																																					case 256:
																																						goto IL_1027;
																																					case 187:
																																						goto IL_103a;
																																					case 8:
																																						goto IL_1048;
																																					case 85:
																																					case 99:
																																						goto IL_1056;
																																					case 216:
																																						goto IL_106a;
																																					case 2:
																																						goto IL_10b6;
																																					case 179:
																																						goto IL_10c4;
																																					case 153:
																																						goto IL_10d7;
																																					case 265:
																																						goto IL_10e5;
																																					case 113:
																																					case 188:
																																						goto IL_10f3;
																																					case 80:
																																						goto IL_1135;
																																					case 253:
																																						goto IL_1149;
																																					case 13:
																																						goto IL_115c;
																																					case 134:
																																						goto IL_1173;
																																					case 31:
																																					case 95:
																																						goto IL_1181;
																																					case 49:
																																						goto IL_11aa;
																																					case 160:
																																						goto IL_11b8;
																																					case 229:
																																						goto IL_11cb;
																																					case 236:
																																						goto IL_11d9;
																																					case 150:
																																						goto IL_11e7;
																																					case 211:
																																						goto IL_11f5;
																																					case 97:
																																					case 136:
																																						goto IL_1203;
																																					case 84:
																																						goto IL_1243;
																																					case 73:
																																						goto IL_1257;
																																					case 50:
																																					case 114:
																																						goto IL_126a;
																																					case 261:
																																						goto IL_127e;
																																					case 104:
																																						goto IL_12bd;
																																					case 255:
																																						goto IL_12cd;
																																					case 141:
																																						goto IL_12d8;
																																					case 178:
																																					case 243:
																																						goto IL_12e3;
																																					case 66:
																																						goto IL_12fc;
																																					case 258:
																																						goto IL_1310;
																																					case 1:
																																					case 4:
																																					case 10:
																																					case 19:
																																					case 22:
																																					case 35:
																																					case 40:
																																					case 52:
																																					case 55:
																																					case 79:
																																					case 109:
																																					case 142:
																																					case 147:
																																					case 151:
																																					case 154:
																																					case 158:
																																					case 166:
																																					case 170:
																																					case 181:
																																					case 184:
																																					case 185:
																																					case 190:
																																					case 202:
																																					case 209:
																																					case 218:
																																					case 227:
																																					case 231:
																																					case 241:
																																					case 246:
																																					case 247:
																																					case 248:
																																					case 250:
																																					case 260:
																																					case 262:
																																					case 272:
																																						goto end_IL_049a;
																																					case 3:
																																					case 6:
																																					case 7:
																																					case 18:
																																					case 21:
																																					case 24:
																																					case 27:
																																					case 37:
																																					case 46:
																																					case 51:
																																					case 54:
																																					case 56:
																																					case 57:
																																					case 58:
																																					case 68:
																																					case 75:
																																					case 76:
																																					case 98:
																																					case 116:
																																					case 118:
																																					case 124:
																																					case 125:
																																					case 137:
																																					case 145:
																																					case 148:
																																					case 157:
																																					case 162:
																																					case 163:
																																					case 174:
																																					case 183:
																																					case 189:
																																					case 204:
																																					case 206:
																																					case 225:
																																					case 266:
																																						goto IL_1337;
																																					case 77:
																																						goto IL_134a;
																																					case 182:
																																						goto IL_1354;
																																					case 208:
																																						goto IL_135f;
																																					case 237:
																																						goto IL_136f;
																																					case 41:
																																						goto IL_137f;
																																					case 107:
																																						goto IL_138f;
																																					case 186:
																																						goto IL_139f;
																																					case 106:
																																						goto IL_13af;
																																					case 131:
																																						goto IL_13bf;
																																					case 271:
																																						goto IL_13cf;
																																					case 64:
																																						goto IL_13df;
																																					case 232:
																																					case 245:
																																						return;
																																					}
																																					goto end_IL_052d;
																																				}
																																				goto IL_08cb;
																																				IL_08e9:
																																				ptr2 += 8;
																																				goto IL_08f7;
																																				IL_08f7:
																																				num6--;
																																				goto IL_1337;
																																				IL_08cb:
																																				array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																				goto IL_08e9;
																																				continue;
																																				end_IL_0487:
																																				break;
																																			}
																																			goto IL_0db9;
																																			continue;
																																			end_IL_049a:
																																			break;
																																			IL_049a:;
																																		}
																																		break;
																																		IL_04ad:;
																																	}
																																	break;
																																}
																																goto IL_07cd;
																																IL_07f6:
																																array2[num6 - 1] = 5;
																																goto IL_1337;
																																IL_07cd:
																																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																goto IL_07f6;
																															}
																															break;
																														}
																														goto IL_067a;
																														IL_06f9:
																														array3[num6] = array3[num6 - 1];
																														goto IL_07ba;
																														IL_07ba:
																														num6++;
																														goto IL_1337;
																														IL_067a:
																														if (15 < b)
																														{
																															break;
																														}
																														goto IL_0688;
																														IL_0688:
																														if (15 > b)
																														{
																															break;
																														}
																														goto IL_0696;
																														IL_0696:
																														array2[num6] = array2[num6 - 1];
																														goto IL_06ae;
																														IL_06ae:
																														array4[num6 - 0] = array4[num6 - 1];
																														goto IL_06cc;
																														IL_06cc:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														num = 96;
																														goto IL_06f9;
																													}
																													break;
																												}
																												goto IL_0558;
																												IL_064b:
																												array2[num6] = 5;
																												num = 169;
																												goto IL_0716;
																												IL_0558:
																												if (12 > b)
																												{
																													goto IL_0563;
																												}
																												goto IL_0594;
																												IL_0563:
																												if (10 >= b)
																												{
																													goto IL_056e;
																												}
																												goto IL_0581;
																												IL_056e:
																												if (10 > b)
																												{
																													goto IL_0667;
																												}
																												goto IL_0856;
																												IL_0856:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_08b8;
																												IL_08b8:
																												num6 -= 2;
																												goto IL_1337;
																												IL_0667:
																												if (9 < b)
																												{
																													break;
																												}
																												goto IL_0745;
																												IL_0745:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_0753;
																												IL_0753:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0793;
																												IL_0793:
																												array2[num6 - 2] = 0;
																												goto IL_07a7;
																												IL_07a7:
																												num6--;
																												goto IL_1337;
																												IL_0581:
																												if (11 < b)
																												{
																													break;
																												}
																												goto IL_0732;
																												IL_0732:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_1337;
																												IL_0594:
																												array8 = array3;
																												num7 = num6;
																												if (array == null)
																												{
																													goto IL_05a3;
																												}
																												num8 = ptr2;
																												byte b2 = *num8;
																												ptr2 = num8 + 4;
																												int num9 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num9;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_064b;
																												IL_0716:
																												num6++;
																												num = 56;
																												goto IL_1337;
																											}
																											break;
																										}
																										num = 127;
																										goto IL_0913;
																										IL_0c61:
																										array2[num6 - 2] = 0;
																										goto IL_0c75;
																										IL_0c75:
																										num6--;
																										goto IL_1337;
																										IL_0913:
																										if (8 <= b)
																										{
																											goto IL_091e;
																										}
																										goto IL_0931;
																										IL_091e:
																										num6--;
																										goto IL_1337;
																										IL_0931:
																										if (4 >= b)
																										{
																											goto IL_093f;
																										}
																										goto IL_0af9;
																										IL_093f:
																										if (4 <= b)
																										{
																											goto IL_094a;
																										}
																										goto IL_09a6;
																										IL_094a:
																										array2[num6] = 0;
																										goto IL_0958;
																										IL_0958:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_097b;
																										IL_097b:
																										array3[num6] = null;
																										goto IL_0985;
																										IL_0985:
																										num6++;
																										goto IL_0993;
																										IL_0993:
																										ptr2 += 8;
																										goto IL_1337;
																										IL_09a6:
																										if (2 >= b)
																										{
																											goto IL_09b4;
																										}
																										goto IL_0a93;
																										IL_09b4:
																										if (2 <= b)
																										{
																											goto IL_09bf;
																										}
																										goto IL_0a2f;
																										IL_09bf:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_09ff;
																										IL_09ff:
																										array2[num6 - 2] = 0;
																										goto IL_0a13;
																										IL_0a13:
																										num6--;
																										num = 21;
																										goto IL_1337;
																										IL_0a2f:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_0a3d;
																										IL_0a3d:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_0a4b;
																										IL_0a4b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																										goto IL_0a64;
																										IL_0a64:
																										array2[num6] = 0;
																										goto IL_0a72;
																										IL_0a72:
																										num6++;
																										goto IL_0a80;
																										IL_0a80:
																										ptr2 += 8;
																										goto IL_1337;
																										IL_0a93:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_0aa1;
																										IL_0aa1:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0aaf;
																										IL_0aaf:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0ad8;
																										IL_0ad8:
																										ptr2 += 8;
																										goto IL_0ae6;
																										IL_0ae6:
																										num6--;
																										goto IL_1337;
																										IL_0af9:
																										if (6 >= b)
																										{
																											goto IL_0b07;
																										}
																										goto IL_0c05;
																										IL_0b07:
																										if (6 <= b)
																										{
																											goto IL_0b12;
																										}
																										goto IL_0b79;
																										IL_0b12:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0b52;
																										IL_0b52:
																										array2[num6 - 2] = 0;
																										goto IL_0b66;
																										IL_0b66:
																										num6--;
																										goto IL_1337;
																										IL_0b79:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_0b87;
																										IL_0b87:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_0b95;
																										IL_0b95:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0bd5;
																										IL_0bd5:
																										array2[num6 - 2] = 0;
																										num = 171;
																										goto IL_0bf2;
																										IL_0bf2:
																										num6--;
																										goto IL_1337;
																										IL_0c05:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0c13;
																										IL_0c13:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0c21;
																										IL_0c21:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0c61;
																									}
																									break;
																								}
																								goto IL_080f;
																								IL_0843:
																								ptr2 += 8;
																								goto IL_1337;
																								IL_080f:
																								array2[num6] = 5;
																								goto IL_081d;
																								IL_081d:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0835;
																								IL_0835:
																								num6++;
																								goto IL_0843;
																							}
																							break;
																						}
																						goto IL_0c88;
																						IL_12fc:
																						if (32 < b)
																						{
																							break;
																						}
																						num = 258;
																						goto IL_1310;
																						IL_0c88:
																						if (24 >= b)
																						{
																							goto IL_0c96;
																						}
																						goto IL_0fd9;
																						IL_0c96:
																						if (24 <= b)
																						{
																							goto IL_0ca1;
																						}
																						goto IL_0cf4;
																						IL_0ca1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])();
																						goto IL_0cc5;
																						IL_0cc5:
																						array2[num6] = 0;
																						goto IL_0cd3;
																						IL_0cd3:
																						num6++;
																						goto IL_0ce1;
																						IL_0ce1:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_0cf4:
																						if (20 >= b)
																						{
																							goto IL_0d02;
																						}
																						goto IL_0e6e;
																						IL_0d02:
																						if (20 <= b)
																						{
																							goto IL_0d0d;
																						}
																						goto IL_0d25;
																						IL_0d0d:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_1337;
																						IL_0d25:
																						if (18 >= b)
																						{
																							goto IL_0d33;
																						}
																						goto IL_0e0a;
																						IL_0d33:
																						if (18 <= b)
																						{
																							goto IL_0d3e;
																						}
																						goto IL_0d9d;
																						IL_0d3e:
																						array2[num6 - 1] = 5;
																						goto IL_0d52;
																						IL_0d52:
																						array3[num6 - 1] = ((delegate*<string[], string>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_0d8a;
																						IL_0d8a:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_0d9d:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0dab;
																						IL_0dab:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0db9;
																						IL_0db9:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_0df7;
																						IL_0df7:
																						num6 -= 3;
																						goto IL_1337;
																						IL_0e0a:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_0e18;
																						IL_0e18:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_0e26;
																						IL_0e26:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0e3f;
																						IL_0e3f:
																						array2[num6] = 1;
																						goto IL_0e4d;
																						IL_0e4d:
																						num6++;
																						goto IL_0e5b;
																						IL_0e5b:
																						ptr2 += 16;
																						goto IL_1337;
																						IL_0e6e:
																						if (22 >= b)
																						{
																							goto IL_0e7c;
																						}
																						goto IL_0f70;
																						IL_0e7c:
																						if (22 <= b)
																						{
																							goto IL_0e87;
																						}
																						goto IL_0eec;
																						IL_0e87:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0ed9;
																						IL_0ed9:
																						num6--;
																						goto IL_1337;
																						IL_0eec:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0efa;
																						IL_0efa:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0f08;
																						IL_0f08:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_0f49;
																						IL_0f49:
																						array2[num6 - 2] = 0;
																						goto IL_0f5d;
																						IL_0f5d:
																						num6--;
																						goto IL_1337;
																						IL_0f70:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_0f7e;
																						IL_0f7e:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0f8c;
																						IL_0f8c:
																						array3[num6] = ((delegate*<string[]>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])();
																						goto IL_0faa;
																						IL_0faa:
																						array2[num6] = 5;
																						goto IL_0fb8;
																						IL_0fb8:
																						num6++;
																						goto IL_0fc6;
																						IL_0fc6:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_0fd9:
																						if (28 >= b)
																						{
																							goto IL_0fe7;
																						}
																						goto IL_11cb;
																						IL_0fe7:
																						if (28 <= b)
																						{
																							goto IL_0ff2;
																						}
																						goto IL_103a;
																						IL_0ff2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_100b;
																						IL_100b:
																						array2[num6] = 3;
																						goto IL_1019;
																						IL_1019:
																						num6++;
																						goto IL_1027;
																						IL_1027:
																						ptr2 += 16;
																						goto IL_1337;
																						IL_103a:
																						if (26 >= b)
																						{
																							goto IL_1048;
																						}
																						goto IL_115c;
																						IL_1048:
																						if (26 <= b)
																						{
																							goto IL_1056;
																						}
																						goto IL_10d7;
																						IL_1056:
																						array2[num6 - 2] = 5;
																						goto IL_106a;
																						IL_106a:
																						array3[num6 - 2] = ((delegate*<string, string, string>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																						goto IL_10b6;
																						IL_10b6:
																						num6--;
																						goto IL_10c4;
																						IL_10c4:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_10d7:
																						if (25 < b)
																						{
																							break;
																						}
																						goto IL_10e5;
																						IL_10e5:
																						if (25 > b)
																						{
																							break;
																						}
																						goto IL_10f3;
																						IL_10f3:
																						array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						num = 80;
																						goto IL_1135;
																						IL_1135:
																						array2[num6 - 2] = 5;
																						goto IL_1149;
																						IL_1149:
																						num6--;
																						goto IL_1337;
																						IL_115c:
																						if (27 < b)
																						{
																							break;
																						}
																						num = 134;
																						goto IL_1173;
																						IL_1310:
																						if (32 <= b)
																						{
																						}
																						break;
																						IL_1173:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_1181;
																						IL_1181:
																						((delegate*<string, void>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_11aa;
																						IL_11aa:
																						num6--;
																						goto IL_11b8;
																						IL_11b8:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_11cb:
																						if (30 >= b)
																						{
																							goto IL_11d9;
																						}
																						goto IL_12cd;
																						IL_11d9:
																						if (30 > b)
																						{
																							goto IL_11e7;
																						}
																						goto IL_126a;
																						IL_11e7:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_11f5;
																						IL_11f5:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_1203;
																						IL_1203:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1243;
																						IL_1243:
																						array2[num6 - 2] = 3;
																						goto IL_1257;
																						IL_1257:
																						num6--;
																						goto IL_1337;
																						IL_126a:
																						array2[num6 - 1] = 0;
																						goto IL_127e;
																						IL_127e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_12bd;
																						IL_12bd:
																						ptr2 += 8;
																						goto IL_1337;
																						IL_12cd:
																						if (31 >= b)
																						{
																							goto IL_12d8;
																						}
																						goto IL_12fc;
																						IL_12d8:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_12e3;
																						IL_12e3:
																						num10 = ptr2;
																						num11 = -200;
																						num5 = 1;
																						ptr2 = num10 + num11;
																						goto IL_1337;
																					}
																					break;
																					IL_051d:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 68;
																			goto IL_1337;
																			continue;
																			end_IL_052d:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_05a3:
			while (true)
			{
				IL_05a3_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_064b_2:
						array2[num6] = 5;
						num = 169;
						while (true)
						{
							IL_0716_2:
							num6++;
							num = 56;
							while (true)
							{
								IL_1337_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_052d_2:
											if (b >= 1)
											{
												while (b <= 32)
												{
													while (true)
													{
														IL_050d_2:
														if (16 >= b)
														{
															while (true)
															{
																IL_04fd_2:
																if (16 > b)
																{
																	while (true)
																	{
																		IL_04ed_2:
																		if (8 < b)
																		{
																			while (true)
																			{
																				IL_04e0_2:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_04cd_2:
																						if (14 >= b)
																						{
																							num = 267;
																							while (true)
																							{
																								IL_04bd_2:
																								if (14 > b)
																								{
																									while (13 >= b)
																									{
																										while (13 <= b)
																										{
																											num = 279;
																											while (true)
																											{
																												if (num != 279)
																												{
																													if (num != 1260)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 14:
																														goto IL_049a_2;
																													case 29:
																														goto IL_04ad_2;
																													case 267:
																														goto IL_04bd_2;
																													case 20:
																														goto IL_04cd_2;
																													case 234:
																														goto IL_04e0_2;
																													case 213:
																														goto IL_04ed_2;
																													case 207:
																														goto IL_04fd_2;
																													case 269:
																														goto IL_050d_2;
																													case 100:
																														goto IL_051d_2;
																													case 102:
																														goto IL_052d_2;
																													case 155:
																														goto end_IL_052d_2;
																													case 59:
																													case 238:
																														goto end_IL_053d;
																													case 62:
																														goto IL_0558_2;
																													case 43:
																														goto IL_0563_2;
																													case 16:
																														goto IL_056e_2;
																													case 25:
																														goto IL_0581_2;
																													case 47:
																													case 101:
																														goto end_IL_054d;
																													case 110:
																														goto IL_064b_2;
																													case 117:
																														goto IL_0667_2;
																													case 139:
																														goto IL_067a_2;
																													case 70:
																														goto IL_0688_2;
																													case 53:
																													case 108:
																														goto IL_0696_2;
																													case 36:
																														goto IL_06ae_2;
																													case 39:
																														goto IL_06cc_2;
																													case 96:
																														goto IL_06f9_2;
																													case 169:
																														goto IL_0716_2;
																													case 194:
																														goto IL_0732_2;
																													case 228:
																														goto IL_0745_2;
																													case 48:
																													case 177:
																														goto IL_0753_2;
																													case 167:
																														goto IL_0793_2;
																													case 126:
																														goto IL_07a7_2;
																													case 230:
																														goto IL_07ba_2;
																													case 81:
																													case 240:
																														goto IL_07cd_2;
																													case 93:
																														goto IL_07f6_2;
																													case 217:
																													case 244:
																														goto IL_080f_2;
																													case 67:
																														goto IL_081d_2;
																													case 251:
																														goto IL_0835_2;
																													case 26:
																														goto IL_0843_2;
																													case 130:
																													case 252:
																														goto IL_0856_2;
																													case 254:
																														goto IL_08b8_2;
																													case 172:
																														goto IL_08cb_2;
																													case 235:
																														goto IL_08e9_2;
																													case 44:
																														goto IL_08f7_2;
																													case 127:
																														goto IL_0913_2;
																													case 156:
																													case 176:
																														goto IL_091e_2;
																													case 28:
																														goto IL_0931_2;
																													case 173:
																														goto IL_093f_2;
																													case 87:
																													case 152:
																														goto IL_094a_2;
																													case 92:
																														goto IL_0958_2;
																													case 263:
																														goto IL_097b_2;
																													case 15:
																														goto IL_0985_2;
																													case 103:
																														goto IL_0993_2;
																													case 42:
																														goto IL_09a6_2;
																													case 203:
																														goto IL_09b4_2;
																													case 86:
																													case 175:
																														goto IL_09bf_2;
																													case 242:
																														goto IL_09ff_2;
																													case 88:
																														goto IL_0a13_2;
																													case 45:
																														goto IL_0a2f_2;
																													case 89:
																														goto IL_0a3d_2;
																													case 111:
																													case 259:
																														goto IL_0a4b_2;
																													case 264:
																														goto IL_0a64_2;
																													case 60:
																														goto IL_0a72_2;
																													case 196:
																														goto IL_0a80_2;
																													case 34:
																														goto IL_0a93_2;
																													case 215:
																														goto IL_0aa1_2;
																													case 129:
																													case 212:
																														goto IL_0aaf_2;
																													case 201:
																														goto IL_0ad8_2;
																													case 94:
																														goto IL_0ae6_2;
																													case 38:
																														goto IL_0af9_2;
																													case 83:
																														goto IL_0b07_2;
																													case 138:
																													case 233:
																														goto IL_0b12_2;
																													case 72:
																														goto IL_0b52_2;
																													case 159:
																														goto IL_0b66_2;
																													case 270:
																														goto IL_0b79_2;
																													case 197:
																														goto IL_0b87_2;
																													case 91:
																													case 115:
																														goto IL_0b95_2;
																													case 257:
																														goto IL_0bd5_2;
																													case 171:
																														goto IL_0bf2_2;
																													case 222:
																														goto IL_0c05_2;
																													case 5:
																														goto IL_0c13_2;
																													case 74:
																													case 205:
																														goto IL_0c21_2;
																													case 146:
																														goto IL_0c61_2;
																													case 221:
																														goto IL_0c75_2;
																													case 192:
																														goto IL_0c88_2;
																													case 239:
																														goto IL_0c96_2;
																													case 0:
																													case 11:
																														goto IL_0ca1_2;
																													case 17:
																														goto IL_0cc5_2;
																													case 199:
																														goto IL_0cd3_2;
																													case 30:
																														goto IL_0ce1_2;
																													case 249:
																														goto IL_0cf4_2;
																													case 69:
																														goto IL_0d02_2;
																													case 32:
																													case 63:
																														goto IL_0d0d_2;
																													case 143:
																														goto IL_0d25_2;
																													case 220:
																														goto IL_0d33_2;
																													case 61:
																													case 161:
																														goto IL_0d3e_2;
																													case 82:
																														goto IL_0d52_2;
																													case 78:
																														goto IL_0d8a_2;
																													case 198:
																														goto IL_0d9d_2;
																													case 23:
																														goto IL_0dab_2;
																													case 9:
																													case 135:
																														goto end_IL_0487_2;
																													case 144:
																														goto IL_0df7_2;
																													case 223:
																														goto IL_0e0a_2;
																													case 180:
																														goto IL_0e18_2;
																													case 164:
																													case 165:
																														goto IL_0e26_2;
																													case 71:
																														goto IL_0e3f_2;
																													case 219:
																														goto IL_0e4d_2;
																													case 140:
																														goto IL_0e5b_2;
																													case 214:
																														goto IL_0e6e_2;
																													case 210:
																														goto IL_0e7c_2;
																													case 33:
																													case 123:
																														goto IL_0e87_2;
																													case 105:
																														goto IL_0ed9_2;
																													case 168:
																														goto IL_0eec_2;
																													case 121:
																														goto IL_0efa_2;
																													case 120:
																													case 226:
																														goto IL_0f08_2;
																													case 119:
																														goto IL_0f49_2;
																													case 90:
																														goto IL_0f5d_2;
																													case 191:
																														goto IL_0f70_2;
																													case 195:
																														goto IL_0f7e_2;
																													case 122:
																													case 132:
																														goto IL_0f8c_2;
																													case 200:
																														goto IL_0faa_2;
																													case 149:
																														goto IL_0fb8_2;
																													case 133:
																														goto IL_0fc6_2;
																													case 12:
																														goto IL_0fd9_2;
																													case 268:
																														goto IL_0fe7_2;
																													case 112:
																													case 193:
																														goto IL_0ff2_2;
																													case 224:
																														goto IL_100b_2;
																													case 128:
																														goto IL_1019_2;
																													case 256:
																														goto IL_1027_2;
																													case 187:
																														goto IL_103a_2;
																													case 8:
																														goto IL_1048_2;
																													case 85:
																													case 99:
																														goto IL_1056_2;
																													case 216:
																														goto IL_106a_2;
																													case 2:
																														goto IL_10b6_2;
																													case 179:
																														goto IL_10c4_2;
																													case 153:
																														goto IL_10d7_2;
																													case 265:
																														goto IL_10e5_2;
																													case 113:
																													case 188:
																														goto IL_10f3_2;
																													case 80:
																														goto IL_1135_2;
																													case 253:
																														goto IL_1149_2;
																													case 13:
																														goto IL_115c_2;
																													case 134:
																														goto IL_1173_2;
																													case 31:
																													case 95:
																														goto IL_1181_2;
																													case 49:
																														goto IL_11aa_2;
																													case 160:
																														goto IL_11b8_2;
																													case 229:
																														goto IL_11cb_2;
																													case 236:
																														goto IL_11d9_2;
																													case 150:
																														goto IL_11e7_2;
																													case 211:
																														goto IL_11f5_2;
																													case 97:
																													case 136:
																														goto IL_1203_2;
																													case 84:
																														goto IL_1243_2;
																													case 73:
																														goto IL_1257_2;
																													case 50:
																													case 114:
																														goto IL_126a_2;
																													case 261:
																														goto IL_127e_2;
																													case 104:
																														goto IL_12bd_2;
																													case 255:
																														goto IL_12cd_2;
																													case 141:
																														goto IL_12d8_2;
																													case 178:
																													case 243:
																														goto IL_12e3_2;
																													case 66:
																														goto IL_12fc_2;
																													case 258:
																														goto IL_1310_2;
																													case 1:
																													case 4:
																													case 10:
																													case 19:
																													case 22:
																													case 35:
																													case 40:
																													case 52:
																													case 55:
																													case 79:
																													case 109:
																													case 142:
																													case 147:
																													case 151:
																													case 154:
																													case 158:
																													case 166:
																													case 170:
																													case 181:
																													case 184:
																													case 185:
																													case 190:
																													case 202:
																													case 209:
																													case 218:
																													case 227:
																													case 231:
																													case 241:
																													case 246:
																													case 247:
																													case 248:
																													case 250:
																													case 260:
																													case 262:
																													case 272:
																														goto end_IL_049a_2;
																													case 3:
																													case 6:
																													case 7:
																													case 18:
																													case 21:
																													case 24:
																													case 27:
																													case 37:
																													case 46:
																													case 51:
																													case 54:
																													case 56:
																													case 57:
																													case 58:
																													case 68:
																													case 75:
																													case 76:
																													case 98:
																													case 116:
																													case 118:
																													case 124:
																													case 125:
																													case 137:
																													case 145:
																													case 148:
																													case 157:
																													case 162:
																													case 163:
																													case 174:
																													case 183:
																													case 189:
																													case 204:
																													case 206:
																													case 225:
																													case 266:
																														goto IL_1337_2;
																													case 77:
																														ptr2 = ptr;
																														goto IL_1337_2;
																													case 182:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRealProxygetChannelSinkChain.NotContentIndexedTryUpdate);
																														goto case 77;
																													case 208:
																														array7 = new object[13];
																														goto case 182;
																													case 237:
																														array6 = new long[4];
																														goto case 208;
																													case 41:
																														array5 = new int[7];
																														goto case 237;
																													case 107:
																														array4 = new int[4];
																														goto case 41;
																													case 186:
																														array3 = new object[4];
																														goto case 107;
																													case 106:
																														array2 = new byte[4];
																														goto case 186;
																													case 131:
																														num4 = num2 * 8;
																														goto case 106;
																													case 271:
																														num3 = num2 * 4;
																														goto case 131;
																													case 64:
																														num2 = 1;
																														goto case 271;
																													case 65:
																														goto end_IL_05b1;
																													case 232:
																													case 245:
																														return;
																													}
																													continue;
																												}
																												goto IL_08cb_2;
																												IL_08e9_2:
																												ptr2 += 8;
																												goto IL_08f7_2;
																												IL_08f7_2:
																												num6--;
																												goto IL_1337_2;
																												IL_08cb_2:
																												array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																												goto IL_08e9_2;
																												continue;
																												end_IL_0487_2:
																												break;
																											}
																											goto IL_0db9_2;
																											continue;
																											end_IL_049a_2:
																											break;
																											IL_049a_2:;
																										}
																										break;
																										IL_04ad_2:;
																									}
																									break;
																								}
																								goto IL_07cd_2;
																								IL_07f6_2:
																								array2[num6 - 1] = 5;
																								goto IL_1337_2;
																								IL_07cd_2:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_07f6_2;
																							}
																							break;
																						}
																						goto IL_067a_2;
																						IL_06f9_2:
																						array3[num6] = array3[num6 - 1];
																						goto IL_07ba_2;
																						IL_07ba_2:
																						num6++;
																						goto IL_1337_2;
																						IL_067a_2:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0688_2;
																						IL_0688_2:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_0696_2;
																						IL_0696_2:
																						array2[num6] = array2[num6 - 1];
																						goto IL_06ae_2;
																						IL_06ae_2:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_06cc_2;
																						IL_06cc_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 96;
																						goto IL_06f9_2;
																					}
																					break;
																				}
																				goto IL_0558_2;
																				IL_0732_2:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_1337_2;
																				IL_0558_2:
																				if (12 <= b)
																				{
																					goto end_IL_054d;
																				}
																				goto IL_0563_2;
																				IL_0563_2:
																				if (10 >= b)
																				{
																					goto IL_056e_2;
																				}
																				goto IL_0581_2;
																				IL_056e_2:
																				if (10 > b)
																				{
																					goto IL_0667_2;
																				}
																				goto IL_0856_2;
																				IL_0856_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08b8_2;
																				IL_08b8_2:
																				num6 -= 2;
																				goto IL_1337_2;
																				IL_0667_2:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0745_2;
																				IL_0745_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0753_2;
																				IL_0753_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0793_2;
																				IL_0793_2:
																				array2[num6 - 2] = 0;
																				goto IL_07a7_2;
																				IL_07a7_2:
																				num6--;
																				goto IL_1337_2;
																				IL_0581_2:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0732_2;
																			}
																			break;
																		}
																		num = 127;
																		goto IL_0913_2;
																		IL_0c61_2:
																		array2[num6 - 2] = 0;
																		goto IL_0c75_2;
																		IL_0c75_2:
																		num6--;
																		goto IL_1337_2;
																		IL_0913_2:
																		if (8 <= b)
																		{
																			goto IL_091e_2;
																		}
																		goto IL_0931_2;
																		IL_091e_2:
																		num6--;
																		goto IL_1337_2;
																		IL_0931_2:
																		if (4 >= b)
																		{
																			goto IL_093f_2;
																		}
																		goto IL_0af9_2;
																		IL_093f_2:
																		if (4 <= b)
																		{
																			goto IL_094a_2;
																		}
																		goto IL_09a6_2;
																		IL_094a_2:
																		array2[num6] = 0;
																		goto IL_0958_2;
																		IL_0958_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_097b_2;
																		IL_097b_2:
																		array3[num6] = null;
																		goto IL_0985_2;
																		IL_0985_2:
																		num6++;
																		goto IL_0993_2;
																		IL_0993_2:
																		ptr2 += 8;
																		goto IL_1337_2;
																		IL_09a6_2:
																		if (2 >= b)
																		{
																			goto IL_09b4_2;
																		}
																		goto IL_0a93_2;
																		IL_09b4_2:
																		if (2 <= b)
																		{
																			goto IL_09bf_2;
																		}
																		goto IL_0a2f_2;
																		IL_09bf_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_09ff_2;
																		IL_09ff_2:
																		array2[num6 - 2] = 0;
																		goto IL_0a13_2;
																		IL_0a13_2:
																		num6--;
																		num = 21;
																		goto IL_1337_2;
																		IL_0a2f_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0a3d_2;
																		IL_0a3d_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0a4b_2;
																		IL_0a4b_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a64_2;
																		IL_0a64_2:
																		array2[num6] = 0;
																		goto IL_0a72_2;
																		IL_0a72_2:
																		num6++;
																		goto IL_0a80_2;
																		IL_0a80_2:
																		ptr2 += 8;
																		goto IL_1337_2;
																		IL_0a93_2:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_0aa1_2;
																		IL_0aa1_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0aaf_2;
																		IL_0aaf_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0ad8_2;
																		IL_0ad8_2:
																		ptr2 += 8;
																		goto IL_0ae6_2;
																		IL_0ae6_2:
																		num6--;
																		goto IL_1337_2;
																		IL_0af9_2:
																		if (6 >= b)
																		{
																			goto IL_0b07_2;
																		}
																		goto IL_0c05_2;
																		IL_0b07_2:
																		if (6 <= b)
																		{
																			goto IL_0b12_2;
																		}
																		goto IL_0b79_2;
																		IL_0b12_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b52_2;
																		IL_0b52_2:
																		array2[num6 - 2] = 0;
																		goto IL_0b66_2;
																		IL_0b66_2:
																		num6--;
																		goto IL_1337_2;
																		IL_0b79_2:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_0b87_2;
																		IL_0b87_2:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_0b95_2;
																		IL_0b95_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0bd5_2;
																		IL_0bd5_2:
																		array2[num6 - 2] = 0;
																		num = 171;
																		goto IL_0bf2_2;
																		IL_0bf2_2:
																		num6--;
																		goto IL_1337_2;
																		IL_0c05_2:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_0c13_2;
																		IL_0c13_2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0c21_2;
																		IL_0c21_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0c61_2;
																	}
																	break;
																}
																goto IL_080f_2;
																IL_0843_2:
																ptr2 += 8;
																goto IL_1337_2;
																IL_080f_2:
																array2[num6] = 5;
																goto IL_081d_2;
																IL_081d_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0835_2;
																IL_0835_2:
																num6++;
																goto IL_0843_2;
															}
															break;
														}
														goto IL_0c88_2;
														IL_12fc_2:
														if (32 < b)
														{
															break;
														}
														num = 258;
														goto IL_1310_2;
														IL_0c88_2:
														if (24 >= b)
														{
															goto IL_0c96_2;
														}
														goto IL_0fd9_2;
														IL_0c96_2:
														if (24 <= b)
														{
															goto IL_0ca1_2;
														}
														goto IL_0cf4_2;
														IL_0ca1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])();
														goto IL_0cc5_2;
														IL_0cc5_2:
														array2[num6] = 0;
														goto IL_0cd3_2;
														IL_0cd3_2:
														num6++;
														goto IL_0ce1_2;
														IL_0ce1_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_0cf4_2:
														if (20 >= b)
														{
															goto IL_0d02_2;
														}
														goto IL_0e6e_2;
														IL_0d02_2:
														if (20 <= b)
														{
															goto IL_0d0d_2;
														}
														goto IL_0d25_2;
														IL_0d0d_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1337_2;
														IL_0d25_2:
														if (18 >= b)
														{
															goto IL_0d33_2;
														}
														goto IL_0e0a_2;
														IL_0d33_2:
														if (18 <= b)
														{
															goto IL_0d3e_2;
														}
														goto IL_0d9d_2;
														IL_0d3e_2:
														array2[num6 - 1] = 5;
														goto IL_0d52_2;
														IL_0d52_2:
														array3[num6 - 1] = ((delegate*<string[], string>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_0d8a_2;
														IL_0d8a_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_0d9d_2:
														if (17 < b)
														{
															break;
														}
														goto IL_0dab_2;
														IL_0dab_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0db9_2;
														IL_0db9_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_0df7_2;
														IL_0df7_2:
														num6 -= 3;
														goto IL_1337_2;
														IL_0e0a_2:
														if (19 < b)
														{
															break;
														}
														goto IL_0e18_2;
														IL_0e18_2:
														if (19 > b)
														{
															break;
														}
														goto IL_0e26_2;
														IL_0e26_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_0e3f_2;
														IL_0e3f_2:
														array2[num6] = 1;
														goto IL_0e4d_2;
														IL_0e4d_2:
														num6++;
														goto IL_0e5b_2;
														IL_0e5b_2:
														ptr2 += 16;
														goto IL_1337_2;
														IL_0e6e_2:
														if (22 >= b)
														{
															goto IL_0e7c_2;
														}
														goto IL_0f70_2;
														IL_0e7c_2:
														if (22 <= b)
														{
															goto IL_0e87_2;
														}
														goto IL_0eec_2;
														IL_0e87_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0ed9_2;
														IL_0ed9_2:
														num6--;
														goto IL_1337_2;
														IL_0eec_2:
														if (21 < b)
														{
															break;
														}
														goto IL_0efa_2;
														IL_0efa_2:
														if (21 > b)
														{
															break;
														}
														goto IL_0f08_2;
														IL_0f08_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_0f49_2;
														IL_0f49_2:
														array2[num6 - 2] = 0;
														goto IL_0f5d_2;
														IL_0f5d_2:
														num6--;
														goto IL_1337_2;
														IL_0f70_2:
														if (23 < b)
														{
															break;
														}
														goto IL_0f7e_2;
														IL_0f7e_2:
														if (23 > b)
														{
															break;
														}
														goto IL_0f8c_2;
														IL_0f8c_2:
														array3[num6] = ((delegate*<string[]>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])();
														goto IL_0faa_2;
														IL_0faa_2:
														array2[num6] = 5;
														goto IL_0fb8_2;
														IL_0fb8_2:
														num6++;
														goto IL_0fc6_2;
														IL_0fc6_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_0fd9_2:
														if (28 >= b)
														{
															goto IL_0fe7_2;
														}
														goto IL_11cb_2;
														IL_0fe7_2:
														if (28 <= b)
														{
															goto IL_0ff2_2;
														}
														goto IL_103a_2;
														IL_0ff2_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_100b_2;
														IL_100b_2:
														array2[num6] = 3;
														goto IL_1019_2;
														IL_1019_2:
														num6++;
														goto IL_1027_2;
														IL_1027_2:
														ptr2 += 16;
														goto IL_1337_2;
														IL_103a_2:
														if (26 >= b)
														{
															goto IL_1048_2;
														}
														goto IL_115c_2;
														IL_1048_2:
														if (26 <= b)
														{
															goto IL_1056_2;
														}
														goto IL_10d7_2;
														IL_1056_2:
														array2[num6 - 2] = 5;
														goto IL_106a_2;
														IL_106a_2:
														array3[num6 - 2] = ((delegate*<string, string, string>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
														goto IL_10b6_2;
														IL_10b6_2:
														num6--;
														goto IL_10c4_2;
														IL_10c4_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_10d7_2:
														if (25 < b)
														{
															break;
														}
														goto IL_10e5_2;
														IL_10e5_2:
														if (25 > b)
														{
															break;
														}
														goto IL_10f3_2;
														IL_10f3_2:
														array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														num = 80;
														goto IL_1135_2;
														IL_1135_2:
														array2[num6 - 2] = 5;
														goto IL_1149_2;
														IL_1149_2:
														num6--;
														goto IL_1337_2;
														IL_115c_2:
														if (27 < b)
														{
															break;
														}
														num = 134;
														goto IL_1173_2;
														IL_1310_2:
														if (32 <= b)
														{
														}
														break;
														IL_1173_2:
														if (27 > b)
														{
															break;
														}
														goto IL_1181_2;
														IL_1181_2:
														((delegate*<string, void>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_11aa_2;
														IL_11aa_2:
														num6--;
														goto IL_11b8_2;
														IL_11b8_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_11cb_2:
														if (30 >= b)
														{
															goto IL_11d9_2;
														}
														goto IL_12cd_2;
														IL_11d9_2:
														if (30 > b)
														{
															goto IL_11e7_2;
														}
														goto IL_126a_2;
														IL_11e7_2:
														if (29 < b)
														{
															break;
														}
														goto IL_11f5_2;
														IL_11f5_2:
														if (29 > b)
														{
															break;
														}
														goto IL_1203_2;
														IL_1203_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1243_2;
														IL_1243_2:
														array2[num6 - 2] = 3;
														goto IL_1257_2;
														IL_1257_2:
														num6--;
														goto IL_1337_2;
														IL_126a_2:
														array2[num6 - 1] = 0;
														goto IL_127e_2;
														IL_127e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)DecoderExceptionFallbackOnDeserialization[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_12bd_2;
														IL_12bd_2:
														ptr2 += 8;
														goto IL_1337_2;
														IL_12cd_2:
														if (31 >= b)
														{
															goto IL_12d8_2;
														}
														goto IL_12fc_2;
														IL_12d8_2:
														if (31 > b)
														{
															break;
														}
														goto IL_12e3_2;
														IL_12e3_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_1337_2;
													}
													break;
													IL_051d_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											num = 68;
											goto IL_1337_2;
											continue;
											end_IL_052d_2:
											break;
										}
										continue;
										end_IL_053d:
										break;
									}
									continue;
									end_IL_054d:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_05a3_2;
					}
					continue;
					end_IL_05b1:
					break;
				}
				break;
			}
		}
	}

	public unsafe static Color smethod_1()
	{
		int num = 171;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 192;
				while (true)
				{
					int num4 = num2 * 8;
					num = 261;
					while (true)
					{
						byte[] array = new byte[3];
						num = 82;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									num = 220;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SBCSCodePageEncodingsetParameters.SEPAmWriteToUnderlyingStreamAsyncd);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 != 1)
												{
													while (true)
													{
														IL_05d5:
														byte b = *ptr2;
														while (true)
														{
															IL_05c5:
															ptr2++;
															while (true)
															{
																IL_05b5:
																if (b >= 1)
																{
																	while (b <= 35)
																	{
																		while (true)
																		{
																			IL_0595:
																			if (18 >= b)
																			{
																				while (true)
																				{
																					IL_0585:
																					if (18 > b)
																					{
																						while (true)
																						{
																							IL_0575:
																							if (9 < b)
																							{
																								while (true)
																								{
																									IL_0568:
																									if (13 < b)
																									{
																										while (true)
																										{
																											IL_0558:
																											if (15 >= b)
																											{
																												while (true)
																												{
																													IL_0548:
																													if (15 <= b)
																													{
																														while (true)
																														{
																															IL_0505:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																															while (true)
																															{
																																IL_04ef:
																																array[num6 - 2] = 0;
																																while (true)
																																{
																																	IL_04d6:
																																	num6--;
																																	num = 301;
																																	while (num != 301)
																																	{
																																		if (num != 1282)
																																		{
																																			goto end_IL_05a5;
																																		}
																																		switch (num)
																																		{
																																		case 289:
																																			goto IL_04d6;
																																		case 102:
																																			goto IL_04ef;
																																		case 108:
																																		case 287:
																																			goto IL_0505;
																																		case 179:
																																			goto IL_0548;
																																		case 169:
																																			goto IL_0558;
																																		case 293:
																																			goto IL_0568;
																																		case 168:
																																			goto IL_0575;
																																		case 174:
																																			goto IL_0585;
																																		case 275:
																																			goto IL_0595;
																																		case 163:
																																			goto IL_05a5;
																																		case 150:
																																			goto IL_05b5;
																																		case 54:
																																			goto IL_05c5;
																																		case 27:
																																		case 74:
																																			goto IL_05d5;
																																		case 33:
																																			goto IL_05e0;
																																		case 84:
																																		case 193:
																																			goto IL_05eb;
																																		case 197:
																																			goto IL_0609;
																																		case 4:
																																			goto IL_0617;
																																		case 7:
																																		case 164:
																																			goto IL_0625;
																																		case 88:
																																			goto IL_0639;
																																		case 162:
																																			goto IL_068d;
																																		case 51:
																																			goto IL_069b;
																																		case 222:
																																			goto IL_06ae;
																																		case 107:
																																			goto IL_06bc;
																																		case 56:
																																		case 223:
																																			goto IL_06cc;
																																		case 218:
																																			goto IL_06e6;
																																		case 153:
																																		case 229:
																																			goto IL_06f6;
																																		case 165:
																																			goto IL_0758;
																																		case 252:
																																			goto IL_076b;
																																		case 254:
																																			goto IL_0784;
																																		case 81:
																																			goto IL_0792;
																																		case 255:
																																			goto IL_07a5;
																																		case 264:
																																			goto IL_07b8;
																																		case 151:
																																			goto IL_07c6;
																																		case 227:
																																			goto IL_07d1;
																																		case 65:
																																		case 240:
																																			goto IL_07df;
																																		case 228:
																																			goto IL_07ed;
																																		case 112:
																																			goto IL_0810;
																																		case 126:
																																			goto IL_081f;
																																		case 175:
																																			goto IL_082d;
																																		case 187:
																																			goto IL_083b;
																																		case 130:
																																			goto IL_0852;
																																		case 26:
																																		case 116:
																																			goto IL_0869;
																																		case 11:
																																			goto IL_08a9;
																																		case 257:
																																			goto IL_08bd;
																																		case 16:
																																		case 34:
																																			goto IL_08d9;
																																		case 125:
																																			goto IL_0922;
																																		case 35:
																																			goto IL_0936;
																																		case 173:
																																			goto IL_0949;
																																		case 69:
																																			goto IL_0954;
																																		case 22:
																																			goto IL_0967;
																																		case 141:
																																			goto IL_0975;
																																		case 185:
																																		case 207:
																																			goto IL_0991;
																																		case 30:
																																			goto IL_09d1;
																																		case 0:
																																			goto IL_09e5;
																																		case 157:
																																		case 271:
																																			goto IL_0a01;
																																		case 41:
																																			goto IL_0a41;
																																		case 80:
																																			goto IL_0a55;
																																		case 277:
																																			goto IL_0a71;
																																		case 114:
																																			goto IL_0a7f;
																																		case 138:
																																		case 279:
																																			goto IL_0a92;
																																		case 284:
																																			goto IL_0aa5;
																																		case 226:
																																			goto IL_0ab3;
																																		case 45:
																																			goto IL_0aca;
																																		case 285:
																																			goto IL_0add;
																																		case 1:
																																			goto IL_0aeb;
																																		case 143:
																																		case 183:
																																			goto IL_0af6;
																																		case 20:
																																			goto IL_0b36;
																																		case 212:
																																			goto IL_0b4a;
																																		case 267:
																																			goto IL_0b5d;
																																		case 215:
																																			goto IL_0b6b;
																																		case 129:
																																		case 135:
																																			goto IL_0b79;
																																		case 113:
																																			goto IL_0b92;
																																		case 31:
																																			goto IL_0ba0;
																																		case 155:
																																			goto IL_0bae;
																																		case 25:
																																			goto IL_0bc1;
																																		case 232:
																																			goto IL_0bcf;
																																		case 21:
																																		case 142:
																																			goto IL_0bdd;
																																		case 68:
																																			goto IL_0c06;
																																		case 109:
																																			goto IL_0c14;
																																		case 291:
																																			goto IL_0c30;
																																		case 110:
																																			goto IL_0c3e;
																																		case 14:
																																		case 36:
																																			goto IL_0c4c;
																																		case 77:
																																			goto IL_0c64;
																																		case 48:
																																			goto IL_0c6f;
																																		case 15:
																																		case 106:
																																			goto IL_0c7d;
																																		case 144:
																																			goto IL_0ccf;
																																		case 216:
																																			goto IL_0ce2;
																																		case 62:
																																			goto IL_0cf0;
																																		case 18:
																																		case 250:
																																			goto IL_0cfe;
																																		case 235:
																																			goto IL_0d0c;
																																		case 92:
																																			goto IL_0d30;
																																		case 23:
																																			goto IL_0d3e;
																																		case 177:
																																			goto IL_0d51;
																																		case 5:
																																			goto IL_0d5f;
																																		case 234:
																																			goto IL_0d6d;
																																		case 186:
																																			goto IL_0d7b;
																																		case 38:
																																		case 127:
																																			goto IL_0d86;
																																		case 59:
																																			goto IL_0da2;
																																		case 6:
																																			goto IL_0db0;
																																		case 219:
																																		case 281:
																																			goto IL_0dbb;
																																		case 159:
																																			goto IL_0dfb;
																																		case 128:
																																			goto IL_0e0f;
																																		case 8:
																																			goto IL_0e22;
																																		case 43:
																																			goto IL_0e30;
																																		case 103:
																																		case 156:
																																			goto IL_0e3e;
																																		case 158:
																																			goto IL_0e7e;
																																		case 238:
																																			goto IL_0e92;
																																		case 209:
																																			goto IL_0ea5;
																																		case 167:
																																			goto IL_0eb3;
																																		case 71:
																																		case 208:
																																			goto IL_0ec1;
																																		case 172:
																																			goto IL_0ede;
																																		case 282:
																																			goto IL_0f46;
																																		case 268:
																																			goto IL_0f54;
																																		case 230:
																																			goto IL_0f67;
																																		case 120:
																																			goto IL_0f75;
																																		case 86:
																																		case 278:
																																			goto IL_0f80;
																																		case 140:
																																			goto IL_0f9e;
																																		case 46:
																																			goto IL_0fac;
																																		case 204:
																																			goto IL_0fba;
																																		case 161:
																																			goto IL_0fcd;
																																		case 118:
																																			goto IL_0fdb;
																																		case 166:
																																		case 246:
																																			goto IL_0fe9;
																																		case 217:
																																			goto IL_100d;
																																		case 61:
																																			goto IL_101b;
																																		case 97:
																																			goto IL_1032;
																																		case 269:
																																			goto IL_1045;
																																		case 274:
																																			goto IL_1050;
																																		case 123:
																																		case 145:
																																			goto IL_105e;
																																		case 79:
																																			goto IL_1088;
																																		case 122:
																																			goto IL_10a1;
																																		case 70:
																																			goto IL_10af;
																																		case 111:
																																		case 180:
																																			goto IL_10bd;
																																		case 119:
																																			goto IL_10f1;
																																		case 160:
																																		case 196:
																																			goto IL_110a;
																																		case 55:
																																			goto IL_1153;
																																		case 133:
																																			goto IL_1167;
																																		case 49:
																																			goto IL_117a;
																																		case 136:
																																			goto IL_1188;
																																		case 66:
																																		case 147:
																																			goto IL_1193;
																																		case 248:
																																			goto IL_11d3;
																																		case 152:
																																			goto IL_11e7;
																																		case 60:
																																			goto IL_11fa;
																																		case 91:
																																			goto IL_1208;
																																		case 105:
																																		case 198:
																																			goto IL_1213;
																																		case 201:
																																			goto IL_122c;
																																		case 213:
																																			goto IL_1243;
																																		case 29:
																																			goto IL_1251;
																																		case 280:
																																			goto IL_1264;
																																		case 266:
																																			goto IL_1272;
																																		case 100:
																																		case 256:
																																			goto IL_1280;
																																		case 249:
																																			goto IL_12ee;
																																		case 53:
																																			goto IL_1301;
																																		case 117:
																																			goto IL_130f;
																																		case 195:
																																		case 224:
																																			goto IL_131d;
																																		case 276:
																																			goto IL_1331;
																																		case 28:
																																			goto IL_1370;
																																		case 90:
																																			goto IL_1383;
																																		case 211:
																																			goto IL_1391;
																																		case 89:
																																		case 244:
																																			goto IL_139c;
																																		case 206:
																																			goto IL_13ba;
																																		case 184:
																																			goto IL_13c8;
																																		case 225:
																																			goto IL_13d6;
																																		case 24:
																																			goto IL_13e9;
																																		case 154:
																																			goto IL_13f7;
																																		case 260:
																																		case 294:
																																			goto IL_1405;
																																		case 247:
																																			goto IL_1419;
																																		case 137:
																																			goto IL_1458;
																																		case 178:
																																			goto IL_146b;
																																		case 258:
																																			goto IL_1476;
																																		case 272:
																																		case 290:
																																			goto IL_148d;
																																		case 3:
																																			goto IL_14ca;
																																		case 191:
																																			goto IL_14de;
																																		case 85:
																																			goto IL_14ee;
																																		case 58:
																																			goto IL_14f9;
																																		case 9:
																																		case 17:
																																		case 39:
																																		case 44:
																																		case 47:
																																		case 50:
																																		case 64:
																																		case 67:
																																		case 75:
																																		case 76:
																																		case 83:
																																		case 87:
																																		case 93:
																																		case 94:
																																		case 99:
																																		case 101:
																																		case 104:
																																		case 115:
																																		case 121:
																																		case 132:
																																		case 134:
																																		case 139:
																																		case 149:
																																		case 182:
																																		case 199:
																																		case 202:
																																		case 203:
																																		case 214:
																																		case 231:
																																		case 239:
																																		case 242:
																																		case 245:
																																		case 253:
																																		case 262:
																																		case 263:
																																		case 265:
																																		case 286:
																																		case 288:
																																			goto end_IL_05a5;
																																		case 2:
																																		case 10:
																																		case 12:
																																		case 19:
																																		case 32:
																																		case 37:
																																		case 40:
																																		case 42:
																																		case 52:
																																		case 57:
																																		case 63:
																																		case 72:
																																		case 73:
																																		case 95:
																																		case 96:
																																		case 98:
																																		case 124:
																																		case 131:
																																		case 146:
																																		case 176:
																																		case 181:
																																		case 189:
																																		case 190:
																																		case 194:
																																		case 200:
																																		case 205:
																																		case 210:
																																		case 221:
																																		case 233:
																																		case 236:
																																		case 237:
																																		case 241:
																																		case 243:
																																		case 259:
																																		case 273:
																																		case 283:
																																		case 292:
																																			goto end_IL_04c3;
																																		case 251:
																																			goto end_IL_1517;
																																		case 220:
																																			goto end_IL_152a;
																																		case 13:
																																			goto end_IL_1534;
																																		case 148:
																																		case 270:
																																			goto end_IL_153f;
																																		case 82:
																																			goto end_IL_1558;
																																		case 261:
																																			goto end_IL_1568;
																																		case 192:
																																			goto end_IL_1578;
																																		case 170:
																																			goto end_IL_1591;
																																		case 171:
																																			goto end_IL_15aa;
																																		case 78:
																																		case 188:
																																			goto IL_15ce;
																																		}
																																		continue;
																																		end_IL_04c3:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0c30;
																													IL_0c4c:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													break;
																													IL_0c30:
																													if (14 < b)
																													{
																														goto end_IL_05a5;
																													}
																													goto IL_0c3e;
																													IL_0c3e:
																													if (14 > b)
																													{
																														goto end_IL_05a5;
																													}
																													goto IL_0c4c;
																												}
																												break;
																											}
																											goto IL_0c64;
																											IL_0d3e:
																											ptr2 += 8;
																											break;
																											IL_0c64:
																											if (16 >= b)
																											{
																												goto IL_0c6f;
																											}
																											goto IL_0ce2;
																											IL_0c6f:
																											if (16 > b)
																											{
																												goto end_IL_05a5;
																											}
																											goto IL_0c7d;
																											IL_0c7d:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0ccf;
																											IL_0ccf:
																											num6--;
																											break;
																											IL_0ce2:
																											if (17 < b)
																											{
																												goto end_IL_05a5;
																											}
																											goto IL_0cf0;
																											IL_0cf0:
																											if (17 > b)
																											{
																												goto end_IL_05a5;
																											}
																											goto IL_0cfe;
																											IL_0cfe:
																											array[num6] = 3;
																											goto IL_0d0c;
																											IL_0d0c:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])();
																											goto IL_0d30;
																											IL_0d30:
																											num6++;
																											goto IL_0d3e;
																										}
																										break;
																									}
																									goto IL_05e0;
																									IL_0792:
																									if (12 > b)
																									{
																										goto end_IL_05a5;
																									}
																									break;
																									IL_05e0:
																									if (13 <= b)
																									{
																										goto IL_05eb;
																									}
																									goto IL_0609;
																									IL_05eb:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0aa5;
																									IL_0aa5:
																									array[num6] = 1;
																									goto IL_0ab3;
																									IL_0ab3:
																									num6++;
																									num = 45;
																									goto IL_0aca;
																									IL_0aca:
																									ptr2 += 16;
																									break;
																									IL_0609:
																									if (11 >= b)
																									{
																										goto IL_0617;
																									}
																									goto IL_0784;
																									IL_0617:
																									if (11 <= b)
																									{
																										goto IL_0625;
																									}
																									goto IL_06ae;
																									IL_0625:
																									array[num6 - 2] = 0;
																									goto IL_0639;
																									IL_0639:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_068d;
																									IL_068d:
																									num6--;
																									goto IL_069b;
																									IL_069b:
																									ptr2 += 8;
																									break;
																									IL_06ae:
																									if (10 < b)
																									{
																										goto end_IL_05a5;
																									}
																									goto IL_06bc;
																									IL_06bc:
																									if (10 > b)
																									{
																										goto end_IL_05a5;
																									}
																									goto IL_06f6;
																									IL_06f6:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0758;
																									IL_0758:
																									num6 -= 2;
																									break;
																									IL_0784:
																									if (12 < b)
																									{
																										goto end_IL_05a5;
																									}
																									goto IL_0792;
																								}
																								break;
																							}
																							goto IL_07b8;
																							IL_0a92:
																							num6--;
																							break;
																							IL_07b8:
																							if (9 > b)
																							{
																								goto IL_07c6;
																							}
																							num = 185;
																							goto IL_0991;
																							IL_07c6:
																							if (4 >= b)
																							{
																								goto IL_07d1;
																							}
																							goto IL_081f;
																							IL_07d1:
																							if (4 <= b)
																							{
																								goto IL_07df;
																							}
																							goto IL_0add;
																							IL_07df:
																							array[num6] = 0;
																							goto IL_07ed;
																							IL_07ed:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0810;
																							IL_0810:
																							array2[num6] = null;
																							goto IL_0a71;
																							IL_0a71:
																							num6++;
																							goto IL_0a7f;
																							IL_0a7f:
																							ptr2 += 8;
																							break;
																							IL_0add:
																							if (2 >= b)
																							{
																								goto IL_0aeb;
																							}
																							goto IL_0bc1;
																							IL_0aeb:
																							if (2 <= b)
																							{
																								goto IL_0af6;
																							}
																							goto IL_0b5d;
																							IL_0af6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0b36;
																							IL_0b36:
																							array[num6 - 2] = 0;
																							goto IL_0b4a;
																							IL_0b4a:
																							num6--;
																							break;
																							IL_0b5d:
																							if (1 < b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0b6b;
																							IL_0b6b:
																							if (1 > b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0b79;
																							IL_0b79:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0b92;
																							IL_0b92:
																							array[num6] = 0;
																							goto IL_0ba0;
																							IL_0ba0:
																							num6++;
																							goto IL_0bae;
																							IL_0bae:
																							ptr2 += 8;
																							break;
																							IL_0bc1:
																							if (3 < b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0bcf;
																							IL_0bcf:
																							if (3 > b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0bdd;
																							IL_0bdd:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0c06;
																							IL_0c06:
																							ptr2 += 8;
																							goto IL_0c14;
																							IL_0c14:
																							num6--;
																							num = 236;
																							break;
																							IL_081f:
																							if (6 >= b)
																							{
																								goto IL_082d;
																							}
																							goto IL_0949;
																							IL_082d:
																							if (6 > b)
																							{
																								goto IL_083b;
																							}
																							num = 16;
																							goto IL_08d9;
																							IL_083b:
																							if (5 < b)
																							{
																								goto end_IL_05a5;
																							}
																							num = 130;
																							goto IL_0852;
																							IL_09d1:
																							array[num6 - 2] = 0;
																							goto IL_09e5;
																							IL_0852:
																							if (5 > b)
																							{
																								goto end_IL_05a5;
																							}
																							num = 26;
																							goto IL_0869;
																							IL_09e5:
																							num6--;
																							num = 194;
																							break;
																							IL_0869:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_08a9;
																							IL_08a9:
																							array[num6 - 2] = 0;
																							goto IL_08bd;
																							IL_08bd:
																							num6--;
																							break;
																							IL_0991:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_09d1;
																							IL_08d9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							num = 125;
																							goto IL_0922;
																							IL_0922:
																							array[num6 - 2] = 0;
																							goto IL_0936;
																							IL_0936:
																							num6--;
																							break;
																							IL_0949:
																							if (7 >= b)
																							{
																								goto IL_0954;
																							}
																							goto IL_0967;
																							IL_0954:
																							if (7 > b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0a01;
																							IL_0a01:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0a41;
																							IL_0a41:
																							array[num6 - 2] = 0;
																							goto IL_0a55;
																							IL_0a55:
																							num6--;
																							num = 42;
																							break;
																							IL_0967:
																							if (8 < b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0975;
																							IL_0975:
																							if (8 > b)
																							{
																								goto end_IL_05a5;
																							}
																							goto IL_0a92;
																						}
																						break;
																					}
																					goto IL_06cc;
																					IL_07a5:
																					ptr2 += 8;
																					break;
																					IL_06cc:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																					goto IL_06e6;
																					IL_06e6:
																					array[num6] = 3;
																					goto IL_076b;
																					IL_076b:
																					num6++;
																					num = 255;
																					goto IL_07a5;
																				}
																				break;
																			}
																			goto IL_0d51;
																			IL_14ee:
																			if (35 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_14f9;
																			IL_0d51:
																			if (27 >= b)
																			{
																				goto IL_0d5f;
																			}
																			goto IL_117a;
																			IL_0d5f:
																			if (27 > b)
																			{
																				goto IL_0d6d;
																			}
																			goto IL_110a;
																			IL_0d6d:
																			if (22 >= b)
																			{
																				goto IL_0d7b;
																			}
																			goto IL_0f67;
																			IL_0d7b:
																			if (22 <= b)
																			{
																				goto IL_0d86;
																			}
																			goto IL_0da2;
																			IL_0d86:
																			byte* num7 = ptr2;
																			num5 = 1;
																			ptr2 = num7 + -200;
																			break;
																			IL_0da2:
																			if (20 >= b)
																			{
																				goto IL_0db0;
																			}
																			goto IL_0ea5;
																			IL_0db0:
																			if (20 <= b)
																			{
																				goto IL_0dbb;
																			}
																			goto IL_0e22;
																			IL_0dbb:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) % *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0dfb;
																			IL_0dfb:
																			array[num6 - 2] = 3;
																			goto IL_0e0f;
																			IL_0e0f:
																			num6--;
																			break;
																			IL_0e22:
																			if (19 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0e30;
																			IL_0e30:
																			if (19 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0e3e;
																			IL_0e3e:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0e7e;
																			IL_0e7e:
																			array[num6 - 2] = 3;
																			goto IL_0e92;
																			IL_0e92:
																			num6--;
																			break;
																			IL_0ea5:
																			if (21 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0eb3;
																			IL_0eb3:
																			if (21 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0ec1;
																			IL_0ec1:
																			array[num6 - 3] = 4;
																			num = 172;
																			goto IL_0ede;
																			IL_0ede:
																			array2[num6 - 3] = ((delegate*<float, float, float, Color>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																			goto IL_0f46;
																			IL_0f46:
																			num6 -= 2;
																			goto IL_0f54;
																			IL_0f54:
																			ptr2 += 8;
																			break;
																			IL_0f67:
																			if (24 >= b)
																			{
																				goto IL_0f75;
																			}
																			goto IL_1045;
																			IL_0f75:
																			if (24 <= b)
																			{
																				goto IL_0f80;
																			}
																			goto IL_0fcd;
																			IL_0f80:
																			array2[num6] = ((delegate*<string[]>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])();
																			goto IL_0f9e;
																			IL_0f9e:
																			array[num6] = 5;
																			goto IL_0fac;
																			IL_0fac:
																			num6++;
																			goto IL_0fba;
																			IL_0fba:
																			ptr2 += 8;
																			break;
																			IL_0fcd:
																			if (23 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0fdb;
																			IL_0fdb:
																			if (23 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_0fe9;
																			IL_0fe9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])();
																			goto IL_100d;
																			IL_100d:
																			array[num6] = 0;
																			goto IL_101b;
																			IL_101b:
																			num6++;
																			num = 97;
																			goto IL_1032;
																			IL_1032:
																			ptr2 += 8;
																			break;
																			IL_1045:
																			if (25 >= b)
																			{
																				goto IL_1050;
																			}
																			goto IL_10a1;
																			IL_1050:
																			if (25 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_105e;
																			IL_105e:
																			*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((string[])array2[num6 - 1]).LongLength;
																			goto IL_1088;
																			IL_1088:
																			array[num6 - 1] = 2;
																			break;
																			IL_10a1:
																			if (26 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_10af;
																			IL_10af:
																			if (26 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_10bd;
																			IL_10bd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			num = 119;
																			goto IL_10f1;
																			IL_10f1:
																			array[num6 - 1] = 0;
																			break;
																			IL_110a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 55;
																			goto IL_1153;
																			IL_1153:
																			array[num6 - 2] = 0;
																			goto IL_1167;
																			IL_1167:
																			num6--;
																			break;
																			IL_117a:
																			if (31 >= b)
																			{
																				goto IL_1188;
																			}
																			goto IL_1383;
																			IL_1188:
																			if (31 <= b)
																			{
																				goto IL_1193;
																			}
																			goto IL_11fa;
																			IL_1193:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_11d3;
																			IL_11d3:
																			array[num6 - 2] = 3;
																			goto IL_11e7;
																			IL_11e7:
																			num6--;
																			break;
																			IL_11fa:
																			if (29 >= b)
																			{
																				goto IL_1208;
																			}
																			goto IL_1301;
																			IL_1208:
																			if (29 <= b)
																			{
																				goto IL_1213;
																			}
																			goto IL_1264;
																			IL_1213:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																			goto IL_122c;
																			IL_122c:
																			array[num6] = 3;
																			num = 213;
																			goto IL_1243;
																			IL_1243:
																			num6++;
																			goto IL_1251;
																			IL_1251:
																			ptr2 += 16;
																			break;
																			IL_1264:
																			if (28 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_1272;
																			IL_1272:
																			if (28 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_1280;
																			IL_1280:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_12ee;
																			IL_12ee:
																			num6 -= 2;
																			break;
																			IL_1301:
																			if (30 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_130f;
																			IL_130f:
																			if (30 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_131d;
																			IL_131d:
																			array[num6 - 1] = 3;
																			goto IL_1331;
																			IL_1331:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_1370;
																			IL_1370:
																			ptr2 += 8;
																			break;
																			IL_1383:
																			if (33 >= b)
																			{
																				goto IL_1391;
																			}
																			goto IL_146b;
																			IL_1391:
																			if (33 <= b)
																			{
																				goto IL_139c;
																			}
																			goto IL_13e9;
																			IL_139c:
																			array2[num6] = ((delegate*<Color[]>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])();
																			goto IL_13ba;
																			IL_13ba:
																			array[num6] = 5;
																			goto IL_13c8;
																			IL_13c8:
																			num6++;
																			goto IL_13d6;
																			IL_13d6:
																			ptr2 += 8;
																			break;
																			IL_13e9:
																			if (32 < b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_13f7;
																			IL_13f7:
																			if (32 > b)
																			{
																				goto end_IL_05a5;
																			}
																			goto IL_1405;
																			IL_1405:
																			array[num6 - 1] = 0;
																			goto IL_1419;
																			IL_1419:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)FormatJapaneseFirstYearAsANumbergetXsdType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			goto IL_1458;
																			IL_1458:
																			ptr2 += 8;
																			break;
																			IL_146b:
																			if (34 >= b)
																			{
																				goto IL_1476;
																			}
																			goto IL_14ee;
																			IL_1476:
																			if (34 > b)
																			{
																				goto end_IL_05a5;
																			}
																			num = 290;
																			goto IL_148d;
																			IL_14f9:
																			if (35 <= b)
																			{
																			}
																			goto end_IL_05a5;
																			IL_148d:
																			array2[num6 - 2] = ((Color[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																			goto IL_14ca;
																			IL_14ca:
																			array[num6 - 2] = 4;
																			goto IL_14de;
																			IL_14de:
																			num6--;
																			break;
																		}
																		goto end_IL_05b5;
																		continue;
																		end_IL_05a5:
																		break;
																		IL_05a5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_05b5:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_15ce;
												IL_15ce:
												return (Color)array2[num6 - 1];
												continue;
												end_IL_1517:
												break;
											}
											continue;
											end_IL_152a:
											break;
										}
										continue;
										end_IL_1534:
										break;
									}
									continue;
									end_IL_153f:
									break;
								}
								continue;
								end_IL_1558:
								break;
							}
							continue;
							end_IL_1568:
							break;
						}
						continue;
						end_IL_1578:
						break;
					}
					continue;
					end_IL_1591:
					break;
				}
				continue;
				end_IL_15aa:
				break;
			}
		}
	}

	public Class140()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class140()
	{
		//The blocks IL_03c4, IL_03cb, IL_044e, IL_0457, IL_0460, IL_046e, IL_047c, IL_048a, IL_0498, IL_04a6, IL_04b4, IL_04c2, IL_04d0, IL_04db, IL_04f0, IL_0503, IL_050e, IL_0521, IL_052f, IL_053d, IL_0552, IL_0565, IL_0570, IL_057e, IL_0587, IL_059c, IL_05af, IL_05bd, IL_05cb, IL_05e9, IL_05fc, IL_0611, IL_0624, IL_0632, IL_063d, IL_064b, IL_0659, IL_0682, IL_069b, IL_06a6, IL_06e6, IL_0703, IL_0716, IL_0724, IL_0732, IL_074b, IL_0759, IL_0767, IL_077a, IL_0788, IL_0793, IL_07a1, IL_07bf, IL_07d2, IL_07e0, IL_07ee, IL_080b, IL_085a, IL_0864, IL_0891, IL_08a5, IL_08b3, IL_08c6, IL_08cf, IL_08ed, IL_08fb, IL_090e, IL_0926, IL_0944, IL_0968, IL_0980, IL_099c, IL_09aa, IL_09b5, IL_09de, IL_09f7, IL_0a05, IL_0a10, IL_0a1e, IL_0a38, IL_0a54, IL_0a62, IL_0a70, IL_0a89, IL_0a9c, IL_0aaa, IL_0ab5, IL_0ac3, IL_0ad1, IL_0ae9, IL_0af7, IL_0b0a, IL_0b18, IL_0b26, IL_0b64, IL_0b77, IL_0b8b, IL_0bc3, IL_0bd6, IL_0be4, IL_0bef, IL_0c09, IL_0c17, IL_0c25, IL_0c38, IL_0c43, IL_0c51, IL_0c5f, IL_0c82, IL_0c99, IL_0cb5, IL_0cc3, IL_0cd1, IL_0d13, IL_0d26, IL_0d34, IL_0d3f, IL_0d58, IL_0d6b, IL_0d79, IL_0d87, IL_0d9b, IL_0e13, IL_0e21, IL_0e3a, IL_0e45, IL_0e50, IL_0e69, IL_0e7e, IL_0e95 are reachable both inside and outside the pinned region starting at IL_03b5. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 23;
		Class296.Aw4EYyy3h();
		num = 22;
		Class300.smethod_0();
		int num3 = default(int);
		object[] array2 = default(object[]);
		int num4 = default(int);
		long[] array3 = default(long[]);
		byte[] array4 = default(byte[]);
		int[] array5 = default(int[]);
		object[] array6 = default(object[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		object[] array7;
		int num6;
		byte* num7;
		byte* num9;
		int num10;
		byte* ptr = default(byte*);
		byte b = default(byte);
		while (true)
		{
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0397:
					int num2 = 1;
					num = 222;
					while (true)
					{
						if (num != 222)
						{
							if (num != 1203)
							{
								goto IL_047c;
							}
							switch (num)
							{
							case 161:
								break;
							default:
								continue;
							case 115:
								goto IL_0397;
							case 42:
								break;
							case 85:
								break;
							case 102:
								break;
							case 22:
								Class300.smethod_0();
								break;
							case 23:
								Class296.Aw4EYyy3h();
								num = 22;
								goto case 22;
							case 9:
							case 51:
								goto IL_03e9;
							case 93:
								goto IL_0400;
							case 197:
								goto IL_040e;
							case 58:
								goto IL_041c;
							case 37:
								goto IL_042a;
							case 86:
								goto IL_0438;
							case 176:
								goto IL_0441;
							case 125:
								goto IL_044e;
							case 63:
								goto IL_0457;
							case 186:
								goto IL_0460;
							case 40:
								goto IL_046e;
							case 114:
								goto IL_047c;
							case 175:
								goto IL_048a;
							case 189:
								goto IL_0498;
							case 148:
								goto IL_04a6;
							case 27:
								goto IL_04b4;
							case 158:
								goto IL_04c2;
							case 24:
								goto IL_04d0;
							case 83:
							case 213:
								goto IL_04db;
							case 101:
								goto IL_04f0;
							case 38:
								goto IL_0503;
							case 155:
								goto IL_050e;
							case 154:
								goto IL_0521;
							case 17:
								goto IL_052f;
							case 14:
							case 95:
								goto IL_053d;
							case 178:
								goto IL_0552;
							case 12:
								goto IL_0565;
							case 28:
								goto IL_0570;
							case 151:
							case 207:
								goto IL_0587;
							case 33:
								goto IL_059c;
							case 157:
								goto IL_05af;
							case 139:
								goto IL_05bd;
							case 80:
							case 90:
								goto IL_05cb;
							case 153:
								goto IL_05e9;
							case 8:
							case 47:
								goto IL_05fc;
							case 122:
								goto IL_0611;
							case 164:
								goto IL_0624;
							case 106:
								goto IL_0632;
							case 108:
								goto IL_063d;
							case 91:
								goto IL_064b;
							case 144:
							case 152:
								goto IL_0659;
							case 74:
								goto IL_0682;
							case 127:
								goto IL_069b;
							case 72:
							case 136:
								goto IL_06a6;
							case 182:
								goto IL_06e6;
							case 82:
								goto IL_0703;
							case 54:
								goto IL_0716;
							case 130:
								goto IL_0724;
							case 30:
							case 69:
								goto IL_0732;
							case 146:
								goto IL_074b;
							case 45:
								goto IL_0759;
							case 32:
								goto IL_0767;
							case 53:
								goto IL_077a;
							case 3:
								goto IL_0788;
							case 187:
								goto IL_0793;
							case 56:
							case 194:
								goto IL_07a1;
							case 132:
								goto IL_07bf;
							case 1:
								goto IL_07d2;
							case 166:
								goto IL_07e0;
							case 26:
							case 62:
								goto IL_07ee;
							case 203:
								goto IL_08a5;
							case 198:
								goto IL_08b3;
							case 99:
							case 211:
								goto IL_08cf;
							case 100:
								goto IL_08ed;
							case 97:
								goto IL_08fb;
							case 123:
							case 133:
								goto IL_090e;
							case 36:
								goto IL_0926;
							case 94:
								goto IL_0944;
							case 172:
								goto IL_0968;
							case 87:
								goto IL_0980;
							case 60:
								goto IL_099c;
							case 50:
								goto IL_09aa;
							case 196:
							case 200:
								goto IL_09b5;
							case 20:
								goto IL_09de;
							case 131:
								goto IL_09f7;
							case 15:
								goto IL_0a05;
							case 70:
								goto IL_0a10;
							case 104:
							case 145:
								goto IL_0a1e;
							case 79:
								goto IL_0a38;
							case 191:
								goto IL_0a54;
							case 67:
								goto IL_0a62;
							case 105:
							case 112:
								goto IL_0a70;
							case 109:
								goto IL_0a89;
							case 113:
								goto IL_0a9c;
							case 121:
								goto IL_0aaa;
							case 55:
								goto IL_0ab5;
							case 173:
							case 174:
								goto IL_0ac3;
							case 39:
								goto IL_0ad1;
							case 126:
								goto IL_0ae9;
							case 2:
								goto IL_0af7;
							case 98:
								goto IL_0b0a;
							case 34:
								goto IL_0b18;
							case 6:
							case 192:
								goto IL_0b26;
							case 46:
								goto IL_0b64;
							case 84:
							case 143:
								goto IL_0b77;
							case 165:
								goto IL_0b8b;
							case 140:
								goto IL_0bc3;
							case 156:
								goto IL_0bd6;
							case 188:
								goto IL_0be4;
							case 61:
							case 206:
								goto IL_0bef;
							case 31:
								goto IL_0c09;
							case 212:
								goto IL_0c17;
							case 52:
								goto IL_0c25;
							case 171:
								goto IL_0c38;
							case 19:
								goto IL_0c43;
							case 119:
							case 199:
								goto IL_0c51;
							case 201:
								goto IL_0c5f;
							case 205:
								goto IL_0c82;
							case 209:
								goto IL_0c99;
							case 21:
								goto IL_0cb5;
							case 193:
								goto IL_0cc3;
							case 7:
							case 117:
								goto IL_0cd1;
							case 150:
								goto IL_0d13;
							case 110:
								goto IL_0d26;
							case 167:
								goto IL_0d34;
							case 4:
							case 162:
								goto IL_0d3f;
							case 215:
								goto IL_0d58;
							case 120:
								goto IL_0d6b;
							case 141:
								goto IL_0d79;
							case 96:
							case 103:
								goto IL_0d87;
							case 66:
								goto IL_0d9b;
							case 149:
								goto IL_0e13;
							case 78:
								goto IL_0e21;
							case 163:
								goto IL_0e3a;
							case 214:
								goto IL_0e45;
							case 68:
							case 160:
								goto IL_0e50;
							case 0:
							case 5:
							case 11:
							case 13:
							case 16:
							case 25:
							case 29:
							case 41:
							case 44:
							case 64:
							case 65:
							case 81:
							case 89:
							case 92:
							case 129:
							case 134:
							case 137:
							case 138:
							case 168:
							case 179:
							case 180:
							case 181:
							case 184:
							case 185:
							case 190:
							case 195:
							case 204:
							case 208:
								goto IL_0e69;
							case 170:
								goto IL_0e7e;
							case 10:
							case 18:
							case 35:
							case 43:
							case 48:
							case 49:
							case 57:
							case 59:
							case 71:
							case 73:
							case 75:
							case 76:
							case 77:
							case 88:
							case 107:
							case 118:
							case 124:
							case 128:
							case 135:
							case 142:
							case 147:
							case 159:
							case 169:
							case 177:
							case 183:
							case 202:
							case 210:
								goto IL_0e95;
							case 111:
							case 116:
								return;
							}
							break;
						}
						num3 = num2 * 4;
						goto IL_03e9;
						IL_0d9b:
						array2[num4 - 4] = ((delegate*<float, float, float, float, object>)getExportablegetOut[*(int*)(ptr + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])));
						goto IL_0e13;
						IL_0e21:
						ptr += 8;
						num = 75;
						goto IL_0e95;
						IL_0e13:
						num4 -= 3;
						goto IL_0e21;
						IL_03e9:
						array4 = new byte[7];
						num = 93;
						goto IL_0400;
						IL_0400:
						array2 = new object[7];
						goto IL_040e;
						IL_040e:
						array5 = new int[7];
						goto IL_041c;
						IL_041c:
						array3 = new long[7];
						goto IL_042a;
						IL_042a:
						array6 = new object[36];
						goto IL_0438;
						IL_0438:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsFlowSuppressedDateWordToken.LdfldgetChannelScheme);
						goto IL_0441;
						IL_0441:
						ptr = ptr2;
						goto IL_0e95;
						IL_0e95:
						if (num5 == 1)
						{
							return;
						}
						goto IL_044e;
						IL_044e:
						num = 63;
						goto IL_0457;
						IL_0457:
						b = *ptr;
						goto IL_0460;
						IL_0460:
						ptr++;
						goto IL_046e;
						IL_046e:
						if (b >= 1)
						{
							goto IL_047c;
						}
						goto IL_0e69;
						IL_047c:
						if (b <= 25)
						{
							goto IL_048a;
						}
						goto IL_0e69;
						IL_048a:
						if (13 >= b)
						{
							goto IL_0498;
						}
						goto IL_099c;
						IL_0498:
						if (13 > b)
						{
							goto IL_04a6;
						}
						goto IL_090e;
						IL_04a6:
						if (6 >= b)
						{
							goto IL_04b4;
						}
						goto IL_0624;
						IL_04b4:
						if (6 > b)
						{
							goto IL_04c2;
						}
						goto IL_05fc;
						IL_04c2:
						if (3 >= b)
						{
							goto IL_04d0;
						}
						goto IL_0565;
						IL_04d0:
						if (3 <= b)
						{
							goto IL_04db;
						}
						goto IL_0503;
						IL_04db:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_04f0;
						IL_04f0:
						ptr += 8;
						goto IL_0e95;
						IL_0503:
						if (1 >= b)
						{
							goto IL_050e;
						}
						goto IL_0521;
						IL_050e:
						if (1 > b)
						{
						}
						goto IL_0e69;
						IL_0521:
						if (2 >= b)
						{
							goto IL_052f;
						}
						goto IL_0e69;
						IL_052f:
						if (2 <= b)
						{
							goto IL_053d;
						}
						goto IL_0e69;
						IL_053d:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_0552;
						IL_0552:
						ptr += 8;
						goto IL_0e95;
						IL_0565:
						if (4 >= b)
						{
							goto IL_0570;
						}
						goto IL_05af;
						IL_0570:
						if (4 <= b)
						{
							num = 207;
							goto IL_0587;
						}
						goto IL_0e69;
						IL_0e3a:
						if (25 >= b)
						{
							goto IL_0e45;
						}
						goto IL_0e69;
						IL_0587:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_059c;
						IL_059c:
						ptr += 8;
						goto IL_0e95;
						IL_05af:
						if (5 >= b)
						{
							goto IL_05bd;
						}
						goto IL_0e69;
						IL_05bd:
						if (5 <= b)
						{
							goto IL_05cb;
						}
						goto IL_0e69;
						IL_05cb:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						num = 153;
						goto IL_05e9;
						IL_05e9:
						ptr += 8;
						goto IL_0e95;
						IL_05fc:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_0611;
						IL_0611:
						ptr += 8;
						goto IL_0e95;
						IL_0624:
						if (9 < b)
						{
							goto IL_0632;
						}
						goto IL_077a;
						IL_0632:
						if (11 < b)
						{
							goto IL_063d;
						}
						goto IL_069b;
						IL_063d:
						if (12 >= b)
						{
							goto IL_064b;
						}
						goto IL_0e69;
						IL_064b:
						if (12 <= b)
						{
							goto IL_0659;
						}
						goto IL_0e69;
						IL_0659:
						array2[num4 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])];
						goto IL_0682;
						IL_0682:
						array4[num4 - 1] = 5;
						goto IL_0e95;
						IL_069b:
						if (11 <= b)
						{
							goto IL_06a6;
						}
						goto IL_0716;
						IL_06a6:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						goto IL_06e6;
						IL_06e6:
						array4[num4 - 2] = 0;
						num = 82;
						goto IL_0703;
						IL_0703:
						num4--;
						goto IL_0e95;
						IL_0716:
						if (10 >= b)
						{
							goto IL_0724;
						}
						goto IL_0e69;
						IL_0724:
						if (10 <= b)
						{
							goto IL_0732;
						}
						goto IL_0e69;
						IL_0732:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
						goto IL_074b;
						IL_074b:
						array4[num4] = 0;
						goto IL_0759;
						IL_0759:
						num4++;
						goto IL_0767;
						IL_0767:
						ptr += 8;
						goto IL_0e95;
						IL_077a:
						if (9 > b)
						{
							goto IL_0788;
						}
						num = 211;
						goto IL_08cf;
						IL_0788:
						if (7 >= b)
						{
							goto IL_0793;
						}
						goto IL_07d2;
						IL_0793:
						if (7 <= b)
						{
							goto IL_07a1;
						}
						goto IL_0e69;
						IL_07a1:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						num = 132;
						goto IL_07bf;
						IL_07bf:
						ptr += 8;
						goto IL_0e95;
						IL_07d2:
						if (8 >= b)
						{
							goto IL_07e0;
						}
						goto IL_0e69;
						IL_07e0:
						if (8 <= b)
						{
							goto IL_07ee;
						}
						goto IL_0e69;
						IL_07ee:
						array7 = array2;
						num6 = num4;
						if (array == null)
						{
							goto end_IL_03ab;
						}
						num7 = ptr;
						byte b2 = *num7;
						ptr = num7 + 4;
						int num8 = *(int*)(ptr + num3);
						ptr += 8;
						byte* ptr3 = ptr + num8;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr != ptr3)
						{
							*ptr4 = (byte)(*ptr ^ b2);
							ptr++;
							ptr4++;
						}
						array7[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						goto IL_08a5;
						IL_0e50:
						num9 = ptr;
						num10 = -200;
						num5 = 1;
						ptr = num9 + num10;
						goto IL_0e95;
						IL_0e69:
						((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_0e7e;
						IL_0e7e:
						ptr += 8;
						num = 73;
						goto IL_0e95;
						IL_08a5:
						array4[num4] = 5;
						goto IL_08b3;
						IL_08b3:
						num4++;
						goto IL_0e95;
						IL_0e45:
						if (25 <= b)
						{
							goto IL_0e50;
						}
						goto IL_0e69;
						IL_08cf:
						array6[*(int*)(ptr + num3)] = array2[num4 - 1];
						goto IL_08ed;
						IL_08ed:
						ptr += 8;
						goto IL_08fb;
						IL_08fb:
						num4--;
						goto IL_0e95;
						IL_090e:
						array4[num4] = array4[num4 - 1];
						goto IL_0926;
						IL_0926:
						array5[num4 - 0] = array5[num4 - 1];
						goto IL_0944;
						IL_0944:
						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						goto IL_0968;
						IL_0968:
						array2[num4] = array2[num4 - 1];
						goto IL_0980;
						IL_0980:
						num4++;
						num = 183;
						goto IL_0e95;
						IL_099c:
						if (19 >= b)
						{
							goto IL_09aa;
						}
						goto IL_0bd6;
						IL_09aa:
						if (19 <= b)
						{
							goto IL_09b5;
						}
						goto IL_09f7;
						IL_09b5:
						array2[num4 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])];
						goto IL_09de;
						IL_09de:
						array4[num4 - 1] = 5;
						goto IL_0e95;
						IL_09f7:
						if (16 < b)
						{
							goto IL_0a05;
						}
						goto IL_0a9c;
						IL_0a05:
						if (17 >= b)
						{
							goto IL_0a10;
						}
						goto IL_0a54;
						IL_0a10:
						if (17 <= b)
						{
							goto IL_0a1e;
						}
						goto IL_0e69;
						IL_0a1e:
						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
						goto IL_0a38;
						IL_0a38:
						num4--;
						num = 177;
						goto IL_0e95;
						IL_0a54:
						if (18 >= b)
						{
							goto IL_0a62;
						}
						goto IL_0e69;
						IL_0a62:
						if (18 <= b)
						{
							goto IL_0a70;
						}
						goto IL_0e69;
						IL_0a70:
						string_0 = (string[])array2[num4 - 1];
						goto IL_0a89;
						IL_0a89:
						num4--;
						goto IL_0e95;
						IL_0a9c:
						if (16 > b)
						{
							goto IL_0aaa;
						}
						goto IL_0b77;
						IL_0aaa:
						if (14 >= b)
						{
							goto IL_0ab5;
						}
						goto IL_0b0a;
						IL_0ab5:
						if (14 <= b)
						{
							goto IL_0ac3;
						}
						goto IL_0e69;
						IL_0ac3:
						array4[num4] = 5;
						goto IL_0ad1;
						IL_0ad1:
						array2[num4] = array6[*(int*)(ptr + num3)];
						goto IL_0ae9;
						IL_0ae9:
						num4++;
						goto IL_0af7;
						IL_0af7:
						ptr += 8;
						goto IL_0e95;
						IL_0b0a:
						if (15 >= b)
						{
							goto IL_0b18;
						}
						goto IL_0e69;
						IL_0b18:
						if (15 <= b)
						{
							goto IL_0b26;
						}
						goto IL_0e69;
						IL_0b26:
						((string[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])] = (string)array2[num4 - 1];
						goto IL_0b64;
						IL_0b64:
						num4 -= 3;
						goto IL_0e95;
						IL_0b77:
						array4[num4 - 1] = 5;
						goto IL_0b8b;
						IL_0b8b:
						array2[num4 - 1] = ((delegate*<string[], string>)getExportablegetOut[*(int*)(ptr + num3)])((string[])array2[num4 - 1]);
						goto IL_0bc3;
						IL_0bc3:
						ptr += 8;
						goto IL_0e95;
						IL_0bd6:
						if (22 >= b)
						{
							goto IL_0be4;
						}
						goto IL_0d26;
						IL_0be4:
						if (22 <= b)
						{
							goto IL_0bef;
						}
						goto IL_0c38;
						IL_0bef:
						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(float*)(ptr + num3);
						goto IL_0c09;
						IL_0c09:
						array4[num4] = 3;
						goto IL_0c17;
						IL_0c17:
						num4++;
						goto IL_0c25;
						IL_0c25:
						ptr += 8;
						goto IL_0e95;
						IL_0c38:
						if (20 >= b)
						{
							goto IL_0c43;
						}
						goto IL_0cb5;
						IL_0c43:
						if (20 <= b)
						{
							goto IL_0c51;
						}
						goto IL_0e69;
						IL_0c51:
						array4[num4] = 4;
						goto IL_0c5f;
						IL_0c5f:
						array2[num4] = ((delegate*<Color>)getExportablegetOut[*(int*)(ptr + num3)])();
						goto IL_0c82;
						IL_0c82:
						num4++;
						num = 209;
						goto IL_0c99;
						IL_0c99:
						ptr += 8;
						num = 43;
						goto IL_0e95;
						IL_0cb5:
						if (21 >= b)
						{
							goto IL_0cc3;
						}
						goto IL_0e69;
						IL_0cc3:
						if (21 <= b)
						{
							goto IL_0cd1;
						}
						goto IL_0e69;
						IL_0cd1:
						((Color[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])] = (Color)array2[num4 - 1];
						goto IL_0d13;
						IL_0d13:
						num4 -= 3;
						goto IL_0e95;
						IL_0d26:
						if (24 >= b)
						{
							goto IL_0d34;
						}
						goto IL_0e3a;
						IL_0d34:
						if (24 <= b)
						{
							goto IL_0d3f;
						}
						goto IL_0d6b;
						IL_0d3f:
						color_0 = (Color[])array2[num4 - 1];
						goto IL_0d58;
						IL_0d58:
						num4--;
						goto IL_0e95;
						IL_0d6b:
						if (23 >= b)
						{
							goto IL_0d79;
						}
						goto IL_0e69;
						IL_0d79:
						if (23 <= b)
						{
							goto IL_0d87;
						}
						goto IL_0e69;
						IL_0d87:
						array4[num4 - 4] = 5;
						goto IL_0d9b;
					}
					break;
				}
			}
			continue;
			end_IL_03ab:
			break;
		}
		while (true)
		{
			byte[] array = new byte[4];
			do
			{
				num7 = ptr;
				byte b2 = *num7;
				ptr = num7 + 4;
				int num8 = *(int*)(ptr + num3);
				ptr += 8;
				byte* ptr3 = ptr + num8;
				byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
				while (ptr != ptr3)
				{
					*ptr4 = (byte)(*ptr ^ b2);
					ptr++;
					ptr4++;
				}
				array7[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
				array4[num4] = 5;
				num4++;
				while (true)
				{
					if (num5 == 1)
					{
						return;
					}
					num = 63;
					b = *ptr;
					ptr++;
					if (b >= 1 && b <= 25)
					{
						if (13 >= b)
						{
							if (13 <= b)
							{
								array4[num4] = array4[num4 - 1];
								array5[num4 - 0] = array5[num4 - 1];
								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								array2[num4] = array2[num4 - 1];
								num4++;
								num = 183;
								continue;
							}
							if (6 >= b)
							{
								if (6 <= b)
								{
									((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
									ptr += 8;
									continue;
								}
								if (3 >= b)
								{
									if (3 <= b)
									{
										((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
										ptr += 8;
										continue;
									}
									if (1 >= b)
									{
										if (1 > b)
										{
										}
									}
									else if (2 >= b && 2 <= b)
									{
										((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
										ptr += 8;
										continue;
									}
								}
								else if (4 >= b)
								{
									if (4 <= b)
									{
										num = 207;
										((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
										ptr += 8;
										continue;
									}
								}
								else if (5 >= b && 5 <= b)
								{
									((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
									num = 153;
									ptr += 8;
									continue;
								}
							}
							else if (9 < b)
							{
								if (11 < b)
								{
									if (12 >= b && 12 <= b)
									{
										array2[num4 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])];
										array4[num4 - 1] = 5;
										continue;
									}
								}
								else
								{
									if (11 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
										array4[num4 - 2] = 0;
										num = 82;
										num4--;
										continue;
									}
									if (10 >= b && 10 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
										array4[num4] = 0;
										num4++;
										ptr += 8;
										continue;
									}
								}
							}
							else
							{
								if (9 <= b)
								{
									num = 211;
									array6[*(int*)(ptr + num3)] = array2[num4 - 1];
									ptr += 8;
									num4--;
									continue;
								}
								if (7 >= b)
								{
									if (7 <= b)
									{
										((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
										num = 132;
										ptr += 8;
										continue;
									}
								}
								else if (8 >= b && 8 <= b)
								{
									break;
								}
							}
						}
						else if (19 >= b)
						{
							if (19 <= b)
							{
								array2[num4 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])];
								array4[num4 - 1] = 5;
								continue;
							}
							if (16 < b)
							{
								if (17 >= b)
								{
									if (17 <= b)
									{
										int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
										num4--;
										num = 177;
										continue;
									}
								}
								else if (18 >= b && 18 <= b)
								{
									string_0 = (string[])array2[num4 - 1];
									num4--;
									continue;
								}
							}
							else
							{
								if (16 <= b)
								{
									array4[num4 - 1] = 5;
									array2[num4 - 1] = ((delegate*<string[], string>)getExportablegetOut[*(int*)(ptr + num3)])((string[])array2[num4 - 1]);
									ptr += 8;
									continue;
								}
								if (14 >= b)
								{
									if (14 <= b)
									{
										array4[num4] = 5;
										array2[num4] = array6[*(int*)(ptr + num3)];
										num4++;
										ptr += 8;
										continue;
									}
								}
								else if (15 >= b && 15 <= b)
								{
									((string[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])] = (string)array2[num4 - 1];
									num4 -= 3;
									continue;
								}
							}
						}
						else if (22 >= b)
						{
							if (22 <= b)
							{
								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(float*)(ptr + num3);
								array4[num4] = 3;
								num4++;
								ptr += 8;
								continue;
							}
							if (20 >= b)
							{
								if (20 <= b)
								{
									array4[num4] = 4;
									array2[num4] = ((delegate*<Color>)getExportablegetOut[*(int*)(ptr + num3)])();
									num4++;
									num = 209;
									ptr += 8;
									num = 43;
									continue;
								}
							}
							else if (21 >= b && 21 <= b)
							{
								((Color[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])] = (Color)array2[num4 - 1];
								num4 -= 3;
								continue;
							}
						}
						else if (24 >= b)
						{
							if (24 <= b)
							{
								color_0 = (Color[])array2[num4 - 1];
								num4--;
								continue;
							}
							if (23 >= b && 23 <= b)
							{
								array4[num4 - 4] = 5;
								array2[num4 - 4] = ((delegate*<float, float, float, float, object>)getExportablegetOut[*(int*)(ptr + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1])));
								num4 -= 3;
								ptr += 8;
								num = 75;
								continue;
							}
						}
						else if (25 >= b && 25 <= b)
						{
							num9 = ptr;
							num10 = -200;
							num5 = 1;
							ptr = num9 + num10;
							continue;
						}
					}
					((delegate*<void>)getExportablegetOut[*(int*)(ptr + num3)])();
					ptr += 8;
					num = 73;
				}
				array7 = array2;
				num6 = num4;
			}
			while (array != null);
		}
	}

	private unsafe static int smethod_2(int int_3, int int_4)
	{
		int num = 110;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									num = 113;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref fVersionedgetPercentGroupSeparator.UnsafeLoadFromAlgorithmType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0349:
															byte b = *ptr2;
															while (true)
															{
																IL_0339:
																ptr2++;
																while (true)
																{
																	IL_0329:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0309:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_02e9:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02d9:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_02c9:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (true)
																													{
																														IL_02a6:
																														if (2 <= b)
																														{
																															while (true)
																															{
																																IL_022a:
																																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																num = 130;
																																while (true)
																																{
																																	if (num != 130)
																																	{
																																		if (num != 1111)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 26:
																																		case 30:
																																			goto IL_022a;
																																		case 60:
																																			goto IL_02a6;
																																		case 44:
																																			goto IL_02b9;
																																		case 4:
																																			goto IL_02c9;
																																		case 25:
																																			goto IL_02d9;
																																		case 33:
																																			goto IL_02e9;
																																		case 70:
																																			goto IL_02f9;
																																		case 85:
																																			goto IL_0309;
																																		case 75:
																																			goto IL_0319;
																																		case 103:
																																			goto IL_0329;
																																		case 89:
																																			goto IL_0339;
																																		case 94:
																																		case 95:
																																			goto IL_0349;
																																		case 16:
																																			goto IL_0375;
																																		case 67:
																																		case 104:
																																			goto IL_0388;
																																		case 79:
																																			goto IL_03c8;
																																		case 56:
																																			goto IL_03dc;
																																		case 18:
																																		case 72:
																																			goto IL_03ef;
																																		case 28:
																																			goto IL_03fa;
																																		case 68:
																																		case 90:
																																			goto IL_0408;
																																		case 40:
																																			goto IL_0431;
																																		case 112:
																																			goto IL_043f;
																																		case 76:
																																			goto IL_0452;
																																		case 73:
																																			goto IL_045d;
																																		case 31:
																																		case 45:
																																			goto IL_0468;
																																		case 88:
																																			goto IL_049c;
																																		case 54:
																																		case 82:
																																			goto IL_04b3;
																																		case 34:
																																		case 80:
																																			goto IL_04be;
																																		case 53:
																																			goto IL_04cc;
																																		case 17:
																																		case 123:
																																			goto IL_04da;
																																		case 106:
																																			goto IL_04f6;
																																		case 3:
																																		case 29:
																																			goto IL_0501;
																																		case 66:
																																			goto IL_0514;
																																		case 91:
																																			goto IL_0522;
																																		case 19:
																																		case 21:
																																			goto IL_0530;
																																		case 102:
																																			goto IL_0544;
																																		case 57:
																																			goto IL_0598;
																																		case 6:
																																			goto IL_05a6;
																																		case 32:
																																			goto IL_05b9;
																																		case 8:
																																			goto IL_05c7;
																																		case 98:
																																			goto IL_05d2;
																																		case 9:
																																		case 52:
																																			goto IL_05e0;
																																		case 111:
																																			goto IL_05ee;
																																		case 97:
																																			goto IL_0611;
																																		case 119:
																																			goto IL_061b;
																																		case 99:
																																			goto IL_0629;
																																		case 48:
																																		case 50:
																																			goto IL_0645;
																																		case 108:
																																			goto IL_0653;
																																		case 51:
																																		case 93:
																																			goto IL_0661;
																																		case 120:
																																			goto IL_067a;
																																		case 59:
																																			goto IL_0691;
																																		case 64:
																																			goto IL_069f;
																																		case 38:
																																		case 101:
																																			goto IL_06b2;
																																		case 43:
																																			goto IL_06f2;
																																		case 14:
																																			goto IL_0706;
																																		case 1:
																																		case 2:
																																		case 10:
																																		case 11:
																																		case 12:
																																		case 20:
																																		case 23:
																																		case 24:
																																		case 27:
																																		case 36:
																																		case 37:
																																		case 46:
																																		case 47:
																																		case 49:
																																		case 65:
																																		case 83:
																																		case 84:
																																		case 86:
																																		case 87:
																																		case 96:
																																		case 107:
																																		case 116:
																																		case 121:
																																			goto end_IL_0217;
																																		case 77:
																																			goto IL_0739;
																																		case 13:
																																			goto IL_0747;
																																		case 74:
																																			goto IL_0755;
																																		case 0:
																																		case 35:
																																		case 39:
																																		case 41:
																																		case 42:
																																		case 55:
																																		case 58:
																																		case 61:
																																		case 62:
																																		case 63:
																																		case 71:
																																		case 81:
																																		case 114:
																																		case 115:
																																		case 117:
																																			goto end_IL_02f9;
																																		case 7:
																																			goto end_IL_0763;
																																		case 22:
																																			goto end_IL_0776;
																																		case 113:
																																			goto end_IL_0780;
																																		case 122:
																																			goto end_IL_078b;
																																		case 5:
																																			goto end_IL_07a0;
																																		case 78:
																																		case 105:
																																			goto end_IL_07be;
																																		case 69:
																																			goto end_IL_07ce;
																																		case 15:
																																		case 100:
																																			goto end_IL_07de;
																																		case 109:
																																			goto end_IL_07ee;
																																		case 110:
																																			goto end_IL_07fe;
																																		case 92:
																																		case 118:
																																			goto IL_0819;
																																		}
																																		continue;
																																	}
																																	num5 -= 2;
																																	goto end_IL_02f9;
																																	continue;
																																	end_IL_0217:
																																	break;
																																}
																																break;
																															}
																														}
																														else
																														{
																															num = 23;
																														}
																														break;
																													}
																													break;
																													IL_02b9:;
																												}
																												break;
																											}
																											goto IL_0375;
																											IL_0375:
																											if (1 > b)
																											{
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0388;
																									IL_03dc:
																									num5--;
																									goto end_IL_02f9;
																									IL_0388:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03c8;
																									IL_03c8:
																									array[num5 - 2] = 0;
																									goto IL_03dc;
																								}
																								break;
																							}
																							goto IL_03ef;
																							IL_0468:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02f9;
																							IL_03ef:
																							if (4 >= b)
																							{
																								goto IL_03fa;
																							}
																							goto IL_0452;
																							IL_03fa:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0408;
																							IL_0408:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0431;
																							IL_0431:
																							ptr2 += 8;
																							goto IL_043f;
																							IL_043f:
																							num5--;
																							goto end_IL_02f9;
																							IL_0452:
																							if (5 < b)
																							{
																								num = 86;
																								break;
																							}
																							goto IL_045d;
																							IL_045d:
																							if (5 > b)
																							{
																								num = 87;
																								break;
																							}
																							goto IL_0468;
																						}
																						goto end_IL_0319;
																						continue;
																						end_IL_02f9:
																						break;
																						IL_02f9:;
																					}
																					break;
																				}
																				goto IL_049c;
																				IL_06b2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06f2;
																				IL_049c:
																				if (9 < b)
																				{
																					num = 54;
																					goto IL_04b3;
																				}
																				goto IL_05b9;
																				IL_06f2:
																				array[num5 - 2] = 0;
																				goto IL_0706;
																				IL_04b3:
																				if (11 < b)
																				{
																					goto IL_04be;
																				}
																				goto IL_04f6;
																				IL_04be:
																				if (12 < b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_04cc;
																				IL_04cc:
																				if (12 > b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_04da;
																				IL_04da:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_04f6:
																				if (11 <= b)
																				{
																					goto IL_0501;
																				}
																				goto IL_0514;
																				IL_0501:
																				num5--;
																				break;
																				IL_0514:
																				if (10 < b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_0522;
																				IL_0522:
																				if (10 > b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_0530;
																				IL_0530:
																				array[num5 - 2] = 0;
																				goto IL_0544;
																				IL_0544:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)PaddingHelpersDispatchWrapperType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0598;
																				IL_0598:
																				num5--;
																				goto IL_05a6;
																				IL_05a6:
																				ptr2 += 8;
																				break;
																				IL_05b9:
																				if (9 > b)
																				{
																					goto IL_05c7;
																				}
																				goto IL_06b2;
																				IL_05c7:
																				if (7 >= b)
																				{
																					goto IL_05d2;
																				}
																				num = 50;
																				goto IL_0645;
																				IL_05d2:
																				if (7 > b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_05e0;
																				IL_05e0:
																				array[num5] = 0;
																				goto IL_05ee;
																				IL_05ee:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0611;
																				IL_0611:
																				array2[num5] = null;
																				goto IL_061b;
																				IL_061b:
																				num5++;
																				goto IL_0629;
																				IL_0629:
																				ptr2 += 8;
																				break;
																				IL_0706:
																				num5--;
																				break;
																				IL_0645:
																				if (8 < b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_0653;
																				IL_0653:
																				if (8 > b)
																				{
																					goto end_IL_0319;
																				}
																				goto IL_0661;
																				IL_0661:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_067a;
																				IL_067a:
																				array[num5] = 0;
																				num = 59;
																				goto IL_0691;
																				IL_0691:
																				num5++;
																				goto IL_069f;
																				IL_069f:
																				ptr2 += 8;
																				break;
																			}
																			goto end_IL_0329;
																			continue;
																			end_IL_0319:
																			break;
																			IL_0319:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0739;
																	IL_0755:
																	ptr2 += 8;
																	break;
																	IL_0747:
																	num5++;
																	goto IL_0755;
																	IL_0739:
																	array[num5] = 0;
																	goto IL_0747;
																	continue;
																	end_IL_0329:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0819;
													IL_0819:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0763:
													break;
												}
												continue;
												end_IL_0776:
												break;
											}
											continue;
											end_IL_0780:
											break;
										}
										continue;
										end_IL_078b:
										break;
									}
									continue;
									end_IL_07a0:
									break;
								}
								continue;
								end_IL_07be:
								break;
							}
							continue;
							end_IL_07ce:
							break;
						}
						continue;
						end_IL_07de:
						break;
					}
					continue;
					end_IL_07ee:
					break;
				}
				continue;
				end_IL_07fe:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 69;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StandardNameArrayWithOffset.CobolAwayFromZero);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0285:
															byte b = *ptr2;
															while (true)
															{
																IL_0275:
																ptr2++;
																while (true)
																{
																	IL_0265:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0248:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0238:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0228:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (9 <= b)
																										{
																											while (true)
																											{
																												IL_01e6:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 113;
																												while (num != 113)
																												{
																													if (num != 1094)
																													{
																														goto IL_0285;
																													}
																													switch (num)
																													{
																													case 21:
																													case 90:
																														goto IL_01e6;
																													case 20:
																														goto IL_0208;
																													case 65:
																													case 99:
																														goto IL_0218;
																													case 48:
																													case 77:
																														goto IL_0228;
																													case 31:
																													case 59:
																														goto IL_0238;
																													case 76:
																														goto IL_0248;
																													case 27:
																														goto IL_0255;
																													case 75:
																														goto IL_0265;
																													case 34:
																														goto IL_0275;
																													case 53:
																													case 94:
																														goto IL_0285;
																													case 16:
																														goto IL_0290;
																													case 24:
																													case 42:
																														goto IL_029e;
																													case 25:
																														goto IL_02ac;
																													case 43:
																														goto IL_02d1;
																													case 45:
																														goto IL_02e1;
																													case 13:
																													case 52:
																														goto IL_02ef;
																													case 70:
																														goto IL_0334;
																													case 9:
																													case 92:
																														goto IL_0343;
																													case 93:
																														goto IL_0356;
																													case 47:
																														goto IL_0364;
																													case 57:
																													case 58:
																														goto IL_0372;
																													case 1:
																													case 96:
																														goto IL_03b7;
																													case 40:
																														goto IL_03d0;
																													case 46:
																														goto IL_03de;
																													case 73:
																														goto IL_03ec;
																													case 4:
																													case 97:
																														goto IL_03ff;
																													case 82:
																														goto IL_040a;
																													case 37:
																													case 41:
																														goto IL_0418;
																													case 63:
																														goto IL_0441;
																													case 8:
																														goto IL_044f;
																													case 87:
																														goto IL_0462;
																													case 62:
																														goto IL_0470;
																													case 23:
																													case 33:
																														goto IL_047e;
																													case 28:
																														goto IL_04c7;
																													case 61:
																														goto IL_04db;
																													case 100:
																														goto IL_04ee;
																													case 38:
																														goto IL_04fc;
																													case 101:
																														goto IL_050f;
																													case 32:
																														goto IL_0523;
																													case 104:
																														goto IL_0536;
																													case 84:
																														goto IL_054a;
																													case 106:
																														goto IL_055d;
																													case 56:
																													case 74:
																														goto IL_0568;
																													case 29:
																														goto IL_05a8;
																													case 18:
																														goto IL_05bc;
																													case 26:
																														goto IL_05cc;
																													case 72:
																														goto IL_05d7;
																													case 2:
																													case 3:
																													case 5:
																													case 6:
																													case 7:
																													case 12:
																													case 14:
																													case 15:
																													case 35:
																													case 49:
																													case 50:
																													case 54:
																													case 55:
																													case 64:
																													case 66:
																													case 71:
																													case 95:
																													case 98:
																													case 105:
																														goto end_IL_0208;
																													case 10:
																														goto IL_060e;
																													case 83:
																														goto IL_061c;
																													case 88:
																														goto IL_0633;
																													case 0:
																													case 11:
																													case 17:
																													case 30:
																													case 36:
																													case 39:
																													case 67:
																													case 81:
																													case 91:
																													case 102:
																														goto end_IL_01d3;
																													case 51:
																														goto end_IL_0641;
																													case 89:
																														goto end_IL_0654;
																													case 85:
																														goto end_IL_065e;
																													case 78:
																														goto end_IL_0669;
																													case 79:
																														goto end_IL_067e;
																													case 22:
																													case 103:
																														goto end_IL_0693;
																													case 86:
																														goto end_IL_06a3;
																													case 19:
																													case 60:
																														goto end_IL_06b3;
																													case 68:
																														goto end_IL_06c3;
																													case 69:
																														goto end_IL_06d3;
																													case 44:
																													case 80:
																														goto IL_06ee;
																													}
																													continue;
																													end_IL_01d3:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0265;
																											continue;
																											end_IL_0208:
																											break;
																											IL_0208:;
																										}
																										break;
																										IL_0218:;
																									}
																									break;
																								}
																								goto IL_02e1;
																								IL_0523:
																								num6--;
																								goto end_IL_0265;
																								IL_02e1:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02ef;
																								IL_02ef:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_050f;
																								IL_050f:
																								array[num6 - 2] = 0;
																								goto IL_0523;
																							}
																							break;
																						}
																						goto IL_02d1;
																						IL_03ec:
																						ptr2 += 8;
																						goto end_IL_0265;
																						IL_02d1:
																						if (7 > b)
																						{
																							goto IL_0356;
																						}
																						goto IL_03b7;
																						IL_0356:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0364;
																						IL_0364:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0372;
																						IL_0372:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0536;
																						IL_0536:
																						array[num6 - 2] = 0;
																						goto IL_054a;
																						IL_054a:
																						num6--;
																						goto end_IL_0265;
																						IL_03b7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_03d0;
																						IL_03d0:
																						array[num6] = 0;
																						goto IL_03de;
																						IL_03de:
																						num6++;
																						goto IL_03ec;
																					}
																					break;
																				}
																				goto IL_0290;
																				IL_05d7:
																				if (1 > b)
																				{
																					num = 105;
																				}
																				break;
																				IL_0290:
																				if (5 <= b)
																				{
																					goto IL_029e;
																				}
																				goto IL_0343;
																				IL_029e:
																				array[num6] = 0;
																				goto IL_02ac;
																				IL_02ac:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0334;
																				IL_0334:
																				array2[num6] = null;
																				goto IL_04ee;
																				IL_04ee:
																				num6++;
																				goto IL_04fc;
																				IL_04fc:
																				ptr2 += 8;
																				goto end_IL_0265;
																				IL_0343:
																				if (2 < b)
																				{
																					goto IL_03ff;
																				}
																				goto IL_055d;
																				IL_03ff:
																				if (3 >= b)
																				{
																					goto IL_040a;
																				}
																				goto IL_0462;
																				IL_040a:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0418;
																				IL_0418:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0441;
																				IL_0441:
																				ptr2 += 8;
																				goto IL_044f;
																				IL_044f:
																				num6--;
																				goto end_IL_0265;
																				IL_0462:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0470;
																				IL_0470:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_047e;
																				IL_047e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 28;
																				goto IL_04c7;
																				IL_04c7:
																				array[num6 - 2] = 0;
																				goto IL_04db;
																				IL_04db:
																				num6--;
																				goto end_IL_0265;
																				IL_055d:
																				if (2 <= b)
																				{
																					goto IL_0568;
																				}
																				goto IL_05cc;
																				IL_0568:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_05a8;
																				IL_05a8:
																				array[num6 - 2] = 0;
																				goto IL_05bc;
																				IL_05bc:
																				num6--;
																				goto end_IL_0265;
																				IL_05cc:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_05d7;
																			}
																			break;
																			IL_0255:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060e;
																	IL_0633:
																	ptr2 += 8;
																	break;
																	IL_061c:
																	num6++;
																	num = 88;
																	goto IL_0633;
																	IL_060e:
																	array[num6] = 0;
																	goto IL_061c;
																	continue;
																	end_IL_0265:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06ee;
													IL_06ee:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0641:
													break;
												}
												continue;
												end_IL_0654:
												break;
											}
											continue;
											end_IL_065e:
											break;
										}
										continue;
										end_IL_0669:
										break;
									}
									continue;
									end_IL_067e:
									break;
								}
								continue;
								end_IL_0693:
								break;
							}
							continue;
							end_IL_06a3:
							break;
						}
						continue;
						end_IL_06b3:
						break;
					}
					continue;
					end_IL_06c3:
					break;
				}
				continue;
				end_IL_06d3:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 19;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AMDDomainManager.SerializableFileInfo);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 11;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0287:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_026a:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_025a:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_024a:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_023a:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_01ff:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_01e6:
																															array[num5] = 0;
																															num = 113;
																															while (true)
																															{
																																if (num != 113)
																																{
																																	if (num != 1094)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 57:
																																		goto IL_01e6;
																																	case 2:
																																	case 63:
																																		goto IL_01ff;
																																	case 53:
																																		goto IL_021a;
																																	case 43:
																																		goto IL_022a;
																																	case 33:
																																		goto IL_023a;
																																	case 58:
																																		goto IL_024a;
																																	case 49:
																																		goto IL_025a;
																																	case 8:
																																		goto IL_026a;
																																	case 37:
																																		goto IL_0277;
																																	case 64:
																																		goto IL_0287;
																																	case 11:
																																		goto end_IL_0287;
																																	case 54:
																																	case 92:
																																		goto end_IL_0297;
																																	case 35:
																																	case 39:
																																		goto IL_02bb;
																																	case 59:
																																	case 61:
																																		goto IL_02c6;
																																	case 42:
																																		goto IL_02d1;
																																	case 0:
																																		goto IL_02df;
																																	case 73:
																																		goto IL_02f2;
																																	case 1:
																																	case 24:
																																		goto IL_030b;
																																	case 83:
																																		goto IL_0327;
																																	case 7:
																																	case 38:
																																		goto IL_0332;
																																	case 32:
																																		goto IL_0394;
																																	case 20:
																																	case 85:
																																		goto IL_03a7;
																																	case 29:
																																	case 41:
																																		goto IL_03b2;
																																	case 27:
																																		goto IL_03c5;
																																	case 56:
																																	case 91:
																																		goto IL_03d3;
																																	case 86:
																																		goto IL_0413;
																																	case 100:
																																		goto IL_0430;
																																	case 102:
																																		goto IL_0443;
																																	case 89:
																																	case 95:
																																		goto IL_0451;
																																	case 13:
																																		goto IL_0474;
																																	case 84:
																																		goto IL_0482;
																																	case 62:
																																		goto IL_0490;
																																	case 22:
																																		goto IL_04ba;
																																	case 80:
																																	case 94:
																																		goto IL_04cd;
																																	case 12:
																																		goto IL_04ff;
																																	case 90:
																																		goto IL_050d;
																																	case 88:
																																	case 106:
																																		goto IL_0520;
																																	case 72:
																																		goto IL_052b;
																																	case 48:
																																	case 67:
																																		goto IL_0539;
																																	case 60:
																																	case 93:
																																		goto IL_0551;
																																	case 105:
																																		goto IL_055c;
																																	case 9:
																																	case 81:
																																		goto end_IL_01d3;
																																	case 104:
																																		goto IL_0577;
																																	case 66:
																																		goto IL_05a3;
																																	case 82:
																																		goto IL_05ad;
																																	case 10:
																																		goto IL_05bb;
																																	case 3:
																																	case 21:
																																	case 23:
																																	case 26:
																																	case 30:
																																	case 34:
																																	case 36:
																																	case 44:
																																	case 47:
																																	case 51:
																																	case 52:
																																	case 55:
																																	case 65:
																																	case 70:
																																	case 74:
																																	case 76:
																																	case 87:
																																	case 98:
																																	case 99:
																																	case 101:
																																		goto end_IL_021a;
																																	case 14:
																																	case 15:
																																	case 28:
																																	case 45:
																																	case 46:
																																	case 50:
																																	case 75:
																																	case 77:
																																	case 78:
																																	case 79:
																																	case 96:
																																	case 97:
																																	case 103:
																																		goto end_IL_02a7;
																																	case 69:
																																		goto end_IL_05de;
																																	case 16:
																																		goto end_IL_05f1;
																																	case 68:
																																		goto end_IL_05fb;
																																	case 18:
																																		goto end_IL_0606;
																																	case 25:
																																	case 40:
																																		goto end_IL_061b;
																																	case 31:
																																		goto end_IL_062b;
																																	case 19:
																																		goto end_IL_063b;
																																	case 6:
																																		goto end_IL_064b;
																																	case 4:
																																		goto end_IL_065b;
																																	case 5:
																																		goto end_IL_0666;
																																	case 17:
																																	case 71:
																																		goto IL_0681;
																																	}
																																	continue;
																																}
																																num5++;
																																num = 22;
																																goto IL_04ba;
																																IL_04ba:
																																ptr2 += 8;
																																goto end_IL_02a7;
																																continue;
																																end_IL_01d3:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0569;
																													continue;
																													end_IL_021a:
																													break;
																													IL_021a:;
																												}
																												break;
																												IL_022a:;
																											}
																											break;
																										}
																										goto IL_04cd;
																										IL_050d:
																										num5--;
																										goto end_IL_02a7;
																										IL_04cd:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 12;
																										goto IL_04ff;
																										IL_04ff:
																										ptr2 += 8;
																										goto IL_050d;
																									}
																									break;
																								}
																								goto IL_0520;
																								IL_055c:
																								if (4 <= b)
																								{
																									goto end_IL_02a7;
																								}
																								break;
																								IL_0520:
																								if (3 >= b)
																								{
																									goto IL_052b;
																								}
																								goto IL_0551;
																								IL_052b:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0539;
																								IL_0539:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02a7;
																								IL_0551:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_055c;
																							}
																							break;
																						}
																						goto IL_0569;
																						IL_05bb:
																						ptr2 += 8;
																						goto end_IL_02a7;
																						IL_0569:
																						array[num5] = 0;
																						goto IL_0577;
																						IL_0577:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						num = 66;
																						goto IL_05a3;
																						IL_05a3:
																						array2[num5] = null;
																						goto IL_05ad;
																						IL_05ad:
																						num5++;
																						goto IL_05bb;
																					}
																					break;
																				}
																				goto IL_02bb;
																				IL_0413:
																				array[num5 - 2] = 0;
																				num = 100;
																				goto IL_0430;
																				IL_02bb:
																				if (8 < b)
																				{
																					goto IL_02c6;
																				}
																				goto IL_0327;
																				IL_02c6:
																				if (9 < b)
																				{
																					goto IL_02d1;
																				}
																				goto IL_02f2;
																				IL_02d1:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_02df;
																				IL_02df:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_02f2:
																				if (9 > b)
																				{
																					num = 70;
																					break;
																				}
																				goto IL_030b;
																				IL_0430:
																				num5--;
																				goto end_IL_02a7;
																				IL_030b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a7;
																				IL_0327:
																				if (8 <= b)
																				{
																					goto IL_0332;
																				}
																				goto IL_03a7;
																				IL_0332:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0394;
																				IL_0394:
																				num5 -= 2;
																				goto end_IL_02a7;
																				IL_03a7:
																				if (6 < b)
																				{
																					goto IL_03b2;
																				}
																				goto IL_03c5;
																				IL_03b2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0443;
																				IL_0443:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0451;
																				IL_0451:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0474;
																				IL_0474:
																				array[num5] = 0;
																				goto IL_0482;
																				IL_0482:
																				num5++;
																				goto IL_0490;
																				IL_0490:
																				ptr2 += 8;
																				goto end_IL_02a7;
																				IL_03c5:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_03d3;
																				IL_03d3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0413;
																			}
																			break;
																			IL_0277:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02a7;
																	continue;
																	end_IL_0287:
																	break;
																}
																continue;
																end_IL_0297:
																break;
															}
															continue;
															end_IL_02a7:
															break;
														}
														continue;
													}
													goto IL_0681;
													IL_0681:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05de:
													break;
												}
												continue;
												end_IL_05f1:
												break;
											}
											continue;
											end_IL_05fb:
											break;
										}
										continue;
										end_IL_0606:
										break;
									}
									continue;
									end_IL_061b:
									break;
								}
								continue;
								end_IL_062b:
								break;
							}
							continue;
							end_IL_063b:
							break;
						}
						continue;
						end_IL_064b:
						break;
					}
					continue;
					end_IL_065b:
					break;
				}
				continue;
				end_IL_0666:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 147;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StlocSsetVolumeLabel.setExceptionMessageGetApplicationManifestBytes);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0374:
															byte b = *ptr2;
															while (true)
															{
																IL_0364:
																ptr2++;
																while (true)
																{
																	IL_0354:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				IL_0334:
																				if (9 >= b)
																				{
																					while (9 > b)
																					{
																						while (true)
																						{
																							IL_0317:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_0307:
																									if (6 < b)
																									{
																										while (true)
																										{
																											IL_02f7:
																											if (7 < b)
																											{
																												while (8 >= b)
																												{
																													while (8 <= b)
																													{
																														num = 169;
																														while (true)
																														{
																															if (num != 169)
																															{
																																if (num != 1150)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 106:
																																	goto IL_02d4;
																																case 77:
																																	goto IL_02e7;
																																case 93:
																																case 158:
																																	goto IL_02f7;
																																case 1:
																																case 142:
																																	goto IL_0307;
																																case 63:
																																	goto IL_0317;
																																case 87:
																																	goto IL_0324;
																																case 19:
																																	goto IL_0334;
																																case 82:
																																	goto end_IL_02c1;
																																case 26:
																																	goto IL_0354;
																																case 136:
																																	goto IL_0364;
																																case 140:
																																case 149:
																																	goto IL_0374;
																																case 34:
																																	goto IL_037f;
																																case 33:
																																case 98:
																																	goto IL_038a;
																																case 80:
																																	goto IL_03a8;
																																case 22:
																																	goto IL_03b6;
																																case 2:
																																case 110:
																																	goto IL_03c9;
																																case 102:
																																	goto IL_03d7;
																																case 42:
																																case 132:
																																	goto IL_03e5;
																																case 28:
																																	goto IL_0425;
																																case 131:
																																	goto IL_0439;
																																case 133:
																																	goto IL_044c;
																																case 71:
																																	goto IL_0457;
																																case 99:
																																	goto IL_0465;
																																case 6:
																																case 128:
																																	goto IL_0481;
																																case 4:
																																	goto IL_04c9;
																																case 138:
																																	goto IL_04dc;
																																case 139:
																																	goto IL_04ea;
																																case 59:
																																case 112:
																																	goto IL_04f8;
																																case 84:
																																	goto IL_0521;
																																case 153:
																																	goto IL_053a;
																																case 73:
																																	goto IL_0548;
																																case 8:
																																case 64:
																																	goto IL_0556;
																																case 52:
																																	goto IL_056f;
																																case 72:
																																	goto IL_057d;
																																case 13:
																																	goto IL_058b;
																																case 48:
																																case 156:
																																	goto IL_059e;
																																case 78:
																																	goto IL_05ac;
																																case 54:
																																	goto IL_05c4;
																																case 113:
																																	goto IL_05d2;
																																case 148:
																																	goto IL_05ee;
																																case 62:
																																	goto IL_060f;
																																case 49:
																																case 121:
																																	goto IL_061d;
																																case 109:
																																	goto IL_0646;
																																case 36:
																																	goto IL_0654;
																																case 60:
																																case 115:
																																	goto IL_0667;
																																case 7:
																																	goto IL_0675;
																																case 18:
																																case 146:
																																	goto IL_0683;
																																case 141:
																																case 145:
																																	goto IL_0691;
																																case 129:
																																	goto IL_069f;
																																case 23:
																																case 155:
																																	goto IL_06ad;
																																case 38:
																																	goto IL_06ed;
																																case 152:
																																	goto IL_0701;
																																case 95:
																																	goto IL_0714;
																																case 31:
																																case 57:
																																	goto IL_071f;
																																case 50:
																																	goto IL_0763;
																																case 76:
																																	goto IL_0777;
																																case 21:
																																	goto IL_078a;
																																case 12:
																																	goto IL_0798;
																																case 74:
																																case 107:
																																	goto IL_07a6;
																																case 89:
																																	goto IL_07b4;
																																case 3:
																																	goto IL_07d7;
																																case 154:
																																	goto IL_07e1;
																																case 79:
																																	goto IL_07ef;
																																case 114:
																																case 143:
																																	goto IL_080b;
																																case 44:
																																	goto IL_086d;
																																case 75:
																																	goto IL_0880;
																																case 56:
																																	goto IL_088e;
																																case 5:
																																case 161:
																																	goto IL_0899;
																																case 151:
																																	goto IL_08ac;
																																case 108:
																																	goto IL_08ba;
																																case 91:
																																case 157:
																																	goto IL_08c8;
																																case 116:
																																	goto IL_08dc;
																																case 126:
																																	goto IL_0930;
																																case 46:
																																	goto IL_093e;
																																case 14:
																																	goto IL_0957;
																																case 27:
																																	goto IL_0962;
																																case 37:
																																case 81:
																																	goto IL_096d;
																																case 162:
																																	goto IL_0986;
																																case 15:
																																	goto IL_0991;
																																case 9:
																																case 10:
																																case 11:
																																case 24:
																																case 25:
																																case 29:
																																case 32:
																																case 35:
																																case 39:
																																case 41:
																																case 45:
																																case 47:
																																case 61:
																																case 65:
																																case 66:
																																case 86:
																																case 90:
																																case 92:
																																case 96:
																																case 97:
																																case 103:
																																case 117:
																																case 118:
																																case 119:
																																case 123:
																																case 124:
																																case 127:
																																case 130:
																																case 135:
																																case 159:
																																	goto end_IL_02d4;
																																case 0:
																																case 16:
																																case 17:
																																case 51:
																																case 53:
																																case 55:
																																case 69:
																																case 83:
																																case 85:
																																case 94:
																																case 100:
																																case 101:
																																case 104:
																																case 111:
																																case 120:
																																case 122:
																																case 134:
																																case 137:
																																case 150:
																																case 160:
																																	goto end_IL_0324;
																																case 40:
																																	goto end_IL_09af;
																																case 125:
																																	goto end_IL_09c2;
																																case 70:
																																	goto end_IL_09cc;
																																case 144:
																																	goto end_IL_09d7;
																																case 147:
																																	goto end_IL_09e7;
																																case 88:
																																	goto end_IL_09f7;
																																case 30:
																																	goto end_IL_0a07;
																																case 43:
																																case 105:
																																	goto end_IL_0a12;
																																case 67:
																																	goto end_IL_0a22;
																																case 68:
																																	goto end_IL_0a32;
																																case 20:
																																case 58:
																																	goto IL_0a4d;
																																}
																																continue;
																															}
																															goto IL_05ee;
																															IL_05ee:
																															ptr2 = ptr + *(int*)(ptr2 + num3);
																															goto end_IL_0324;
																															continue;
																															end_IL_02c1:
																															break;
																														}
																														goto IL_0344;
																														continue;
																														end_IL_02d4:
																														break;
																														IL_02d4:;
																													}
																													break;
																													IL_02e7:;
																												}
																												break;
																											}
																											num = 62;
																											goto IL_060f;
																											IL_0646:
																											ptr2 += 8;
																											goto IL_0654;
																											IL_0654:
																											num5--;
																											goto end_IL_0324;
																											IL_060f:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_061d;
																											IL_061d:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0646;
																										}
																										break;
																									}
																									goto IL_044c;
																									IL_0481:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 4;
																									goto IL_04c9;
																									IL_044c:
																									if (6 > b)
																									{
																										goto IL_0457;
																									}
																									goto IL_0481;
																									IL_0457:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0465;
																									IL_0465:
																									if (5 > b)
																									{
																										num = 11;
																										break;
																									}
																									goto IL_059e;
																									IL_04c9:
																									num5 -= 3;
																									goto end_IL_0324;
																									IL_059e:
																									array[num5] = 5;
																									goto IL_05ac;
																									IL_05ac:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_05c4;
																									IL_05c4:
																									num5++;
																									goto IL_05d2;
																									IL_05d2:
																									ptr2 += 8;
																									num = 160;
																									goto end_IL_0324;
																								}
																								break;
																							}
																							goto IL_037f;
																							IL_0521:
																							array[num5 - 1] = 5;
																							goto end_IL_0324;
																							IL_037f:
																							if (4 <= b)
																							{
																								goto IL_038a;
																							}
																							goto IL_03c9;
																							IL_038a:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_03a8;
																							IL_03a8:
																							ptr2 += 8;
																							goto IL_03b6;
																							IL_03b6:
																							num5--;
																							goto end_IL_0324;
																							IL_03c9:
																							if (2 >= b)
																							{
																								goto IL_03d7;
																							}
																							goto IL_04dc;
																							IL_03d7:
																							if (2 <= b)
																							{
																								goto IL_03e5;
																							}
																							goto IL_053a;
																							IL_03e5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0425;
																							IL_0425:
																							array[num5 - 2] = 0;
																							goto IL_0439;
																							IL_0439:
																							num5--;
																							goto end_IL_0324;
																							IL_053a:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0548;
																							IL_0548:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0556;
																							IL_0556:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_056f;
																							IL_056f:
																							array[num5] = 0;
																							goto IL_057d;
																							IL_057d:
																							num5++;
																							goto IL_058b;
																							IL_058b:
																							ptr2 += 8;
																							goto end_IL_0324;
																							IL_04dc:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_04ea;
																							IL_04ea:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_04f8;
																							IL_04f8:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0521;
																						}
																						goto end_IL_0344;
																						continue;
																						end_IL_0324:
																						break;
																						IL_0324:;
																					}
																					break;
																				}
																				goto IL_0667;
																				IL_0991:
																				if (17 <= b)
																				{
																				}
																				goto end_IL_0344;
																				IL_0667:
																				if (13 >= b)
																				{
																					goto IL_0675;
																				}
																				goto IL_0880;
																				IL_0675:
																				if (13 > b)
																				{
																					goto IL_0683;
																				}
																				goto IL_080b;
																				IL_0683:
																				if (11 < b)
																				{
																					goto IL_0691;
																				}
																				goto IL_0714;
																				IL_0691:
																				if (12 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_069f;
																				IL_069f:
																				if (12 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_06ad;
																				IL_06ad:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06ed;
																				IL_06ed:
																				array[num5 - 2] = 0;
																				goto IL_0701;
																				IL_0701:
																				num5--;
																				break;
																				IL_0714:
																				if (11 <= b)
																				{
																					goto IL_071f;
																				}
																				goto IL_078a;
																				IL_071f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0763;
																				IL_0763:
																				array[num5 - 2] = 0;
																				goto IL_0777;
																				IL_0777:
																				num5--;
																				break;
																				IL_078a:
																				if (10 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_0798;
																				IL_0798:
																				if (10 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_07a6;
																				IL_07a6:
																				array[num5] = 0;
																				goto IL_07b4;
																				IL_07b4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_07d7;
																				IL_07d7:
																				array2[num5] = null;
																				goto IL_07e1;
																				IL_07e1:
																				num5++;
																				goto IL_07ef;
																				IL_07ef:
																				ptr2 += 8;
																				num = 16;
																				break;
																				IL_080b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_086d;
																				IL_086d:
																				num5 -= 2;
																				break;
																				IL_0880:
																				if (15 >= b)
																				{
																					goto IL_088e;
																				}
																				goto IL_0957;
																				IL_088e:
																				if (15 <= b)
																				{
																					goto IL_0899;
																				}
																				goto IL_08ac;
																				IL_0899:
																				num5--;
																				break;
																				IL_08ac:
																				if (14 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_08ba;
																				IL_08ba:
																				if (14 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_08c8;
																				IL_08c8:
																				array[num5 - 2] = 0;
																				goto IL_08dc;
																				IL_08dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)IServiceProviderEncodingProvider[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0930;
																				IL_0930:
																				num5--;
																				goto IL_093e;
																				IL_093e:
																				ptr2 += 8;
																				num = 111;
																				break;
																				IL_0957:
																				if (16 >= b)
																				{
																					goto IL_0962;
																				}
																				goto IL_0986;
																				IL_0962:
																				if (16 > b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_096d;
																				IL_096d:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0986:
																				if (17 < b)
																				{
																					goto end_IL_0344;
																				}
																				goto IL_0991;
																			}
																			goto end_IL_0354;
																			continue;
																			end_IL_0344:
																			break;
																			IL_0344:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0354:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0a4d;
													IL_0a4d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_09af:
													break;
												}
												continue;
												end_IL_09c2:
												break;
											}
											continue;
											end_IL_09cc:
											break;
										}
										continue;
										end_IL_09d7:
										break;
									}
									continue;
									end_IL_09e7:
									break;
								}
								continue;
								end_IL_09f7:
								break;
							}
							continue;
							end_IL_0a07:
							break;
						}
						continue;
						end_IL_0a12:
						break;
					}
					continue;
					end_IL_0a22:
					break;
				}
				continue;
				end_IL_0a32:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_3)
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 34;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							IL_0626:
							object[] array2 = new object[2];
							while (true)
							{
								IL_0616:
								int[] array3 = new int[3];
								while (true)
								{
									IL_0606:
									long[] array4 = new long[2];
									while (true)
									{
										IL_05f1:
										array3[0] = int_3;
										while (true)
										{
											IL_05e6:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DateTimeTokenProgIdRedirectionRedirectedGuid.INVOCATIONFLAGSINITIALIZEDgetTargetScheduler);
											while (true)
											{
												IL_05d3:
												byte* ptr2 = ptr;
												num = 67;
												while (true)
												{
													IL_05c0:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0269:
															byte b = *ptr2;
															while (true)
															{
																IL_0259:
																ptr2++;
																while (true)
																{
																	IL_0249:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_022c:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_021f:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_020f:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_01ff:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													num = 107;
																													while (true)
																													{
																														if (num != 107)
																														{
																															if (num != 1088)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 22:
																																goto IL_01dc;
																															case 44:
																																goto IL_01ef;
																															case 10:
																															case 95:
																																goto IL_01ff;
																															case 28:
																																goto IL_020f;
																															case 73:
																																goto IL_021f;
																															case 31:
																																goto IL_022c;
																															case 8:
																																goto IL_0239;
																															case 26:
																																goto IL_0249;
																															case 82:
																																goto IL_0259;
																															case 93:
																															case 100:
																																goto IL_0269;
																															case 14:
																																goto IL_0274;
																															case 0:
																																goto IL_0282;
																															case 30:
																																goto IL_028d;
																															case 19:
																															case 42:
																																goto IL_029d;
																															case 25:
																																goto IL_02ab;
																															case 48:
																																goto IL_02be;
																															case 57:
																																goto IL_02ce;
																															case 63:
																																goto IL_02e1;
																															case 65:
																																goto IL_02f4;
																															case 20:
																																goto IL_0302;
																															case 2:
																															case 15:
																																goto IL_0319;
																															case 5:
																															case 66:
																																goto IL_0337;
																															case 70:
																																goto IL_0345;
																															case 11:
																																goto IL_0368;
																															case 29:
																																goto IL_0372;
																															case 6:
																																goto IL_0380;
																															case 7:
																															case 76:
																																goto IL_0393;
																															case 83:
																																goto IL_03d3;
																															case 37:
																																goto IL_03e7;
																															case 84:
																																goto IL_03fa;
																															case 32:
																																goto IL_0408;
																															case 47:
																															case 85:
																																goto IL_041b;
																															case 33:
																															case 87:
																																goto IL_0437;
																															case 71:
																																goto IL_0445;
																															case 50:
																															case 89:
																																goto IL_0458;
																															case 94:
																																goto IL_0470;
																															case 90:
																																goto IL_047e;
																															case 59:
																																goto IL_048c;
																															case 80:
																															case 98:
																																goto IL_049f;
																															case 51:
																																goto IL_04c8;
																															case 39:
																																goto IL_04d6;
																															case 91:
																																goto IL_04e9;
																															case 35:
																																goto IL_050c;
																															case 52:
																																goto IL_051a;
																															case 43:
																																goto IL_0528;
																															case 21:
																															case 99:
																																goto IL_053b;
																															case 40:
																																goto IL_059d;
																															case 1:
																															case 3:
																															case 4:
																															case 9:
																															case 18:
																															case 27:
																															case 36:
																															case 38:
																															case 41:
																															case 54:
																															case 60:
																															case 64:
																															case 69:
																															case 72:
																															case 75:
																															case 77:
																															case 81:
																																goto end_IL_01dc;
																															case 23:
																															case 24:
																															case 46:
																															case 49:
																															case 53:
																															case 55:
																															case 62:
																															case 67:
																															case 74:
																															case 78:
																															case 86:
																															case 88:
																															case 92:
																																goto IL_05c0;
																															case 56:
																																goto IL_05d3;
																															case 97:
																																goto IL_05e6;
																															case 13:
																																goto IL_05f1;
																															case 45:
																																goto IL_0606;
																															case 79:
																															case 96:
																																goto IL_0616;
																															case 61:
																																goto IL_0626;
																															case 34:
																																goto end_IL_01c9;
																															case 12:
																																goto end_IL_0636;
																															case 16:
																																goto end_IL_0646;
																															case 17:
																																goto end_IL_0651;
																															case 58:
																															case 68:
																																goto IL_066c;
																															}
																															continue;
																														}
																														goto IL_04e9;
																														IL_051a:
																														num5++;
																														goto IL_0528;
																														IL_0528:
																														ptr2 += 8;
																														goto IL_05c0;
																														IL_04e9:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														goto IL_050c;
																														IL_050c:
																														array[num5] = 0;
																														goto IL_051a;
																														continue;
																														end_IL_01c9:
																														break;
																													}
																													goto end_IL_0249;
																													continue;
																													end_IL_01dc:
																													break;
																													IL_01dc:;
																												}
																												break;
																												IL_01ef:;
																											}
																											break;
																										}
																										goto IL_02ce;
																										IL_03e7:
																										num5--;
																										goto IL_05c0;
																										IL_02ce:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_0393;
																										IL_0393:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03d3;
																										IL_03d3:
																										array[num5 - 2] = 0;
																										goto IL_03e7;
																									}
																									break;
																								}
																								goto IL_053b;
																								IL_059d:
																								num5 -= 2;
																								goto IL_05c0;
																								IL_053b:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_059d;
																							}
																							break;
																						}
																						goto IL_029d;
																						IL_0408:
																						if (10 <= b)
																						{
																						}
																						break;
																						IL_029d:
																						if (9 >= b)
																						{
																							goto IL_02ab;
																						}
																						goto IL_03fa;
																						IL_02ab:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_041b;
																						IL_041b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto IL_05c0;
																						IL_03fa:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0408;
																					}
																					break;
																				}
																				goto IL_0274;
																				IL_0372:
																				num5++;
																				goto IL_0380;
																				IL_0274:
																				if (5 > b)
																				{
																					goto IL_0282;
																				}
																				goto IL_0337;
																				IL_0282:
																				if (2 < b)
																				{
																					goto IL_028d;
																				}
																				goto IL_02be;
																				IL_028d:
																				if (3 >= b)
																				{
																					goto IL_02e1;
																				}
																				goto IL_0437;
																				IL_02e1:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0458;
																				IL_0458:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05c0;
																				IL_0437:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0445;
																				IL_0445:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05c0;
																				IL_02be:
																				if (2 > b)
																				{
																					goto IL_02f4;
																				}
																				goto IL_049f;
																				IL_02f4:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0302;
																				IL_0302:
																				if (1 > b)
																				{
																					break;
																				}
																				num = 15;
																				goto IL_0319;
																				IL_0380:
																				ptr2 += 8;
																				goto IL_05c0;
																				IL_0319:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0470;
																				IL_0470:
																				array[num5] = 0;
																				goto IL_047e;
																				IL_047e:
																				num5++;
																				goto IL_048c;
																				IL_048c:
																				ptr2 += 8;
																				goto IL_05c0;
																				IL_049f:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c8;
																				IL_04c8:
																				ptr2 += 8;
																				goto IL_04d6;
																				IL_04d6:
																				num5--;
																				goto IL_05c0;
																				IL_0337:
																				array[num5] = 0;
																				goto IL_0345;
																				IL_0345:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0368;
																				IL_0368:
																				array2[num5] = null;
																				goto IL_0372;
																			}
																			break;
																			IL_0239:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05c0;
																	continue;
																	end_IL_0249:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_066c;
													IL_066c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0636:
						break;
					}
					continue;
					end_IL_0646:
					break;
				}
				continue;
				end_IL_0651:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 48;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RoundSortedListEnumerator.GetAbbreviatedMonthNameEncodingNLS);
											num = 87;
											while (true)
											{
												byte* ptr2 = ptr;
												num = 96;
												while (true)
												{
													if (num == 96)
													{
														goto IL_024e;
													}
													if (num != 1077)
													{
														goto IL_0573;
													}
													switch (num)
													{
													case 87:
														goto end_IL_018f;
													case 51:
														goto end_IL_01a2;
													case 73:
														goto end_IL_01b5;
													case 81:
														goto end_IL_01c9;
													case 72:
														goto end_IL_01de;
													case 9:
													case 23:
														goto end_IL_01f3;
													case 82:
														goto end_IL_0203;
													case 26:
													case 52:
														goto end_IL_0213;
													case 47:
														goto end_IL_0223;
													case 48:
														goto end_IL_0233;
													case 11:
													case 14:
													case 17:
													case 21:
													case 36:
													case 56:
													case 63:
													case 69:
													case 79:
													case 83:
														goto IL_024e;
													case 53:
														goto IL_025e;
													case 3:
														goto IL_0267;
													case 40:
														goto IL_0270;
													case 71:
														goto IL_027e;
													case 49:
														goto IL_028c;
													case 37:
														goto IL_029a;
													case 39:
														goto IL_02a8;
													case 32:
													case 66:
														goto IL_02b3;
													case 2:
														goto IL_02dc;
													case 84:
														goto IL_02ea;
													case 78:
														goto IL_02fd;
													case 5:
														goto IL_030b;
													case 62:
													case 77:
														goto IL_0319;
													case 1:
														goto IL_0387;
													case 60:
														goto IL_039a;
													case 19:
														goto IL_03a8;
													case 35:
														goto IL_03bb;
													case 61:
														goto IL_03c9;
													case 43:
													case 74:
														goto IL_03d7;
													case 28:
														goto IL_0417;
													case 68:
														goto IL_042b;
													case 13:
														goto IL_043e;
													case 15:
														goto IL_0449;
													case 20:
													case 46:
														goto IL_0460;
													case 34:
														goto IL_046e;
													case 30:
													case 67:
														goto IL_047c;
													case 55:
														goto IL_0494;
													case 7:
														goto IL_049f;
													case 10:
													case 88:
														goto IL_04ad;
													case 29:
														goto IL_04bb;
													case 86:
														goto IL_04de;
													case 16:
														goto IL_04e8;
													case 58:
														goto IL_04f6;
													case 59:
														goto IL_0509;
													case 6:
														goto IL_0514;
													case 45:
													case 64:
														goto IL_051f;
													case 27:
														goto IL_0544;
													case 70:
														goto IL_0552;
													case 8:
														goto IL_0560;
													case 0:
													case 4:
													case 12:
													case 18:
													case 24:
													case 25:
													case 31:
													case 33:
													case 38:
													case 41:
													case 42:
													case 44:
													case 50:
													case 54:
													case 57:
													case 65:
													case 76:
													case 80:
													case 85:
													case 89:
														goto IL_0573;
													case 22:
													case 75:
														goto IL_0598;
													}
													continue;
													IL_0544:
													array[num4] = 0;
													goto IL_0552;
													IL_0552:
													num4++;
													goto IL_0560;
													IL_024e:
													if (num5 != 1)
													{
														goto IL_025e;
													}
													goto IL_0598;
													IL_0598:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_025e:
													num = 3;
													goto IL_0267;
													IL_0267:
													b = *ptr2;
													goto IL_0270;
													IL_0270:
													ptr2++;
													goto IL_027e;
													IL_027e:
													if (b >= 1)
													{
														goto IL_028c;
													}
													goto IL_0573;
													IL_028c:
													if (b <= 8)
													{
														goto IL_029a;
													}
													goto IL_0573;
													IL_029a:
													if (4 >= b)
													{
														goto IL_02a8;
													}
													goto IL_043e;
													IL_02a8:
													if (4 <= b)
													{
														goto IL_02b3;
													}
													goto IL_02fd;
													IL_02b3:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_02dc;
													IL_02dc:
													ptr2 += 8;
													goto IL_02ea;
													IL_02ea:
													num4--;
													goto IL_024e;
													IL_02fd:
													if (2 >= b)
													{
														goto IL_030b;
													}
													goto IL_03bb;
													IL_030b:
													if (2 <= b)
													{
														goto IL_0319;
													}
													goto IL_039a;
													IL_0319:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0387;
													IL_0387:
													num4 -= 2;
													goto IL_024e;
													IL_039a:
													if (1 >= b)
													{
														goto IL_03a8;
													}
													goto IL_0573;
													IL_03a8:
													if (1 <= b)
													{
													}
													goto IL_0573;
													IL_03bb:
													if (3 >= b)
													{
														goto IL_03c9;
													}
													goto IL_0573;
													IL_03c9:
													if (3 <= b)
													{
														goto IL_03d7;
													}
													goto IL_0573;
													IL_03d7:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0417;
													IL_0417:
													array[num4 - 2] = 0;
													goto IL_042b;
													IL_042b:
													num4--;
													goto IL_024e;
													IL_043e:
													if (6 >= b)
													{
														goto IL_0449;
													}
													goto IL_0494;
													IL_0449:
													if (6 <= b)
													{
														goto IL_024e;
													}
													num = 46;
													goto IL_0460;
													IL_0560:
													ptr2 += 8;
													goto IL_024e;
													IL_0460:
													if (5 >= b)
													{
														goto IL_046e;
													}
													goto IL_0573;
													IL_046e:
													if (5 <= b)
													{
														goto IL_047c;
													}
													goto IL_0573;
													IL_047c:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_024e;
													IL_0494:
													if (7 >= b)
													{
														goto IL_049f;
													}
													goto IL_0509;
													IL_049f:
													if (7 <= b)
													{
														goto IL_04ad;
													}
													goto IL_0573;
													IL_04ad:
													array[num4] = 0;
													goto IL_04bb;
													IL_04bb:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_04de;
													IL_04de:
													array2[num4] = null;
													goto IL_04e8;
													IL_04e8:
													num4++;
													goto IL_04f6;
													IL_04f6:
													ptr2 += 8;
													goto IL_024e;
													IL_0509:
													if (8 >= b)
													{
														goto IL_0514;
													}
													goto IL_0573;
													IL_0514:
													if (8 <= b)
													{
														goto IL_051f;
													}
													goto IL_0573;
													IL_051f:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													num = 14;
													goto IL_024e;
													IL_0573:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0544;
													continue;
													end_IL_018f:
													break;
												}
												continue;
												end_IL_01a2:
												break;
											}
											continue;
											end_IL_01b5:
											break;
										}
										continue;
										end_IL_01c9:
										break;
									}
									continue;
									end_IL_01de:
									break;
								}
								continue;
								end_IL_01f3:
								break;
							}
							continue;
							end_IL_0203:
							break;
						}
						continue;
						end_IL_0213:
						break;
					}
					continue;
					end_IL_0223:
					break;
				}
				continue;
				end_IL_0233:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_3)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 84;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 26;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getTotalSizeNames.ToStringEndgetApplicationName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 5;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0284:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0264:
																				if (5 < b)
																				{
																					goto IL_03f3;
																				}
																				while (true)
																				{
																					IL_0254:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0244:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0237:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_0203:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 44;
																											while (true)
																											{
																												IL_01ea:
																												ptr2 += 8;
																												num = 114;
																												while (true)
																												{
																													if (num != 114)
																													{
																														if (num != 1095)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 44:
																															goto IL_01ea;
																														case 32:
																														case 69:
																															goto IL_0203;
																														case 17:
																															goto IL_0237;
																														case 20:
																														case 83:
																															goto IL_0244;
																														case 90:
																															goto IL_0254;
																														case 81:
																															goto IL_0264;
																														case 50:
																															goto end_IL_0264;
																														case 77:
																															goto IL_0284;
																														case 34:
																															goto end_IL_0284;
																														case 5:
																															goto end_IL_0294;
																														case 13:
																															goto end_IL_02a4;
																														case 7:
																														case 70:
																															goto IL_02ba;
																														case 29:
																															goto IL_02c8;
																														case 12:
																														case 47:
																															goto IL_02d6;
																														case 63:
																															goto IL_02ef;
																														case 55:
																															goto IL_02fd;
																														case 10:
																															goto IL_030b;
																														case 73:
																														case 94:
																															goto IL_033a;
																														case 21:
																														case 49:
																															goto IL_0345;
																														case 98:
																															goto IL_0353;
																														case 75:
																															goto IL_0366;
																														case 16:
																														case 22:
																															goto IL_0371;
																														case 64:
																														case 87:
																															goto IL_0397;
																														case 18:
																															goto IL_03a5;
																														case 86:
																															goto IL_03c8;
																														case 14:
																															goto IL_03d2;
																														case 35:
																															goto IL_03e0;
																														case 78:
																															goto IL_03f3;
																														case 59:
																														case 105:
																															goto IL_03fe;
																														case 25:
																														case 30:
																															goto IL_0409;
																														case 31:
																															goto IL_0420;
																														case 61:
																															goto IL_0433;
																														case 8:
																														case 57:
																															goto IL_0441;
																														case 37:
																															goto IL_045d;
																														case 62:
																															goto IL_046b;
																														case 79:
																															goto IL_0476;
																														case 2:
																														case 67:
																															goto IL_0484;
																														case 15:
																															goto IL_04c4;
																														case 40:
																															goto end_IL_01d7;
																														case 45:
																															goto IL_04f4;
																														case 72:
																															goto IL_0502;
																														case 48:
																														case 91:
																															goto IL_0510;
																														case 51:
																															goto IL_0533;
																														case 58:
																															goto IL_0541;
																														case 104:
																															goto IL_0558;
																														case 19:
																														case 56:
																															goto IL_056b;
																														case 68:
																															goto IL_05d6;
																														case 1:
																														case 3:
																														case 9:
																														case 11:
																														case 24:
																														case 27:
																														case 28:
																														case 33:
																														case 38:
																														case 39:
																														case 42:
																														case 54:
																														case 65:
																														case 74:
																														case 80:
																														case 88:
																														case 96:
																														case 97:
																														case 99:
																														case 100:
																														case 101:
																															goto end_IL_0274;
																														case 4:
																														case 36:
																														case 46:
																														case 52:
																														case 66:
																														case 76:
																														case 82:
																														case 89:
																														case 92:
																														case 93:
																														case 95:
																														case 106:
																														case 107:
																															goto end_IL_02af;
																														case 41:
																															goto end_IL_05f9;
																														case 103:
																															goto end_IL_060c;
																														case 6:
																															goto end_IL_0616;
																														case 26:
																															goto end_IL_0621;
																														case 23:
																														case 71:
																															goto end_IL_0636;
																														case 53:
																															goto end_IL_0646;
																														case 43:
																														case 60:
																															goto end_IL_065f;
																														case 84:
																															goto end_IL_066f;
																														case 85:
																															goto end_IL_067f;
																														case 0:
																														case 102:
																															goto IL_06a3;
																														}
																														continue;
																													}
																													num5--;
																													goto end_IL_02af;
																													continue;
																													end_IL_01d7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02ba;
																									IL_030b:
																									ptr2 += 8;
																									goto end_IL_02af;
																									IL_02ba:
																									if (1 < b)
																									{
																										goto end_IL_0274;
																									}
																									goto IL_02c8;
																									IL_02c8:
																									if (1 > b)
																									{
																										goto end_IL_0274;
																									}
																									goto IL_02d6;
																									IL_02d6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_02ef;
																									IL_02ef:
																									array[num5] = 0;
																									goto IL_02fd;
																									IL_02fd:
																									num5++;
																									goto IL_030b;
																								}
																								break;
																							}
																							num = 73;
																							goto IL_033a;
																							IL_0366:
																							if (3 > b)
																							{
																								num = 101;
																								goto end_IL_0274;
																							}
																							goto IL_0371;
																							IL_0371:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02af;
																							IL_033a:
																							if (3 < b)
																							{
																								goto IL_0345;
																							}
																							goto IL_0366;
																							IL_0345:
																							if (4 < b)
																							{
																								goto end_IL_0274;
																							}
																							goto IL_0353;
																							IL_0353:
																							if (4 > b)
																							{
																								goto end_IL_0274;
																							}
																							goto end_IL_02af;
																						}
																						break;
																					}
																					goto IL_0397;
																					IL_03e0:
																					ptr2 += 8;
																					goto end_IL_02af;
																					IL_0397:
																					array[num5] = 0;
																					goto IL_03a5;
																					IL_03a5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03c8;
																					IL_03c8:
																					array2[num5] = null;
																					goto IL_03d2;
																					IL_03d2:
																					num5++;
																					goto IL_03e0;
																				}
																				goto IL_04e1;
																				IL_056b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 68;
																				goto IL_05d6;
																				IL_03f3:
																				if (8 < b)
																				{
																					goto IL_03fe;
																				}
																				goto IL_045d;
																				IL_03fe:
																				if (9 < b)
																				{
																					goto IL_0409;
																				}
																				goto IL_0433;
																				IL_0409:
																				if (10 < b)
																				{
																					goto end_IL_0274;
																				}
																				num = 31;
																				goto IL_0420;
																				IL_05d6:
																				num5 -= 2;
																				goto end_IL_02af;
																				IL_0420:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0274;
																				IL_0433:
																				if (9 > b)
																				{
																					goto end_IL_0274;
																				}
																				goto IL_0441;
																				IL_0441:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02af;
																				IL_045d:
																				if (8 > b)
																				{
																					goto IL_046b;
																				}
																				goto IL_056b;
																				IL_046b:
																				if (6 >= b)
																				{
																					goto IL_0476;
																				}
																				goto IL_04f4;
																				IL_0476:
																				if (6 > b)
																				{
																					goto end_IL_0274;
																				}
																				goto IL_0484;
																				IL_0484:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c4;
																				IL_04c4:
																				array[num5 - 2] = 0;
																				num = 40;
																				goto IL_04e1;
																				IL_04e1:
																				num5--;
																				goto end_IL_02af;
																				IL_04f4:
																				if (7 < b)
																				{
																					goto end_IL_0274;
																				}
																				goto IL_0502;
																				IL_0502:
																				if (7 > b)
																				{
																					goto end_IL_0274;
																				}
																				goto IL_0510;
																				IL_0510:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0533;
																				IL_0533:
																				array[num5] = 0;
																				goto IL_0541;
																				IL_0541:
																				num5++;
																				num = 104;
																				goto IL_0558;
																				IL_0558:
																				ptr2 += 8;
																				goto end_IL_02af;
																				continue;
																				end_IL_0264:
																				break;
																			}
																			continue;
																			end_IL_0274:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02af;
																	continue;
																	end_IL_0284:
																	break;
																}
																continue;
																end_IL_0294:
																break;
															}
															continue;
															end_IL_02a4:
															break;
														}
														continue;
														end_IL_02af:
														break;
													}
													continue;
												}
												goto IL_06a3;
												IL_06a3:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f9:
												break;
											}
											continue;
											end_IL_060c:
											break;
										}
										continue;
										end_IL_0616:
										break;
									}
									continue;
									end_IL_0621:
									break;
								}
								continue;
								end_IL_0636:
								break;
							}
							continue;
							end_IL_0646:
							break;
						}
						continue;
						end_IL_065f:
						break;
					}
					continue;
					end_IL_066f:
					break;
				}
				continue;
				end_IL_067f:
				break;
			}
		}
	}

	private static int smethod_9(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		if (num <= num2)
		{
			num = int_4;
			num2 = int_3;
			return num - num2;
		}
		num = int_3;
		num2 = int_4;
		return num - num2;
	}
}
