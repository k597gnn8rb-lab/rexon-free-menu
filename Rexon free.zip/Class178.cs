using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("First Person Camera", "Rig", "First person camera mode.", false, 45, ModType.const_0, false)]
internal class Class178 : MonoBehaviour
{
	private GameObject gameObject_0;

	private static bool bool_0;

	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static IntPtr[] ByteCapacityStoreCategoryEnumeration;

	private static IntPtr[] PermissionSetEntryReflectionOnlyLoadFrom;

	private static IntPtr[] PrimaryGroupSidNumLockOn;

	private static IntPtr[] EnumSubcategoriesFlagsFUiDefault;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0475, IL_0488, IL_049b, IL_04a8, IL_04b8, IL_04c8, IL_04d8, IL_04e8, IL_04f8, IL_0508, IL_0513, IL_051e, IL_052e, IL_0553, IL_0561, IL_059f, IL_05ad, IL_05c0, IL_05d3, IL_05dc, IL_05e7, IL_0639, IL_064c, IL_065a, IL_0668, IL_0676, IL_068a, IL_06d7, IL_06e5, IL_06f8, IL_0703, IL_0711, IL_071f, IL_0757, IL_076b, IL_077e, IL_0788, IL_0796, IL_07b2, IL_07bd, IL_07ea, IL_07fd, IL_0806, IL_0814, IL_0822, IL_082d, IL_083b, IL_0849, IL_0857, IL_086f, IL_087d, IL_0890, IL_089e, IL_08a7, IL_08bf, IL_08dd, IL_0901, IL_0919, IL_092c, IL_0935, IL_0973, IL_098f, IL_099a, IL_09a8, IL_09b6, IL_09ca, IL_0a02, IL_0a15, IL_0a20, IL_0a38, IL_0a4f, IL_0a5d, IL_0a70, IL_0a7e, IL_0a8c, IL_0aa0, IL_0ad8, IL_0aeb, IL_0af9, IL_0b07, IL_0b15, IL_0b23, IL_0b2e, IL_0b3c, IL_0b4f, IL_0b6c, IL_0bbb, IL_0bc5, IL_0bf2, IL_0c06, IL_0c14, IL_0c30, IL_0c39, IL_0c47, IL_0c55, IL_0c73, IL_0c81, IL_0c94, IL_0ca2, IL_0cad, IL_0cbb, IL_0cce, IL_0cdc, IL_0cea, IL_0d2a, IL_0d3e, IL_0d51, IL_0db3, IL_0dc6, IL_0dd4, IL_0de2, IL_0df0, IL_0dfb, IL_0e09, IL_0e17, IL_0e25, IL_0e48, IL_0e52, IL_0e60, IL_0e73, IL_0eb3, IL_0ed0, IL_0ee3, IL_0eee, IL_0efc, IL_0f0a, IL_0f13, IL_0f53, IL_0f67, IL_0f7a, IL_0f85, IL_0fae, IL_0fbc, IL_0fcf, IL_0fdd, IL_0feb, IL_0ff9, IL_1039, IL_104d, IL_1060, IL_106e, IL_1087, IL_1095, IL_10ac, IL_10bf, IL_10ff, IL_1113, IL_1123, IL_114c, IL_1162, IL_116b, IL_1187, IL_119a, IL_11a4, IL_11af, IL_11bf, IL_11cf, IL_11df, IL_11ef, IL_11ff, IL_120f, IL_121f, IL_122a, IL_123a, IL_1255 are reachable both inside and outside the pinned region starting at IL_124f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 200;
		int num4 = default(int);
		int num7 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num5;
			int num6;
			object[] array8;
			int num8;
			byte* num9;
			int __rxRef79 = default(int);
			ref int reference = ref __rxRef79;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_123a:
					num2 = 1;
					while (true)
					{
						IL_122a:
						num3 = num2 * 4;
						while (true)
						{
							IL_121f:
							num = 73;
							while (true)
							{
								IL_120f:
								array2 = new byte[4];
								while (true)
								{
									IL_11ff:
									array3 = new object[4];
									while (true)
									{
										IL_11ef:
										array4 = new int[4];
										while (true)
										{
											IL_11df:
											array5 = new int[6];
											while (true)
											{
												IL_11cf:
												array6 = new long[4];
												while (true)
												{
													array7 = new object[16];
													while (true)
													{
														IL_11af:
														array7[0] = this;
														while (true)
														{
															IL_11a4:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaKeyExchangeShortInlineI.DeclaringMethodAssemblyAlgorithmIdAttribute);
															while (true)
															{
																IL_119a:
																ptr2 = ptr;
																while (true)
																{
																	IL_1187:
																	if (num4 != 1)
																	{
																		while (true)
																		{
																			IL_0508:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_04f8:
																				ptr2++;
																				while (true)
																				{
																					IL_04e8:
																					if (b >= 1)
																					{
																						while (true)
																						{
																							IL_04d8:
																							if (b <= 28)
																							{
																								while (true)
																								{
																									IL_04c8:
																									if (14 < b)
																									{
																										while (true)
																										{
																											IL_04b8:
																											if (21 < b)
																											{
																												while (true)
																												{
																													IL_04a8:
																													if (25 < b)
																													{
																														while (true)
																														{
																															IL_049b:
																															if (27 < b)
																															{
																																while (true)
																																{
																																	IL_0488:
																																	if (28 < b)
																																	{
																																		num = 278;
																																		while (num != 278)
																																		{
																																			if (num != 1259)
																																			{
																																				goto end_IL_04e8;
																																			}
																																			switch (num)
																																			{
																																			case 200:
																																				break;
																																			default:
																																				continue;
																																			case 72:
																																				goto IL_0488;
																																			case 40:
																																				goto IL_049b;
																																			case 20:
																																			case 93:
																																				goto IL_04a8;
																																			case 36:
																																			case 81:
																																				goto IL_04b8;
																																			case 132:
																																				goto IL_04c8;
																																			case 253:
																																				goto IL_04d8;
																																			case 195:
																																				goto IL_04e8;
																																			case 133:
																																				goto IL_04f8;
																																			case 27:
																																			case 177:
																																				goto IL_0508;
																																			case 197:
																																				goto IL_0513;
																																			case 52:
																																			case 130:
																																				goto IL_051e;
																																			case 17:
																																			case 147:
																																				goto IL_052e;
																																			case 219:
																																				goto IL_0553;
																																			case 13:
																																			case 247:
																																				goto IL_0561;
																																			case 263:
																																				goto IL_059f;
																																			case 238:
																																				goto IL_05ad;
																																			case 257:
																																				goto IL_05c0;
																																			case 32:
																																				goto IL_05dc;
																																			case 192:
																																			case 244:
																																				goto IL_05e7;
																																			case 127:
																																				goto IL_0639;
																																			case 235:
																																				goto IL_064c;
																																			case 58:
																																			case 121:
																																				goto IL_065a;
																																			case 217:
																																				goto IL_0668;
																																			case 160:
																																			case 165:
																																				goto IL_0676;
																																			case 186:
																																				goto IL_068a;
																																			case 159:
																																				goto IL_06d7;
																																			case 111:
																																				goto IL_06e5;
																																			case 25:
																																				goto IL_06f8;
																																			case 172:
																																				goto IL_0703;
																																			case 151:
																																				goto IL_0711;
																																			case 14:
																																			case 18:
																																				goto IL_071f;
																																			case 96:
																																				goto IL_0757;
																																			case 41:
																																				goto IL_076b;
																																			case 87:
																																			case 161:
																																				goto IL_077e;
																																			case 39:
																																				goto IL_0788;
																																			case 269:
																																				goto IL_0796;
																																			case 44:
																																				goto IL_07b2;
																																			case 45:
																																			case 140:
																																				goto IL_07bd;
																																			case 205:
																																				goto IL_07ea;
																																			case 69:
																																			case 120:
																																				goto IL_0806;
																																			case 156:
																																				goto IL_0814;
																																			case 61:
																																				goto IL_0822;
																																			case 215:
																																				goto IL_082d;
																																			case 12:
																																				goto IL_083b;
																																			case 11:
																																			case 56:
																																				goto IL_0849;
																																			case 50:
																																				goto IL_0857;
																																			case 75:
																																				goto IL_086f;
																																			case 240:
																																				goto IL_087d;
																																			case 8:
																																				goto IL_0890;
																																			case 57:
																																			case 110:
																																				goto IL_08a7;
																																			case 63:
																																				goto IL_08bf;
																																			case 231:
																																				goto IL_08dd;
																																			case 88:
																																				goto IL_0901;
																																			case 103:
																																				goto IL_0919;
																																			case 9:
																																			case 137:
																																				goto IL_0935;
																																			case 179:
																																				goto IL_0973;
																																			case 178:
																																				goto IL_098f;
																																			case 149:
																																			case 207:
																																				goto IL_099a;
																																			case 123:
																																				goto IL_09a8;
																																			case 23:
																																			case 122:
																																				goto IL_09b6;
																																			case 236:
																																				goto IL_09ca;
																																			case 24:
																																				goto IL_0a02;
																																			case 208:
																																				goto IL_0a15;
																																			case 105:
																																			case 152:
																																				goto IL_0a20;
																																			case 146:
																																				goto IL_0a38;
																																			case 265:
																																				goto IL_0a4f;
																																			case 66:
																																				goto IL_0a5d;
																																			case 95:
																																				goto IL_0a70;
																																			case 212:
																																				goto IL_0a7e;
																																			case 85:
																																			case 126:
																																				goto IL_0a8c;
																																			case 33:
																																				goto IL_0aa0;
																																			case 108:
																																				goto IL_0ad8;
																																			case 34:
																																				goto IL_0aeb;
																																			case 134:
																																			case 164:
																																				goto IL_0af9;
																																			case 15:
																																			case 260:
																																				goto IL_0b07;
																																			case 189:
																																			case 232:
																																				goto IL_0b15;
																																			case 6:
																																				goto IL_0b23;
																																			case 65:
																																			case 209:
																																				goto IL_0b2e;
																																			case 259:
																																				goto IL_0b3c;
																																			case 109:
																																			case 170:
																																				goto IL_0b4f;
																																			case 48:
																																				goto IL_0c06;
																																			case 202:
																																				goto IL_0c14;
																																			case 54:
																																			case 79:
																																				goto IL_0c39;
																																			case 4:
																																				goto IL_0c47;
																																			case 89:
																																			case 243:
																																				goto IL_0c55;
																																			case 118:
																																				goto IL_0c73;
																																			case 193:
																																				goto IL_0c81;
																																			case 222:
																																				goto IL_0c94;
																																			case 153:
																																			case 239:
																																				goto IL_0ca2;
																																			case 102:
																																				goto IL_0cad;
																																			case 30:
																																			case 92:
																																				goto IL_0cbb;
																																			case 53:
																																				goto IL_0cce;
																																			case 190:
																																				goto IL_0cdc;
																																			case 128:
																																			case 145:
																																				goto IL_0cea;
																																			case 175:
																																				goto IL_0d2a;
																																			case 233:
																																				goto IL_0d3e;
																																			case 99:
																																			case 141:
																																				goto IL_0d51;
																																			case 90:
																																				goto IL_0db3;
																																			case 0:
																																				goto IL_0dc6;
																																			case 42:
																																			case 43:
																																				goto IL_0dd4;
																																			case 84:
																																				goto IL_0de2;
																																			case 169:
																																				goto IL_0df0;
																																			case 136:
																																				goto IL_0dfb;
																																			case 206:
																																				goto IL_0e09;
																																			case 21:
																																			case 237:
																																				goto IL_0e17;
																																			case 271:
																																				goto IL_0e25;
																																			case 264:
																																				goto IL_0e48;
																																			case 230:
																																				goto IL_0e52;
																																			case 221:
																																				goto IL_0e60;
																																			case 28:
																																			case 181:
																																				goto IL_0e73;
																																			case 185:
																																				goto IL_0eb3;
																																			case 22:
																																				goto IL_0ed0;
																																			case 91:
																																			case 183:
																																				goto IL_0ee3;
																																			case 234:
																																				goto IL_0efc;
																																			case 35:
																																			case 188:
																																				goto IL_0f13;
																																			case 246:
																																				goto IL_0f53;
																																			case 154:
																																				goto IL_0f67;
																																			case 256:
																																				goto IL_0f7a;
																																			case 101:
																																			case 196:
																																				goto IL_0f85;
																																			case 226:
																																				goto IL_0fae;
																																			case 187:
																																				goto IL_0fbc;
																																			case 173:
																																				goto IL_0fcf;
																																			case 83:
																																			case 142:
																																				goto IL_0fdd;
																																			case 67:
																																				goto IL_0feb;
																																			case 150:
																																			case 220:
																																				goto IL_0ff9;
																																			case 229:
																																				goto IL_1039;
																																			case 46:
																																				goto IL_104d;
																																			case 100:
																																				goto IL_1060;
																																			case 155:
																																			case 157:
																																				goto IL_106e;
																																			case 47:
																																				goto IL_1087;
																																			case 224:
																																				goto IL_1095;
																																			case 38:
																																				goto IL_10ac;
																																			case 49:
																																			case 55:
																																				goto IL_10bf;
																																			case 76:
																																				goto IL_10ff;
																																			case 114:
																																				goto IL_1113;
																																			case 241:
																																			case 262:
																																				goto IL_1123;
																																			case 59:
																																				goto IL_114c;
																																			case 2:
																																			case 7:
																																			case 16:
																																			case 31:
																																			case 37:
																																			case 62:
																																			case 68:
																																			case 71:
																																			case 82:
																																			case 97:
																																			case 106:
																																			case 112:
																																			case 115:
																																			case 116:
																																			case 125:
																																			case 138:
																																			case 139:
																																			case 143:
																																			case 148:
																																			case 158:
																																			case 162:
																																			case 163:
																																			case 166:
																																			case 167:
																																			case 171:
																																			case 174:
																																			case 176:
																																			case 180:
																																			case 191:
																																			case 198:
																																			case 201:
																																			case 204:
																																			case 210:
																																			case 211:
																																			case 213:
																																			case 214:
																																			case 216:
																																			case 218:
																																			case 223:
																																			case 249:
																																			case 250:
																																			case 251:
																																			case 252:
																																			case 261:
																																			case 267:
																																			case 268:
																																			case 270:
																																				goto end_IL_0475;
																																			case 5:
																																			case 19:
																																			case 26:
																																			case 29:
																																			case 51:
																																			case 60:
																																			case 64:
																																			case 70:
																																			case 77:
																																			case 78:
																																			case 86:
																																			case 94:
																																			case 98:
																																			case 104:
																																			case 113:
																																			case 117:
																																			case 119:
																																			case 129:
																																			case 135:
																																			case 168:
																																			case 182:
																																			case 184:
																																			case 225:
																																			case 228:
																																			case 242:
																																			case 245:
																																			case 248:
																																			case 254:
																																			case 255:
																																			case 258:
																																			case 266:
																																				goto IL_1187;
																																			case 144:
																																				goto IL_119a;
																																			case 227:
																																				goto IL_11a4;
																																			case 74:
																																				goto IL_11af;
																																			case 194:
																																				goto end_IL_04e8;
																																			case 1:
																																				goto IL_11cf;
																																			case 80:
																																				goto IL_11df;
																																			case 10:
																																				goto IL_11ef;
																																			case 203:
																																				goto IL_11ff;
																																			case 73:
																																				goto IL_120f;
																																			case 124:
																																				goto IL_121f;
																																			case 3:
																																				goto IL_122a;
																																			case 199:
																																				goto IL_123a;
																																			case 107:
																																			case 131:
																																				return;
																																			}
																																			goto end_IL_11bf;
																																			continue;
																																			end_IL_0475:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_05c0;
																																	IL_05c0:
																																	if (28 <= b)
																																	{
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_0513;
																															IL_052e:
																															num5 = ptr2;
																															num6 = -200;
																															num4 = 1;
																															ptr2 = num5 + num6;
																															num = 117;
																															goto IL_1187;
																															IL_0513:
																															if (27 > b)
																															{
																																goto IL_051e;
																															}
																															goto IL_052e;
																															IL_051e:
																															if (26 < b)
																															{
																																break;
																															}
																															goto IL_0553;
																															IL_0553:
																															if (26 > b)
																															{
																																break;
																															}
																															goto IL_0561;
																															IL_0561:
																															((delegate*<GameObject, bool, void>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((GameObject)array3[num7 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) != 0);
																															goto IL_059f;
																															IL_059f:
																															num7 -= 2;
																															goto IL_05ad;
																															IL_05ad:
																															ptr2 += 8;
																															goto IL_1187;
																														}
																														break;
																													}
																													num = 32;
																													goto IL_05dc;
																													IL_0788:
																													array2[num7] = 5;
																													goto IL_0796;
																													IL_0796:
																													num7++;
																													num = 258;
																													goto IL_1187;
																													IL_05dc:
																													if (25 <= b)
																													{
																														goto IL_05e7;
																													}
																													goto IL_064c;
																													IL_05e7:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0639;
																													IL_0639:
																													num7--;
																													goto IL_1187;
																													IL_064c:
																													if (23 < b)
																													{
																														goto IL_065a;
																													}
																													goto IL_06f8;
																													IL_065a:
																													if (24 < b)
																													{
																														break;
																													}
																													goto IL_0668;
																													IL_0668:
																													if (24 > b)
																													{
																														break;
																													}
																													goto IL_0676;
																													IL_0676:
																													array2[num7 - 2] = 0;
																													goto IL_068a;
																													IL_068a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((GameObject)array3[num7 - 2], (UnityEngine.Object)array3[num7 - 1]) ? 1 : 0);
																													goto IL_06d7;
																													IL_06d7:
																													num7--;
																													goto IL_06e5;
																													IL_06e5:
																													ptr2 += 8;
																													goto IL_1187;
																													IL_06f8:
																													if (23 > b)
																													{
																														goto IL_0703;
																													}
																													goto IL_077e;
																													IL_0703:
																													if (22 < b)
																													{
																														break;
																													}
																													goto IL_0711;
																													IL_0711:
																													if (22 > b)
																													{
																														break;
																													}
																													goto IL_071f;
																													IL_071f:
																													array3[num7 - 1] = ((delegate*<Class178, GameObject>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((Class178)array3[num7 - 1]);
																													goto IL_0757;
																													IL_0757:
																													array2[num7 - 1] = 5;
																													goto IL_076b;
																													IL_076b:
																													ptr2 += 8;
																													goto IL_1187;
																													IL_077e:
																													array3[num7] = null;
																													goto IL_0788;
																												}
																												break;
																											}
																											goto IL_07b2;
																											IL_0a7e:
																											if (18 > b)
																											{
																												break;
																											}
																											goto IL_0a8c;
																											IL_07b2:
																											if (21 <= b)
																											{
																												goto IL_07bd;
																											}
																											num = 69;
																											goto IL_0806;
																											IL_07bd:
																											((Class178)array3[num7 - 2]).gameObject_0 = (GameObject)array3[num7 - 1];
																											goto IL_07ea;
																											IL_07ea:
																											num7 -= 2;
																											goto IL_1187;
																											IL_0a8c:
																											array2[num7 - 1] = 5;
																											goto IL_0aa0;
																											IL_0806:
																											if (17 >= b)
																											{
																												goto IL_0814;
																											}
																											goto IL_098f;
																											IL_0814:
																											if (17 > b)
																											{
																												goto IL_0822;
																											}
																											num = 137;
																											goto IL_0935;
																											IL_0822:
																											if (15 < b)
																											{
																												goto IL_082d;
																											}
																											goto IL_0890;
																											IL_082d:
																											if (16 < b)
																											{
																												break;
																											}
																											goto IL_083b;
																											IL_083b:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_0849;
																											IL_0849:
																											array2[num7] = 5;
																											goto IL_0857;
																											IL_0857:
																											array3[num7] = array7[*(int*)(ptr2 + num3)];
																											goto IL_086f;
																											IL_086f:
																											num7++;
																											goto IL_087d;
																											IL_087d:
																											ptr2 += 8;
																											goto IL_1187;
																											IL_0890:
																											if (15 > b)
																											{
																												break;
																											}
																											num = 110;
																											goto IL_08a7;
																											IL_0ad8:
																											ptr2 += 8;
																											goto IL_1187;
																											IL_08a7:
																											array2[num7] = array2[num7 - 1];
																											goto IL_08bf;
																											IL_08bf:
																											array4[num7 - 0] = array4[num7 - 1];
																											goto IL_08dd;
																											IL_08dd:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																											goto IL_0901;
																											IL_0901:
																											array3[num7] = array3[num7 - 1];
																											goto IL_0919;
																											IL_0919:
																											num7++;
																											goto IL_1187;
																											IL_0aa0:
																											array3[num7 - 1] = ((delegate*<string[], string>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																											goto IL_0ad8;
																											IL_0935:
																											((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
																											goto IL_0973;
																											IL_0973:
																											num7 -= 3;
																											num = 113;
																											goto IL_1187;
																											IL_098f:
																											if (19 < b)
																											{
																												goto IL_099a;
																											}
																											goto IL_0a15;
																											IL_099a:
																											if (20 < b)
																											{
																												break;
																											}
																											goto IL_09a8;
																											IL_09a8:
																											if (20 > b)
																											{
																												break;
																											}
																											goto IL_09b6;
																											IL_09b6:
																											array2[num7 - 1] = 5;
																											goto IL_09ca;
																											IL_09ca:
																											array3[num7 - 1] = ((delegate*<string, GameObject>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
																											goto IL_0a02;
																											IL_0a02:
																											ptr2 += 8;
																											goto IL_1187;
																											IL_0a15:
																											if (19 <= b)
																											{
																												goto IL_0a20;
																											}
																											goto IL_0a70;
																											IL_0a20:
																											array3[num7] = array7[*(int*)(ptr2 + num3)];
																											goto IL_0a38;
																											IL_0a38:
																											array2[num7] = 5;
																											num = 265;
																											goto IL_0a4f;
																											IL_0a4f:
																											num7++;
																											goto IL_0a5d;
																											IL_0a5d:
																											ptr2 += 8;
																											goto IL_1187;
																											IL_0a70:
																											if (18 < b)
																											{
																												break;
																											}
																											goto IL_0a7e;
																										}
																										break;
																									}
																									goto IL_0aeb;
																									IL_1095:
																									num7++;
																									num = 38;
																									goto IL_10ac;
																									IL_0aeb:
																									if (14 > b)
																									{
																										goto IL_0af9;
																									}
																									goto IL_1123;
																									IL_0af9:
																									if (7 < b)
																									{
																										goto IL_0b07;
																									}
																									goto IL_0dc6;
																									IL_0b07:
																									if (10 < b)
																									{
																										goto IL_0b15;
																									}
																									goto IL_0c94;
																									IL_0b15:
																									if (12 >= b)
																									{
																										goto IL_0b23;
																									}
																									num = 79;
																									goto IL_0c39;
																									IL_0b23:
																									if (12 > b)
																									{
																										goto IL_0b2e;
																									}
																									goto IL_0b4f;
																									IL_0b2e:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_0b3c;
																									IL_0b3c:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_1187;
																									IL_0b4f:
																									array8 = array3;
																									num8 = num7;
																									if (array == null)
																									{
																										goto IL_0b5e;
																									}
																									num9 = ptr2;
																									byte b2 = *num9;
																									ptr2 = num9 + 4;
																									int num10 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num10;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_0c06;
																									IL_10bf:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_10ff;
																									IL_10ff:
																									array2[num7 - 2] = 0;
																									goto IL_1113;
																									IL_1113:
																									num7--;
																									goto IL_1187;
																									IL_0c06:
																									array2[num7] = 5;
																									goto IL_0c14;
																									IL_0c14:
																									num7++;
																									num = 78;
																									goto IL_1187;
																									IL_10ac:
																									ptr2 += 8;
																									goto IL_1187;
																									IL_0c39:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_0c47;
																									IL_0c47:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_0c55;
																									IL_0c55:
																									array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																									goto IL_0c73;
																									IL_0c73:
																									ptr2 += 8;
																									goto IL_0c81;
																									IL_0c81:
																									num7--;
																									goto IL_1187;
																									IL_0c94:
																									if (10 > b)
																									{
																										goto IL_0ca2;
																									}
																									goto IL_0d51;
																									IL_0ca2:
																									if (8 >= b)
																									{
																										goto IL_0cad;
																									}
																									goto IL_0cce;
																									IL_0cad:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0cbb;
																									IL_0cbb:
																									num7--;
																									goto IL_1187;
																									IL_0cce:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_0cdc;
																									IL_0cdc:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_0cea;
																									IL_0cea:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_0d2a;
																									IL_0d2a:
																									array2[num7 - 2] = 0;
																									goto IL_0d3e;
																									IL_0d3e:
																									num7--;
																									goto IL_1187;
																									IL_0d51:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0db3;
																									IL_0db3:
																									num7 -= 2;
																									goto IL_1187;
																									IL_0dc6:
																									if (7 > b)
																									{
																										goto IL_0dd4;
																									}
																									goto IL_10bf;
																									IL_0dd4:
																									if (3 < b)
																									{
																										goto IL_0de2;
																									}
																									goto IL_0f7a;
																									IL_0de2:
																									if (5 >= b)
																									{
																										goto IL_0df0;
																									}
																									goto IL_0ee3;
																									IL_0df0:
																									if (5 > b)
																									{
																										goto IL_0dfb;
																									}
																									goto IL_0e73;
																									IL_0dfb:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_0e09;
																									IL_0e09:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_0e17;
																									IL_0e17:
																									array2[num7] = 0;
																									goto IL_0e25;
																									IL_0e25:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
																									goto IL_0e48;
																									IL_0e48:
																									array3[num7] = null;
																									goto IL_0e52;
																									IL_0e52:
																									num7++;
																									goto IL_0e60;
																									IL_0e60:
																									ptr2 += 8;
																									goto IL_1187;
																									IL_0e73:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_0eb3;
																									IL_0eb3:
																									array2[num7 - 2] = 0;
																									num = 22;
																									goto IL_0ed0;
																									IL_0ed0:
																									num7--;
																									goto IL_1187;
																									IL_0ee3:
																									if (6 < b)
																									{
																										num = 214;
																										break;
																									}
																									goto IL_0efc;
																									IL_1123:
																									array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
																									goto IL_114c;
																									IL_0efc:
																									if (6 > b)
																									{
																										break;
																									}
																									num = 35;
																									goto IL_0f13;
																									IL_114c:
																									array2[num7 - 1] = 5;
																									goto IL_1187;
																									IL_0f13:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_0f53;
																									IL_0f53:
																									array2[num7 - 2] = 0;
																									goto IL_0f67;
																									IL_0f67:
																									num7--;
																									goto IL_1187;
																									IL_0f7a:
																									if (3 <= b)
																									{
																										goto IL_0f85;
																									}
																									goto IL_0fcf;
																									IL_0f85:
																									reference = ref array5[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_0fae;
																									IL_0fae:
																									ptr2 += 8;
																									goto IL_0fbc;
																									IL_0fbc:
																									num7--;
																									goto IL_1187;
																									IL_0fcf:
																									if (1 < b)
																									{
																										goto IL_0fdd;
																									}
																									goto IL_1060;
																									IL_0fdd:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_0feb;
																									IL_0feb:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_0ff9;
																									IL_0ff9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																									goto IL_1039;
																									IL_1039:
																									array2[num7 - 2] = 0;
																									goto IL_104d;
																									IL_104d:
																									num7--;
																									goto IL_1187;
																									IL_1060:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_106e;
																									IL_106e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
																									goto IL_1087;
																									IL_1087:
																									array2[num7] = 0;
																									goto IL_1095;
																								}
																							}
																							else
																							{
																								num = 37;
																							}
																							break;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					num = 129;
																					goto IL_1187;
																					continue;
																					end_IL_04e8:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	num = 107;
																	return;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_11bf:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0b5e:
			while (true)
			{
				IL_0b5e_2:
				array = new byte[4];
				while (true)
				{
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0c06_2:
						array2[num7] = 5;
						while (true)
						{
							IL_0c14_2:
							num7++;
							num = 78;
							while (true)
							{
								IL_1187_2:
								if (num4 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_04e8_2:
												if (b >= 1)
												{
													while (true)
													{
														IL_04d8_2:
														if (b <= 28)
														{
															while (true)
															{
																IL_04c8_2:
																if (14 < b)
																{
																	while (true)
																	{
																		IL_04b8_2:
																		if (21 < b)
																		{
																			while (true)
																			{
																				IL_04a8_2:
																				if (25 < b)
																				{
																					while (true)
																					{
																						IL_049b_2:
																						if (27 < b)
																						{
																							while (true)
																							{
																								IL_0488_2:
																								if (28 < b)
																								{
																									num = 278;
																									while (num != 278)
																									{
																										if (num != 1259)
																										{
																											goto IL_11bf_2;
																										}
																										switch (num)
																										{
																										case 72:
																											goto IL_0488_2;
																										case 40:
																											goto IL_049b_2;
																										case 20:
																										case 93:
																											goto IL_04a8_2;
																										case 36:
																										case 81:
																											goto IL_04b8_2;
																										case 132:
																											goto IL_04c8_2;
																										case 253:
																											goto IL_04d8_2;
																										case 195:
																											goto IL_04e8_2;
																										case 133:
																											goto end_IL_04e8_2;
																										case 27:
																										case 177:
																											goto end_IL_04f8;
																										case 197:
																											goto IL_0513_2;
																										case 52:
																										case 130:
																											goto IL_051e_2;
																										case 17:
																										case 147:
																											goto IL_052e_2;
																										case 219:
																											goto IL_0553_2;
																										case 13:
																										case 247:
																											goto IL_0561_2;
																										case 263:
																											goto IL_059f_2;
																										case 238:
																											goto IL_05ad_2;
																										case 257:
																											goto IL_05c0_2;
																										case 32:
																											goto IL_05dc_2;
																										case 192:
																										case 244:
																											goto IL_05e7_2;
																										case 127:
																											goto IL_0639_2;
																										case 235:
																											goto IL_064c_2;
																										case 58:
																										case 121:
																											goto IL_065a_2;
																										case 217:
																											goto IL_0668_2;
																										case 160:
																										case 165:
																											goto IL_0676_2;
																										case 186:
																											goto IL_068a_2;
																										case 159:
																											goto IL_06d7_2;
																										case 111:
																											goto IL_06e5_2;
																										case 25:
																											goto IL_06f8_2;
																										case 172:
																											goto IL_0703_2;
																										case 151:
																											goto IL_0711_2;
																										case 14:
																										case 18:
																											goto IL_071f_2;
																										case 96:
																											goto IL_0757_2;
																										case 41:
																											goto IL_076b_2;
																										case 87:
																										case 161:
																											goto IL_077e_2;
																										case 39:
																											goto IL_0788_2;
																										case 269:
																											goto IL_0796_2;
																										case 44:
																											goto IL_07b2_2;
																										case 45:
																										case 140:
																											goto IL_07bd_2;
																										case 205:
																											goto IL_07ea_2;
																										case 69:
																										case 120:
																											goto IL_0806_2;
																										case 156:
																											goto IL_0814_2;
																										case 61:
																											goto IL_0822_2;
																										case 215:
																											goto IL_082d_2;
																										case 12:
																											goto IL_083b_2;
																										case 11:
																										case 56:
																											goto IL_0849_2;
																										case 50:
																											goto IL_0857_2;
																										case 75:
																											goto IL_086f_2;
																										case 240:
																											goto IL_087d_2;
																										case 8:
																											goto IL_0890_2;
																										case 57:
																										case 110:
																											goto IL_08a7_2;
																										case 63:
																											goto IL_08bf_2;
																										case 231:
																											goto IL_08dd_2;
																										case 88:
																											goto IL_0901_2;
																										case 103:
																											goto IL_0919_2;
																										case 9:
																										case 137:
																											goto IL_0935_2;
																										case 179:
																											goto IL_0973_2;
																										case 178:
																											goto IL_098f_2;
																										case 149:
																										case 207:
																											goto IL_099a_2;
																										case 123:
																											goto IL_09a8_2;
																										case 23:
																										case 122:
																											goto IL_09b6_2;
																										case 236:
																											goto IL_09ca_2;
																										case 24:
																											goto IL_0a02_2;
																										case 208:
																											goto IL_0a15_2;
																										case 105:
																										case 152:
																											goto IL_0a20_2;
																										case 146:
																											goto IL_0a38_2;
																										case 265:
																											goto IL_0a4f_2;
																										case 66:
																											goto IL_0a5d_2;
																										case 95:
																											goto IL_0a70_2;
																										case 212:
																											goto IL_0a7e_2;
																										case 85:
																										case 126:
																											goto IL_0a8c_2;
																										case 33:
																											goto IL_0aa0_2;
																										case 108:
																											goto IL_0ad8_2;
																										case 34:
																											goto IL_0aeb_2;
																										case 134:
																										case 164:
																											goto IL_0af9_2;
																										case 15:
																										case 260:
																											goto IL_0b07_2;
																										case 189:
																										case 232:
																											goto IL_0b15_2;
																										case 6:
																											goto IL_0b23_2;
																										case 65:
																										case 209:
																											goto IL_0b2e_2;
																										case 259:
																											goto IL_0b3c_2;
																										case 109:
																										case 170:
																											goto end_IL_0508;
																										case 48:
																											goto IL_0c06_2;
																										case 202:
																											goto IL_0c14_2;
																										case 54:
																										case 79:
																											goto IL_0c39_2;
																										case 4:
																											goto IL_0c47_2;
																										case 89:
																										case 243:
																											goto IL_0c55_2;
																										case 118:
																											goto IL_0c73_2;
																										case 193:
																											goto IL_0c81_2;
																										case 222:
																											goto IL_0c94_2;
																										case 153:
																										case 239:
																											goto IL_0ca2_2;
																										case 102:
																											goto IL_0cad_2;
																										case 30:
																										case 92:
																											goto IL_0cbb_2;
																										case 53:
																											goto IL_0cce_2;
																										case 190:
																											goto IL_0cdc_2;
																										case 128:
																										case 145:
																											goto IL_0cea_2;
																										case 175:
																											goto IL_0d2a_2;
																										case 233:
																											goto IL_0d3e_2;
																										case 99:
																										case 141:
																											goto IL_0d51_2;
																										case 90:
																											goto IL_0db3_2;
																										case 0:
																											goto IL_0dc6_2;
																										case 42:
																										case 43:
																											goto IL_0dd4_2;
																										case 84:
																											goto IL_0de2_2;
																										case 169:
																											goto IL_0df0_2;
																										case 136:
																											goto IL_0dfb_2;
																										case 206:
																											goto IL_0e09_2;
																										case 21:
																										case 237:
																											goto IL_0e17_2;
																										case 271:
																											goto IL_0e25_2;
																										case 264:
																											goto IL_0e48_2;
																										case 230:
																											goto IL_0e52_2;
																										case 221:
																											goto IL_0e60_2;
																										case 28:
																										case 181:
																											goto IL_0e73_2;
																										case 185:
																											goto IL_0eb3_2;
																										case 22:
																											goto IL_0ed0_2;
																										case 91:
																										case 183:
																											goto IL_0ee3_2;
																										case 234:
																											goto IL_0efc_2;
																										case 35:
																										case 188:
																											goto IL_0f13_2;
																										case 246:
																											goto IL_0f53_2;
																										case 154:
																											goto IL_0f67_2;
																										case 256:
																											goto IL_0f7a_2;
																										case 101:
																										case 196:
																											goto IL_0f85_2;
																										case 226:
																											goto IL_0fae_2;
																										case 187:
																											goto IL_0fbc_2;
																										case 173:
																											goto IL_0fcf_2;
																										case 83:
																										case 142:
																											goto IL_0fdd_2;
																										case 67:
																											goto IL_0feb_2;
																										case 150:
																										case 220:
																											goto IL_0ff9_2;
																										case 229:
																											goto IL_1039_2;
																										case 46:
																											goto IL_104d_2;
																										case 100:
																											goto IL_1060_2;
																										case 155:
																										case 157:
																											goto IL_106e_2;
																										case 47:
																											goto IL_1087_2;
																										case 224:
																											goto IL_1095_2;
																										case 38:
																											goto IL_10ac_2;
																										case 49:
																										case 55:
																											goto IL_10bf_2;
																										case 76:
																											goto IL_10ff_2;
																										case 114:
																											goto IL_1113_2;
																										case 241:
																										case 262:
																											goto IL_1123_2;
																										case 59:
																											goto IL_114c_2;
																										case 2:
																										case 7:
																										case 16:
																										case 31:
																										case 37:
																										case 62:
																										case 68:
																										case 71:
																										case 82:
																										case 97:
																										case 106:
																										case 112:
																										case 115:
																										case 116:
																										case 125:
																										case 138:
																										case 139:
																										case 143:
																										case 148:
																										case 158:
																										case 162:
																										case 163:
																										case 166:
																										case 167:
																										case 171:
																										case 174:
																										case 176:
																										case 180:
																										case 191:
																										case 198:
																										case 201:
																										case 204:
																										case 210:
																										case 211:
																										case 213:
																										case 214:
																										case 216:
																										case 218:
																										case 223:
																										case 249:
																										case 250:
																										case 251:
																										case 252:
																										case 261:
																										case 267:
																										case 268:
																										case 270:
																											goto end_IL_0475_2;
																										case 5:
																										case 19:
																										case 26:
																										case 29:
																										case 51:
																										case 60:
																										case 64:
																										case 70:
																										case 77:
																										case 78:
																										case 86:
																										case 94:
																										case 98:
																										case 104:
																										case 113:
																										case 117:
																										case 119:
																										case 129:
																										case 135:
																										case 168:
																										case 182:
																										case 184:
																										case 225:
																										case 228:
																										case 242:
																										case 245:
																										case 248:
																										case 254:
																										case 255:
																										case 258:
																										case 266:
																											goto IL_1187_2;
																										case 144:
																											goto IL_119a_2;
																										case 227:
																											goto IL_11a4_2;
																										case 74:
																											goto IL_11af_2;
																										case 194:
																											goto IL_11bf_2;
																										case 1:
																											array6 = new long[4];
																											goto IL_11bf_2;
																										case 80:
																											array5 = new int[6];
																											goto case 1;
																										case 10:
																											array4 = new int[4];
																											goto case 80;
																										case 203:
																											array3 = new object[4];
																											goto case 10;
																										case 73:
																											array2 = new byte[4];
																											goto case 203;
																										case 124:
																											num = 73;
																											goto case 73;
																										case 3:
																											num3 = num2 * 4;
																											goto case 124;
																										case 199:
																											num2 = 1;
																											goto case 3;
																										case 200:
																											goto end_IL_0b6c;
																										case 107:
																										case 131:
																											return;
																										}
																										continue;
																										IL_11a4_2:
																										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaKeyExchangeShortInlineI.DeclaringMethodAssemblyAlgorithmIdAttribute);
																										goto IL_119a_2;
																										IL_119a_2:
																										ptr2 = ptr;
																										goto IL_1187_2;
																										IL_11bf_2:
																										array7 = new object[16];
																										goto IL_11af_2;
																										IL_11af_2:
																										array7[0] = this;
																										goto IL_11a4_2;
																										continue;
																										end_IL_0475_2:
																										break;
																									}
																									break;
																								}
																								goto IL_05c0_2;
																								IL_05c0_2:
																								if (28 <= b)
																								{
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0513_2;
																						IL_052e_2:
																						num5 = ptr2;
																						num6 = -200;
																						num4 = 1;
																						ptr2 = num5 + num6;
																						num = 117;
																						goto IL_1187_2;
																						IL_0513_2:
																						if (27 > b)
																						{
																							goto IL_051e_2;
																						}
																						goto IL_052e_2;
																						IL_051e_2:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0553_2;
																						IL_0553_2:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_0561_2;
																						IL_0561_2:
																						((delegate*<GameObject, bool, void>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((GameObject)array3[num7 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) != 0);
																						goto IL_059f_2;
																						IL_059f_2:
																						num7 -= 2;
																						goto IL_05ad_2;
																						IL_05ad_2:
																						ptr2 += 8;
																						goto IL_1187_2;
																					}
																					break;
																				}
																				num = 32;
																				goto IL_05dc_2;
																				IL_0788_2:
																				array2[num7] = 5;
																				goto IL_0796_2;
																				IL_0796_2:
																				num7++;
																				num = 258;
																				goto IL_1187_2;
																				IL_05dc_2:
																				if (25 <= b)
																				{
																					goto IL_05e7_2;
																				}
																				goto IL_064c_2;
																				IL_05e7_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0639_2;
																				IL_0639_2:
																				num7--;
																				goto IL_1187_2;
																				IL_064c_2:
																				if (23 < b)
																				{
																					goto IL_065a_2;
																				}
																				goto IL_06f8_2;
																				IL_065a_2:
																				if (24 < b)
																				{
																					break;
																				}
																				goto IL_0668_2;
																				IL_0668_2:
																				if (24 > b)
																				{
																					break;
																				}
																				goto IL_0676_2;
																				IL_0676_2:
																				array2[num7 - 2] = 0;
																				goto IL_068a_2;
																				IL_068a_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((GameObject)array3[num7 - 2], (UnityEngine.Object)array3[num7 - 1]) ? 1 : 0);
																				goto IL_06d7_2;
																				IL_06d7_2:
																				num7--;
																				goto IL_06e5_2;
																				IL_06e5_2:
																				ptr2 += 8;
																				goto IL_1187_2;
																				IL_06f8_2:
																				if (23 > b)
																				{
																					goto IL_0703_2;
																				}
																				goto IL_077e_2;
																				IL_0703_2:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0711_2;
																				IL_0711_2:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_071f_2;
																				IL_071f_2:
																				array3[num7 - 1] = ((delegate*<Class178, GameObject>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((Class178)array3[num7 - 1]);
																				goto IL_0757_2;
																				IL_0757_2:
																				array2[num7 - 1] = 5;
																				goto IL_076b_2;
																				IL_076b_2:
																				ptr2 += 8;
																				goto IL_1187_2;
																				IL_077e_2:
																				array3[num7] = null;
																				goto IL_0788_2;
																			}
																			break;
																		}
																		goto IL_07b2_2;
																		IL_0a7e_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0a8c_2;
																		IL_07b2_2:
																		if (21 <= b)
																		{
																			goto IL_07bd_2;
																		}
																		num = 69;
																		goto IL_0806_2;
																		IL_07bd_2:
																		((Class178)array3[num7 - 2]).gameObject_0 = (GameObject)array3[num7 - 1];
																		goto IL_07ea_2;
																		IL_07ea_2:
																		num7 -= 2;
																		goto IL_1187_2;
																		IL_0a8c_2:
																		array2[num7 - 1] = 5;
																		goto IL_0aa0_2;
																		IL_0806_2:
																		if (17 >= b)
																		{
																			goto IL_0814_2;
																		}
																		goto IL_098f_2;
																		IL_0814_2:
																		if (17 > b)
																		{
																			goto IL_0822_2;
																		}
																		num = 137;
																		goto IL_0935_2;
																		IL_0822_2:
																		if (15 < b)
																		{
																			goto IL_082d_2;
																		}
																		goto IL_0890_2;
																		IL_082d_2:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_083b_2;
																		IL_083b_2:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_0849_2;
																		IL_0849_2:
																		array2[num7] = 5;
																		goto IL_0857_2;
																		IL_0857_2:
																		array3[num7] = array7[*(int*)(ptr2 + num3)];
																		goto IL_086f_2;
																		IL_086f_2:
																		num7++;
																		goto IL_087d_2;
																		IL_087d_2:
																		ptr2 += 8;
																		goto IL_1187_2;
																		IL_0890_2:
																		if (15 > b)
																		{
																			break;
																		}
																		num = 110;
																		goto IL_08a7_2;
																		IL_0ad8_2:
																		ptr2 += 8;
																		goto IL_1187_2;
																		IL_08a7_2:
																		array2[num7] = array2[num7 - 1];
																		goto IL_08bf_2;
																		IL_08bf_2:
																		array4[num7 - 0] = array4[num7 - 1];
																		goto IL_08dd_2;
																		IL_08dd_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																		goto IL_0901_2;
																		IL_0901_2:
																		array3[num7] = array3[num7 - 1];
																		goto IL_0919_2;
																		IL_0919_2:
																		num7++;
																		goto IL_1187_2;
																		IL_0aa0_2:
																		array3[num7 - 1] = ((delegate*<string[], string>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																		goto IL_0ad8_2;
																		IL_0935_2:
																		((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
																		goto IL_0973_2;
																		IL_0973_2:
																		num7 -= 3;
																		num = 113;
																		goto IL_1187_2;
																		IL_098f_2:
																		if (19 < b)
																		{
																			goto IL_099a_2;
																		}
																		goto IL_0a15_2;
																		IL_099a_2:
																		if (20 < b)
																		{
																			break;
																		}
																		goto IL_09a8_2;
																		IL_09a8_2:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_09b6_2;
																		IL_09b6_2:
																		array2[num7 - 1] = 5;
																		goto IL_09ca_2;
																		IL_09ca_2:
																		array3[num7 - 1] = ((delegate*<string, GameObject>)ByteCapacityStoreCategoryEnumeration[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
																		goto IL_0a02_2;
																		IL_0a02_2:
																		ptr2 += 8;
																		goto IL_1187_2;
																		IL_0a15_2:
																		if (19 <= b)
																		{
																			goto IL_0a20_2;
																		}
																		goto IL_0a70_2;
																		IL_0a20_2:
																		array3[num7] = array7[*(int*)(ptr2 + num3)];
																		goto IL_0a38_2;
																		IL_0a38_2:
																		array2[num7] = 5;
																		num = 265;
																		goto IL_0a4f_2;
																		IL_0a4f_2:
																		num7++;
																		goto IL_0a5d_2;
																		IL_0a5d_2:
																		ptr2 += 8;
																		goto IL_1187_2;
																		IL_0a70_2:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_0a7e_2;
																	}
																	break;
																}
																goto IL_0aeb_2;
																IL_10ff_2:
																array2[num7 - 2] = 0;
																goto IL_1113_2;
																IL_0aeb_2:
																if (14 > b)
																{
																	goto IL_0af9_2;
																}
																goto IL_1123_2;
																IL_0af9_2:
																if (7 < b)
																{
																	goto IL_0b07_2;
																}
																goto IL_0dc6_2;
																IL_0b07_2:
																if (10 < b)
																{
																	goto IL_0b15_2;
																}
																goto IL_0c94_2;
																IL_0b15_2:
																if (12 >= b)
																{
																	goto IL_0b23_2;
																}
																num = 79;
																goto IL_0c39_2;
																IL_0b23_2:
																if (12 <= b)
																{
																	goto end_IL_0508;
																}
																goto IL_0b2e_2;
																IL_0b2e_2:
																if (11 < b)
																{
																	break;
																}
																goto IL_0b3c_2;
																IL_0b3c_2:
																if (11 > b)
																{
																	break;
																}
																goto IL_1187_2;
																IL_1113_2:
																num7--;
																goto IL_1187_2;
																IL_0c39_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_0c47_2;
																IL_0c47_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_0c55_2;
																IL_0c55_2:
																array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																goto IL_0c73_2;
																IL_0c73_2:
																ptr2 += 8;
																goto IL_0c81_2;
																IL_0c81_2:
																num7--;
																goto IL_1187_2;
																IL_0c94_2:
																if (10 > b)
																{
																	goto IL_0ca2_2;
																}
																goto IL_0d51_2;
																IL_0ca2_2:
																if (8 >= b)
																{
																	goto IL_0cad_2;
																}
																goto IL_0cce_2;
																IL_0cad_2:
																if (8 > b)
																{
																	break;
																}
																goto IL_0cbb_2;
																IL_0cbb_2:
																num7--;
																goto IL_1187_2;
																IL_0cce_2:
																if (9 < b)
																{
																	break;
																}
																goto IL_0cdc_2;
																IL_0cdc_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_0cea_2;
																IL_0cea_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_0d2a_2;
																IL_0d2a_2:
																array2[num7 - 2] = 0;
																goto IL_0d3e_2;
																IL_0d3e_2:
																num7--;
																goto IL_1187_2;
																IL_0d51_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0db3_2;
																IL_0db3_2:
																num7 -= 2;
																goto IL_1187_2;
																IL_0dc6_2:
																if (7 > b)
																{
																	goto IL_0dd4_2;
																}
																goto IL_10bf_2;
																IL_0dd4_2:
																if (3 < b)
																{
																	goto IL_0de2_2;
																}
																goto IL_0f7a_2;
																IL_0de2_2:
																if (5 >= b)
																{
																	goto IL_0df0_2;
																}
																goto IL_0ee3_2;
																IL_0df0_2:
																if (5 > b)
																{
																	goto IL_0dfb_2;
																}
																goto IL_0e73_2;
																IL_0dfb_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_0e09_2;
																IL_0e09_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0e17_2;
																IL_0e17_2:
																array2[num7] = 0;
																goto IL_0e25_2;
																IL_0e25_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0e48_2;
																IL_0e48_2:
																array3[num7] = null;
																goto IL_0e52_2;
																IL_0e52_2:
																num7++;
																goto IL_0e60_2;
																IL_0e60_2:
																ptr2 += 8;
																goto IL_1187_2;
																IL_0e73_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_0eb3_2;
																IL_0eb3_2:
																array2[num7 - 2] = 0;
																num = 22;
																goto IL_0ed0_2;
																IL_0ed0_2:
																num7--;
																goto IL_1187_2;
																IL_0ee3_2:
																if (6 < b)
																{
																	num = 214;
																	break;
																}
																goto IL_0efc_2;
																IL_1123_2:
																array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
																goto IL_114c_2;
																IL_0efc_2:
																if (6 > b)
																{
																	break;
																}
																num = 35;
																goto IL_0f13_2;
																IL_114c_2:
																array2[num7 - 1] = 5;
																goto IL_1187_2;
																IL_0f13_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_0f53_2;
																IL_0f53_2:
																array2[num7 - 2] = 0;
																goto IL_0f67_2;
																IL_0f67_2:
																num7--;
																goto IL_1187_2;
																IL_0f7a_2:
																if (3 <= b)
																{
																	goto IL_0f85_2;
																}
																goto IL_0fcf_2;
																IL_0f85_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_0fae_2;
																IL_0fae_2:
																ptr2 += 8;
																goto IL_0fbc_2;
																IL_0fbc_2:
																num7--;
																goto IL_1187_2;
																IL_0fcf_2:
																if (1 < b)
																{
																	goto IL_0fdd_2;
																}
																goto IL_1060_2;
																IL_0fdd_2:
																if (2 < b)
																{
																	break;
																}
																goto IL_0feb_2;
																IL_0feb_2:
																if (2 > b)
																{
																	break;
																}
																goto IL_0ff9_2;
																IL_0ff9_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_1039_2;
																IL_1039_2:
																array2[num7 - 2] = 0;
																goto IL_104d_2;
																IL_104d_2:
																num7--;
																goto IL_1187_2;
																IL_1060_2:
																if (1 > b)
																{
																	break;
																}
																goto IL_106e_2;
																IL_106e_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
																goto IL_1087_2;
																IL_1087_2:
																array2[num7] = 0;
																goto IL_1095_2;
																IL_1095_2:
																num7++;
																num = 38;
																goto IL_10ac_2;
																IL_10ac_2:
																ptr2 += 8;
																goto IL_1187_2;
																IL_10bf_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
																goto IL_10ff_2;
															}
														}
														else
														{
															num = 37;
														}
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												num = 129;
												goto IL_1187_2;
												continue;
												end_IL_04e8_2:
												break;
											}
											continue;
											end_IL_04f8:
											break;
										}
										continue;
										end_IL_0508:
										break;
									}
									break;
								}
								num = 107;
								return;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num8 = num7;
					if (array == null)
					{
						goto IL_0b5e_2;
					}
					continue;
					end_IL_0b6c:
					break;
				}
				break;
			}
		}
	}

	private void OnDisable()
	{
		smethod_8(this);
	}

	private unsafe void method_0()
	{
		int num = 99;
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 158;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												array5[0] = this;
												while (true)
												{
													IL_0365:
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HashMembershipConditiongetAsyncState.hashMembershipConditiongetAsyncState_0);
													while (true)
													{
														IL_0352:
														byte* ptr2 = ptr;
														num = 204;
														while (true)
														{
															if (num != 204)
															{
																if (num != 1185)
																{
																	break;
																}
																switch (num)
																{
																case 6:
																	goto IL_0352;
																case 76:
																	goto IL_0365;
																case 130:
																	goto end_IL_033f;
																case 3:
																	goto end_IL_0370;
																case 174:
																	goto end_IL_0380;
																case 158:
																	goto end_IL_0390;
																case 145:
																	goto end_IL_03a0;
																case 23:
																	goto end_IL_03b0;
																case 100:
																	goto end_IL_03bb;
																case 162:
																	goto end_IL_03cb;
																case 98:
																	goto end_IL_03db;
																case 99:
																	goto end_IL_03eb;
																case 37:
																case 39:
																	goto IL_0406;
																case 63:
																	goto IL_040f;
																case 138:
																	goto IL_041d;
																case 86:
																	goto IL_042b;
																case 142:
																	goto IL_0442;
																case 16:
																	goto IL_0450;
																case 49:
																case 85:
																	goto IL_045b;
																case 135:
																	goto IL_0474;
																case 149:
																	goto IL_0482;
																case 152:
																	goto IL_0490;
																case 193:
																	goto IL_04a3;
																case 120:
																	goto IL_04b1;
																case 34:
																	goto IL_04bf;
																case 125:
																case 182:
																	goto IL_04ca;
																case 181:
																	goto IL_050a;
																case 20:
																	goto IL_051e;
																case 169:
																	goto IL_0531;
																case 54:
																	goto IL_053c;
																case 118:
																case 140:
																	goto IL_054a;
																case 30:
																	goto IL_058a;
																case 1:
																	goto IL_059e;
																case 109:
																	goto IL_05b1;
																case 150:
																	goto IL_05bf;
																case 148:
																case 163:
																	goto IL_05cd;
																case 19:
																	goto IL_05e0;
																case 101:
																	goto IL_05ee;
																case 50:
																case 117:
																	goto IL_05fc;
																case 93:
																	goto IL_065e;
																case 70:
																	goto IL_0671;
																case 40:
																	goto IL_067f;
																case 141:
																	goto IL_069b;
																case 84:
																case 113:
																	goto IL_06a6;
																case 183:
																	goto IL_06e6;
																case 9:
																	goto IL_06fa;
																case 147:
																	goto IL_070d;
																case 123:
																	goto IL_071b;
																case 15:
																case 155:
																	goto IL_0726;
																case 144:
																	goto IL_074f;
																case 105:
																	goto IL_075d;
																case 44:
																	goto IL_0770;
																case 71:
																	goto IL_077b;
																case 26:
																case 61:
																	goto IL_0789;
																case 27:
																	goto IL_07a2;
																case 176:
																	goto IL_07b9;
																case 95:
																	goto IL_07c7;
																case 119:
																	goto IL_07da;
																case 79:
																	goto IL_07e8;
																case 32:
																case 73:
																	goto IL_07f6;
																case 110:
																	goto IL_0836;
																case 74:
																	goto IL_084a;
																case 22:
																	goto IL_085d;
																case 77:
																	goto IL_0868;
																case 47:
																case 179:
																	goto IL_0876;
																case 112:
																	goto IL_0884;
																case 69:
																	goto IL_08a7;
																case 197:
																	goto IL_08b1;
																case 41:
																	goto IL_08bf;
																case 51:
																	goto IL_08d2;
																case 173:
																	goto IL_08e0;
																case 17:
																case 36:
																	goto IL_08ee;
																case 59:
																	goto IL_092e;
																case 128:
																	goto IL_0942;
																case 177:
																	goto IL_0955;
																case 18:
																	goto IL_0963;
																case 13:
																	goto IL_0971;
																case 134:
																	goto IL_097f;
																case 131:
																	goto IL_098a;
																case 60:
																case 82:
																	goto IL_09a1;
																case 46:
																	goto IL_09b9;
																case 104:
																	goto IL_09c7;
																case 160:
																	goto IL_09d5;
																case 196:
																	goto IL_09f1;
																case 0:
																	goto IL_09ff;
																case 25:
																case 90:
																	goto IL_0a0d;
																case 157:
																	goto IL_0a36;
																case 89:
																	goto IL_0a44;
																case 156:
																	goto IL_0a57;
																case 7:
																case 172:
																	goto IL_0a62;
																case 87:
																	goto IL_0ab4;
																case 133:
																	goto IL_0ac7;
																case 55:
																	goto IL_0ad2;
																case 11:
																case 14:
																	goto IL_0ae0;
																case 139:
																	goto IL_0af8;
																case 186:
																	goto IL_0b06;
																case 175:
																case 184:
																	goto IL_0b14;
																case 91:
																	goto IL_0b55;
																case 83:
																	goto IL_0b72;
																case 94:
																case 168:
																	goto IL_0b85;
																case 180:
																	goto IL_0ba7;
																case 189:
																	goto IL_0bb5;
																case 52:
																	goto IL_0bc3;
																case 132:
																	goto IL_0bd6;
																case 154:
																	goto IL_0be4;
																case 103:
																case 106:
																	goto IL_0bf8;
																case 2:
																	goto IL_0c0c;
																case 75:
																	goto IL_0c54;
																case 190:
																	goto IL_0c67;
																case 4:
																	goto IL_0c72;
																case 102:
																case 107:
																	goto IL_0c80;
																case 62:
																	goto IL_0c94;
																case 68:
																	goto IL_0cd3;
																case 165:
																	goto IL_0ce6;
																case 43:
																	goto IL_0cf4;
																case 56:
																case 143:
																	goto IL_0d0b;
																case 66:
																	goto IL_0d54;
																case 129:
																	goto IL_0d68;
																case 111:
																	goto IL_0d78;
																case 136:
																	goto IL_0d83;
																case 45:
																case 187:
																	goto IL_0d8e;
																case 122:
																	goto IL_0da7;
																case 97:
																	goto IL_0db2;
																case 8:
																case 10:
																case 21:
																case 24:
																case 33:
																case 57:
																case 58:
																case 64:
																case 67:
																case 80:
																case 81:
																case 92:
																case 96:
																case 108:
																case 114:
																case 115:
																case 124:
																case 137:
																case 146:
																case 161:
																case 164:
																case 167:
																case 170:
																case 171:
																case 178:
																case 191:
																	goto IL_0dbd;
																case 5:
																case 12:
																case 28:
																case 29:
																case 31:
																case 35:
																case 38:
																case 48:
																case 53:
																case 65:
																case 78:
																case 88:
																case 116:
																case 121:
																case 126:
																case 127:
																case 151:
																case 153:
																case 159:
																case 166:
																case 185:
																case 188:
																case 192:
																case 194:
																case 195:
																	goto IL_0dd0;
																case 42:
																case 72:
																	return;
																}
																continue;
															}
															goto IL_0dd0;
															IL_0d68:
															num5--;
															goto IL_0dd0;
															IL_0d78:
															if (22 >= b)
															{
																goto IL_0d83;
															}
															goto IL_0da7;
															IL_0dd0:
															if (num6 == 1)
															{
																return;
															}
															goto IL_0406;
															IL_0406:
															b = *ptr2;
															goto IL_040f;
															IL_040f:
															ptr2++;
															goto IL_041d;
															IL_041d:
															if (b >= 1)
															{
																goto IL_042b;
															}
															goto IL_0dbd;
															IL_042b:
															if (b <= 23)
															{
																num = 142;
																goto IL_0442;
															}
															goto IL_0dbd;
															IL_0d83:
															if (22 <= b)
															{
																goto IL_0d8e;
															}
															goto IL_0dbd;
															IL_0442:
															if (12 >= b)
															{
																goto IL_0450;
															}
															goto IL_0955;
															IL_0450:
															if (12 <= b)
															{
																goto IL_045b;
															}
															goto IL_04a3;
															IL_045b:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)(ptr2 + num4);
															goto IL_0474;
															IL_0474:
															array[num5] = 1;
															goto IL_0482;
															IL_0482:
															num5++;
															goto IL_0490;
															IL_0490:
															ptr2 += 16;
															goto IL_0dd0;
															IL_04a3:
															if (6 < b)
															{
																goto IL_04b1;
															}
															num = 141;
															goto IL_069b;
															IL_04b1:
															if (9 >= b)
															{
																goto IL_04bf;
															}
															goto IL_05e0;
															IL_04bf:
															if (9 <= b)
															{
																goto IL_04ca;
															}
															goto IL_0531;
															IL_04ca:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_050a;
															IL_050a:
															array[num5 - 2] = 0;
															goto IL_051e;
															IL_051e:
															num5--;
															goto IL_0dd0;
															IL_0531:
															if (7 >= b)
															{
																goto IL_053c;
															}
															goto IL_05b1;
															IL_053c:
															if (7 <= b)
															{
																goto IL_054a;
															}
															goto IL_0dbd;
															IL_054a:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_058a;
															IL_058a:
															array[num5 - 2] = 0;
															goto IL_059e;
															IL_059e:
															num5--;
															goto IL_0dd0;
															IL_05b1:
															if (8 >= b)
															{
																goto IL_05bf;
															}
															goto IL_0dbd;
															IL_05bf:
															if (8 <= b)
															{
																goto IL_05cd;
															}
															goto IL_0dbd;
															IL_05cd:
															num5--;
															goto IL_0dd0;
															IL_05e0:
															if (10 >= b)
															{
																goto IL_05ee;
															}
															goto IL_0671;
															IL_05ee:
															if (10 <= b)
															{
																goto IL_05fc;
															}
															goto IL_0dbd;
															IL_05fc:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_065e;
															IL_065e:
															num5 -= 2;
															goto IL_0dd0;
															IL_0671:
															if (11 >= b)
															{
																goto IL_067f;
															}
															goto IL_0dbd;
															IL_067f:
															if (11 > b)
															{
																goto IL_0dbd;
															}
															goto IL_0dd0;
															IL_0d8e:
															byte* num7 = ptr2;
															num6 = 1;
															ptr2 = num7 + -200;
															goto IL_0dd0;
															IL_069b:
															if (6 <= b)
															{
																goto IL_06a6;
															}
															goto IL_070d;
															IL_06a6:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_06e6;
															IL_06e6:
															array[num5 - 2] = 0;
															goto IL_06fa;
															IL_06fa:
															num5--;
															goto IL_0dd0;
															IL_070d:
															if (3 >= b)
															{
																goto IL_071b;
															}
															goto IL_085d;
															IL_071b:
															if (3 <= b)
															{
																goto IL_0726;
															}
															goto IL_0770;
															IL_0726:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_074f;
															IL_074f:
															ptr2 += 8;
															goto IL_075d;
															IL_075d:
															num5--;
															goto IL_0dd0;
															IL_0770:
															if (1 >= b)
															{
																goto IL_077b;
															}
															goto IL_07da;
															IL_077b:
															if (1 <= b)
															{
																goto IL_0789;
															}
															goto IL_0dbd;
															IL_0789:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_07a2;
															IL_07a2:
															array[num5] = 0;
															num = 176;
															goto IL_07b9;
															IL_07b9:
															num5++;
															goto IL_07c7;
															IL_07c7:
															ptr2 += 8;
															goto IL_0dd0;
															IL_07da:
															if (2 >= b)
															{
																goto IL_07e8;
															}
															goto IL_0dbd;
															IL_07e8:
															if (2 <= b)
															{
																goto IL_07f6;
															}
															goto IL_0dbd;
															IL_07f6:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0836;
															IL_0836:
															array[num5 - 2] = 0;
															goto IL_084a;
															IL_084a:
															num5--;
															goto IL_0dd0;
															IL_085d:
															if (4 >= b)
															{
																goto IL_0868;
															}
															goto IL_08d2;
															IL_0868:
															if (4 <= b)
															{
																goto IL_0876;
															}
															goto IL_0dbd;
															IL_0876:
															array[num5] = 0;
															goto IL_0884;
															IL_0884:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_08a7;
															IL_08a7:
															array2[num5] = null;
															goto IL_08b1;
															IL_08b1:
															num5++;
															goto IL_08bf;
															IL_08bf:
															ptr2 += 8;
															goto IL_0dd0;
															IL_08d2:
															if (5 >= b)
															{
																goto IL_08e0;
															}
															goto IL_0dbd;
															IL_08e0:
															if (5 <= b)
															{
																goto IL_08ee;
															}
															goto IL_0dbd;
															IL_08ee:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_092e;
															IL_092e:
															array[num5 - 2] = 0;
															goto IL_0942;
															IL_0942:
															num5--;
															goto IL_0dd0;
															IL_0955:
															if (18 >= b)
															{
																goto IL_0963;
															}
															goto IL_0bd6;
															IL_0963:
															if (18 > b)
															{
																goto IL_0971;
															}
															goto IL_0b85;
															IL_0971:
															if (15 < b)
															{
																goto IL_097f;
															}
															goto IL_0a57;
															IL_097f:
															if (16 >= b)
															{
																goto IL_098a;
															}
															goto IL_09f1;
															IL_098a:
															if (16 <= b)
															{
																num = 60;
																goto IL_09a1;
															}
															goto IL_0dbd;
															IL_0da7:
															if (23 >= b)
															{
																goto IL_0db2;
															}
															goto IL_0dbd;
															IL_09a1:
															array2[num5] = array5[*(int*)(ptr2 + num3)];
															goto IL_09b9;
															IL_09b9:
															array[num5] = 5;
															goto IL_09c7;
															IL_09c7:
															num5++;
															goto IL_09d5;
															IL_09d5:
															ptr2 += 8;
															num = 151;
															goto IL_0dd0;
															IL_09f1:
															if (17 >= b)
															{
																goto IL_09ff;
															}
															goto IL_0dbd;
															IL_09ff:
															if (17 <= b)
															{
																goto IL_0a0d;
															}
															goto IL_0dbd;
															IL_0a0d:
															((delegate*<Class178, void>)PermissionSetEntryReflectionOnlyLoadFrom[*(int*)(ptr2 + num3)])((Class178)array2[num5 - 1]);
															goto IL_0a36;
															IL_0a36:
															num5--;
															goto IL_0a44;
															IL_0a44:
															ptr2 += 8;
															goto IL_0dd0;
															IL_0a57:
															if (15 <= b)
															{
																goto IL_0a62;
															}
															goto IL_0ac7;
															IL_0a62:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0ab4;
															IL_0ab4:
															num5--;
															goto IL_0dd0;
															IL_0ac7:
															if (13 >= b)
															{
																goto IL_0ad2;
															}
															goto IL_0af8;
															IL_0ad2:
															if (13 <= b)
															{
																goto IL_0ae0;
															}
															goto IL_0dbd;
															IL_0ae0:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_0dd0;
															IL_0af8:
															if (14 >= b)
															{
																goto IL_0b06;
															}
															goto IL_0dbd;
															IL_0b06:
															if (14 <= b)
															{
																goto IL_0b14;
															}
															goto IL_0dbd;
															IL_0b14:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0);
															goto IL_0b55;
															IL_0b55:
															array[num5 - 2] = 0;
															num = 83;
															goto IL_0b72;
															IL_0b72:
															num5--;
															goto IL_0dd0;
															IL_0b85:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(double*)(ptr2 + num4);
															num = 180;
															goto IL_0ba7;
															IL_0ba7:
															array[num5] = 3;
															goto IL_0bb5;
															IL_0bb5:
															num5++;
															goto IL_0bc3;
															IL_0bc3:
															ptr2 += 16;
															goto IL_0dd0;
															IL_0bd6:
															if (21 >= b)
															{
																goto IL_0be4;
															}
															goto IL_0d78;
															IL_0be4:
															if (21 <= b)
															{
																num = 106;
																goto IL_0bf8;
															}
															goto IL_0c67;
															IL_0db2:
															if (23 <= b)
															{
															}
															goto IL_0dbd;
															IL_0bf8:
															array[num5 - 1] = 0;
															goto IL_0c0c;
															IL_0c0c:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<double, int>)PermissionSetEntryReflectionOnlyLoadFrom[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
															num = 75;
															goto IL_0c54;
															IL_0c54:
															ptr2 += 8;
															goto IL_0dd0;
															IL_0c67:
															if (19 >= b)
															{
																goto IL_0c72;
															}
															goto IL_0ce6;
															IL_0c72:
															if (19 <= b)
															{
																goto IL_0c80;
															}
															goto IL_0dbd;
															IL_0c80:
															array[num5 - 1] = 3;
															goto IL_0c94;
															IL_0c94:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<double, double>)PermissionSetEntryReflectionOnlyLoadFrom[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
															goto IL_0cd3;
															IL_0cd3:
															ptr2 += 8;
															goto IL_0dd0;
															IL_0ce6:
															if (20 >= b)
															{
																goto IL_0cf4;
															}
															goto IL_0dbd;
															IL_0cf4:
															if (20 <= b)
															{
																num = 56;
																goto IL_0d0b;
															}
															goto IL_0dbd;
															IL_0dbd:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_0dd0;
															IL_0d0b:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															num = 66;
															goto IL_0d54;
															IL_0d54:
															array[num5 - 2] = 3;
															goto IL_0d68;
															continue;
															end_IL_033f:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_0370:
												break;
											}
											continue;
											end_IL_0380:
											break;
										}
										continue;
										end_IL_0390:
										break;
									}
									continue;
									end_IL_03a0:
									break;
								}
								continue;
								end_IL_03b0:
								break;
							}
							continue;
							end_IL_03bb:
							break;
						}
						continue;
						end_IL_03cb:
						break;
					}
					continue;
					end_IL_03db:
					break;
				}
				continue;
				end_IL_03eb:
				break;
			}
		}
	}

	private unsafe void method_1()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_058b, IL_059e, IL_05bd, IL_05d0, IL_05e3, IL_05f3, IL_0603, IL_0613, IL_0623, IL_0633, IL_0640, IL_0650, IL_0660, IL_0670, IL_067b, IL_068b, IL_069b, IL_06b4, IL_06cb, IL_06d9, IL_06ec, IL_0708, IL_0713, IL_0753, IL_0767, IL_077a, IL_0788, IL_0796, IL_07a4, IL_07af, IL_07f0, IL_0809, IL_0817, IL_0825, IL_082e, IL_0846, IL_0851, IL_085f, IL_08b1, IL_08cd, IL_08db, IL_08e9, IL_090a, IL_0918, IL_0926, IL_0939, IL_0971, IL_0985, IL_09a1, IL_09af, IL_09bd, IL_09cb, IL_09d9, IL_09e4, IL_09f2, IL_0a32, IL_0a46, IL_0a59, IL_0a64, IL_0a72, IL_0a9b, IL_0aa9, IL_0abc, IL_0aca, IL_0ad8, IL_0ae6, IL_0b09, IL_0b13, IL_0b21, IL_0b34, IL_0b79, IL_0b87, IL_0b9a, IL_0bfc, IL_0c18, IL_0c23, IL_0c31, IL_0c3c, IL_0c4f, IL_0c5a, IL_0c6d, IL_0c7b, IL_0c8e, IL_0c9c, IL_0ca7, IL_0cba, IL_0cc8, IL_0cd1, IL_0cdf, IL_0cf3, IL_0d2b, IL_0d3e, IL_0d5c, IL_0d6a, IL_0d7d, IL_0d8b, IL_0d9e, IL_0dde, IL_0df2, IL_0e05, IL_0e22, IL_0e71, IL_0e7b, IL_0ea8, IL_0ebc, IL_0eca, IL_0edd, IL_0f1b, IL_0f2e, IL_0f3c, IL_0f47, IL_0f5a, IL_0f65, IL_0f78, IL_0f86, IL_0f8f, IL_0f9d, IL_0fbb, IL_0fc9, IL_0fd7, IL_0fea, IL_102a, IL_103e, IL_1051, IL_105f, IL_106f, IL_10ad, IL_10bb, IL_10ce, IL_10e1, IL_1103, IL_1111, IL_111f, IL_1132, IL_1140, IL_1169, IL_1174, IL_1182, IL_119a, IL_11a8, IL_11bb, IL_11c9, IL_11d7, IL_11ef, IL_120d, IL_1231, IL_1252, IL_1265, IL_1273, IL_127e, IL_1291, IL_129f, IL_12ad, IL_12c1, IL_1300, IL_131c, IL_1325, IL_1333, IL_1347, IL_1394, IL_13ab, IL_13be, IL_13cc, IL_13d5, IL_13e3, IL_13ed, IL_13fb, IL_140e, IL_1421, IL_143a, IL_1445, IL_1458, IL_1466, IL_1479, IL_1487, IL_1495, IL_14a9, IL_14ed, IL_1509, IL_1526, IL_1565, IL_1578, IL_15b8, IL_15cc, IL_15df, IL_15f8, IL_1606, IL_1614, IL_1630, IL_1643, IL_166c, IL_1685, IL_16a1, IL_16af, IL_16ef, IL_1703, IL_1716, IL_1729, IL_173c, IL_1774, IL_1787, IL_17a0, IL_17bc, IL_17c7, IL_17d5, IL_17f2, IL_1831, IL_1841, IL_184c, IL_1857, IL_186a, IL_187d, IL_1887, IL_1892, IL_18a2, IL_18bb, IL_18cb, IL_18db, IL_18eb, IL_1904, IL_1914, IL_1924, IL_1934 are reachable both inside and outside the pinned region starting at IL_1949. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 113;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef80 = default(int);
			ref int reference = ref __rxRef80;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1934:
					num2 = 1;
					while (true)
					{
						IL_1924:
						num3 = num2 * 4;
						while (true)
						{
							IL_1914:
							num4 = num2 * 8;
							while (true)
							{
								IL_1904:
								array2 = new byte[4];
								while (true)
								{
									IL_18eb:
									array3 = new object[4];
									num = 271;
									while (true)
									{
										IL_18db:
										array4 = new int[4];
										while (true)
										{
											IL_18cb:
											array5 = new int[7];
											while (true)
											{
												IL_18bb:
												array6 = new long[4];
												while (true)
												{
													IL_18a2:
													array7 = new object[16];
													num = 224;
													while (true)
													{
														IL_1892:
														array7[0] = this;
														while (true)
														{
															IL_1887:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllocateBufferFromNotGengetUseMachineKeyStore.ExceptionFromErrorCodeGetSymWriter);
															while (true)
															{
																IL_187d:
																ptr2 = ptr;
																while (true)
																{
																	IL_186a:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0670:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0660:
																			ptr2++;
																			while (true)
																			{
																				IL_0650:
																				if (b >= 1)
																				{
																					while (b <= 40)
																					{
																						while (true)
																						{
																							IL_0633:
																							if (20 < b)
																							{
																								while (true)
																								{
																									IL_0623:
																									if (30 < b)
																									{
																										while (true)
																										{
																											IL_0613:
																											if (35 < b)
																											{
																												while (true)
																												{
																													IL_0603:
																													if (38 >= b)
																													{
																														while (true)
																														{
																															IL_05f3:
																															if (38 > b)
																															{
																																while (true)
																																{
																																	IL_05e3:
																																	if (36 < b)
																																	{
																																		while (37 >= b)
																																		{
																																			num = 83;
																																			while (37 <= b)
																																			{
																																				num = 93;
																																				while (true)
																																				{
																																					IL_059e:
																																					array2[num6 - 1] = 5;
																																					num = 344;
																																					while (true)
																																					{
																																						if (num != 344)
																																						{
																																							if (num != 1325)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 113:
																																								break;
																																							default:
																																								continue;
																																							case 93:
																																							case 319:
																																								goto IL_059e;
																																							case 83:
																																								goto IL_05bd;
																																							case 105:
																																								goto IL_05d0;
																																							case 30:
																																								goto IL_05e3;
																																							case 56:
																																								goto IL_05f3;
																																							case 120:
																																								goto IL_0603;
																																							case 154:
																																								goto IL_0613;
																																							case 250:
																																								goto IL_0623;
																																							case 247:
																																								goto IL_0633;
																																							case 232:
																																								goto IL_0640;
																																							case 178:
																																								goto IL_0650;
																																							case 321:
																																								goto IL_0660;
																																							case 50:
																																							case 145:
																																								goto IL_0670;
																																							case 26:
																																								goto IL_067b;
																																							case 100:
																																								goto IL_068b;
																																							case 165:
																																							case 219:
																																								goto IL_069b;
																																							case 253:
																																								goto IL_06b4;
																																							case 228:
																																								goto IL_06cb;
																																							case 223:
																																								goto IL_06d9;
																																							case 44:
																																							case 261:
																																								goto IL_06ec;
																																							case 269:
																																								goto IL_0708;
																																							case 176:
																																							case 266:
																																								goto IL_0713;
																																							case 189:
																																								goto IL_0753;
																																							case 251:
																																								goto IL_0767;
																																							case 124:
																																								goto IL_077a;
																																							case 164:
																																								goto IL_0788;
																																							case 18:
																																								goto IL_0796;
																																							case 134:
																																								goto IL_07a4;
																																							case 158:
																																							case 234:
																																								goto IL_07af;
																																							case 221:
																																								goto IL_07f0;
																																							case 197:
																																								goto IL_0809;
																																							case 12:
																																								goto IL_0817;
																																							case 3:
																																							case 101:
																																								goto IL_082e;
																																							case 111:
																																								goto IL_0846;
																																							case 48:
																																								goto IL_0851;
																																							case 60:
																																							case 143:
																																								goto IL_085f;
																																							case 47:
																																								goto IL_08b1;
																																							case 89:
																																								goto IL_08cd;
																																							case 0:
																																								goto IL_08db;
																																							case 186:
																																							case 187:
																																								goto IL_08e9;
																																							case 13:
																																								goto IL_090a;
																																							case 23:
																																								goto IL_0918;
																																							case 25:
																																								goto IL_0926;
																																							case 87:
																																							case 182:
																																								goto IL_0939;
																																							case 82:
																																								goto IL_0971;
																																							case 160:
																																								goto IL_0985;
																																							case 270:
																																								goto IL_09a1;
																																							case 71:
																																								goto IL_09af;
																																							case 5:
																																								goto IL_09bd;
																																							case 65:
																																								goto IL_09cb;
																																							case 90:
																																								goto IL_09d9;
																																							case 15:
																																								goto IL_09e4;
																																							case 49:
																																							case 129:
																																								goto IL_09f2;
																																							case 79:
																																								goto IL_0a32;
																																							case 68:
																																								goto IL_0a46;
																																							case 40:
																																								goto IL_0a59;
																																							case 161:
																																								goto IL_0a64;
																																							case 125:
																																							case 220:
																																								goto IL_0a72;
																																							case 203:
																																								goto IL_0a9b;
																																							case 236:
																																								goto IL_0aa9;
																																							case 39:
																																								goto IL_0abc;
																																							case 162:
																																								goto IL_0aca;
																																							case 80:
																																							case 142:
																																								goto IL_0ad8;
																																							case 133:
																																								goto IL_0ae6;
																																							case 130:
																																								goto IL_0b09;
																																							case 35:
																																								goto IL_0b13;
																																							case 75:
																																								goto IL_0b21;
																																							case 24:
																																							case 198:
																																								goto IL_0b34;
																																							case 92:
																																								goto IL_0b79;
																																							case 188:
																																								goto IL_0b87;
																																							case 8:
																																							case 237:
																																								goto IL_0b9a;
																																							case 208:
																																								goto IL_0bfc;
																																							case 229:
																																								goto IL_0c18;
																																							case 9:
																																								goto IL_0c23;
																																							case 97:
																																								goto IL_0c31;
																																							case 246:
																																								goto IL_0c3c;
																																							case 167:
																																								goto IL_0c4f;
																																							case 45:
																																								goto IL_0c5a;
																																							case 95:
																																								goto IL_0c6d;
																																							case 135:
																																								goto IL_0c7b;
																																							case 259:
																																								goto IL_0c8e;
																																							case 204:
																																								goto IL_0c9c;
																																							case 254:
																																								goto IL_0ca7;
																																							case 262:
																																								goto IL_0cba;
																																							case 215:
																																								goto IL_0cd1;
																																							case 85:
																																							case 194:
																																								goto IL_0cdf;
																																							case 104:
																																								goto IL_0cf3;
																																							case 98:
																																								goto IL_0d2b;
																																							case 37:
																																							case 278:
																																								goto IL_0d3e;
																																							case 102:
																																								goto IL_0d5c;
																																							case 248:
																																								goto IL_0d6a;
																																							case 280:
																																								goto IL_0d7d;
																																							case 172:
																																								goto IL_0d8b;
																																							case 277:
																																							case 281:
																																								goto IL_0d9e;
																																							case 57:
																																								goto IL_0dde;
																																							case 206:
																																								goto IL_0df2;
																																							case 117:
																																							case 289:
																																								goto IL_0e05;
																																							case 34:
																																								goto IL_0ebc;
																																							case 275:
																																								goto IL_0eca;
																																							case 123:
																																							case 290:
																																								goto IL_0edd;
																																							case 196:
																																								goto IL_0f1b;
																																							case 292:
																																								goto IL_0f2e;
																																							case 231:
																																								goto IL_0f3c;
																																							case 258:
																																								goto IL_0f47;
																																							case 43:
																																								goto IL_0f5a;
																																							case 107:
																																								goto IL_0f65;
																																							case 192:
																																								goto IL_0f78;
																																							case 149:
																																								goto IL_0f8f;
																																							case 38:
																																							case 77:
																																								goto IL_0f9d;
																																							case 207:
																																								goto IL_0fbb;
																																							case 252:
																																								goto IL_0fc9;
																																							case 116:
																																								goto IL_0fd7;
																																							case 212:
																																							case 218:
																																								goto IL_0fea;
																																							case 199:
																																								goto IL_102a;
																																							case 163:
																																								goto IL_103e;
																																							case 293:
																																								goto IL_1051;
																																							case 279:
																																								goto IL_105f;
																																							case 132:
																																							case 298:
																																								goto IL_106f;
																																							case 69:
																																								goto IL_10ad;
																																							case 183:
																																								goto IL_10bb;
																																							case 299:
																																								goto IL_10ce;
																																							case 53:
																																							case 300:
																																								goto IL_10e1;
																																							case 191:
																																								goto IL_1103;
																																							case 179:
																																								goto IL_1111;
																																							case 33:
																																								goto IL_111f;
																																							case 76:
																																							case 306:
																																								goto IL_1132;
																																							case 288:
																																								goto IL_1140;
																																							case 311:
																																								goto IL_1169;
																																							case 21:
																																							case 70:
																																								goto IL_1174;
																																							case 216:
																																								goto IL_1182;
																																							case 297:
																																								goto IL_119a;
																																							case 190:
																																								goto IL_11a8;
																																							case 282:
																																								goto IL_11bb;
																																							case 127:
																																								goto IL_11c9;
																																							case 41:
																																							case 305:
																																								goto IL_11d7;
																																							case 14:
																																								goto IL_11ef;
																																							case 131:
																																								goto IL_120d;
																																							case 285:
																																								goto IL_1231;
																																							case 106:
																																								goto IL_1252;
																																							case 314:
																																								goto IL_1265;
																																							case 291:
																																								goto IL_1273;
																																							case 209:
																																								goto IL_127e;
																																							case 265:
																																								goto IL_1291;
																																							case 139:
																																								goto IL_129f;
																																							case 59:
																																							case 287:
																																								goto IL_12ad;
																																							case 22:
																																								goto IL_12c1;
																																							case 233:
																																								goto IL_1300;
																																							case 230:
																																								goto IL_1325;
																																							case 175:
																																							case 226:
																																								goto IL_1333;
																																							case 151:
																																								goto IL_1347;
																																							case 73:
																																								goto IL_1394;
																																							case 257:
																																								goto IL_13ab;
																																							case 274:
																																								goto IL_13be;
																																							case 72:
																																								goto IL_13d5;
																																							case 174:
																																							case 313:
																																								goto IL_13e3;
																																							case 181:
																																								goto IL_13ed;
																																							case 11:
																																								goto IL_13fb;
																																							case 316:
																																								goto IL_140e;
																																							case 317:
																																								goto IL_1421;
																																							case 318:
																																								goto IL_143a;
																																							case 118:
																																								goto IL_1445;
																																							case 210:
																																								goto IL_1458;
																																							case 308:
																																								goto IL_1466;
																																							case 322:
																																								goto IL_1479;
																																							case 119:
																																								goto IL_1487;
																																							case 1:
																																							case 86:
																																								goto IL_1495;
																																							case 169:
																																								goto IL_14a9;
																																							case 46:
																																							case 324:
																																								goto IL_14ed;
																																							case 4:
																																							case 325:
																																								goto IL_1509;
																																							case 303:
																																								goto IL_1526;
																																							case 51:
																																								goto IL_1565;
																																							case 211:
																																							case 327:
																																								goto IL_1578;
																																							case 185:
																																								goto IL_15b8;
																																							case 114:
																																								goto IL_15cc;
																																							case 309:
																																							case 328:
																																								goto IL_15df;
																																							case 17:
																																								goto IL_15f8;
																																							case 99:
																																								goto IL_1606;
																																							case 144:
																																								goto IL_1614;
																																							case 330:
																																								goto IL_1630;
																																							case 42:
																																							case 331:
																																								goto IL_1643;
																																							case 141:
																																								goto IL_166c;
																																							case 332:
																																								goto IL_1685;
																																							case 334:
																																								goto IL_16a1;
																																							case 94:
																																							case 329:
																																								goto IL_16af;
																																							case 240:
																																								goto IL_16ef;
																																							case 74:
																																								goto IL_1703;
																																							case 335:
																																								goto IL_1716;
																																							case 337:
																																								goto IL_1729;
																																							case 184:
																																								goto IL_1774;
																																							case 243:
																																							case 302:
																																								goto IL_1787;
																																							case 91:
																																								goto IL_17a0;
																																							case 156:
																																								goto IL_17bc;
																																							case 244:
																																								goto IL_17c7;
																																							case 242:
																																							case 263:
																																								goto IL_17d5;
																																							case 54:
																																								goto IL_17f2;
																																							case 213:
																																								goto IL_1831;
																																							case 126:
																																								goto IL_1841;
																																							case 217:
																																								goto IL_184c;
																																							case 6:
																																							case 27:
																																							case 29:
																																							case 32:
																																							case 55:
																																							case 58:
																																							case 78:
																																							case 88:
																																							case 96:
																																							case 108:
																																							case 110:
																																							case 115:
																																							case 137:
																																							case 146:
																																							case 147:
																																							case 148:
																																							case 152:
																																							case 157:
																																							case 166:
																																							case 168:
																																							case 170:
																																							case 173:
																																							case 177:
																																							case 195:
																																							case 201:
																																							case 222:
																																							case 227:
																																							case 239:
																																							case 255:
																																							case 256:
																																							case 260:
																																							case 268:
																																							case 272:
																																							case 283:
																																							case 284:
																																							case 286:
																																							case 296:
																																							case 310:
																																							case 312:
																																							case 315:
																																							case 323:
																																							case 326:
																																							case 333:
																																								goto end_IL_058b;
																																							case 2:
																																							case 19:
																																							case 20:
																																							case 36:
																																							case 52:
																																							case 61:
																																							case 63:
																																							case 64:
																																							case 66:
																																							case 67:
																																							case 81:
																																							case 84:
																																							case 103:
																																							case 109:
																																							case 121:
																																							case 122:
																																							case 136:
																																							case 138:
																																							case 140:
																																							case 150:
																																							case 153:
																																							case 155:
																																							case 171:
																																							case 180:
																																							case 193:
																																							case 202:
																																							case 205:
																																							case 214:
																																							case 225:
																																							case 235:
																																							case 238:
																																							case 241:
																																							case 245:
																																							case 249:
																																							case 264:
																																							case 267:
																																							case 276:
																																							case 294:
																																							case 295:
																																							case 301:
																																							case 304:
																																							case 320:
																																							case 336:
																																								goto IL_186a;
																																							case 28:
																																								goto IL_187d;
																																							case 159:
																																								goto IL_1887;
																																							case 224:
																																								goto IL_1892;
																																							case 7:
																																								goto IL_18a2;
																																							case 31:
																																								goto IL_18bb;
																																							case 10:
																																								goto IL_18cb;
																																							case 271:
																																								goto IL_18db;
																																							case 62:
																																								goto IL_18eb;
																																							case 307:
																																								goto IL_1904;
																																							case 273:
																																								goto IL_1914;
																																							case 128:
																																								goto IL_1924;
																																							case 112:
																																								goto IL_1934;
																																							case 16:
																																							case 200:
																																								return;
																																							}
																																							goto end_IL_0650;
																																						}
																																						array3[num6 - 1] = ((delegate*<string, GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																																						goto IL_1774;
																																						IL_1774:
																																						ptr2 += 8;
																																						goto IL_186a;
																																						continue;
																																						end_IL_058b:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																				IL_05bd:;
																																			}
																																			break;
																																			IL_05d0:;
																																		}
																																		break;
																																	}
																																	goto IL_068b;
																																	IL_06ec:
																																	num7 = ptr2;
																																	num8 = -200;
																																	num5 = 1;
																																	ptr2 = num7 + num8;
																																	goto IL_186a;
																																	IL_068b:
																																	if (36 > b)
																																	{
																																		break;
																																	}
																																	goto IL_06ec;
																																}
																																break;
																															}
																															goto IL_1787;
																															IL_17a0:
																															num6--;
																															num = 320;
																															goto IL_186a;
																															IL_1787:
																															global::_003CModule_003E.gameObject_26 = (GameObject)array3[num6 - 1];
																															goto IL_17a0;
																														}
																														break;
																													}
																													goto IL_17bc;
																													IL_184c:
																													if (40 <= b)
																													{
																													}
																													break;
																													IL_17bc:
																													if (39 >= b)
																													{
																														goto IL_17c7;
																													}
																													goto IL_1841;
																													IL_17c7:
																													if (39 > b)
																													{
																														break;
																													}
																													goto IL_17d5;
																													IL_17d5:
																													array2[num6 - 1] = 3;
																													num = 54;
																													goto IL_17f2;
																													IL_17f2:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_1831;
																													IL_1831:
																													ptr2 += 8;
																													goto IL_186a;
																													IL_1841:
																													if (40 < b)
																													{
																														break;
																													}
																													goto IL_184c;
																												}
																												break;
																											}
																											goto IL_0f2e;
																											IL_102a:
																											array2[num6 - 2] = 3;
																											goto IL_103e;
																											IL_0f2e:
																											if (35 > b)
																											{
																												goto IL_0f3c;
																											}
																											goto IL_0fea;
																											IL_0f3c:
																											if (32 >= b)
																											{
																												goto IL_0f47;
																											}
																											goto IL_0f5a;
																											IL_0f47:
																											if (32 <= b)
																											{
																												goto IL_106f;
																											}
																											goto IL_1479;
																											IL_106f:
																											((delegate*<GameObject, bool, void>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																											goto IL_10ad;
																											IL_10ad:
																											num6 -= 2;
																											goto IL_10bb;
																											IL_10bb:
																											ptr2 += 8;
																											goto IL_186a;
																											IL_1479:
																											if (31 < b)
																											{
																												break;
																											}
																											goto IL_1487;
																											IL_1487:
																											if (31 > b)
																											{
																												break;
																											}
																											goto IL_1495;
																											IL_1495:
																											array2[num6 - 1] = 0;
																											goto IL_14a9;
																											IL_14a9:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1716;
																											IL_1716:
																											ptr2 += 8;
																											goto IL_186a;
																											IL_0f5a:
																											if (33 >= b)
																											{
																												goto IL_0f65;
																											}
																											goto IL_0f78;
																											IL_0f65:
																											if (33 > b)
																											{
																												break;
																											}
																											goto IL_1509;
																											IL_1509:
																											array2[num6 - 1] = 3;
																											num = 303;
																											goto IL_1526;
																											IL_1526:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1565;
																											IL_1565:
																											ptr2 += 8;
																											goto IL_186a;
																											IL_0f78:
																											if (34 < b)
																											{
																												break;
																											}
																											num = 149;
																											goto IL_0f8f;
																											IL_103e:
																											num6--;
																											goto IL_186a;
																											IL_0f8f:
																											if (34 > b)
																											{
																												break;
																											}
																											goto IL_0f9d;
																											IL_0f9d:
																											array3[num6] = ((delegate*<GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])();
																											goto IL_0fbb;
																											IL_0fbb:
																											array2[num6] = 5;
																											goto IL_0fc9;
																											IL_0fc9:
																											num6++;
																											goto IL_0fd7;
																											IL_0fd7:
																											ptr2 += 8;
																											goto IL_186a;
																											IL_0fea:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_102a;
																										}
																										break;
																									}
																									goto IL_0708;
																									IL_13d5:
																									if (26 > b)
																									{
																										break;
																									}
																									goto IL_13e3;
																									IL_0708:
																									if (30 <= b)
																									{
																										goto IL_0713;
																									}
																									goto IL_077a;
																									IL_0713:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0753;
																									IL_0753:
																									array2[num6 - 2] = 3;
																									goto IL_0767;
																									IL_0767:
																									num6--;
																									goto IL_186a;
																									IL_077a:
																									if (25 >= b)
																									{
																										goto IL_0788;
																									}
																									goto IL_1265;
																									IL_0788:
																									if (25 > b)
																									{
																										goto IL_0796;
																									}
																									goto IL_0939;
																									IL_0796:
																									if (22 >= b)
																									{
																										goto IL_07a4;
																									}
																									goto IL_0846;
																									IL_07a4:
																									if (22 <= b)
																									{
																										goto IL_07af;
																									}
																									goto IL_0809;
																									IL_07af:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																									goto IL_07f0;
																									IL_07f0:
																									array2[num6 - 2] = 0;
																									goto IL_1729;
																									IL_1729:
																									num6--;
																									goto IL_186a;
																									IL_0809:
																									if (21 < b)
																									{
																										break;
																									}
																									goto IL_0817;
																									IL_0817:
																									if (21 > b)
																									{
																										break;
																									}
																									num = 101;
																									goto IL_082e;
																									IL_13e3:
																									array3[num6] = null;
																									goto IL_13ed;
																									IL_082e:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_186a;
																									IL_0846:
																									if (23 >= b)
																									{
																										goto IL_0851;
																									}
																									goto IL_08cd;
																									IL_0851:
																									if (23 > b)
																									{
																										break;
																									}
																									goto IL_085f;
																									IL_085f:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_08b1;
																									IL_08b1:
																									num6--;
																									num = 264;
																									goto IL_186a;
																									IL_08cd:
																									if (24 < b)
																									{
																										break;
																									}
																									goto IL_08db;
																									IL_08db:
																									if (24 > b)
																									{
																										break;
																									}
																									goto IL_08e9;
																									IL_08e9:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									num = 13;
																									goto IL_090a;
																									IL_090a:
																									array2[num6] = 5;
																									goto IL_0918;
																									IL_0918:
																									num6++;
																									goto IL_0926;
																									IL_0926:
																									ptr2 += 8;
																									goto IL_186a;
																									IL_0939:
																									array3[num6 - 1] = ((delegate*<Class178, GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((Class178)array3[num6 - 1]);
																									goto IL_0971;
																									IL_0971:
																									array2[num6 - 1] = 5;
																									goto IL_0985;
																									IL_0985:
																									ptr2 += 8;
																									num = 245;
																									goto IL_186a;
																									IL_1265:
																									if (27 < b)
																									{
																										goto IL_1273;
																									}
																									num = 230;
																									goto IL_1325;
																									IL_1273:
																									if (28 >= b)
																									{
																										goto IL_127e;
																									}
																									goto IL_1291;
																									IL_127e:
																									if (28 > b)
																									{
																										break;
																									}
																									goto IL_15df;
																									IL_15df:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																									goto IL_15f8;
																									IL_15f8:
																									array2[num6] = 3;
																									goto IL_1606;
																									IL_1606:
																									num6++;
																									goto IL_1614;
																									IL_1614:
																									ptr2 += 16;
																									num = 155;
																									goto IL_186a;
																									IL_1291:
																									if (29 < b)
																									{
																										break;
																									}
																									goto IL_129f;
																									IL_129f:
																									if (29 > b)
																									{
																										break;
																									}
																									goto IL_12ad;
																									IL_12ad:
																									array2[num6 - 1] = 3;
																									goto IL_12c1;
																									IL_12c1:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1300;
																									IL_1300:
																									ptr2 += 8;
																									num = 241;
																									goto IL_186a;
																									IL_13ed:
																									array2[num6] = 5;
																									goto IL_13fb;
																									IL_1325:
																									if (27 <= b)
																									{
																										goto IL_1333;
																									}
																									goto IL_13be;
																									IL_1333:
																									array2[num6 - 2] = 0;
																									goto IL_1347;
																									IL_1347:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																									goto IL_1394;
																									IL_1394:
																									num6--;
																									num = 257;
																									goto IL_13ab;
																									IL_13ab:
																									ptr2 += 8;
																									goto IL_186a;
																									IL_13be:
																									if (26 < b)
																									{
																										break;
																									}
																									num = 72;
																									goto IL_13d5;
																									IL_13fb:
																									num6++;
																									goto IL_186a;
																								}
																								break;
																							}
																							goto IL_067b;
																							IL_11d7:
																							array2[num6] = array2[num6 - 1];
																							goto IL_11ef;
																							IL_067b:
																							if (20 <= b)
																							{
																								goto IL_069b;
																							}
																							goto IL_09a1;
																							IL_069b:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_06b4;
																							IL_06b4:
																							array2[num6] = 1;
																							num = 228;
																							goto IL_06cb;
																							IL_06cb:
																							num6++;
																							goto IL_06d9;
																							IL_06d9:
																							ptr2 += 16;
																							goto IL_186a;
																							IL_09a1:
																							if (10 >= b)
																							{
																								goto IL_09af;
																							}
																							goto IL_0c18;
																							IL_09af:
																							if (10 > b)
																							{
																								goto IL_09bd;
																							}
																							goto IL_0b9a;
																							IL_09bd:
																							if (5 >= b)
																							{
																								goto IL_09cb;
																							}
																							goto IL_0b79;
																							IL_09cb:
																							if (5 > b)
																							{
																								goto IL_09d9;
																							}
																							goto IL_0b34;
																							IL_09d9:
																							if (2 >= b)
																							{
																								goto IL_09e4;
																							}
																							goto IL_0a59;
																							IL_09e4:
																							if (2 <= b)
																							{
																								goto IL_09f2;
																							}
																							goto IL_1051;
																							IL_09f2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0a32;
																							IL_0a32:
																							array2[num6 - 2] = 0;
																							goto IL_0a46;
																							IL_0a46:
																							num6--;
																							goto IL_186a;
																							IL_1051:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_105f;
																							IL_105f:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_10e1;
																							IL_10e1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							num = 191;
																							goto IL_1103;
																							IL_1103:
																							array2[num6] = 0;
																							goto IL_1111;
																							IL_1111:
																							num6++;
																							goto IL_111f;
																							IL_111f:
																							ptr2 += 8;
																							goto IL_186a;
																							IL_0a59:
																							if (3 >= b)
																							{
																								goto IL_0a64;
																							}
																							goto IL_0abc;
																							IL_0a64:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0a72;
																							IL_0a72:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0a9b;
																							IL_0a9b:
																							ptr2 += 8;
																							goto IL_0aa9;
																							IL_0aa9:
																							num6--;
																							goto IL_186a;
																							IL_0abc:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0aca;
																							IL_0aca:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0ad8;
																							IL_0ad8:
																							array2[num6] = 0;
																							goto IL_0ae6;
																							IL_0ae6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0b09;
																							IL_0b09:
																							array3[num6] = null;
																							goto IL_0b13;
																							IL_0b13:
																							num6++;
																							goto IL_0b21;
																							IL_0b21:
																							ptr2 += 8;
																							goto IL_186a;
																							IL_0b34:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1421;
																							IL_1421:
																							array2[num6 - 2] = 0;
																							goto IL_1685;
																							IL_1685:
																							num6--;
																							num = 150;
																							goto IL_186a;
																							IL_0b79:
																							if (7 >= b)
																							{
																								goto IL_0b87;
																							}
																							goto IL_143a;
																							IL_0b87:
																							if (7 <= b)
																							{
																								goto IL_0d9e;
																							}
																							goto IL_10ce;
																							IL_0d9e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0dde;
																							IL_0dde:
																							array2[num6 - 2] = 0;
																							goto IL_0df2;
																							IL_0df2:
																							num6--;
																							goto IL_186a;
																							IL_10ce:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_16a1;
																							IL_16a1:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_16af;
																							IL_16af:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_16ef;
																							IL_16ef:
																							array2[num6 - 2] = 0;
																							goto IL_1703;
																							IL_1703:
																							num6--;
																							goto IL_186a;
																							IL_143a:
																							if (8 >= b)
																							{
																								goto IL_1445;
																							}
																							goto IL_1458;
																							IL_1445:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_14ed;
																							IL_14ed:
																							num6--;
																							num = 2;
																							goto IL_186a;
																							IL_1458:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_1466;
																							IL_1466:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_1578;
																							IL_1578:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_15b8;
																							IL_15b8:
																							array2[num6 - 2] = 0;
																							goto IL_15cc;
																							IL_15cc:
																							num6--;
																							goto IL_186a;
																							IL_0b9a:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0bfc;
																							IL_0bfc:
																							num6 -= 2;
																							num = 336;
																							goto IL_186a;
																							IL_0c18:
																							if (15 >= b)
																							{
																								goto IL_0c23;
																							}
																							goto IL_0c8e;
																							IL_0c23:
																							if (15 > b)
																							{
																								goto IL_0c31;
																							}
																							goto IL_1643;
																							IL_0c31:
																							if (12 >= b)
																							{
																								goto IL_0c3c;
																							}
																							goto IL_0c4f;
																							IL_0c3c:
																							if (12 <= b)
																							{
																								goto IL_186a;
																							}
																							goto IL_0d7d;
																							IL_0d7d:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0d8b;
																							IL_0d8b:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_1132;
																							IL_1132:
																							array2[num6] = 0;
																							goto IL_1140;
																							IL_1140:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])();
																							goto IL_140e;
																							IL_140e:
																							num6++;
																							goto IL_1630;
																							IL_1630:
																							ptr2 += 8;
																							goto IL_186a;
																							IL_0c4f:
																							if (13 >= b)
																							{
																								goto IL_0c5a;
																							}
																							goto IL_0c6d;
																							IL_0c5a:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0e05;
																							IL_0e05:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_0e14;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0ebc;
																							IL_11ef:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_120d;
																							IL_120d:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1231;
																							IL_1231:
																							array3[num6] = array3[num6 - 1];
																							num = 106;
																							goto IL_1252;
																							IL_0ebc:
																							array2[num6] = 5;
																							goto IL_0eca;
																							IL_0eca:
																							num6++;
																							goto IL_186a;
																							IL_0c6d:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_0c7b;
																							IL_0c7b:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_0d3e;
																							IL_0d3e:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_0d5c;
																							IL_0d5c:
																							ptr2 += 8;
																							goto IL_0d6a;
																							IL_0d6a:
																							num6--;
																							goto IL_186a;
																							IL_1643:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_166c;
																							IL_166c:
																							array2[num6 - 1] = 5;
																							goto IL_186a;
																							IL_0c8e:
																							if (17 < b)
																							{
																								goto IL_0c9c;
																							}
																							goto IL_1169;
																							IL_0c9c:
																							if (18 >= b)
																							{
																								goto IL_0ca7;
																							}
																							goto IL_0cba;
																							IL_0ca7:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0edd;
																							IL_0edd:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_0f1b;
																							IL_0f1b:
																							num6 -= 3;
																							goto IL_186a;
																							IL_0cba:
																							if (19 < b)
																							{
																								break;
																							}
																							num = 215;
																							goto IL_0cd1;
																							IL_1252:
																							num6++;
																							goto IL_186a;
																							IL_0cd1:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0cdf;
																							IL_0cdf:
																							array2[num6 - 1] = 5;
																							goto IL_0cf3;
																							IL_0cf3:
																							array3[num6 - 1] = ((delegate*<string[], string>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_0d2b;
																							IL_0d2b:
																							ptr2 += 8;
																							goto IL_186a;
																							IL_1169:
																							if (17 <= b)
																							{
																								goto IL_1174;
																							}
																							goto IL_11bb;
																							IL_1174:
																							array2[num6] = 5;
																							goto IL_1182;
																							IL_1182:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_119a;
																							IL_119a:
																							num6++;
																							goto IL_11a8;
																							IL_11a8:
																							ptr2 += 8;
																							goto IL_186a;
																							IL_11bb:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_11c9;
																							IL_11c9:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_11d7;
																						}
																						break;
																						IL_0640:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_186a;
																				continue;
																				end_IL_0650:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0e14:
			while (true)
			{
				IL_0e14_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0ebc_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0eca_2:
							num6++;
							while (true)
							{
								IL_186a_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0650_2:
											if (b >= 1)
											{
												while (b <= 40)
												{
													while (true)
													{
														IL_0633_2:
														if (20 < b)
														{
															while (true)
															{
																IL_0623_2:
																if (30 < b)
																{
																	while (true)
																	{
																		IL_0613_2:
																		if (35 < b)
																		{
																			while (true)
																			{
																				IL_0603_2:
																				if (38 >= b)
																				{
																					while (true)
																					{
																						IL_05f3_2:
																						if (38 > b)
																						{
																							while (true)
																							{
																								IL_05e3_2:
																								if (36 < b)
																								{
																									while (37 >= b)
																									{
																										num = 83;
																										while (37 <= b)
																										{
																											num = 93;
																											while (true)
																											{
																												IL_059e_2:
																												array2[num6 - 1] = 5;
																												num = 344;
																												while (true)
																												{
																													if (num != 344)
																													{
																														if (num != 1325)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 93:
																														case 319:
																															goto IL_059e_2;
																														case 83:
																															goto IL_05bd_2;
																														case 105:
																															goto IL_05d0_2;
																														case 30:
																															goto IL_05e3_2;
																														case 56:
																															goto IL_05f3_2;
																														case 120:
																															goto IL_0603_2;
																														case 154:
																															goto IL_0613_2;
																														case 250:
																															goto IL_0623_2;
																														case 247:
																															goto IL_0633_2;
																														case 232:
																															goto IL_0640_2;
																														case 178:
																															goto IL_0650_2;
																														case 321:
																															goto end_IL_0650_2;
																														case 50:
																														case 145:
																															goto end_IL_0660;
																														case 26:
																															goto IL_067b_2;
																														case 100:
																															goto IL_068b_2;
																														case 165:
																														case 219:
																															goto IL_069b_2;
																														case 253:
																															goto IL_06b4_2;
																														case 228:
																															goto IL_06cb_2;
																														case 223:
																															goto IL_06d9_2;
																														case 44:
																														case 261:
																															goto IL_06ec_2;
																														case 269:
																															goto IL_0708_2;
																														case 176:
																														case 266:
																															goto IL_0713_2;
																														case 189:
																															goto IL_0753_2;
																														case 251:
																															goto IL_0767_2;
																														case 124:
																															goto IL_077a_2;
																														case 164:
																															goto IL_0788_2;
																														case 18:
																															goto IL_0796_2;
																														case 134:
																															goto IL_07a4_2;
																														case 158:
																														case 234:
																															goto IL_07af_2;
																														case 221:
																															goto IL_07f0_2;
																														case 197:
																															goto IL_0809_2;
																														case 12:
																															goto IL_0817_2;
																														case 3:
																														case 101:
																															goto IL_082e_2;
																														case 111:
																															goto IL_0846_2;
																														case 48:
																															goto IL_0851_2;
																														case 60:
																														case 143:
																															goto IL_085f_2;
																														case 47:
																															goto IL_08b1_2;
																														case 89:
																															goto IL_08cd_2;
																														case 0:
																															goto IL_08db_2;
																														case 186:
																														case 187:
																															goto IL_08e9_2;
																														case 13:
																															goto IL_090a_2;
																														case 23:
																															goto IL_0918_2;
																														case 25:
																															goto IL_0926_2;
																														case 87:
																														case 182:
																															goto IL_0939_2;
																														case 82:
																															goto IL_0971_2;
																														case 160:
																															goto IL_0985_2;
																														case 270:
																															goto IL_09a1_2;
																														case 71:
																															goto IL_09af_2;
																														case 5:
																															goto IL_09bd_2;
																														case 65:
																															goto IL_09cb_2;
																														case 90:
																															goto IL_09d9_2;
																														case 15:
																															goto IL_09e4_2;
																														case 49:
																														case 129:
																															goto IL_09f2_2;
																														case 79:
																															goto IL_0a32_2;
																														case 68:
																															goto IL_0a46_2;
																														case 40:
																															goto IL_0a59_2;
																														case 161:
																															goto IL_0a64_2;
																														case 125:
																														case 220:
																															goto IL_0a72_2;
																														case 203:
																															goto IL_0a9b_2;
																														case 236:
																															goto IL_0aa9_2;
																														case 39:
																															goto IL_0abc_2;
																														case 162:
																															goto IL_0aca_2;
																														case 80:
																														case 142:
																															goto IL_0ad8_2;
																														case 133:
																															goto IL_0ae6_2;
																														case 130:
																															goto IL_0b09_2;
																														case 35:
																															goto IL_0b13_2;
																														case 75:
																															goto IL_0b21_2;
																														case 24:
																														case 198:
																															goto IL_0b34_2;
																														case 92:
																															goto IL_0b79_2;
																														case 188:
																															goto IL_0b87_2;
																														case 8:
																														case 237:
																															goto IL_0b9a_2;
																														case 208:
																															goto IL_0bfc_2;
																														case 229:
																															goto IL_0c18_2;
																														case 9:
																															goto IL_0c23_2;
																														case 97:
																															goto IL_0c31_2;
																														case 246:
																															goto IL_0c3c_2;
																														case 167:
																															goto IL_0c4f_2;
																														case 45:
																															goto IL_0c5a_2;
																														case 95:
																															goto IL_0c6d_2;
																														case 135:
																															goto IL_0c7b_2;
																														case 259:
																															goto IL_0c8e_2;
																														case 204:
																															goto IL_0c9c_2;
																														case 254:
																															goto IL_0ca7_2;
																														case 262:
																															goto IL_0cba_2;
																														case 215:
																															goto IL_0cd1_2;
																														case 85:
																														case 194:
																															goto IL_0cdf_2;
																														case 104:
																															goto IL_0cf3_2;
																														case 98:
																															goto IL_0d2b_2;
																														case 37:
																														case 278:
																															goto IL_0d3e_2;
																														case 102:
																															goto IL_0d5c_2;
																														case 248:
																															goto IL_0d6a_2;
																														case 280:
																															goto IL_0d7d_2;
																														case 172:
																															goto IL_0d8b_2;
																														case 277:
																														case 281:
																															goto IL_0d9e_2;
																														case 57:
																															goto IL_0dde_2;
																														case 206:
																															goto IL_0df2_2;
																														case 117:
																														case 289:
																															goto end_IL_0670;
																														case 34:
																															goto IL_0ebc_2;
																														case 275:
																															goto IL_0eca_2;
																														case 123:
																														case 290:
																															goto IL_0edd_2;
																														case 196:
																															goto IL_0f1b_2;
																														case 292:
																															goto IL_0f2e_2;
																														case 231:
																															goto IL_0f3c_2;
																														case 258:
																															goto IL_0f47_2;
																														case 43:
																															goto IL_0f5a_2;
																														case 107:
																															goto IL_0f65_2;
																														case 192:
																															goto IL_0f78_2;
																														case 149:
																															goto IL_0f8f_2;
																														case 38:
																														case 77:
																															goto IL_0f9d_2;
																														case 207:
																															goto IL_0fbb_2;
																														case 252:
																															goto IL_0fc9_2;
																														case 116:
																															goto IL_0fd7_2;
																														case 212:
																														case 218:
																															goto IL_0fea_2;
																														case 199:
																															goto IL_102a_2;
																														case 163:
																															goto IL_103e_2;
																														case 293:
																															goto IL_1051_2;
																														case 279:
																															goto IL_105f_2;
																														case 132:
																														case 298:
																															goto IL_106f_2;
																														case 69:
																															goto IL_10ad_2;
																														case 183:
																															goto IL_10bb_2;
																														case 299:
																															goto IL_10ce_2;
																														case 53:
																														case 300:
																															goto IL_10e1_2;
																														case 191:
																															goto IL_1103_2;
																														case 179:
																															goto IL_1111_2;
																														case 33:
																															goto IL_111f_2;
																														case 76:
																														case 306:
																															goto IL_1132_2;
																														case 288:
																															goto IL_1140_2;
																														case 311:
																															goto IL_1169_2;
																														case 21:
																														case 70:
																															goto IL_1174_2;
																														case 216:
																															goto IL_1182_2;
																														case 297:
																															goto IL_119a_2;
																														case 190:
																															goto IL_11a8_2;
																														case 282:
																															goto IL_11bb_2;
																														case 127:
																															goto IL_11c9_2;
																														case 41:
																														case 305:
																															goto IL_11d7_2;
																														case 14:
																															goto IL_11ef_2;
																														case 131:
																															goto IL_120d_2;
																														case 285:
																															goto IL_1231_2;
																														case 106:
																															goto IL_1252_2;
																														case 314:
																															goto IL_1265_2;
																														case 291:
																															goto IL_1273_2;
																														case 209:
																															goto IL_127e_2;
																														case 265:
																															goto IL_1291_2;
																														case 139:
																															goto IL_129f_2;
																														case 59:
																														case 287:
																															goto IL_12ad_2;
																														case 22:
																															goto IL_12c1_2;
																														case 233:
																															goto IL_1300_2;
																														case 230:
																															goto IL_1325_2;
																														case 175:
																														case 226:
																															goto IL_1333_2;
																														case 151:
																															goto IL_1347_2;
																														case 73:
																															goto IL_1394_2;
																														case 257:
																															goto IL_13ab_2;
																														case 274:
																															goto IL_13be_2;
																														case 72:
																															goto IL_13d5_2;
																														case 174:
																														case 313:
																															goto IL_13e3_2;
																														case 181:
																															goto IL_13ed_2;
																														case 11:
																															goto IL_13fb_2;
																														case 316:
																															goto IL_140e_2;
																														case 317:
																															goto IL_1421_2;
																														case 318:
																															goto IL_143a_2;
																														case 118:
																															goto IL_1445_2;
																														case 210:
																															goto IL_1458_2;
																														case 308:
																															goto IL_1466_2;
																														case 322:
																															goto IL_1479_2;
																														case 119:
																															goto IL_1487_2;
																														case 1:
																														case 86:
																															goto IL_1495_2;
																														case 169:
																															goto IL_14a9_2;
																														case 46:
																														case 324:
																															goto IL_14ed_2;
																														case 4:
																														case 325:
																															goto IL_1509_2;
																														case 303:
																															goto IL_1526_2;
																														case 51:
																															goto IL_1565_2;
																														case 211:
																														case 327:
																															goto IL_1578_2;
																														case 185:
																															goto IL_15b8_2;
																														case 114:
																															goto IL_15cc_2;
																														case 309:
																														case 328:
																															goto IL_15df_2;
																														case 17:
																															goto IL_15f8_2;
																														case 99:
																															goto IL_1606_2;
																														case 144:
																															goto IL_1614_2;
																														case 330:
																															goto IL_1630_2;
																														case 42:
																														case 331:
																															goto IL_1643_2;
																														case 141:
																															goto IL_166c_2;
																														case 332:
																															goto IL_1685_2;
																														case 334:
																															goto IL_16a1_2;
																														case 94:
																														case 329:
																															goto IL_16af_2;
																														case 240:
																															goto IL_16ef_2;
																														case 74:
																															goto IL_1703_2;
																														case 335:
																															goto IL_1716_2;
																														case 337:
																															goto IL_1729_2;
																														case 184:
																															goto IL_1774_2;
																														case 243:
																														case 302:
																															goto IL_1787_2;
																														case 91:
																															goto IL_17a0_2;
																														case 156:
																															goto IL_17bc_2;
																														case 244:
																															goto IL_17c7_2;
																														case 242:
																														case 263:
																															goto IL_17d5_2;
																														case 54:
																															goto IL_17f2_2;
																														case 213:
																															goto IL_1831_2;
																														case 126:
																															goto IL_1841_2;
																														case 217:
																															goto IL_184c_2;
																														case 6:
																														case 27:
																														case 29:
																														case 32:
																														case 55:
																														case 58:
																														case 78:
																														case 88:
																														case 96:
																														case 108:
																														case 110:
																														case 115:
																														case 137:
																														case 146:
																														case 147:
																														case 148:
																														case 152:
																														case 157:
																														case 166:
																														case 168:
																														case 170:
																														case 173:
																														case 177:
																														case 195:
																														case 201:
																														case 222:
																														case 227:
																														case 239:
																														case 255:
																														case 256:
																														case 260:
																														case 268:
																														case 272:
																														case 283:
																														case 284:
																														case 286:
																														case 296:
																														case 310:
																														case 312:
																														case 315:
																														case 323:
																														case 326:
																														case 333:
																															goto end_IL_058b_2;
																														case 2:
																														case 19:
																														case 20:
																														case 36:
																														case 52:
																														case 61:
																														case 63:
																														case 64:
																														case 66:
																														case 67:
																														case 81:
																														case 84:
																														case 103:
																														case 109:
																														case 121:
																														case 122:
																														case 136:
																														case 138:
																														case 140:
																														case 150:
																														case 153:
																														case 155:
																														case 171:
																														case 180:
																														case 193:
																														case 202:
																														case 205:
																														case 214:
																														case 225:
																														case 235:
																														case 238:
																														case 241:
																														case 245:
																														case 249:
																														case 264:
																														case 267:
																														case 276:
																														case 294:
																														case 295:
																														case 301:
																														case 304:
																														case 320:
																														case 336:
																															goto IL_186a_2;
																														case 28:
																															ptr2 = ptr;
																															goto IL_186a_2;
																														case 159:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllocateBufferFromNotGengetUseMachineKeyStore.ExceptionFromErrorCodeGetSymWriter);
																															goto case 28;
																														case 224:
																															array7[0] = this;
																															goto case 159;
																														case 7:
																															array7 = new object[16];
																															num = 224;
																															goto case 224;
																														case 31:
																															array6 = new long[4];
																															goto case 7;
																														case 10:
																															array5 = new int[7];
																															goto case 31;
																														case 271:
																															array4 = new int[4];
																															goto case 10;
																														case 62:
																															array3 = new object[4];
																															num = 271;
																															goto case 271;
																														case 307:
																															array2 = new byte[4];
																															goto case 62;
																														case 273:
																															num4 = num2 * 8;
																															goto case 307;
																														case 128:
																															num3 = num2 * 4;
																															goto case 273;
																														case 112:
																															num2 = 1;
																															goto case 128;
																														case 113:
																															goto end_IL_0e22;
																														case 16:
																														case 200:
																															return;
																														}
																														continue;
																													}
																													array3[num6 - 1] = ((delegate*<string, GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																													goto IL_1774_2;
																													IL_1774_2:
																													ptr2 += 8;
																													goto IL_186a_2;
																													continue;
																													end_IL_058b_2:
																													break;
																												}
																												break;
																											}
																											break;
																											IL_05bd_2:;
																										}
																										break;
																										IL_05d0_2:;
																									}
																									break;
																								}
																								goto IL_068b_2;
																								IL_06ec_2:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								goto IL_186a_2;
																								IL_068b_2:
																								if (36 > b)
																								{
																									break;
																								}
																								goto IL_06ec_2;
																							}
																							break;
																						}
																						goto IL_1787_2;
																						IL_17a0_2:
																						num6--;
																						num = 320;
																						goto IL_186a_2;
																						IL_1787_2:
																						global::_003CModule_003E.gameObject_26 = (GameObject)array3[num6 - 1];
																						goto IL_17a0_2;
																					}
																					break;
																				}
																				goto IL_17bc_2;
																				IL_184c_2:
																				if (40 <= b)
																				{
																				}
																				break;
																				IL_17bc_2:
																				if (39 >= b)
																				{
																					goto IL_17c7_2;
																				}
																				goto IL_1841_2;
																				IL_17c7_2:
																				if (39 > b)
																				{
																					break;
																				}
																				goto IL_17d5_2;
																				IL_17d5_2:
																				array2[num6 - 1] = 3;
																				num = 54;
																				goto IL_17f2_2;
																				IL_17f2_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1831_2;
																				IL_1831_2:
																				ptr2 += 8;
																				goto IL_186a_2;
																				IL_1841_2:
																				if (40 < b)
																				{
																					break;
																				}
																				goto IL_184c_2;
																			}
																			break;
																		}
																		goto IL_0f2e_2;
																		IL_102a_2:
																		array2[num6 - 2] = 3;
																		goto IL_103e_2;
																		IL_0f2e_2:
																		if (35 > b)
																		{
																			goto IL_0f3c_2;
																		}
																		goto IL_0fea_2;
																		IL_0f3c_2:
																		if (32 >= b)
																		{
																			goto IL_0f47_2;
																		}
																		goto IL_0f5a_2;
																		IL_0f47_2:
																		if (32 <= b)
																		{
																			goto IL_106f_2;
																		}
																		goto IL_1479_2;
																		IL_106f_2:
																		((delegate*<GameObject, bool, void>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																		goto IL_10ad_2;
																		IL_10ad_2:
																		num6 -= 2;
																		goto IL_10bb_2;
																		IL_10bb_2:
																		ptr2 += 8;
																		goto IL_186a_2;
																		IL_1479_2:
																		if (31 < b)
																		{
																			break;
																		}
																		goto IL_1487_2;
																		IL_1487_2:
																		if (31 > b)
																		{
																			break;
																		}
																		goto IL_1495_2;
																		IL_1495_2:
																		array2[num6 - 1] = 0;
																		goto IL_14a9_2;
																		IL_14a9_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1716_2;
																		IL_1716_2:
																		ptr2 += 8;
																		goto IL_186a_2;
																		IL_0f5a_2:
																		if (33 >= b)
																		{
																			goto IL_0f65_2;
																		}
																		goto IL_0f78_2;
																		IL_0f65_2:
																		if (33 > b)
																		{
																			break;
																		}
																		goto IL_1509_2;
																		IL_1509_2:
																		array2[num6 - 1] = 3;
																		num = 303;
																		goto IL_1526_2;
																		IL_1526_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1565_2;
																		IL_1565_2:
																		ptr2 += 8;
																		goto IL_186a_2;
																		IL_0f78_2:
																		if (34 < b)
																		{
																			break;
																		}
																		num = 149;
																		goto IL_0f8f_2;
																		IL_103e_2:
																		num6--;
																		goto IL_186a_2;
																		IL_0f8f_2:
																		if (34 > b)
																		{
																			break;
																		}
																		goto IL_0f9d_2;
																		IL_0f9d_2:
																		array3[num6] = ((delegate*<GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])();
																		goto IL_0fbb_2;
																		IL_0fbb_2:
																		array2[num6] = 5;
																		goto IL_0fc9_2;
																		IL_0fc9_2:
																		num6++;
																		goto IL_0fd7_2;
																		IL_0fd7_2:
																		ptr2 += 8;
																		goto IL_186a_2;
																		IL_0fea_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_102a_2;
																	}
																	break;
																}
																goto IL_0708_2;
																IL_13d5_2:
																if (26 > b)
																{
																	break;
																}
																goto IL_13e3_2;
																IL_0708_2:
																if (30 <= b)
																{
																	goto IL_0713_2;
																}
																goto IL_077a_2;
																IL_0713_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0753_2;
																IL_0753_2:
																array2[num6 - 2] = 3;
																goto IL_0767_2;
																IL_0767_2:
																num6--;
																goto IL_186a_2;
																IL_077a_2:
																if (25 >= b)
																{
																	goto IL_0788_2;
																}
																goto IL_1265_2;
																IL_0788_2:
																if (25 > b)
																{
																	goto IL_0796_2;
																}
																goto IL_0939_2;
																IL_0796_2:
																if (22 >= b)
																{
																	goto IL_07a4_2;
																}
																goto IL_0846_2;
																IL_07a4_2:
																if (22 <= b)
																{
																	goto IL_07af_2;
																}
																goto IL_0809_2;
																IL_07af_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																goto IL_07f0_2;
																IL_07f0_2:
																array2[num6 - 2] = 0;
																goto IL_1729_2;
																IL_1729_2:
																num6--;
																goto IL_186a_2;
																IL_0809_2:
																if (21 < b)
																{
																	break;
																}
																goto IL_0817_2;
																IL_0817_2:
																if (21 > b)
																{
																	break;
																}
																num = 101;
																goto IL_082e_2;
																IL_13e3_2:
																array3[num6] = null;
																goto IL_13ed_2;
																IL_082e_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_186a_2;
																IL_0846_2:
																if (23 >= b)
																{
																	goto IL_0851_2;
																}
																goto IL_08cd_2;
																IL_0851_2:
																if (23 > b)
																{
																	break;
																}
																goto IL_085f_2;
																IL_085f_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_08b1_2;
																IL_08b1_2:
																num6--;
																num = 264;
																goto IL_186a_2;
																IL_08cd_2:
																if (24 < b)
																{
																	break;
																}
																goto IL_08db_2;
																IL_08db_2:
																if (24 > b)
																{
																	break;
																}
																goto IL_08e9_2;
																IL_08e9_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																num = 13;
																goto IL_090a_2;
																IL_090a_2:
																array2[num6] = 5;
																goto IL_0918_2;
																IL_0918_2:
																num6++;
																goto IL_0926_2;
																IL_0926_2:
																ptr2 += 8;
																goto IL_186a_2;
																IL_0939_2:
																array3[num6 - 1] = ((delegate*<Class178, GameObject>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((Class178)array3[num6 - 1]);
																goto IL_0971_2;
																IL_0971_2:
																array2[num6 - 1] = 5;
																goto IL_0985_2;
																IL_0985_2:
																ptr2 += 8;
																num = 245;
																goto IL_186a_2;
																IL_1265_2:
																if (27 < b)
																{
																	goto IL_1273_2;
																}
																num = 230;
																goto IL_1325_2;
																IL_1273_2:
																if (28 >= b)
																{
																	goto IL_127e_2;
																}
																goto IL_1291_2;
																IL_127e_2:
																if (28 > b)
																{
																	break;
																}
																goto IL_15df_2;
																IL_15df_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																goto IL_15f8_2;
																IL_15f8_2:
																array2[num6] = 3;
																goto IL_1606_2;
																IL_1606_2:
																num6++;
																goto IL_1614_2;
																IL_1614_2:
																ptr2 += 16;
																num = 155;
																goto IL_186a_2;
																IL_1291_2:
																if (29 < b)
																{
																	break;
																}
																goto IL_129f_2;
																IL_129f_2:
																if (29 > b)
																{
																	break;
																}
																goto IL_12ad_2;
																IL_12ad_2:
																array2[num6 - 1] = 3;
																goto IL_12c1_2;
																IL_12c1_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1300_2;
																IL_1300_2:
																ptr2 += 8;
																num = 241;
																goto IL_186a_2;
																IL_13ed_2:
																array2[num6] = 5;
																goto IL_13fb_2;
																IL_1325_2:
																if (27 <= b)
																{
																	goto IL_1333_2;
																}
																goto IL_13be_2;
																IL_1333_2:
																array2[num6 - 2] = 0;
																goto IL_1347_2;
																IL_1347_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((GameObject)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																goto IL_1394_2;
																IL_1394_2:
																num6--;
																num = 257;
																goto IL_13ab_2;
																IL_13ab_2:
																ptr2 += 8;
																goto IL_186a_2;
																IL_13be_2:
																if (26 < b)
																{
																	break;
																}
																num = 72;
																goto IL_13d5_2;
																IL_13fb_2:
																num6++;
																goto IL_186a_2;
															}
															break;
														}
														goto IL_067b_2;
														IL_1231_2:
														array3[num6] = array3[num6 - 1];
														num = 106;
														goto IL_1252_2;
														IL_067b_2:
														if (20 <= b)
														{
															goto IL_069b_2;
														}
														goto IL_09a1_2;
														IL_069b_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_06b4_2;
														IL_06b4_2:
														array2[num6] = 1;
														num = 228;
														goto IL_06cb_2;
														IL_06cb_2:
														num6++;
														goto IL_06d9_2;
														IL_06d9_2:
														ptr2 += 16;
														goto IL_186a_2;
														IL_09a1_2:
														if (10 >= b)
														{
															goto IL_09af_2;
														}
														goto IL_0c18_2;
														IL_09af_2:
														if (10 > b)
														{
															goto IL_09bd_2;
														}
														goto IL_0b9a_2;
														IL_09bd_2:
														if (5 >= b)
														{
															goto IL_09cb_2;
														}
														goto IL_0b79_2;
														IL_09cb_2:
														if (5 > b)
														{
															goto IL_09d9_2;
														}
														goto IL_0b34_2;
														IL_09d9_2:
														if (2 >= b)
														{
															goto IL_09e4_2;
														}
														goto IL_0a59_2;
														IL_09e4_2:
														if (2 <= b)
														{
															goto IL_09f2_2;
														}
														goto IL_1051_2;
														IL_09f2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0a32_2;
														IL_0a32_2:
														array2[num6 - 2] = 0;
														goto IL_0a46_2;
														IL_0a46_2:
														num6--;
														goto IL_186a_2;
														IL_1051_2:
														if (1 < b)
														{
															break;
														}
														goto IL_105f_2;
														IL_105f_2:
														if (1 > b)
														{
															break;
														}
														goto IL_10e1_2;
														IL_10e1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														num = 191;
														goto IL_1103_2;
														IL_1103_2:
														array2[num6] = 0;
														goto IL_1111_2;
														IL_1111_2:
														num6++;
														goto IL_111f_2;
														IL_111f_2:
														ptr2 += 8;
														goto IL_186a_2;
														IL_0a59_2:
														if (3 >= b)
														{
															goto IL_0a64_2;
														}
														goto IL_0abc_2;
														IL_0a64_2:
														if (3 > b)
														{
															break;
														}
														goto IL_0a72_2;
														IL_0a72_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0a9b_2;
														IL_0a9b_2:
														ptr2 += 8;
														goto IL_0aa9_2;
														IL_0aa9_2:
														num6--;
														goto IL_186a_2;
														IL_0abc_2:
														if (4 < b)
														{
															break;
														}
														goto IL_0aca_2;
														IL_0aca_2:
														if (4 > b)
														{
															break;
														}
														goto IL_0ad8_2;
														IL_0ad8_2:
														array2[num6] = 0;
														goto IL_0ae6_2;
														IL_0ae6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0b09_2;
														IL_0b09_2:
														array3[num6] = null;
														goto IL_0b13_2;
														IL_0b13_2:
														num6++;
														goto IL_0b21_2;
														IL_0b21_2:
														ptr2 += 8;
														goto IL_186a_2;
														IL_0b34_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1421_2;
														IL_1421_2:
														array2[num6 - 2] = 0;
														goto IL_1685_2;
														IL_1685_2:
														num6--;
														num = 150;
														goto IL_186a_2;
														IL_0b79_2:
														if (7 >= b)
														{
															goto IL_0b87_2;
														}
														goto IL_143a_2;
														IL_0b87_2:
														if (7 <= b)
														{
															goto IL_0d9e_2;
														}
														goto IL_10ce_2;
														IL_0d9e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0dde_2;
														IL_0dde_2:
														array2[num6 - 2] = 0;
														goto IL_0df2_2;
														IL_0df2_2:
														num6--;
														goto IL_186a_2;
														IL_10ce_2:
														if (6 < b)
														{
															break;
														}
														goto IL_16a1_2;
														IL_16a1_2:
														if (6 > b)
														{
															break;
														}
														goto IL_16af_2;
														IL_16af_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_16ef_2;
														IL_16ef_2:
														array2[num6 - 2] = 0;
														goto IL_1703_2;
														IL_1703_2:
														num6--;
														goto IL_186a_2;
														IL_143a_2:
														if (8 >= b)
														{
															goto IL_1445_2;
														}
														goto IL_1458_2;
														IL_1445_2:
														if (8 > b)
														{
															break;
														}
														goto IL_14ed_2;
														IL_14ed_2:
														num6--;
														num = 2;
														goto IL_186a_2;
														IL_1458_2:
														if (9 < b)
														{
															break;
														}
														goto IL_1466_2;
														IL_1466_2:
														if (9 > b)
														{
															break;
														}
														goto IL_1578_2;
														IL_1578_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_15b8_2;
														IL_15b8_2:
														array2[num6 - 2] = 0;
														goto IL_15cc_2;
														IL_15cc_2:
														num6--;
														goto IL_186a_2;
														IL_0b9a_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0bfc_2;
														IL_0bfc_2:
														num6 -= 2;
														num = 336;
														goto IL_186a_2;
														IL_0c18_2:
														if (15 >= b)
														{
															goto IL_0c23_2;
														}
														goto IL_0c8e_2;
														IL_0c23_2:
														if (15 > b)
														{
															goto IL_0c31_2;
														}
														goto IL_1643_2;
														IL_0c31_2:
														if (12 >= b)
														{
															goto IL_0c3c_2;
														}
														goto IL_0c4f_2;
														IL_0c3c_2:
														if (12 <= b)
														{
															goto IL_186a_2;
														}
														goto IL_0d7d_2;
														IL_0d7d_2:
														if (11 < b)
														{
															break;
														}
														goto IL_0d8b_2;
														IL_0d8b_2:
														if (11 > b)
														{
															break;
														}
														goto IL_1132_2;
														IL_1132_2:
														array2[num6] = 0;
														goto IL_1140_2;
														IL_1140_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])();
														goto IL_140e_2;
														IL_140e_2:
														num6++;
														goto IL_1630_2;
														IL_1630_2:
														ptr2 += 8;
														goto IL_186a_2;
														IL_0c4f_2:
														if (13 >= b)
														{
															goto IL_0c5a_2;
														}
														goto IL_0c6d_2;
														IL_0c5a_2:
														if (13 > b)
														{
															break;
														}
														goto end_IL_0670;
														IL_0c6d_2:
														if (14 < b)
														{
															break;
														}
														goto IL_0c7b_2;
														IL_0c7b_2:
														if (14 > b)
														{
															break;
														}
														goto IL_0d3e_2;
														IL_0d3e_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_0d5c_2;
														IL_0d5c_2:
														ptr2 += 8;
														goto IL_0d6a_2;
														IL_0d6a_2:
														num6--;
														goto IL_186a_2;
														IL_1643_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_166c_2;
														IL_166c_2:
														array2[num6 - 1] = 5;
														goto IL_186a_2;
														IL_0c8e_2:
														if (17 < b)
														{
															goto IL_0c9c_2;
														}
														goto IL_1169_2;
														IL_0c9c_2:
														if (18 >= b)
														{
															goto IL_0ca7_2;
														}
														goto IL_0cba_2;
														IL_0ca7_2:
														if (18 > b)
														{
															break;
														}
														goto IL_0edd_2;
														IL_0edd_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_0f1b_2;
														IL_0f1b_2:
														num6 -= 3;
														goto IL_186a_2;
														IL_0cba_2:
														if (19 < b)
														{
															break;
														}
														num = 215;
														goto IL_0cd1_2;
														IL_1252_2:
														num6++;
														goto IL_186a_2;
														IL_0cd1_2:
														if (19 > b)
														{
															break;
														}
														goto IL_0cdf_2;
														IL_0cdf_2:
														array2[num6 - 1] = 5;
														goto IL_0cf3_2;
														IL_0cf3_2:
														array3[num6 - 1] = ((delegate*<string[], string>)PrimaryGroupSidNumLockOn[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_0d2b_2;
														IL_0d2b_2:
														ptr2 += 8;
														goto IL_186a_2;
														IL_1169_2:
														if (17 <= b)
														{
															goto IL_1174_2;
														}
														goto IL_11bb_2;
														IL_1174_2:
														array2[num6] = 5;
														goto IL_1182_2;
														IL_1182_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_119a_2;
														IL_119a_2:
														num6++;
														goto IL_11a8_2;
														IL_11a8_2:
														ptr2 += 8;
														goto IL_186a_2;
														IL_11bb_2:
														if (16 < b)
														{
															break;
														}
														goto IL_11c9_2;
														IL_11c9_2:
														if (16 > b)
														{
															break;
														}
														goto IL_11d7_2;
														IL_11d7_2:
														array2[num6] = array2[num6 - 1];
														goto IL_11ef_2;
														IL_11ef_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_120d_2;
														IL_120d_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1231_2;
													}
													break;
													IL_0640_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_186a_2;
											continue;
											end_IL_0650_2:
											break;
										}
										continue;
										end_IL_0660:
										break;
									}
									continue;
									end_IL_0670:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_0e14_2;
					}
					continue;
					end_IL_0e22:
					break;
				}
				break;
			}
		}
	}

	public Class178()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3, int int_4)
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenerateDefinitionKeyDefaultCategory.VARFLAGFREQUESTEDITRaiseOnSerializedEvent);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 96;
													while (true)
													{
														if (num == 96)
														{
															goto IL_0247;
														}
														if (num != 1077)
														{
															goto IL_0562;
														}
														switch (num)
														{
														case 23:
															goto end_IL_018f;
														case 34:
															goto end_IL_01a2;
														case 14:
															goto end_IL_01ad;
														case 49:
															goto end_IL_01b7;
														case 88:
															goto end_IL_01c2;
														case 1:
															goto end_IL_01d7;
														case 59:
														case 84:
															goto end_IL_01ec;
														case 62:
															goto end_IL_01fc;
														case 16:
														case 24:
															goto end_IL_020c;
														case 56:
															goto end_IL_021c;
														case 57:
															goto end_IL_022c;
														case 2:
														case 13:
														case 35:
														case 46:
														case 54:
														case 75:
														case 77:
														case 86:
														case 87:
															goto IL_0247;
														case 4:
														case 74:
															goto IL_0257;
														case 64:
															goto IL_0269;
														case 78:
															goto IL_0277;
														case 85:
															goto IL_0285;
														case 43:
															goto IL_0293;
														case 0:
														case 37:
															goto IL_02a1;
														case 9:
															goto IL_02ac;
														case 30:
														case 79:
															goto IL_02c0;
														case 7:
															goto IL_02ce;
														case 18:
														case 28:
															goto IL_02dc;
														case 53:
															goto IL_02f4;
														case 73:
															goto IL_02ff;
														case 31:
														case 80:
															goto IL_0318;
														case 32:
															goto IL_0326;
														case 15:
															goto IL_0349;
														case 25:
															goto IL_0353;
														case 72:
															goto IL_0361;
														case 3:
															goto IL_0374;
														case 68:
															goto IL_0382;
														case 27:
														case 42:
															goto IL_0390;
														case 66:
															goto IL_03ac;
														case 5:
														case 41:
															goto IL_03b7;
														case 44:
															goto IL_03e0;
														case 61:
															goto IL_03ee;
														case 19:
														case 71:
															goto IL_040a;
														case 40:
															goto IL_0418;
														case 21:
														case 29:
															goto IL_0426;
														case 67:
															goto IL_0494;
														case 60:
															goto IL_04b0;
														case 17:
															goto IL_04be;
														case 20:
															goto IL_04d1;
														case 63:
															goto IL_04df;
														case 81:
														case 89:
															goto IL_04ed;
														case 22:
															goto IL_052d;
														case 82:
															goto IL_0541;
														case 76:
															goto IL_0554;
														case 45:
															goto IL_0562;
														case 65:
															goto IL_0579;
														case 6:
														case 8:
														case 10:
														case 11:
														case 26:
														case 33:
														case 36:
														case 38:
														case 39:
														case 47:
														case 48:
														case 50:
														case 51:
														case 52:
														case 55:
														case 58:
														case 69:
														case 83:
															goto IL_058c;
														case 12:
														case 70:
															goto IL_05b1;
														}
														continue;
														IL_058c:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0554;
														IL_0554:
														array[num4] = 0;
														goto IL_0562;
														IL_0247:
														if (num5 != 1)
														{
															goto IL_0257;
														}
														goto IL_05b1;
														IL_05b1:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														IL_0257:
														b = *ptr2;
														num = 64;
														goto IL_0269;
														IL_0269:
														ptr2++;
														goto IL_0277;
														IL_0277:
														if (b >= 1)
														{
															goto IL_0285;
														}
														goto IL_058c;
														IL_0285:
														if (b <= 8)
														{
															goto IL_0293;
														}
														goto IL_058c;
														IL_0293:
														if (4 < b)
														{
															goto IL_02a1;
														}
														goto IL_03ac;
														IL_02a1:
														if (6 >= b)
														{
															goto IL_02ac;
														}
														goto IL_02f4;
														IL_02ac:
														if (6 <= b)
														{
															goto IL_0247;
														}
														num = 79;
														goto IL_02c0;
														IL_0562:
														num4++;
														num = 65;
														goto IL_0579;
														IL_02c0:
														if (5 >= b)
														{
															goto IL_02ce;
														}
														goto IL_058c;
														IL_02ce:
														if (5 <= b)
														{
															goto IL_02dc;
														}
														goto IL_058c;
														IL_02dc:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_0247;
														IL_02f4:
														if (7 >= b)
														{
															goto IL_02ff;
														}
														goto IL_0374;
														IL_02ff:
														if (7 <= b)
														{
															goto IL_0318;
														}
														num = 36;
														goto IL_058c;
														IL_0579:
														ptr2 += 8;
														goto IL_0247;
														IL_0318:
														array[num4] = 0;
														goto IL_0326;
														IL_0326:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0349;
														IL_0349:
														array2[num4] = null;
														goto IL_0353;
														IL_0353:
														num4++;
														goto IL_0361;
														IL_0361:
														ptr2 += 8;
														goto IL_0247;
														IL_0374:
														if (8 >= b)
														{
															goto IL_0382;
														}
														goto IL_058c;
														IL_0382:
														if (8 <= b)
														{
															goto IL_0390;
														}
														goto IL_058c;
														IL_0390:
														byte* num6 = ptr2;
														num5 = 1;
														ptr2 = num6 + -200;
														goto IL_0247;
														IL_03ac:
														if (4 <= b)
														{
															goto IL_03b7;
														}
														goto IL_040a;
														IL_03b7:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_03e0;
														IL_03e0:
														ptr2 += 8;
														goto IL_03ee;
														IL_03ee:
														num4--;
														num = 86;
														goto IL_0247;
														IL_040a:
														if (2 >= b)
														{
															goto IL_0418;
														}
														goto IL_04d1;
														IL_0418:
														if (2 <= b)
														{
															goto IL_0426;
														}
														goto IL_04b0;
														IL_0426:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0494;
														IL_0494:
														num4 -= 2;
														num = 35;
														goto IL_0247;
														IL_04b0:
														if (1 >= b)
														{
															goto IL_04be;
														}
														goto IL_058c;
														IL_04be:
														if (1 <= b)
														{
														}
														goto IL_058c;
														IL_04d1:
														if (3 >= b)
														{
															goto IL_04df;
														}
														goto IL_058c;
														IL_04df:
														if (3 <= b)
														{
															goto IL_04ed;
														}
														goto IL_058c;
														IL_04ed:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_052d;
														IL_052d:
														array[num4 - 2] = 0;
														goto IL_0541;
														IL_0541:
														num4--;
														goto IL_0247;
														continue;
														end_IL_018f:
														break;
													}
													continue;
													end_IL_01a2:
													break;
												}
												continue;
												end_IL_01ad:
												break;
											}
											continue;
											end_IL_01b7:
											break;
										}
										continue;
										end_IL_01c2:
										break;
									}
									continue;
									end_IL_01d7:
									break;
								}
								continue;
								end_IL_01ec:
								break;
							}
							continue;
							end_IL_01fc:
							break;
						}
						continue;
						end_IL_020c:
						break;
					}
					continue;
					end_IL_021c:
					break;
				}
				continue;
				end_IL_022c:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3)
	{
		int num = 93;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StringToHGlobalAutoStringSort.GetSerialNumberParamValues);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0289:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_026c:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_025c:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_024c:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_023f:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0206:
																													array[num5] = 0;
																													num = 121;
																													while (true)
																													{
																														if (num != 121)
																														{
																															if (num != 1102)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 45:
																															case 87:
																																goto IL_0206;
																															case 59:
																																goto IL_021f;
																															case 58:
																																goto IL_022f;
																															case 37:
																																goto IL_023f;
																															case 15:
																																goto IL_024c;
																															case 11:
																																goto IL_025c;
																															case 105:
																																goto IL_026c;
																															case 24:
																																goto IL_0279;
																															case 48:
																																goto IL_0289;
																															case 96:
																																goto end_IL_0289;
																															case 5:
																															case 8:
																																goto end_IL_0299;
																															case 44:
																																goto IL_02b4;
																															case 78:
																															case 82:
																																goto IL_02c7;
																															case 84:
																																goto IL_02d5;
																															case 75:
																															case 88:
																																goto IL_02e3;
																															case 83:
																																goto IL_0345;
																															case 29:
																															case 107:
																																goto IL_0358;
																															case 4:
																																goto IL_0363;
																															case 2:
																															case 49:
																																goto IL_0371;
																															case 67:
																																goto IL_038d;
																															case 23:
																																goto IL_039b;
																															case 52:
																															case 110:
																																goto IL_03ae;
																															case 6:
																															case 66:
																																goto IL_03b9;
																															case 62:
																																goto IL_03c7;
																															case 47:
																															case 97:
																																goto IL_03d5;
																															case 42:
																																goto IL_03f8;
																															case 19:
																																goto IL_0406;
																															case 46:
																																goto IL_0414;
																															case 63:
																																goto IL_0427;
																															case 28:
																															case 57:
																																goto IL_0435;
																															case 81:
																																goto IL_0475;
																															case 74:
																																goto IL_0489;
																															case 100:
																																goto IL_04bf;
																															case 34:
																																goto IL_04c9;
																															case 112:
																																goto IL_04d7;
																															case 102:
																																goto IL_04f3;
																															case 26:
																															case 30:
																																goto IL_0501;
																															case 9:
																																goto IL_050c;
																															case 114:
																																goto IL_051a;
																															case 64:
																															case 104:
																																goto IL_0528;
																															case 21:
																																goto IL_0551;
																															case 43:
																																goto IL_055f;
																															case 35:
																																goto IL_0572;
																															case 38:
																															case 101:
																																goto IL_0580;
																															case 77:
																																goto IL_0599;
																															case 108:
																																goto IL_05a7;
																															case 1:
																																goto IL_05b5;
																															case 22:
																															case 51:
																																goto IL_05c8;
																															case 39:
																															case 109:
																																goto IL_05e0;
																															case 3:
																																goto IL_0620;
																															case 91:
																																goto IL_0634;
																															case 13:
																															case 14:
																															case 31:
																															case 32:
																															case 36:
																															case 40:
																															case 50:
																															case 55:
																															case 56:
																															case 60:
																															case 61:
																															case 65:
																															case 68:
																															case 69:
																															case 70:
																															case 85:
																															case 90:
																															case 95:
																															case 98:
																															case 99:
																															case 111:
																															case 113:
																																goto end_IL_01f3;
																															case 7:
																															case 12:
																															case 16:
																															case 17:
																															case 33:
																															case 41:
																															case 53:
																															case 54:
																															case 71:
																															case 72:
																															case 76:
																															case 80:
																															case 89:
																															case 106:
																																goto end_IL_02a9;
																															case 18:
																																goto end_IL_0660;
																															case 79:
																																goto end_IL_0673;
																															case 103:
																																goto end_IL_067d;
																															case 86:
																																goto end_IL_0688;
																															case 20:
																															case 25:
																																goto end_IL_069d;
																															case 0:
																																goto end_IL_06ad;
																															case 10:
																															case 94:
																																goto end_IL_06bd;
																															case 92:
																																goto end_IL_06cd;
																															case 93:
																																goto end_IL_06dd;
																															case 27:
																															case 73:
																																goto IL_06f8;
																															}
																															continue;
																														}
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														goto IL_04bf;
																														IL_04bf:
																														array2[num5] = null;
																														goto IL_04c9;
																														IL_04d7:
																														ptr2 += 8;
																														goto end_IL_02a9;
																														IL_04c9:
																														num5++;
																														goto IL_04d7;
																														continue;
																														end_IL_01f3:
																														break;
																													}
																													break;
																												}
																												break;
																												IL_021f:;
																											}
																											break;
																											IL_022f:;
																										}
																										break;
																									}
																									goto IL_02b4;
																									IL_02b4:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02a9;
																								}
																								break;
																							}
																							num = 102;
																							goto IL_04f3;
																							IL_05b5:
																							ptr2 += 8;
																							goto end_IL_02a9;
																							IL_05c8:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02a9;
																							IL_04f3:
																							if (3 > b)
																							{
																								goto IL_0501;
																							}
																							goto IL_05c8;
																							IL_0501:
																							if (1 < b)
																							{
																								goto IL_050c;
																							}
																							goto IL_0572;
																							IL_050c:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_051a;
																							IL_051a:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0528;
																							IL_0528:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0551;
																							IL_0551:
																							ptr2 += 8;
																							goto IL_055f;
																							IL_055f:
																							num5--;
																							goto end_IL_02a9;
																							IL_0572:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0580;
																							IL_0580:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0599;
																							IL_0599:
																							array[num5] = 0;
																							goto IL_05a7;
																							IL_05a7:
																							num5++;
																							goto IL_05b5;
																						}
																						break;
																					}
																					goto IL_05e0;
																					IL_0634:
																					num5--;
																					num = 53;
																					goto end_IL_02a9;
																					IL_05e0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0620;
																					IL_0620:
																					array[num5 - 2] = 0;
																					goto IL_0634;
																				}
																				break;
																			}
																			goto IL_02c7;
																			IL_039b:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_02c7:
																			if (9 >= b)
																			{
																				goto IL_02d5;
																			}
																			goto IL_0358;
																			IL_02d5:
																			if (9 <= b)
																			{
																				goto IL_02e3;
																			}
																			goto IL_03ae;
																			IL_02e3:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0345;
																			IL_0345:
																			num5 -= 2;
																			goto end_IL_02a9;
																			IL_03ae:
																			if (7 < b)
																			{
																				goto IL_03b9;
																			}
																			goto IL_0427;
																			IL_03b9:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03c7;
																			IL_03c7:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03d5;
																			IL_03d5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03f8;
																			IL_03f8:
																			array[num5] = 0;
																			goto IL_0406;
																			IL_0406:
																			num5++;
																			goto IL_0414;
																			IL_0414:
																			ptr2 += 8;
																			goto end_IL_02a9;
																			IL_0427:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0435;
																			IL_0435:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0475;
																			IL_0475:
																			array[num5 - 2] = 0;
																			goto IL_0489;
																			IL_0489:
																			num5--;
																			goto end_IL_02a9;
																			IL_0358:
																			if (10 >= b)
																			{
																				goto IL_0363;
																			}
																			goto IL_038d;
																			IL_0363:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0371;
																			IL_0371:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a9;
																			IL_038d:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_039b;
																		}
																		break;
																		IL_0279:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a9;
																continue;
																end_IL_0289:
																break;
															}
															continue;
															end_IL_0299:
															break;
														}
														continue;
														end_IL_02a9:
														break;
													}
													continue;
												}
												goto IL_06f8;
												IL_06f8:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0660:
												break;
											}
											continue;
											end_IL_0673:
											break;
										}
										continue;
										end_IL_067d:
										break;
									}
									continue;
									end_IL_0688:
									break;
								}
								continue;
								end_IL_069d:
								break;
							}
							continue;
							end_IL_06ad:
							break;
						}
						continue;
						end_IL_06bd:
						break;
					}
					continue;
					end_IL_06cd:
					break;
				}
				continue;
				end_IL_06dd:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 45;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setAssemblyNameOnDeserialized.getCheckExecutionRightsE);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 86;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0235:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0215:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0208:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_01fb:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01e8:
																										if (3 < b)
																										{
																											num = 110;
																											while (true)
																											{
																												if (num != 110)
																												{
																													if (num != 1091)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 19:
																														goto IL_01e8;
																													case 43:
																													case 89:
																														goto IL_01fb;
																													case 17:
																														goto IL_0208;
																													case 70:
																														goto IL_0215;
																													case 56:
																														goto end_IL_0215;
																													case 99:
																														goto IL_0235;
																													case 39:
																														goto end_IL_0235;
																													case 34:
																													case 83:
																														goto end_IL_0245;
																													case 15:
																														goto IL_0260;
																													case 16:
																														goto IL_026e;
																													case 21:
																													case 30:
																														goto IL_027e;
																													case 40:
																														goto IL_0291;
																													case 38:
																													case 58:
																														goto IL_029f;
																													case 9:
																														goto IL_02b8;
																													case 59:
																														goto IL_02c8;
																													case 57:
																													case 61:
																														goto IL_02d6;
																													case 62:
																														goto IL_02ee;
																													case 51:
																														goto IL_02fc;
																													case 95:
																														goto IL_0318;
																													case 32:
																														goto IL_033b;
																													case 28:
																														goto IL_0345;
																													case 88:
																														goto IL_0353;
																													case 2:
																													case 100:
																														goto IL_0366;
																													case 1:
																														goto IL_038f;
																													case 18:
																														goto IL_039d;
																													case 84:
																														goto IL_03b0;
																													case 46:
																														goto IL_03be;
																													case 33:
																														goto end_IL_01d5;
																													case 53:
																														goto IL_03df;
																													case 36:
																														goto IL_03ed;
																													case 35:
																													case 80:
																														goto IL_03f8;
																													case 103:
																														goto IL_0406;
																													case 5:
																													case 23:
																														goto IL_0414;
																													case 47:
																														goto IL_0437;
																													case 90:
																														goto IL_0445;
																													case 4:
																														goto IL_0453;
																													case 24:
																														goto IL_0466;
																													case 25:
																													case 87:
																														goto IL_0474;
																													case 44:
																														goto IL_04b4;
																													case 60:
																														goto IL_04c8;
																													case 37:
																													case 64:
																														goto IL_04db;
																													case 72:
																														goto IL_053d;
																													case 65:
																														goto IL_054d;
																													case 31:
																														goto IL_0558;
																													case 82:
																														goto IL_0563;
																													case 11:
																														goto IL_0570;
																													case 50:
																													case 69:
																														goto IL_057b;
																													case 0:
																													case 7:
																													case 10:
																													case 12:
																													case 13:
																													case 14:
																													case 41:
																													case 42:
																													case 54:
																													case 55:
																													case 63:
																													case 73:
																													case 75:
																													case 76:
																													case 79:
																													case 85:
																													case 93:
																													case 96:
																													case 98:
																													case 101:
																														goto end_IL_0225;
																													case 6:
																													case 20:
																													case 22:
																													case 26:
																													case 29:
																													case 66:
																													case 68:
																													case 74:
																													case 78:
																													case 81:
																													case 86:
																													case 94:
																														goto end_IL_0255;
																													case 71:
																														goto end_IL_05a7;
																													case 52:
																														goto end_IL_05ba;
																													case 67:
																														goto end_IL_05c5;
																													case 45:
																														goto end_IL_05cf;
																													case 3:
																														goto end_IL_05da;
																													case 27:
																													case 102:
																														goto end_IL_05ef;
																													case 77:
																														goto end_IL_0608;
																													case 8:
																													case 92:
																														goto end_IL_0618;
																													case 48:
																														goto end_IL_0628;
																													case 49:
																														goto end_IL_0638;
																													case 91:
																													case 97:
																														goto IL_0653;
																													}
																													continue;
																												}
																												goto IL_03b0;
																												IL_03b0:
																												if (4 < b)
																												{
																													goto end_IL_0225;
																												}
																												goto IL_03be;
																												IL_03be:
																												if (4 > b)
																												{
																													goto end_IL_0225;
																												}
																												goto end_IL_0255;
																												continue;
																												end_IL_01d5:
																												break;
																											}
																											break;
																										}
																										goto IL_02c8;
																										IL_02c8:
																										if (3 > b)
																										{
																											goto end_IL_0225;
																										}
																										goto IL_02d6;
																										IL_02d6:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0255;
																									}
																									break;
																								}
																								goto IL_0260;
																								IL_039d:
																								num5--;
																								goto end_IL_0255;
																								IL_0260:
																								if (2 > b)
																								{
																									goto IL_026e;
																								}
																								goto IL_0366;
																								IL_026e:
																								if (1 < b)
																								{
																									goto end_IL_0225;
																								}
																								goto IL_0291;
																								IL_0291:
																								if (1 > b)
																								{
																									goto end_IL_0225;
																								}
																								goto IL_029f;
																								IL_029f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02b8;
																								IL_02b8:
																								array[num5] = 0;
																								goto IL_02ee;
																								IL_02ee:
																								num5++;
																								goto IL_02fc;
																								IL_02fc:
																								ptr2 += 8;
																								num = 6;
																								goto end_IL_0255;
																								IL_0366:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_038f;
																								IL_038f:
																								ptr2 += 8;
																								goto IL_039d;
																							}
																							break;
																						}
																						goto IL_027e;
																						IL_0353:
																						ptr2 += 8;
																						goto end_IL_0255;
																						IL_027e:
																						array[num5] = 0;
																						goto IL_0318;
																						IL_0318:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_033b;
																						IL_033b:
																						array2[num5] = null;
																						goto IL_0345;
																						IL_0345:
																						num5++;
																						goto IL_0353;
																					}
																				}
																				if (8 >= b)
																				{
																					goto IL_03df;
																				}
																				goto IL_054d;
																				IL_057b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0255;
																				IL_0570:
																				if (9 > b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_057b;
																				IL_03df:
																				if (8 > b)
																				{
																					goto IL_03ed;
																				}
																				goto IL_04db;
																				IL_03ed:
																				if (6 < b)
																				{
																					goto IL_03f8;
																				}
																				goto IL_0466;
																				IL_03f8:
																				if (7 < b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_0406;
																				IL_0406:
																				if (7 > b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_0414;
																				IL_0414:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0437;
																				IL_0437:
																				array[num5] = 0;
																				goto IL_0445;
																				IL_0445:
																				num5++;
																				goto IL_0453;
																				IL_0453:
																				ptr2 += 8;
																				goto end_IL_0255;
																				IL_0466:
																				if (6 > b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_0474;
																				IL_0474:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b4;
																				IL_04b4:
																				array[num5 - 2] = 0;
																				goto IL_04c8;
																				IL_04c8:
																				num5--;
																				goto end_IL_0255;
																				IL_04db:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_053d;
																				IL_053d:
																				num5 -= 2;
																				goto end_IL_0255;
																				IL_054d:
																				if (9 < b)
																				{
																					goto IL_0558;
																				}
																				goto IL_0570;
																				IL_0558:
																				if (10 < b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_0563;
																				IL_0563:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0225;
																				continue;
																				end_IL_0215:
																				break;
																			}
																			continue;
																			end_IL_0225:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0255;
																	continue;
																	end_IL_0235:
																	break;
																}
																continue;
																end_IL_0245:
																break;
															}
															continue;
															end_IL_0255:
															break;
														}
														continue;
													}
													goto IL_0653;
													IL_0653:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05a7:
													break;
												}
												continue;
												end_IL_05ba:
												break;
											}
											continue;
											end_IL_05c5:
											break;
										}
										continue;
										end_IL_05cf:
										break;
									}
									continue;
									end_IL_05da:
									break;
								}
								continue;
								end_IL_05ef:
								break;
							}
							continue;
							end_IL_0608:
							break;
						}
						continue;
						end_IL_0618:
						break;
					}
					continue;
					end_IL_0628:
					break;
				}
				continue;
				end_IL_0638:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 36;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 18;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 53;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										num = 52;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReflectionPermissionFlagVTBLOB.StoreAssemblyEnumerationgetMemberAccess);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 110;
													while (true)
													{
														if (num == 110)
														{
															goto IL_029a;
														}
														if (num != 1091)
														{
															goto IL_049d;
														}
														switch (num)
														{
														case 89:
															goto end_IL_01c7;
														case 101:
															goto end_IL_01da;
														case 52:
															goto end_IL_01e5;
														case 48:
															goto end_IL_01ef;
														case 53:
															goto end_IL_01fa;
														case 34:
															goto end_IL_0218;
														case 18:
														case 46:
															goto end_IL_022d;
														case 55:
															goto end_IL_0246;
														case 51:
														case 90:
															goto end_IL_0256;
														case 35:
															goto end_IL_026f;
														case 36:
															goto end_IL_027f;
														case 4:
														case 5:
														case 11:
														case 38:
														case 47:
														case 56:
														case 73:
														case 86:
														case 97:
															goto IL_029a;
														case 42:
														case 99:
															goto IL_02aa;
														case 76:
															goto IL_02b3;
														case 30:
															goto IL_02c1;
														case 102:
															goto IL_02cf;
														case 62:
															goto IL_02dd;
														case 49:
															goto IL_02eb;
														case 2:
														case 72:
															goto IL_02f6;
														case 66:
															goto IL_0304;
														case 28:
															goto IL_0327;
														case 44:
															goto IL_0331;
														case 98:
															goto IL_033f;
														case 67:
															goto IL_0352;
														case 45:
															goto IL_0360;
														case 7:
														case 33:
															goto IL_036b;
														case 71:
															goto IL_0379;
														case 83:
														case 96:
															goto IL_038c;
														case 57:
															goto IL_03cc;
														case 81:
															goto IL_03e0;
														case 91:
															goto IL_03f3;
														case 70:
														case 85:
															goto IL_0401;
														case 60:
															goto IL_040f;
														case 3:
														case 77:
															goto IL_041a;
														case 64:
															goto IL_045a;
														case 22:
															goto IL_046e;
														case 43:
															goto IL_048f;
														case 14:
														case 23:
															goto IL_049d;
														case 39:
															goto IL_04cf;
														case 15:
															goto IL_04dd;
														case 16:
															goto IL_04f0;
														case 59:
															goto IL_04fe;
														case 95:
															goto IL_0509;
														case 41:
														case 87:
															goto IL_0517;
														case 27:
															goto IL_0557;
														case 0:
															goto IL_056b;
														case 26:
															goto IL_057e;
														case 84:
															goto IL_058c;
														case 37:
														case 79:
															goto IL_059a;
														case 21:
															goto IL_05b6;
														case 10:
														case 74:
															goto IL_05c1;
														case 93:
															goto IL_05da;
														case 6:
															goto IL_05e8;
														case 1:
															goto IL_05f6;
														case 9:
														case 25:
															goto IL_0612;
														case 32:
															goto IL_0620;
														case 65:
														case 68:
															goto IL_062e;
														case 80:
															goto IL_066e;
														case 19:
															goto IL_0682;
														case 24:
															goto IL_0695;
														case 20:
															goto IL_06a3;
														case 69:
															goto IL_06b1;
														case 8:
														case 12:
														case 13:
														case 29:
														case 31:
														case 40:
														case 50:
														case 54:
														case 58:
														case 61:
														case 63:
														case 75:
														case 78:
														case 88:
														case 92:
														case 94:
														case 100:
														case 103:
															goto IL_06c4;
														case 17:
														case 82:
															goto IL_06f2;
														}
														continue;
														IL_0682:
														num4--;
														goto IL_029a;
														IL_06c4:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0695;
														IL_029a:
														if (num5 != 1)
														{
															goto IL_02aa;
														}
														num = 17;
														goto IL_06f2;
														IL_0695:
														array[num4] = 0;
														goto IL_06a3;
														IL_06f2:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														IL_02aa:
														b = *ptr2;
														goto IL_02b3;
														IL_02b3:
														ptr2++;
														goto IL_02c1;
														IL_02c1:
														if (b >= 1)
														{
															goto IL_02cf;
														}
														goto IL_06c4;
														IL_02cf:
														if (b <= 9)
														{
															goto IL_02dd;
														}
														goto IL_06c4;
														IL_02dd:
														if (5 >= b)
														{
															goto IL_02eb;
														}
														goto IL_04f0;
														IL_02eb:
														if (5 <= b)
														{
															goto IL_02f6;
														}
														goto IL_0352;
														IL_02f6:
														array[num4] = 0;
														goto IL_0304;
														IL_0304:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0327;
														IL_0327:
														array2[num4] = null;
														goto IL_0331;
														IL_0331:
														num4++;
														goto IL_033f;
														IL_033f:
														ptr2 += 8;
														goto IL_029a;
														IL_0352:
														if (2 >= b)
														{
															goto IL_0360;
														}
														goto IL_03f3;
														IL_0360:
														if (2 > b)
														{
															goto IL_036b;
														}
														goto IL_038c;
														IL_036b:
														if (1 >= b)
														{
															goto IL_0379;
														}
														goto IL_06c4;
														IL_0379:
														if (1 > b)
														{
														}
														goto IL_06c4;
														IL_038c:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_03cc;
														IL_03cc:
														array[num4 - 2] = 0;
														goto IL_03e0;
														IL_03e0:
														num4--;
														goto IL_029a;
														IL_03f3:
														if (3 < b)
														{
															goto IL_0401;
														}
														goto IL_048f;
														IL_0401:
														if (4 >= b)
														{
															goto IL_040f;
														}
														goto IL_06c4;
														IL_040f:
														if (4 <= b)
														{
															goto IL_041a;
														}
														num = 88;
														goto IL_06c4;
														IL_041a:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_045a;
														IL_045a:
														array[num4 - 2] = 0;
														goto IL_046e;
														IL_046e:
														num4--;
														goto IL_029a;
														IL_06a3:
														num4++;
														goto IL_06b1;
														IL_048f:
														if (3 <= b)
														{
															goto IL_049d;
														}
														goto IL_06c4;
														IL_049d:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														num = 39;
														goto IL_04cf;
														IL_04cf:
														ptr2 += 8;
														goto IL_04dd;
														IL_04dd:
														num4--;
														goto IL_029a;
														IL_04f0:
														if (7 < b)
														{
															goto IL_04fe;
														}
														goto IL_05b6;
														IL_04fe:
														if (8 >= b)
														{
															goto IL_0509;
														}
														goto IL_057e;
														IL_0509:
														if (8 <= b)
														{
															goto IL_0517;
														}
														goto IL_06c4;
														IL_0517:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_0557;
														IL_0557:
														array[num4 - 2] = 0;
														goto IL_056b;
														IL_056b:
														num4--;
														goto IL_029a;
														IL_057e:
														if (9 >= b)
														{
															goto IL_058c;
														}
														goto IL_06c4;
														IL_058c:
														if (9 <= b)
														{
															goto IL_059a;
														}
														goto IL_06c4;
														IL_059a:
														byte* num6 = ptr2;
														num5 = 1;
														ptr2 = num6 + -200;
														goto IL_029a;
														IL_05b6:
														if (7 <= b)
														{
															goto IL_05c1;
														}
														num = 9;
														goto IL_0612;
														IL_05c1:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
														goto IL_05da;
														IL_05da:
														array[num4] = 0;
														goto IL_05e8;
														IL_05e8:
														num4++;
														goto IL_05f6;
														IL_05f6:
														ptr2 += 8;
														goto IL_029a;
														IL_06b1:
														ptr2 += 8;
														goto IL_029a;
														IL_0612:
														if (6 >= b)
														{
															goto IL_0620;
														}
														goto IL_06c4;
														IL_0620:
														if (6 <= b)
														{
															goto IL_062e;
														}
														goto IL_06c4;
														IL_062e:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
														goto IL_066e;
														IL_066e:
														array[num4 - 2] = 0;
														goto IL_0682;
														continue;
														end_IL_01c7:
														break;
													}
													continue;
													end_IL_01da:
													break;
												}
												continue;
												end_IL_01e5:
												break;
											}
											continue;
											end_IL_01ef:
											break;
										}
										continue;
										end_IL_01fa:
										break;
									}
									continue;
									end_IL_0218:
									break;
								}
								continue;
								end_IL_022d:
								break;
							}
							continue;
							end_IL_0246:
							break;
						}
						continue;
						end_IL_0256:
						break;
					}
					continue;
					end_IL_026f:
					break;
				}
				continue;
				end_IL_027f:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 14;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 85;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EncoderNLSPow.getDisallowApplicationBaseProbingreplicasAreQuitting);
												num = 70;
												while (true)
												{
													byte* ptr2 = ptr;
													num = 32;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 94;
																while (true)
																{
																	if (num != 94)
																	{
																		if (num != 1075)
																		{
																			goto IL_0482;
																		}
																		switch (num)
																		{
																		case 4:
																			goto end_IL_0187;
																		case 64:
																			goto IL_01ab;
																		case 77:
																			goto IL_01b9;
																		case 83:
																			goto IL_01c7;
																		case 62:
																			goto IL_01d5;
																		case 25:
																			goto IL_01e3;
																		case 54:
																		case 59:
																			goto IL_01f1;
																		case 21:
																			goto IL_01ff;
																		case 47:
																			goto IL_020d;
																		case 40:
																		case 84:
																			goto IL_0224;
																		case 17:
																			goto IL_0264;
																		case 23:
																			goto IL_0278;
																		case 74:
																			goto IL_028b;
																		case 8:
																		case 55:
																			goto IL_0296;
																		case 34:
																			goto IL_02a4;
																		case 30:
																		case 37:
																			goto IL_02b7;
																		case 1:
																			goto IL_0325;
																		case 61:
																		case 68:
																			goto IL_0338;
																		case 6:
																			goto IL_0361;
																		case 35:
																			goto IL_036f;
																		case 87:
																			goto IL_0382;
																		case 19:
																		case 39:
																			goto IL_0390;
																		case 69:
																			goto IL_039b;
																		case 11:
																		case 51:
																			goto IL_03a9;
																		case 28:
																			goto IL_03b7;
																		case 58:
																			goto IL_03da;
																		case 24:
																			goto IL_03e4;
																		case 0:
																			goto IL_03f2;
																		case 16:
																			goto IL_0405;
																		case 18:
																			goto IL_0419;
																		case 33:
																		case 44:
																			goto IL_0424;
																		case 41:
																			goto IL_0440;
																		case 66:
																			goto IL_044e;
																		case 29:
																			goto IL_0459;
																		case 26:
																		case 45:
																			goto IL_0464;
																		case 9:
																		case 10:
																		case 12:
																		case 15:
																		case 22:
																		case 43:
																		case 52:
																		case 56:
																		case 57:
																		case 65:
																		case 67:
																		case 71:
																		case 75:
																		case 78:
																		case 82:
																		case 86:
																			goto IL_0482;
																		case 27:
																			goto IL_04a5;
																		case 31:
																			goto IL_04b3;
																		case 7:
																			goto IL_04c1;
																		case 32:
																		case 38:
																		case 46:
																		case 49:
																		case 53:
																		case 60:
																		case 63:
																		case 76:
																		case 79:
																		case 80:
																		case 81:
																			goto end_IL_0197;
																		case 70:
																			goto end_IL_04cf;
																		case 50:
																			goto end_IL_04e2;
																		case 20:
																			goto end_IL_04f5;
																		case 2:
																			goto end_IL_0509;
																		case 5:
																			goto end_IL_051e;
																		case 85:
																			goto end_IL_0533;
																		case 36:
																			goto end_IL_0543;
																		case 72:
																			goto end_IL_0553;
																		case 48:
																		case 73:
																			goto end_IL_055e;
																		case 13:
																			goto end_IL_056e;
																		case 14:
																			goto end_IL_057e;
																		case 3:
																		case 42:
																			goto IL_0599;
																		}
																		continue;
																	}
																	b = *ptr2;
																	goto IL_01ab;
																	IL_0464:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 63;
																	goto end_IL_0197;
																	IL_04a5:
																	array[num5] = 0;
																	goto IL_04b3;
																	IL_0482:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a5;
																	IL_01ab:
																	ptr2++;
																	goto IL_01b9;
																	IL_01b9:
																	if (b >= 1)
																	{
																		goto IL_01c7;
																	}
																	goto IL_0482;
																	IL_01c7:
																	if (b <= 8)
																	{
																		goto IL_01d5;
																	}
																	goto IL_0482;
																	IL_01d5:
																	if (4 >= b)
																	{
																		goto IL_01e3;
																	}
																	goto IL_0382;
																	IL_01e3:
																	if (4 > b)
																	{
																		goto IL_01f1;
																	}
																	goto IL_0338;
																	IL_01f1:
																	if (2 < b)
																	{
																		goto IL_01ff;
																	}
																	goto IL_028b;
																	IL_01ff:
																	if (3 >= b)
																	{
																		goto IL_020d;
																	}
																	goto IL_0482;
																	IL_020d:
																	if (3 <= b)
																	{
																		num = 84;
																		goto IL_0224;
																	}
																	goto IL_0482;
																	IL_04b3:
																	num5++;
																	goto IL_04c1;
																	IL_0224:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0264;
																	IL_0264:
																	array[num5 - 2] = 0;
																	goto IL_0278;
																	IL_0278:
																	num5--;
																	goto end_IL_0197;
																	IL_028b:
																	if (2 > b)
																	{
																		goto IL_0296;
																	}
																	goto IL_02b7;
																	IL_0296:
																	if (1 >= b)
																	{
																		goto IL_02a4;
																	}
																	goto IL_0482;
																	IL_02a4:
																	if (1 <= b)
																	{
																	}
																	goto IL_0482;
																	IL_02b7:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0325;
																	IL_0325:
																	num5 -= 2;
																	goto end_IL_0197;
																	IL_0338:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0361;
																	IL_0361:
																	ptr2 += 8;
																	goto IL_036f;
																	IL_036f:
																	num5--;
																	goto end_IL_0197;
																	IL_0382:
																	if (6 < b)
																	{
																		goto IL_0390;
																	}
																	goto IL_0440;
																	IL_0390:
																	if (7 >= b)
																	{
																		goto IL_039b;
																	}
																	goto IL_0405;
																	IL_039b:
																	if (7 <= b)
																	{
																		goto IL_03a9;
																	}
																	goto IL_0482;
																	IL_03a9:
																	array[num5] = 0;
																	goto IL_03b7;
																	IL_03b7:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_03da;
																	IL_03da:
																	array2[num5] = null;
																	goto IL_03e4;
																	IL_03e4:
																	num5++;
																	goto IL_03f2;
																	IL_03f2:
																	ptr2 += 8;
																	goto end_IL_0197;
																	IL_0405:
																	if (8 >= b)
																	{
																		num = 18;
																		goto IL_0419;
																	}
																	goto IL_0482;
																	IL_04c1:
																	ptr2 += 8;
																	goto end_IL_0197;
																	IL_0419:
																	if (8 <= b)
																	{
																		goto IL_0424;
																	}
																	goto IL_0482;
																	IL_0424:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_0197;
																	IL_0440:
																	if (6 <= b)
																	{
																		goto end_IL_0197;
																	}
																	goto IL_044e;
																	IL_044e:
																	if (5 >= b)
																	{
																		goto IL_0459;
																	}
																	goto IL_0482;
																	IL_0459:
																	if (5 <= b)
																	{
																		goto IL_0464;
																	}
																	goto IL_0482;
																	continue;
																	end_IL_0187:
																	break;
																}
																continue;
																end_IL_0197:
																break;
															}
															continue;
														}
														goto IL_0599;
														IL_0599:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04cf:
														break;
													}
													continue;
													end_IL_04e2:
													break;
												}
												continue;
												end_IL_04f5:
												break;
											}
											continue;
											end_IL_0509:
											break;
										}
										continue;
										end_IL_051e:
										break;
									}
									continue;
									end_IL_0533:
									break;
								}
								continue;
								end_IL_0543:
								break;
							}
							continue;
							end_IL_0553:
							break;
						}
						continue;
						end_IL_055e:
						break;
					}
					continue;
					end_IL_056e:
					break;
				}
				continue;
				end_IL_057e:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 136;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 46;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								num = 68;
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToFileTimegetRFCPattern.getSettingAsyncDelegate);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0294:
															byte b = *ptr2;
															while (true)
															{
																IL_0284:
																ptr2++;
																while (true)
																{
																	IL_0271:
																	if (b >= 1)
																	{
																		num = 145;
																		while (true)
																		{
																			if (num != 145)
																			{
																				if (num != 1126)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 4:
																					goto IL_0271;
																				case 93:
																					goto IL_0284;
																				case 21:
																				case 30:
																					goto IL_0294;
																				case 102:
																					goto IL_02ad;
																				case 28:
																					goto IL_02bb;
																				case 57:
																				case 121:
																					goto IL_02c9;
																				case 49:
																					goto IL_02d7;
																				case 42:
																				case 105:
																					goto IL_02eb;
																				case 128:
																					goto IL_0303;
																				case 26:
																				case 104:
																					goto IL_030e;
																				case 73:
																					goto IL_031c;
																				case 112:
																				case 137:
																					goto IL_032a;
																				case 130:
																					goto IL_035c;
																				case 133:
																					goto IL_036a;
																				case 39:
																					goto IL_037d;
																				case 37:
																				case 64:
																					goto IL_038b;
																				case 51:
																					goto IL_03a4;
																				case 96:
																					goto IL_03b2;
																				case 123:
																					goto IL_03c0;
																				case 85:
																					goto IL_03d3;
																				case 1:
																					goto IL_03e1;
																				case 72:
																				case 114:
																					goto IL_03ec;
																				case 13:
																					goto IL_03fa;
																				case 9:
																				case 65:
																					goto IL_040d;
																				case 84:
																					goto IL_041b;
																				case 124:
																					goto IL_043e;
																				case 127:
																					goto IL_0448;
																				case 71:
																					goto IL_0456;
																				case 132:
																					goto IL_0472;
																				case 82:
																					goto IL_0480;
																				case 15:
																				case 74:
																					goto IL_048e;
																				case 31:
																					goto IL_04ce;
																				case 122:
																					goto IL_04e2;
																				case 78:
																				case 79:
																					goto IL_04f5;
																				case 103:
																					goto IL_0535;
																				case 17:
																					goto IL_0552;
																				case 89:
																					goto IL_0565;
																				case 52:
																					goto IL_0573;
																				case 48:
																				case 95:
																					goto IL_0581;
																				case 61:
																					goto IL_0595;
																				case 88:
																					goto IL_05e9;
																				case 3:
																					goto IL_05f7;
																				case 8:
																					goto IL_060a;
																				case 14:
																				case 118:
																					goto IL_0618;
																				case 87:
																					goto IL_0626;
																				case 22:
																				case 91:
																					goto IL_0634;
																				case 6:
																					goto IL_0674;
																				case 19:
																					goto IL_0688;
																				case 119:
																					goto IL_069b;
																				case 32:
																				case 83:
																					goto IL_06a6;
																				case 63:
																					goto IL_0708;
																				case 5:
																				case 108:
																					goto IL_071b;
																				case 54:
																					goto IL_0729;
																				case 2:
																				case 100:
																					goto IL_0737;
																				case 107:
																					goto IL_075a;
																				case 129:
																					goto IL_0771;
																				case 47:
																					goto IL_077f;
																				case 50:
																				case 53:
																					goto IL_0792;
																				case 60:
																					goto IL_079d;
																				case 45:
																				case 70:
																					goto IL_07a8;
																				case 109:
																				case 120:
																					goto IL_07ca;
																				case 16:
																					goto IL_07d5;
																				case 18:
																				case 34:
																					goto IL_07e0;
																				case 27:
																				case 98:
																					goto IL_07f9;
																				case 113:
																					goto IL_0804;
																				case 0:
																				case 20:
																				case 24:
																				case 33:
																				case 35:
																				case 43:
																				case 56:
																				case 62:
																				case 67:
																				case 75:
																				case 76:
																				case 77:
																				case 80:
																				case 92:
																				case 94:
																				case 97:
																				case 101:
																				case 111:
																				case 115:
																				case 116:
																				case 126:
																				case 131:
																				case 138:
																					goto IL_080f;
																				case 10:
																				case 12:
																				case 25:
																				case 29:
																				case 40:
																				case 41:
																				case 44:
																				case 55:
																				case 58:
																				case 66:
																				case 69:
																				case 90:
																				case 99:
																				case 110:
																				case 117:
																				case 125:
																				case 134:
																					goto end_IL_0261;
																				case 106:
																					goto end_IL_082b;
																				case 38:
																					goto end_IL_083e;
																				case 59:
																					goto end_IL_0848;
																				case 68:
																					goto end_IL_0853;
																				case 36:
																				case 81:
																					goto end_IL_0868;
																				case 23:
																					goto end_IL_0878;
																				case 46:
																					goto end_IL_0891;
																				case 11:
																					goto end_IL_08a1;
																				case 135:
																					goto end_IL_08b1;
																				case 136:
																					goto end_IL_08bc;
																				case 7:
																				case 86:
																					goto IL_08d7;
																				}
																				continue;
																			}
																			if (b <= 14)
																			{
																				goto IL_02ad;
																			}
																			goto IL_080f;
																			IL_07ca:
																			if (12 >= b)
																			{
																				goto IL_07d5;
																			}
																			goto IL_080f;
																			IL_07e0:
																			num5--;
																			break;
																			IL_07d5:
																			if (12 <= b)
																			{
																				goto IL_07e0;
																			}
																			goto IL_080f;
																			IL_02ad:
																			if (7 >= b)
																			{
																				goto IL_02bb;
																			}
																			goto IL_0565;
																			IL_02bb:
																			if (7 > b)
																			{
																				goto IL_02c9;
																			}
																			goto IL_04f5;
																			IL_02c9:
																			if (3 >= b)
																			{
																				goto IL_02d7;
																			}
																			goto IL_03d3;
																			IL_02d7:
																			if (3 <= b)
																			{
																				num = 105;
																				goto IL_02eb;
																			}
																			goto IL_0303;
																			IL_07f9:
																			if (14 >= b)
																			{
																				goto IL_0804;
																			}
																			goto IL_080f;
																			IL_02eb:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0303:
																			if (1 < b)
																			{
																				goto IL_030e;
																			}
																			goto IL_037d;
																			IL_030e:
																			if (2 >= b)
																			{
																				goto IL_031c;
																			}
																			goto IL_080f;
																			IL_031c:
																			if (2 <= b)
																			{
																				goto IL_032a;
																			}
																			goto IL_080f;
																			IL_032a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 130;
																			goto IL_035c;
																			IL_035c:
																			ptr2 += 8;
																			goto IL_036a;
																			IL_036a:
																			num5--;
																			break;
																			IL_037d:
																			if (1 <= b)
																			{
																				goto IL_038b;
																			}
																			goto IL_080f;
																			IL_038b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_03a4;
																			IL_03a4:
																			array[num5] = 0;
																			goto IL_03b2;
																			IL_03b2:
																			num5++;
																			goto IL_03c0;
																			IL_03c0:
																			ptr2 += 8;
																			break;
																			IL_03d3:
																			if (5 >= b)
																			{
																				goto IL_03e1;
																			}
																			goto IL_0472;
																			IL_03e1:
																			if (5 > b)
																			{
																				goto IL_03ec;
																			}
																			goto IL_040d;
																			IL_03ec:
																			if (4 >= b)
																			{
																				goto IL_03fa;
																			}
																			goto IL_080f;
																			IL_03fa:
																			if (4 <= b)
																			{
																				break;
																			}
																			goto IL_080f;
																			IL_040d:
																			array[num5] = 0;
																			goto IL_041b;
																			IL_041b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_043e;
																			IL_043e:
																			array2[num5] = null;
																			goto IL_0448;
																			IL_0448:
																			num5++;
																			goto IL_0456;
																			IL_0456:
																			ptr2 += 8;
																			num = 12;
																			break;
																			IL_0472:
																			if (6 >= b)
																			{
																				goto IL_0480;
																			}
																			goto IL_080f;
																			IL_0480:
																			if (6 <= b)
																			{
																				goto IL_048e;
																			}
																			goto IL_080f;
																			IL_048e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04ce;
																			IL_04ce:
																			array[num5 - 2] = 0;
																			goto IL_04e2;
																			IL_04e2:
																			num5--;
																			break;
																			IL_04f5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0535;
																			IL_0535:
																			array[num5 - 2] = 0;
																			num = 17;
																			goto IL_0552;
																			IL_0552:
																			num5--;
																			break;
																			IL_0565:
																			if (11 >= b)
																			{
																				goto IL_0573;
																			}
																			goto IL_0792;
																			IL_0573:
																			if (11 <= b)
																			{
																				goto IL_0581;
																			}
																			goto IL_060a;
																			IL_0581:
																			array[num5 - 2] = 0;
																			goto IL_0595;
																			IL_0595:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)EnumSubcategoriesFlagsFUiDefault[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_05e9;
																			IL_05e9:
																			num5--;
																			goto IL_05f7;
																			IL_05f7:
																			ptr2 += 8;
																			break;
																			IL_060a:
																			if (9 < b)
																			{
																				goto IL_0618;
																			}
																			goto IL_069b;
																			IL_0618:
																			if (10 >= b)
																			{
																				goto IL_0626;
																			}
																			goto IL_080f;
																			IL_0626:
																			if (10 <= b)
																			{
																				goto IL_0634;
																			}
																			goto IL_080f;
																			IL_0634:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0674;
																			IL_0674:
																			array[num5 - 2] = 0;
																			goto IL_0688;
																			IL_0688:
																			num5--;
																			break;
																			IL_069b:
																			if (9 <= b)
																			{
																				goto IL_06a6;
																			}
																			goto IL_071b;
																			IL_06a6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0708;
																			IL_0708:
																			num5 -= 2;
																			break;
																			IL_071b:
																			if (8 >= b)
																			{
																				goto IL_0729;
																			}
																			goto IL_080f;
																			IL_0729:
																			if (8 <= b)
																			{
																				goto IL_0737;
																			}
																			goto IL_080f;
																			IL_0737:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_075a;
																			IL_075a:
																			array[num5] = 0;
																			num = 129;
																			goto IL_0771;
																			IL_0771:
																			num5++;
																			goto IL_077f;
																			IL_077f:
																			ptr2 += 8;
																			break;
																			IL_0792:
																			if (13 >= b)
																			{
																				goto IL_079d;
																			}
																			num = 98;
																			goto IL_07f9;
																			IL_079d:
																			if (13 <= b)
																			{
																				goto IL_07a8;
																			}
																			num = 120;
																			goto IL_07ca;
																			IL_07a8:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0804:
																			if (14 > b)
																			{
																			}
																			goto IL_080f;
																			continue;
																			end_IL_0261:
																			break;
																		}
																		break;
																	}
																	goto IL_080f;
																	IL_080f:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 58;
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_08d7;
													IL_08d7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_082b:
													break;
												}
												continue;
												end_IL_083e:
												break;
											}
											continue;
											end_IL_0848:
											break;
										}
										continue;
										end_IL_0853:
										break;
									}
									continue;
									end_IL_0868:
									break;
								}
								continue;
								end_IL_0878:
								break;
							}
							continue;
							end_IL_0891:
							break;
						}
						continue;
						end_IL_08a1:
						break;
					}
					continue;
					end_IL_08b1:
					break;
				}
				continue;
				end_IL_08bc:
				break;
			}
		}
	}

	private static int smethod_6()
	{
		int num = 15;
		int num2 = 3;
		num = 5;
		object obj = new int[5];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 396;
		num3 = 36;
		((int[])obj)[0] = 36;
		obj = obj2;
		num2 = 1;
		num3 = 1;
		((int[])obj)[1] = 1;
		obj = obj2;
		num2 = 8;
		num3 = 4;
		num2 = 2;
		num3 = 121;
		num3 = 11;
		((int[])obj)[2] = 11;
		obj = obj2;
		num2 = 33;
		num3 = 11;
		num2 = 3;
		num3 = 168;
		num3 = 42;
		((int[])obj)[3] = 42;
		obj = obj2;
		num2 = 8;
		num3 = 2;
		num2 = 4;
		num3 = 155;
		num3 = 31;
		((int[])obj)[4] = 31;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 25;
			num3 = 5;
			num2 = 5;
			if (num >= 5)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_7()
	{
		int num = 139;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 6;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ElementCountgetUseStdAsciiRules.EntryPointDefineGlobalMethod);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0357:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_0347:
																			if (b <= 15)
																			{
																				while (true)
																				{
																					IL_0337:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0327:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0317:
																									if (4 >= b)
																									{
																										while (true)
																										{
																											IL_0307:
																											if (4 > b)
																											{
																												while (true)
																												{
																													IL_02f7:
																													if (2 >= b)
																													{
																														while (true)
																														{
																															IL_02e7:
																															if (2 > b)
																															{
																																while (1 >= b)
																																{
																																	while (1 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_02a3:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																			num = 20;
																																			while (true)
																																			{
																																				IL_028a:
																																				array[num5] = 0;
																																				num = 154;
																																				while (true)
																																				{
																																					if (num != 154)
																																					{
																																						if (num != 1135)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 20:
																																							goto IL_028a;
																																						case 58:
																																						case 128:
																																							goto IL_02a3;
																																						case 82:
																																							goto IL_02c7;
																																						case 54:
																																						case 140:
																																							goto IL_02d7;
																																						case 146:
																																							goto IL_02e7;
																																						case 24:
																																						case 100:
																																							goto IL_02f7;
																																						case 45:
																																							goto IL_0307;
																																						case 29:
																																							goto IL_0317;
																																						case 134:
																																							goto IL_0327;
																																						case 36:
																																							goto IL_0337;
																																						case 23:
																																							goto IL_0347;
																																						case 94:
																																							goto IL_0357;
																																						case 126:
																																							goto end_IL_0357;
																																						case 55:
																																						case 130:
																																							goto end_IL_0367;
																																						case 53:
																																						case 104:
																																							goto IL_0382;
																																						case 60:
																																							goto IL_03c2;
																																						case 15:
																																							goto IL_03d6;
																																						case 87:
																																						case 109:
																																							goto IL_03e9;
																																						case 123:
																																						case 127:
																																							goto IL_0401;
																																						case 65:
																																							goto IL_040f;
																																						case 32:
																																							goto IL_041d;
																																						case 30:
																																							goto IL_042b;
																																						case 98:
																																						case 99:
																																							goto IL_0436;
																																						case 39:
																																							goto IL_0444;
																																						case 56:
																																							goto IL_0467;
																																						case 5:
																																							goto IL_0471;
																																						case 74:
																																							goto IL_047f;
																																						case 68:
																																							goto IL_0492;
																																						case 57:
																																							goto IL_04a0;
																																						case 18:
																																						case 86:
																																							goto IL_04c5;
																																						case 117:
																																							goto IL_0507;
																																						case 0:
																																							goto IL_0512;
																																						case 89:
																																						case 92:
																																							goto IL_051d;
																																						case 26:
																																						case 38:
																																							goto IL_052d;
																																						case 17:
																																						case 47:
																																							goto IL_0549;
																																						case 105:
																																							goto IL_0557;
																																						case 131:
																																							goto IL_056a;
																																						case 91:
																																							goto IL_057e;
																																						case 136:
																																							goto IL_0591;
																																						case 4:
																																						case 19:
																																							goto IL_059f;
																																						case 79:
																																							goto IL_0601;
																																						case 50:
																																						case 144:
																																							goto IL_0614;
																																						case 13:
																																						case 48:
																																							goto IL_061f;
																																						case 120:
																																							goto IL_062d;
																																						case 52:
																																						case 78:
																																							goto IL_063b;
																																						case 119:
																																							goto IL_0664;
																																						case 110:
																																							goto IL_0672;
																																						case 51:
																																							goto IL_0685;
																																						case 70:
																																							goto IL_0690;
																																						case 143:
																																							goto IL_069e;
																																						case 22:
																																						case 137:
																																							goto IL_06ac;
																																						case 27:
																																							goto IL_06ba;
																																						case 44:
																																							goto IL_06d2;
																																						case 8:
																																							goto IL_06e0;
																																						case 40:
																																						case 85:
																																							goto IL_06f3;
																																						case 145:
																																							goto IL_0732;
																																						case 147:
																																							goto IL_0745;
																																						case 31:
																																							goto IL_0753;
																																						case 2:
																																						case 14:
																																							goto IL_0761;
																																						case 43:
																																							goto IL_07a5;
																																						case 16:
																																							goto IL_07b9;
																																						case 116:
																																							goto IL_07da;
																																						case 81:
																																							goto IL_07ed;
																																						case 35:
																																							goto IL_07fb;
																																						case 75:
																																						case 102:
																																							goto IL_0809;
																																						case 106:
																																							goto end_IL_0277;
																																						case 1:
																																						case 88:
																																							goto IL_0848;
																																						case 64:
																																							goto IL_0866;
																																						case 115:
																																							goto IL_0874;
																																						case 10:
																																						case 28:
																																						case 33:
																																						case 41:
																																						case 42:
																																						case 46:
																																						case 49:
																																						case 59:
																																						case 61:
																																						case 73:
																																						case 76:
																																						case 77:
																																						case 95:
																																						case 97:
																																						case 101:
																																						case 103:
																																						case 112:
																																						case 113:
																																						case 118:
																																						case 121:
																																						case 122:
																																						case 129:
																																						case 132:
																																						case 133:
																																						case 135:
																																						case 141:
																																						case 142:
																																							goto end_IL_02c7;
																																						case 3:
																																						case 7:
																																						case 12:
																																						case 21:
																																						case 34:
																																						case 37:
																																						case 67:
																																						case 69:
																																						case 71:
																																						case 80:
																																						case 90:
																																						case 93:
																																						case 96:
																																						case 107:
																																						case 108:
																																						case 111:
																																						case 114:
																																						case 125:
																																							goto end_IL_0377;
																																						case 83:
																																							goto end_IL_08a0;
																																						case 25:
																																							goto end_IL_08b3;
																																						case 72:
																																							goto end_IL_08bd;
																																						case 66:
																																							goto end_IL_08c8;
																																						case 6:
																																							goto end_IL_08d8;
																																						case 124:
																																							goto end_IL_08e8;
																																						case 9:
																																							goto end_IL_08f8;
																																						case 11:
																																						case 63:
																																							goto end_IL_0903;
																																						case 138:
																																							goto end_IL_0913;
																																						case 139:
																																							goto end_IL_0923;
																																						case 62:
																																						case 84:
																																							goto IL_093e;
																																						}
																																						continue;
																																					}
																																					num5++;
																																					goto IL_07da;
																																					IL_07da:
																																					ptr2 += 8;
																																					goto end_IL_0377;
																																					continue;
																																					end_IL_0277:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_0832;
																																		continue;
																																		end_IL_02c7:
																																		break;
																																		IL_02c7:;
																																	}
																																	break;
																																	IL_02d7:;
																																}
																																break;
																															}
																															goto IL_0382;
																															IL_03d6:
																															num5--;
																															goto end_IL_0377;
																															IL_0382:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_03c2;
																															IL_03c2:
																															array[num5 - 2] = 0;
																															goto IL_03d6;
																														}
																														break;
																													}
																													goto IL_07ed;
																													IL_0832:
																													array[num5 - 1] = 5;
																													goto end_IL_0377;
																													IL_07ed:
																													if (3 < b)
																													{
																														break;
																													}
																													goto IL_07fb;
																													IL_07fb:
																													if (3 > b)
																													{
																														break;
																													}
																													goto IL_0809;
																													IL_0809:
																													array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													goto IL_0832;
																												}
																												break;
																											}
																											goto IL_0848;
																											IL_0874:
																											num5--;
																											goto end_IL_0377;
																											IL_0848:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_0866;
																											IL_0866:
																											ptr2 += 8;
																											goto IL_0874;
																										}
																										break;
																									}
																									goto IL_0614;
																									IL_0732:
																									num5 -= 3;
																									goto end_IL_0377;
																									IL_0614:
																									if (6 < b)
																									{
																										goto IL_061f;
																									}
																									goto IL_0685;
																									IL_061f:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_062d;
																									IL_062d:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_063b;
																									IL_063b:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0664;
																									IL_0664:
																									ptr2 += 8;
																									goto IL_0672;
																									IL_0672:
																									num5--;
																									goto end_IL_0377;
																									IL_0685:
																									if (6 > b)
																									{
																										goto IL_0690;
																									}
																									goto IL_06f3;
																									IL_0690:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_069e;
																									IL_069e:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_06ac;
																									IL_06ac:
																									array[num5] = 5;
																									goto IL_06ba;
																									IL_06ba:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_06d2;
																									IL_06d2:
																									num5++;
																									goto IL_06e0;
																									IL_06e0:
																									ptr2 += 8;
																									goto end_IL_0377;
																									IL_06f3:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0732;
																								}
																								break;
																							}
																							goto IL_03e9;
																							IL_03e9:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0377;
																						}
																						break;
																					}
																					goto IL_0401;
																					IL_052d:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0377;
																					IL_0401:
																					if (12 >= b)
																					{
																						goto IL_040f;
																					}
																					goto IL_0507;
																					IL_040f:
																					if (12 > b)
																					{
																						goto IL_041d;
																					}
																					num = 86;
																					goto IL_04c5;
																					IL_041d:
																					if (10 >= b)
																					{
																						goto IL_042b;
																					}
																					goto IL_0745;
																					IL_042b:
																					if (10 <= b)
																					{
																						goto IL_0436;
																					}
																					goto IL_0492;
																					IL_0436:
																					array[num5] = 0;
																					goto IL_0444;
																					IL_0444:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0467;
																					IL_0467:
																					array2[num5] = null;
																					goto IL_0471;
																					IL_0471:
																					num5++;
																					goto IL_047f;
																					IL_047f:
																					ptr2 += 8;
																					goto end_IL_0377;
																					IL_0492:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_04a0;
																					IL_04a0:
																					if (9 > b)
																					{
																						break;
																					}
																					num = 37;
																					goto end_IL_0377;
																					IL_0557:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_0745:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0753;
																					IL_0753:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0761;
																					IL_0761:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_07a5;
																					IL_07a5:
																					array[num5 - 2] = 0;
																					goto IL_07b9;
																					IL_07b9:
																					num5--;
																					goto end_IL_0377;
																					IL_0549:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0557;
																					IL_04c5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_056a;
																					IL_056a:
																					array[num5 - 2] = 0;
																					goto IL_057e;
																					IL_057e:
																					num5--;
																					goto end_IL_0377;
																					IL_0507:
																					if (14 >= b)
																					{
																						goto IL_0512;
																					}
																					goto IL_0549;
																					IL_0512:
																					if (14 > b)
																					{
																						goto IL_051d;
																					}
																					goto IL_052d;
																					IL_051d:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0591;
																					IL_0591:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_059f;
																					IL_059f:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0601;
																					IL_0601:
																					num5 -= 2;
																					goto end_IL_0377;
																				}
																			}
																			else
																			{
																				num = 95;
																			}
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0377;
																	continue;
																	end_IL_0357:
																	break;
																}
																continue;
																end_IL_0367:
																break;
															}
															continue;
															end_IL_0377:
															break;
														}
														continue;
													}
													goto IL_093e;
													IL_093e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a0:
													break;
												}
												continue;
												end_IL_08b3:
												break;
											}
											continue;
											end_IL_08bd:
											break;
										}
										continue;
										end_IL_08c8:
										break;
									}
									continue;
									end_IL_08d8:
									break;
								}
								continue;
								end_IL_08e8:
								break;
							}
							continue;
							end_IL_08f8:
							break;
						}
						continue;
						end_IL_0903:
						break;
					}
					continue;
					end_IL_0913:
					break;
				}
				continue;
				end_IL_0923:
				break;
			}
		}
	}

	static Class178()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 2;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 4:
							case 7:
								goto end_IL_0041;
							case 2:
								goto end_IL_004e;
							case 3:
								goto end_IL_005d;
							case 0:
								return;
							case 1:
								return;
							case 5:
								return;
							case 6:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0041:
						break;
					}
					continue;
					end_IL_004e:
					break;
				}
				continue;
				end_IL_005d:
				break;
			}
		}
	}

	private static void smethod_8(Class178 class178_1)
	{
		class178_1.method_1();
	}
}
