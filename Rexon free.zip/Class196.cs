using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Rapid Hand Taps", "Rig", "Removes hand tap cooldown.", false, 41, ModType.const_0, false)]
internal class Class196 : MonoBehaviour
{
	private static float float_0;

	private static bool bool_0;

	private static float float_1;

	private static int int_0;

	private static bool bool_1;

	private static IntPtr[] DirectoryExistsgetIsHomogenous;

	private static IntPtr[] StartProfilegetStackBehaviourPush;

	private static IntPtr[] CovariantPARAMFLAGFOUT;

	private static IntPtr[] StackOverflowExceptionCFB;

	private unsafe void Update()
	{
		int num = 180;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 137;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IDisposableToIClosableAdapterTrustedComputingBase.getHostDllTokenRestrictedSids);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_04b9:
															if (b >= 1)
															{
																while (b <= 29)
																{
																	while (true)
																	{
																		IL_0499:
																		if (15 >= b)
																		{
																			while (true)
																			{
																				IL_048c:
																				if (15 > b)
																				{
																					while (true)
																					{
																						IL_0479:
																						if (7 >= b)
																						{
																							num = 211;
																							while (true)
																							{
																								IL_0469:
																								if (7 > b)
																								{
																									while (true)
																									{
																										IL_0459:
																										if (3 >= b)
																										{
																											while (true)
																											{
																												IL_0449:
																												if (3 > b)
																												{
																													while (true)
																													{
																														IL_0439:
																														if (1 < b)
																														{
																															while (2 >= b)
																															{
																																num = 250;
																																while (true)
																																{
																																	if (num != 250)
																																	{
																																		if (num != 1231)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 83:
																																			goto IL_0426;
																																		case 26:
																																			goto IL_0439;
																																		case 232:
																																			goto IL_0449;
																																		case 88:
																																			goto IL_0459;
																																		case 211:
																																			goto IL_0469;
																																		case 23:
																																			goto IL_0479;
																																		case 207:
																																			goto IL_048c;
																																		case 200:
																																			goto IL_0499;
																																		case 6:
																																			goto IL_04a9;
																																		case 69:
																																			goto IL_04b9;
																																		case 92:
																																			goto end_IL_04b9;
																																		case 30:
																																		case 131:
																																			goto end_IL_04c9;
																																		case 109:
																																			goto IL_04e4;
																																		case 112:
																																		case 168:
																																			goto IL_04f7;
																																		case 127:
																																			goto IL_0538;
																																		case 13:
																																			goto IL_054c;
																																		case 188:
																																			goto IL_055f;
																																		case 159:
																																			goto IL_056d;
																																		case 12:
																																			goto IL_057b;
																																		case 36:
																																		case 150:
																																			goto IL_0592;
																																		case 173:
																																			goto IL_05d2;
																																		case 49:
																																			goto IL_05e6;
																																		case 51:
																																		case 193:
																																			goto IL_0602;
																																		case 144:
																																		case 195:
																																			goto IL_0647;
																																		case 117:
																																			goto IL_0660;
																																		case 50:
																																			goto IL_0677;
																																		case 16:
																																			goto IL_0685;
																																		case 189:
																																		case 197:
																																			goto IL_0698;
																																		case 93:
																																			goto IL_06c1;
																																		case 118:
																																			goto IL_06cf;
																																		case 205:
																																			goto IL_06e2;
																																		case 126:
																																			goto IL_06f6;
																																		case 208:
																																			goto IL_0709;
																																		case 201:
																																			goto IL_0714;
																																		case 97:
																																			goto IL_072b;
																																		case 133:
																																		case 161:
																																			goto IL_0739;
																																		case 54:
																																		case 142:
																																			goto IL_0749;
																																		case 132:
																																			goto IL_0789;
																																		case 138:
																																			goto IL_07a6;
																																		case 234:
																																			goto IL_07b9;
																																		case 229:
																																			goto IL_07dc;
																																		case 225:
																																			goto IL_07e6;
																																		case 85:
																																			goto IL_07f4;
																																		case 52:
																																		case 114:
																																			goto IL_0815;
																																		case 59:
																																			goto IL_0855;
																																		case 187:
																																			goto IL_0869;
																																		case 210:
																																			goto IL_087c;
																																		case 241:
																																			goto IL_088a;
																																		case 141:
																																		case 192:
																																			goto IL_0898;
																																		case 98:
																																			goto end_IL_0413;
																																		case 194:
																																			goto IL_0900;
																																		case 8:
																																			goto IL_0917;
																																		case 75:
																																			goto IL_0933;
																																		case 108:
																																			goto IL_0941;
																																		case 25:
																																		case 145:
																																			goto IL_094c;
																																		case 80:
																																			goto IL_098c;
																																		case 43:
																																			goto IL_09a0;
																																		case 182:
																																			goto IL_09b3;
																																		case 106:
																																			goto IL_09ca;
																																		case 143:
																																		case 214:
																																			goto IL_09d8;
																																		case 40:
																																			goto IL_09eb;
																																		case 31:
																																			goto IL_09f9;
																																		case 70:
																																		case 129:
																																			goto IL_0a07;
																																		case 35:
																																			goto IL_0a69;
																																		case 74:
																																			goto IL_0a7c;
																																		case 227:
																																			goto IL_0a87;
																																		case 147:
																																		case 199:
																																			goto IL_0a92;
																																		case 202:
																																			goto IL_0aab;
																																		case 158:
																																			goto IL_0ab9;
																																		case 105:
																																			goto IL_0ac7;
																																		case 120:
																																			goto IL_0ada;
																																		case 1:
																																			goto IL_0ae8;
																																		case 0:
																																			goto IL_0afb;
																																		case 38:
																																			goto IL_0b09;
																																		case 186:
																																		case 240:
																																			goto IL_0b20;
																																		case 171:
																																			goto IL_0b38;
																																		case 28:
																																			goto IL_0b46;
																																		case 72:
																																		case 100:
																																			goto IL_0b51;
																																		case 220:
																																			goto IL_0b91;
																																		case 89:
																																			goto IL_0ba5;
																																		case 94:
																																			goto IL_0bc1;
																																		case 60:
																																			goto IL_0bcf;
																																		case 155:
																																		case 212:
																																			goto IL_0bda;
																																		case 184:
																																			goto IL_0be4;
																																		case 55:
																																			goto IL_0bf2;
																																		case 11:
																																			goto IL_0c05;
																																		case 41:
																																			goto IL_0c10;
																																		case 95:
																																			goto IL_0c1e;
																																		case 217:
																																		case 239:
																																			goto IL_0c2c;
																																		case 116:
																																			goto IL_0c3a;
																																		case 125:
																																			goto IL_0c58;
																																		case 175:
																																			goto IL_0c66;
																																		case 178:
																																			goto IL_0c79;
																																		case 102:
																																		case 140:
																																			goto IL_0c87;
																																		case 81:
																																			goto IL_0cd9;
																																		case 107:
																																			goto IL_0cec;
																																		case 206:
																																			goto IL_0cfa;
																																		case 62:
																																			goto IL_0d08;
																																		case 46:
																																			goto IL_0d16;
																																		case 22:
																																		case 165:
																																			goto IL_0d24;
																																		case 128:
																																			goto IL_0d38;
																																		case 24:
																																			goto IL_0d85;
																																		case 82:
																																			goto IL_0d93;
																																		case 19:
																																		case 56:
																																			goto IL_0da6;
																																		case 64:
																																			goto IL_0dc8;
																																		case 37:
																																			goto IL_0dd6;
																																		case 7:
																																			goto IL_0ded;
																																		case 149:
																																			goto IL_0e00;
																																		case 235:
																																			goto IL_0e0e;
																																		case 228:
																																		case 243:
																																			goto IL_0e1c;
																																		case 29:
																																			goto IL_0e30;
																																		case 111:
																																			goto IL_0e6f;
																																		case 5:
																																			goto IL_0e82;
																																		case 153:
																																			goto IL_0e90;
																																		case 9:
																																		case 34:
																																			goto IL_0e9b;
																																		case 146:
																																			goto IL_0ec6;
																																		case 139:
																																			goto IL_0edf;
																																		case 14:
																																			goto IL_0eed;
																																		case 136:
																																		case 177:
																																			goto IL_0ef8;
																																		case 223:
																																			goto IL_0f12;
																																		case 63:
																																			goto IL_0f20;
																																		case 242:
																																			goto IL_0f2e;
																																		case 226:
																																			goto IL_0f41;
																																		case 45:
																																			goto IL_0f4f;
																																		case 73:
																																		case 224:
																																			goto IL_0f5d;
																																		case 121:
																																			goto IL_0f71;
																																		case 169:
																																			goto IL_0fb0;
																																		case 216:
																																			goto IL_0fc3;
																																		case 190:
																																			goto IL_0fda;
																																		case 130:
																																		case 191:
																																			goto IL_0fe8;
																																		case 215:
																																			goto IL_1016;
																																		case 152:
																																			goto IL_1029;
																																		case 91:
																																			goto IL_1034;
																																		case 48:
																																		case 167:
																																			goto IL_103f;
																																		case 87:
																																			goto IL_1058;
																																		case 44:
																																			goto IL_1063;
																																		case 110:
																																		case 231:
																																			goto IL_106e;
																																		case 39:
																																			goto IL_109c;
																																		case 181:
																																			goto IL_10ac;
																																		case 209:
																																			goto IL_10b7;
																																		case 2:
																																		case 10:
																																		case 15:
																																		case 17:
																																		case 27:
																																		case 32:
																																		case 61:
																																		case 71:
																																		case 78:
																																		case 79:
																																		case 84:
																																		case 86:
																																		case 90:
																																		case 96:
																																		case 101:
																																		case 103:
																																		case 104:
																																		case 113:
																																		case 119:
																																		case 122:
																																		case 154:
																																		case 157:
																																		case 160:
																																		case 162:
																																		case 172:
																																		case 174:
																																		case 185:
																																		case 203:
																																		case 213:
																																		case 218:
																																		case 221:
																																		case 233:
																																			goto end_IL_0426;
																																		case 4:
																																		case 18:
																																		case 20:
																																		case 33:
																																		case 42:
																																		case 47:
																																		case 53:
																																		case 65:
																																		case 67:
																																		case 68:
																																		case 76:
																																		case 77:
																																		case 115:
																																		case 123:
																																		case 124:
																																		case 134:
																																		case 135:
																																		case 148:
																																		case 151:
																																		case 156:
																																		case 163:
																																		case 164:
																																		case 166:
																																		case 170:
																																		case 176:
																																		case 196:
																																		case 198:
																																		case 204:
																																		case 219:
																																		case 222:
																																		case 236:
																																		case 237:
																																			goto end_IL_04d9;
																																		case 57:
																																			goto end_IL_10d5;
																																		case 21:
																																			goto end_IL_10e8;
																																		case 99:
																																			goto end_IL_10f2;
																																		case 58:
																																		case 183:
																																			goto end_IL_10fd;
																																		case 230:
																																			goto end_IL_110d;
																																		case 238:
																																			goto end_IL_111d;
																																		case 137:
																																			goto end_IL_112d;
																																		case 179:
																																			goto end_IL_113d;
																																		case 180:
																																			goto end_IL_114d;
																																		case 3:
																																		case 66:
																																			return;
																																		}
																																		continue;
																																	}
																																	if (2 > b)
																																	{
																																		goto end_IL_0426;
																																	}
																																	goto IL_0815;
																																	IL_0815:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	goto IL_0855;
																																	IL_0869:
																																	num6--;
																																	goto end_IL_04d9;
																																	IL_0855:
																																	array[num6 - 2] = 0;
																																	goto IL_0869;
																																	continue;
																																	end_IL_0413:
																																	break;
																																}
																																goto IL_08ac;
																																continue;
																																end_IL_0426:
																																break;
																																IL_0426:;
																															}
																															break;
																														}
																														goto IL_04e4;
																														IL_0685:
																														ptr2 += 8;
																														goto end_IL_04d9;
																														IL_04e4:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_0647;
																														IL_0647:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																														goto IL_0660;
																														IL_0660:
																														array[num6] = 0;
																														num = 50;
																														goto IL_0677;
																														IL_0677:
																														num6++;
																														goto IL_0685;
																													}
																													break;
																												}
																												goto IL_0698;
																												IL_06cf:
																												num6--;
																												goto end_IL_04d9;
																												IL_0698:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_06c1;
																												IL_06c1:
																												ptr2 += 8;
																												goto IL_06cf;
																											}
																											break;
																										}
																										goto IL_055f;
																										IL_0749:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0789;
																										IL_055f:
																										if (5 < b)
																										{
																											goto IL_056d;
																										}
																										goto IL_0709;
																										IL_056d:
																										if (6 < b)
																										{
																											break;
																										}
																										goto IL_057b;
																										IL_057b:
																										if (6 > b)
																										{
																											break;
																										}
																										num = 36;
																										goto IL_0592;
																										IL_0789:
																										array[num6 - 2] = 0;
																										num = 138;
																										goto IL_07a6;
																										IL_0592:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_05d2;
																										IL_05d2:
																										array[num6 - 2] = 0;
																										goto IL_05e6;
																										IL_05e6:
																										num6--;
																										num = 124;
																										goto end_IL_04d9;
																										IL_0709:
																										if (5 > b)
																										{
																											goto IL_0714;
																										}
																										goto IL_0749;
																										IL_0714:
																										if (4 < b)
																										{
																											break;
																										}
																										num = 97;
																										goto IL_072b;
																										IL_07a6:
																										num6--;
																										goto end_IL_04d9;
																										IL_072b:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_0739;
																										IL_0739:
																										array[num6] = 0;
																										goto IL_07b9;
																										IL_07b9:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_07dc;
																										IL_07dc:
																										array2[num6] = null;
																										goto IL_07e6;
																										IL_07e6:
																										num6++;
																										goto IL_07f4;
																										IL_07f4:
																										ptr2 += 8;
																										goto end_IL_04d9;
																									}
																									break;
																								}
																								goto IL_0602;
																								IL_06f6:
																								num6--;
																								goto end_IL_04d9;
																								IL_0602:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_06e2;
																								IL_06e2:
																								array[num6 - 2] = 0;
																								goto IL_06f6;
																							}
																							break;
																						}
																						goto IL_087c;
																						IL_0afb:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_0b09;
																						IL_0b09:
																						if (14 > b)
																						{
																							break;
																						}
																						num = 186;
																						goto IL_0b20;
																						IL_087c:
																						if (11 >= b)
																						{
																							goto IL_088a;
																						}
																						goto IL_0a7c;
																						IL_088a:
																						if (11 <= b)
																						{
																							goto IL_0898;
																						}
																						goto IL_0933;
																						IL_0898:
																						array[num6 - 2] = 0;
																						goto IL_08ac;
																						IL_08ac:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)DirectoryExistsgetIsHomogenous[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0900;
																						IL_0900:
																						num6--;
																						num = 8;
																						goto IL_0917;
																						IL_0917:
																						ptr2 += 8;
																						num = 151;
																						goto end_IL_04d9;
																						IL_0933:
																						if (9 >= b)
																						{
																							goto IL_0941;
																						}
																						goto IL_09eb;
																						IL_0941:
																						if (9 <= b)
																						{
																							goto IL_094c;
																						}
																						goto IL_09b3;
																						IL_094c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_098c;
																						IL_098c:
																						array[num6 - 2] = 0;
																						goto IL_09a0;
																						IL_09a0:
																						num6--;
																						goto end_IL_04d9;
																						IL_09b3:
																						if (8 < b)
																						{
																							break;
																						}
																						num = 106;
																						goto IL_09ca;
																						IL_0b20:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_04d9;
																						IL_09ca:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_09d8;
																						IL_09d8:
																						num6--;
																						goto end_IL_04d9;
																						IL_09eb:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_09f9;
																						IL_09f9:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0a07;
																						IL_0a07:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0a69;
																						IL_0a69:
																						num6 -= 2;
																						goto end_IL_04d9;
																						IL_0a7c:
																						if (13 >= b)
																						{
																							goto IL_0a87;
																						}
																						goto IL_0afb;
																						IL_0a87:
																						if (13 <= b)
																						{
																							goto IL_0a92;
																						}
																						goto IL_0ada;
																						IL_0a92:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0aab;
																						IL_0aab:
																						array[num6] = 1;
																						goto IL_0ab9;
																						IL_0ab9:
																						num6++;
																						goto IL_0ac7;
																						IL_0ac7:
																						ptr2 += 16;
																						goto end_IL_04d9;
																						IL_0ada:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0ae8;
																						IL_0ae8:
																						if (12 > b)
																						{
																							break;
																						}
																						goto end_IL_04d9;
																					}
																					break;
																				}
																				goto IL_04f7;
																				IL_054c:
																				num6--;
																				goto end_IL_04d9;
																				IL_04f7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_0538;
																				IL_0538:
																				array[num6 - 2] = 0;
																				goto IL_054c;
																			}
																			break;
																		}
																		goto IL_0b38;
																		IL_10ac:
																		if (29 < b)
																		{
																			break;
																		}
																		goto IL_10b7;
																		IL_0b38:
																		if (22 >= b)
																		{
																			goto IL_0b46;
																		}
																		goto IL_0e82;
																		IL_0b46:
																		if (22 <= b)
																		{
																			goto IL_0b51;
																		}
																		goto IL_0bc1;
																		IL_0b51:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0b91;
																		IL_0b91:
																		array[num6 - 2] = 3;
																		goto IL_0ba5;
																		IL_0ba5:
																		num6--;
																		num = 219;
																		goto end_IL_04d9;
																		IL_0bc1:
																		if (18 >= b)
																		{
																			goto IL_0bcf;
																		}
																		goto IL_0cec;
																		IL_0bcf:
																		if (18 <= b)
																		{
																			goto IL_0bda;
																		}
																		goto IL_0c05;
																		IL_0bda:
																		array2[num6] = null;
																		goto IL_0be4;
																		IL_0be4:
																		array[num6] = 5;
																		goto IL_0bf2;
																		IL_0bf2:
																		num6++;
																		goto end_IL_04d9;
																		IL_0c05:
																		if (16 < b)
																		{
																			goto IL_0c10;
																		}
																		goto IL_0c79;
																		IL_0c10:
																		if (17 < b)
																		{
																			break;
																		}
																		goto IL_0c1e;
																		IL_0c1e:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_0c2c;
																		IL_0c2c:
																		array[num6] = 5;
																		goto IL_0c3a;
																		IL_0c3a:
																		array2[num6] = ((delegate*<GorillaTagger>)DirectoryExistsgetIsHomogenous[*(int*)(ptr2 + num3)])();
																		goto IL_0c58;
																		IL_0c58:
																		num6++;
																		goto IL_0c66;
																		IL_0c66:
																		ptr2 += 8;
																		goto end_IL_04d9;
																		IL_0c79:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_0c87;
																		IL_0c87:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0cd9;
																		IL_0cd9:
																		num6--;
																		goto end_IL_04d9;
																		IL_0cec:
																		if (20 >= b)
																		{
																			goto IL_0cfa;
																		}
																		goto IL_0e00;
																		IL_0cfa:
																		if (20 > b)
																		{
																			goto IL_0d08;
																		}
																		goto IL_0da6;
																		IL_0d08:
																		if (19 < b)
																		{
																			break;
																		}
																		goto IL_0d16;
																		IL_0d16:
																		if (19 > b)
																		{
																			break;
																		}
																		goto IL_0d24;
																		IL_0d24:
																		array[num6 - 2] = 0;
																		goto IL_0d38;
																		IL_0d38:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)DirectoryExistsgetIsHomogenous[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																		goto IL_0d85;
																		IL_0d85:
																		num6--;
																		goto IL_0d93;
																		IL_0d93:
																		ptr2 += 8;
																		goto end_IL_04d9;
																		IL_0da6:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		num = 64;
																		goto IL_0dc8;
																		IL_0dc8:
																		array[num6] = 3;
																		goto IL_0dd6;
																		IL_0dd6:
																		num6++;
																		num = 7;
																		goto IL_0ded;
																		IL_0ded:
																		ptr2 += 16;
																		goto end_IL_04d9;
																		IL_0e00:
																		if (21 < b)
																		{
																			break;
																		}
																		goto IL_0e0e;
																		IL_0e0e:
																		if (21 > b)
																		{
																			break;
																		}
																		goto IL_0e1c;
																		IL_0e1c:
																		array[num6 - 1] = 3;
																		goto IL_0e30;
																		IL_0e30:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)DirectoryExistsgetIsHomogenous[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0e6f;
																		IL_0e6f:
																		ptr2 += 8;
																		goto end_IL_04d9;
																		IL_0e82:
																		if (26 >= b)
																		{
																			goto IL_0e90;
																		}
																		goto IL_1029;
																		IL_0e90:
																		if (26 <= b)
																		{
																			goto IL_0e9b;
																		}
																		goto IL_0edf;
																		IL_0e9b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0ec6;
																		IL_0ec6:
																		array[num6 - 1] = 0;
																		goto end_IL_04d9;
																		IL_0edf:
																		if (24 >= b)
																		{
																			goto IL_0eed;
																		}
																		goto IL_0fc3;
																		IL_0eed:
																		if (24 <= b)
																		{
																			goto IL_0ef8;
																		}
																		goto IL_0f41;
																		IL_0ef8:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																		goto IL_0f12;
																		IL_0f12:
																		array[num6] = 3;
																		goto IL_0f20;
																		IL_0f20:
																		num6++;
																		goto IL_0f2e;
																		IL_0f2e:
																		ptr2 += 8;
																		goto end_IL_04d9;
																		IL_0f41:
																		if (23 < b)
																		{
																			break;
																		}
																		goto IL_0f4f;
																		IL_0f4f:
																		if (23 > b)
																		{
																			break;
																		}
																		goto IL_0f5d;
																		IL_0f5d:
																		array[num6 - 1] = 0;
																		goto IL_0f71;
																		IL_0f71:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)DirectoryExistsgetIsHomogenous[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0fb0;
																		IL_0fb0:
																		ptr2 += 8;
																		goto end_IL_04d9;
																		IL_0fc3:
																		if (25 < b)
																		{
																			break;
																		}
																		num = 190;
																		goto IL_0fda;
																		IL_10b7:
																		if (29 <= b)
																		{
																		}
																		break;
																		IL_0fda:
																		if (25 > b)
																		{
																			break;
																		}
																		goto IL_0fe8;
																		IL_0fe8:
																		((GorillaTagger)array2[num6 - 2]).lastRightTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_1016;
																		IL_1016:
																		num6 -= 2;
																		goto end_IL_04d9;
																		IL_1029:
																		if (28 >= b)
																		{
																			goto IL_1034;
																		}
																		goto IL_10ac;
																		IL_1034:
																		if (28 <= b)
																		{
																			goto IL_103f;
																		}
																		goto IL_1058;
																		IL_103f:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		goto end_IL_04d9;
																		IL_1058:
																		if (27 < b)
																		{
																			break;
																		}
																		goto IL_1063;
																		IL_1063:
																		if (27 > b)
																		{
																			break;
																		}
																		goto IL_106e;
																		IL_106e:
																		((GorillaTagger)array2[num6 - 2]).lastLeftTap = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_109c;
																		IL_109c:
																		num6 -= 2;
																		goto end_IL_04d9;
																	}
																	break;
																	IL_04a9:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_04d9;
															continue;
															end_IL_04b9:
															break;
														}
														continue;
														end_IL_04c9:
														break;
													}
													continue;
													end_IL_04d9:
													break;
												}
												continue;
												end_IL_10d5:
												break;
											}
											continue;
											end_IL_10e8:
											break;
										}
										continue;
										end_IL_10f2:
										break;
									}
									continue;
									end_IL_10fd:
									break;
								}
								continue;
								end_IL_110d:
								break;
							}
							continue;
							end_IL_111d:
							break;
						}
						continue;
						end_IL_112d:
						break;
					}
					continue;
					end_IL_113d:
					break;
				}
				continue;
				end_IL_114d:
				break;
			}
		}
	}

	public Class196()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 115;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setCreateIsValueFaulted.RecordArrayElementFixupMemberName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02cc:
														byte b = *ptr2;
														while (true)
														{
															IL_02bc:
															ptr2++;
															while (true)
															{
																IL_02ac:
																if (b >= 1)
																{
																	while (b <= 12)
																	{
																		while (true)
																		{
																			IL_028c:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_027c:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_026f:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_025f:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_024f:
																											if (1 >= b)
																											{
																												while (true)
																												{
																													IL_023c:
																													if (1 > b)
																													{
																														num = 131;
																														while (num != 131)
																														{
																															if (num != 1112)
																															{
																																goto end_IL_02ac;
																															}
																															switch (num)
																															{
																															case 44:
																																goto IL_023c;
																															case 86:
																																goto IL_024f;
																															case 101:
																																goto IL_025f;
																															case 4:
																															case 32:
																																goto IL_026f;
																															case 28:
																																goto IL_027c;
																															case 13:
																																goto IL_028c;
																															case 16:
																																goto IL_029c;
																															case 33:
																																goto IL_02ac;
																															case 111:
																																goto IL_02bc;
																															case 23:
																															case 66:
																																goto IL_02cc;
																															case 20:
																															case 56:
																																goto IL_02d7;
																															case 68:
																															case 75:
																																goto IL_02ea;
																															case 42:
																																goto IL_02f8;
																															case 17:
																															case 80:
																																goto IL_030b;
																															case 1:
																															case 95:
																																goto IL_0323;
																															case 46:
																																goto IL_0331;
																															case 50:
																															case 60:
																																goto IL_033f;
																															case 64:
																																goto IL_0356;
																															case 31:
																																goto IL_037a;
																															case 59:
																																goto IL_0388;
																															case 90:
																															case 100:
																																goto IL_039b;
																															case 45:
																																goto IL_03a9;
																															case 35:
																															case 94:
																																goto IL_03b7;
																															case 98:
																																goto IL_03c5;
																															case 61:
																															case 103:
																																goto IL_03ed;
																															case 93:
																																goto IL_03fb;
																															case 52:
																															case 107:
																																goto IL_040e;
																															case 69:
																																goto IL_0437;
																															case 21:
																																goto IL_0445;
																															case 106:
																															case 108:
																																goto IL_0458;
																															case 36:
																																goto IL_0463;
																															case 65:
																															case 73:
																																goto IL_046e;
																															case 11:
																															case 72:
																																goto IL_047e;
																															case 26:
																															case 74:
																																goto IL_049a;
																															case 38:
																																goto IL_04a8;
																															case 113:
																																goto IL_04bb;
																															case 116:
																																goto IL_04cb;
																															case 117:
																																goto IL_04de;
																															case 37:
																																goto IL_04e8;
																															case 96:
																																goto IL_04f6;
																															case 2:
																															case 118:
																																goto IL_0509;
																															case 63:
																															case 120:
																																goto IL_051c;
																															case 5:
																																goto IL_052a;
																															case 39:
																															case 97:
																																goto IL_0538;
																															case 99:
																																goto IL_059a;
																															case 91:
																															case 123:
																																goto IL_05ad;
																															case 6:
																																goto IL_05d0;
																															case 89:
																																goto IL_05e7;
																															case 25:
																																goto IL_05fe;
																															case 27:
																															case 122:
																																goto IL_0611;
																															case 10:
																																goto IL_062a;
																															case 24:
																																goto IL_0641;
																															case 77:
																																goto IL_064f;
																															case 104:
																															case 105:
																																goto IL_065f;
																															case 7:
																																goto IL_069f;
																															case 19:
																																goto IL_06b3;
																															case 0:
																															case 8:
																															case 14:
																															case 15:
																															case 29:
																															case 30:
																															case 34:
																															case 47:
																															case 48:
																															case 51:
																															case 53:
																															case 58:
																															case 62:
																															case 76:
																															case 78:
																															case 85:
																															case 92:
																															case 119:
																															case 121:
																															case 124:
																																goto end_IL_0229;
																															case 3:
																															case 9:
																															case 18:
																															case 22:
																															case 49:
																															case 54:
																															case 55:
																															case 57:
																															case 70:
																															case 71:
																															case 83:
																															case 84:
																															case 102:
																															case 109:
																															case 112:
																																goto end_IL_02ac;
																															case 12:
																																goto end_IL_06d6;
																															case 40:
																																goto end_IL_06e9;
																															case 79:
																																goto end_IL_06f3;
																															case 41:
																																goto end_IL_06fe;
																															case 82:
																															case 87:
																																goto end_IL_0713;
																															case 43:
																																goto end_IL_0723;
																															case 81:
																															case 88:
																																goto end_IL_0733;
																															case 114:
																																goto end_IL_0743;
																															case 115:
																																goto end_IL_0753;
																															case 67:
																															case 110:
																																goto IL_076e;
																															}
																															continue;
																															end_IL_0229:
																															break;
																														}
																														break;
																													}
																													goto IL_0611;
																													IL_0641:
																													num5++;
																													goto IL_064f;
																													IL_064f:
																													ptr2 += 8;
																													goto end_IL_02ac;
																													IL_0611:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_062a;
																													IL_062a:
																													array[num5] = 0;
																													num = 24;
																													goto IL_0641;
																												}
																												break;
																											}
																											goto IL_02ea;
																											IL_0445:
																											num5--;
																											goto end_IL_02ac;
																											IL_02ea:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_02f8;
																											IL_02f8:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_040e;
																											IL_040e:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0437;
																											IL_0437:
																											ptr2 += 8;
																											goto IL_0445;
																										}
																										break;
																									}
																									goto IL_030b;
																									IL_030b:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02ac;
																								}
																								break;
																							}
																							goto IL_02d7;
																							IL_04cb:
																							if (4 <= b)
																							{
																								goto end_IL_02ac;
																							}
																							break;
																							IL_02d7:
																							if (4 < b)
																							{
																								goto IL_039b;
																							}
																							goto IL_04cb;
																							IL_039b:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_03a9;
																							IL_03a9:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_03b7;
																							IL_03b7:
																							array[num5] = 0;
																							goto IL_03c5;
																							IL_03c5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_04de;
																							IL_04de:
																							array2[num5] = null;
																							goto IL_04e8;
																							IL_04e8:
																							num5++;
																							goto IL_04f6;
																							IL_04f6:
																							ptr2 += 8;
																							goto end_IL_02ac;
																						}
																						break;
																					}
																					goto IL_065f;
																					IL_06b3:
																					num5--;
																					goto end_IL_02ac;
																					IL_065f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_069f;
																					IL_069f:
																					array[num5 - 2] = 0;
																					goto IL_06b3;
																				}
																				break;
																			}
																			goto IL_0323;
																			IL_04a8:
																			if (12 > b)
																			{
																			}
																			break;
																			IL_0323:
																			if (9 >= b)
																			{
																				goto IL_0331;
																			}
																			goto IL_0458;
																			IL_0331:
																			if (9 <= b)
																			{
																				goto IL_033f;
																			}
																			goto IL_03ed;
																			IL_033f:
																			array[num5] = 0;
																			num = 64;
																			goto IL_0356;
																			IL_0356:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)StartProfilegetStackBehaviourPush[*(int*)(ptr2 + num3)])();
																			goto IL_037a;
																			IL_037a:
																			num5++;
																			goto IL_0388;
																			IL_0388:
																			ptr2 += 8;
																			goto end_IL_02ac;
																			IL_03ed:
																			if (7 >= b)
																			{
																				goto IL_03fb;
																			}
																			goto IL_051c;
																			IL_03fb:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05ad;
																			IL_05ad:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05d0;
																			IL_05d0:
																			array[num5] = 0;
																			num = 89;
																			goto IL_05e7;
																			IL_05e7:
																			num5++;
																			num = 25;
																			goto IL_05fe;
																			IL_05fe:
																			ptr2 += 8;
																			goto end_IL_02ac;
																			IL_051c:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_052a;
																			IL_052a:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0538;
																			IL_0538:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_059a;
																			IL_059a:
																			num5 -= 2;
																			goto end_IL_02ac;
																			IL_0458:
																			if (11 >= b)
																			{
																				goto IL_0463;
																			}
																			goto IL_049a;
																			IL_0463:
																			if (11 > b)
																			{
																				goto IL_046e;
																			}
																			goto IL_047e;
																			IL_046e:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_04bb;
																			IL_04bb:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0509;
																			IL_0509:
																			num5--;
																			goto end_IL_02ac;
																			IL_047e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02ac;
																			IL_049a:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_04a8;
																		}
																		break;
																		IL_029c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02ac:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_076e;
												IL_076e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06d6:
												break;
											}
											continue;
											end_IL_06e9:
											break;
										}
										continue;
										end_IL_06f3:
										break;
									}
									continue;
									end_IL_06fe:
									break;
								}
								continue;
								end_IL_0713:
								break;
							}
							continue;
							end_IL_0723:
							break;
						}
						continue;
						end_IL_0733:
						break;
					}
					continue;
					end_IL_0743:
					break;
				}
				continue;
				end_IL_0753:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 65;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BitArrayTypeNameConverter.SZArrayEnumeratorStartDTD);
										num = 94;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02cf:
														num = 55;
														while (true)
														{
															IL_02c4:
															byte b = *ptr2;
															while (true)
															{
																IL_02b4:
																ptr2++;
																while (true)
																{
																	IL_02a4:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0287:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0277:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0267:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_01fa:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										num = 118;
																										while (true)
																										{
																											if (num != 118)
																											{
																												if (num != 1099)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 50:
																												case 101:
																													goto IL_01fa;
																												case 51:
																													goto IL_0267;
																												case 12:
																													goto IL_0277;
																												case 110:
																													goto IL_0287;
																												case 105:
																													goto IL_0294;
																												case 85:
																													goto IL_02a4;
																												case 83:
																													goto IL_02b4;
																												case 55:
																													goto IL_02c4;
																												case 22:
																													goto IL_02cf;
																												case 95:
																													goto IL_02da;
																												case 66:
																												case 88:
																													goto IL_02e8;
																												case 71:
																													goto IL_02f6;
																												case 70:
																													goto IL_0304;
																												case 63:
																												case 82:
																													goto IL_030f;
																												case 54:
																													goto IL_031d;
																												case 9:
																												case 52:
																													goto IL_032b;
																												case 49:
																													goto IL_0354;
																												case 30:
																													goto IL_0362;
																												case 29:
																													goto IL_0375;
																												case 16:
																												case 28:
																													goto IL_0385;
																												case 45:
																													goto IL_03c5;
																												case 33:
																													goto IL_03d9;
																												case 87:
																												case 98:
																													goto IL_03ec;
																												case 80:
																													goto IL_0405;
																												case 89:
																													goto IL_0413;
																												case 61:
																													goto IL_042a;
																												case 7:
																												case 100:
																													goto IL_043d;
																												case 107:
																													goto IL_045e;
																												case 41:
																												case 96:
																													goto IL_0469;
																												case 86:
																													goto IL_0477;
																												case 24:
																												case 60:
																													goto IL_0485;
																												case 44:
																													goto IL_0493;
																												case 31:
																													goto IL_04b6;
																												case 36:
																													goto IL_04c0;
																												case 10:
																													goto IL_04ce;
																												case 91:
																													goto IL_04e1;
																												case 93:
																													goto IL_0507;
																												case 74:
																													goto IL_0512;
																												case 25:
																												case 72:
																													goto IL_0520;
																												case 109:
																													goto IL_0560;
																												case 69:
																													goto IL_0574;
																												case 73:
																													goto IL_0587;
																												case 111:
																													goto IL_0595;
																												case 1:
																												case 48:
																													goto IL_05a3;
																												case 108:
																													goto IL_05c6;
																												case 57:
																													goto IL_05d4;
																												case 102:
																													goto IL_05e2;
																												case 26:
																													goto IL_05f2;
																												case 39:
																													goto IL_05fd;
																												case 78:
																													goto IL_0608;
																												case 77:
																													goto IL_0615;
																												case 15:
																												case 106:
																													goto IL_062b;
																												case 2:
																												case 5:
																												case 11:
																												case 14:
																												case 17:
																												case 18:
																												case 19:
																												case 20:
																												case 23:
																												case 32:
																												case 37:
																												case 47:
																												case 53:
																												case 56:
																												case 67:
																												case 68:
																												case 76:
																												case 79:
																												case 84:
																												case 90:
																												case 99:
																													goto end_IL_0294;
																												case 3:
																												case 8:
																												case 21:
																												case 27:
																												case 34:
																												case 38:
																												case 42:
																												case 46:
																												case 58:
																												case 59:
																												case 62:
																												case 75:
																												case 103:
																												case 104:
																													goto end_IL_01e7;
																												case 94:
																													goto end_IL_0660;
																												case 4:
																													goto end_IL_0673;
																												case 35:
																													goto end_IL_067d;
																												case 0:
																													goto end_IL_0691;
																												case 81:
																												case 97:
																													goto end_IL_06a6;
																												case 13:
																													goto end_IL_06b6;
																												case 6:
																												case 43:
																													goto end_IL_06c6;
																												case 64:
																													goto end_IL_06d6;
																												case 65:
																													goto end_IL_06e6;
																												case 40:
																												case 92:
																													goto IL_0701;
																												}
																												continue;
																											}
																											num5 -= 2;
																											break;
																											continue;
																											end_IL_01e7:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0507;
																								IL_05e2:
																								ptr2 += 8;
																								break;
																								IL_0507:
																								if (7 >= b)
																								{
																									goto IL_0512;
																								}
																								goto IL_0587;
																								IL_0512:
																								if (7 > b)
																								{
																									goto end_IL_0294;
																								}
																								goto IL_0520;
																								IL_0520:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0560;
																								IL_0560:
																								array[num5 - 2] = 0;
																								goto IL_0574;
																								IL_0574:
																								num5--;
																								break;
																								IL_0587:
																								if (8 < b)
																								{
																									goto end_IL_0294;
																								}
																								goto IL_0595;
																								IL_0595:
																								if (8 > b)
																								{
																									goto end_IL_0294;
																								}
																								goto IL_05a3;
																								IL_05a3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_05c6;
																								IL_05c6:
																								array[num5] = 0;
																								goto IL_05d4;
																								IL_05d4:
																								num5++;
																								goto IL_05e2;
																							}
																							break;
																						}
																						goto IL_05f2;
																						IL_062b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						num = 3;
																						break;
																						IL_05f2:
																						if (10 < b)
																						{
																							goto IL_05fd;
																						}
																						goto IL_0615;
																						IL_05fd:
																						if (11 < b)
																						{
																							goto end_IL_0294;
																						}
																						goto IL_0608;
																						IL_0608:
																						if (11 <= b)
																						{
																						}
																						goto end_IL_0294;
																						IL_0615:
																						if (10 > b)
																						{
																							num = 5;
																							goto end_IL_0294;
																						}
																						goto IL_062b;
																					}
																					break;
																				}
																				goto IL_02da;
																				IL_03d9:
																				num5--;
																				break;
																				IL_02da:
																				if (6 > b)
																				{
																					goto IL_02e8;
																				}
																				goto IL_0385;
																				IL_02e8:
																				if (3 >= b)
																				{
																					goto IL_02f6;
																				}
																				goto IL_045e;
																				IL_02f6:
																				if (3 > b)
																				{
																					goto IL_0304;
																				}
																				goto IL_043d;
																				IL_0304:
																				if (1 < b)
																				{
																					goto IL_030f;
																				}
																				goto IL_0375;
																				IL_030f:
																				if (2 < b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_031d;
																				IL_031d:
																				if (2 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_032b;
																				IL_032b:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0354;
																				IL_0354:
																				ptr2 += 8;
																				goto IL_0362;
																				IL_0362:
																				num5--;
																				break;
																				IL_0375:
																				if (1 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_03ec;
																				IL_03ec:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0405;
																				IL_0405:
																				array[num5] = 0;
																				goto IL_0413;
																				IL_0413:
																				num5++;
																				num = 61;
																				goto IL_042a;
																				IL_042a:
																				ptr2 += 8;
																				break;
																				IL_043d:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 59;
																				break;
																				IL_045e:
																				if (4 < b)
																				{
																					goto IL_0469;
																				}
																				goto IL_04e1;
																				IL_0469:
																				if (5 < b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_0477;
																				IL_0477:
																				if (5 > b)
																				{
																					goto end_IL_0294;
																				}
																				goto IL_0485;
																				IL_0485:
																				array[num5] = 0;
																				goto IL_0493;
																				IL_0493:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04b6;
																				IL_04b6:
																				array2[num5] = null;
																				goto IL_04c0;
																				IL_04c0:
																				num5++;
																				goto IL_04ce;
																				IL_04ce:
																				ptr2 += 8;
																				break;
																				IL_04e1:
																				if (4 <= b)
																				{
																					break;
																				}
																				goto end_IL_0294;
																				IL_0385:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c5;
																				IL_03c5:
																				array[num5 - 2] = 0;
																				goto IL_03d9;
																			}
																			goto end_IL_02a4;
																			continue;
																			end_IL_0294:
																			break;
																			IL_0294:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02a4:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0701;
												IL_0701:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0660:
												break;
											}
											continue;
											end_IL_0673:
											break;
										}
										continue;
										end_IL_067d:
										break;
									}
									continue;
									end_IL_0691:
									break;
								}
								continue;
								end_IL_06a6:
								break;
							}
							continue;
							end_IL_06b6:
							break;
						}
						continue;
						end_IL_06c6:
						break;
					}
					continue;
					end_IL_06d6:
					break;
				}
				continue;
				end_IL_06e6:
				break;
			}
		}
	}

	private static int smethod_2()
	{
		int num = 52;
		int num2 = 13;
		num = 4;
		object obj = new int[4];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 48;
		num3 = 12;
		((int[])obj)[0] = 12;
		obj = obj2;
		num2 = 1;
		num3 = 155;
		num3 = 31;
		((int[])obj)[1] = 31;
		obj = obj2;
		num2 = 4;
		num3 = 2;
		num2 = 2;
		num3 = 78;
		num3 = 6;
		((int[])obj)[2] = 6;
		obj = obj2;
		num2 = 39;
		num3 = 13;
		num2 = 3;
		num3 = 144;
		num3 = 36;
		((int[])obj)[3] = 36;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 20;
			num3 = 5;
			num2 = 4;
			if (num >= 4)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 43;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TrackResurrectionGetGenericArguments.ProcessArchitectureAtan);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02c9:
														byte b = *ptr2;
														while (true)
														{
															IL_02b9:
															ptr2++;
															while (true)
															{
																IL_02a9:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0289:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_027c:
																					if (10 < b)
																					{
																						while (true)
																						{
																							IL_026c:
																							if (12 >= b)
																							{
																								while (true)
																								{
																									IL_025c:
																									if (12 <= b)
																									{
																										while (true)
																										{
																											IL_023a:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											num = 134;
																											while (num != 134)
																											{
																												if (num != 1115)
																												{
																													goto IL_0398;
																												}
																												switch (num)
																												{
																												case 6:
																												case 92:
																													goto IL_023a;
																												case 27:
																													goto IL_025c;
																												case 95:
																													goto IL_026c;
																												case 56:
																												case 75:
																													goto IL_027c;
																												case 126:
																													goto IL_0289;
																												case 93:
																													goto IL_0299;
																												case 1:
																													goto IL_02a9;
																												case 104:
																													goto IL_02b9;
																												case 22:
																												case 121:
																													goto IL_02c9;
																												case 125:
																													goto IL_02d4;
																												case 117:
																													goto IL_02e2;
																												case 47:
																													goto IL_02f0;
																												case 2:
																												case 54:
																													goto IL_02fe;
																												case 91:
																													goto IL_0360;
																												case 3:
																													goto IL_0373;
																												case 12:
																													goto IL_0381;
																												case 58:
																												case 98:
																													goto IL_0398;
																												case 105:
																													goto IL_03d8;
																												case 62:
																													goto IL_03ec;
																												case 55:
																												case 100:
																													goto IL_0408;
																												case 127:
																													goto IL_041c;
																												case 81:
																													goto IL_0470;
																												case 63:
																													goto IL_047e;
																												case 119:
																													goto IL_0491;
																												case 20:
																													goto IL_049f;
																												case 110:
																												case 122:
																													goto IL_04ad;
																												case 32:
																												case 103:
																													goto IL_04c0;
																												case 59:
																													goto IL_04ce;
																												case 10:
																													goto IL_04e1;
																												case 69:
																												case 77:
																													goto IL_04ec;
																												case 40:
																													goto IL_050f;
																												case 61:
																													goto IL_051d;
																												case 57:
																													goto IL_052b;
																												case 120:
																													goto IL_053e;
																												case 66:
																												case 68:
																													goto IL_054c;
																												case 18:
																													goto IL_055a;
																												case 44:
																												case 109:
																													goto IL_0565;
																												case 33:
																													goto IL_0573;
																												case 97:
																													goto IL_0596;
																												case 26:
																													goto IL_05a0;
																												case 52:
																													goto IL_05ae;
																												case 21:
																													goto IL_05c1;
																												case 87:
																													goto IL_05cf;
																												case 13:
																													goto IL_05e2;
																												case 60:
																													goto IL_05f0;
																												case 23:
																												case 111:
																													goto IL_05fe;
																												case 16:
																													goto IL_063e;
																												case 5:
																													goto IL_0652;
																												case 65:
																													goto IL_0665;
																												case 19:
																												case 39:
																													goto IL_0670;
																												case 94:
																													goto IL_0688;
																												case 7:
																												case 86:
																													goto IL_0693;
																												case 84:
																													goto IL_06a1;
																												case 37:
																												case 64:
																													goto IL_06af;
																												case 124:
																													goto IL_06d8;
																												case 28:
																													goto IL_06e6;
																												case 45:
																													goto IL_06f6;
																												case 78:
																												case 108:
																													goto IL_070a;
																												case 51:
																													goto IL_0723;
																												case 107:
																													goto IL_0731;
																												case 0:
																													goto IL_073f;
																												case 9:
																												case 11:
																												case 14:
																												case 29:
																												case 30:
																												case 34:
																												case 35:
																												case 41:
																												case 50:
																												case 53:
																												case 67:
																												case 71:
																												case 74:
																												case 76:
																												case 79:
																												case 82:
																												case 83:
																												case 89:
																												case 96:
																												case 99:
																												case 113:
																												case 114:
																												case 118:
																													goto end_IL_0299;
																												case 4:
																												case 17:
																												case 24:
																												case 25:
																												case 38:
																												case 46:
																												case 48:
																												case 70:
																												case 72:
																												case 80:
																												case 85:
																												case 88:
																												case 90:
																												case 101:
																												case 116:
																													goto end_IL_0227;
																												case 112:
																													goto end_IL_0762;
																												case 106:
																													goto end_IL_0775;
																												case 73:
																													goto end_IL_077f;
																												case 15:
																													goto end_IL_078a;
																												case 31:
																												case 123:
																													goto end_IL_079f;
																												case 102:
																													goto end_IL_07af;
																												case 8:
																												case 49:
																													goto end_IL_07bf;
																												case 42:
																													goto end_IL_07cf;
																												case 43:
																													goto end_IL_07df;
																												case 36:
																												case 115:
																													goto IL_07fa;
																												}
																												continue;
																												end_IL_0227:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0491;
																									IL_04ad:
																									num6--;
																									break;
																									IL_0491:
																									if (11 < b)
																									{
																										goto end_IL_0299;
																									}
																									goto IL_049f;
																									IL_049f:
																									if (11 > b)
																									{
																										goto end_IL_0299;
																									}
																									goto IL_04ad;
																								}
																								break;
																							}
																							goto IL_04c0;
																							IL_04ce:
																							if (13 <= b)
																							{
																							}
																							goto end_IL_0299;
																							IL_04c0:
																							if (13 < b)
																							{
																								goto end_IL_0299;
																							}
																							goto IL_04ce;
																						}
																						break;
																					}
																					goto IL_02d4;
																					IL_0470:
																					num6--;
																					goto IL_047e;
																					IL_02d4:
																					if (10 > b)
																					{
																						goto IL_02e2;
																					}
																					goto IL_0408;
																					IL_02e2:
																					if (8 >= b)
																					{
																						goto IL_02f0;
																					}
																					goto IL_0373;
																					IL_02f0:
																					if (8 > b)
																					{
																						goto end_IL_0299;
																					}
																					goto IL_02fe;
																					IL_02fe:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0360;
																					IL_0360:
																					num6 -= 2;
																					break;
																					IL_0373:
																					if (9 < b)
																					{
																						goto end_IL_0299;
																					}
																					goto IL_0381;
																					IL_0381:
																					if (9 > b)
																					{
																						goto end_IL_0299;
																					}
																					num = 98;
																					goto IL_0398;
																					IL_047e:
																					ptr2 += 8;
																					break;
																					IL_0398:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_03d8;
																					IL_03d8:
																					array[num6 - 2] = 0;
																					goto IL_03ec;
																					IL_03ec:
																					num6--;
																					num = 70;
																					break;
																					IL_0408:
																					array[num6 - 2] = 0;
																					goto IL_041c;
																					IL_041c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)CovariantPARAMFLAGFOUT[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0470;
																				}
																				break;
																			}
																			goto IL_04e1;
																			IL_0731:
																			num6++;
																			goto IL_073f;
																			IL_04e1:
																			if (7 <= b)
																			{
																				goto IL_04ec;
																			}
																			goto IL_053e;
																			IL_04ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_050f;
																			IL_050f:
																			array[num6] = 0;
																			goto IL_051d;
																			IL_051d:
																			num6++;
																			goto IL_052b;
																			IL_052b:
																			ptr2 += 8;
																			break;
																			IL_053e:
																			if (3 < b)
																			{
																				goto IL_054c;
																			}
																			goto IL_0665;
																			IL_054c:
																			if (5 >= b)
																			{
																				goto IL_055a;
																			}
																			goto IL_05e2;
																			IL_055a:
																			if (5 <= b)
																			{
																				goto IL_0565;
																			}
																			goto IL_05c1;
																			IL_0565:
																			array[num6] = 0;
																			goto IL_0573;
																			IL_0573:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0596;
																			IL_0596:
																			array2[num6] = null;
																			goto IL_05a0;
																			IL_05a0:
																			num6++;
																			goto IL_05ae;
																			IL_05ae:
																			ptr2 += 8;
																			break;
																			IL_05c1:
																			if (4 < b)
																			{
																				goto end_IL_0299;
																			}
																			goto IL_05cf;
																			IL_05cf:
																			if (4 > b)
																			{
																				goto end_IL_0299;
																			}
																			break;
																			IL_05e2:
																			if (6 < b)
																			{
																				goto end_IL_0299;
																			}
																			goto IL_05f0;
																			IL_05f0:
																			if (6 > b)
																			{
																				goto end_IL_0299;
																			}
																			goto IL_05fe;
																			IL_05fe:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_063e;
																			IL_063e:
																			array[num6 - 2] = 0;
																			goto IL_0652;
																			IL_0652:
																			num6--;
																			break;
																			IL_0665:
																			if (3 <= b)
																			{
																				goto IL_0670;
																			}
																			goto IL_0688;
																			IL_0670:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0688:
																			if (1 < b)
																			{
																				goto IL_0693;
																			}
																			goto IL_06f6;
																			IL_0693:
																			if (2 < b)
																			{
																				goto end_IL_0299;
																			}
																			goto IL_06a1;
																			IL_06a1:
																			if (2 > b)
																			{
																				goto end_IL_0299;
																			}
																			goto IL_06af;
																			IL_06af:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_06d8;
																			IL_06d8:
																			ptr2 += 8;
																			goto IL_06e6;
																			IL_06e6:
																			num6--;
																			break;
																			IL_06f6:
																			if (1 > b)
																			{
																				goto end_IL_0299;
																			}
																			num = 108;
																			goto IL_070a;
																			IL_073f:
																			ptr2 += 8;
																			break;
																			IL_070a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0723;
																			IL_0723:
																			array[num6] = 0;
																			goto IL_0731;
																		}
																		goto end_IL_02a9;
																		continue;
																		end_IL_0299:
																		break;
																		IL_0299:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02a9:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_07fa;
												IL_07fa:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0762:
												break;
											}
											continue;
											end_IL_0775:
											break;
										}
										continue;
										end_IL_077f:
										break;
									}
									continue;
									end_IL_078a:
									break;
								}
								continue;
								end_IL_079f:
								break;
							}
							continue;
							end_IL_07af:
							break;
						}
						continue;
						end_IL_07bf:
						break;
					}
					continue;
					end_IL_07cf:
					break;
				}
				continue;
				end_IL_07df:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 159;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 158;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FormatWithParameterContinuationWrapper.SetIterationContextSTOREASSEMBLYSTATUSMANIFESTONLY);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_034b:
														num = 6;
														while (true)
														{
															IL_0340:
															byte b = *ptr2;
															while (true)
															{
																IL_0330:
																ptr2++;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 17)
																		{
																			while (true)
																			{
																				IL_0303:
																				if (9 >= b)
																				{
																					while (9 > b)
																					{
																						num = 176;
																						while (true)
																						{
																							if (num == 176)
																							{
																								goto IL_0693;
																							}
																							if (num != 1157)
																							{
																								goto IL_0951;
																							}
																							switch (num)
																							{
																							case 23:
																								goto end_IL_02dd;
																							case 127:
																								goto IL_0303;
																							case 51:
																								goto IL_0310;
																							case 11:
																								goto IL_0320;
																							case 80:
																								goto IL_0330;
																							case 6:
																								goto IL_0340;
																							case 52:
																								goto IL_034b;
																							case 96:
																							case 129:
																								goto IL_0356;
																							case 99:
																								goto IL_0361;
																							case 9:
																								goto IL_0386;
																							case 37:
																							case 119:
																								goto IL_0394;
																							case 68:
																								goto IL_03f6;
																							case 131:
																								goto IL_0409;
																							case 53:
																							case 56:
																								goto IL_0414;
																							case 12:
																							case 141:
																								goto IL_0427;
																							case 142:
																								goto IL_043a;
																							case 40:
																								goto IL_0445;
																							case 91:
																							case 100:
																								goto IL_0458;
																							case 107:
																								goto IL_0466;
																							case 93:
																							case 138:
																								goto IL_0474;
																							case 140:
																								goto IL_04b4;
																							case 24:
																								goto IL_04c8;
																							case 97:
																							case 144:
																								goto IL_04db;
																							case 86:
																								goto IL_051f;
																							case 112:
																								goto IL_0533;
																							case 145:
																								goto IL_0546;
																							case 165:
																								goto IL_0556;
																							case 29:
																								goto IL_0564;
																							case 2:
																							case 33:
																								goto IL_0572;
																							case 167:
																								goto IL_0580;
																							case 67:
																								goto IL_05a3;
																							case 95:
																								goto IL_05ad;
																							case 83:
																								goto IL_05bb;
																							case 54:
																							case 168:
																								goto IL_05ce;
																							case 78:
																								goto IL_05e2;
																							case 146:
																								goto IL_0621;
																							case 63:
																							case 169:
																								goto IL_0634;
																							case 50:
																							case 150:
																								goto IL_063f;
																							case 47:
																								goto IL_064d;
																							case 39:
																								goto IL_0660;
																							case 28:
																							case 118:
																								goto IL_066e;
																							case 113:
																								goto IL_0693;
																							case 92:
																								goto IL_06a1;
																							case 114:
																								goto IL_06af;
																							case 10:
																							case 94:
																								goto IL_06ba;
																							case 101:
																								goto IL_06c8;
																							case 120:
																							case 151:
																								goto IL_06d6;
																							case 132:
																								goto IL_06ff;
																							case 110:
																								goto IL_0718;
																							case 26:
																							case 155:
																								goto IL_0723;
																							case 38:
																								goto IL_0763;
																							case 27:
																								goto IL_0777;
																							case 157:
																							case 166:
																								goto IL_078a;
																							case 70:
																								goto IL_0798;
																							case 36:
																							case 139:
																								goto IL_07a6;
																							case 81:
																								goto IL_07bf;
																							case 106:
																								goto IL_07cd;
																							case 111:
																								goto IL_07db;
																							case 34:
																							case 154:
																								goto IL_07ee;
																							case 58:
																								goto IL_080c;
																							case 149:
																								goto IL_081a;
																							case 130:
																							case 164:
																								goto IL_082d;
																							case 124:
																								goto IL_083b;
																							case 5:
																							case 77:
																								goto IL_0846;
																							case 135:
																								goto IL_0854;
																							case 13:
																							case 17:
																								goto IL_086d;
																							case 20:
																								goto IL_0885;
																							case 35:
																							case 66:
																								goto IL_0893;
																							case 69:
																								goto IL_08bc;
																							case 156:
																								goto IL_08ca;
																							case 76:
																								goto IL_08e6;
																							case 64:
																							case 75:
																								goto IL_08f1;
																							case 32:
																								goto IL_08ff;
																							case 109:
																							case 117:
																								goto IL_090d;
																							case 136:
																								goto IL_091b;
																							case 160:
																								goto IL_0933;
																							case 162:
																								goto IL_0941;
																							case 15:
																							case 18:
																								goto IL_0951;
																							case 3:
																								goto IL_0990;
																							case 0:
																							case 1:
																							case 7:
																							case 8:
																							case 16:
																							case 22:
																							case 41:
																							case 42:
																							case 44:
																							case 48:
																							case 49:
																							case 59:
																							case 60:
																							case 71:
																							case 73:
																							case 79:
																							case 82:
																							case 85:
																							case 87:
																							case 89:
																							case 90:
																							case 104:
																							case 115:
																							case 116:
																							case 121:
																							case 123:
																							case 126:
																							case 133:
																							case 134:
																							case 137:
																							case 147:
																							case 148:
																							case 153:
																								goto end_IL_0310;
																							case 4:
																							case 19:
																							case 21:
																							case 25:
																							case 30:
																							case 31:
																							case 43:
																							case 45:
																							case 57:
																							case 61:
																							case 65:
																							case 74:
																							case 84:
																							case 103:
																							case 105:
																							case 108:
																							case 128:
																							case 143:
																							case 152:
																							case 161:
																								goto end_IL_02f0;
																							case 55:
																								goto end_IL_09b3;
																							case 125:
																								goto end_IL_09c6;
																							case 98:
																								goto end_IL_09d0;
																							case 102:
																								goto end_IL_09db;
																							case 122:
																							case 163:
																								goto end_IL_09eb;
																							case 72:
																								goto end_IL_09fb;
																							case 14:
																							case 62:
																								goto end_IL_0a0b;
																							case 158:
																								goto end_IL_0a1b;
																							case 159:
																								goto end_IL_0a2b;
																							case 46:
																							case 88:
																								goto IL_0a4f;
																							}
																							continue;
																							IL_0933:
																							num5++;
																							goto IL_0941;
																							IL_0941:
																							ptr2 += 8;
																							goto end_IL_02f0;
																							IL_0693:
																							if (4 >= b)
																							{
																								goto IL_06a1;
																							}
																							goto IL_082d;
																							IL_06a1:
																							if (4 > b)
																							{
																								goto IL_06af;
																							}
																							goto IL_07ee;
																							IL_06af:
																							if (2 < b)
																							{
																								goto IL_06ba;
																							}
																							goto IL_0718;
																							IL_06ba:
																							if (3 < b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_06c8;
																							IL_06c8:
																							if (3 > b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_06d6;
																							IL_06d6:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_06ff;
																							IL_06ff:
																							array[num5 - 1] = 5;
																							goto end_IL_02f0;
																							IL_0718:
																							if (2 <= b)
																							{
																								goto IL_0723;
																							}
																							goto IL_078a;
																							IL_0723:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0763;
																							IL_0763:
																							array[num5 - 2] = 0;
																							goto IL_0777;
																							IL_0777:
																							num5--;
																							goto end_IL_02f0;
																							IL_078a:
																							if (1 < b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_0798;
																							IL_0798:
																							if (1 > b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_07a6;
																							IL_07a6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_07bf;
																							IL_07bf:
																							array[num5] = 0;
																							goto IL_07cd;
																							IL_07cd:
																							num5++;
																							goto IL_07db;
																							IL_07db:
																							ptr2 += 8;
																							goto end_IL_02f0;
																							IL_07ee:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_080c;
																							IL_080c:
																							ptr2 += 8;
																							goto IL_081a;
																							IL_081a:
																							num5--;
																							goto end_IL_02f0;
																							IL_082d:
																							if (6 < b)
																							{
																								goto IL_083b;
																							}
																							num = 76;
																							goto IL_08e6;
																							IL_083b:
																							if (7 < b)
																							{
																								goto IL_0846;
																							}
																							goto IL_0885;
																							IL_0846:
																							if (8 < b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_0854;
																							IL_0854:
																							if (8 > b)
																							{
																								num = 8;
																								goto end_IL_0310;
																							}
																							goto IL_086d;
																							IL_0990:
																							num5 -= 3;
																							goto end_IL_02f0;
																							IL_086d:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02f0;
																							IL_0885:
																							if (7 > b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_0893;
																							IL_0893:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_08bc;
																							IL_08bc:
																							ptr2 += 8;
																							goto IL_08ca;
																							IL_08ca:
																							num5--;
																							goto end_IL_02f0;
																							IL_0951:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0990;
																							IL_08e6:
																							if (6 > b)
																							{
																								goto IL_08f1;
																							}
																							goto IL_0951;
																							IL_08f1:
																							if (5 < b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_08ff;
																							IL_08ff:
																							if (5 > b)
																							{
																								goto end_IL_0310;
																							}
																							goto IL_090d;
																							IL_090d:
																							array[num5] = 5;
																							goto IL_091b;
																							IL_091b:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0933;
																							continue;
																							end_IL_02dd:
																							break;
																						}
																						continue;
																						end_IL_02f0:
																						break;
																					}
																					break;
																				}
																				goto IL_0356;
																				IL_0474:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b4;
																				IL_0356:
																				if (13 < b)
																				{
																					goto IL_0361;
																				}
																				num = 9;
																				goto IL_0386;
																				IL_0361:
																				if (15 >= b)
																				{
																					goto IL_0409;
																				}
																				num = 63;
																				goto IL_0634;
																				IL_04c8:
																				num5--;
																				break;
																				IL_0634:
																				if (16 < b)
																				{
																					goto IL_063f;
																				}
																				goto IL_0660;
																				IL_063f:
																				if (17 < b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_064d;
																				IL_064d:
																				if (17 <= b)
																				{
																				}
																				goto end_IL_0310;
																				IL_0660:
																				if (16 > b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_066e;
																				IL_066e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 161;
																				break;
																				IL_0409:
																				if (15 > b)
																				{
																					goto IL_0414;
																				}
																				goto IL_0427;
																				IL_0414:
																				if (14 < b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_0546;
																				IL_0546:
																				if (14 > b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_05ce;
																				IL_05ce:
																				array[num5 - 1] = 0;
																				goto IL_05e2;
																				IL_05e2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)StackOverflowExceptionCFB[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0621;
																				IL_0621:
																				ptr2 += 8;
																				break;
																				IL_0427:
																				num5--;
																				break;
																				IL_04b4:
																				array[num5 - 2] = 0;
																				goto IL_04c8;
																				IL_0386:
																				if (13 <= b)
																				{
																					goto IL_0394;
																				}
																				goto IL_043a;
																				IL_0394:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03f6;
																				IL_03f6:
																				num5 -= 2;
																				break;
																				IL_043a:
																				if (11 >= b)
																				{
																					goto IL_0445;
																				}
																				goto IL_0458;
																				IL_0445:
																				if (11 <= b)
																				{
																					goto IL_04db;
																				}
																				goto IL_0556;
																				IL_04db:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_051f;
																				IL_051f:
																				array[num5 - 2] = 0;
																				goto IL_0533;
																				IL_0533:
																				num5--;
																				break;
																				IL_0556:
																				if (10 < b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_0564;
																				IL_0564:
																				if (10 > b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_0572;
																				IL_0572:
																				array[num5] = 0;
																				goto IL_0580;
																				IL_0580:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05a3;
																				IL_05a3:
																				array2[num5] = null;
																				goto IL_05ad;
																				IL_05ad:
																				num5++;
																				goto IL_05bb;
																				IL_05bb:
																				ptr2 += 8;
																				break;
																				IL_0458:
																				if (12 < b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_0466;
																				IL_0466:
																				if (12 > b)
																				{
																					goto end_IL_0310;
																				}
																				goto IL_0474;
																			}
																			goto end_IL_0320;
																			continue;
																			end_IL_0310:
																			break;
																			IL_0310:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0320:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a4f;
												IL_0a4f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09b3:
												break;
											}
											continue;
											end_IL_09c6:
											break;
										}
										continue;
										end_IL_09d0:
										break;
									}
									continue;
									end_IL_09db:
									break;
								}
								continue;
								end_IL_09eb:
								break;
							}
							continue;
							end_IL_09fb:
							break;
						}
						continue;
						end_IL_0a0b:
						break;
					}
					continue;
					end_IL_0a1b:
					break;
				}
				continue;
				end_IL_0a2b:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 56;
		int num4 = default(int);
		long[] array3 = default(long[]);
		int[] array4 = default(int[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 101;
					while (true)
					{
						byte[] array = new byte[3];
						num = 98;
						while (true)
						{
							object[] array2 = new object[3];
							num = 111;
							while (true)
							{
								if (num == 111)
								{
									goto IL_0233;
								}
								if (num != 1092)
								{
									goto IL_06c4;
								}
								switch (num)
								{
								case 98:
									goto end_IL_01cb;
								case 101:
									goto end_IL_01db;
								case 30:
									goto end_IL_01f4;
								case 55:
									goto end_IL_020d;
								case 56:
									goto end_IL_0218;
								case 45:
									goto IL_0233;
								case 39:
									goto IL_0241;
								case 50:
									goto IL_024f;
								case 59:
									goto IL_0262;
								case 61:
									goto IL_0275;
								case 22:
									goto IL_027e;
								case 4:
								case 19:
								case 20:
								case 68:
								case 69:
								case 72:
								case 78:
								case 80:
								case 92:
								case 95:
								case 97:
									goto IL_0286;
								case 12:
									goto IL_0296;
								case 82:
									goto IL_029f;
								case 26:
									goto IL_02a8;
								case 63:
									goto IL_02b6;
								case 102:
									goto IL_02cf;
								case 0:
									goto IL_02dd;
								case 21:
									goto IL_02eb;
								case 46:
								case 53:
									goto IL_02f9;
								case 3:
								case 8:
									goto IL_0307;
								case 62:
								case 85:
									goto IL_0315;
								case 75:
									goto IL_0323;
								case 28:
								case 77:
									goto IL_0331;
								case 89:
									goto IL_0371;
								case 66:
									goto IL_0385;
								case 31:
									goto IL_0398;
								case 16:
								case 40:
									goto IL_03a6;
								case 74:
									goto IL_03cf;
								case 5:
									goto IL_03dd;
								case 17:
									goto IL_03f0;
								case 44:
								case 79:
									goto IL_03fb;
								case 49:
									goto IL_043b;
								case 32:
									goto IL_044f;
								case 51:
									goto IL_0462;
								case 103:
									goto IL_0470;
								case 6:
								case 81:
									goto IL_0483;
								case 88:
									goto IL_049a;
								case 34:
									goto IL_04bd;
								case 57:
									goto IL_04c7;
								case 9:
									goto IL_04d5;
								case 23:
									goto IL_04e8;
								case 87:
									goto IL_04f6;
								case 15:
									goto IL_0504;
								case 91:
									goto IL_0512;
								case 29:
								case 65:
									goto IL_0520;
								case 86:
									goto IL_0560;
								case 48:
									goto IL_0574;
								case 13:
								case 24:
									goto IL_0590;
								case 35:
									goto IL_05a9;
								case 100:
									goto IL_05b7;
								case 10:
									goto IL_05c5;
								case 99:
									goto IL_05d8;
								case 37:
									goto IL_05e3;
								case 36:
								case 94:
									goto IL_05f1;
								case 7:
									goto IL_0631;
								case 14:
									goto IL_0645;
								case 90:
									goto IL_0658;
								case 43:
									goto IL_0663;
								case 41:
								case 64:
									goto IL_066e;
								case 1:
									goto IL_0695;
								case 104:
									goto IL_06a3;
								case 76:
									goto IL_06b1;
								case 2:
								case 18:
								case 25:
								case 27:
								case 33:
								case 38:
								case 42:
								case 47:
								case 52:
								case 54:
								case 58:
								case 60:
								case 67:
								case 70:
								case 71:
								case 83:
								case 84:
								case 93:
								case 96:
									goto IL_06c4;
								case 11:
								case 73:
									goto IL_06e9;
								}
								continue;
								IL_06a3:
								num4++;
								goto IL_06b1;
								IL_06c4:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
								goto IL_0695;
								IL_0233:
								array4 = new int[5];
								goto IL_0241;
								IL_0241:
								array3 = new long[3];
								goto IL_024f;
								IL_024f:
								array4[0] = int_1;
								goto IL_0262;
								IL_0262:
								array4[1] = int_2;
								goto IL_0275;
								IL_0275:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReturnXmlElementNamesetXmlElementName.GetManifestResourceStreamRemoveMemoryPressure);
								goto IL_027e;
								IL_027e:
								ptr = ptr2;
								goto IL_0286;
								IL_0286:
								if (num5 != 1)
								{
									goto IL_0296;
								}
								goto IL_06e9;
								IL_06e9:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								IL_0296:
								num = 82;
								goto IL_029f;
								IL_029f:
								b = *ptr;
								goto IL_02a8;
								IL_02a8:
								ptr++;
								goto IL_02b6;
								IL_02b6:
								if (b >= 1)
								{
									goto IL_02cf;
								}
								num = 93;
								goto IL_06c4;
								IL_0695:
								array[num4] = 0;
								goto IL_06a3;
								IL_02cf:
								if (b <= 9)
								{
									goto IL_02dd;
								}
								num = 60;
								goto IL_06c4;
								IL_02dd:
								if (5 >= b)
								{
									goto IL_02eb;
								}
								goto IL_04e8;
								IL_02eb:
								if (5 > b)
								{
									goto IL_02f9;
								}
								goto IL_0483;
								IL_02f9:
								if (2 < b)
								{
									goto IL_0307;
								}
								goto IL_03f0;
								IL_0307:
								if (3 < b)
								{
									goto IL_0315;
								}
								goto IL_0398;
								IL_0315:
								if (4 >= b)
								{
									goto IL_0323;
								}
								goto IL_06c4;
								IL_0323:
								if (4 <= b)
								{
									goto IL_0331;
								}
								goto IL_06c4;
								IL_0331:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								goto IL_0371;
								IL_0371:
								array[num4 - 2] = 0;
								goto IL_0385;
								IL_0385:
								num4--;
								goto IL_0286;
								IL_0398:
								if (3 <= b)
								{
									goto IL_03a6;
								}
								goto IL_06c4;
								IL_03a6:
								ref int reference = ref array4[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								goto IL_03cf;
								IL_03cf:
								ptr += 8;
								goto IL_03dd;
								IL_03dd:
								num4--;
								goto IL_0286;
								IL_03f0:
								if (2 <= b)
								{
									goto IL_03fb;
								}
								goto IL_0462;
								IL_03fb:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								goto IL_043b;
								IL_043b:
								array[num4 - 2] = 0;
								goto IL_044f;
								IL_044f:
								num4--;
								goto IL_0286;
								IL_0462:
								if (1 >= b)
								{
									goto IL_0470;
								}
								goto IL_06c4;
								IL_0470:
								if (1 > b)
								{
								}
								goto IL_06c4;
								IL_0483:
								array[num4] = 0;
								num = 88;
								goto IL_049a;
								IL_049a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
								goto IL_04bd;
								IL_04bd:
								array2[num4] = null;
								goto IL_04c7;
								IL_04c7:
								num4++;
								goto IL_04d5;
								IL_04d5:
								ptr += 8;
								goto IL_0286;
								IL_04e8:
								if (7 >= b)
								{
									goto IL_04f6;
								}
								goto IL_05d8;
								IL_04f6:
								if (7 > b)
								{
									goto IL_0504;
								}
								num = 13;
								goto IL_0590;
								IL_0504:
								if (6 >= b)
								{
									goto IL_0512;
								}
								goto IL_06c4;
								IL_0512:
								if (6 <= b)
								{
									goto IL_0520;
								}
								goto IL_06c4;
								IL_0520:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								goto IL_0560;
								IL_0560:
								array[num4 - 2] = 0;
								goto IL_0574;
								IL_0574:
								num4--;
								goto IL_0286;
								IL_06b1:
								ptr += 8;
								goto IL_0286;
								IL_0590:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
								goto IL_05a9;
								IL_05a9:
								array[num4] = 0;
								goto IL_05b7;
								IL_05b7:
								num4++;
								goto IL_05c5;
								IL_05c5:
								ptr += 8;
								goto IL_0286;
								IL_05d8:
								if (8 >= b)
								{
									goto IL_05e3;
								}
								goto IL_0658;
								IL_05e3:
								if (8 <= b)
								{
									goto IL_05f1;
								}
								goto IL_06c4;
								IL_05f1:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
								goto IL_0631;
								IL_0631:
								array[num4 - 2] = 0;
								goto IL_0645;
								IL_0645:
								num4--;
								goto IL_0286;
								IL_0658:
								if (9 >= b)
								{
									goto IL_0663;
								}
								goto IL_06c4;
								IL_0663:
								if (9 <= b)
								{
									goto IL_066e;
								}
								goto IL_06c4;
								IL_066e:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0286;
								continue;
								end_IL_01cb:
								break;
							}
							continue;
							end_IL_01db:
							break;
						}
						continue;
						end_IL_01f4:
						break;
					}
					continue;
					end_IL_020d:
					break;
				}
				continue;
				end_IL_0218:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 6;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UIntPtrArrayTypeInfoCanSkipCSEvaluation.BestFitMappingAttributeIMuiResourceMapEntry);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_023c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_021c:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_020f:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_01ff:
																							if (9 < b)
																							{
																								while (10 >= b)
																								{
																									while (10 <= b)
																									{
																										num = 107;
																										while (num != 107 && num == 1088)
																										{
																											switch (num)
																											{
																											case 16:
																												goto IL_01dc;
																											case 7:
																												goto IL_01ef;
																											case 35:
																												goto IL_01ff;
																											case 33:
																											case 96:
																												goto IL_020f;
																											case 78:
																												goto IL_021c;
																											case 63:
																												goto IL_022c;
																											case 76:
																												goto IL_023c;
																											case 77:
																												goto end_IL_023c;
																											case 21:
																											case 24:
																												goto end_IL_024c;
																											case 10:
																												goto IL_0267;
																											case 30:
																												goto IL_0275;
																											case 86:
																												goto IL_0283;
																											case 37:
																											case 45:
																												goto IL_0291;
																											case 27:
																												goto IL_02da;
																											case 50:
																												goto IL_02f7;
																											case 95:
																												goto IL_0313;
																											case 92:
																												goto IL_0321;
																											case 34:
																											case 71:
																												goto IL_032f;
																											case 47:
																											case 97:
																												goto IL_0354;
																											case 56:
																												goto IL_03bf;
																											case 100:
																												goto IL_03d2;
																											case 43:
																												goto IL_03e0;
																											case 23:
																												goto IL_03ee;
																											case 75:
																												goto IL_040a;
																											case 12:
																											case 67:
																												goto IL_0418;
																											case 66:
																												goto IL_043d;
																											case 52:
																												goto IL_044b;
																											case 46:
																												goto IL_0459;
																											case 79:
																											case 93:
																												goto IL_0464;
																											case 42:
																												goto IL_048d;
																											case 20:
																												goto IL_049b;
																											case 49:
																												goto IL_04ae;
																											case 32:
																												goto IL_04bc;
																											case 72:
																											case 82:
																												goto IL_04ca;
																											case 11:
																												goto IL_04e3;
																											case 29:
																												goto IL_04f1;
																											case 98:
																												goto IL_0508;
																											case 36:
																												goto IL_051b;
																											case 48:
																											case 69:
																												goto IL_0526;
																											case 0:
																												goto IL_0534;
																											case 15:
																												goto IL_054d;
																											case 44:
																											case 62:
																												goto IL_0558;
																											case 1:
																											case 83:
																												goto IL_056d;
																											case 39:
																												goto IL_057b;
																											case 80:
																												goto IL_059e;
																											case 38:
																												goto IL_05a8;
																											case 99:
																												goto IL_05b6;
																											case 2:
																											case 8:
																											case 13:
																											case 14:
																											case 19:
																											case 25:
																											case 28:
																											case 40:
																											case 53:
																											case 54:
																											case 65:
																											case 68:
																											case 74:
																											case 81:
																											case 87:
																											case 88:
																											case 91:
																												goto end_IL_01c9;
																											case 3:
																											case 9:
																											case 18:
																											case 41:
																											case 51:
																											case 55:
																											case 57:
																											case 59:
																											case 60:
																											case 84:
																											case 85:
																											case 89:
																											case 94:
																												goto end_IL_025c;
																											case 61:
																												goto end_IL_05d9;
																											case 58:
																												goto end_IL_05ec;
																											case 22:
																												goto end_IL_05f6;
																											case 64:
																												goto end_IL_0601;
																											case 70:
																											case 90:
																												goto end_IL_0616;
																											case 73:
																												goto end_IL_0626;
																											case 26:
																											case 31:
																												goto end_IL_0636;
																											case 5:
																												goto end_IL_0646;
																											case 6:
																												goto end_IL_0656;
																											case 4:
																											case 17:
																												goto IL_0671;
																											}
																											continue;
																											end_IL_01c9:
																											break;
																										}
																										break;
																										IL_01dc:;
																									}
																									break;
																									IL_01ef:;
																								}
																								break;
																							}
																							num = 75;
																							goto IL_040a;
																							IL_040a:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0418;
																							IL_0418:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							num = 9;
																							goto end_IL_025c;
																						}
																						break;
																					}
																					goto IL_0267;
																					IL_03bf:
																					num6 -= 2;
																					goto end_IL_025c;
																					IL_0267:
																					if (8 > b)
																					{
																						goto IL_0275;
																					}
																					goto IL_0354;
																					IL_0275:
																					if (6 >= b)
																					{
																						goto IL_0283;
																					}
																					goto IL_0313;
																					IL_0283:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0291;
																					IL_0291:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 27;
																					goto IL_02da;
																					IL_02da:
																					array[num6 - 2] = 0;
																					num = 50;
																					goto IL_02f7;
																					IL_02f7:
																					num6--;
																					num = 89;
																					goto end_IL_025c;
																					IL_0313:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0321;
																					IL_0321:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_032f;
																					IL_032f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03d2;
																					IL_03d2:
																					array[num6] = 0;
																					goto IL_03e0;
																					IL_03e0:
																					num6++;
																					goto IL_03ee;
																					IL_03ee:
																					ptr2 += 8;
																					goto end_IL_025c;
																					IL_0354:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 56;
																					goto IL_03bf;
																				}
																				break;
																			}
																			goto IL_043d;
																			IL_05a8:
																			num6++;
																			goto IL_05b6;
																			IL_043d:
																			if (5 > b)
																			{
																				goto IL_044b;
																			}
																			goto IL_056d;
																			IL_044b:
																			if (2 >= b)
																			{
																				goto IL_0459;
																			}
																			goto IL_051b;
																			IL_0459:
																			if (2 <= b)
																			{
																				goto IL_0464;
																			}
																			goto IL_04ae;
																			IL_0464:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_048d;
																			IL_048d:
																			ptr2 += 8;
																			goto IL_049b;
																			IL_049b:
																			num6--;
																			goto end_IL_025c;
																			IL_04ae:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04bc;
																			IL_04bc:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04ca;
																			IL_04ca:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_04e3;
																			IL_04e3:
																			array[num6] = 0;
																			goto IL_04f1;
																			IL_04f1:
																			num6++;
																			num = 98;
																			goto IL_0508;
																			IL_0508:
																			ptr2 += 8;
																			goto end_IL_025c;
																			IL_051b:
																			if (3 < b)
																			{
																				goto IL_0526;
																			}
																			goto IL_054d;
																			IL_0526:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0534;
																			IL_0534:
																			if (4 <= b)
																			{
																				goto end_IL_025c;
																			}
																			num = 2;
																			break;
																			IL_05b6:
																			ptr2 += 8;
																			goto end_IL_025c;
																			IL_054d:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0558;
																			IL_0558:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_025c;
																			IL_056d:
																			array[num6] = 0;
																			goto IL_057b;
																			IL_057b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_059e;
																			IL_059e:
																			array2[num6] = null;
																			goto IL_05a8;
																		}
																		break;
																		IL_022c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_025c;
																continue;
																end_IL_023c:
																break;
															}
															continue;
															end_IL_024c:
															break;
														}
														continue;
														end_IL_025c:
														break;
													}
													continue;
												}
												goto IL_0671;
												IL_0671:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05d9:
												break;
											}
											continue;
											end_IL_05ec:
											break;
										}
										continue;
										end_IL_05f6:
										break;
									}
									continue;
									end_IL_0601:
									break;
								}
								continue;
								end_IL_0616:
								break;
							}
							continue;
							end_IL_0626:
							break;
						}
						continue;
						end_IL_0636:
						break;
					}
					continue;
					end_IL_0646:
					break;
				}
				continue;
				end_IL_0656:
				break;
			}
		}
	}

	private static int smethod_7(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 616;
		num2 = 88;
		return num + 88;
	}

	static Class196()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 3;
					while (true)
					{
						num = 4;
						while (true)
						{
							num = 13;
							while (true)
							{
								if (num != 13)
								{
									if (num != 994)
									{
										break;
									}
									switch (num)
									{
									case 4:
										goto end_IL_003d;
									case 0:
									case 3:
										goto end_IL_004a;
									case 1:
										goto end_IL_0056;
									case 5:
										goto end_IL_0065;
									case 6:
										goto end_IL_0071;
									case 2:
										return;
									}
									continue;
								}
								return;
								continue;
								end_IL_003d:
								break;
							}
							continue;
							end_IL_004a:
							break;
						}
						continue;
						end_IL_0056:
						break;
					}
					continue;
					end_IL_0065:
					break;
				}
				continue;
				end_IL_0071:
				break;
			}
		}
	}
}
