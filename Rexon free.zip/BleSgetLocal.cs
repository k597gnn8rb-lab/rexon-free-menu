using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1)]
internal struct BleSgetLocal
{
	internal static BleSgetLocal IContributeDynamicSinkServerContextTerminatorSink/* Not supported: data(01) */;
}
