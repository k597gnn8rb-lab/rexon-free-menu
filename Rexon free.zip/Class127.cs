using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Critter Size: 1.00", "Settings", "Click to adjust critter size.", false, 18, ModType.const_1, false)]
internal class Class127 : MonoBehaviour
{
	public static float float_0;

	public static int int_0;

	private static float[] float_1;

	private static int int_1;

	private static bool bool_0;

	private static float float_2;

	private static bool bool_1;

	private static float float_3;

	private static int int_2;

	private static float float_4;

	private static IntPtr[] AppendCharTimeoutHelper;

	private static IntPtr[] setNumberGroupSizesgetCurrentUICulture;

	private static IntPtr[] CreatorOwnerServerSidHasCreationContext;

	private static IntPtr[] CreateOriginSchemeAccessgetShortestDayNames;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_04cf, IL_04e2, IL_04f5, IL_0505, IL_0512, IL_0522, IL_0532, IL_0542, IL_0552, IL_0562, IL_0572, IL_057d, IL_058d, IL_05a0, IL_05ab, IL_05be, IL_05d1, IL_05e1, IL_05ef, IL_060c, IL_064c, IL_0660, IL_0673, IL_0681, IL_068c, IL_06ba, IL_06c8, IL_06d6, IL_06ee, IL_06fc, IL_070a, IL_071d, IL_0728, IL_0736, IL_0752, IL_0760, IL_0773, IL_078d, IL_07a0, IL_07ae, IL_07c1, IL_07cc, IL_07f5, IL_0803, IL_0816, IL_0824, IL_082f, IL_083d, IL_084b, IL_0859, IL_086c, IL_087a, IL_088d, IL_0896, IL_08aa, IL_0928, IL_0936, IL_0949, IL_0957, IL_0965, IL_0979, IL_09c5, IL_09d3, IL_09e6, IL_09f4, IL_0a10, IL_0a1e, IL_0a29, IL_0a43, IL_0a56, IL_0a64, IL_0a6f, IL_0a7d, IL_0a8b, IL_0ad2, IL_0ae5, IL_0af9, IL_0b3a, IL_0b4d, IL_0b5b, IL_0b69, IL_0b8d, IL_0b9b, IL_0ba9, IL_0bc5, IL_0bd3, IL_0bde, IL_0bec, IL_0bfa, IL_0c21, IL_0c2f, IL_0c3d, IL_0c59, IL_0c62, IL_0c8c, IL_0ca5, IL_0cb0, IL_0cbe, IL_0ce9, IL_0d02, IL_0d10, IL_0d1e, IL_0d62, IL_0d76, IL_0d89, IL_0d94, IL_0d9d, IL_0ddd, IL_0df1, IL_0e04, IL_0e12, IL_0e20, IL_0e60, IL_0e74, IL_0e90, IL_0e99, IL_0ea4, IL_0eb2, IL_0ed5, IL_0edf, IL_0eed, IL_0f00, IL_0f0e, IL_0f19, IL_0f59, IL_0f6d, IL_0f80, IL_0f8e, IL_0f9c, IL_0fb5, IL_0fc3, IL_0fd1, IL_0fe4, IL_0ff2, IL_1000, IL_1029, IL_1037, IL_104a, IL_1058, IL_1066, IL_1074, IL_107f, IL_10e1, IL_10f4, IL_1102, IL_1110, IL_1150, IL_1164, IL_1177, IL_1185, IL_1193, IL_119c, IL_11b0, IL_1204, IL_1212, IL_1225, IL_1233, IL_1241, IL_124f, IL_125d, IL_127a, IL_12c9, IL_12d3, IL_1300, IL_1314, IL_1322, IL_133e, IL_135c, IL_136a, IL_137d, IL_1388, IL_1396, IL_13bf, IL_13d8, IL_13e6, IL_13f4, IL_140c, IL_1433, IL_1457, IL_146f, IL_147f, IL_1492, IL_14a5, IL_14af, IL_14ba, IL_14ca, IL_14da, IL_14ea, IL_14fa, IL_150a, IL_151a, IL_152a, IL_153a, IL_1555 are reachable both inside and outside the pinned region starting at IL_154f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef39 = default(int);
			ref int reference = ref __rxRef39;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_153a:
					num2 = 1;
					while (true)
					{
						IL_152a:
						num3 = num2 * 4;
						while (true)
						{
							IL_151a:
							array2 = new byte[4];
							while (true)
							{
								IL_150a:
								array3 = new object[4];
								while (true)
								{
									IL_14fa:
									array4 = new int[4];
									while (true)
									{
										IL_14ea:
										array5 = new int[6];
										while (true)
										{
											IL_14da:
											array6 = new long[4];
											while (true)
											{
												IL_14ca:
												array7 = new object[14];
												while (true)
												{
													IL_14ba:
													array7[0] = this;
													while (true)
													{
														IL_14af:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DateTimeStylesIEnumSTOREASSEMBLY.getOriginalExceptionTOKENSTATISTICS);
														while (true)
														{
															IL_14a5:
															ptr2 = ptr;
															while (true)
															{
																IL_1492:
																if (num4 != 1)
																{
																	while (true)
																	{
																		IL_0572:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0562:
																			ptr2++;
																			while (true)
																			{
																				IL_0552:
																				if (b >= 1)
																				{
																					while (b <= 34)
																					{
																						while (true)
																						{
																							IL_0532:
																							if (17 >= b)
																							{
																								num = 99;
																								while (true)
																								{
																									IL_0522:
																									if (17 > b)
																									{
																										while (true)
																										{
																											IL_0512:
																											if (8 >= b)
																											{
																												while (true)
																												{
																													IL_0505:
																													if (8 > b)
																													{
																														while (true)
																														{
																															if (4 < b)
																															{
																																while (true)
																																{
																																	IL_04e2:
																																	if (6 >= b)
																																	{
																																		num = 297;
																																		while (true)
																																		{
																																			if (num != 297)
																																			{
																																				if (num != 1278)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 32:
																																					break;
																																				default:
																																					continue;
																																				case 36:
																																					goto IL_04e2;
																																				case 227:
																																					goto end_IL_04cf;
																																				case 95:
																																					goto IL_0505;
																																				case 235:
																																					goto IL_0512;
																																				case 99:
																																					goto IL_0522;
																																				case 252:
																																					goto IL_0532;
																																				case 129:
																																					goto IL_0542;
																																				case 93:
																																					goto IL_0552;
																																				case 72:
																																					goto IL_0562;
																																				case 262:
																																				case 281:
																																					goto IL_0572;
																																				case 14:
																																					goto IL_057d;
																																				case 2:
																																				case 177:
																																					goto IL_058d;
																																				case 185:
																																					goto IL_05a0;
																																				case 182:
																																					goto IL_05ab;
																																				case 156:
																																					goto IL_05be;
																																				case 211:
																																					goto IL_05d1;
																																				case 39:
																																				case 223:
																																					goto IL_05e1;
																																				case 88:
																																					goto IL_05ef;
																																				case 38:
																																				case 236:
																																					goto IL_060c;
																																				case 37:
																																					goto IL_064c;
																																				case 90:
																																					goto IL_0660;
																																				case 249:
																																					goto IL_0673;
																																				case 18:
																																					goto IL_0681;
																																				case 108:
																																				case 161:
																																					goto IL_068c;
																																				case 33:
																																					goto IL_06ba;
																																				case 238:
																																					goto IL_06c8;
																																				case 46:
																																				case 107:
																																					goto IL_06d6;
																																				case 225:
																																					goto IL_06ee;
																																				case 112:
																																					goto IL_06fc;
																																				case 135:
																																					goto IL_070a;
																																				case 164:
																																					goto IL_071d;
																																				case 134:
																																					goto IL_0728;
																																				case 69:
																																				case 199:
																																					goto IL_0736;
																																				case 0:
																																					goto IL_0752;
																																				case 98:
																																					goto IL_0760;
																																				case 206:
																																				case 259:
																																					goto IL_0773;
																																				case 196:
																																					goto IL_078d;
																																				case 267:
																																					goto IL_07a0;
																																				case 40:
																																					goto IL_07ae;
																																				case 272:
																																					goto IL_07c1;
																																				case 4:
																																				case 122:
																																					goto IL_07cc;
																																				case 28:
																																					goto IL_07f5;
																																				case 89:
																																					goto IL_0803;
																																				case 106:
																																					goto IL_0816;
																																				case 150:
																																					goto IL_0824;
																																				case 195:
																																					goto IL_082f;
																																				case 34:
																																					goto IL_083d;
																																				case 151:
																																				case 245:
																																					goto IL_084b;
																																				case 197:
																																					goto IL_0859;
																																				case 188:
																																					goto IL_086c;
																																				case 190:
																																					goto IL_087a;
																																				case 47:
																																				case 226:
																																					goto IL_0896;
																																				case 57:
																																					goto IL_08aa;
																																				case 133:
																																					goto IL_0928;
																																				case 241:
																																					goto IL_0936;
																																				case 166:
																																					goto IL_0949;
																																				case 180:
																																					goto IL_0957;
																																				case 202:
																																				case 239:
																																					goto IL_0965;
																																				case 62:
																																					goto IL_0979;
																																				case 85:
																																					goto IL_09c5;
																																				case 128:
																																					goto IL_09d3;
																																				case 278:
																																					goto IL_09e6;
																																				case 8:
																																					goto IL_09f4;
																																				case 289:
																																					goto IL_0a10;
																																				case 68:
																																					goto IL_0a1e;
																																				case 84:
																																				case 279:
																																					goto IL_0a29;
																																				case 176:
																																					goto IL_0a43;
																																				case 7:
																																					goto IL_0a56;
																																				case 148:
																																					goto IL_0a64;
																																				case 154:
																																					goto IL_0a6f;
																																				case 81:
																																					goto IL_0a7d;
																																				case 132:
																																				case 179:
																																					goto IL_0a8b;
																																				case 169:
																																					goto IL_0ad2;
																																				case 5:
																																				case 287:
																																					goto IL_0ae5;
																																				case 77:
																																					goto IL_0af9;
																																				case 83:
																																					goto IL_0b3a;
																																				case 144:
																																					goto IL_0b4d;
																																				case 126:
																																					goto IL_0b5b;
																																				case 45:
																																				case 273:
																																					goto IL_0b69;
																																				case 145:
																																					goto IL_0b8d;
																																				case 234:
																																					goto IL_0b9b;
																																				case 255:
																																					goto IL_0ba9;
																																				case 91:
																																					goto IL_0bc5;
																																				case 204:
																																					goto IL_0bd3;
																																				case 191:
																																					goto IL_0bde;
																																				case 171:
																																					goto IL_0bec;
																																				case 71:
																																				case 264:
																																					goto IL_0bfa;
																																				case 229:
																																					goto IL_0c21;
																																				case 175:
																																					goto IL_0c2f;
																																				case 139:
																																					goto IL_0c3d;
																																				case 75:
																																				case 215:
																																					goto IL_0c62;
																																				case 42:
																																					goto IL_0c8c;
																																				case 290:
																																					goto IL_0ca5;
																																				case 82:
																																					goto IL_0cb0;
																																				case 101:
																																				case 257:
																																					goto IL_0cbe;
																																				case 247:
																																					goto IL_0ce9;
																																				case 13:
																																					goto IL_0d02;
																																				case 55:
																																					goto IL_0d10;
																																				case 60:
																																				case 192:
																																					goto IL_0d1e;
																																				case 186:
																																					goto IL_0d62;
																																				case 143:
																																					goto IL_0d76;
																																				case 109:
																																				case 244:
																																					goto IL_0d9d;
																																				case 254:
																																					goto IL_0ddd;
																																				case 105:
																																					goto IL_0df1;
																																				case 212:
																																					goto IL_0e04;
																																				case 276:
																																					goto IL_0e12;
																																				case 114:
																																				case 123:
																																					goto IL_0e20;
																																				case 121:
																																					goto IL_0e60;
																																				case 120:
																																					goto IL_0e74;
																																				case 97:
																																					goto IL_0e99;
																																				case 51:
																																				case 189:
																																					goto IL_0ea4;
																																				case 61:
																																					goto IL_0eb2;
																																				case 275:
																																					goto IL_0ed5;
																																				case 242:
																																					goto IL_0edf;
																																				case 270:
																																					goto IL_0eed;
																																				case 237:
																																					goto IL_0f00;
																																				case 25:
																																					goto IL_0f0e;
																																				case 125:
																																				case 213:
																																					goto IL_0f19;
																																				case 258:
																																					goto IL_0f59;
																																				case 210:
																																					goto IL_0f6d;
																																				case 178:
																																					goto IL_0f80;
																																				case 22:
																																					goto IL_0f8e;
																																				case 153:
																																				case 155:
																																					goto IL_0f9c;
																																				case 11:
																																					goto IL_0fb5;
																																				case 183:
																																					goto IL_0fc3;
																																				case 76:
																																					goto IL_0fd1;
																																				case 222:
																																					goto IL_0fe4;
																																				case 73:
																																					goto IL_0ff2;
																																				case 17:
																																				case 111:
																																					goto IL_1000;
																																				case 49:
																																					goto IL_1029;
																																				case 266:
																																					goto IL_1037;
																																				case 119:
																																					goto IL_104a;
																																				case 52:
																																					goto IL_1058;
																																				case 214:
																																					goto IL_1066;
																																				case 248:
																																					goto IL_1074;
																																				case 21:
																																				case 280:
																																					goto IL_107f;
																																				case 268:
																																					goto IL_10e1;
																																				case 232:
																																					goto IL_10f4;
																																				case 50:
																																					goto IL_1102;
																																				case 103:
																																				case 170:
																																					goto IL_1110;
																																				case 224:
																																					goto IL_1150;
																																				case 165:
																																					goto IL_1164;
																																				case 35:
																																					goto IL_1177;
																																				case 137:
																																					goto IL_1185;
																																				case 87:
																																				case 288:
																																					goto IL_119c;
																																				case 64:
																																					goto IL_11b0;
																																				case 158:
																																					goto IL_1204;
																																				case 147:
																																					goto IL_1212;
																																				case 29:
																																					goto IL_1225;
																																				case 146:
																																					goto IL_1233;
																																				case 10:
																																					goto IL_1241;
																																				case 58:
																																					goto IL_124f;
																																				case 59:
																																				case 271:
																																					goto IL_125d;
																																				case 173:
																																					goto IL_1314;
																																				case 19:
																																					goto IL_1322;
																																				case 220:
																																				case 284:
																																					goto IL_133e;
																																				case 260:
																																					goto IL_135c;
																																				case 26:
																																					goto IL_136a;
																																				case 160:
																																					goto IL_137d;
																																				case 65:
																																					goto IL_1388;
																																				case 20:
																																				case 92:
																																					goto IL_1396;
																																				case 94:
																																					goto IL_13bf;
																																				case 265:
																																					goto IL_13d8;
																																				case 141:
																																					goto IL_13e6;
																																				case 12:
																																				case 66:
																																					goto IL_13f4;
																																				case 194:
																																					goto IL_140c;
																																				case 174:
																																					goto IL_1433;
																																				case 217:
																																					goto IL_1457;
																																				case 163:
																																					goto IL_146f;
																																				case 3:
																																				case 9:
																																				case 30:
																																				case 41:
																																				case 48:
																																				case 53:
																																				case 56:
																																				case 63:
																																				case 70:
																																				case 80:
																																				case 86:
																																				case 96:
																																				case 100:
																																				case 102:
																																				case 113:
																																				case 116:
																																				case 117:
																																				case 127:
																																				case 131:
																																				case 136:
																																				case 140:
																																				case 142:
																																				case 162:
																																				case 168:
																																				case 172:
																																				case 184:
																																				case 200:
																																				case 203:
																																				case 205:
																																				case 218:
																																				case 221:
																																				case 233:
																																				case 243:
																																				case 251:
																																				case 256:
																																				case 263:
																																				case 285:
																																					goto end_IL_0542;
																																				case 6:
																																				case 15:
																																				case 16:
																																				case 23:
																																				case 24:
																																				case 27:
																																				case 44:
																																				case 54:
																																				case 67:
																																				case 74:
																																				case 78:
																																				case 104:
																																				case 110:
																																				case 115:
																																				case 118:
																																				case 124:
																																				case 130:
																																				case 138:
																																				case 149:
																																				case 152:
																																				case 159:
																																				case 181:
																																				case 193:
																																				case 201:
																																				case 207:
																																				case 208:
																																				case 216:
																																				case 219:
																																				case 228:
																																				case 230:
																																				case 231:
																																				case 246:
																																				case 250:
																																				case 269:
																																				case 277:
																																				case 283:
																																				case 286:
																																					goto IL_1492;
																																				case 79:
																																					goto IL_14a5;
																																				case 157:
																																					goto IL_14af;
																																				case 240:
																																					goto IL_14ba;
																																				case 198:
																																					goto IL_14ca;
																																				case 1:
																																					goto IL_14da;
																																				case 274:
																																					goto IL_14ea;
																																				case 167:
																																					goto IL_14fa;
																																				case 43:
																																					goto IL_150a;
																																				case 261:
																																				case 282:
																																					goto IL_151a;
																																				case 253:
																																					goto IL_152a;
																																				case 31:
																																					goto IL_153a;
																																				case 187:
																																				case 209:
																																					return;
																																				}
																																				goto end_IL_04f5;
																																			}
																																			if (6 <= b)
																																			{
																																				num = 109;
																																				goto IL_0d9d;
																																			}
																																			goto IL_0e04;
																																			IL_0e12:
																																			if (5 > b)
																																			{
																																				goto end_IL_0542;
																																			}
																																			goto IL_0e20;
																																			IL_0e60:
																																			array2[num5 - 2] = 0;
																																			goto IL_0e74;
																																			IL_0e20:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																			goto IL_0e60;
																																			IL_0e74:
																																			num5--;
																																			num = 228;
																																			goto IL_1492;
																																			IL_0d9d:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																			goto IL_0ddd;
																																			IL_0ddd:
																																			array2[num5 - 2] = 0;
																																			goto IL_0df1;
																																			IL_0df1:
																																			num5--;
																																			goto IL_1492;
																																			IL_0e04:
																																			if (5 < b)
																																			{
																																				goto end_IL_0542;
																																			}
																																			goto IL_0e12;
																																			continue;
																																			end_IL_04cf:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_057d;
																																	IL_064c:
																																	array2[num5 - 2] = 0;
																																	goto IL_0660;
																																	IL_0660:
																																	num5--;
																																	goto IL_1492;
																																	IL_057d:
																																	if (7 < b)
																																	{
																																		goto end_IL_0542;
																																	}
																																	goto IL_05d1;
																																	IL_05d1:
																																	if (7 > b)
																																	{
																																		goto end_IL_0542;
																																	}
																																	goto IL_060c;
																																	IL_060c:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																	goto IL_064c;
																																}
																																continue;
																															}
																															num = 97;
																															goto IL_0e99;
																															IL_1029:
																															ptr2 += 8;
																															goto IL_1037;
																															IL_1037:
																															num5--;
																															goto IL_1492;
																															IL_0e99:
																															if (4 <= b)
																															{
																																goto IL_0ea4;
																															}
																															goto IL_0f00;
																															IL_0ea4:
																															array2[num5] = 0;
																															goto IL_0eb2;
																															IL_0eb2:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																															goto IL_0ed5;
																															IL_0ed5:
																															array3[num5] = null;
																															goto IL_0edf;
																															IL_0edf:
																															num5++;
																															goto IL_0eed;
																															IL_0eed:
																															ptr2 += 8;
																															goto IL_1492;
																															IL_0f00:
																															if (2 >= b)
																															{
																																goto IL_0f0e;
																															}
																															goto IL_0fe4;
																															IL_0f0e:
																															if (2 <= b)
																															{
																																goto IL_0f19;
																															}
																															goto IL_0f80;
																															IL_0f19:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															goto IL_0f59;
																															IL_0f59:
																															array2[num5 - 2] = 0;
																															goto IL_0f6d;
																															IL_0f6d:
																															num5--;
																															goto IL_1492;
																															IL_0f80:
																															if (1 < b)
																															{
																																goto end_IL_0542;
																															}
																															goto IL_0f8e;
																															IL_0f8e:
																															if (1 > b)
																															{
																																goto end_IL_0542;
																															}
																															goto IL_0f9c;
																															IL_0f9c:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																															goto IL_0fb5;
																															IL_0fb5:
																															array2[num5] = 0;
																															goto IL_0fc3;
																															IL_0fc3:
																															num5++;
																															goto IL_0fd1;
																															IL_0fd1:
																															ptr2 += 8;
																															goto IL_1492;
																															IL_0fe4:
																															if (3 < b)
																															{
																																goto end_IL_0542;
																															}
																															goto IL_0ff2;
																															IL_0ff2:
																															if (3 > b)
																															{
																																goto end_IL_0542;
																															}
																															goto IL_1000;
																															IL_1000:
																															reference = ref array5[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															goto IL_1029;
																															continue;
																															end_IL_04f5:
																															break;
																														}
																														break;
																													}
																													goto IL_058d;
																													IL_058d:
																													num5--;
																													goto IL_1492;
																												}
																												break;
																											}
																											goto IL_104a;
																											IL_13f4:
																											array2[num5] = array2[num5 - 1];
																											goto IL_140c;
																											IL_104a:
																											if (12 >= b)
																											{
																												goto IL_1058;
																											}
																											goto IL_1225;
																											IL_1058:
																											if (12 <= b)
																											{
																												goto IL_1492;
																											}
																											goto IL_1066;
																											IL_1066:
																											if (10 >= b)
																											{
																												goto IL_1074;
																											}
																											goto IL_1177;
																											IL_1074:
																											if (10 <= b)
																											{
																												goto IL_107f;
																											}
																											goto IL_10f4;
																											IL_107f:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_10e1;
																											IL_10e1:
																											num5 -= 2;
																											goto IL_1492;
																											IL_10f4:
																											if (9 < b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_1102;
																											IL_1102:
																											if (9 > b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_1110;
																											IL_1110:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_1150;
																											IL_1150:
																											array2[num5 - 2] = 0;
																											goto IL_1164;
																											IL_1164:
																											num5--;
																											goto IL_1492;
																											IL_1177:
																											if (11 < b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_1185;
																											IL_1185:
																											if (11 > b)
																											{
																												goto end_IL_0542;
																											}
																											num = 87;
																											goto IL_119c;
																											IL_140c:
																											array4[num5 - 0] = array4[num5 - 1];
																											num = 174;
																											goto IL_1433;
																											IL_119c:
																											array2[num5 - 2] = 0;
																											goto IL_11b0;
																											IL_11b0:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																											goto IL_1204;
																											IL_1204:
																											num5--;
																											goto IL_1212;
																											IL_1212:
																											ptr2 += 8;
																											goto IL_1492;
																											IL_1225:
																											if (14 >= b)
																											{
																												goto IL_1233;
																											}
																											goto IL_137d;
																											IL_1233:
																											if (14 > b)
																											{
																												goto IL_1241;
																											}
																											goto IL_133e;
																											IL_1241:
																											if (13 < b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_124f;
																											IL_124f:
																											if (13 > b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_125d;
																											IL_125d:
																											array8 = array3;
																											num6 = num5;
																											if (array == null)
																											{
																												goto IL_126c;
																											}
																											num7 = ptr2;
																											byte b2 = *num7;
																											ptr2 = num7 + 4;
																											int num8 = *(int*)(ptr2 + num3);
																											ptr2 += 8;
																											byte* ptr3 = ptr2 + num8;
																											byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																											while (ptr2 != ptr3)
																											{
																												*ptr4 = (byte)(*ptr2 ^ b2);
																												ptr2++;
																												ptr4++;
																											}
																											array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																											goto IL_1314;
																											IL_1433:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_1457;
																											IL_1457:
																											array3[num5] = array3[num5 - 1];
																											goto IL_146f;
																											IL_146f:
																											num5++;
																											goto IL_1492;
																											IL_1314:
																											array2[num5] = 5;
																											goto IL_1322;
																											IL_1322:
																											num5++;
																											num = 78;
																											goto IL_1492;
																											IL_133e:
																											array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																											goto IL_135c;
																											IL_135c:
																											ptr2 += 8;
																											goto IL_136a;
																											IL_136a:
																											num5--;
																											goto IL_1492;
																											IL_137d:
																											if (15 >= b)
																											{
																												goto IL_1388;
																											}
																											goto IL_13d8;
																											IL_1388:
																											if (15 > b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_1396;
																											IL_1396:
																											array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																											goto IL_13bf;
																											IL_13bf:
																											array2[num5 - 1] = 5;
																											goto IL_1492;
																											IL_13d8:
																											if (16 < b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_13e6;
																											IL_13e6:
																											if (16 > b)
																											{
																												goto end_IL_0542;
																											}
																											goto IL_13f4;
																										}
																										break;
																									}
																									goto IL_05e1;
																									IL_07ae:
																									ptr2 += 8;
																									goto IL_1492;
																									IL_05e1:
																									array2[num5] = 5;
																									goto IL_05ef;
																									IL_05ef:
																									array3[num5] = array7[*(int*)(ptr2 + num3)];
																									goto IL_07a0;
																									IL_07a0:
																									num5++;
																									goto IL_07ae;
																								}
																								break;
																							}
																							goto IL_05a0;
																							IL_0965:
																							array2[num5 - 2] = 5;
																							goto IL_0979;
																							IL_0979:
																							array3[num5 - 2] = ((delegate*<string, string, string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																							goto IL_09c5;
																							IL_05a0:
																							if (26 >= b)
																							{
																								goto IL_05ab;
																							}
																							goto IL_05be;
																							IL_05ab:
																							if (26 <= b)
																							{
																								goto IL_0773;
																							}
																							goto IL_0a10;
																							IL_0773:
																							float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																							goto IL_078d;
																							IL_078d:
																							num5--;
																							goto IL_1492;
																							IL_0a10:
																							if (21 >= b)
																							{
																								goto IL_0a1e;
																							}
																							goto IL_0bc5;
																							IL_0a1e:
																							if (21 <= b)
																							{
																								goto IL_0a29;
																							}
																							goto IL_0a56;
																							IL_0a29:
																							int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0a43;
																							IL_0a43:
																							num5--;
																							goto IL_1492;
																							IL_0a56:
																							if (19 >= b)
																							{
																								goto IL_0a64;
																							}
																							goto IL_0b4d;
																							IL_0a64:
																							if (19 > b)
																							{
																								goto IL_0a6f;
																							}
																							goto IL_0ae5;
																							IL_0a6f:
																							if (18 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0a7d;
																							IL_0a7d:
																							if (18 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0a8b;
																							IL_0a8b:
																							((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																							num = 169;
																							goto IL_0ad2;
																							IL_0ad2:
																							num5 -= 3;
																							goto IL_1492;
																							IL_0ae5:
																							array2[num5 - 1] = 5;
																							goto IL_0af9;
																							IL_0af9:
																							array3[num5 - 1] = ((delegate*<string[], string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																							num = 83;
																							goto IL_0b3a;
																							IL_0b3a:
																							ptr2 += 8;
																							goto IL_1492;
																							IL_0b4d:
																							if (20 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0b5b;
																							IL_0b5b:
																							if (20 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0b69;
																							IL_0b69:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])();
																							goto IL_0b8d;
																							IL_0b8d:
																							array2[num5] = 0;
																							goto IL_0b9b;
																							IL_0b9b:
																							num5++;
																							goto IL_0ba9;
																							IL_0ba9:
																							ptr2 += 8;
																							num = 124;
																							goto IL_1492;
																							IL_0bc5:
																							if (23 >= b)
																							{
																								goto IL_0bd3;
																							}
																							goto IL_0ca5;
																							IL_0bd3:
																							if (23 > b)
																							{
																								goto IL_0bde;
																							}
																							num = 75;
																							goto IL_0c62;
																							IL_0bde:
																							if (22 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0bec;
																							IL_0bec:
																							if (22 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0bfa;
																							IL_0bfa:
																							array3[num5] = ((delegate*<float[]>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])();
																							num = 229;
																							goto IL_0c21;
																							IL_0c21:
																							array2[num5] = 5;
																							goto IL_0c2f;
																							IL_0c2f:
																							num5++;
																							goto IL_0c3d;
																							IL_0c3d:
																							ptr2 += 8;
																							num = 27;
																							goto IL_1492;
																							IL_09c5:
																							num5--;
																							goto IL_09d3;
																							IL_0c62:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
																							goto IL_0c8c;
																							IL_0c8c:
																							array2[num5 - 1] = 2;
																							goto IL_1492;
																							IL_0ca5:
																							if (24 >= b)
																							{
																								goto IL_0cb0;
																							}
																							goto IL_0d02;
																							IL_0cb0:
																							if (24 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0cbe;
																							IL_0cbe:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																							goto IL_0ce9;
																							IL_0ce9:
																							array2[num5 - 1] = 0;
																							goto IL_1492;
																							IL_0d02:
																							if (25 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0d10;
																							IL_0d10:
																							if (25 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0d1e;
																							IL_0d1e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																							goto IL_0d62;
																							IL_0d62:
																							array2[num5 - 2] = 3;
																							goto IL_0d76;
																							IL_0d76:
																							num5--;
																							goto IL_1492;
																							IL_05be:
																							if (30 < b)
																							{
																								goto IL_0673;
																							}
																							goto IL_07c1;
																							IL_0673:
																							if (32 >= b)
																							{
																								goto IL_0681;
																							}
																							goto IL_071d;
																							IL_0681:
																							if (32 <= b)
																							{
																								goto IL_068c;
																							}
																							goto IL_06ba;
																							IL_068c:
																							((delegate*<UnityEngine.Object, void>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((Class127)array3[num5 - 1]);
																							goto IL_09e6;
																							IL_09e6:
																							num5--;
																							goto IL_09f4;
																							IL_09f4:
																							ptr2 += 8;
																							num = 110;
																							goto IL_1492;
																							IL_06ba:
																							if (31 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_06c8;
																							IL_06c8:
																							if (31 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_06d6;
																							IL_06d6:
																							array3[num5] = array7[*(int*)(ptr2 + num3)];
																							goto IL_06ee;
																							IL_06ee:
																							array2[num5] = 5;
																							goto IL_06fc;
																							IL_06fc:
																							num5++;
																							goto IL_070a;
																							IL_070a:
																							ptr2 += 8;
																							goto IL_1492;
																							IL_071d:
																							if (33 >= b)
																							{
																								goto IL_0728;
																							}
																							goto IL_0752;
																							IL_0728:
																							if (33 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0736;
																							IL_0736:
																							num9 = ptr2;
																							num10 = -200;
																							num4 = 1;
																							ptr2 = num9 + num10;
																							goto IL_1492;
																							IL_0752:
																							if (34 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0760;
																							IL_0760:
																							if (34 > b)
																							{
																							}
																							goto end_IL_0542;
																							IL_07c1:
																							if (30 <= b)
																							{
																								goto IL_07cc;
																							}
																							goto IL_0816;
																							IL_07cc:
																							((delegate*<string, void>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																							goto IL_07f5;
																							IL_07f5:
																							num5--;
																							goto IL_0803;
																							IL_0803:
																							ptr2 += 8;
																							goto IL_1492;
																							IL_0816:
																							if (28 >= b)
																							{
																								goto IL_0824;
																							}
																							goto IL_0949;
																							IL_0824:
																							if (28 > b)
																							{
																								goto IL_082f;
																							}
																							num = 226;
																							goto IL_0896;
																							IL_082f:
																							if (27 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_083d;
																							IL_083d:
																							if (27 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_084b;
																							IL_084b:
																							array2[num5] = 15;
																							goto IL_0859;
																							IL_0859:
																							array4[num5] = *(int*)(ptr2 + num3);
																							goto IL_086c;
																							IL_086c:
																							ptr2 += 8;
																							goto IL_087a;
																							IL_087a:
																							num5++;
																							goto IL_1492;
																							IL_09d3:
																							ptr2 += 8;
																							goto IL_1492;
																							IL_0896:
																							array2[num5 - 2] = 5;
																							goto IL_08aa;
																							IL_08aa:
																							array3[num5 - 2] = ((delegate*<ref float, string, string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)AppendCharTimeoutHelper[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																							goto IL_0928;
																							IL_0928:
																							num5--;
																							goto IL_0936;
																							IL_0936:
																							ptr2 += 8;
																							goto IL_1492;
																							IL_0949:
																							if (29 < b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0957;
																							IL_0957:
																							if (29 > b)
																							{
																								goto end_IL_0542;
																							}
																							goto IL_0965;
																						}
																						goto end_IL_0552;
																						continue;
																						end_IL_0542:
																						break;
																						IL_0542:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_1492;
																				continue;
																				end_IL_0552:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 187;
																return;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_126c:
			while (true)
			{
				IL_126c_2:
				array = new byte[4];
				while (true)
				{
					IL_127a:
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_1322_2:
							num5++;
							num = 78;
							while (true)
							{
								IL_1492_2:
								if (num4 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0552_2:
												if (b >= 1)
												{
													while (b <= 34)
													{
														while (true)
														{
															if (17 >= b)
															{
																num = 99;
																while (true)
																{
																	if (17 > b)
																	{
																		while (true)
																		{
																			if (8 >= b)
																			{
																				while (true)
																				{
																					if (8 > b)
																					{
																						while (true)
																						{
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_04e2_2:
																									if (6 >= b)
																									{
																										num = 297;
																										while (true)
																										{
																											if (num != 297)
																											{
																												if (num != 1278)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 36:
																													goto IL_04e2_2;
																												case 227:
																													goto end_IL_04cf_2;
																												case 95:
																													goto end_IL_04f5_2;
																												case 235:
																													goto end_IL_0505;
																												case 99:
																													goto end_IL_0512;
																												case 252:
																													goto end_IL_0522;
																												case 129:
																													goto end_IL_0532;
																												case 93:
																													goto IL_0552_2;
																												case 72:
																													goto end_IL_0552_2;
																												case 262:
																												case 281:
																													goto end_IL_0562;
																												case 14:
																													goto IL_057d_2;
																												case 2:
																												case 177:
																													goto IL_058d_2;
																												case 185:
																													goto IL_05a0_2;
																												case 182:
																													goto IL_05ab_2;
																												case 156:
																													goto IL_05be_2;
																												case 211:
																													goto IL_05d1_2;
																												case 39:
																												case 223:
																													goto IL_05e1_2;
																												case 88:
																													goto IL_05ef_2;
																												case 38:
																												case 236:
																													goto IL_060c_2;
																												case 37:
																													goto IL_064c_2;
																												case 90:
																													goto IL_0660_2;
																												case 249:
																													goto IL_0673_2;
																												case 18:
																													goto IL_0681_2;
																												case 108:
																												case 161:
																													goto IL_068c_2;
																												case 33:
																													goto IL_06ba_2;
																												case 238:
																													goto IL_06c8_2;
																												case 46:
																												case 107:
																													goto IL_06d6_2;
																												case 225:
																													goto IL_06ee_2;
																												case 112:
																													goto IL_06fc_2;
																												case 135:
																													goto IL_070a_2;
																												case 164:
																													goto IL_071d_2;
																												case 134:
																													goto IL_0728_2;
																												case 69:
																												case 199:
																													goto IL_0736_2;
																												case 0:
																													goto IL_0752_2;
																												case 98:
																													goto IL_0760_2;
																												case 206:
																												case 259:
																													goto IL_0773_2;
																												case 196:
																													goto IL_078d_2;
																												case 267:
																													goto IL_07a0_2;
																												case 40:
																													goto IL_07ae_2;
																												case 272:
																													goto IL_07c1_2;
																												case 4:
																												case 122:
																													goto IL_07cc_2;
																												case 28:
																													goto IL_07f5_2;
																												case 89:
																													goto IL_0803_2;
																												case 106:
																													goto IL_0816_2;
																												case 150:
																													goto IL_0824_2;
																												case 195:
																													goto IL_082f_2;
																												case 34:
																													goto IL_083d_2;
																												case 151:
																												case 245:
																													goto IL_084b_2;
																												case 197:
																													goto IL_0859_2;
																												case 188:
																													goto IL_086c_2;
																												case 190:
																													goto IL_087a_2;
																												case 47:
																												case 226:
																													goto IL_0896_2;
																												case 57:
																													goto IL_08aa_2;
																												case 133:
																													goto IL_0928_2;
																												case 241:
																													goto IL_0936_2;
																												case 166:
																													goto IL_0949_2;
																												case 180:
																													goto IL_0957_2;
																												case 202:
																												case 239:
																													goto IL_0965_2;
																												case 62:
																													goto IL_0979_2;
																												case 85:
																													goto IL_09c5_2;
																												case 128:
																													goto IL_09d3_2;
																												case 278:
																													goto IL_09e6_2;
																												case 8:
																													goto IL_09f4_2;
																												case 289:
																													goto IL_0a10_2;
																												case 68:
																													goto IL_0a1e_2;
																												case 84:
																												case 279:
																													goto IL_0a29_2;
																												case 176:
																													goto IL_0a43_2;
																												case 7:
																													goto IL_0a56_2;
																												case 148:
																													goto IL_0a64_2;
																												case 154:
																													goto IL_0a6f_2;
																												case 81:
																													goto IL_0a7d_2;
																												case 132:
																												case 179:
																													goto IL_0a8b_2;
																												case 169:
																													goto IL_0ad2_2;
																												case 5:
																												case 287:
																													goto IL_0ae5_2;
																												case 77:
																													goto IL_0af9_2;
																												case 83:
																													goto IL_0b3a_2;
																												case 144:
																													goto IL_0b4d_2;
																												case 126:
																													goto IL_0b5b_2;
																												case 45:
																												case 273:
																													goto IL_0b69_2;
																												case 145:
																													goto IL_0b8d_2;
																												case 234:
																													goto IL_0b9b_2;
																												case 255:
																													goto IL_0ba9_2;
																												case 91:
																													goto IL_0bc5_2;
																												case 204:
																													goto IL_0bd3_2;
																												case 191:
																													goto IL_0bde_2;
																												case 171:
																													goto IL_0bec_2;
																												case 71:
																												case 264:
																													goto IL_0bfa_2;
																												case 229:
																													goto IL_0c21_2;
																												case 175:
																													goto IL_0c2f_2;
																												case 139:
																													goto IL_0c3d_2;
																												case 75:
																												case 215:
																													goto IL_0c62_2;
																												case 42:
																													goto IL_0c8c_2;
																												case 290:
																													goto IL_0ca5_2;
																												case 82:
																													goto IL_0cb0_2;
																												case 101:
																												case 257:
																													goto IL_0cbe_2;
																												case 247:
																													goto IL_0ce9_2;
																												case 13:
																													goto IL_0d02_2;
																												case 55:
																													goto IL_0d10_2;
																												case 60:
																												case 192:
																													goto IL_0d1e_2;
																												case 186:
																													goto IL_0d62_2;
																												case 143:
																													goto IL_0d76_2;
																												case 109:
																												case 244:
																													goto IL_0d9d_2;
																												case 254:
																													goto IL_0ddd_2;
																												case 105:
																													goto IL_0df1_2;
																												case 212:
																													goto IL_0e04_2;
																												case 276:
																													goto IL_0e12_2;
																												case 114:
																												case 123:
																													goto IL_0e20_2;
																												case 121:
																													goto IL_0e60_2;
																												case 120:
																													goto IL_0e74_2;
																												case 97:
																													goto IL_0e99_2;
																												case 51:
																												case 189:
																													goto IL_0ea4_2;
																												case 61:
																													goto IL_0eb2_2;
																												case 275:
																													goto IL_0ed5_2;
																												case 242:
																													goto IL_0edf_2;
																												case 270:
																													goto IL_0eed_2;
																												case 237:
																													goto IL_0f00_2;
																												case 25:
																													goto IL_0f0e_2;
																												case 125:
																												case 213:
																													goto IL_0f19_2;
																												case 258:
																													goto IL_0f59_2;
																												case 210:
																													goto IL_0f6d_2;
																												case 178:
																													goto IL_0f80_2;
																												case 22:
																													goto IL_0f8e_2;
																												case 153:
																												case 155:
																													goto IL_0f9c_2;
																												case 11:
																													goto IL_0fb5_2;
																												case 183:
																													goto IL_0fc3_2;
																												case 76:
																													goto IL_0fd1_2;
																												case 222:
																													goto IL_0fe4_2;
																												case 73:
																													goto IL_0ff2_2;
																												case 17:
																												case 111:
																													goto IL_1000_2;
																												case 49:
																													goto IL_1029_2;
																												case 266:
																													goto IL_1037_2;
																												case 119:
																													goto IL_104a_2;
																												case 52:
																													goto IL_1058_2;
																												case 214:
																													goto IL_1066_2;
																												case 248:
																													goto IL_1074_2;
																												case 21:
																												case 280:
																													goto IL_107f_2;
																												case 268:
																													goto IL_10e1_2;
																												case 232:
																													goto IL_10f4_2;
																												case 50:
																													goto IL_1102_2;
																												case 103:
																												case 170:
																													goto IL_1110_2;
																												case 224:
																													goto IL_1150_2;
																												case 165:
																													goto IL_1164_2;
																												case 35:
																													goto IL_1177_2;
																												case 137:
																													goto IL_1185_2;
																												case 87:
																												case 288:
																													goto IL_119c_2;
																												case 64:
																													goto IL_11b0_2;
																												case 158:
																													goto IL_1204_2;
																												case 147:
																													goto IL_1212_2;
																												case 29:
																													goto IL_1225_2;
																												case 146:
																													goto IL_1233_2;
																												case 10:
																													goto IL_1241_2;
																												case 58:
																													goto IL_124f_2;
																												case 59:
																												case 271:
																													goto IL_125d_2;
																												case 173:
																													goto end_IL_0572;
																												case 19:
																													goto IL_1322_2;
																												case 220:
																												case 284:
																													goto IL_133e_2;
																												case 260:
																													goto IL_135c_2;
																												case 26:
																													goto IL_136a_2;
																												case 160:
																													goto IL_137d_2;
																												case 65:
																													goto IL_1388_2;
																												case 20:
																												case 92:
																													goto IL_1396_2;
																												case 94:
																													goto IL_13bf_2;
																												case 265:
																													goto IL_13d8_2;
																												case 141:
																													goto IL_13e6_2;
																												case 12:
																												case 66:
																													goto IL_13f4_2;
																												case 194:
																													goto IL_140c_2;
																												case 174:
																													goto IL_1433_2;
																												case 217:
																													goto IL_1457_2;
																												case 163:
																													goto IL_146f_2;
																												case 3:
																												case 9:
																												case 30:
																												case 41:
																												case 48:
																												case 53:
																												case 56:
																												case 63:
																												case 70:
																												case 80:
																												case 86:
																												case 96:
																												case 100:
																												case 102:
																												case 113:
																												case 116:
																												case 117:
																												case 127:
																												case 131:
																												case 136:
																												case 140:
																												case 142:
																												case 162:
																												case 168:
																												case 172:
																												case 184:
																												case 200:
																												case 203:
																												case 205:
																												case 218:
																												case 221:
																												case 233:
																												case 243:
																												case 251:
																												case 256:
																												case 263:
																												case 285:
																													goto end_IL_0542_2;
																												case 6:
																												case 15:
																												case 16:
																												case 23:
																												case 24:
																												case 27:
																												case 44:
																												case 54:
																												case 67:
																												case 74:
																												case 78:
																												case 104:
																												case 110:
																												case 115:
																												case 118:
																												case 124:
																												case 130:
																												case 138:
																												case 149:
																												case 152:
																												case 159:
																												case 181:
																												case 193:
																												case 201:
																												case 207:
																												case 208:
																												case 216:
																												case 219:
																												case 228:
																												case 230:
																												case 231:
																												case 246:
																												case 250:
																												case 269:
																												case 277:
																												case 283:
																												case 286:
																													goto IL_1492_2;
																												case 79:
																													ptr2 = ptr;
																													goto IL_1492_2;
																												case 157:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DateTimeStylesIEnumSTOREASSEMBLY.getOriginalExceptionTOKENSTATISTICS);
																													goto case 79;
																												case 240:
																													array7[0] = this;
																													goto case 157;
																												case 198:
																													array7 = new object[14];
																													goto case 240;
																												case 1:
																													array6 = new long[4];
																													goto case 198;
																												case 274:
																													array5 = new int[6];
																													goto case 1;
																												case 167:
																													array4 = new int[4];
																													goto case 274;
																												case 43:
																													array3 = new object[4];
																													goto case 167;
																												case 261:
																												case 282:
																													array2 = new byte[4];
																													goto case 43;
																												case 253:
																													num3 = num2 * 4;
																													goto case 261;
																												case 31:
																													num2 = 1;
																													goto case 253;
																												case 32:
																													goto end_IL_1314;
																												case 187:
																												case 209:
																													return;
																												}
																												continue;
																											}
																											if (6 <= b)
																											{
																												num = 109;
																												goto IL_0d9d_2;
																											}
																											goto IL_0e04_2;
																											IL_0e12_2:
																											if (5 > b)
																											{
																												goto end_IL_0542_2;
																											}
																											goto IL_0e20_2;
																											IL_0e60_2:
																											array2[num5 - 2] = 0;
																											goto IL_0e74_2;
																											IL_0e20_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0e60_2;
																											IL_0e74_2:
																											num5--;
																											num = 228;
																											goto IL_1492_2;
																											IL_0d9d_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0ddd_2;
																											IL_0ddd_2:
																											array2[num5 - 2] = 0;
																											goto IL_0df1_2;
																											IL_0df1_2:
																											num5--;
																											goto IL_1492_2;
																											IL_0e04_2:
																											if (5 < b)
																											{
																												goto end_IL_0542_2;
																											}
																											goto IL_0e12_2;
																											continue;
																											end_IL_04cf_2:
																											break;
																										}
																										break;
																									}
																									goto IL_057d_2;
																									IL_064c_2:
																									array2[num5 - 2] = 0;
																									goto IL_0660_2;
																									IL_0660_2:
																									num5--;
																									goto IL_1492_2;
																									IL_057d_2:
																									if (7 < b)
																									{
																										goto end_IL_0542_2;
																									}
																									goto IL_05d1_2;
																									IL_05d1_2:
																									if (7 > b)
																									{
																										goto end_IL_0542_2;
																									}
																									goto IL_060c_2;
																									IL_060c_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_064c_2;
																								}
																								continue;
																							}
																							num = 97;
																							goto IL_0e99_2;
																							IL_1029_2:
																							ptr2 += 8;
																							goto IL_1037_2;
																							IL_1037_2:
																							num5--;
																							goto IL_1492_2;
																							IL_0e99_2:
																							if (4 <= b)
																							{
																								goto IL_0ea4_2;
																							}
																							goto IL_0f00_2;
																							IL_0ea4_2:
																							array2[num5] = 0;
																							goto IL_0eb2_2;
																							IL_0eb2_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0ed5_2;
																							IL_0ed5_2:
																							array3[num5] = null;
																							goto IL_0edf_2;
																							IL_0edf_2:
																							num5++;
																							goto IL_0eed_2;
																							IL_0eed_2:
																							ptr2 += 8;
																							goto IL_1492_2;
																							IL_0f00_2:
																							if (2 >= b)
																							{
																								goto IL_0f0e_2;
																							}
																							goto IL_0fe4_2;
																							IL_0f0e_2:
																							if (2 <= b)
																							{
																								goto IL_0f19_2;
																							}
																							goto IL_0f80_2;
																							IL_0f19_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0f59_2;
																							IL_0f59_2:
																							array2[num5 - 2] = 0;
																							goto IL_0f6d_2;
																							IL_0f6d_2:
																							num5--;
																							goto IL_1492_2;
																							IL_0f80_2:
																							if (1 < b)
																							{
																								goto end_IL_0542_2;
																							}
																							goto IL_0f8e_2;
																							IL_0f8e_2:
																							if (1 > b)
																							{
																								goto end_IL_0542_2;
																							}
																							goto IL_0f9c_2;
																							IL_0f9c_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0fb5_2;
																							IL_0fb5_2:
																							array2[num5] = 0;
																							goto IL_0fc3_2;
																							IL_0fc3_2:
																							num5++;
																							goto IL_0fd1_2;
																							IL_0fd1_2:
																							ptr2 += 8;
																							goto IL_1492_2;
																							IL_0fe4_2:
																							if (3 < b)
																							{
																								goto end_IL_0542_2;
																							}
																							goto IL_0ff2_2;
																							IL_0ff2_2:
																							if (3 > b)
																							{
																								goto end_IL_0542_2;
																							}
																							goto IL_1000_2;
																							IL_1000_2:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_1029_2;
																							continue;
																							end_IL_04f5_2:
																							break;
																						}
																						continue;
																					}
																					goto IL_058d_2;
																					IL_058d_2:
																					num5--;
																					goto IL_1492_2;
																					continue;
																					end_IL_0505:
																					break;
																				}
																				continue;
																			}
																			goto IL_104a_2;
																			IL_1457_2:
																			array3[num5] = array3[num5 - 1];
																			goto IL_146f_2;
																			IL_104a_2:
																			if (12 >= b)
																			{
																				goto IL_1058_2;
																			}
																			goto IL_1225_2;
																			IL_1058_2:
																			if (12 <= b)
																			{
																				goto IL_1492_2;
																			}
																			goto IL_1066_2;
																			IL_1066_2:
																			if (10 >= b)
																			{
																				goto IL_1074_2;
																			}
																			goto IL_1177_2;
																			IL_1074_2:
																			if (10 <= b)
																			{
																				goto IL_107f_2;
																			}
																			goto IL_10f4_2;
																			IL_107f_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_10e1_2;
																			IL_10e1_2:
																			num5 -= 2;
																			goto IL_1492_2;
																			IL_10f4_2:
																			if (9 < b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_1102_2;
																			IL_1102_2:
																			if (9 > b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_1110_2;
																			IL_1110_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_1150_2;
																			IL_1150_2:
																			array2[num5 - 2] = 0;
																			goto IL_1164_2;
																			IL_1164_2:
																			num5--;
																			goto IL_1492_2;
																			IL_1177_2:
																			if (11 < b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_1185_2;
																			IL_1185_2:
																			if (11 > b)
																			{
																				goto end_IL_0542_2;
																			}
																			num = 87;
																			goto IL_119c_2;
																			IL_146f_2:
																			num5++;
																			goto IL_1492_2;
																			IL_119c_2:
																			array2[num5 - 2] = 0;
																			goto IL_11b0_2;
																			IL_11b0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																			goto IL_1204_2;
																			IL_1204_2:
																			num5--;
																			goto IL_1212_2;
																			IL_1212_2:
																			ptr2 += 8;
																			goto IL_1492_2;
																			IL_1225_2:
																			if (14 >= b)
																			{
																				goto IL_1233_2;
																			}
																			goto IL_137d_2;
																			IL_1233_2:
																			if (14 > b)
																			{
																				goto IL_1241_2;
																			}
																			goto IL_133e_2;
																			IL_1241_2:
																			if (13 < b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_124f_2;
																			IL_124f_2:
																			if (13 > b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_125d_2;
																			IL_125d_2:
																			array8 = array3;
																			num6 = num5;
																			if (array == null)
																			{
																				goto IL_126c_2;
																			}
																			goto IL_127a;
																			IL_133e_2:
																			array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																			goto IL_135c_2;
																			IL_135c_2:
																			ptr2 += 8;
																			goto IL_136a_2;
																			IL_136a_2:
																			num5--;
																			goto IL_1492_2;
																			IL_137d_2:
																			if (15 >= b)
																			{
																				goto IL_1388_2;
																			}
																			goto IL_13d8_2;
																			IL_1388_2:
																			if (15 > b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_1396_2;
																			IL_1396_2:
																			array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																			goto IL_13bf_2;
																			IL_13bf_2:
																			array2[num5 - 1] = 5;
																			goto IL_1492_2;
																			IL_13d8_2:
																			if (16 < b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_13e6_2;
																			IL_13e6_2:
																			if (16 > b)
																			{
																				goto end_IL_0542_2;
																			}
																			goto IL_13f4_2;
																			IL_13f4_2:
																			array2[num5] = array2[num5 - 1];
																			goto IL_140c_2;
																			IL_140c_2:
																			array4[num5 - 0] = array4[num5 - 1];
																			num = 174;
																			goto IL_1433_2;
																			IL_1433_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_1457_2;
																			continue;
																			end_IL_0512:
																			break;
																		}
																		continue;
																	}
																	goto IL_05e1_2;
																	IL_07ae_2:
																	ptr2 += 8;
																	goto IL_1492_2;
																	IL_05e1_2:
																	array2[num5] = 5;
																	goto IL_05ef_2;
																	IL_05ef_2:
																	array3[num5] = array7[*(int*)(ptr2 + num3)];
																	goto IL_07a0_2;
																	IL_07a0_2:
																	num5++;
																	goto IL_07ae_2;
																	continue;
																	end_IL_0522:
																	break;
																}
																continue;
															}
															goto IL_05a0_2;
															IL_0965_2:
															array2[num5 - 2] = 5;
															goto IL_0979_2;
															IL_0979_2:
															array3[num5 - 2] = ((delegate*<string, string, string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
															goto IL_09c5_2;
															IL_05a0_2:
															if (26 >= b)
															{
																goto IL_05ab_2;
															}
															goto IL_05be_2;
															IL_05ab_2:
															if (26 <= b)
															{
																goto IL_0773_2;
															}
															goto IL_0a10_2;
															IL_0773_2:
															float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
															goto IL_078d_2;
															IL_078d_2:
															num5--;
															goto IL_1492_2;
															IL_0a10_2:
															if (21 >= b)
															{
																goto IL_0a1e_2;
															}
															goto IL_0bc5_2;
															IL_0a1e_2:
															if (21 <= b)
															{
																goto IL_0a29_2;
															}
															goto IL_0a56_2;
															IL_0a29_2:
															int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0a43_2;
															IL_0a43_2:
															num5--;
															goto IL_1492_2;
															IL_0a56_2:
															if (19 >= b)
															{
																goto IL_0a64_2;
															}
															goto IL_0b4d_2;
															IL_0a64_2:
															if (19 > b)
															{
																goto IL_0a6f_2;
															}
															goto IL_0ae5_2;
															IL_0a6f_2:
															if (18 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0a7d_2;
															IL_0a7d_2:
															if (18 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0a8b_2;
															IL_0a8b_2:
															((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
															num = 169;
															goto IL_0ad2_2;
															IL_0ad2_2:
															num5 -= 3;
															goto IL_1492_2;
															IL_0ae5_2:
															array2[num5 - 1] = 5;
															goto IL_0af9_2;
															IL_0af9_2:
															array3[num5 - 1] = ((delegate*<string[], string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															num = 83;
															goto IL_0b3a_2;
															IL_0b3a_2:
															ptr2 += 8;
															goto IL_1492_2;
															IL_0b4d_2:
															if (20 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0b5b_2;
															IL_0b5b_2:
															if (20 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0b69_2;
															IL_0b69_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])();
															goto IL_0b8d_2;
															IL_0b8d_2:
															array2[num5] = 0;
															goto IL_0b9b_2;
															IL_0b9b_2:
															num5++;
															goto IL_0ba9_2;
															IL_0ba9_2:
															ptr2 += 8;
															num = 124;
															goto IL_1492_2;
															IL_0bc5_2:
															if (23 >= b)
															{
																goto IL_0bd3_2;
															}
															goto IL_0ca5_2;
															IL_0bd3_2:
															if (23 > b)
															{
																goto IL_0bde_2;
															}
															num = 75;
															goto IL_0c62_2;
															IL_0bde_2:
															if (22 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0bec_2;
															IL_0bec_2:
															if (22 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0bfa_2;
															IL_0bfa_2:
															array3[num5] = ((delegate*<float[]>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])();
															num = 229;
															goto IL_0c21_2;
															IL_0c21_2:
															array2[num5] = 5;
															goto IL_0c2f_2;
															IL_0c2f_2:
															num5++;
															goto IL_0c3d_2;
															IL_0c3d_2:
															ptr2 += 8;
															num = 27;
															goto IL_1492_2;
															IL_09c5_2:
															num5--;
															goto IL_09d3_2;
															IL_0c62_2:
															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
															goto IL_0c8c_2;
															IL_0c8c_2:
															array2[num5 - 1] = 2;
															goto IL_1492_2;
															IL_0ca5_2:
															if (24 >= b)
															{
																goto IL_0cb0_2;
															}
															goto IL_0d02_2;
															IL_0cb0_2:
															if (24 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0cbe_2;
															IL_0cbe_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
															goto IL_0ce9_2;
															IL_0ce9_2:
															array2[num5 - 1] = 0;
															goto IL_1492_2;
															IL_0d02_2:
															if (25 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0d10_2;
															IL_0d10_2:
															if (25 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0d1e_2;
															IL_0d1e_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
															goto IL_0d62_2;
															IL_0d62_2:
															array2[num5 - 2] = 3;
															goto IL_0d76_2;
															IL_0d76_2:
															num5--;
															goto IL_1492_2;
															IL_05be_2:
															if (30 < b)
															{
																goto IL_0673_2;
															}
															goto IL_07c1_2;
															IL_0673_2:
															if (32 >= b)
															{
																goto IL_0681_2;
															}
															goto IL_071d_2;
															IL_0681_2:
															if (32 <= b)
															{
																goto IL_068c_2;
															}
															goto IL_06ba_2;
															IL_068c_2:
															((delegate*<UnityEngine.Object, void>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((Class127)array3[num5 - 1]);
															goto IL_09e6_2;
															IL_09e6_2:
															num5--;
															goto IL_09f4_2;
															IL_09f4_2:
															ptr2 += 8;
															num = 110;
															goto IL_1492_2;
															IL_06ba_2:
															if (31 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_06c8_2;
															IL_06c8_2:
															if (31 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_06d6_2;
															IL_06d6_2:
															array3[num5] = array7[*(int*)(ptr2 + num3)];
															goto IL_06ee_2;
															IL_06ee_2:
															array2[num5] = 5;
															goto IL_06fc_2;
															IL_06fc_2:
															num5++;
															goto IL_070a_2;
															IL_070a_2:
															ptr2 += 8;
															goto IL_1492_2;
															IL_071d_2:
															if (33 >= b)
															{
																goto IL_0728_2;
															}
															goto IL_0752_2;
															IL_0728_2:
															if (33 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0736_2;
															IL_0736_2:
															num9 = ptr2;
															num10 = -200;
															num4 = 1;
															ptr2 = num9 + num10;
															goto IL_1492_2;
															IL_0752_2:
															if (34 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0760_2;
															IL_0760_2:
															if (34 > b)
															{
															}
															goto end_IL_0542_2;
															IL_07c1_2:
															if (30 <= b)
															{
																goto IL_07cc_2;
															}
															goto IL_0816_2;
															IL_07cc_2:
															((delegate*<string, void>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
															goto IL_07f5_2;
															IL_07f5_2:
															num5--;
															goto IL_0803_2;
															IL_0803_2:
															ptr2 += 8;
															goto IL_1492_2;
															IL_0816_2:
															if (28 >= b)
															{
																goto IL_0824_2;
															}
															goto IL_0949_2;
															IL_0824_2:
															if (28 > b)
															{
																goto IL_082f_2;
															}
															num = 226;
															goto IL_0896_2;
															IL_082f_2:
															if (27 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_083d_2;
															IL_083d_2:
															if (27 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_084b_2;
															IL_084b_2:
															array2[num5] = 15;
															goto IL_0859_2;
															IL_0859_2:
															array4[num5] = *(int*)(ptr2 + num3);
															goto IL_086c_2;
															IL_086c_2:
															ptr2 += 8;
															goto IL_087a_2;
															IL_087a_2:
															num5++;
															goto IL_1492_2;
															IL_09d3_2:
															ptr2 += 8;
															goto IL_1492_2;
															IL_0896_2:
															array2[num5 - 2] = 5;
															goto IL_08aa_2;
															IL_08aa_2:
															array3[num5 - 2] = ((delegate*<ref float, string, string>)AppendCharTimeoutHelper[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)AppendCharTimeoutHelper[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
															goto IL_0928_2;
															IL_0928_2:
															num5--;
															goto IL_0936_2;
															IL_0936_2:
															ptr2 += 8;
															goto IL_1492_2;
															IL_0949_2:
															if (29 < b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0957_2;
															IL_0957_2:
															if (29 > b)
															{
																goto end_IL_0542_2;
															}
															goto IL_0965_2;
															continue;
															end_IL_0532:
															break;
														}
														continue;
														end_IL_0542_2:
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_1492_2;
												continue;
												end_IL_0552_2:
												break;
											}
											continue;
											end_IL_0562:
											break;
										}
										continue;
										end_IL_0572:
										break;
									}
									break;
								}
								num = 187;
								return;
							}
							break;
						}
						continue;
						end_IL_1314:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class127()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class127()
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					while (true)
					{
						int num3 = num2 * 4;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[3];
									while (true)
									{
										long[] array4 = new long[3];
										num = 113;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BinaryObjectWithMapaddResourceResolve.STAThreadAttributeRequired);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 12;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0298:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0278:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0268:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0258:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_024b:
																									if (5 < b)
																									{
																										while (6 >= b)
																										{
																											num = 130;
																											while (true)
																											{
																												if (num != 130)
																												{
																													if (num != 1111)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 5:
																														goto IL_0238;
																													case 22:
																														goto IL_024b;
																													case 25:
																														goto IL_0258;
																													case 54:
																														goto IL_0268;
																													case 69:
																														goto IL_0278;
																													case 41:
																														goto IL_0288;
																													case 111:
																														goto IL_0298;
																													case 27:
																														goto end_IL_0298;
																													case 30:
																													case 56:
																														goto end_IL_02a8;
																													case 43:
																														goto IL_02c3;
																													case 11:
																													case 35:
																														goto IL_02ce;
																													case 23:
																														goto IL_02ec;
																													case 79:
																														goto IL_02ff;
																													case 7:
																														goto IL_030a;
																													case 59:
																														goto IL_0315;
																													case 73:
																														goto IL_0323;
																													case 13:
																													case 49:
																														goto IL_0331;
																													case 38:
																														goto IL_0346;
																													case 2:
																														goto IL_0359;
																													case 28:
																													case 101:
																														goto IL_036c;
																													case 86:
																														goto IL_0386;
																													case 47:
																														goto IL_0394;
																													case 102:
																														goto IL_03a4;
																													case 74:
																														goto IL_03b2;
																													case 19:
																														goto IL_03c0;
																													case 115:
																														goto IL_03d3;
																													case 95:
																													case 99:
																														goto IL_03e1;
																													case 90:
																														goto IL_03fb;
																													case 120:
																														goto IL_0417;
																													case 24:
																													case 71:
																														goto IL_0441;
																													case 52:
																														goto IL_0481;
																													case 39:
																														goto IL_049e;
																													case 42:
																													case 121:
																														goto IL_04b1;
																													case 37:
																														goto IL_04cb;
																													case 4:
																														goto IL_04de;
																													case 58:
																														goto IL_04ec;
																													case 32:
																														goto IL_04fa;
																													case 57:
																													case 77:
																														goto IL_0505;
																													case 118:
																														goto IL_051e;
																													case 76:
																														goto IL_0531;
																													case 78:
																														goto IL_053f;
																													case 81:
																													case 84:
																														goto IL_054d;
																													case 34:
																														goto IL_058a;
																													case 55:
																														goto IL_0598;
																													case 21:
																														goto IL_05b4;
																													case 85:
																														goto IL_05c2;
																													case 80:
																													case 100:
																														goto IL_05d9;
																													case 106:
																														goto IL_05f5;
																													case 20:
																													case 40:
																														goto IL_0600;
																													case 10:
																														goto IL_0613;
																													case 68:
																														goto IL_062a;
																													case 29:
																														goto IL_063d;
																													case 15:
																														goto IL_0648;
																													case 16:
																													case 91:
																														goto IL_0656;
																													case 50:
																														goto IL_067f;
																													case 109:
																														goto IL_0698;
																													case 9:
																														goto IL_06a6;
																													case 51:
																													case 94:
																														goto IL_06b4;
																													case 65:
																														goto IL_06cc;
																													case 82:
																														goto IL_06ea;
																													case 61:
																														goto IL_0717;
																													case 112:
																														goto IL_072f;
																													case 3:
																													case 17:
																													case 18:
																													case 26:
																													case 46:
																													case 53:
																													case 70:
																													case 87:
																													case 88:
																													case 93:
																													case 98:
																													case 104:
																													case 105:
																													case 114:
																													case 119:
																													case 122:
																														goto end_IL_0225;
																													case 31:
																														goto IL_075d;
																													case 0:
																													case 1:
																													case 8:
																													case 12:
																													case 14:
																													case 33:
																													case 36:
																													case 44:
																													case 45:
																													case 48:
																													case 60:
																													case 67:
																													case 103:
																													case 108:
																													case 117:
																														goto end_IL_02b8;
																													case 116:
																														goto end_IL_076b;
																													case 113:
																														goto end_IL_077e;
																													case 123:
																														goto end_IL_0791;
																													case 62:
																														goto end_IL_079c;
																													case 72:
																														goto end_IL_07b5;
																													case 75:
																													case 107:
																														goto end_IL_07c5;
																													case 97:
																														goto end_IL_07d5;
																													case 6:
																													case 83:
																													case 89:
																													case 92:
																													case 96:
																														goto end_IL_07e5;
																													case 63:
																														goto end_IL_07f5;
																													case 64:
																														goto end_IL_080c;
																													case 66:
																													case 110:
																														return;
																													}
																													continue;
																												}
																												if (6 > b)
																												{
																													break;
																												}
																												goto IL_0441;
																												IL_0441:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0481;
																												IL_049e:
																												num5--;
																												goto end_IL_02b8;
																												IL_0481:
																												array[num5 - 2] = 0;
																												num = 39;
																												goto IL_049e;
																												continue;
																												end_IL_0225:
																												break;
																											}
																											break;
																											IL_0238:;
																										}
																										break;
																									}
																									goto IL_02c3;
																									IL_03fb:
																									num5--;
																									num = 44;
																									goto end_IL_02b8;
																									IL_02c3:
																									if (5 <= b)
																									{
																										goto IL_02ce;
																									}
																									goto IL_02ec;
																									IL_02ce:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_03a4;
																									IL_03a4:
																									array[num5] = 0;
																									goto IL_03b2;
																									IL_03b2:
																									num5++;
																									goto IL_03c0;
																									IL_03c0:
																									ptr2 += 8;
																									goto end_IL_02b8;
																									IL_02ec:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_03d3;
																									IL_03d3:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_03e1;
																									IL_03e1:
																									float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																									goto IL_03fb;
																								}
																								break;
																							}
																							goto IL_02ff;
																							IL_0417:
																							ptr2 += 8;
																							num = 103;
																							goto end_IL_02b8;
																							IL_02ff:
																							if (3 > b)
																							{
																								goto IL_030a;
																							}
																							goto IL_036c;
																							IL_030a:
																							if (1 < b)
																							{
																								goto IL_0315;
																							}
																							goto IL_0359;
																							IL_0315:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0323;
																							IL_0323:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0331;
																							IL_0331:
																							((delegate*<void>)setNumberGroupSizesgetCurrentUICulture[*(int*)(ptr2 + num3)])();
																							goto IL_0346;
																							IL_0346:
																							ptr2 += 8;
																							goto end_IL_02b8;
																							IL_0359:
																							if (1 > b)
																							{
																							}
																							break;
																							IL_036c:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																							goto IL_0386;
																							IL_0386:
																							array[num5] = 3;
																							goto IL_0394;
																							IL_0394:
																							num5++;
																							goto IL_0417;
																						}
																						break;
																					}
																					goto IL_04b1;
																					IL_04cb:
																					num5--;
																					goto end_IL_02b8;
																					IL_04b1:
																					int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04cb;
																				}
																				break;
																			}
																			goto IL_04de;
																			IL_0717:
																			array2[num5] = array2[num5 - 1];
																			goto IL_072f;
																			IL_04de:
																			if (10 < b)
																			{
																				goto IL_04ec;
																			}
																			goto IL_05f5;
																			IL_04ec:
																			if (12 >= b)
																			{
																				goto IL_04fa;
																			}
																			goto IL_05b4;
																			IL_04fa:
																			if (12 <= b)
																			{
																				goto IL_0505;
																			}
																			goto IL_0531;
																			IL_0505:
																			float_1 = (float[])array2[num5 - 1];
																			goto IL_051e;
																			IL_051e:
																			num5--;
																			goto end_IL_02b8;
																			IL_0531:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_053f;
																			IL_053f:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_054d;
																			IL_054d:
																			((delegate*<Array, RuntimeFieldHandle, void>)setNumberGroupSizesgetCurrentUICulture[*(int*)(ptr2 + num3)])((float[])array2[num5 - 2], (RuntimeFieldHandle)array2[num5 - 1]);
																			goto IL_058a;
																			IL_058a:
																			num5 -= 2;
																			goto IL_0598;
																			IL_0598:
																			ptr2 += 8;
																			num = 108;
																			goto end_IL_02b8;
																			IL_05b4:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_05c2;
																			IL_05c2:
																			if (13 > b)
																			{
																				break;
																			}
																			num = 80;
																			goto IL_05d9;
																			IL_072f:
																			num5++;
																			goto end_IL_02b8;
																			IL_05d9:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02b8;
																			IL_05f5:
																			if (10 <= b)
																			{
																				goto IL_0600;
																			}
																			goto IL_063d;
																			IL_0600:
																			array2[num5] = default(RuntimeFieldHandle);
																			goto IL_0613;
																			IL_0613:
																			array[num5] = 4;
																			num = 68;
																			goto IL_062a;
																			IL_062a:
																			num5++;
																			goto end_IL_02b8;
																			IL_063d:
																			if (8 >= b)
																			{
																				goto IL_0648;
																			}
																			goto IL_0698;
																			IL_0648:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0656;
																			IL_0656:
																			array2[num5 - 1] = new float[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_067f;
																			IL_067f:
																			array[num5 - 1] = 5;
																			goto end_IL_02b8;
																			IL_0698:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06a6;
																			IL_06a6:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_06b4;
																			IL_06b4:
																			array[num5] = array[num5 - 1];
																			goto IL_06cc;
																			IL_06cc:
																			array3[num5 - 0] = array3[num5 - 1];
																			goto IL_06ea;
																			IL_06ea:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 61;
																			goto IL_0717;
																		}
																		break;
																		IL_0288:;
																	}
																}
																((delegate*<void>)setNumberGroupSizesgetCurrentUICulture[*(int*)(ptr2 + num3)])();
																num = 31;
																goto IL_075d;
																IL_075d:
																ptr2 += 8;
																goto end_IL_02b8;
																continue;
																end_IL_0298:
																break;
															}
															continue;
															end_IL_02a8:
															break;
														}
														continue;
														end_IL_02b8:
														break;
													}
													continue;
													end_IL_076b:
													break;
												}
												continue;
												end_IL_077e:
												break;
											}
											continue;
											end_IL_0791:
											break;
										}
										continue;
										end_IL_079c:
										break;
									}
									continue;
									end_IL_07b5:
									break;
								}
								continue;
								end_IL_07c5:
								break;
							}
							continue;
							end_IL_07d5:
							break;
						}
						continue;
						end_IL_07e5:
						break;
					}
					continue;
					end_IL_07f5:
					break;
				}
				continue;
				end_IL_080c:
				break;
			}
		}
	}

	private unsafe static int smethod_0()
	{
		int num = 126;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 125;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 32;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IEnumDefinitionIdentityKeyExchangeAlgorithm.DataAvailableSetWindowPosition);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_033d:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_030d:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02fd:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02f0:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_02e0:
																												if (6 <= b)
																												{
																													while (true)
																													{
																														IL_0296:
																														((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 157;
																														while (true)
																														{
																															if (num != 157)
																															{
																																if (num != 1138)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 138:
																																case 143:
																																	goto IL_0296;
																																case 93:
																																	goto IL_02e0;
																																case 30:
																																case 101:
																																	goto IL_02f0;
																																case 131:
																																	goto IL_02fd;
																																case 31:
																																	goto IL_030d;
																																case 60:
																																	goto end_IL_0283;
																																case 108:
																																	goto end_IL_031d;
																																case 141:
																																	goto IL_033d;
																																case 87:
																																	goto end_IL_033d;
																																case 20:
																																case 66:
																																	goto end_IL_034d;
																																case 70:
																																	goto IL_0368;
																																case 79:
																																	goto IL_0376;
																																case 53:
																																case 71:
																																	goto IL_0384;
																																case 33:
																																case 112:
																																	goto IL_03af;
																																case 56:
																																	goto IL_03ba;
																																case 15:
																																	goto IL_03c8;
																																case 21:
																																	goto IL_03d6;
																																case 130:
																																	goto IL_03e9;
																																case 134:
																																	goto IL_03fc;
																																case 51:
																																case 57:
																																	goto IL_0407;
																																case 14:
																																	goto IL_0447;
																																case 67:
																																	goto IL_045b;
																																case 2:
																																case 76:
																																	goto IL_046e;
																																case 28:
																																	goto IL_047c;
																																case 104:
																																case 119:
																																	goto IL_0487;
																																case 85:
																																	goto IL_0495;
																																case 23:
																																	goto IL_04b8;
																																case 123:
																																	goto IL_04c2;
																																case 65:
																																	goto IL_04d0;
																																case 17:
																																	goto IL_04e3;
																																case 9:
																																	goto IL_04f1;
																																case 62:
																																case 129:
																																	goto IL_0504;
																																case 43:
																																	goto IL_0512;
																																case 135:
																																	goto IL_0522;
																																case 24:
																																case 144:
																																	goto IL_0535;
																																case 96:
																																	goto IL_0579;
																																case 118:
																																	goto IL_058d;
																																case 148:
																																	goto IL_05a0;
																																case 73:
																																case 128:
																																	goto IL_05ab;
																																case 26:
																																case 81:
																																	goto IL_05c7;
																																case 92:
																																	goto IL_05d5;
																																case 59:
																																case 147:
																																	goto IL_05e3;
																																case 63:
																																	goto IL_0645;
																																case 122:
																																	goto IL_066b;
																																case 97:
																																	goto IL_0679;
																																case 1:
																																case 5:
																																	goto IL_0684;
																																case 111:
																																	goto IL_0692;
																																case 115:
																																	goto IL_06aa;
																																case 84:
																																	goto IL_06b8;
																																case 145:
																																	goto IL_06d9;
																																case 48:
																																case 61:
																																	goto IL_06e7;
																																case 44:
																																case 113:
																																	goto IL_06f2;
																																case 54:
																																	goto IL_0700;
																																case 89:
																																case 140:
																																	goto IL_070e;
																																case 109:
																																	goto IL_0737;
																																case 69:
																																	goto IL_0750;
																																case 36:
																																case 86:
																																	goto IL_075b;
																																case 50:
																																	goto IL_0769;
																																case 7:
																																case 139:
																																	goto IL_0777;
																																case 4:
																																	goto IL_0790;
																																case 106:
																																	goto IL_079e;
																																case 11:
																																	goto IL_07ac;
																																case 40:
																																case 78:
																																	goto IL_07bf;
																																case 114:
																																	goto IL_07ff;
																																case 46:
																																	goto IL_081c;
																																case 25:
																																case 42:
																																	goto IL_082c;
																																case 98:
																																	goto IL_084a;
																																case 41:
																																	goto IL_0858;
																																case 80:
																																case 95:
																																	goto IL_0868;
																																case 0:
																																case 6:
																																case 8:
																																case 10:
																																case 12:
																																case 16:
																																case 18:
																																case 22:
																																case 29:
																																case 35:
																																case 37:
																																case 38:
																																case 39:
																																case 52:
																																case 55:
																																case 58:
																																case 68:
																																case 82:
																																case 99:
																																case 102:
																																case 105:
																																case 107:
																																case 110:
																																case 116:
																																case 127:
																																case 133:
																																case 142:
																																case 149:
																																case 150:
																																	goto end_IL_032d;
																																case 13:
																																case 34:
																																case 49:
																																case 64:
																																case 72:
																																case 74:
																																case 75:
																																case 88:
																																case 91:
																																case 100:
																																case 103:
																																case 117:
																																case 120:
																																case 121:
																																case 124:
																																case 132:
																																case 136:
																																case 137:
																																	goto end_IL_035d;
																																case 94:
																																	goto end_IL_0890;
																																case 3:
																																	goto end_IL_08a3;
																																case 47:
																																	goto end_IL_08ad;
																																case 45:
																																	goto end_IL_08b8;
																																case 90:
																																case 146:
																																	goto end_IL_08c8;
																																case 77:
																																	goto end_IL_08d8;
																																case 32:
																																	goto end_IL_08e8;
																																case 27:
																																	goto end_IL_08f8;
																																case 125:
																																	goto end_IL_0908;
																																case 126:
																																	goto end_IL_0913;
																																case 19:
																																case 83:
																																	goto IL_0937;
																																}
																																continue;
																															}
																															num5 -= 3;
																															goto end_IL_035d;
																															continue;
																															end_IL_0283:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_066b;
																												IL_06b8:
																												ptr2 += 8;
																												goto end_IL_035d;
																												IL_066b:
																												if (5 < b)
																												{
																													goto end_IL_032d;
																												}
																												goto IL_0679;
																												IL_0679:
																												if (5 > b)
																												{
																													num = 116;
																													goto end_IL_032d;
																												}
																												goto IL_0684;
																												IL_0684:
																												array[num5] = 5;
																												goto IL_0692;
																												IL_0692:
																												array2[num5] = array5[*(int*)(ptr2 + num3)];
																												goto IL_06aa;
																												IL_06aa:
																												num5++;
																												goto IL_06b8;
																											}
																											break;
																										}
																										goto IL_0368;
																										IL_0522:
																										num5--;
																										goto end_IL_035d;
																										IL_0368:
																										if (7 < b)
																										{
																											goto end_IL_032d;
																										}
																										goto IL_0376;
																										IL_0376:
																										if (7 > b)
																										{
																											goto end_IL_032d;
																										}
																										goto IL_0384;
																										IL_0384:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03e9;
																										IL_03e9:
																										ptr2 += 8;
																										goto IL_0522;
																									}
																									break;
																								}
																								goto IL_06d9;
																								IL_0858:
																								num5--;
																								goto end_IL_035d;
																								IL_06d9:
																								if (4 > b)
																								{
																									goto IL_06e7;
																								}
																								goto IL_082c;
																								IL_06e7:
																								if (2 < b)
																								{
																									goto IL_06f2;
																								}
																								goto IL_0750;
																								IL_06f2:
																								if (3 < b)
																								{
																									goto end_IL_032d;
																								}
																								goto IL_0700;
																								IL_0700:
																								if (3 > b)
																								{
																									goto end_IL_032d;
																								}
																								goto IL_070e;
																								IL_070e:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_0737;
																								IL_0737:
																								array[num5 - 1] = 5;
																								goto end_IL_035d;
																								IL_0750:
																								if (2 > b)
																								{
																									goto IL_075b;
																								}
																								goto IL_07bf;
																								IL_075b:
																								if (1 < b)
																								{
																									goto end_IL_032d;
																								}
																								goto IL_0769;
																								IL_0769:
																								if (1 > b)
																								{
																									goto end_IL_032d;
																								}
																								goto IL_0777;
																								IL_0777:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0790;
																								IL_0790:
																								array[num5] = 0;
																								goto IL_079e;
																								IL_079e:
																								num5++;
																								goto IL_07ac;
																								IL_07ac:
																								ptr2 += 8;
																								goto end_IL_035d;
																								IL_07bf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07ff;
																								IL_07ff:
																								array[num5 - 2] = 0;
																								num = 46;
																								goto IL_081c;
																								IL_081c:
																								num5--;
																								goto end_IL_035d;
																								IL_082c:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_084a;
																								IL_084a:
																								ptr2 += 8;
																								goto IL_0858;
																							}
																							break;
																						}
																						goto IL_0868;
																						IL_0868:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_035d;
																					}
																					continue;
																				}
																				goto IL_03af;
																				IL_058d:
																				num5--;
																				goto end_IL_035d;
																				IL_03af:
																				if (12 < b)
																				{
																					goto IL_03ba;
																				}
																				goto IL_03fc;
																				IL_03ba:
																				if (14 < b)
																				{
																					goto IL_03c8;
																				}
																				goto IL_05a0;
																				IL_03c8:
																				if (15 < b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_03d6;
																				IL_03d6:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_032d;
																				IL_05a0:
																				if (14 <= b)
																				{
																					goto IL_05ab;
																				}
																				goto IL_05c7;
																				IL_05ab:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_035d;
																				IL_05c7:
																				if (13 < b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_05d5;
																				IL_05d5:
																				if (13 > b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_05e3;
																				IL_05e3:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0645;
																				IL_0645:
																				num5 -= 2;
																				goto end_IL_035d;
																				IL_03fc:
																				if (12 <= b)
																				{
																					goto IL_0407;
																				}
																				goto IL_046e;
																				IL_0407:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0447;
																				IL_0447:
																				array[num5 - 2] = 0;
																				goto IL_045b;
																				IL_045b:
																				num5--;
																				goto end_IL_035d;
																				IL_046e:
																				if (10 >= b)
																				{
																					goto IL_047c;
																				}
																				goto IL_0504;
																				IL_047c:
																				if (10 <= b)
																				{
																					goto IL_0487;
																				}
																				goto IL_04e3;
																				IL_0487:
																				array[num5] = 0;
																				goto IL_0495;
																				IL_0495:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04b8;
																				IL_04b8:
																				array2[num5] = null;
																				goto IL_04c2;
																				IL_04c2:
																				num5++;
																				goto IL_04d0;
																				IL_04d0:
																				ptr2 += 8;
																				goto end_IL_035d;
																				IL_04e3:
																				if (9 < b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_04f1;
																				IL_04f1:
																				if (9 > b)
																				{
																					goto end_IL_032d;
																				}
																				goto end_IL_035d;
																				IL_0504:
																				if (11 < b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_0512;
																				IL_0512:
																				if (11 > b)
																				{
																					goto end_IL_032d;
																				}
																				goto IL_0535;
																				IL_0535:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0579;
																				IL_0579:
																				array[num5 - 2] = 0;
																				goto IL_058d;
																				continue;
																				end_IL_031d:
																				break;
																			}
																			continue;
																			end_IL_032d:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_035d;
																	continue;
																	end_IL_033d:
																	break;
																}
																continue;
																end_IL_034d:
																break;
															}
															continue;
															end_IL_035d:
															break;
														}
														continue;
													}
													goto IL_0937;
													IL_0937:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0890:
													break;
												}
												continue;
												end_IL_08a3:
												break;
											}
											continue;
											end_IL_08ad:
											break;
										}
										continue;
										end_IL_08b8:
										break;
									}
									continue;
									end_IL_08c8:
									break;
								}
								continue;
								end_IL_08d8:
								break;
							}
							continue;
							end_IL_08e8:
							break;
						}
						continue;
						end_IL_08f8:
						break;
					}
					continue;
					end_IL_0908:
					break;
				}
				continue;
				end_IL_0913:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3, int int_4)
	{
		int num = 12;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HasLocalValuesgetPrimaryIdentitySelector.EventTaskgetSource);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 130;
															while (true)
															{
																if (num != 130)
																{
																	if (num != 1111)
																	{
																		goto IL_0289;
																	}
																	switch (num)
																	{
																	case 108:
																		goto end_IL_0217;
																	case 7:
																		goto IL_023b;
																	case 84:
																		goto IL_0249;
																	case 27:
																		goto IL_0257;
																	case 113:
																		goto IL_0265;
																	case 72:
																	case 92:
																		goto IL_0273;
																	case 58:
																	case 123:
																		goto IL_027e;
																	case 13:
																	case 28:
																		goto IL_0289;
																	case 117:
																		goto IL_0297;
																	case 95:
																	case 110:
																		goto IL_02a5;
																	case 44:
																		goto IL_02c1;
																	case 66:
																	case 86:
																		goto IL_02cf;
																	case 74:
																		goto IL_02e2;
																	case 46:
																	case 122:
																		goto IL_02f0;
																	case 16:
																		goto IL_0304;
																	case 79:
																		goto IL_0358;
																	case 120:
																		goto IL_0366;
																	case 22:
																		goto IL_0379;
																	case 96:
																	case 116:
																		goto IL_0387;
																	case 26:
																		goto IL_0395;
																	case 70:
																	case 106:
																		goto IL_03a3;
																	case 73:
																		goto IL_03e3;
																	case 75:
																		goto IL_03f7;
																	case 40:
																		goto IL_040a;
																	case 24:
																	case 53:
																		goto IL_0418;
																	case 118:
																		goto IL_0431;
																	case 1:
																		goto IL_043f;
																	case 56:
																		goto IL_044d;
																	case 57:
																		goto IL_0460;
																	case 30:
																	case 89:
																		goto IL_046e;
																	case 10:
																	case 109:
																		goto IL_047c;
																	case 99:
																	case 101:
																		goto IL_0487;
																	case 107:
																		goto IL_0495;
																	case 36:
																	case 88:
																		goto IL_04a3;
																	case 0:
																		goto IL_04b1;
																	case 54:
																		goto IL_04d4;
																	case 6:
																		goto IL_04de;
																	case 48:
																		goto IL_04ec;
																	case 80:
																		goto IL_04ff;
																	case 23:
																	case 71:
																		goto IL_0516;
																	case 33:
																		goto IL_0556;
																	case 119:
																		goto IL_056a;
																	case 39:
																		goto IL_057d;
																	case 18:
																	case 100:
																		goto IL_0588;
																	case 41:
																		goto IL_05b1;
																	case 45:
																		goto IL_05bf;
																	case 121:
																		goto IL_05d2;
																	case 114:
																		goto IL_05dd;
																	case 50:
																		goto IL_05f0;
																	case 104:
																		goto IL_05fe;
																	case 34:
																	case 49:
																		goto IL_060c;
																	case 20:
																		goto IL_0655;
																	case 51:
																		goto IL_0669;
																	case 60:
																	case 69:
																		goto IL_067c;
																	case 37:
																		goto IL_06c5;
																	case 81:
																		goto IL_06d9;
																	case 15:
																	case 25:
																	case 29:
																	case 32:
																	case 35:
																	case 38:
																	case 42:
																	case 55:
																	case 62:
																	case 63:
																	case 64:
																	case 65:
																	case 67:
																	case 85:
																	case 87:
																	case 93:
																	case 103:
																	case 105:
																	case 111:
																	case 112:
																	case 115:
																		goto IL_06e9;
																	case 3:
																		goto IL_0715;
																	case 5:
																		goto IL_0723;
																	case 43:
																		goto IL_0731;
																	case 9:
																	case 14:
																	case 17:
																	case 21:
																	case 52:
																	case 59:
																	case 61:
																	case 76:
																	case 78:
																	case 82:
																	case 91:
																	case 94:
																	case 98:
																		goto end_IL_0227;
																	case 47:
																		goto end_IL_073f;
																	case 77:
																		goto end_IL_0752;
																	case 2:
																		goto end_IL_075c;
																	case 19:
																		goto end_IL_0767;
																	case 83:
																		goto end_IL_077c;
																	case 31:
																	case 102:
																		goto end_IL_0791;
																	case 97:
																		goto end_IL_07a1;
																	case 4:
																	case 90:
																		goto end_IL_07b1;
																	case 11:
																		goto end_IL_07c1;
																	case 12:
																		goto end_IL_07d1;
																	case 8:
																	case 68:
																		goto IL_07ec;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_023b;
																IL_06e9:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																num = 3;
																goto IL_0715;
																IL_0723:
																num5++;
																goto IL_0731;
																IL_0715:
																array[num5] = 0;
																goto IL_0723;
																IL_023b:
																ptr2++;
																goto IL_0249;
																IL_0249:
																if (b >= 1)
																{
																	goto IL_0257;
																}
																goto IL_06e9;
																IL_0257:
																if (b <= 11)
																{
																	goto IL_0265;
																}
																goto IL_06e9;
																IL_0265:
																if (6 < b)
																{
																	goto IL_0273;
																}
																goto IL_0460;
																IL_0273:
																if (9 < b)
																{
																	goto IL_027e;
																}
																goto IL_02e2;
																IL_027e:
																if (10 < b)
																{
																	goto IL_0289;
																}
																goto IL_02c1;
																IL_0289:
																if (11 >= b)
																{
																	goto IL_0297;
																}
																goto IL_06e9;
																IL_0297:
																if (11 <= b)
																{
																	goto IL_02a5;
																}
																goto IL_06e9;
																IL_02a5:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_0227;
																IL_02c1:
																if (10 <= b)
																{
																	goto IL_02cf;
																}
																goto IL_06e9;
																IL_02cf:
																num5--;
																goto end_IL_0227;
																IL_02e2:
																if (9 <= b)
																{
																	goto IL_02f0;
																}
																goto IL_0379;
																IL_02f0:
																array[num5 - 2] = 0;
																goto IL_0304;
																IL_0304:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)CreatorOwnerServerSidHasCreationContext[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_0358;
																IL_0358:
																num5--;
																goto IL_0366;
																IL_0366:
																ptr2 += 8;
																goto end_IL_0227;
																IL_0379:
																if (7 < b)
																{
																	goto IL_0387;
																}
																goto IL_040a;
																IL_0387:
																if (8 >= b)
																{
																	goto IL_0395;
																}
																goto IL_06e9;
																IL_0395:
																if (8 <= b)
																{
																	goto IL_03a3;
																}
																goto IL_06e9;
																IL_03a3:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_03e3;
																IL_03e3:
																array[num5 - 2] = 0;
																goto IL_03f7;
																IL_03f7:
																num5--;
																goto end_IL_0227;
																IL_040a:
																if (7 <= b)
																{
																	goto IL_0418;
																}
																goto IL_06e9;
																IL_0418:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0431;
																IL_0431:
																array[num5] = 0;
																goto IL_043f;
																IL_043f:
																num5++;
																goto IL_044d;
																IL_044d:
																ptr2 += 8;
																goto end_IL_0227;
																IL_0460:
																if (6 > b)
																{
																	goto IL_046e;
																}
																goto IL_067c;
																IL_046e:
																if (3 < b)
																{
																	goto IL_047c;
																}
																goto IL_057d;
																IL_047c:
																if (4 < b)
																{
																	goto IL_0487;
																}
																goto IL_04ff;
																IL_0487:
																if (5 >= b)
																{
																	goto IL_0495;
																}
																goto IL_06e9;
																IL_0495:
																if (5 <= b)
																{
																	goto IL_04a3;
																}
																goto IL_06e9;
																IL_04a3:
																array[num5] = 0;
																goto IL_04b1;
																IL_04b1:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04d4;
																IL_04d4:
																array2[num5] = null;
																goto IL_04de;
																IL_04de:
																num5++;
																goto IL_04ec;
																IL_04ec:
																ptr2 += 8;
																goto end_IL_0227;
																IL_04ff:
																if (4 <= b)
																{
																	num = 71;
																	goto IL_0516;
																}
																goto IL_06e9;
																IL_0731:
																ptr2 += 8;
																goto end_IL_0227;
																IL_0516:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0556;
																IL_0556:
																array[num5 - 2] = 0;
																goto IL_056a;
																IL_056a:
																num5--;
																goto end_IL_0227;
																IL_057d:
																if (3 <= b)
																{
																	goto IL_0588;
																}
																goto IL_05d2;
																IL_0588:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05b1;
																IL_05b1:
																ptr2 += 8;
																goto IL_05bf;
																IL_05bf:
																num5--;
																goto end_IL_0227;
																IL_05d2:
																if (1 >= b)
																{
																	goto IL_05dd;
																}
																goto IL_05f0;
																IL_05dd:
																if (1 > b)
																{
																}
																goto IL_06e9;
																IL_05f0:
																if (2 >= b)
																{
																	goto IL_05fe;
																}
																goto IL_06e9;
																IL_05fe:
																if (2 <= b)
																{
																	goto IL_060c;
																}
																goto IL_06e9;
																IL_060c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 20;
																goto IL_0655;
																IL_0655:
																array[num5 - 2] = 0;
																goto IL_0669;
																IL_0669:
																num5--;
																goto end_IL_0227;
																IL_067c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 37;
																goto IL_06c5;
																IL_06c5:
																array[num5 - 2] = 0;
																goto IL_06d9;
																IL_06d9:
																num5--;
																goto end_IL_0227;
																continue;
																end_IL_0217:
																break;
															}
															continue;
															end_IL_0227:
															break;
														}
														continue;
													}
													goto IL_07ec;
													IL_07ec:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_073f:
													break;
												}
												continue;
												end_IL_0752:
												break;
											}
											continue;
											end_IL_075c:
											break;
										}
										continue;
										end_IL_0767:
										break;
									}
									continue;
									end_IL_077c:
									break;
								}
								continue;
								end_IL_0791:
								break;
							}
							continue;
							end_IL_07a1:
							break;
						}
						continue;
						end_IL_07b1:
						break;
					}
					continue;
					end_IL_07c1:
					break;
				}
				continue;
				end_IL_07d1:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 55;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SecurityCriticalAttributeLocalType.LocalDataStoreMgrRequestMinimum);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f9:
														byte b = *ptr2;
														while (true)
														{
															IL_02e9:
															ptr2++;
															while (true)
															{
																IL_02d9:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02b9:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02a9:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_029c:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_028c:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_025c:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0237:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_022b:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_021b:
																																num5++;
																																while (true)
																																{
																																	IL_0202:
																																	ptr2 += 8;
																																	num = 120;
																																	while (num != 120)
																																	{
																																		if (num != 1101)
																																		{
																																			goto IL_022b;
																																		}
																																		switch (num)
																																		{
																																		case 1:
																																			goto IL_0202;
																																		case 59:
																																			goto IL_021b;
																																		case 46:
																																			goto IL_022b;
																																		case 93:
																																			goto IL_0237;
																																		case 21:
																																		case 103:
																																			goto IL_025c;
																																		case 6:
																																			goto IL_026c;
																																		case 3:
																																		case 73:
																																			goto IL_027c;
																																		case 44:
																																		case 112:
																																			goto IL_028c;
																																		case 64:
																																			goto IL_029c;
																																		case 105:
																																			goto IL_02a9;
																																		case 83:
																																			goto IL_02b9;
																																		case 31:
																																			goto IL_02c9;
																																		case 48:
																																			goto IL_02d9;
																																		case 56:
																																			goto IL_02e9;
																																		case 24:
																																		case 30:
																																			goto IL_02f9;
																																		case 11:
																																			goto IL_0304;
																																		case 27:
																																			goto IL_030f;
																																		case 58:
																																			goto IL_031a;
																																		case 53:
																																		case 77:
																																			goto IL_0328;
																																		case 66:
																																			goto IL_0341;
																																		case 84:
																																			goto IL_0358;
																																		case 60:
																																			goto IL_0366;
																																		case 17:
																																		case 86:
																																			goto IL_0379;
																																		case 107:
																																			goto IL_0391;
																																		case 104:
																																			goto IL_039f;
																																		case 87:
																																		case 95:
																																			goto IL_03ad;
																																		case 110:
																																			goto IL_03d8;
																																		case 111:
																																			goto IL_03eb;
																																		case 34:
																																			goto IL_0402;
																																		case 14:
																																		case 25:
																																			goto IL_0415;
																																		case 29:
																																			goto IL_0455;
																																		case 50:
																																			goto IL_0472;
																																		case 71:
																																		case 76:
																																			goto IL_0485;
																																		case 12:
																																			goto IL_0493;
																																		case 36:
																																		case 108:
																																			goto IL_04a1;
																																		case 35:
																																		case 49:
																																			goto IL_04ac;
																																		case 9:
																																			goto IL_04ba;
																																		case 16:
																																		case 52:
																																			goto IL_04c8;
																																		case 39:
																																			goto IL_04eb;
																																		case 2:
																																			goto IL_04f9;
																																		case 5:
																																			goto IL_0507;
																																		case 51:
																																			goto IL_051a;
																																		case 37:
																																		case 38:
																																			goto IL_0528;
																																		case 78:
																																			goto IL_0568;
																																		case 102:
																																			goto IL_057c;
																																		case 94:
																																		case 101:
																																			goto IL_058f;
																																		case 67:
																																			goto IL_05f1;
																																		case 15:
																																			goto IL_0601;
																																		case 32:
																																			goto IL_060c;
																																		case 89:
																																		case 91:
																																			goto IL_0617;
																																		case 45:
																																		case 92:
																																			goto IL_0630;
																																		case 20:
																																			goto IL_063b;
																																		case 0:
																																		case 7:
																																		case 10:
																																		case 13:
																																		case 19:
																																		case 23:
																																		case 40:
																																		case 43:
																																		case 47:
																																		case 57:
																																		case 65:
																																		case 69:
																																		case 70:
																																		case 72:
																																		case 74:
																																		case 79:
																																		case 85:
																																		case 96:
																																		case 100:
																																		case 113:
																																			goto end_IL_026c;
																																		case 8:
																																		case 18:
																																		case 26:
																																		case 28:
																																		case 41:
																																		case 54:
																																		case 61:
																																		case 68:
																																		case 80:
																																		case 81:
																																		case 82:
																																		case 97:
																																		case 98:
																																			goto end_IL_01ef;
																																		case 90:
																																			goto end_IL_0659;
																																		case 88:
																																			goto end_IL_066c;
																																		case 99:
																																			goto end_IL_0676;
																																		case 42:
																																			goto end_IL_0681;
																																		case 55:
																																		case 106:
																																			goto end_IL_0696;
																																		case 4:
																																			goto end_IL_06a6;
																																		case 22:
																																		case 33:
																																			goto end_IL_06b6;
																																		case 62:
																																			goto end_IL_06cf;
																																		case 63:
																																			goto end_IL_06df;
																																		case 75:
																																		case 109:
																																			goto IL_06fa;
																																		}
																																		continue;
																																		end_IL_01ef:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02d9;
																												continue;
																												end_IL_026c:
																												break;
																												IL_026c:;
																											}
																											break;
																											IL_027c:;
																										}
																										break;
																									}
																									goto IL_03d8;
																									IL_03d8:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02d9;
																								}
																								break;
																							}
																							goto IL_0304;
																							IL_0379:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02d9;
																							IL_0304:
																							if (3 > b)
																							{
																								goto IL_030f;
																							}
																							goto IL_0379;
																							IL_030f:
																							if (1 >= b)
																							{
																								goto IL_031a;
																							}
																							goto IL_0391;
																							IL_031a:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0328;
																							IL_0328:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0341;
																							IL_0341:
																							array[num5] = 0;
																							num = 84;
																							goto IL_0358;
																							IL_0358:
																							num5++;
																							goto IL_0366;
																							IL_0366:
																							ptr2 += 8;
																							goto end_IL_02d9;
																							IL_0391:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_039f;
																							IL_039f:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_03ad;
																							IL_03ad:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03eb;
																							IL_03eb:
																							ptr2 += 8;
																							num = 34;
																							goto IL_0402;
																							IL_0402:
																							num5--;
																							goto end_IL_02d9;
																						}
																						break;
																					}
																					goto IL_0415;
																					IL_0472:
																					num5--;
																					goto end_IL_02d9;
																					IL_0415:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0455;
																					IL_0455:
																					array[num5 - 2] = 0;
																					num = 50;
																					goto IL_0472;
																				}
																				break;
																			}
																			goto IL_0485;
																			IL_063b:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_0485:
																			if (9 >= b)
																			{
																				goto IL_0493;
																			}
																			goto IL_0601;
																			IL_0493:
																			if (9 > b)
																			{
																				goto IL_04a1;
																			}
																			goto IL_058f;
																			IL_04a1:
																			if (7 < b)
																			{
																				goto IL_04ac;
																			}
																			goto IL_051a;
																			IL_04ac:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_04ba;
																			IL_04ba:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04c8;
																			IL_04c8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04eb;
																			IL_04eb:
																			array[num5] = 0;
																			goto IL_04f9;
																			IL_04f9:
																			num5++;
																			goto IL_0507;
																			IL_0507:
																			ptr2 += 8;
																			goto end_IL_02d9;
																			IL_051a:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0528;
																			IL_0528:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0568;
																			IL_0568:
																			array[num5 - 2] = 0;
																			goto IL_057c;
																			IL_057c:
																			num5--;
																			goto end_IL_02d9;
																			IL_058f:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05f1;
																			IL_05f1:
																			num5 -= 2;
																			goto end_IL_02d9;
																			IL_0601:
																			if (10 >= b)
																			{
																				goto IL_060c;
																			}
																			goto IL_0630;
																			IL_060c:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0617;
																			IL_0617:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d9;
																			IL_0630:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_063b;
																		}
																		break;
																		IL_02c9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d9:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06fa;
												IL_06fa:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0659:
												break;
											}
											continue;
											end_IL_066c:
											break;
										}
										continue;
										end_IL_0676:
										break;
									}
									continue;
									end_IL_0681:
									break;
								}
								continue;
								end_IL_0696:
								break;
							}
							continue;
							end_IL_06a6:
							break;
						}
						continue;
						end_IL_06b6:
						break;
					}
					continue;
					end_IL_06cf:
					break;
				}
				continue;
				end_IL_06df:
				break;
			}
		}
	}

	private static int smethod_3(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_3;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		int num7 = smethod_0();
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 50;
									while (true)
									{
										array3[1] = int_4;
										num = 31;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WeakReferenceISCIIDecoder.ReadOnlyPermissionSetEnumeratorCodeAccessPermission);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0297:
															byte b = *ptr2;
															while (true)
															{
																IL_0287:
																ptr2++;
																while (true)
																{
																	IL_0277:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0257:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_024a:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_023a:
																								if (7 <= b)
																								{
																									while (true)
																									{
																										IL_021f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										while (true)
																										{
																											IL_020f:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01ff:
																												num5++;
																												while (true)
																												{
																													IL_01e6:
																													ptr2 += 8;
																													num = 113;
																													while (num != 113 && num == 1094)
																													{
																														switch (num)
																														{
																														case 68:
																															goto IL_01e6;
																														case 63:
																															goto IL_01ff;
																														case 6:
																															goto IL_020f;
																														case 65:
																														case 71:
																															goto IL_021f;
																														case 79:
																															goto IL_023a;
																														case 56:
																														case 57:
																															goto IL_024a;
																														case 69:
																															goto IL_0257;
																														case 5:
																															goto IL_0267;
																														case 88:
																															goto IL_0277;
																														case 20:
																															goto IL_0287;
																														case 19:
																														case 35:
																															goto IL_0297;
																														case 26:
																														case 83:
																															goto IL_02a2;
																														case 70:
																														case 74:
																															goto IL_02b0;
																														case 51:
																															goto IL_02be;
																														case 1:
																														case 94:
																															goto IL_02cc;
																														case 97:
																															goto IL_02e8;
																														case 14:
																															goto IL_02f6;
																														case 78:
																														case 92:
																															goto IL_0304;
																														case 48:
																															goto IL_0344;
																														case 86:
																															goto IL_0358;
																														case 105:
																															goto IL_0374;
																														case 16:
																														case 60:
																															goto IL_0382;
																														case 66:
																															goto IL_03cb;
																														case 98:
																															goto IL_03df;
																														case 21:
																															goto IL_03f2;
																														case 10:
																														case 106:
																															goto IL_03fd;
																														case 43:
																															goto IL_040b;
																														case 28:
																															goto IL_042e;
																														case 73:
																															goto IL_0441;
																														case 8:
																															goto IL_044f;
																														case 49:
																															goto IL_0462;
																														case 0:
																														case 32:
																															goto IL_0470;
																														case 18:
																														case 80:
																															goto IL_047e;
																														case 30:
																															goto IL_048c;
																														case 23:
																														case 46:
																															goto IL_049a;
																														case 15:
																															goto IL_04da;
																														case 53:
																															goto IL_04ee;
																														case 17:
																															goto IL_0501;
																														case 25:
																														case 45:
																															goto IL_050f;
																														case 62:
																															goto IL_0538;
																														case 103:
																															goto IL_054f;
																														case 37:
																															goto IL_0562;
																														case 96:
																														case 101:
																															goto IL_056d;
																														case 40:
																															goto IL_05ad;
																														case 41:
																															goto IL_05c1;
																														case 39:
																														case 93:
																															goto IL_05da;
																														case 54:
																															goto IL_05e5;
																														case 2:
																														case 3:
																														case 7:
																														case 13:
																														case 22:
																														case 24:
																														case 29:
																														case 33:
																														case 34:
																														case 42:
																														case 52:
																														case 58:
																														case 81:
																														case 84:
																														case 85:
																														case 99:
																														case 100:
																														case 104:
																															goto end_IL_0267;
																														case 12:
																															goto IL_0613;
																														case 47:
																															goto IL_0621;
																														case 90:
																															goto IL_062f;
																														case 4:
																														case 11:
																														case 36:
																														case 38:
																														case 44:
																														case 59:
																														case 72:
																														case 75:
																														case 87:
																														case 89:
																															goto end_IL_01d3;
																														case 55:
																															goto end_IL_063d;
																														case 31:
																															goto end_IL_0650;
																														case 50:
																															goto end_IL_065a;
																														case 9:
																															goto end_IL_0665;
																														case 82:
																															goto end_IL_0683;
																														case 64:
																														case 95:
																															goto end_IL_06a1;
																														case 91:
																															goto end_IL_06b1;
																														case 27:
																														case 61:
																															goto end_IL_06c1;
																														case 76:
																															goto end_IL_06d1;
																														case 77:
																															goto end_IL_06e1;
																														case 67:
																														case 102:
																															goto IL_06fc;
																														}
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02e8;
																								IL_0358:
																								num5--;
																								num = 38;
																								break;
																								IL_02e8:
																								if (6 < b)
																								{
																									goto end_IL_0267;
																								}
																								goto IL_02f6;
																								IL_02f6:
																								if (6 > b)
																								{
																									goto end_IL_0267;
																								}
																								goto IL_0304;
																								IL_0304:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0344;
																								IL_0344:
																								array[num5 - 2] = 0;
																								goto IL_0358;
																							}
																							break;
																						}
																						goto IL_02a2;
																						IL_03df:
																						num5--;
																						break;
																						IL_02a2:
																						if (8 < b)
																						{
																							goto IL_02b0;
																						}
																						goto IL_0374;
																						IL_02b0:
																						if (9 < b)
																						{
																							goto end_IL_0267;
																						}
																						goto IL_02be;
																						IL_02be:
																						if (9 > b)
																						{
																							goto end_IL_0267;
																						}
																						goto IL_02cc;
																						IL_02cc:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_0374:
																						if (8 > b)
																						{
																							goto end_IL_0267;
																						}
																						goto IL_0382;
																						IL_0382:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 66;
																						goto IL_03cb;
																						IL_03cb:
																						array[num5 - 2] = 0;
																						goto IL_03df;
																					}
																					break;
																				}
																				goto IL_03f2;
																				IL_05da:
																				if (1 < b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_05e5;
																				IL_03f2:
																				if (5 <= b)
																				{
																					goto IL_03fd;
																				}
																				goto IL_0462;
																				IL_03fd:
																				array[num5] = 0;
																				goto IL_040b;
																				IL_040b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_042e;
																				IL_042e:
																				array2[num5] = null;
																				num = 73;
																				goto IL_0441;
																				IL_0441:
																				num5++;
																				goto IL_044f;
																				IL_044f:
																				ptr2 += 8;
																				break;
																				IL_0462:
																				if (2 < b)
																				{
																					goto IL_0470;
																				}
																				goto IL_0562;
																				IL_0470:
																				if (3 < b)
																				{
																					goto IL_047e;
																				}
																				goto IL_0501;
																				IL_047e:
																				if (4 < b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_048c;
																				IL_048c:
																				if (4 > b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_049a;
																				IL_049a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04da;
																				IL_04da:
																				array[num5 - 2] = 0;
																				goto IL_04ee;
																				IL_04ee:
																				num5--;
																				break;
																				IL_0501:
																				if (3 > b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_050f;
																				IL_050f:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0538;
																				IL_0538:
																				ptr2 += 8;
																				num = 103;
																				goto IL_054f;
																				IL_054f:
																				num5--;
																				break;
																				IL_0562:
																				if (2 <= b)
																				{
																					goto IL_056d;
																				}
																				num = 93;
																				goto IL_05da;
																				IL_056d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ad;
																				IL_05ad:
																				array[num5 - 2] = 0;
																				goto IL_05c1;
																				IL_05c1:
																				num5--;
																				break;
																				IL_05e5:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0267;
																			}
																			goto end_IL_0277;
																			continue;
																			end_IL_0267:
																			break;
																			IL_0267:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0613;
																	IL_062f:
																	ptr2 += 8;
																	break;
																	IL_0621:
																	num5++;
																	goto IL_062f;
																	IL_0613:
																	array[num5] = 0;
																	goto IL_0621;
																	continue;
																	end_IL_0277:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06fc;
													IL_06fc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_063d:
													break;
												}
												continue;
												end_IL_0650:
												break;
											}
											continue;
											end_IL_065a:
											break;
										}
										continue;
										end_IL_0665:
										break;
									}
									continue;
									end_IL_0683:
									break;
								}
								continue;
								end_IL_06a1:
								break;
							}
							continue;
							end_IL_06b1:
							break;
						}
						continue;
						end_IL_06c1:
						break;
					}
					continue;
					end_IL_06d1:
					break;
				}
				continue;
				end_IL_06e1:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CallConvFastcallgetTicks.FindInterfacesField);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 109;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_049c:
															byte b = *ptr2;
															while (true)
															{
																IL_0483:
																ptr2++;
																num = 31;
																while (true)
																{
																	IL_0473:
																	if (b >= 1)
																	{
																		goto IL_027e;
																	}
																	goto IL_0452;
																	IL_0452:
																	while (true)
																	{
																		IL_0452_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 151;
																		while (num != 151)
																		{
																			if (num != 1132)
																			{
																				goto IL_0568;
																			}
																			switch (num)
																			{
																			case 90:
																				goto IL_027e;
																			case 96:
																				goto IL_028c;
																			case 7:
																				goto IL_0297;
																			case 61:
																			case 78:
																				goto IL_02a5;
																			case 22:
																			case 41:
																				goto IL_02b0;
																			case 62:
																				goto IL_02be;
																			case 26:
																				goto IL_02cc;
																			case 55:
																				goto IL_02da;
																			case 49:
																				goto IL_02ed;
																			case 39:
																				goto IL_0300;
																			case 8:
																				goto IL_0314;
																			case 80:
																				goto IL_0322;
																			case 28:
																				goto IL_0330;
																			case 125:
																				goto IL_033e;
																			case 118:
																				goto IL_034c;
																			case 131:
																				goto IL_035f;
																			case 21:
																				goto IL_036a;
																			case 24:
																			case 100:
																				goto IL_0378;
																			case 35:
																				goto IL_0386;
																			case 128:
																				goto IL_0399;
																			case 73:
																				goto IL_03a7;
																			case 134:
																				goto IL_03ba;
																			case 68:
																				goto IL_03c8;
																			case 88:
																			case 137:
																				goto IL_03d8;
																			case 37:
																				goto IL_03e3;
																			case 0:
																			case 132:
																				goto IL_03f1;
																			case 116:
																				goto IL_03fc;
																			case 66:
																				goto IL_040c;
																			case 129:
																				goto IL_0417;
																			case 29:
																			case 140:
																				goto IL_0430;
																			case 1:
																				goto IL_043b;
																			case 3:
																			case 6:
																			case 9:
																			case 15:
																			case 27:
																			case 38:
																			case 42:
																			case 46:
																			case 50:
																			case 53:
																			case 54:
																			case 60:
																			case 65:
																			case 69:
																			case 76:
																			case 83:
																			case 89:
																			case 101:
																			case 108:
																			case 120:
																			case 123:
																			case 124:
																			case 136:
																			case 139:
																			case 142:
																				goto IL_0452_2;
																			case 31:
																				goto IL_0473;
																			case 93:
																				goto IL_0483;
																			case 32:
																			case 43:
																				goto IL_049c;
																			case 19:
																			case 33:
																				goto IL_04a7;
																			case 91:
																			case 95:
																				goto IL_04eb;
																			case 57:
																				goto IL_04f9;
																			case 63:
																			case 77:
																				goto IL_0516;
																			case 87:
																				goto IL_053d;
																			case 10:
																			case 34:
																				goto IL_0550;
																			case 25:
																			case 99:
																				goto IL_0568;
																			case 36:
																				goto IL_05a8;
																			case 102:
																				goto IL_05c1;
																			case 106:
																				goto IL_05d4;
																			case 51:
																				goto IL_05e2;
																			case 130:
																				goto IL_05f5;
																			case 4:
																			case 107:
																				goto IL_0608;
																			case 64:
																				goto IL_066a;
																			case 81:
																			case 82:
																				goto IL_067d;
																			case 44:
																			case 56:
																				goto IL_0699;
																			case 121:
																				goto IL_06dd;
																			case 97:
																				goto IL_06f1;
																			case 135:
																				goto IL_0704;
																			case 23:
																			case 48:
																				goto IL_0717;
																			case 94:
																				goto IL_0730;
																			case 18:
																				goto IL_073e;
																			case 103:
																				goto IL_074c;
																			case 110:
																			case 111:
																				goto IL_075f;
																			case 17:
																			case 138:
																				goto IL_07a4;
																			case 113:
																				goto IL_07cd;
																			case 71:
																			case 84:
																				goto IL_07e6;
																			case 67:
																				goto IL_080f;
																			case 30:
																				goto IL_081d;
																			case 133:
																			case 143:
																				goto IL_0830;
																			case 105:
																				goto IL_083e;
																			case 112:
																				goto IL_0861;
																			case 2:
																				goto IL_0874;
																			case 79:
																				goto IL_0882;
																			case 144:
																				goto IL_0892;
																			case 74:
																				goto IL_08a6;
																			case 5:
																			case 11:
																			case 12:
																			case 13:
																			case 14:
																			case 20:
																			case 40:
																			case 45:
																			case 59:
																			case 92:
																			case 98:
																			case 109:
																			case 114:
																			case 115:
																			case 119:
																			case 122:
																				goto end_IL_026b;
																			case 141:
																				goto end_IL_08b4;
																			case 47:
																				goto end_IL_08c7;
																			case 75:
																				goto end_IL_08d2;
																			case 16:
																				goto end_IL_08dc;
																			case 70:
																				goto end_IL_08e7;
																			case 52:
																			case 104:
																				goto end_IL_08f7;
																			case 127:
																				goto end_IL_0907;
																			case 58:
																			case 117:
																				goto end_IL_0917;
																			case 85:
																				goto end_IL_0927;
																			case 86:
																				goto end_IL_0937;
																			case 72:
																			case 126:
																				goto IL_0952;
																			}
																			continue;
																			end_IL_026b:
																			break;
																		}
																		break;
																	}
																	break;
																	IL_027e:
																	if (b <= 15)
																	{
																		goto IL_028c;
																	}
																	goto IL_0452;
																	IL_028c:
																	if (8 >= b)
																	{
																		goto IL_0297;
																	}
																	goto IL_0300;
																	IL_0297:
																	if (8 > b)
																	{
																		goto IL_02a5;
																	}
																	goto IL_0550;
																	IL_02a5:
																	if (4 < b)
																	{
																		goto IL_02b0;
																	}
																	goto IL_02ed;
																	IL_02b0:
																	if (6 >= b)
																	{
																		goto IL_02be;
																	}
																	goto IL_0430;
																	IL_02be:
																	if (6 > b)
																	{
																		goto IL_02cc;
																	}
																	goto IL_04a7;
																	IL_02cc:
																	if (5 >= b)
																	{
																		goto IL_02da;
																	}
																	goto IL_0452;
																	IL_02da:
																	if (5 > b)
																	{
																		goto IL_0452;
																	}
																	goto IL_04eb;
																	IL_04eb:
																	array[num5] = 5;
																	goto IL_04f9;
																	IL_04f9:
																	array2[num5] = array5[*(int*)(ptr2 + num3)];
																	goto IL_05d4;
																	IL_05d4:
																	num5++;
																	goto IL_05e2;
																	IL_05e2:
																	ptr2 += 8;
																	break;
																	IL_04a7:
																	((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05c1;
																	IL_05c1:
																	num5 -= 3;
																	break;
																	IL_0430:
																	if (7 >= b)
																	{
																		goto IL_043b;
																	}
																	goto IL_0452;
																	IL_043b:
																	if (7 > b)
																	{
																		num = 42;
																		goto IL_0452;
																	}
																	goto IL_07e6;
																	IL_067d:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_07e6:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_080f;
																	IL_080f:
																	ptr2 += 8;
																	goto IL_081d;
																	IL_081d:
																	num5--;
																	break;
																	IL_02ed:
																	if (4 > b)
																	{
																		goto IL_03d8;
																	}
																	goto IL_0516;
																	IL_03d8:
																	if (2 >= b)
																	{
																		goto IL_03e3;
																	}
																	goto IL_040c;
																	IL_03e3:
																	if (2 > b)
																	{
																		goto IL_03f1;
																	}
																	goto IL_075f;
																	IL_03f1:
																	if (1 >= b)
																	{
																		goto IL_03fc;
																	}
																	goto IL_0452;
																	IL_03fc:
																	if (1 > b)
																	{
																		goto IL_0452;
																	}
																	goto IL_0717;
																	IL_0717:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0730;
																	IL_0730:
																	array[num5] = 0;
																	goto IL_073e;
																	IL_073e:
																	num5++;
																	goto IL_074c;
																	IL_074c:
																	ptr2 += 8;
																	break;
																	IL_075f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0892;
																	IL_0892:
																	array[num5 - 2] = 0;
																	goto IL_08a6;
																	IL_08a6:
																	num5--;
																	break;
																	IL_040c:
																	if (3 >= b)
																	{
																		goto IL_0417;
																	}
																	goto IL_0452;
																	IL_0417:
																	if (3 > b)
																	{
																		num = 139;
																		goto IL_0452;
																	}
																	goto IL_07a4;
																	IL_0399:
																	if (15 >= b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_0452;
																	IL_07a4:
																	array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																	goto IL_07cd;
																	IL_07cd:
																	array[num5 - 1] = 5;
																	break;
																	IL_0516:
																	array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																	num = 87;
																	goto IL_053d;
																	IL_053d:
																	ptr2 += 8;
																	goto IL_05f5;
																	IL_05f5:
																	num5--;
																	break;
																	IL_0550:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_0300:
																	if (12 >= b)
																	{
																		num = 8;
																		goto IL_0314;
																	}
																	goto IL_035f;
																	IL_03a7:
																	if (15 <= b)
																	{
																	}
																	goto IL_0452;
																	IL_0314:
																	if (12 > b)
																	{
																		goto IL_0322;
																	}
																	goto IL_0568;
																	IL_0322:
																	if (10 >= b)
																	{
																		goto IL_0330;
																	}
																	goto IL_03ba;
																	IL_0330:
																	if (10 > b)
																	{
																		goto IL_033e;
																	}
																	goto IL_0830;
																	IL_033e:
																	if (9 >= b)
																	{
																		goto IL_034c;
																	}
																	goto IL_0452;
																	IL_034c:
																	if (9 <= b)
																	{
																		break;
																	}
																	goto IL_0452;
																	IL_0830:
																	array[num5] = 0;
																	goto IL_083e;
																	IL_083e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0861;
																	IL_0861:
																	array2[num5] = null;
																	num = 2;
																	goto IL_0874;
																	IL_0874:
																	num5++;
																	goto IL_0882;
																	IL_0882:
																	ptr2 += 8;
																	break;
																	IL_03ba:
																	if (11 >= b)
																	{
																		goto IL_03c8;
																	}
																	goto IL_0452;
																	IL_03c8:
																	if (11 > b)
																	{
																		goto IL_0452;
																	}
																	goto IL_0699;
																	IL_0699:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																	goto IL_06dd;
																	IL_06dd:
																	array[num5 - 2] = 0;
																	goto IL_06f1;
																	IL_06f1:
																	num5--;
																	break;
																	IL_0568:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05a8;
																	IL_05a8:
																	array[num5 - 2] = 0;
																	goto IL_0704;
																	IL_0704:
																	num5--;
																	break;
																	IL_035f:
																	if (14 >= b)
																	{
																		goto IL_036a;
																	}
																	goto IL_0399;
																	IL_036a:
																	if (14 > b)
																	{
																		goto IL_0378;
																	}
																	goto IL_067d;
																	IL_0378:
																	if (13 >= b)
																	{
																		goto IL_0386;
																	}
																	goto IL_0452;
																	IL_0386:
																	if (13 > b)
																	{
																		goto IL_0452;
																	}
																	goto IL_0608;
																	IL_0608:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_066a;
																	IL_066a:
																	num5 -= 2;
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0952;
													IL_0952:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08b4:
													break;
												}
												continue;
												end_IL_08c7:
												break;
											}
											continue;
											end_IL_08d2:
											break;
										}
										continue;
										end_IL_08dc:
										break;
									}
									continue;
									end_IL_08e7:
									break;
								}
								continue;
								end_IL_08f7:
								break;
							}
							continue;
							end_IL_0907:
							break;
						}
						continue;
						end_IL_0917:
						break;
					}
					continue;
					end_IL_0927:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_3, int int_4)
	{
		int num = 72;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 61;
						while (true)
						{
							num = 57;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllLocalFilessetIsConsoleEnabled.DecodeXmlNamespaceForClrTypeNamespacecNamedArgs);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0208:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01e8:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01db:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_01cb:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (true)
																											{
																												IL_01a8:
																												if (8 > b)
																												{
																													num = 94;
																													while (num != 94)
																													{
																														if (num != 1075)
																														{
																															goto IL_0275;
																														}
																														switch (num)
																														{
																														case 12:
																															goto IL_01a8;
																														case 33:
																														case 45:
																															goto IL_01bb;
																														case 65:
																														case 70:
																															goto IL_01cb;
																														case 69:
																														case 87:
																															goto IL_01db;
																														case 39:
																															goto IL_01e8;
																														case 52:
																															goto IL_01f8;
																														case 64:
																															goto IL_0208;
																														case 50:
																															goto end_IL_0208;
																														case 21:
																														case 29:
																															goto end_IL_0218;
																														case 28:
																															goto IL_0233;
																														case 58:
																															goto IL_0241;
																														case 83:
																															goto IL_024f;
																														case 13:
																														case 68:
																															goto IL_025d;
																														case 2:
																														case 67:
																															goto IL_0275;
																														case 55:
																															goto IL_029a;
																														case 37:
																														case 84:
																															goto IL_02a8;
																														case 27:
																															goto IL_02b6;
																														case 30:
																															goto IL_02d9;
																														case 22:
																															goto IL_02ec;
																														case 3:
																															goto IL_02fa;
																														case 60:
																															goto IL_030d;
																														case 8:
																														case 75:
																															goto IL_0318;
																														case 78:
																															goto IL_0341;
																														case 5:
																															goto IL_034f;
																														case 23:
																															goto IL_0362;
																														case 51:
																															goto IL_0370;
																														case 24:
																														case 54:
																															goto IL_037e;
																														case 10:
																															goto IL_03ec;
																														case 26:
																															goto IL_03ff;
																														case 48:
																															goto IL_040a;
																														case 1:
																														case 9:
																															goto IL_0428;
																														case 81:
																															goto IL_0433;
																														case 20:
																														case 41:
																															goto IL_043e;
																														case 47:
																															goto IL_047e;
																														case 42:
																															goto IL_0492;
																														case 0:
																														case 16:
																														case 19:
																														case 31:
																														case 32:
																														case 35:
																														case 43:
																														case 59:
																														case 66:
																														case 74:
																														case 76:
																														case 77:
																														case 85:
																														case 86:
																															goto end_IL_0195;
																														case 79:
																															goto IL_04c5;
																														case 38:
																															goto IL_04d3;
																														case 17:
																															goto IL_04ea;
																														case 11:
																														case 14:
																														case 15:
																														case 18:
																														case 25:
																														case 34:
																														case 36:
																														case 40:
																														case 53:
																														case 56:
																														case 73:
																															goto end_IL_0228;
																														case 80:
																															goto end_IL_04f8;
																														case 44:
																															goto end_IL_050b;
																														case 49:
																															goto end_IL_0515;
																														case 82:
																															goto end_IL_0520;
																														case 46:
																															goto end_IL_0535;
																														case 57:
																															goto end_IL_054a;
																														case 61:
																															goto end_IL_055a;
																														case 62:
																															goto end_IL_056a;
																														case 4:
																														case 63:
																															goto end_IL_0575;
																														case 71:
																															goto end_IL_058e;
																														case 72:
																															goto end_IL_059e;
																														case 6:
																														case 7:
																															goto IL_05b9;
																														}
																														continue;
																														end_IL_0195:
																														break;
																													}
																													break;
																												}
																												goto IL_0275;
																												IL_0275:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 40;
																												goto end_IL_0228;
																											}
																											break;
																											IL_01bb:;
																										}
																										break;
																									}
																									goto IL_029a;
																									IL_02fa:
																									ptr2 += 8;
																									goto end_IL_0228;
																									IL_029a:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_02a8;
																									IL_02a8:
																									array[num6] = 0;
																									goto IL_02b6;
																									IL_02b6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_02d9;
																									IL_02d9:
																									array2[num6] = null;
																									num = 22;
																									goto IL_02ec;
																									IL_02ec:
																									num6++;
																									goto IL_02fa;
																								}
																								break;
																							}
																							goto IL_0233;
																							IL_025d:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0228;
																							IL_0233:
																							if (6 <= b)
																							{
																								goto end_IL_0228;
																							}
																							goto IL_0241;
																							IL_0241:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_024f;
																							IL_024f:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_025d;
																						}
																						break;
																					}
																					goto IL_030d;
																					IL_047e:
																					array[num6 - 2] = 0;
																					goto IL_0492;
																					IL_030d:
																					if (4 <= b)
																					{
																						goto IL_0318;
																					}
																					goto IL_0362;
																					IL_0318:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0341;
																					IL_0341:
																					ptr2 += 8;
																					goto IL_034f;
																					IL_034f:
																					num6--;
																					goto end_IL_0228;
																					IL_0362:
																					if (2 >= b)
																					{
																						goto IL_0370;
																					}
																					goto IL_0428;
																					IL_0370:
																					if (2 <= b)
																					{
																						goto IL_037e;
																					}
																					goto IL_03ff;
																					IL_037e:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03ec;
																					IL_03ec:
																					num6 -= 2;
																					goto end_IL_0228;
																					IL_03ff:
																					if (1 < b)
																					{
																						num = 66;
																						break;
																					}
																					goto IL_040a;
																					IL_040a:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0492:
																					num6--;
																					goto end_IL_0228;
																					IL_0428:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0433;
																					IL_0433:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_043e;
																					IL_043e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_047e;
																				}
																				break;
																				IL_01f8:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04c5;
																		IL_04ea:
																		ptr2 += 8;
																		goto end_IL_0228;
																		IL_04d3:
																		num6++;
																		num = 17;
																		goto IL_04ea;
																		IL_04c5:
																		array[num6] = 0;
																		goto IL_04d3;
																		continue;
																		end_IL_0208:
																		break;
																	}
																	continue;
																	end_IL_0218:
																	break;
																}
																continue;
																end_IL_0228:
																break;
															}
															continue;
														}
														goto IL_05b9;
														IL_05b9:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_04f8:
														break;
													}
													continue;
													end_IL_050b:
													break;
												}
												continue;
												end_IL_0515:
												break;
											}
											continue;
											end_IL_0520:
											break;
										}
										continue;
										end_IL_0535:
										break;
									}
									continue;
									end_IL_054a:
									break;
								}
								continue;
								end_IL_055a:
								break;
							}
							continue;
							end_IL_056a:
							break;
						}
						continue;
						end_IL_0575:
						break;
					}
					continue;
					end_IL_058e:
					break;
				}
				continue;
				end_IL_059e:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 66;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSponsorshipTimeoutGetEnvironmentVariables.TokenGroupsAndPrivilegessetFilterLevel);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02b9:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0299:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0286:
																						if (6 > b)
																						{
																							num = 32;
																							while (true)
																							{
																								IL_0279:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0269:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0230:
																														array[num5] = 0;
																														num = 128;
																														while (true)
																														{
																															if (num != 128)
																															{
																																if (num != 1109)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 42:
																																case 104:
																																	goto IL_0230;
																																case 6:
																																	goto IL_0249;
																																case 44:
																																case 112:
																																	goto IL_0259;
																																case 40:
																																case 83:
																																	goto IL_0269;
																																case 32:
																																case 70:
																																	goto IL_0279;
																																case 61:
																																	goto IL_0286;
																																case 81:
																																	goto IL_0299;
																																case 38:
																																	goto IL_02a9;
																																case 92:
																																	goto IL_02b9;
																																case 43:
																																	goto end_IL_02b9;
																																case 95:
																																case 108:
																																	goto end_IL_02c9;
																																case 29:
																																	goto IL_02e4;
																																case 17:
																																case 99:
																																	goto IL_02f2;
																																case 35:
																																	goto IL_02fd;
																																case 3:
																																	goto IL_0310;
																																case 7:
																																	goto IL_031e;
																																case 12:
																																case 101:
																																	goto IL_032c;
																																case 91:
																																	goto IL_036c;
																																case 72:
																																	goto IL_0380;
																																case 58:
																																case 105:
																																	goto IL_0393;
																																case 88:
																																	goto IL_03d3;
																																case 33:
																																	goto IL_03e7;
																																case 54:
																																case 110:
																																	goto IL_03fa;
																																case 77:
																																	goto IL_0423;
																																case 11:
																																	goto IL_0431;
																																case 10:
																																	goto IL_0470;
																																case 55:
																																	goto IL_047a;
																																case 9:
																																	goto IL_0488;
																																case 118:
																																	goto IL_049b;
																																case 23:
																																case 63:
																																	goto end_IL_021d;
																																case 26:
																																	goto IL_04e9;
																																case 31:
																																	goto IL_0506;
																																case 51:
																																case 80:
																																	goto IL_0522;
																																case 8:
																																case 75:
																																	goto IL_052d;
																																case 2:
																																case 16:
																																	goto IL_0538;
																																case 96:
																																	goto IL_0546;
																																case 25:
																																case 117:
																																	goto IL_0554;
																																case 107:
																																	goto IL_0570;
																																case 13:
																																case 119:
																																	goto IL_057e;
																																case 62:
																																	goto IL_0591;
																																case 24:
																																case 64:
																																	goto IL_059c;
																																case 121:
																																	goto IL_05b0;
																																case 53:
																																	goto IL_05ef;
																																case 57:
																																	goto IL_0602;
																																case 39:
																																	goto IL_060d;
																																case 60:
																																case 98:
																																	goto IL_061b;
																																case 5:
																																	goto IL_0634;
																																case 22:
																																	goto IL_0642;
																																case 97:
																																	goto IL_0659;
																																case 52:
																																	goto IL_066c;
																																case 115:
																																	goto IL_0683;
																																case 30:
																																case 65:
																																	goto IL_068e;
																																case 37:
																																	goto IL_06d7;
																																case 56:
																																	goto IL_06eb;
																																case 4:
																																case 14:
																																case 15:
																																case 27:
																																case 28:
																																case 34:
																																case 46:
																																case 48:
																																case 49:
																																case 67:
																																case 68:
																																case 73:
																																case 78:
																																case 79:
																																case 82:
																																case 89:
																																case 103:
																																case 109:
																																case 111:
																																case 113:
																																	goto end_IL_0249;
																																case 106:
																																	goto IL_071e;
																																case 76:
																																	goto IL_072c;
																																case 94:
																																	goto IL_073a;
																																case 0:
																																case 1:
																																case 18:
																																case 20:
																																case 36:
																																case 47:
																																case 71:
																																case 74:
																																case 84:
																																case 93:
																																case 100:
																																case 102:
																																case 114:
																																	goto end_IL_02d9;
																																case 116:
																																	goto end_IL_0748;
																																case 45:
																																	goto end_IL_075b;
																																case 66:
																																	goto end_IL_0765;
																																case 21:
																																	goto end_IL_0770;
																																case 50:
																																	goto end_IL_0785;
																																case 19:
																																case 87:
																																	goto end_IL_07a3;
																																case 59:
																																	goto end_IL_07b3;
																																case 90:
																																case 120:
																																	goto end_IL_07c3;
																																case 85:
																																	goto end_IL_07d3;
																																case 86:
																																	goto end_IL_07e3;
																																case 41:
																																case 69:
																																	goto IL_07fe;
																																}
																																continue;
																															}
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_0470;
																															IL_0470:
																															array2[num5] = null;
																															goto IL_047a;
																															IL_0488:
																															ptr2 += 8;
																															goto end_IL_02d9;
																															IL_047a:
																															num5++;
																															goto IL_0488;
																															continue;
																															end_IL_021d:
																															break;
																														}
																														break;
																													}
																													goto IL_04a9;
																													continue;
																													end_IL_0249:
																													break;
																													IL_0249:;
																												}
																												break;
																												IL_0259:;
																											}
																											break;
																										}
																										goto IL_049b;
																										IL_0506:
																										num5--;
																										goto end_IL_02d9;
																										IL_049b:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_04a9;
																										IL_04a9:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04e9;
																										IL_04e9:
																										array[num5 - 2] = 0;
																										num = 31;
																										goto IL_0506;
																									}
																									break;
																								}
																								goto IL_02e4;
																								IL_0431:
																								num5--;
																								num = 100;
																								goto end_IL_02d9;
																								IL_02e4:
																								if (3 > b)
																								{
																									goto IL_02f2;
																								}
																								goto IL_03fa;
																								IL_02f2:
																								if (1 >= b)
																								{
																									goto IL_02fd;
																								}
																								goto IL_0310;
																								IL_02fd:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0310:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_031e;
																								IL_031e:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_032c;
																								IL_032c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_036c;
																								IL_036c:
																								array[num5 - 2] = 0;
																								goto IL_0380;
																								IL_0380:
																								num5--;
																								goto end_IL_02d9;
																								IL_03fa:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0423;
																								IL_0423:
																								ptr2 += 8;
																								goto IL_0431;
																							}
																							break;
																						}
																						goto IL_0393;
																						IL_03d3:
																						array[num5 - 2] = 0;
																						goto IL_03e7;
																						IL_03e7:
																						num5--;
																						goto end_IL_02d9;
																						IL_0393:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03d3;
																					}
																					break;
																				}
																				num = 80;
																				goto IL_0522;
																				IL_068e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 37;
																				goto IL_06d7;
																				IL_06d7:
																				array[num5 - 2] = 0;
																				goto IL_06eb;
																				IL_0522:
																				if (9 < b)
																				{
																					goto IL_052d;
																				}
																				goto IL_0591;
																				IL_052d:
																				if (10 < b)
																				{
																					goto IL_0538;
																				}
																				goto IL_0570;
																				IL_0538:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0546;
																				IL_0546:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0554;
																				IL_0554:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02d9;
																				IL_0570:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_057e;
																				IL_057e:
																				num5--;
																				goto end_IL_02d9;
																				IL_0591:
																				if (9 <= b)
																				{
																					goto IL_059c;
																				}
																				goto IL_0602;
																				IL_059c:
																				array[num5 - 1] = 0;
																				goto IL_05b0;
																				IL_05b0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CreateOriginSchemeAccessgetShortestDayNames[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_05ef;
																				IL_05ef:
																				ptr2 += 8;
																				goto end_IL_02d9;
																				IL_0602:
																				if (7 >= b)
																				{
																					goto IL_060d;
																				}
																				goto IL_066c;
																				IL_060d:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_061b;
																				IL_061b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0634;
																				IL_0634:
																				array[num5] = 0;
																				goto IL_0642;
																				IL_0642:
																				num5++;
																				num = 97;
																				goto IL_0659;
																				IL_0659:
																				ptr2 += 8;
																				goto end_IL_02d9;
																				IL_066c:
																				if (8 < b)
																				{
																					break;
																				}
																				num = 115;
																				goto IL_0683;
																				IL_06eb:
																				num5--;
																				goto end_IL_02d9;
																				IL_0683:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_068e;
																			}
																			break;
																			IL_02a9:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_071e;
																	IL_073a:
																	ptr2 += 8;
																	goto end_IL_02d9;
																	IL_072c:
																	num5++;
																	goto IL_073a;
																	IL_071e:
																	array[num5] = 0;
																	goto IL_072c;
																	continue;
																	end_IL_02b9:
																	break;
																}
																continue;
																end_IL_02c9:
																break;
															}
															continue;
															end_IL_02d9:
															break;
														}
														continue;
													}
													goto IL_07fe;
													IL_07fe:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0748:
													break;
												}
												continue;
												end_IL_075b:
												break;
											}
											continue;
											end_IL_0765:
											break;
										}
										continue;
										end_IL_0770:
										break;
									}
									continue;
									end_IL_0785:
									break;
								}
								continue;
								end_IL_07a3:
								break;
							}
							continue;
							end_IL_07b3:
							break;
						}
						continue;
						end_IL_07c3:
						break;
					}
					continue;
					end_IL_07d3:
					break;
				}
				continue;
				end_IL_07e3:
				break;
			}
		}
	}
}
