using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 41)]
internal struct BCLDebugISTOREENUMFILESFLAGS
{
	internal static BCLDebugISTOREENUMFILESFLAGS getMajorMonitoringIsEnabled/* Not supported: data(01 00 00 00 00 00 00 00 00 02 03 01 00 00 00 00 00 00 00 00 04 FF FF FF EA EA FF FF FF 04 00 00 00 0B 0B 00 00 00 05 06 07) */;
}
