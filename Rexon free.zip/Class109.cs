using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Turkey Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns turkeys.", false, 14, ModType.const_0, false)]
internal class Class109 : Class93
{
	private static bool bool_0;

	private static int int_3;

	private static float float_0;

	private static int int_4;

	private static int int_5;

	private static double double_1;

	private static IntPtr[] HexIntgetHasCurrent;

	private static IntPtr[] RsagetFailure;

	private static IntPtr[] CLRSurrogateClassNameDelete;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_037b, IL_038e, IL_03a7, IL_03b7, IL_03c7, IL_03e2, IL_03f2, IL_0402, IL_0412, IL_041f, IL_042f, IL_043f, IL_044f, IL_045a, IL_0465, IL_0473, IL_0481, IL_048f, IL_049c, IL_04af, IL_04bf, IL_04d2, IL_04e0, IL_0542, IL_0555, IL_0563, IL_0571, IL_057c, IL_058a, IL_059d, IL_05e2, IL_0622, IL_0636, IL_0649, IL_0689, IL_06a2, IL_06ad, IL_06bb, IL_06c9, IL_06d9, IL_06e7, IL_0710, IL_071e, IL_0731, IL_0754, IL_0767, IL_0775, IL_0788, IL_079b, IL_07a9, IL_07b7, IL_07c5, IL_07d3, IL_0813, IL_0827, IL_083a, IL_084d, IL_085b, IL_089b, IL_08af, IL_08c2, IL_08d5, IL_08e9, IL_08fc, IL_090a, IL_0915, IL_0933, IL_0941, IL_0954, IL_0962, IL_0970, IL_097e, IL_099b, IL_09ea, IL_09f4, IL_0a21, IL_0a35, IL_0a43, IL_0a56, IL_0a64, IL_0a77, IL_0a85, IL_0a93, IL_0aa1, IL_0ab9, IL_0ad7, IL_0b04, IL_0b1c, IL_0b2f, IL_0b3d, IL_0b66, IL_0b7f, IL_0b8d, IL_0bb1, IL_0bbf, IL_0bd2, IL_0bea, IL_0bf8, IL_0c0b, IL_0c16, IL_0c24, IL_0c62, IL_0c75, IL_0c83, IL_0c91, IL_0ca5, IL_0cdd, IL_0cf0, IL_0cfb, IL_0d06, IL_0d11, IL_0d33, IL_0d3e, IL_0d53, IL_0d6c, IL_0d7a, IL_0d88, IL_0d96, IL_0da9, IL_0db3, IL_0dbe, IL_0dce, IL_0dde, IL_0dee, IL_0dfe, IL_0e0e, IL_0e1e, IL_0e2e, IL_0e3e, IL_0e62 are reachable both inside and outside the pinned region starting at IL_0e53. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 161;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef20 = default(int);
				ref int reference = ref __rxRef20;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					num = 160;
					while (true)
					{
						IL_0e3e:
						num2 = 1;
						while (true)
						{
							IL_0e2e:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e1e:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e0e:
									array2 = new byte[4];
									while (true)
									{
										IL_0dfe:
										array3 = new object[4];
										while (true)
										{
											IL_0dee:
											array4 = new int[4];
											while (true)
											{
												IL_0dde:
												array5 = new int[6];
												while (true)
												{
													IL_0dce:
													array6 = new long[4];
													while (true)
													{
														IL_0dbe:
														array7 = new object[9];
														while (true)
														{
															IL_0db3:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCreationOptionsTrademark.DateTimeParseReport);
															while (true)
															{
																IL_0da9:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_044f:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_043f:
																				ptr2++;
																				while (true)
																				{
																					IL_042f:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0412:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_0402:
																										if (17 < b)
																										{
																											while (true)
																											{
																												IL_03f2:
																												if (20 >= b)
																												{
																													while (true)
																													{
																														IL_03e2:
																														if (20 <= b)
																														{
																															while (true)
																															{
																																IL_03c7:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																																while (true)
																																{
																																	IL_03b7:
																																	array2[num6] = 1;
																																	while (true)
																																	{
																																		IL_03a7:
																																		num6++;
																																		while (true)
																																		{
																																			IL_038e:
																																			ptr2 += 16;
																																			num = 219;
																																			while (num != 219)
																																			{
																																				if (num != 1200)
																																				{
																																					goto IL_03c7;
																																				}
																																				switch (num)
																																				{
																																				case 161:
																																					break;
																																				default:
																																					continue;
																																				case 157:
																																					goto IL_038e;
																																				case 29:
																																					goto IL_03a7;
																																				case 0:
																																					goto IL_03b7;
																																				case 166:
																																				case 202:
																																					goto IL_03c7;
																																				case 205:
																																					goto IL_03e2;
																																				case 98:
																																					goto IL_03f2;
																																				case 9:
																																				case 211:
																																					goto IL_0402;
																																				case 39:
																																					goto IL_0412;
																																				case 208:
																																					goto IL_041f;
																																				case 165:
																																					goto IL_042f;
																																				case 28:
																																					goto IL_043f;
																																				case 63:
																																				case 168:
																																					goto IL_044f;
																																				case 49:
																																					goto IL_045a;
																																				case 85:
																																					goto IL_0473;
																																				case 88:
																																					goto IL_0481;
																																				case 45:
																																					goto IL_048f;
																																				case 108:
																																					goto IL_049c;
																																				case 36:
																																				case 116:
																																					goto IL_04af;
																																				case 123:
																																					goto IL_04bf;
																																				case 133:
																																					goto IL_04d2;
																																				case 104:
																																				case 140:
																																					goto IL_04e0;
																																				case 21:
																																					goto IL_0542;
																																				case 141:
																																					goto IL_0555;
																																				case 69:
																																					goto IL_0563;
																																				case 48:
																																					goto IL_0571;
																																				case 138:
																																					goto IL_057c;
																																				case 25:
																																					goto IL_058a;
																																				case 26:
																																				case 145:
																																					goto IL_059d;
																																				case 126:
																																				case 146:
																																					goto IL_05e2;
																																				case 37:
																																					goto IL_0622;
																																				case 30:
																																					goto IL_0636;
																																				case 60:
																																				case 156:
																																					goto IL_0649;
																																				case 31:
																																					goto IL_0689;
																																				case 17:
																																				case 159:
																																					goto IL_06a2;
																																				case 120:
																																					goto IL_06ad;
																																				case 114:
																																					goto IL_06bb;
																																				case 70:
																																				case 147:
																																					goto IL_06c9;
																																				case 167:
																																					goto IL_06d9;
																																				case 8:
																																				case 34:
																																					goto IL_06e7;
																																				case 77:
																																					goto IL_0710;
																																				case 136:
																																					goto IL_071e;
																																				case 179:
																																					goto IL_0731;
																																				case 5:
																																					goto IL_0754;
																																				case 27:
																																					goto IL_0767;
																																				case 158:
																																					goto IL_0775;
																																				case 33:
																																				case 185:
																																					goto IL_0788;
																																				case 187:
																																					goto IL_079b;
																																				case 12:
																																				case 82:
																																					goto IL_07a9;
																																				case 163:
																																					goto IL_07b7;
																																				case 99:
																																					goto IL_07c5;
																																				case 13:
																																				case 52:
																																					goto IL_07d3;
																																				case 107:
																																					goto IL_0813;
																																				case 124:
																																					goto IL_0827;
																																				case 59:
																																				case 180:
																																					goto IL_083a;
																																				case 188:
																																					goto IL_084d;
																																				case 58:
																																				case 72:
																																					goto IL_085b;
																																				case 134:
																																					goto IL_089b;
																																				case 97:
																																					goto IL_08af;
																																				case 193:
																																					goto IL_08c2;
																																				case 196:
																																					goto IL_08d5;
																																				case 155:
																																					goto IL_08e9;
																																				case 24:
																																				case 197:
																																					goto IL_08fc;
																																				case 14:
																																					goto IL_090a;
																																				case 6:
																																				case 10:
																																					goto IL_0915;
																																				case 94:
																																					goto IL_0933;
																																				case 106:
																																					goto IL_0941;
																																				case 190:
																																					goto IL_0954;
																																				case 2:
																																				case 115:
																																					goto IL_0962;
																																				case 22:
																																					goto IL_0970;
																																				case 3:
																																				case 41:
																																					goto IL_097e;
																																				case 96:
																																					goto IL_0a35;
																																				case 144:
																																					goto IL_0a43;
																																				case 75:
																																					goto IL_0a64;
																																				case 127:
																																					goto IL_0a77;
																																				case 169:
																																				case 186:
																																					goto IL_0a85;
																																				case 129:
																																					goto IL_0a93;
																																				case 1:
																																				case 121:
																																					goto IL_0aa1;
																																				case 175:
																																					goto IL_0ab9;
																																				case 177:
																																					goto IL_0ad7;
																																				case 135:
																																					goto IL_0b04;
																																				case 194:
																																					goto IL_0b1c;
																																				case 83:
																																					goto IL_0b2f;
																																				case 78:
																																				case 128:
																																					goto IL_0b3d;
																																				case 170:
																																					goto IL_0b66;
																																				case 79:
																																				case 199:
																																					goto IL_0b7f;
																																				case 173:
																																					goto IL_0b8d;
																																				case 119:
																																					goto IL_0bb1;
																																				case 65:
																																					goto IL_0bbf;
																																				case 210:
																																					goto IL_0bd2;
																																				case 89:
																																					goto IL_0bea;
																																				case 152:
																																					goto IL_0bf8;
																																				case 103:
																																					goto IL_0c0b;
																																				case 68:
																																					goto IL_0c16;
																																				case 35:
																																				case 125:
																																					goto IL_0c24;
																																				case 92:
																																					goto IL_0c62;
																																				case 19:
																																					goto IL_0c75;
																																				case 112:
																																					goto IL_0c83;
																																				case 15:
																																				case 55:
																																					goto IL_0c91;
																																				case 61:
																																					goto IL_0ca5;
																																				case 111:
																																					goto IL_0cdd;
																																				case 154:
																																					goto IL_0cf0;
																																				case 74:
																																				case 105:
																																					goto IL_0cfb;
																																				case 7:
																																					goto IL_0d06;
																																				case 51:
																																				case 149:
																																					goto IL_0d11;
																																				case 148:
																																					goto IL_0d33;
																																				case 66:
																																				case 204:
																																					goto IL_0d3e;
																																				case 16:
																																				case 43:
																																				case 47:
																																				case 50:
																																				case 53:
																																				case 54:
																																				case 56:
																																				case 57:
																																				case 62:
																																				case 76:
																																				case 80:
																																				case 84:
																																				case 90:
																																				case 93:
																																				case 100:
																																				case 101:
																																				case 110:
																																				case 117:
																																				case 118:
																																				case 122:
																																				case 130:
																																				case 131:
																																				case 132:
																																				case 142:
																																				case 151:
																																				case 153:
																																				case 162:
																																				case 164:
																																				case 176:
																																				case 178:
																																				case 183:
																																				case 191:
																																				case 192:
																																				case 195:
																																				case 203:
																																				case 207:
																																				case 209:
																																					goto end_IL_041f;
																																				case 87:
																																					goto IL_0d6c;
																																				case 184:
																																					goto IL_0d7a;
																																				case 198:
																																					goto IL_0d88;
																																				case 11:
																																				case 18:
																																				case 20:
																																				case 23:
																																				case 32:
																																				case 38:
																																				case 40:
																																				case 44:
																																				case 46:
																																				case 64:
																																				case 71:
																																				case 73:
																																				case 81:
																																				case 86:
																																				case 91:
																																				case 95:
																																				case 113:
																																				case 137:
																																				case 139:
																																				case 143:
																																				case 150:
																																				case 189:
																																				case 206:
																																				case 212:
																																					goto end_IL_037b;
																																				case 102:
																																					goto IL_0da9;
																																				case 201:
																																					goto IL_0db3;
																																				case 181:
																																					goto IL_0dbe;
																																				case 171:
																																					goto IL_0dce;
																																				case 182:
																																					goto IL_0dde;
																																				case 109:
																																					goto IL_0dee;
																																				case 174:
																																					goto IL_0dfe;
																																				case 4:
																																					goto IL_0e0e;
																																				case 42:
																																					goto IL_0e1e;
																																				case 200:
																																					goto IL_0e2e;
																																				case 160:
																																					goto IL_0e3e;
																																				case 67:
																																				case 172:
																																					goto IL_0e62;
																																				}
																																				goto end_IL_0d96;
																																				continue;
																																				end_IL_037b:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0c0b;
																														IL_0cdd:
																														ptr2 += 8;
																														break;
																														IL_0c0b:
																														if (18 >= b)
																														{
																															goto IL_0c16;
																														}
																														goto IL_0c75;
																														IL_0c16:
																														if (18 > b)
																														{
																															goto end_IL_041f;
																														}
																														goto IL_0c24;
																														IL_0c24:
																														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																														goto IL_0c62;
																														IL_0c62:
																														num6 -= 3;
																														break;
																														IL_0c75:
																														if (19 < b)
																														{
																															goto end_IL_041f;
																														}
																														goto IL_0c83;
																														IL_0c83:
																														if (19 > b)
																														{
																															goto end_IL_041f;
																														}
																														goto IL_0c91;
																														IL_0c91:
																														array2[num6 - 1] = 5;
																														goto IL_0ca5;
																														IL_0ca5:
																														array3[num6 - 1] = ((delegate*<string[], string>)HexIntgetHasCurrent[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																														goto IL_0cdd;
																													}
																													break;
																												}
																												goto IL_0cf0;
																												IL_0d3e:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												break;
																												IL_0cf0:
																												if (21 < b)
																												{
																													goto IL_0cfb;
																												}
																												goto IL_0d33;
																												IL_0cfb:
																												if (22 < b)
																												{
																													goto end_IL_041f;
																												}
																												goto IL_0d06;
																												IL_0d06:
																												if (22 > b)
																												{
																													goto end_IL_041f;
																												}
																												goto IL_0d11;
																												IL_0d11:
																												num7 = ptr2;
																												num8 = -200;
																												num5 = 1;
																												ptr2 = num7 + num8;
																												num = 46;
																												break;
																												IL_0d33:
																												if (21 > b)
																												{
																													goto end_IL_041f;
																												}
																												goto IL_0d3e;
																											}
																											break;
																										}
																										goto IL_049c;
																										IL_0b66:
																										array2[num6 - 1] = 5;
																										break;
																										IL_049c:
																										if (17 <= b)
																										{
																											goto IL_0788;
																										}
																										goto IL_08fc;
																										IL_08fc:
																										if (14 >= b)
																										{
																											goto IL_090a;
																										}
																										goto IL_0a77;
																										IL_090a:
																										if (14 <= b)
																										{
																											goto IL_0915;
																										}
																										goto IL_0954;
																										IL_0915:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_0933;
																										IL_0933:
																										ptr2 += 8;
																										goto IL_0941;
																										IL_0941:
																										num6--;
																										break;
																										IL_0954:
																										if (12 < b)
																										{
																											goto IL_0962;
																										}
																										goto IL_0a64;
																										IL_0962:
																										if (13 < b)
																										{
																											num = 43;
																											goto end_IL_041f;
																										}
																										goto IL_0970;
																										IL_0970:
																										if (13 > b)
																										{
																											goto end_IL_041f;
																										}
																										goto IL_097e;
																										IL_097e:
																										array8 = array3;
																										num9 = num6;
																										if (array == null)
																										{
																											goto IL_098d;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0a35;
																										IL_0bd2:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_0bea;
																										IL_0bea:
																										num6++;
																										goto IL_0bf8;
																										IL_0bf8:
																										ptr2 += 8;
																										break;
																										IL_0a35:
																										array2[num6] = 5;
																										goto IL_0a43;
																										IL_0a43:
																										num6++;
																										break;
																										IL_0788:
																										array2[num6] = 5;
																										goto IL_0bd2;
																										IL_0a64:
																										if (12 <= b)
																										{
																											break;
																										}
																										goto end_IL_041f;
																										IL_0a77:
																										if (15 < b)
																										{
																											goto IL_0a85;
																										}
																										goto IL_0b2f;
																										IL_0a85:
																										if (16 < b)
																										{
																											goto end_IL_041f;
																										}
																										goto IL_0a93;
																										IL_0a93:
																										if (16 > b)
																										{
																											goto end_IL_041f;
																										}
																										goto IL_0aa1;
																										IL_0aa1:
																										array2[num6] = array2[num6 - 1];
																										goto IL_0ab9;
																										IL_0ab9:
																										array4[num6 - 0] = array4[num6 - 1];
																										goto IL_0ad7;
																										IL_0ad7:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										num = 135;
																										goto IL_0b04;
																										IL_0b04:
																										array3[num6] = array3[num6 - 1];
																										goto IL_0b1c;
																										IL_0b1c:
																										num6++;
																										break;
																										IL_0b2f:
																										if (15 > b)
																										{
																											goto end_IL_041f;
																										}
																										goto IL_0b3d;
																										IL_0b3d:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_0b66;
																									}
																									break;
																								}
																								goto IL_045a;
																								IL_0689:
																								array2[num6 - 2] = 0;
																								goto IL_08c2;
																								IL_045a:
																								if (11 > b)
																								{
																									goto IL_0473;
																								}
																								num = 79;
																								goto IL_0b7f;
																								IL_08c2:
																								num6--;
																								break;
																								IL_0b7f:
																								array2[num6] = 0;
																								goto IL_0b8d;
																								IL_0b8d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)HexIntgetHasCurrent[*(int*)(ptr2 + num3)])();
																								goto IL_0bb1;
																								IL_0bb1:
																								num6++;
																								goto IL_0bbf;
																								IL_0bbf:
																								ptr2 += 8;
																								break;
																								IL_0473:
																								if (5 < b)
																								{
																									goto IL_0481;
																								}
																								goto IL_0555;
																								IL_0481:
																								if (8 < b)
																								{
																									goto IL_048f;
																								}
																								goto IL_079b;
																								IL_048f:
																								if (9 < b)
																								{
																									goto IL_04af;
																								}
																								goto IL_04bf;
																								IL_04af:
																								if (10 < b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_04d2;
																								IL_04d2:
																								if (10 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_04e0;
																								IL_04e0:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0542;
																								IL_0542:
																								num6 -= 2;
																								break;
																								IL_04bf:
																								if (9 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_059d;
																								IL_059d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_08d5;
																								IL_08d5:
																								array2[num6 - 2] = 0;
																								goto IL_08e9;
																								IL_08e9:
																								num6--;
																								break;
																								IL_079b:
																								if (8 > b)
																								{
																									goto IL_07a9;
																								}
																								goto IL_083a;
																								IL_07a9:
																								if (6 < b)
																								{
																									goto IL_07b7;
																								}
																								goto IL_084d;
																								IL_07b7:
																								if (7 < b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_07c5;
																								IL_07c5:
																								if (7 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_07d3;
																								IL_07d3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0813;
																								IL_0813:
																								array2[num6 - 2] = 0;
																								goto IL_0827;
																								IL_0827:
																								num6--;
																								break;
																								IL_084d:
																								if (6 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_085b;
																								IL_085b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_089b;
																								IL_089b:
																								array2[num6 - 2] = 0;
																								goto IL_08af;
																								IL_08af:
																								num6--;
																								break;
																								IL_083a:
																								num6--;
																								break;
																								IL_0555:
																								if (5 > b)
																								{
																									goto IL_0563;
																								}
																								goto IL_0649;
																								IL_0563:
																								if (2 >= b)
																								{
																									goto IL_0571;
																								}
																								goto IL_06a2;
																								IL_0571:
																								if (2 > b)
																								{
																									goto IL_057c;
																								}
																								goto IL_05e2;
																								IL_057c:
																								if (1 < b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_058a;
																								IL_058a:
																								if (1 > b)
																								{
																								}
																								goto end_IL_041f;
																								IL_05e2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0622;
																								IL_0622:
																								array2[num6 - 2] = 0;
																								goto IL_0636;
																								IL_0636:
																								num6--;
																								break;
																								IL_06a2:
																								if (3 < b)
																								{
																									goto IL_06ad;
																								}
																								goto IL_06d9;
																								IL_06ad:
																								if (4 < b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_06bb;
																								IL_06bb:
																								if (4 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_06c9;
																								IL_06c9:
																								array2[num6] = 0;
																								goto IL_0731;
																								IL_0731:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0754;
																								IL_0754:
																								array3[num6] = null;
																								num = 27;
																								goto IL_0767;
																								IL_0767:
																								num6++;
																								goto IL_0775;
																								IL_0775:
																								ptr2 += 8;
																								break;
																								IL_06d9:
																								if (3 > b)
																								{
																									goto end_IL_041f;
																								}
																								goto IL_06e7;
																								IL_06e7:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0710;
																								IL_0710:
																								ptr2 += 8;
																								goto IL_071e;
																								IL_071e:
																								num6--;
																								break;
																								IL_0649:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0689;
																							}
																							goto end_IL_042f;
																							continue;
																							end_IL_041f:
																							break;
																							IL_041f:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d6c;
																					IL_0d88:
																					ptr2 += 8;
																					break;
																					IL_0d7a:
																					num6++;
																					goto IL_0d88;
																					IL_0d6c:
																					array2[num6] = 0;
																					goto IL_0d7a;
																					continue;
																					end_IL_042f:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0e62;
																	IL_0e62:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0d96:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_098d:
				while (true)
				{
					IL_098d_2:
					array = new byte[4];
					while (true)
					{
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							IL_0a35_2:
							array2[num6] = 5;
							while (true)
							{
								IL_0a43_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_044f_2:
											byte b = *ptr2;
											while (true)
											{
												IL_043f_2:
												ptr2++;
												while (true)
												{
													IL_042f_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_0412_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_0402_2:
																		if (17 < b)
																		{
																			while (true)
																			{
																				IL_03f2_2:
																				if (20 >= b)
																				{
																					while (true)
																					{
																						IL_03e2_2:
																						if (20 <= b)
																						{
																							while (true)
																							{
																								IL_03c7_2:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								while (true)
																								{
																									IL_03b7_2:
																									array2[num6] = 1;
																									while (true)
																									{
																										IL_03a7_2:
																										num6++;
																										while (true)
																										{
																											IL_038e_2:
																											ptr2 += 16;
																											num = 219;
																											while (num != 219)
																											{
																												if (num != 1200)
																												{
																													goto IL_03c7_2;
																												}
																												switch (num)
																												{
																												case 157:
																													goto IL_038e_2;
																												case 29:
																													goto IL_03a7_2;
																												case 0:
																													goto IL_03b7_2;
																												case 166:
																												case 202:
																													goto IL_03c7_2;
																												case 205:
																													goto IL_03e2_2;
																												case 98:
																													goto IL_03f2_2;
																												case 9:
																												case 211:
																													goto IL_0402_2;
																												case 39:
																													goto IL_0412_2;
																												case 208:
																													goto IL_041f_2;
																												case 165:
																													goto IL_042f_2;
																												case 28:
																													goto IL_043f_2;
																												case 63:
																												case 168:
																													goto IL_044f_2;
																												case 49:
																													goto IL_045a_2;
																												case 85:
																													goto IL_0473_2;
																												case 88:
																													goto IL_0481_2;
																												case 45:
																													goto IL_048f_2;
																												case 108:
																													goto IL_049c_2;
																												case 36:
																												case 116:
																													goto IL_04af_2;
																												case 123:
																													goto IL_04bf_2;
																												case 133:
																													goto IL_04d2_2;
																												case 104:
																												case 140:
																													goto IL_04e0_2;
																												case 21:
																													goto IL_0542_2;
																												case 141:
																													goto IL_0555_2;
																												case 69:
																													goto IL_0563_2;
																												case 48:
																													goto IL_0571_2;
																												case 138:
																													goto IL_057c_2;
																												case 25:
																													goto IL_058a_2;
																												case 26:
																												case 145:
																													goto IL_059d_2;
																												case 126:
																												case 146:
																													goto IL_05e2_2;
																												case 37:
																													goto IL_0622_2;
																												case 30:
																													goto IL_0636_2;
																												case 60:
																												case 156:
																													goto IL_0649_2;
																												case 31:
																													goto IL_0689_2;
																												case 17:
																												case 159:
																													goto IL_06a2_2;
																												case 120:
																													goto IL_06ad_2;
																												case 114:
																													goto IL_06bb_2;
																												case 70:
																												case 147:
																													goto IL_06c9_2;
																												case 167:
																													goto IL_06d9_2;
																												case 8:
																												case 34:
																													goto IL_06e7_2;
																												case 77:
																													goto IL_0710_2;
																												case 136:
																													goto IL_071e_2;
																												case 179:
																													goto IL_0731_2;
																												case 5:
																													goto IL_0754_2;
																												case 27:
																													goto IL_0767_2;
																												case 158:
																													goto IL_0775_2;
																												case 33:
																												case 185:
																													goto IL_0788_2;
																												case 187:
																													goto IL_079b_2;
																												case 12:
																												case 82:
																													goto IL_07a9_2;
																												case 163:
																													goto IL_07b7_2;
																												case 99:
																													goto IL_07c5_2;
																												case 13:
																												case 52:
																													goto IL_07d3_2;
																												case 107:
																													goto IL_0813_2;
																												case 124:
																													goto IL_0827_2;
																												case 59:
																												case 180:
																													goto IL_083a_2;
																												case 188:
																													goto IL_084d_2;
																												case 58:
																												case 72:
																													goto IL_085b_2;
																												case 134:
																													goto IL_089b_2;
																												case 97:
																													goto IL_08af_2;
																												case 193:
																													goto IL_08c2_2;
																												case 196:
																													goto IL_08d5_2;
																												case 155:
																													goto IL_08e9_2;
																												case 24:
																												case 197:
																													goto IL_08fc_2;
																												case 14:
																													goto IL_090a_2;
																												case 6:
																												case 10:
																													goto IL_0915_2;
																												case 94:
																													goto IL_0933_2;
																												case 106:
																													goto IL_0941_2;
																												case 190:
																													goto IL_0954_2;
																												case 2:
																												case 115:
																													goto IL_0962_2;
																												case 22:
																													goto IL_0970_2;
																												case 3:
																												case 41:
																													goto end_IL_0d96_2;
																												case 96:
																													goto IL_0a35_2;
																												case 144:
																													goto IL_0a43_2;
																												case 75:
																													goto IL_0a64_2;
																												case 127:
																													goto IL_0a77_2;
																												case 169:
																												case 186:
																													goto IL_0a85_2;
																												case 129:
																													goto IL_0a93_2;
																												case 1:
																												case 121:
																													goto IL_0aa1_2;
																												case 175:
																													goto IL_0ab9_2;
																												case 177:
																													goto IL_0ad7_2;
																												case 135:
																													goto IL_0b04_2;
																												case 194:
																													goto IL_0b1c_2;
																												case 83:
																													goto IL_0b2f_2;
																												case 78:
																												case 128:
																													goto IL_0b3d_2;
																												case 170:
																													goto IL_0b66_2;
																												case 79:
																												case 199:
																													goto IL_0b7f_2;
																												case 173:
																													goto IL_0b8d_2;
																												case 119:
																													goto IL_0bb1_2;
																												case 65:
																													goto IL_0bbf_2;
																												case 210:
																													goto IL_0bd2_2;
																												case 89:
																													goto IL_0bea_2;
																												case 152:
																													goto IL_0bf8_2;
																												case 103:
																													goto IL_0c0b_2;
																												case 68:
																													goto IL_0c16_2;
																												case 35:
																												case 125:
																													goto IL_0c24_2;
																												case 92:
																													goto IL_0c62_2;
																												case 19:
																													goto IL_0c75_2;
																												case 112:
																													goto IL_0c83_2;
																												case 15:
																												case 55:
																													goto IL_0c91_2;
																												case 61:
																													goto IL_0ca5_2;
																												case 111:
																													goto IL_0cdd_2;
																												case 154:
																													goto IL_0cf0_2;
																												case 74:
																												case 105:
																													goto IL_0cfb_2;
																												case 7:
																													goto IL_0d06_2;
																												case 51:
																												case 149:
																													goto IL_0d11_2;
																												case 148:
																													goto IL_0d33_2;
																												case 66:
																												case 204:
																													goto IL_0d3e_2;
																												case 16:
																												case 43:
																												case 47:
																												case 50:
																												case 53:
																												case 54:
																												case 56:
																												case 57:
																												case 62:
																												case 76:
																												case 80:
																												case 84:
																												case 90:
																												case 93:
																												case 100:
																												case 101:
																												case 110:
																												case 117:
																												case 118:
																												case 122:
																												case 130:
																												case 131:
																												case 132:
																												case 142:
																												case 151:
																												case 153:
																												case 162:
																												case 164:
																												case 176:
																												case 178:
																												case 183:
																												case 191:
																												case 192:
																												case 195:
																												case 203:
																												case 207:
																												case 209:
																													goto end_IL_041f_2;
																												case 87:
																													goto IL_0d6c_2;
																												case 184:
																													goto IL_0d7a_2;
																												case 198:
																													goto IL_0d88_2;
																												case 11:
																												case 18:
																												case 20:
																												case 23:
																												case 32:
																												case 38:
																												case 40:
																												case 44:
																												case 46:
																												case 64:
																												case 71:
																												case 73:
																												case 81:
																												case 86:
																												case 91:
																												case 95:
																												case 113:
																												case 137:
																												case 139:
																												case 143:
																												case 150:
																												case 189:
																												case 206:
																												case 212:
																													goto end_IL_037b_2;
																												case 102:
																													ptr2 = ptr;
																													goto end_IL_037b_2;
																												case 201:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCreationOptionsTrademark.DateTimeParseReport);
																													goto case 102;
																												case 181:
																													array7 = new object[9];
																													goto case 201;
																												case 171:
																													array6 = new long[4];
																													goto case 181;
																												case 182:
																													array5 = new int[6];
																													goto case 171;
																												case 109:
																													array4 = new int[4];
																													goto case 182;
																												case 174:
																													array3 = new object[4];
																													goto case 109;
																												case 4:
																													array2 = new byte[4];
																													goto case 174;
																												case 42:
																													num4 = num2 * 8;
																													goto case 4;
																												case 200:
																													num3 = num2 * 4;
																													goto case 42;
																												case 160:
																													num2 = 1;
																													goto case 200;
																												case 161:
																													goto end_IL_099b;
																												case 67:
																												case 172:
																													goto IL_0e62_2;
																												}
																												continue;
																												end_IL_037b_2:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0c0b_2;
																						IL_0cdd_2:
																						ptr2 += 8;
																						break;
																						IL_0c0b_2:
																						if (18 >= b)
																						{
																							goto IL_0c16_2;
																						}
																						goto IL_0c75_2;
																						IL_0c16_2:
																						if (18 > b)
																						{
																							goto end_IL_041f_2;
																						}
																						goto IL_0c24_2;
																						IL_0c24_2:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_0c62_2;
																						IL_0c62_2:
																						num6 -= 3;
																						break;
																						IL_0c75_2:
																						if (19 < b)
																						{
																							goto end_IL_041f_2;
																						}
																						goto IL_0c83_2;
																						IL_0c83_2:
																						if (19 > b)
																						{
																							goto end_IL_041f_2;
																						}
																						goto IL_0c91_2;
																						IL_0c91_2:
																						array2[num6 - 1] = 5;
																						goto IL_0ca5_2;
																						IL_0ca5_2:
																						array3[num6 - 1] = ((delegate*<string[], string>)HexIntgetHasCurrent[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_0cdd_2;
																					}
																					break;
																				}
																				goto IL_0cf0_2;
																				IL_0d3e_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0cf0_2:
																				if (21 < b)
																				{
																					goto IL_0cfb_2;
																				}
																				goto IL_0d33_2;
																				IL_0cfb_2:
																				if (22 < b)
																				{
																					goto end_IL_041f_2;
																				}
																				goto IL_0d06_2;
																				IL_0d06_2:
																				if (22 > b)
																				{
																					goto end_IL_041f_2;
																				}
																				goto IL_0d11_2;
																				IL_0d11_2:
																				num7 = ptr2;
																				num8 = -200;
																				num5 = 1;
																				ptr2 = num7 + num8;
																				num = 46;
																				break;
																				IL_0d33_2:
																				if (21 > b)
																				{
																					goto end_IL_041f_2;
																				}
																				goto IL_0d3e_2;
																			}
																			break;
																		}
																		goto IL_049c_2;
																		IL_0bea_2:
																		num6++;
																		goto IL_0bf8_2;
																		IL_049c_2:
																		if (17 <= b)
																		{
																			goto IL_0788_2;
																		}
																		goto IL_08fc_2;
																		IL_08fc_2:
																		if (14 >= b)
																		{
																			goto IL_090a_2;
																		}
																		goto IL_0a77_2;
																		IL_090a_2:
																		if (14 <= b)
																		{
																			goto IL_0915_2;
																		}
																		goto IL_0954_2;
																		IL_0915_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_0933_2;
																		IL_0933_2:
																		ptr2 += 8;
																		goto IL_0941_2;
																		IL_0941_2:
																		num6--;
																		break;
																		IL_0954_2:
																		if (12 < b)
																		{
																			goto IL_0962_2;
																		}
																		goto IL_0a64_2;
																		IL_0962_2:
																		if (13 < b)
																		{
																			num = 43;
																			goto end_IL_041f_2;
																		}
																		goto IL_0970_2;
																		IL_0970_2:
																		if (13 > b)
																		{
																			goto end_IL_041f_2;
																		}
																		goto end_IL_0d96_2;
																		IL_0bf8_2:
																		ptr2 += 8;
																		break;
																		IL_0a64_2:
																		if (12 <= b)
																		{
																			break;
																		}
																		goto end_IL_041f_2;
																		IL_0a77_2:
																		if (15 < b)
																		{
																			goto IL_0a85_2;
																		}
																		goto IL_0b2f_2;
																		IL_0a85_2:
																		if (16 < b)
																		{
																			goto end_IL_041f_2;
																		}
																		goto IL_0a93_2;
																		IL_0a93_2:
																		if (16 > b)
																		{
																			goto end_IL_041f_2;
																		}
																		goto IL_0aa1_2;
																		IL_0aa1_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_0ab9_2;
																		IL_0ab9_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_0ad7_2;
																		IL_0ad7_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 135;
																		goto IL_0b04_2;
																		IL_0b04_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_0b1c_2;
																		IL_0b1c_2:
																		num6++;
																		break;
																		IL_0b2f_2:
																		if (15 > b)
																		{
																			goto end_IL_041f_2;
																		}
																		goto IL_0b3d_2;
																		IL_0b3d_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_0b66_2;
																		IL_0b66_2:
																		array2[num6 - 1] = 5;
																		break;
																		IL_0788_2:
																		array2[num6] = 5;
																		goto IL_0bd2_2;
																		IL_0bd2_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_0bea_2;
																	}
																	break;
																}
																goto IL_045a_2;
																IL_0689_2:
																array2[num6 - 2] = 0;
																goto IL_08c2_2;
																IL_045a_2:
																if (11 > b)
																{
																	goto IL_0473_2;
																}
																num = 79;
																goto IL_0b7f_2;
																IL_08c2_2:
																num6--;
																break;
																IL_0b7f_2:
																array2[num6] = 0;
																goto IL_0b8d_2;
																IL_0b8d_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)HexIntgetHasCurrent[*(int*)(ptr2 + num3)])();
																goto IL_0bb1_2;
																IL_0bb1_2:
																num6++;
																goto IL_0bbf_2;
																IL_0bbf_2:
																ptr2 += 8;
																break;
																IL_0473_2:
																if (5 < b)
																{
																	goto IL_0481_2;
																}
																goto IL_0555_2;
																IL_0481_2:
																if (8 < b)
																{
																	goto IL_048f_2;
																}
																goto IL_079b_2;
																IL_048f_2:
																if (9 < b)
																{
																	goto IL_04af_2;
																}
																goto IL_04bf_2;
																IL_04af_2:
																if (10 < b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_04d2_2;
																IL_04d2_2:
																if (10 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_04e0_2;
																IL_04e0_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0542_2;
																IL_0542_2:
																num6 -= 2;
																break;
																IL_04bf_2:
																if (9 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_059d_2;
																IL_059d_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_08d5_2;
																IL_08d5_2:
																array2[num6 - 2] = 0;
																goto IL_08e9_2;
																IL_08e9_2:
																num6--;
																break;
																IL_079b_2:
																if (8 > b)
																{
																	goto IL_07a9_2;
																}
																goto IL_083a_2;
																IL_07a9_2:
																if (6 < b)
																{
																	goto IL_07b7_2;
																}
																goto IL_084d_2;
																IL_07b7_2:
																if (7 < b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_07c5_2;
																IL_07c5_2:
																if (7 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_07d3_2;
																IL_07d3_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0813_2;
																IL_0813_2:
																array2[num6 - 2] = 0;
																goto IL_0827_2;
																IL_0827_2:
																num6--;
																break;
																IL_084d_2:
																if (6 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_085b_2;
																IL_085b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_089b_2;
																IL_089b_2:
																array2[num6 - 2] = 0;
																goto IL_08af_2;
																IL_08af_2:
																num6--;
																break;
																IL_083a_2:
																num6--;
																break;
																IL_0555_2:
																if (5 > b)
																{
																	goto IL_0563_2;
																}
																goto IL_0649_2;
																IL_0563_2:
																if (2 >= b)
																{
																	goto IL_0571_2;
																}
																goto IL_06a2_2;
																IL_0571_2:
																if (2 > b)
																{
																	goto IL_057c_2;
																}
																goto IL_05e2_2;
																IL_057c_2:
																if (1 < b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_058a_2;
																IL_058a_2:
																if (1 > b)
																{
																}
																goto end_IL_041f_2;
																IL_05e2_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0622_2;
																IL_0622_2:
																array2[num6 - 2] = 0;
																goto IL_0636_2;
																IL_0636_2:
																num6--;
																break;
																IL_06a2_2:
																if (3 < b)
																{
																	goto IL_06ad_2;
																}
																goto IL_06d9_2;
																IL_06ad_2:
																if (4 < b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_06bb_2;
																IL_06bb_2:
																if (4 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_06c9_2;
																IL_06c9_2:
																array2[num6] = 0;
																goto IL_0731_2;
																IL_0731_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0754_2;
																IL_0754_2:
																array3[num6] = null;
																num = 27;
																goto IL_0767_2;
																IL_0767_2:
																num6++;
																goto IL_0775_2;
																IL_0775_2:
																ptr2 += 8;
																break;
																IL_06d9_2:
																if (3 > b)
																{
																	goto end_IL_041f_2;
																}
																goto IL_06e7_2;
																IL_06e7_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0710_2;
																IL_0710_2:
																ptr2 += 8;
																goto IL_071e_2;
																IL_071e_2:
																num6--;
																break;
																IL_0649_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0689_2;
															}
															goto end_IL_042f_2;
															continue;
															end_IL_041f_2:
															break;
															IL_041f_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d6c_2;
													IL_0d88_2:
													ptr2 += 8;
													break;
													IL_0d7a_2:
													num6++;
													goto IL_0d88_2;
													IL_0d6c_2:
													array2[num6] = 0;
													goto IL_0d7a_2;
													continue;
													end_IL_042f_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0e62_2;
									IL_0e62_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0d96_2:
									break;
								}
								break;
							}
							break;
						}
						array8 = array3;
						num9 = num6;
						if (array == null)
						{
							goto IL_098d_2;
						}
						continue;
						end_IL_099b:
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0361, IL_0374, IL_0387, IL_0397, IL_03a7, IL_03b7, IL_03c7, IL_03d4, IL_03e4, IL_03f4, IL_0404, IL_040f, IL_0438, IL_0451, IL_045c, IL_046a, IL_0478, IL_0486, IL_0494, IL_04a2, IL_04b0, IL_0512, IL_0525, IL_0538, IL_0543, IL_0556, IL_0564, IL_0577, IL_0582, IL_05c2, IL_05d6, IL_05e9, IL_05f4, IL_0602, IL_0615, IL_0623, IL_0631, IL_0671, IL_0685, IL_0698, IL_06d8, IL_06ec, IL_06ff, IL_0712, IL_0720, IL_0760, IL_0774, IL_0787, IL_0792, IL_07a0, IL_07ae, IL_07be, IL_07cc, IL_07f5, IL_0803, IL_0816, IL_0839, IL_084c, IL_085a, IL_086d, IL_08ad, IL_08c1, IL_08d4, IL_08e2, IL_08f0, IL_0908, IL_0926, IL_094a, IL_0962, IL_0975, IL_0983, IL_0991, IL_099f, IL_09bc, IL_0a0b, IL_0a15, IL_0a42, IL_0a56, IL_0a64, IL_0a77, IL_0a9e, IL_0aac, IL_0abf, IL_0acd, IL_0ae5, IL_0af3, IL_0b06, IL_0b11, IL_0b1c, IL_0b2a, IL_0b42, IL_0b50, IL_0b5e, IL_0b7a, IL_0b85, IL_0b9e, IL_0bac, IL_0bba, IL_0bcd, IL_0bd8, IL_0be6, IL_0bf4, IL_0c08, IL_0c40, IL_0c53, IL_0c5e, IL_0c9c, IL_0cac, IL_0cc5, IL_0cd3, IL_0ce1, IL_0cef, IL_0d02, IL_0d0c, IL_0d17, IL_0d27, IL_0d37, IL_0d47, IL_0d60, IL_0d70, IL_0d80, IL_0d90, IL_0da0, IL_0dbb are reachable both inside and outside the pinned region starting at IL_0db5. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 35;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				int __rxRef21 = default(int);
				ref int reference = ref __rxRef21;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0da0:
						num2 = 1;
						while (true)
						{
							IL_0d90:
							num3 = num2 * 4;
							while (true)
							{
								IL_0d80:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d70:
									array2 = new byte[4];
									while (true)
									{
										IL_0d60:
										array3 = new object[4];
										while (true)
										{
											IL_0d47:
											array4 = new int[4];
											num = 133;
											while (true)
											{
												IL_0d37:
												array5 = new int[6];
												while (true)
												{
													IL_0d27:
													array6 = new long[4];
													while (true)
													{
														IL_0d17:
														array7 = new object[16];
														while (true)
														{
															IL_0d0c:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SilverlightTraceSynchronousWorkBegin.LoggersOffset);
															while (true)
															{
																IL_0d02:
																ptr2 = ptr;
																while (true)
																{
																	IL_0cef:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0404:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_03f4:
																				ptr2++;
																				while (true)
																				{
																					IL_03e4:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_03c7:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_03b7:
																										if (16 >= b)
																										{
																											while (true)
																											{
																												IL_03a7:
																												if (16 > b)
																												{
																													while (true)
																													{
																														IL_0397:
																														if (13 < b)
																														{
																															while (true)
																															{
																																IL_0387:
																																if (14 >= b)
																																{
																																	while (true)
																																	{
																																		IL_0374:
																																		if (14 > b)
																																		{
																																			num = 209;
																																			while (num != 209)
																																			{
																																				if (num != 1190)
																																				{
																																					goto IL_0631;
																																				}
																																				switch (num)
																																				{
																																				case 35:
																																					break;
																																				default:
																																					continue;
																																				case 10:
																																					goto IL_0374;
																																				case 2:
																																				case 105:
																																					goto IL_0387;
																																				case 54:
																																				case 170:
																																					goto IL_0397;
																																				case 153:
																																					goto IL_03a7;
																																				case 152:
																																					goto IL_03b7;
																																				case 172:
																																					goto IL_03c7;
																																				case 78:
																																					goto IL_03d4;
																																				case 32:
																																					goto IL_03e4;
																																				case 56:
																																					goto IL_03f4;
																																				case 44:
																																				case 116:
																																					goto IL_0404;
																																				case 21:
																																				case 46:
																																					goto IL_040f;
																																				case 70:
																																					goto IL_0438;
																																				case 128:
																																					goto IL_0451;
																																				case 171:
																																					goto IL_046a;
																																				case 33:
																																					goto IL_0478;
																																				case 51:
																																					goto IL_0486;
																																				case 109:
																																					goto IL_0494;
																																				case 8:
																																					goto IL_04a2;
																																				case 65:
																																				case 110:
																																					goto IL_04b0;
																																				case 117:
																																					goto IL_0512;
																																				case 37:
																																					goto IL_0525;
																																				case 62:
																																					goto IL_0538;
																																				case 48:
																																				case 125:
																																					goto IL_0543;
																																				case 100:
																																					goto IL_0556;
																																				case 11:
																																				case 167:
																																					goto IL_0564;
																																				case 36:
																																					goto IL_0577;
																																				case 41:
																																				case 58:
																																					goto IL_0582;
																																				case 63:
																																					goto IL_05c2;
																																				case 23:
																																					goto IL_05d6;
																																				case 144:
																																					goto IL_05e9;
																																				case 156:
																																					goto IL_05f4;
																																				case 154:
																																					goto IL_0602;
																																				case 183:
																																					goto IL_0623;
																																				case 40:
																																				case 129:
																																					goto IL_0631;
																																				case 131:
																																					goto IL_0671;
																																				case 15:
																																					goto IL_0685;
																																				case 121:
																																				case 184:
																																					goto IL_0698;
																																				case 124:
																																					goto IL_06d8;
																																				case 26:
																																					goto IL_06ec;
																																				case 185:
																																					goto IL_06ff;
																																				case 186:
																																					goto IL_0712;
																																				case 59:
																																				case 91:
																																					goto IL_0720;
																																				case 82:
																																					goto IL_0760;
																																				case 134:
																																					goto IL_0774;
																																				case 168:
																																				case 189:
																																					goto IL_0787;
																																				case 20:
																																				case 142:
																																					goto IL_0792;
																																				case 90:
																																					goto IL_07a0;
																																				case 60:
																																				case 127:
																																					goto IL_07ae;
																																				case 94:
																																					goto IL_07be;
																																				case 80:
																																				case 92:
																																					goto IL_07cc;
																																				case 88:
																																					goto IL_07f5;
																																				case 13:
																																					goto IL_0803;
																																				case 195:
																																					goto IL_0816;
																																				case 123:
																																					goto IL_0839;
																																				case 182:
																																					goto IL_084c;
																																				case 122:
																																					goto IL_085a;
																																				case 161:
																																				case 200:
																																					goto IL_086d;
																																				case 175:
																																					goto IL_08ad;
																																				case 136:
																																					goto IL_08c1;
																																				case 29:
																																					goto IL_08d4;
																																				case 111:
																																					goto IL_08e2;
																																				case 42:
																																				case 145:
																																					goto IL_08f0;
																																				case 178:
																																					goto IL_0908;
																																				case 143:
																																					goto IL_0926;
																																				case 27:
																																					goto IL_094a;
																																				case 103:
																																					goto IL_0962;
																																				case 53:
																																					goto IL_0975;
																																				case 18:
																																					goto IL_0983;
																																				case 104:
																																					goto IL_0991;
																																				case 132:
																																				case 159:
																																					goto IL_099f;
																																				case 119:
																																					goto IL_0a56;
																																				case 112:
																																					goto IL_0a64;
																																				case 38:
																																				case 179:
																																					goto IL_0a77;
																																				case 73:
																																					goto IL_0a9e;
																																				case 199:
																																					goto IL_0aac;
																																				case 7:
																																				case 76:
																																					goto IL_0abf;
																																				case 120:
																																					goto IL_0acd;
																																				case 77:
																																					goto IL_0ae5;
																																				case 83:
																																					goto IL_0af3;
																																				case 30:
																																					goto IL_0b06;
																																				case 93:
																																				case 98:
																																					goto IL_0b11;
																																				case 49:
																																					goto IL_0b1c;
																																				case 67:
																																				case 85:
																																					goto IL_0b2a;
																																				case 157:
																																					goto IL_0b42;
																																				case 107:
																																					goto IL_0b50;
																																				case 108:
																																				case 146:
																																					goto IL_0b5e;
																																				case 180:
																																					goto IL_0b7a;
																																				case 12:
																																				case 130:
																																					goto IL_0b85;
																																				case 135:
																																					goto IL_0b9e;
																																				case 118:
																																					goto IL_0bac;
																																				case 61:
																																					goto IL_0bba;
																																				case 4:
																																					goto IL_0bcd;
																																				case 50:
																																				case 66:
																																					goto IL_0bd8;
																																				case 97:
																																					goto IL_0be6;
																																				case 150:
																																				case 187:
																																					goto IL_0bf4;
																																				case 9:
																																					goto IL_0c08;
																																				case 99:
																																					goto IL_0c40;
																																				case 22:
																																					goto IL_0c53;
																																				case 17:
																																				case 102:
																																					goto IL_0c5e;
																																				case 201:
																																					goto IL_0c9c;
																																				case 5:
																																				case 6:
																																				case 14:
																																				case 24:
																																				case 25:
																																				case 43:
																																				case 45:
																																				case 47:
																																				case 55:
																																				case 71:
																																				case 79:
																																				case 84:
																																				case 86:
																																				case 89:
																																				case 96:
																																				case 101:
																																				case 106:
																																				case 114:
																																				case 126:
																																				case 137:
																																				case 141:
																																				case 147:
																																				case 149:
																																				case 151:
																																				case 160:
																																				case 162:
																																				case 164:
																																				case 165:
																																				case 169:
																																				case 173:
																																				case 181:
																																				case 190:
																																				case 191:
																																				case 194:
																																				case 198:
																																					goto end_IL_0361;
																																				case 74:
																																					goto IL_0cc5;
																																				case 87:
																																					goto IL_0cd3;
																																				case 177:
																																					goto IL_0ce1;
																																				case 3:
																																				case 16:
																																				case 19:
																																				case 28:
																																				case 39:
																																				case 52:
																																				case 57:
																																				case 64:
																																				case 69:
																																				case 72:
																																				case 75:
																																				case 81:
																																				case 95:
																																				case 113:
																																				case 115:
																																				case 140:
																																				case 166:
																																				case 174:
																																				case 176:
																																				case 188:
																																				case 193:
																																				case 196:
																																				case 197:
																																				case 202:
																																					goto IL_0cef;
																																				case 138:
																																					goto IL_0d02;
																																				case 68:
																																					goto IL_0d0c;
																																				case 0:
																																					goto IL_0d17;
																																				case 148:
																																					goto IL_0d27;
																																				case 133:
																																					goto IL_0d37;
																																				case 158:
																																					goto IL_0d47;
																																				case 31:
																																					goto IL_0d60;
																																				case 155:
																																					goto IL_0d70;
																																				case 1:
																																					goto IL_0d80;
																																				case 192:
																																					goto IL_0d90;
																																				case 34:
																																					goto IL_0da0;
																																				case 139:
																																				case 163:
																																					goto IL_0dbb;
																																				}
																																				goto end_IL_03e4;
																																				continue;
																																				end_IL_0361:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_040f;
																																		IL_040f:
																																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																		goto IL_0438;
																																		IL_0438:
																																		array2[num6 - 1] = 5;
																																		goto IL_0cef;
																																	}
																																	break;
																																}
																																goto IL_08d4;
																																IL_0962:
																																num6++;
																																goto IL_0cef;
																																IL_08d4:
																																if (15 < b)
																																{
																																	break;
																																}
																																goto IL_08e2;
																																IL_08e2:
																																if (15 > b)
																																{
																																	break;
																																}
																																goto IL_08f0;
																																IL_08f0:
																																array2[num6] = array2[num6 - 1];
																																goto IL_0908;
																																IL_0908:
																																array4[num6 - 0] = array4[num6 - 1];
																																goto IL_0926;
																																IL_0926:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_094a;
																																IL_094a:
																																array3[num6] = array3[num6 - 1];
																																goto IL_0962;
																															}
																															break;
																														}
																														goto IL_0975;
																														IL_0a64:
																														num6++;
																														goto IL_0cef;
																														IL_0975:
																														if (13 > b)
																														{
																															goto IL_0983;
																														}
																														goto IL_0a77;
																														IL_0983:
																														if (12 < b)
																														{
																															break;
																														}
																														goto IL_0991;
																														IL_0991:
																														if (12 > b)
																														{
																															break;
																														}
																														goto IL_099f;
																														IL_099f:
																														array8 = array3;
																														num7 = num6;
																														if (array == null)
																														{
																															goto IL_09ae;
																														}
																														num8 = ptr2;
																														byte b2 = *num8;
																														ptr2 = num8 + 4;
																														int num9 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num9;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_0a56;
																														IL_0a77:
																														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																														num = 73;
																														goto IL_0a9e;
																														IL_0a9e:
																														ptr2 += 8;
																														goto IL_0aac;
																														IL_0aac:
																														num6--;
																														goto IL_0cef;
																														IL_0a56:
																														array2[num6] = 5;
																														goto IL_0a64;
																													}
																													break;
																												}
																												goto IL_0abf;
																												IL_0af3:
																												ptr2 += 8;
																												goto IL_0cef;
																												IL_0abf:
																												array2[num6] = 5;
																												goto IL_0acd;
																												IL_0acd:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0ae5;
																												IL_0ae5:
																												num6++;
																												goto IL_0af3;
																											}
																											break;
																										}
																										goto IL_0b06;
																										IL_0c9c:
																										num6 -= 3;
																										goto IL_0cef;
																										IL_0b06:
																										if (19 < b)
																										{
																											goto IL_0b11;
																										}
																										goto IL_0b7a;
																										IL_0b11:
																										if (20 >= b)
																										{
																											goto IL_0b1c;
																										}
																										goto IL_0b42;
																										IL_0b1c:
																										if (20 > b)
																										{
																											break;
																										}
																										goto IL_0b2a;
																										IL_0b2a:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto IL_0cef;
																										IL_0b42:
																										if (21 < b)
																										{
																											break;
																										}
																										goto IL_0b50;
																										IL_0b50:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_0b5e;
																										IL_0b5e:
																										num10 = ptr2;
																										num11 = -200;
																										num5 = 1;
																										ptr2 = num10 + num11;
																										goto IL_0cef;
																										IL_0b7a:
																										if (19 <= b)
																										{
																											goto IL_0b85;
																										}
																										goto IL_0bcd;
																										IL_0b85:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0b9e;
																										IL_0b9e:
																										array2[num6] = 1;
																										goto IL_0bac;
																										IL_0bac:
																										num6++;
																										goto IL_0bba;
																										IL_0bba:
																										ptr2 += 16;
																										goto IL_0cef;
																										IL_0bcd:
																										if (17 < b)
																										{
																											goto IL_0bd8;
																										}
																										goto IL_0c53;
																										IL_0bd8:
																										if (18 < b)
																										{
																											break;
																										}
																										goto IL_0be6;
																										IL_0be6:
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_0bf4;
																										IL_0bf4:
																										array2[num6 - 1] = 5;
																										goto IL_0c08;
																										IL_0c08:
																										array3[num6 - 1] = ((delegate*<string[], string>)RsagetFailure[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																										goto IL_0c40;
																										IL_0c40:
																										ptr2 += 8;
																										goto IL_0cef;
																										IL_0c53:
																										if (17 > b)
																										{
																											break;
																										}
																										goto IL_0c5e;
																										IL_0c5e:
																										((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																										goto IL_0c9c;
																									}
																									break;
																								}
																								goto IL_0451;
																								IL_07cc:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_07f5;
																								IL_0451:
																								if (11 <= b)
																								{
																									num = 81;
																									goto IL_0cef;
																								}
																								goto IL_046a;
																								IL_07f5:
																								ptr2 += 8;
																								goto IL_0803;
																								IL_046a:
																								if (5 < b)
																								{
																									goto IL_0478;
																								}
																								goto IL_0577;
																								IL_0478:
																								if (8 < b)
																								{
																									goto IL_0486;
																								}
																								goto IL_0538;
																								IL_0486:
																								if (9 < b)
																								{
																									goto IL_0494;
																								}
																								goto IL_0525;
																								IL_0494:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_04a2;
																								IL_04a2:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_04b0;
																								IL_04b0:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0512;
																								IL_0512:
																								num6 -= 2;
																								goto IL_0cef;
																								IL_0525:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_086d;
																								IL_086d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_08ad;
																								IL_08ad:
																								array2[num6 - 2] = 0;
																								goto IL_08c1;
																								IL_08c1:
																								num6--;
																								goto IL_0cef;
																								IL_0538:
																								if (8 <= b)
																								{
																									goto IL_0543;
																								}
																								goto IL_0556;
																								IL_0543:
																								num6--;
																								goto IL_0cef;
																								IL_0556:
																								if (6 < b)
																								{
																									goto IL_0564;
																								}
																								goto IL_0623;
																								IL_0564:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0712;
																								IL_0712:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0720;
																								IL_0720:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0760;
																								IL_0760:
																								array2[num6 - 2] = 0;
																								goto IL_0774;
																								IL_0774:
																								num6--;
																								goto IL_0cef;
																								IL_0623:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0631;
																								IL_0631:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0671;
																								IL_0671:
																								array2[num6 - 2] = 0;
																								goto IL_0685;
																								IL_0685:
																								num6--;
																								goto IL_0cef;
																								IL_0577:
																								if (5 <= b)
																								{
																									goto IL_0582;
																								}
																								goto IL_05e9;
																								IL_0582:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_05c2;
																								IL_05c2:
																								array2[num6 - 2] = 0;
																								goto IL_05d6;
																								IL_05d6:
																								num6--;
																								goto IL_0cef;
																								IL_05e9:
																								if (2 >= b)
																								{
																									goto IL_05f4;
																								}
																								num = 189;
																								goto IL_0787;
																								IL_05f4:
																								if (2 > b)
																								{
																									goto IL_0602;
																								}
																								goto IL_0698;
																								IL_0602:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_06ff;
																								IL_06ff:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0698:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_06d8;
																								IL_06d8:
																								array2[num6 - 2] = 0;
																								goto IL_06ec;
																								IL_06ec:
																								num6--;
																								goto IL_0cef;
																								IL_0803:
																								num6--;
																								goto IL_0cef;
																								IL_0787:
																								if (3 < b)
																								{
																									goto IL_0792;
																								}
																								goto IL_07be;
																								IL_0792:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_07a0;
																								IL_07a0:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_07ae;
																								IL_07ae:
																								array2[num6] = 0;
																								goto IL_0816;
																								IL_0816:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0839;
																								IL_0839:
																								array3[num6] = null;
																								num = 182;
																								goto IL_084c;
																								IL_084c:
																								num6++;
																								goto IL_085a;
																								IL_085a:
																								ptr2 += 8;
																								goto IL_0cef;
																								IL_07be:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_07cc;
																							}
																							break;
																							IL_03d4:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0cc5;
																					IL_0ce1:
																					ptr2 += 8;
																					goto IL_0cef;
																					IL_0cd3:
																					num6++;
																					goto IL_0ce1;
																					IL_0cc5:
																					array2[num6] = 0;
																					goto IL_0cd3;
																					continue;
																					end_IL_03e4:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0dbb;
																	IL_0dbb:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_09ae:
				while (true)
				{
					IL_09ae_2:
					array = new byte[4];
					while (true)
					{
						IL_09bc:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0a64_2:
								num6++;
								while (true)
								{
									IL_0cef_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_03e4_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03c7_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_03b7_2:
																		if (16 >= b)
																		{
																			while (true)
																			{
																				IL_03a7_2:
																				if (16 > b)
																				{
																					while (true)
																					{
																						IL_0397_2:
																						if (13 < b)
																						{
																							while (true)
																							{
																								IL_0387_2:
																								if (14 >= b)
																								{
																									while (true)
																									{
																										IL_0374_2:
																										if (14 > b)
																										{
																											num = 209;
																											while (num != 209)
																											{
																												if (num != 1190)
																												{
																													goto IL_0631_2;
																												}
																												switch (num)
																												{
																												case 10:
																													goto IL_0374_2;
																												case 2:
																												case 105:
																													goto IL_0387_2;
																												case 54:
																												case 170:
																													goto IL_0397_2;
																												case 153:
																													goto IL_03a7_2;
																												case 152:
																													goto IL_03b7_2;
																												case 172:
																													goto IL_03c7_2;
																												case 78:
																													goto IL_03d4_2;
																												case 32:
																													goto IL_03e4_2;
																												case 56:
																													goto end_IL_03e4_2;
																												case 44:
																												case 116:
																													goto end_IL_03f4;
																												case 21:
																												case 46:
																													goto IL_040f_2;
																												case 70:
																													goto IL_0438_2;
																												case 128:
																													goto IL_0451_2;
																												case 171:
																													goto IL_046a_2;
																												case 33:
																													goto IL_0478_2;
																												case 51:
																													goto IL_0486_2;
																												case 109:
																													goto IL_0494_2;
																												case 8:
																													goto IL_04a2_2;
																												case 65:
																												case 110:
																													goto IL_04b0_2;
																												case 117:
																													goto IL_0512_2;
																												case 37:
																													goto IL_0525_2;
																												case 62:
																													goto IL_0538_2;
																												case 48:
																												case 125:
																													goto IL_0543_2;
																												case 100:
																													goto IL_0556_2;
																												case 11:
																												case 167:
																													goto IL_0564_2;
																												case 36:
																													goto IL_0577_2;
																												case 41:
																												case 58:
																													goto IL_0582_2;
																												case 63:
																													goto IL_05c2_2;
																												case 23:
																													goto IL_05d6_2;
																												case 144:
																													goto IL_05e9_2;
																												case 156:
																													goto IL_05f4_2;
																												case 154:
																													goto IL_0602_2;
																												case 183:
																													goto IL_0623_2;
																												case 40:
																												case 129:
																													goto IL_0631_2;
																												case 131:
																													goto IL_0671_2;
																												case 15:
																													goto IL_0685_2;
																												case 121:
																												case 184:
																													goto IL_0698_2;
																												case 124:
																													goto IL_06d8_2;
																												case 26:
																													goto IL_06ec_2;
																												case 185:
																													goto IL_06ff_2;
																												case 186:
																													goto IL_0712_2;
																												case 59:
																												case 91:
																													goto IL_0720_2;
																												case 82:
																													goto IL_0760_2;
																												case 134:
																													goto IL_0774_2;
																												case 168:
																												case 189:
																													goto IL_0787_2;
																												case 20:
																												case 142:
																													goto IL_0792_2;
																												case 90:
																													goto IL_07a0_2;
																												case 60:
																												case 127:
																													goto IL_07ae_2;
																												case 94:
																													goto IL_07be_2;
																												case 80:
																												case 92:
																													goto IL_07cc_2;
																												case 88:
																													goto IL_07f5_2;
																												case 13:
																													goto IL_0803_2;
																												case 195:
																													goto IL_0816_2;
																												case 123:
																													goto IL_0839_2;
																												case 182:
																													goto IL_084c_2;
																												case 122:
																													goto IL_085a_2;
																												case 161:
																												case 200:
																													goto IL_086d_2;
																												case 175:
																													goto IL_08ad_2;
																												case 136:
																													goto IL_08c1_2;
																												case 29:
																													goto IL_08d4_2;
																												case 111:
																													goto IL_08e2_2;
																												case 42:
																												case 145:
																													goto IL_08f0_2;
																												case 178:
																													goto IL_0908_2;
																												case 143:
																													goto IL_0926_2;
																												case 27:
																													goto IL_094a_2;
																												case 103:
																													goto IL_0962_2;
																												case 53:
																													goto IL_0975_2;
																												case 18:
																													goto IL_0983_2;
																												case 104:
																													goto IL_0991_2;
																												case 132:
																												case 159:
																													goto IL_099f_2;
																												case 119:
																													goto end_IL_0404;
																												case 112:
																													goto IL_0a64_2;
																												case 38:
																												case 179:
																													goto IL_0a77_2;
																												case 73:
																													goto IL_0a9e_2;
																												case 199:
																													goto IL_0aac_2;
																												case 7:
																												case 76:
																													goto IL_0abf_2;
																												case 120:
																													goto IL_0acd_2;
																												case 77:
																													goto IL_0ae5_2;
																												case 83:
																													goto IL_0af3_2;
																												case 30:
																													goto IL_0b06_2;
																												case 93:
																												case 98:
																													goto IL_0b11_2;
																												case 49:
																													goto IL_0b1c_2;
																												case 67:
																												case 85:
																													goto IL_0b2a_2;
																												case 157:
																													goto IL_0b42_2;
																												case 107:
																													goto IL_0b50_2;
																												case 108:
																												case 146:
																													goto IL_0b5e_2;
																												case 180:
																													goto IL_0b7a_2;
																												case 12:
																												case 130:
																													goto IL_0b85_2;
																												case 135:
																													goto IL_0b9e_2;
																												case 118:
																													goto IL_0bac_2;
																												case 61:
																													goto IL_0bba_2;
																												case 4:
																													goto IL_0bcd_2;
																												case 50:
																												case 66:
																													goto IL_0bd8_2;
																												case 97:
																													goto IL_0be6_2;
																												case 150:
																												case 187:
																													goto IL_0bf4_2;
																												case 9:
																													goto IL_0c08_2;
																												case 99:
																													goto IL_0c40_2;
																												case 22:
																													goto IL_0c53_2;
																												case 17:
																												case 102:
																													goto IL_0c5e_2;
																												case 201:
																													goto IL_0c9c_2;
																												case 5:
																												case 6:
																												case 14:
																												case 24:
																												case 25:
																												case 43:
																												case 45:
																												case 47:
																												case 55:
																												case 71:
																												case 79:
																												case 84:
																												case 86:
																												case 89:
																												case 96:
																												case 101:
																												case 106:
																												case 114:
																												case 126:
																												case 137:
																												case 141:
																												case 147:
																												case 149:
																												case 151:
																												case 160:
																												case 162:
																												case 164:
																												case 165:
																												case 169:
																												case 173:
																												case 181:
																												case 190:
																												case 191:
																												case 194:
																												case 198:
																													goto end_IL_0361_2;
																												case 74:
																													goto IL_0cc5_2;
																												case 87:
																													goto IL_0cd3_2;
																												case 177:
																													goto IL_0ce1_2;
																												case 3:
																												case 16:
																												case 19:
																												case 28:
																												case 39:
																												case 52:
																												case 57:
																												case 64:
																												case 69:
																												case 72:
																												case 75:
																												case 81:
																												case 95:
																												case 113:
																												case 115:
																												case 140:
																												case 166:
																												case 174:
																												case 176:
																												case 188:
																												case 193:
																												case 196:
																												case 197:
																												case 202:
																													goto IL_0cef_2;
																												case 138:
																													ptr2 = ptr;
																													goto IL_0cef_2;
																												case 68:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SilverlightTraceSynchronousWorkBegin.LoggersOffset);
																													goto case 138;
																												case 0:
																													array7 = new object[16];
																													goto case 68;
																												case 148:
																													array6 = new long[4];
																													goto case 0;
																												case 133:
																													array5 = new int[6];
																													goto case 148;
																												case 158:
																													array4 = new int[4];
																													num = 133;
																													goto case 133;
																												case 31:
																													array3 = new object[4];
																													goto case 158;
																												case 155:
																													array2 = new byte[4];
																													goto case 31;
																												case 1:
																													num4 = num2 * 8;
																													goto case 155;
																												case 192:
																													num3 = num2 * 4;
																													goto case 1;
																												case 34:
																													num2 = 1;
																													goto case 192;
																												case 35:
																													goto end_IL_0a56;
																												case 139:
																												case 163:
																													goto IL_0dbb_2;
																												}
																												continue;
																												end_IL_0361_2:
																												break;
																											}
																											break;
																										}
																										goto IL_040f_2;
																										IL_040f_2:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_0438_2;
																										IL_0438_2:
																										array2[num6 - 1] = 5;
																										goto IL_0cef_2;
																									}
																									break;
																								}
																								goto IL_08d4_2;
																								IL_0962_2:
																								num6++;
																								goto IL_0cef_2;
																								IL_08d4_2:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_08e2_2;
																								IL_08e2_2:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_08f0_2;
																								IL_08f0_2:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0908_2;
																								IL_0908_2:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0926_2;
																								IL_0926_2:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_094a_2;
																								IL_094a_2:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0962_2;
																							}
																							break;
																						}
																						goto IL_0975_2;
																						IL_0aac_2:
																						num6--;
																						goto IL_0cef_2;
																						IL_0975_2:
																						if (13 > b)
																						{
																							goto IL_0983_2;
																						}
																						goto IL_0a77_2;
																						IL_0983_2:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0991_2;
																						IL_0991_2:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_099f_2;
																						IL_099f_2:
																						array8 = array3;
																						num7 = num6;
																						if (array == null)
																						{
																							goto IL_09ae_2;
																						}
																						goto IL_09bc;
																						IL_0a77_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						num = 73;
																						goto IL_0a9e_2;
																						IL_0a9e_2:
																						ptr2 += 8;
																						goto IL_0aac_2;
																					}
																					break;
																				}
																				goto IL_0abf_2;
																				IL_0af3_2:
																				ptr2 += 8;
																				goto IL_0cef_2;
																				IL_0abf_2:
																				array2[num6] = 5;
																				goto IL_0acd_2;
																				IL_0acd_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0ae5_2;
																				IL_0ae5_2:
																				num6++;
																				goto IL_0af3_2;
																			}
																			break;
																		}
																		goto IL_0b06_2;
																		IL_0c9c_2:
																		num6 -= 3;
																		goto IL_0cef_2;
																		IL_0b06_2:
																		if (19 < b)
																		{
																			goto IL_0b11_2;
																		}
																		goto IL_0b7a_2;
																		IL_0b11_2:
																		if (20 >= b)
																		{
																			goto IL_0b1c_2;
																		}
																		goto IL_0b42_2;
																		IL_0b1c_2:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_0b2a_2;
																		IL_0b2a_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_0cef_2;
																		IL_0b42_2:
																		if (21 < b)
																		{
																			break;
																		}
																		goto IL_0b50_2;
																		IL_0b50_2:
																		if (21 > b)
																		{
																			break;
																		}
																		goto IL_0b5e_2;
																		IL_0b5e_2:
																		num10 = ptr2;
																		num11 = -200;
																		num5 = 1;
																		ptr2 = num10 + num11;
																		goto IL_0cef_2;
																		IL_0b7a_2:
																		if (19 <= b)
																		{
																			goto IL_0b85_2;
																		}
																		goto IL_0bcd_2;
																		IL_0b85_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0b9e_2;
																		IL_0b9e_2:
																		array2[num6] = 1;
																		goto IL_0bac_2;
																		IL_0bac_2:
																		num6++;
																		goto IL_0bba_2;
																		IL_0bba_2:
																		ptr2 += 16;
																		goto IL_0cef_2;
																		IL_0bcd_2:
																		if (17 < b)
																		{
																			goto IL_0bd8_2;
																		}
																		goto IL_0c53_2;
																		IL_0bd8_2:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_0be6_2;
																		IL_0be6_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0bf4_2;
																		IL_0bf4_2:
																		array2[num6 - 1] = 5;
																		goto IL_0c08_2;
																		IL_0c08_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)RsagetFailure[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_0c40_2;
																		IL_0c40_2:
																		ptr2 += 8;
																		goto IL_0cef_2;
																		IL_0c53_2:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_0c5e_2;
																		IL_0c5e_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0c9c_2;
																	}
																	break;
																}
																goto IL_0451_2;
																IL_07cc_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_07f5_2;
																IL_0451_2:
																if (11 <= b)
																{
																	num = 81;
																	goto IL_0cef_2;
																}
																goto IL_046a_2;
																IL_07f5_2:
																ptr2 += 8;
																goto IL_0803_2;
																IL_046a_2:
																if (5 < b)
																{
																	goto IL_0478_2;
																}
																goto IL_0577_2;
																IL_0478_2:
																if (8 < b)
																{
																	goto IL_0486_2;
																}
																goto IL_0538_2;
																IL_0486_2:
																if (9 < b)
																{
																	goto IL_0494_2;
																}
																goto IL_0525_2;
																IL_0494_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_04a2_2;
																IL_04a2_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_04b0_2;
																IL_04b0_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0512_2;
																IL_0512_2:
																num6 -= 2;
																goto IL_0cef_2;
																IL_0525_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_086d_2;
																IL_086d_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_08ad_2;
																IL_08ad_2:
																array2[num6 - 2] = 0;
																goto IL_08c1_2;
																IL_08c1_2:
																num6--;
																goto IL_0cef_2;
																IL_0538_2:
																if (8 <= b)
																{
																	goto IL_0543_2;
																}
																goto IL_0556_2;
																IL_0543_2:
																num6--;
																goto IL_0cef_2;
																IL_0556_2:
																if (6 < b)
																{
																	goto IL_0564_2;
																}
																goto IL_0623_2;
																IL_0564_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0712_2;
																IL_0712_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0720_2;
																IL_0720_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0760_2;
																IL_0760_2:
																array2[num6 - 2] = 0;
																goto IL_0774_2;
																IL_0774_2:
																num6--;
																goto IL_0cef_2;
																IL_0623_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0631_2;
																IL_0631_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0671_2;
																IL_0671_2:
																array2[num6 - 2] = 0;
																goto IL_0685_2;
																IL_0685_2:
																num6--;
																goto IL_0cef_2;
																IL_0577_2:
																if (5 <= b)
																{
																	goto IL_0582_2;
																}
																goto IL_05e9_2;
																IL_0582_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_05c2_2;
																IL_05c2_2:
																array2[num6 - 2] = 0;
																goto IL_05d6_2;
																IL_05d6_2:
																num6--;
																goto IL_0cef_2;
																IL_05e9_2:
																if (2 >= b)
																{
																	goto IL_05f4_2;
																}
																num = 189;
																goto IL_0787_2;
																IL_05f4_2:
																if (2 > b)
																{
																	goto IL_0602_2;
																}
																goto IL_0698_2;
																IL_0602_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_06ff_2;
																IL_06ff_2:
																if (1 > b)
																{
																}
																break;
																IL_0698_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_06d8_2;
																IL_06d8_2:
																array2[num6 - 2] = 0;
																goto IL_06ec_2;
																IL_06ec_2:
																num6--;
																goto IL_0cef_2;
																IL_0803_2:
																num6--;
																goto IL_0cef_2;
																IL_0787_2:
																if (3 < b)
																{
																	goto IL_0792_2;
																}
																goto IL_07be_2;
																IL_0792_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_07a0_2;
																IL_07a0_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_07ae_2;
																IL_07ae_2:
																array2[num6] = 0;
																goto IL_0816_2;
																IL_0816_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0839_2;
																IL_0839_2:
																array3[num6] = null;
																num = 182;
																goto IL_084c_2;
																IL_084c_2:
																num6++;
																goto IL_085a_2;
																IL_085a_2:
																ptr2 += 8;
																goto IL_0cef_2;
																IL_07be_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_07cc_2;
															}
															break;
															IL_03d4_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0cc5_2;
													IL_0ce1_2:
													ptr2 += 8;
													goto IL_0cef_2;
													IL_0cd3_2:
													num6++;
													goto IL_0ce1_2;
													IL_0cc5_2:
													array2[num6] = 0;
													goto IL_0cd3_2;
													continue;
													end_IL_03e4_2:
													break;
												}
												continue;
												end_IL_03f4:
												break;
											}
											continue;
											end_IL_0404:
											break;
										}
										break;
									}
									goto IL_0dbb_2;
									IL_0dbb_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0a56:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class109()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_13(int int_6, int int_7)
	{
		int num = int_6;
		int num2 = int_7;
		int num3;
		if (num <= num2)
		{
			num = int_7;
			num2 = int_6;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_6;
			num2 = int_7;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 8;
		num2 = 2;
		int num4 = smethod_15(2, 47);
		num2 = num4;
		return num;
	}

	private unsafe static int smethod_14(int int_6)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_6;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddMillisecondsCheckSubKeyReadPermission.AllowHexSpecifierUnique);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_024d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_022d:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0220:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0210:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_01eb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_01d6:
																									array2[num5] = null;
																									num = 109;
																									while (true)
																									{
																										if (num != 109)
																										{
																											if (num != 1090)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 67:
																												goto IL_01d6;
																											case 24:
																												goto IL_01eb;
																											case 94:
																											case 96:
																												goto IL_0210;
																											case 57:
																												goto IL_0220;
																											case 1:
																												goto IL_022d;
																											case 58:
																												goto end_IL_022d;
																											case 29:
																												goto IL_024d;
																											case 3:
																												goto end_IL_024d;
																											case 7:
																											case 10:
																												goto end_IL_025d;
																											case 15:
																												goto IL_0278;
																											case 14:
																												goto IL_0286;
																											case 20:
																											case 35:
																												goto IL_0291;
																											case 31:
																											case 46:
																												goto IL_02a1;
																											case 48:
																												goto IL_02cf;
																											case 59:
																												goto IL_02e2;
																											case 11:
																												goto IL_02ed;
																											case 42:
																												goto IL_02f8;
																											case 25:
																												goto IL_0306;
																											case 37:
																											case 61:
																												goto IL_0319;
																											case 8:
																											case 26:
																												goto IL_0324;
																											case 2:
																												goto IL_0332;
																											case 4:
																												goto IL_0345;
																											case 5:
																											case 55:
																												goto end_IL_01c3;
																											case 34:
																											case 64:
																												goto IL_036f;
																											case 12:
																												goto IL_03d1;
																											case 69:
																												goto IL_03e4;
																											case 38:
																											case 40:
																												goto IL_03f2;
																											case 68:
																												goto IL_0432;
																											case 87:
																												goto IL_044b;
																											case 45:
																											case 89:
																												goto IL_045e;
																											case 41:
																												goto IL_0477;
																											case 70:
																												goto IL_048e;
																											case 51:
																												goto IL_049c;
																											case 62:
																											case 90:
																												goto IL_04b8;
																											case 43:
																												goto IL_04c3;
																											case 0:
																											case 32:
																												goto IL_04d1;
																											case 75:
																												goto IL_04e9;
																											case 23:
																												goto IL_04f7;
																											case 78:
																											case 91:
																												goto IL_050a;
																											case 98:
																												goto IL_052f;
																											case 56:
																												goto IL_053d;
																											case 101:
																												goto IL_054d;
																											case 21:
																												goto IL_0564;
																											case 28:
																												goto IL_0572;
																											case 102:
																												goto IL_0582;
																											case 49:
																												goto IL_05a9;
																											case 9:
																											case 13:
																											case 16:
																											case 19:
																											case 33:
																											case 47:
																											case 50:
																											case 52:
																											case 54:
																											case 60:
																											case 73:
																											case 79:
																											case 81:
																											case 82:
																											case 84:
																											case 92:
																											case 93:
																											case 95:
																												goto end_IL_023d;
																											case 6:
																											case 22:
																											case 27:
																											case 30:
																											case 44:
																											case 53:
																											case 71:
																											case 72:
																											case 74:
																											case 77:
																											case 80:
																											case 99:
																											case 100:
																												goto end_IL_026d;
																											case 36:
																												goto end_IL_05cc;
																											case 65:
																												goto end_IL_05df;
																											case 86:
																												goto end_IL_05e9;
																											case 63:
																												goto end_IL_05f4;
																											case 66:
																											case 83:
																												goto end_IL_0609;
																											case 97:
																												goto end_IL_0619;
																											case 39:
																											case 85:
																												goto end_IL_0629;
																											case 17:
																												goto end_IL_0639;
																											case 18:
																												goto end_IL_0649;
																											case 76:
																											case 88:
																												goto IL_0664;
																											}
																											continue;
																										}
																										num5++;
																										num = 49;
																										goto IL_05a9;
																										IL_05a9:
																										ptr2 += 8;
																										goto end_IL_026d;
																										continue;
																										end_IL_01c3:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0278;
																					IL_04f7:
																					if (4 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto end_IL_026d;
																					IL_0278:
																					if (2 >= b)
																					{
																						goto IL_0286;
																					}
																					goto IL_04b8;
																					IL_0286:
																					if (2 > b)
																					{
																						goto IL_0291;
																					}
																					goto IL_02a1;
																					IL_0291:
																					if (1 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_02cf;
																					IL_02cf:
																					if (1 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_045e;
																					IL_045e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0477;
																					IL_0477:
																					array[num5] = 0;
																					num = 70;
																					goto IL_048e;
																					IL_048e:
																					num5++;
																					goto IL_049c;
																					IL_049c:
																					ptr2 += 8;
																					num = 53;
																					goto end_IL_026d;
																					IL_02a1:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_052f;
																					IL_052f:
																					ptr2 += 8;
																					goto IL_053d;
																					IL_053d:
																					num5--;
																					goto end_IL_026d;
																					IL_04b8:
																					if (3 >= b)
																					{
																						goto IL_04c3;
																					}
																					goto IL_04e9;
																					IL_04c3:
																					if (3 > b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_04d1;
																					IL_04d1:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_026d;
																					IL_04e9:
																					if (4 < b)
																					{
																						goto end_IL_023d;
																					}
																					goto IL_04f7;
																				}
																				goto IL_0353;
																			}
																			goto IL_02e2;
																			IL_0353:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_026d;
																			IL_02e2:
																			if (8 >= b)
																			{
																				goto IL_02ed;
																			}
																			goto IL_0319;
																			IL_02ed:
																			if (8 > b)
																			{
																				goto IL_02f8;
																			}
																			goto IL_036f;
																			IL_02f8:
																			if (6 < b)
																			{
																				goto IL_0306;
																			}
																			goto IL_03e4;
																			IL_0306:
																			if (7 < b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_044b;
																			IL_044b:
																			if (7 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_050a;
																			IL_050a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_054d;
																			IL_054d:
																			array[num5] = 0;
																			num = 21;
																			goto IL_0564;
																			IL_0564:
																			num5++;
																			goto IL_0572;
																			IL_0572:
																			ptr2 += 8;
																			goto end_IL_026d;
																			IL_03e4:
																			if (6 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_03f2;
																			IL_03f2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0432;
																			IL_0432:
																			array[num5 - 2] = 0;
																			goto IL_0582;
																			IL_0582:
																			num5--;
																			goto end_IL_026d;
																			IL_036f:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03d1;
																			IL_03d1:
																			num5 -= 2;
																			goto end_IL_026d;
																			IL_0319:
																			if (9 < b)
																			{
																				goto IL_0324;
																			}
																			goto IL_0345;
																			IL_0324:
																			if (10 < b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_0332;
																			IL_0332:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_023d;
																			IL_0345:
																			if (9 > b)
																			{
																				goto end_IL_023d;
																			}
																			goto IL_0353;
																			continue;
																			end_IL_022d:
																			break;
																		}
																		continue;
																		end_IL_023d:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_026d;
																continue;
																end_IL_024d:
																break;
															}
															continue;
															end_IL_025d:
															break;
														}
														continue;
														end_IL_026d:
														break;
													}
													continue;
												}
												goto IL_0664;
												IL_0664:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05cc:
												break;
											}
											continue;
											end_IL_05df:
											break;
										}
										continue;
										end_IL_05e9:
										break;
									}
									continue;
									end_IL_05f4:
									break;
								}
								continue;
								end_IL_0609:
								break;
							}
							continue;
							end_IL_0619:
							break;
						}
						continue;
						end_IL_0629:
						break;
					}
					continue;
					end_IL_0639:
					break;
				}
				continue;
				end_IL_0649:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_6, int int_7)
	{
		int num = 58;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 21;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 68;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_6;
									while (true)
									{
										array3[1] = int_7;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HMACMDMidpointRounding.getNoneELEMDESC);
											num = 72;
											while (true)
											{
												byte* ptr2 = ptr;
												num = 46;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02a7:
															byte b = *ptr2;
															while (true)
															{
																IL_0297:
																ptr2++;
																while (true)
																{
																	IL_0287:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_026a:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_025a:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_024a:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_023a:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01c7:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												while (true)
																												{
																													IL_01ae:
																													num5 -= 2;
																													num = 99;
																													while (num != 99)
																													{
																														if (num != 1080)
																														{
																															goto end_IL_0277;
																														}
																														switch (num)
																														{
																														case 80:
																															goto IL_01ae;
																														case 0:
																														case 65:
																															goto IL_01c7;
																														case 42:
																															goto IL_023a;
																														case 74:
																														case 86:
																															goto IL_024a;
																														case 77:
																															goto IL_025a;
																														case 20:
																															goto IL_026a;
																														case 6:
																															goto IL_0277;
																														case 15:
																															goto IL_0287;
																														case 3:
																															goto IL_0297;
																														case 11:
																														case 27:
																															goto IL_02a7;
																														case 1:
																														case 30:
																															goto IL_02b2;
																														case 35:
																															goto IL_02bd;
																														case 36:
																															goto IL_02cd;
																														case 48:
																															goto IL_02db;
																														case 17:
																														case 54:
																															goto IL_02eb;
																														case 61:
																															goto IL_02fb;
																														case 32:
																														case 40:
																															goto IL_0309;
																														case 23:
																														case 76:
																															goto IL_0321;
																														case 78:
																															goto IL_032f;
																														case 44:
																														case 63:
																															goto IL_033d;
																														case 87:
																															goto IL_0359;
																														case 91:
																															goto IL_036c;
																														case 70:
																														case 83:
																															goto IL_037a;
																														case 43:
																															goto IL_0388;
																														case 82:
																															goto IL_03ab;
																														case 2:
																															goto IL_03be;
																														case 85:
																															goto IL_03cc;
																														case 79:
																															goto IL_03df;
																														case 28:
																															goto IL_03ed;
																														case 50:
																														case 55:
																															goto IL_03fb;
																														case 19:
																															goto IL_043b;
																														case 7:
																															goto IL_0458;
																														case 52:
																														case 66:
																															goto IL_046b;
																														case 45:
																															goto IL_049d;
																														case 88:
																															goto IL_04ab;
																														case 5:
																														case 8:
																														case 9:
																														case 12:
																														case 13:
																														case 14:
																														case 16:
																														case 18:
																														case 22:
																														case 24:
																														case 25:
																														case 26:
																														case 31:
																														case 38:
																														case 49:
																														case 64:
																														case 69:
																														case 73:
																														case 84:
																														case 92:
																															goto end_IL_0277;
																														case 39:
																															goto IL_04de;
																														case 10:
																															goto IL_04ec;
																														case 53:
																															goto IL_04fa;
																														case 4:
																														case 29:
																														case 34:
																														case 37:
																														case 46:
																														case 47:
																														case 71:
																														case 75:
																														case 81:
																														case 90:
																															goto end_IL_019b;
																														case 72:
																															goto end_IL_0508;
																														case 67:
																															goto end_IL_051b;
																														case 51:
																															goto end_IL_052e;
																														case 60:
																															goto end_IL_0542;
																														case 41:
																															goto end_IL_0557;
																														case 62:
																														case 68:
																															goto end_IL_056c;
																														case 89:
																															goto end_IL_057c;
																														case 21:
																														case 33:
																															goto end_IL_058c;
																														case 57:
																															goto end_IL_05a5;
																														case 58:
																															goto end_IL_05b5;
																														case 56:
																														case 59:
																															goto IL_05d9;
																														}
																														continue;
																														end_IL_019b:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02eb;
																										IL_0359:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_0277;
																										IL_02eb:
																										if (1 < b)
																										{
																											goto end_IL_0277;
																										}
																										goto IL_0359;
																									}
																									break;
																								}
																								goto IL_03df;
																								IL_0458:
																								num5--;
																								break;
																								IL_03df:
																								if (3 < b)
																								{
																									goto end_IL_0277;
																								}
																								goto IL_03ed;
																								IL_03ed:
																								if (3 > b)
																								{
																									goto end_IL_0277;
																								}
																								goto IL_03fb;
																								IL_03fb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_043b;
																								IL_043b:
																								array[num5 - 2] = 0;
																								num = 7;
																								goto IL_0458;
																							}
																							break;
																						}
																						goto IL_046b;
																						IL_04ab:
																						num5--;
																						break;
																						IL_046b:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 45;
																						goto IL_049d;
																						IL_049d:
																						ptr2 += 8;
																						goto IL_04ab;
																					}
																					break;
																				}
																				goto IL_02b2;
																				IL_0309:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_02b2:
																				if (6 < b)
																				{
																					goto IL_02bd;
																				}
																				goto IL_02cd;
																				IL_02bd:
																				if (7 < b)
																				{
																					goto IL_0321;
																				}
																				goto IL_036c;
																				IL_0321:
																				if (8 < b)
																				{
																					goto end_IL_0277;
																				}
																				goto IL_032f;
																				IL_032f:
																				if (8 > b)
																				{
																					goto end_IL_0277;
																				}
																				goto IL_033d;
																				IL_033d:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_036c:
																				if (7 > b)
																				{
																					goto end_IL_0277;
																				}
																				goto IL_037a;
																				IL_037a:
																				array[num5] = 0;
																				goto IL_0388;
																				IL_0388:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03ab;
																				IL_03ab:
																				array2[num5] = null;
																				num = 2;
																				goto IL_03be;
																				IL_03be:
																				num5++;
																				goto IL_03cc;
																				IL_03cc:
																				ptr2 += 8;
																				break;
																				IL_02cd:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_02db;
																				IL_02db:
																				if (5 < b)
																				{
																					goto end_IL_0277;
																				}
																				goto IL_02fb;
																				IL_02fb:
																				if (5 > b)
																				{
																					goto end_IL_0277;
																				}
																				goto IL_0309;
																			}
																			goto end_IL_0287;
																			continue;
																			end_IL_0277:
																			break;
																			IL_0277:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04de;
																	IL_04fa:
																	ptr2 += 8;
																	break;
																	IL_04ec:
																	num5++;
																	goto IL_04fa;
																	IL_04de:
																	array[num5] = 0;
																	goto IL_04ec;
																	continue;
																	end_IL_0287:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05d9;
													IL_05d9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0508:
													break;
												}
												continue;
												end_IL_051b:
												break;
											}
											continue;
											end_IL_052e:
											break;
										}
										continue;
										end_IL_0542:
										break;
									}
									continue;
									end_IL_0557:
									break;
								}
								continue;
								end_IL_056c:
								break;
							}
							continue;
							end_IL_057c:
							break;
						}
						continue;
						end_IL_058c:
						break;
					}
					continue;
					end_IL_05a5:
					break;
				}
				continue;
				end_IL_05b5:
				break;
			}
		}
	}

	private static int smethod_16(int int_6)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_6;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_6;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_17()
	{
		int num = 100;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 53;
				while (true)
				{
					byte[] array = new byte[4];
					num = 129;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WindowsAccountTypeAddXmlElement.windowsAccountTypeAddXmlElement_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 119;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0303:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02f6:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02e6:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02d6:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_0282:
																														ref int reference = ref array3[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 152;
																														while (true)
																														{
																															if (num != 152)
																															{
																																if (num != 1133)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 71:
																																case 120:
																																	goto IL_0282;
																																case 34:
																																	goto IL_02b6;
																																case 45:
																																case 79:
																																	goto IL_02c6;
																																case 104:
																																case 138:
																																	goto IL_02d6;
																																case 82:
																																	goto IL_02e6;
																																case 13:
																																	goto IL_02f6;
																																case 49:
																																	goto IL_0303;
																																case 5:
																																	goto IL_0310;
																																case 15:
																																	goto IL_0320;
																																case 66:
																																	goto end_IL_0320;
																																case 119:
																																	goto end_IL_0330;
																																case 113:
																																	goto end_IL_0340;
																																case 31:
																																case 56:
																																	goto IL_0356;
																																case 55:
																																case 58:
																																	goto IL_0369;
																																case 75:
																																	goto IL_0381;
																																case 76:
																																	goto IL_038c;
																																case 24:
																																	goto IL_0397;
																																case 62:
																																	goto IL_03aa;
																																case 70:
																																	goto IL_03b8;
																																case 102:
																																	goto IL_03cb;
																																case 21:
																																	goto IL_03d9;
																																case 28:
																																case 106:
																																	goto IL_03ec;
																																case 46:
																																	goto IL_040a;
																																case 103:
																																	goto IL_0418;
																																case 89:
																																case 109:
																																	goto IL_042b;
																																case 38:
																																	goto IL_0439;
																																case 68:
																																case 78:
																																	goto IL_0447;
																																case 54:
																																	goto end_IL_026f;
																																case 110:
																																	goto IL_0473;
																																case 77:
																																case 98:
																																	goto IL_048a;
																																case 48:
																																	goto IL_0498;
																																case 22:
																																	goto IL_04b0;
																																case 16:
																																	goto IL_04be;
																																case 125:
																																	goto IL_04da;
																																case 4:
																																	goto IL_04e8;
																																case 26:
																																case 92:
																																	goto IL_04f6;
																																case 19:
																																	goto IL_0504;
																																case 1:
																																case 20:
																																	goto IL_0512;
																																case 44:
																																	goto IL_0574;
																																case 73:
																																case 80:
																																	goto IL_0587;
																																case 101:
																																case 126:
																																	goto IL_05a3;
																																case 112:
																																	goto IL_05e2;
																																case 128:
																																	goto IL_05f5;
																																case 2:
																																case 83:
																																	goto IL_0600;
																																case 84:
																																case 123:
																																	goto IL_060b;
																																case 18:
																																	goto IL_061e;
																																case 86:
																																	goto IL_062c;
																																case 88:
																																	goto IL_063a;
																																case 3:
																																case 14:
																																	goto IL_064d;
																																case 85:
																																	goto IL_068d;
																																case 35:
																																	goto IL_06aa;
																																case 36:
																																case 130:
																																	goto IL_06bd;
																																case 64:
																																	goto IL_06e6;
																																case 61:
																																case 131:
																																	goto IL_06ff;
																																case 96:
																																	goto IL_073f;
																																case 118:
																																	goto IL_0753;
																																case 133:
																																	goto IL_0766;
																																case 136:
																																	goto IL_0774;
																																case 137:
																																	goto IL_0790;
																																case 29:
																																case 115:
																																	goto IL_079e;
																																case 140:
																																	goto IL_07e4;
																																case 107:
																																	goto IL_07f2;
																																case 142:
																																	goto IL_0805;
																																case 12:
																																	goto IL_0819;
																																case 144:
																																case 145:
																																	goto IL_082c;
																																case 57:
																																	goto IL_083a;
																																case 105:
																																	goto IL_085d;
																																case 63:
																																	goto IL_0867;
																																case 117:
																																	goto IL_0875;
																																case 116:
																																	goto IL_0893;
																																case 6:
																																case 9:
																																case 27:
																																case 37:
																																case 42:
																																case 43:
																																case 47:
																																case 50:
																																case 51:
																																case 52:
																																case 65:
																																case 67:
																																case 69:
																																case 81:
																																case 90:
																																case 91:
																																case 93:
																																case 94:
																																case 95:
																																case 97:
																																case 121:
																																case 122:
																																case 134:
																																case 135:
																																case 141:
																																	goto end_IL_02b6;
																																case 0:
																																case 8:
																																case 23:
																																case 32:
																																case 39:
																																case 40:
																																case 41:
																																case 60:
																																case 72:
																																case 74:
																																case 87:
																																case 108:
																																case 111:
																																case 124:
																																case 127:
																																case 132:
																																case 139:
																																case 143:
																																	goto end_IL_034b;
																																case 11:
																																	goto end_IL_08b6;
																																case 10:
																																	goto end_IL_08c9;
																																case 7:
																																	goto end_IL_08d3;
																																case 25:
																																	goto end_IL_08de;
																																case 59:
																																case 114:
																																	goto end_IL_08ee;
																																case 129:
																																	goto end_IL_08fe;
																																case 30:
																																case 53:
																																	goto end_IL_090e;
																																case 99:
																																	goto end_IL_091e;
																																case 100:
																																	goto end_IL_0937;
																																case 17:
																																case 33:
																																	goto IL_095b;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto IL_0893;
																															IL_0893:
																															num5--;
																															goto end_IL_034b;
																															continue;
																															end_IL_026f:
																															break;
																														}
																														break;
																													}
																													goto IL_0460;
																													continue;
																													end_IL_02b6:
																													break;
																													IL_02b6:;
																												}
																												break;
																												IL_02c6:;
																											}
																											break;
																										}
																										goto IL_03cb;
																										IL_05a3:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_05e2;
																										IL_03cb:
																										if (6 > b)
																										{
																											goto IL_03d9;
																										}
																										goto IL_05a3;
																										IL_03d9:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_0473;
																										IL_0473:
																										if (5 > b)
																										{
																											break;
																										}
																										num = 98;
																										goto IL_048a;
																										IL_05e2:
																										num5 -= 3;
																										goto end_IL_034b;
																										IL_048a:
																										array[num5] = 5;
																										goto IL_0498;
																										IL_0498:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_04b0;
																										IL_04b0:
																										num5++;
																										goto IL_04be;
																										IL_04be:
																										ptr2 += 8;
																										num = 111;
																										goto end_IL_034b;
																									}
																									break;
																								}
																								goto IL_0381;
																								IL_0418:
																								num5--;
																								goto end_IL_034b;
																								IL_0381:
																								if (4 > b)
																								{
																									goto IL_038c;
																								}
																								goto IL_03ec;
																								IL_038c:
																								if (2 >= b)
																								{
																									goto IL_0397;
																								}
																								goto IL_03aa;
																								IL_0397:
																								if (2 > b)
																								{
																									goto IL_042b;
																								}
																								goto IL_06ff;
																								IL_042b:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0439;
																								IL_0439:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0447;
																								IL_0447:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0460;
																								IL_0460:
																								array[num5] = 0;
																								goto IL_07e4;
																								IL_07e4:
																								num5++;
																								goto IL_07f2;
																								IL_07f2:
																								ptr2 += 8;
																								goto end_IL_034b;
																								IL_06ff:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_073f;
																								IL_073f:
																								array[num5 - 2] = 0;
																								goto IL_0753;
																								IL_0753:
																								num5--;
																								goto end_IL_034b;
																								IL_03aa:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_03b8;
																								IL_03b8:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_06bd;
																								IL_06bd:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_06e6;
																								IL_06e6:
																								array[num5 - 1] = 5;
																								goto end_IL_034b;
																								IL_03ec:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_040a;
																								IL_040a:
																								ptr2 += 8;
																								goto IL_0418;
																							}
																							break;
																						}
																						goto IL_0369;
																						IL_0369:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_034b;
																					}
																					break;
																				}
																				goto IL_0356;
																				IL_0774:
																				if (15 <= b)
																				{
																					num = 47;
																				}
																				break;
																				IL_0356:
																				if (12 < b)
																				{
																					goto IL_04da;
																				}
																				goto IL_05f5;
																				IL_05f5:
																				if (12 > b)
																				{
																					goto IL_0600;
																				}
																				goto IL_064d;
																				IL_0600:
																				if (10 < b)
																				{
																					goto IL_060b;
																				}
																				goto IL_061e;
																				IL_060b:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0790;
																				IL_0790:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_079e;
																				IL_079e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0805;
																				IL_0805:
																				array[num5 - 2] = 0;
																				goto IL_0819;
																				IL_0819:
																				num5--;
																				goto end_IL_034b;
																				IL_061e:
																				if (10 > b)
																				{
																					goto IL_062c;
																				}
																				goto IL_082c;
																				IL_062c:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_063a;
																				IL_063a:
																				if (9 <= b)
																				{
																					goto end_IL_034b;
																				}
																				break;
																				IL_082c:
																				array[num5] = 0;
																				goto IL_083a;
																				IL_083a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_085d;
																				IL_085d:
																				array2[num5] = null;
																				goto IL_0867;
																				IL_0867:
																				num5++;
																				goto IL_0875;
																				IL_0875:
																				ptr2 += 8;
																				goto end_IL_034b;
																				IL_064d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_068d;
																				IL_068d:
																				array[num5 - 2] = 0;
																				num = 35;
																				goto IL_06aa;
																				IL_06aa:
																				num5--;
																				goto end_IL_034b;
																				IL_04da:
																				if (14 >= b)
																				{
																					goto IL_04e8;
																				}
																				goto IL_0766;
																				IL_04e8:
																				if (14 > b)
																				{
																					goto IL_04f6;
																				}
																				goto IL_0587;
																				IL_04f6:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0504;
																				IL_0504:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0512;
																				IL_0512:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0574;
																				IL_0574:
																				num5 -= 2;
																				goto end_IL_034b;
																				IL_0587:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_034b;
																				IL_0766:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0774;
																			}
																			break;
																			IL_0310:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_034b;
																	continue;
																	end_IL_0320:
																	break;
																}
																continue;
																end_IL_0330:
																break;
															}
															continue;
															end_IL_0340:
															break;
														}
														continue;
														end_IL_034b:
														break;
													}
													continue;
												}
												goto IL_095b;
												IL_095b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b6:
												break;
											}
											continue;
											end_IL_08c9:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08de:
									break;
								}
								continue;
								end_IL_08ee:
								break;
							}
							continue;
							end_IL_08fe:
							break;
						}
						continue;
						end_IL_090e:
						break;
					}
					continue;
					end_IL_091e:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_6, int int_7)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 48;
							while (true)
							{
								int[] array3 = new int[5];
								num = 15;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_6;
										while (true)
										{
											array3[1] = int_7;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref rootTaskTraceLoggingDataCollector.TYPEFLAGFNONEXTENSIBLECaseSensitive);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_024d:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_022d:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0220:
																							if (5 <= b)
																							{
																								while (true)
																								{
																									IL_0210:
																									array[num5] = 0;
																									while (true)
																									{
																										IL_01e2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										num = 112;
																										while (true)
																										{
																											if (num != 112)
																											{
																												if (num != 1093)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 63:
																													goto IL_01e2;
																												case 1:
																												case 58:
																													goto IL_0210;
																												case 37:
																													goto IL_0220;
																												case 38:
																													goto IL_022d;
																												case 99:
																													goto IL_023d;
																												case 12:
																													goto IL_024d;
																												case 52:
																													goto end_IL_024d;
																												case 4:
																												case 57:
																													goto end_IL_025d;
																												case 45:
																													goto IL_0278;
																												case 84:
																												case 86:
																													goto IL_0286;
																												case 42:
																													goto IL_0291;
																												case 27:
																												case 47:
																													goto IL_029f;
																												case 25:
																													goto IL_02c8;
																												case 11:
																													goto IL_02d6;
																												case 85:
																												case 95:
																													goto IL_02e9;
																												case 31:
																													goto IL_02f7;
																												case 29:
																												case 56:
																													goto IL_0305;
																												case 5:
																													goto IL_0345;
																												case 22:
																													goto IL_0359;
																												case 102:
																													goto IL_036c;
																												case 30:
																												case 103:
																													goto IL_0377;
																												case 83:
																													goto IL_0385;
																												case 79:
																												case 105:
																													goto IL_03a1;
																												case 69:
																													goto IL_03ea;
																												case 2:
																													goto IL_03fe;
																												case 73:
																													goto IL_041b;
																												case 40:
																													goto IL_0429;
																												case 89:
																												case 96:
																													goto IL_043c;
																												case 8:
																												case 13:
																													goto IL_044a;
																												case 10:
																													goto IL_0455;
																												case 50:
																												case 97:
																													goto IL_0463;
																												case 34:
																													goto IL_04a3;
																												case 41:
																													goto IL_04b7;
																												case 65:
																													goto IL_04ca;
																												case 68:
																													goto IL_04d8;
																												case 7:
																												case 100:
																													goto IL_04f1;
																												case 54:
																													goto IL_050d;
																												case 75:
																													goto IL_051b;
																												case 3:
																													goto IL_0526;
																												case 23:
																												case 43:
																													goto IL_053c;
																												case 62:
																													goto IL_057c;
																												case 44:
																													goto IL_0590;
																												case 14:
																												case 16:
																												case 17:
																												case 26:
																												case 28:
																												case 32:
																												case 46:
																												case 49:
																												case 60:
																												case 61:
																												case 64:
																												case 74:
																												case 78:
																												case 80:
																												case 81:
																												case 88:
																												case 98:
																												case 104:
																													goto end_IL_01cf;
																												case 36:
																													goto IL_05c6;
																												case 24:
																													goto IL_05d4;
																												case 90:
																													goto IL_05e2;
																												case 92:
																												case 94:
																													goto IL_05f2;
																												case 35:
																													goto IL_0614;
																												case 91:
																													goto IL_0622;
																												case 70:
																													goto IL_0639;
																												case 6:
																												case 18:
																												case 55:
																												case 59:
																												case 67:
																												case 72:
																												case 76:
																												case 82:
																												case 87:
																												case 93:
																												case 101:
																													goto end_IL_026d;
																												case 21:
																													goto end_IL_0647;
																												case 39:
																													goto end_IL_065a;
																												case 71:
																													goto end_IL_0664;
																												case 51:
																													goto end_IL_066f;
																												case 15:
																													goto end_IL_0684;
																												case 48:
																													goto end_IL_0699;
																												case 66:
																													goto end_IL_06a9;
																												case 0:
																													goto end_IL_06c2;
																												case 33:
																												case 53:
																													goto end_IL_06cd;
																												case 19:
																													goto end_IL_06dd;
																												case 20:
																													goto end_IL_06ed;
																												case 9:
																												case 77:
																													goto IL_0708;
																												}
																												continue;
																											}
																											array2[num5] = null;
																											goto IL_041b;
																											IL_041b:
																											num5++;
																											goto IL_0429;
																											IL_0429:
																											ptr2 += 8;
																											goto end_IL_026d;
																											continue;
																											end_IL_01cf:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0278;
																							IL_03ea:
																							array[num5 - 2] = 0;
																							goto IL_03fe;
																							IL_0278:
																							if (2 < b)
																							{
																								goto IL_0286;
																							}
																							goto IL_036c;
																							IL_0286:
																							if (3 >= b)
																							{
																								goto IL_0291;
																							}
																							goto IL_02e9;
																							IL_0291:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_029f;
																							IL_029f:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02c8;
																							IL_02c8:
																							ptr2 += 8;
																							goto IL_02d6;
																							IL_02d6:
																							num5--;
																							goto end_IL_026d;
																							IL_02e9:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_02f7;
																							IL_02f7:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0305;
																							IL_0305:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0345;
																							IL_0345:
																							array[num5 - 2] = 0;
																							goto IL_0359;
																							IL_0359:
																							num5--;
																							goto end_IL_026d;
																							IL_036c:
																							if (2 > b)
																							{
																								goto IL_0377;
																							}
																							goto IL_03a1;
																							IL_0377:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0385;
																							IL_0385:
																							if (1 <= b)
																							{
																								num = 61;
																							}
																							break;
																							IL_03fe:
																							num5--;
																							goto end_IL_026d;
																							IL_03a1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 69;
																							goto IL_03ea;
																						}
																						break;
																					}
																					goto IL_043c;
																					IL_0614:
																					array[num5] = 0;
																					goto IL_0622;
																					IL_043c:
																					if (7 < b)
																					{
																						goto IL_044a;
																					}
																					goto IL_050d;
																					IL_044a:
																					if (8 >= b)
																					{
																						goto IL_0455;
																					}
																					goto IL_04ca;
																					IL_0455:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0463;
																					IL_0463:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04a3;
																					IL_04a3:
																					array[num5 - 2] = 0;
																					goto IL_04b7;
																					IL_04b7:
																					num5--;
																					goto end_IL_026d;
																					IL_04ca:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_04d8;
																					IL_04d8:
																					if (9 > b)
																					{
																						num = 88;
																						break;
																					}
																					goto IL_04f1;
																					IL_0622:
																					num5++;
																					num = 70;
																					goto IL_0639;
																					IL_04f1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_026d;
																					IL_050d:
																					if (7 > b)
																					{
																						goto IL_051b;
																					}
																					goto IL_05f2;
																					IL_051b:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_0526;
																					IL_0526:
																					if (6 > b)
																					{
																						num = 46;
																						break;
																					}
																					goto IL_053c;
																					IL_0639:
																					ptr2 += 8;
																					goto end_IL_026d;
																					IL_053c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_057c;
																					IL_057c:
																					array[num5 - 2] = 0;
																					goto IL_0590;
																					IL_0590:
																					num5--;
																					goto end_IL_026d;
																					IL_05f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 35;
																					goto IL_0614;
																				}
																				break;
																				IL_023d:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05c6;
																		IL_05e2:
																		ptr2 += 8;
																		goto end_IL_026d;
																		IL_05d4:
																		num5++;
																		goto IL_05e2;
																		IL_05c6:
																		array[num5] = 0;
																		goto IL_05d4;
																		continue;
																		end_IL_024d:
																		break;
																	}
																	continue;
																	end_IL_025d:
																	break;
																}
																continue;
																end_IL_026d:
																break;
															}
															continue;
														}
														goto IL_0708;
														IL_0708:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0647:
														break;
													}
													continue;
													end_IL_065a:
													break;
												}
												continue;
												end_IL_0664:
												break;
											}
											continue;
											end_IL_066f:
											break;
										}
										continue;
										end_IL_0684:
										break;
									}
									continue;
									end_IL_0699:
									break;
								}
								continue;
								end_IL_06a9:
								break;
							}
							continue;
							end_IL_06c2:
							break;
						}
						continue;
						end_IL_06cd:
						break;
					}
					continue;
					end_IL_06dd:
					break;
				}
				continue;
				end_IL_06ed:
				break;
			}
		}
	}

	private static int smethod_19(int int_6)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_6;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 155;
		num4 = 31;
		int num5 = smethod_18(31, 41);
		num4 = num5;
		return num;
	}

	private unsafe static int smethod_20(int int_6, int int_7)
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 13;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 60;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_6;
										while (true)
										{
											array3[1] = int_7;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DMNdSafeHandleZeroOrMinusOneIsInvalid.DuplicateMachineKeyset);
												num = 75;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02c6:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_02a9:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_029c:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_028c:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_027f:
																											if (7 >= b)
																											{
																												while (7 <= b)
																												{
																													num = 40;
																													while (true)
																													{
																														IL_0251:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_0241:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_0228:
																																num5++;
																																num = 126;
																																while (true)
																																{
																																	if (num != 126)
																																	{
																																		if (num != 1107)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 52:
																																			goto IL_0228;
																																		case 5:
																																			goto IL_0241;
																																		case 40:
																																		case 46:
																																			goto IL_0251;
																																		case 37:
																																			goto IL_026c;
																																		case 111:
																																			goto IL_027f;
																																		case 105:
																																			goto IL_028c;
																																		case 74:
																																			goto IL_029c;
																																		case 80:
																																			goto IL_02a9;
																																		case 84:
																																			goto IL_02b6;
																																		case 0:
																																			goto IL_02c6;
																																		case 103:
																																			goto end_IL_02c6;
																																		case 43:
																																		case 88:
																																			goto end_IL_02d6;
																																		case 16:
																																		case 45:
																																			goto IL_02f1;
																																		case 24:
																																		case 47:
																																			goto IL_0304;
																																		case 27:
																																			goto IL_0312;
																																		case 49:
																																			goto IL_032e;
																																		case 61:
																																			goto IL_033c;
																																		case 4:
																																		case 57:
																																			goto IL_0347;
																																		case 69:
																																			goto IL_035a;
																																		case 30:
																																		case 55:
																																			goto IL_0368;
																																		case 36:
																																		case 64:
																																			goto IL_0376;
																																		case 39:
																																			goto IL_0384;
																																		case 1:
																																		case 72:
																																			goto IL_0392;
																																		case 44:
																																			goto IL_03d2;
																																		case 8:
																																		case 73:
																																			goto IL_03eb;
																																		case 18:
																																		case 77:
																																			goto IL_0404;
																																		case 19:
																																			goto IL_0444;
																																		case 22:
																																			goto IL_0458;
																																		case 79:
																																			goto IL_046b;
																																		case 81:
																																			goto IL_047e;
																																		case 82:
																																			goto IL_0491;
																																		case 15:
																																		case 42:
																																			goto IL_049f;
																																		case 33:
																																		case 83:
																																			goto IL_04b2;
																																		case 28:
																																			goto IL_04c6;
																																		case 41:
																																		case 87:
																																			goto IL_051f;
																																		case 66:
																																			goto IL_055f;
																																		case 17:
																																			goto IL_0573;
																																		case 90:
																																			goto IL_0586;
																																		case 56:
																																		case 93:
																																			goto IL_0599;
																																		case 76:
																																		case 94:
																																			goto IL_05b5;
																																		case 96:
																																			goto IL_05e0;
																																		case 98:
																																			goto IL_05ee;
																																		case 99:
																																			goto IL_0601;
																																		case 102:
																																			goto IL_0614;
																																		case 29:
																																			goto IL_0622;
																																		case 14:
																																		case 104:
																																			goto IL_0635;
																																		case 11:
																																		case 112:
																																			goto IL_0677;
																																		case 6:
																																			goto IL_0685;
																																		case 32:
																																		case 107:
																																			goto IL_0693;
																																		case 110:
																																			goto IL_06a1;
																																		case 108:
																																			goto IL_06c4;
																																		case 71:
																																			goto IL_06ce;
																																		case 92:
																																			goto IL_06dc;
																																		case 117:
																																			goto IL_06ef;
																																		case 67:
																																			goto IL_0703;
																																		case 3:
																																		case 7:
																																		case 12:
																																		case 20:
																																		case 23:
																																		case 51:
																																		case 53:
																																		case 59:
																																		case 62:
																																		case 63:
																																		case 65:
																																		case 70:
																																		case 85:
																																		case 97:
																																		case 101:
																																		case 109:
																																		case 116:
																																			goto end_IL_0215;
																																		case 10:
																																			goto IL_0746;
																																		case 48:
																																			goto IL_0754;
																																		case 21:
																																			goto IL_076b;
																																		case 2:
																																		case 9:
																																		case 31:
																																		case 34:
																																		case 35:
																																		case 38:
																																		case 50:
																																		case 54:
																																		case 58:
																																		case 68:
																																		case 86:
																																		case 95:
																																		case 119:
																																			goto end_IL_02e6;
																																		case 75:
																																			goto end_IL_0779;
																																		case 91:
																																			goto end_IL_078c;
																																		case 25:
																																			goto end_IL_0796;
																																		case 26:
																																			goto end_IL_07aa;
																																		case 115:
																																			goto end_IL_07bf;
																																		case 60:
																																			goto end_IL_07d4;
																																		case 78:
																																			goto end_IL_07e4;
																																		case 13:
																																			goto end_IL_07f4;
																																		case 89:
																																		case 100:
																																			goto end_IL_07ff;
																																		case 113:
																																			goto end_IL_080f;
																																		case 114:
																																			goto end_IL_0828;
																																		case 106:
																																		case 118:
																																			goto IL_0843;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_02e6;
																																	continue;
																																	end_IL_0215:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_026c:;
																												}
																												break;
																											}
																											goto IL_0304;
																											IL_0444:
																											array[num5 - 2] = 0;
																											goto IL_0458;
																											IL_0304:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_0312;
																											IL_0312:
																											if (8 > b)
																											{
																												break;
																											}
																											num = 18;
																											goto IL_0404;
																											IL_0458:
																											num5--;
																											goto end_IL_02e6;
																											IL_0404:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0444;
																										}
																										break;
																									}
																									goto IL_04b2;
																									IL_05ee:
																									ptr2 += 8;
																									goto end_IL_02e6;
																									IL_04b2:
																									array[num5 - 2] = 0;
																									goto IL_04c6;
																									IL_04c6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)CLRSurrogateClassNameDelete[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																									goto IL_05e0;
																									IL_05e0:
																									num5--;
																									goto IL_05ee;
																								}
																								break;
																							}
																							goto IL_02f1;
																							IL_0491:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_049f;
																							IL_02f1:
																							if (10 < b)
																							{
																								goto IL_03eb;
																							}
																							goto IL_0491;
																							IL_03eb:
																							if (11 < b)
																							{
																								break;
																							}
																							num = 81;
																							goto IL_047e;
																							IL_049f:
																							num5--;
																							goto end_IL_02e6;
																							IL_047e:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_0599;
																							IL_0599:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_02e6;
																						}
																						break;
																					}
																					goto IL_032e;
																					IL_0573:
																					num5--;
																					goto end_IL_02e6;
																					IL_032e:
																					if (6 > b)
																					{
																						goto IL_033c;
																					}
																					goto IL_051f;
																					IL_033c:
																					if (3 < b)
																					{
																						goto IL_0347;
																					}
																					goto IL_035a;
																					IL_0347:
																					if (4 >= b)
																					{
																						goto IL_046b;
																					}
																					goto IL_0677;
																					IL_0677:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_0685;
																					IL_0685:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_0693;
																					IL_0693:
																					array[num5] = 0;
																					goto IL_06a1;
																					IL_06a1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_06c4;
																					IL_06c4:
																					array2[num5] = null;
																					goto IL_06ce;
																					IL_06ce:
																					num5++;
																					goto IL_06dc;
																					IL_06dc:
																					ptr2 += 8;
																					goto end_IL_02e6;
																					IL_046b:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0635;
																					IL_0635:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06ef;
																					IL_06ef:
																					array[num5 - 2] = 0;
																					goto IL_0703;
																					IL_0703:
																					num5--;
																					goto end_IL_02e6;
																					IL_035a:
																					if (3 > b)
																					{
																						goto IL_0368;
																					}
																					goto IL_05b5;
																					IL_0368:
																					if (1 < b)
																					{
																						goto IL_0376;
																					}
																					goto IL_0586;
																					IL_0376:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0384;
																					IL_0384:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0392;
																					IL_0392:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03d2;
																					IL_03d2:
																					array[num5 - 2] = 0;
																					goto IL_0601;
																					IL_0601:
																					num5--;
																					goto end_IL_02e6;
																					IL_0586:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_05b5:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0614;
																					IL_0614:
																					ptr2 += 8;
																					goto IL_0622;
																					IL_0622:
																					num5--;
																					goto end_IL_02e6;
																					IL_051f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_055f;
																					IL_055f:
																					array[num5 - 2] = 0;
																					goto IL_0573;
																				}
																				break;
																				IL_02b6:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0746;
																		IL_076b:
																		ptr2 += 8;
																		goto end_IL_02e6;
																		IL_0754:
																		num5++;
																		num = 21;
																		goto IL_076b;
																		IL_0746:
																		array[num5] = 0;
																		goto IL_0754;
																		continue;
																		end_IL_02c6:
																		break;
																	}
																	continue;
																	end_IL_02d6:
																	break;
																}
																continue;
																end_IL_02e6:
																break;
															}
															continue;
														}
														goto IL_0843;
														IL_0843:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0779:
														break;
													}
													continue;
													end_IL_078c:
													break;
												}
												continue;
												end_IL_0796:
												break;
											}
											continue;
											end_IL_07aa:
											break;
										}
										continue;
										end_IL_07bf:
										break;
									}
									continue;
									end_IL_07d4:
									break;
								}
								continue;
								end_IL_07e4:
								break;
							}
							continue;
							end_IL_07f4:
							break;
						}
						continue;
						end_IL_07ff:
						break;
					}
					continue;
					end_IL_080f:
					break;
				}
				continue;
				end_IL_0828:
				break;
			}
		}
	}

	static Class109()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 7;
					while (true)
					{
						num = 14;
						while (true)
						{
							if (num != 14)
							{
								if (num != 995)
								{
									break;
								}
								switch (num)
								{
								case 7:
									goto end_IL_0044;
								case 0:
								case 1:
								case 2:
								case 3:
								case 4:
									goto end_IL_0051;
								case 5:
									goto end_IL_005d;
								case 6:
									goto end_IL_0075;
								}
								continue;
							}
							return;
							continue;
							end_IL_0044:
							break;
						}
						continue;
						end_IL_0051:
						break;
					}
					continue;
					end_IL_005d:
					break;
				}
				continue;
				end_IL_0075:
				break;
			}
		}
	}
}
