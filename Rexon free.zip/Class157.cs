using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Spoof Rig Color [STUMP]", "Safety", "Sends random color to others so they see you in a fake color.", false, 11, ModType.const_0, false)]
internal class Class157 : MonoBehaviour
{
	internal struct SpoofData
	{
		public Player player_0;

		public string string_0;

		private static IntPtr[] MemberInfoSerializationHolderOpenExistingResult;

		internal static object object_0;

		public unsafe SpoofData(Player player, string userId)
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
			int num = 0;
			int num2 = 0;
			num2 = 0;
			int num3 = default(int);
			while (num2 != 2)
			{
				((delegate*<ref int, ref int, ref int, ref SpoofData, Player, string, void>)MemberInfoSerializationHolderOpenExistingResult[num])(ref num, ref num2, ref num3, ref this, player, userId);
			}
			num2 = 0;
		}

		static SpoofData()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				num = 9;
				while (true)
				{
					if (num != 9)
					{
						if (num == 990)
						{
							switch (num)
							{
							default:
								continue;
							case 1:
								break;
							case 0:
								return;
							case 2:
								return;
							}
							break;
						}
					}
					else
					{
						Class300.smethod_0();
					}
					return;
				}
			}
		}

		internal static bool smethod_0()
		{
			return object_0 == null;
		}

		internal static object smethod_1()
		{
			return object_0;
		}
	}

	private static List<SpoofData> list_0;

	private static int int_0;

	private static float float_0;

	private static float float_1;

	private static float float_2;

	private static int int_1;

	private static IntPtr[] GetExecutingAssemblyJson;

	private static IntPtr[] FlagsGetOrderablePartitions;

	private static IntPtr[] ppStringStringComparison;

	private static IntPtr[] NestedFamilyMuiResourceIdLookupMapEntryFieldId;

	private static IntPtr[] MetadataSectionDependentOSDataPartitioner;

	private void Update()
	{
		int num = 36;
		int num2 = 3;
		num = 12;
		num = 153;
		num2 = 3;
		num = 51;
		num = 12;
		num2 = 51;
		num = 63;
		num2 = 12;
		num2 = 0;
		num = 63;
		num = 63;
		num = 87;
		num2 = 3;
		num = 29;
		num = 759;
		num2 = 11;
		num = 69;
		num = 29;
		num2 = 69;
		num = 98;
		num2 = 29;
		num2 = 2001;
		num = 1971;
		num = 1971;
		num2 = 63;
		num = 2034;
		num = 1210;
		num2 = 11;
		num = 110;
		num2 = 1253;
		num2 = 179;
		object obj = "l";
		object obj2 = obj;
		obj = "C";
		object obj3 = obj;
		obj = "e";
		object obj4 = obj;
		obj = "z";
		object obj5 = obj;
		obj = "r";
		object obj6 = obj;
		obj = "N";
		object obj7 = obj;
		obj = "a";
		object obj8 = obj;
		obj = "t";
		object obj9 = obj;
		obj = "I";
		object obj10 = obj;
		obj = "i";
		object obj11 = obj;
		obj = "R";
		object obj12 = obj;
		obj = "o";
		object obj13 = obj;
		obj = "n";
		object obj14 = obj;
		obj = "b";
		object obj15 = obj;
		obj = "_";
		object obj16 = obj;
		obj = "M";
		object obj17 = obj;
		obj = "P";
		object obj18 = obj;
		num = 130;
		num2 = 5;
		num = 26;
		obj = new string[26];
		object obj19 = obj;
		object obj20 = obj12;
		((string[])obj19)[0] = (string)obj20;
		obj19 = obj;
		obj20 = obj18;
		((string[])obj19)[1] = (string)obj20;
		obj19 = obj;
		int num3 = 3;
		obj20 = obj3;
		((string[])obj19)[2] = (string)obj20;
		obj19 = obj;
		num3 = 7;
		obj20 = obj16;
		((string[])obj19)[3] = (string)obj20;
		obj19 = obj;
		num3 = 5;
		obj20 = obj10;
		((string[])obj19)[4] = (string)obj20;
		obj19 = obj;
		num3 = 5;
		obj20 = obj14;
		((string[])obj19)[5] = (string)obj20;
		obj19 = obj;
		num3 = 5;
		obj20 = obj11;
		((string[])obj19)[6] = (string)obj20;
		obj19 = obj;
		num3 = 13;
		obj20 = obj9;
		((string[])obj19)[7] = (string)obj20;
		obj19 = obj;
		num3 = 11;
		obj20 = obj11;
		((string[])obj19)[8] = (string)obj20;
		obj19 = obj;
		num3 = 2;
		obj20 = obj8;
		((string[])obj19)[9] = (string)obj20;
		obj19 = obj;
		num3 = 7;
		obj20 = obj2;
		((string[])obj19)[10] = (string)obj20;
		obj19 = obj;
		num3 = 5;
		obj20 = obj11;
		((string[])obj19)[11] = (string)obj20;
		obj19 = obj;
		num3 = 11;
		obj20 = obj5;
		((string[])obj19)[12] = (string)obj20;
		obj19 = obj;
		num3 = 2;
		obj20 = obj4;
		((string[])obj19)[13] = (string)obj20;
		obj19 = obj;
		num3 = 13;
		obj20 = obj7;
		((string[])obj19)[14] = (string)obj20;
		obj19 = obj;
		num3 = 7;
		obj20 = obj13;
		((string[])obj19)[15] = (string)obj20;
		obj19 = obj;
		num3 = 11;
		obj20 = obj13;
		((string[])obj19)[16] = (string)obj20;
		obj19 = obj;
		num3 = 4;
		obj20 = obj15;
		((string[])obj19)[17] = (string)obj20;
		obj19 = obj;
		num3 = 3;
		obj20 = obj17;
		((string[])obj19)[18] = (string)obj20;
		obj19 = obj;
		num3 = 4;
		obj20 = obj8;
		((string[])obj19)[19] = (string)obj20;
		obj19 = obj;
		num3 = 11;
		obj20 = obj9;
		((string[])obj19)[20] = (string)obj20;
		obj19 = obj;
		num3 = 5;
		obj20 = obj4;
		((string[])obj19)[21] = (string)obj20;
		obj19 = obj;
		num3 = 4;
		obj20 = obj6;
		((string[])obj19)[22] = (string)obj20;
		obj19 = obj;
		num3 = 2;
		obj20 = obj11;
		((string[])obj19)[23] = (string)obj20;
		obj19 = obj;
		num3 = 13;
		obj20 = obj8;
		((string[])obj19)[24] = (string)obj20;
		obj19 = obj;
		num3 = 7;
		obj20 = obj2;
		((string[])obj19)[25] = (string)obj20;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj21 = obj;
		if (PhotonNetwork.InRoom)
		{
			obj = list_0;
			int count = ((List<SpoofData>)obj).Count;
			num = count;
			num2 = 1;
			num--;
			global::_003CModule_003E.int_207 = num;
			while (true)
			{
				num = global::_003CModule_003E.int_207;
				num2 = 0;
				if (num < 0)
				{
					break;
				}
				obj = list_0;
				num2 = global::_003CModule_003E.int_207;
				SpoofData spoofData = ((List<SpoofData>)obj)[num2];
				obj = spoofData;
				global::_003CModule_003E.PD_TyJEpYI = (SpoofData)obj;
				obj = global::_003CModule_003E.PD_TyJEpYI;
				obj = ((SpoofData)obj).player_0;
				if (obj != null)
				{
					Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
					obj = playerListOthers;
					obj19 = global::_003CModule_003E.PD_TyJEpYI;
					obj19 = ((SpoofData)obj19).player_0;
					if (((Player[])obj).Contains((Player)obj19))
					{
						goto IL_0543;
					}
				}
				obj = list_0;
				num2 = global::_003CModule_003E.int_207;
				((List<SpoofData>)obj).RemoveAt(num2);
				goto IL_0543;
				IL_0543:
				num = global::_003CModule_003E.int_207;
				num2 = 1;
				num--;
				global::_003CModule_003E.int_207 = num;
			}
			Player[] playerListOthers2 = PhotonNetwork.PlayerListOthers;
			obj = playerListOthers2;
			global::_003CModule_003E.player_93 = (Player[])obj;
			num = 0;
			global::_003CModule_003E.int_208 = 0;
			while (true)
			{
				num = global::_003CModule_003E.int_208;
				obj19 = global::_003CModule_003E.player_93;
				IntPtr intPtr = (nint)((Player[])obj19).LongLength;
				num2 = (int)(nint)intPtr;
				if (num >= num2)
				{
					break;
				}
				obj = global::_003CModule_003E.player_93;
				num2 = global::_003CModule_003E.int_208;
				obj = ((Player[])obj)[num2];
				global::_003CModule_003E.player_94 = (Player)obj;
				num = 0;
				global::_003CModule_003E.bool_39 = false;
				num = 0;
				global::_003CModule_003E.iZ_002EQDRiXrM = 0;
				while (true)
				{
					num = global::_003CModule_003E.iZ_002EQDRiXrM;
					obj19 = list_0;
					int count2 = ((List<SpoofData>)obj19).Count;
					num2 = count2;
					if (num < num2)
					{
						obj = list_0;
						num2 = global::_003CModule_003E.iZ_002EQDRiXrM;
						SpoofData spoofData2 = ((List<SpoofData>)obj)[num2];
						obj = spoofData2;
						obj = ((SpoofData)obj).string_0;
						obj19 = global::_003CModule_003E.player_94;
						string userId = ((Player)obj19).UserId;
						obj19 = userId;
						if (!((string)obj == (string)obj19))
						{
							num = global::_003CModule_003E.iZ_002EQDRiXrM;
							num2 = 1;
							num++;
							global::_003CModule_003E.iZ_002EQDRiXrM = num;
							continue;
						}
						num = 1;
						global::_003CModule_003E.bool_39 = true;
						break;
					}
					break;
				}
				if (!global::_003CModule_003E.bool_39)
				{
					try
					{
						GorillaTagger instance = GorillaTagger.Instance;
						obj = instance;
						NetworkView myVRRig = ((GorillaTagger)obj).myVRRig;
						obj = myVRRig;
						PhotonView getView = ((NetworkView)obj).GetView;
						obj = getView;
						obj19 = obj21;
						object player_ = global::_003CModule_003E.player_94;
						double num4 = 1.0;
						double a = 1.5;
						double num5 = Math.Ceiling(a);
						a = num5;
						num4 += a;
						int num6 = Convert.ToInt32(num4);
						num3 = num6;
						obj20 = new object[num3];
						object obj22 = obj20;
						int num7 = 0;
						double num8 = 0.0;
						double num9 = 1.0;
						float num10 = UnityEngine.Random.Range((float)num8, (float)num9);
						num8 = num10;
						object obj23 = (float)num8;
						((object[])obj22)[0] = obj23;
						obj22 = obj20;
						num7 = 1;
						num8 = 0.0;
						num9 = 1.0;
						float num11 = UnityEngine.Random.Range((float)num8, (float)num9);
						num8 = num11;
						obj23 = (float)num8;
						((object[])obj22)[1] = obj23;
						obj22 = obj20;
						double num12 = 3.0;
						num8 = 1.0;
						double num13 = Math.Round(num8);
						num8 = num13;
						num12 -= num8;
						int num14 = Convert.ToInt32(num12);
						num7 = num14;
						num8 = 0.0;
						num9 = 1.0;
						float num15 = UnityEngine.Random.Range((float)num8, (float)num9);
						num8 = num15;
						obj23 = (float)num8;
						((object[])obj22)[num7] = obj23;
						num = (((PhotonView)obj).smethod_1((string)obj19, (Player)player_, (object[])obj20) ? 1 : 0);
						Class9.smethod_82();
						obj = list_0;
						obj19 = global::_003CModule_003E.player_94;
						player_ = global::_003CModule_003E.player_94;
						string userId2 = ((Player)player_).UserId;
						player_ = userId2;
						SpoofData spoofData3 = new SpoofData((Player)obj19, (string)player_);
						obj19 = spoofData3;
						((List<SpoofData>)obj).Add((SpoofData)obj19);
					}
					catch
					{
					}
				}
				num = global::_003CModule_003E.int_208;
				num2 = 1;
				num++;
				global::_003CModule_003E.int_208 = num;
			}
		}
		else
		{
			obj = this;
			((Class157)obj).method_0();
		}
	}

	private unsafe void method_0()
	{
		int num = 99;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AccountComputersSidSignatureID.getAsUnknownGetSharedStringMaker);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 164;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													num = 103;
													while (true)
													{
														ptr2++;
														num = 87;
														while (true)
														{
															IL_03c8:
															if (b >= 1)
															{
																while (b <= 22)
																{
																	while (true)
																	{
																		IL_03ab:
																		if (11 < b)
																		{
																			while (true)
																			{
																				IL_039b:
																				if (17 >= b)
																				{
																					while (true)
																					{
																						IL_038b:
																						if (17 > b)
																						{
																							while (true)
																							{
																								IL_037b:
																								if (14 >= b)
																								{
																									while (true)
																									{
																										IL_036b:
																										if (14 > b)
																										{
																											while (true)
																											{
																												IL_035b:
																												if (12 < b)
																												{
																													while (13 >= b)
																													{
																														while (13 <= b)
																														{
																															num = 194;
																															while (true)
																															{
																																if (num != 194)
																																{
																																	if (num != 1175)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 73:
																																		goto IL_0338;
																																	case 130:
																																		goto IL_034b;
																																	case 61:
																																		goto IL_035b;
																																	case 123:
																																		goto IL_036b;
																																	case 71:
																																		goto IL_037b;
																																	case 97:
																																		goto IL_038b;
																																	case 26:
																																		goto IL_039b;
																																	case 33:
																																		goto IL_03ab;
																																	case 93:
																																		goto IL_03b8;
																																	case 87:
																																		goto IL_03c8;
																																	case 103:
																																		goto end_IL_03c8;
																																	case 46:
																																	case 58:
																																		goto end_IL_03d8;
																																	case 2:
																																		goto IL_0405;
																																	case 88:
																																		goto IL_0413;
																																	case 28:
																																		goto IL_0421;
																																	case 94:
																																		goto IL_042f;
																																	case 12:
																																		goto IL_043d;
																																	case 39:
																																	case 104:
																																		goto IL_044d;
																																	case 31:
																																		goto IL_048e;
																																	case 106:
																																		goto IL_04a2;
																																	case 23:
																																	case 124:
																																		goto IL_04b5;
																																	case 89:
																																		goto IL_04f5;
																																	case 8:
																																		goto IL_0509;
																																	case 135:
																																		goto IL_051c;
																																	case 76:
																																		goto IL_052a;
																																	case 134:
																																		goto IL_0538;
																																	case 105:
																																		goto IL_0546;
																																	case 3:
																																	case 112:
																																		goto IL_0554;
																																	case 137:
																																		goto IL_0594;
																																	case 32:
																																		goto IL_05a8;
																																	case 138:
																																		goto IL_05bb;
																																	case 14:
																																	case 126:
																																		goto IL_05c9;
																																	case 50:
																																		goto IL_0609;
																																	case 24:
																																		goto IL_061d;
																																	case 64:
																																	case 142:
																																		goto IL_0630;
																																	case 90:
																																		goto IL_0659;
																																	case 30:
																																		goto IL_0667;
																																	case 152:
																																		goto IL_067a;
																																	case 49:
																																		goto IL_0688;
																																	case 25:
																																		goto IL_0693;
																																	case 114:
																																	case 141:
																																		goto IL_069e;
																																	case 43:
																																		goto IL_06e3;
																																	case 65:
																																		goto IL_06f1;
																																	case 78:
																																		goto IL_0701;
																																	case 83:
																																		goto IL_070c;
																																	case 45:
																																		goto IL_071c;
																																	case 7:
																																		goto IL_072a;
																																	case 84:
																																	case 153:
																																		goto IL_073d;
																																	case 116:
																																		goto IL_0756;
																																	case 4:
																																	case 157:
																																		goto IL_0769;
																																	case 11:
																																		goto IL_0792;
																																	case 70:
																																		goto IL_07a0;
																																	case 0:
																																	case 161:
																																		goto IL_07b3;
																																	case 113:
																																		goto IL_07f3;
																																	case 149:
																																		goto IL_0807;
																																	case 54:
																																	case 166:
																																		goto IL_081a;
																																	case 173:
																																		goto IL_082d;
																																	case 108:
																																	case 177:
																																		goto end_IL_0325;
																																	case 127:
																																		goto IL_084e;
																																	case 102:
																																		goto IL_0871;
																																	case 91:
																																		goto IL_087b;
																																	case 121:
																																		goto IL_0889;
																																	case 178:
																																		goto IL_089c;
																																	case 74:
																																		goto IL_08aa;
																																	case 179:
																																		goto IL_08bd;
																																	case 125:
																																		goto IL_08cb;
																																	case 55:
																																	case 69:
																																		goto IL_08d9;
																																	case 29:
																																		goto IL_093b;
																																	case 16:
																																	case 180:
																																		goto IL_094e;
																																	case 13:
																																		goto IL_0967;
																																	case 20:
																																		goto IL_0975;
																																	case 47:
																																		goto IL_0983;
																																	case 184:
																																		goto IL_0996;
																																	case 60:
																																		goto IL_09aa;
																																	case 85:
																																		goto IL_09bd;
																																	case 101:
																																		goto IL_09d5;
																																	case 92:
																																		goto IL_09e0;
																																	case 77:
																																		goto IL_09f7;
																																	case 37:
																																	case 96:
																																		goto IL_0a05;
																																	case 118:
																																		goto IL_0a23;
																																	case 183:
																																		goto IL_0a31;
																																	case 169:
																																		goto IL_0a48;
																																	case 187:
																																		goto IL_0a5b;
																																	case 40:
																																	case 109:
																																		goto IL_0a69;
																																	case 75:
																																		goto IL_0abb;
																																	case 139:
																																		goto IL_0ad7;
																																	case 66:
																																		goto IL_0ae5;
																																	case 27:
																																	case 156:
																																		goto IL_0af0;
																																	case 117:
																																		goto IL_0b04;
																																	case 110:
																																		goto IL_0b43;
																																	case 175:
																																		goto IL_0b56;
																																	case 42:
																																		goto IL_0b61;
																																	case 44:
																																	case 147:
																																		goto IL_0b6f;
																																	case 163:
																																		goto IL_0b88;
																																	case 144:
																																		goto IL_0b96;
																																	case 182:
																																		goto IL_0ba4;
																																	case 165:
																																		goto IL_0bb7;
																																	case 52:
																																		goto IL_0bc5;
																																	case 146:
																																	case 151:
																																		goto IL_0bdc;
																																	case 136:
																																		goto IL_0c1c;
																																	case 34:
																																		goto IL_0c30;
																																	case 122:
																																		goto IL_0c40;
																																	case 41:
																																		goto IL_0c4b;
																																	case 51:
																																		goto IL_0c56;
																																	case 185:
																																		goto IL_0c63;
																																	case 35:
																																	case 129:
																																		goto IL_0c6e;
																																	case 1:
																																	case 6:
																																	case 10:
																																	case 36:
																																	case 53:
																																	case 79:
																																	case 80:
																																	case 81:
																																	case 100:
																																	case 107:
																																	case 111:
																																	case 119:
																																	case 128:
																																	case 131:
																																	case 133:
																																	case 140:
																																	case 143:
																																	case 145:
																																	case 150:
																																	case 158:
																																	case 170:
																																	case 172:
																																	case 174:
																																	case 176:
																																	case 181:
																																		goto end_IL_0338;
																																	case 5:
																																	case 15:
																																	case 18:
																																	case 19:
																																	case 21:
																																	case 22:
																																	case 48:
																																	case 57:
																																	case 59:
																																	case 62:
																																	case 63:
																																	case 67:
																																	case 68:
																																	case 72:
																																	case 86:
																																	case 95:
																																	case 115:
																																	case 120:
																																	case 154:
																																	case 155:
																																	case 159:
																																	case 164:
																																	case 168:
																																	case 171:
																																	case 186:
																																		goto end_IL_03f1;
																																	case 162:
																																		goto end_IL_0c9a;
																																	case 56:
																																		goto end_IL_0cad;
																																	case 82:
																																		goto end_IL_0cc0;
																																	case 148:
																																	case 160:
																																		goto end_IL_0ccb;
																																	case 38:
																																		goto end_IL_0cdb;
																																	case 9:
																																		goto end_IL_0ceb;
																																	case 132:
																																		goto end_IL_0cfb;
																																	case 98:
																																		goto end_IL_0d0b;
																																	case 99:
																																		goto end_IL_0d1b;
																																	case 17:
																																	case 167:
																																		return;
																																	}
																																	continue;
																																}
																																goto IL_09bd;
																																IL_09bd:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																goto end_IL_03f1;
																																continue;
																																end_IL_0325:
																																break;
																															}
																															goto IL_0840;
																															continue;
																															end_IL_0338:
																															break;
																															IL_0338:;
																														}
																														break;
																														IL_034b:;
																													}
																													break;
																												}
																												goto IL_082d;
																												IL_0983:
																												ptr2 += 16;
																												goto end_IL_03f1;
																												IL_082d:
																												if (12 > b)
																												{
																													break;
																												}
																												goto IL_094e;
																												IL_094e:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																												goto IL_0967;
																												IL_0967:
																												array[num6] = 1;
																												goto IL_0975;
																												IL_0975:
																												num6++;
																												goto IL_0983;
																											}
																											break;
																										}
																										goto IL_044d;
																										IL_04a2:
																										num6--;
																										goto end_IL_03f1;
																										IL_044d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																										goto IL_048e;
																										IL_048e:
																										array[num6 - 2] = 0;
																										goto IL_04a2;
																									}
																									break;
																								}
																								goto IL_09d5;
																								IL_0a69:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0abb;
																								IL_09d5:
																								if (15 < b)
																								{
																									goto IL_09e0;
																								}
																								goto IL_0a5b;
																								IL_09e0:
																								if (16 < b)
																								{
																									break;
																								}
																								num = 77;
																								goto IL_09f7;
																								IL_0abb:
																								num6--;
																								num = 59;
																								goto end_IL_03f1;
																								IL_09f7:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_0a05;
																								IL_0a05:
																								array2[num6] = ((delegate*<List<SpoofData>>)GetExecutingAssemblyJson[*(int*)(ptr2 + num3)])();
																								goto IL_0a23;
																								IL_0a23:
																								array[num6] = 5;
																								goto IL_0a31;
																								IL_0a31:
																								num6++;
																								num = 169;
																								goto IL_0a48;
																								IL_0a48:
																								ptr2 += 8;
																								goto end_IL_03f1;
																								IL_0a5b:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0a69;
																							}
																							break;
																						}
																						goto IL_0630;
																						IL_0667:
																						ptr2 += 8;
																						goto end_IL_03f1;
																						IL_0630:
																						((delegate*<List<SpoofData>, void>)GetExecutingAssemblyJson[*(int*)(ptr2 + num3)])((List<SpoofData>)array2[num6 - 1]);
																						goto IL_0659;
																						IL_0659:
																						num6--;
																						goto IL_0667;
																					}
																					break;
																				}
																				goto IL_0ad7;
																				IL_0c63:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_0c6e;
																				IL_0ad7:
																				if (20 >= b)
																				{
																					goto IL_0ae5;
																				}
																				goto IL_0c40;
																				IL_0ae5:
																				if (20 <= b)
																				{
																					goto IL_0af0;
																				}
																				goto IL_0b56;
																				IL_0af0:
																				array[num6 - 1] = 0;
																				goto IL_0b04;
																				IL_0b04:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)GetExecutingAssemblyJson[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0b43;
																				IL_0b43:
																				ptr2 += 8;
																				goto end_IL_03f1;
																				IL_0b56:
																				if (18 >= b)
																				{
																					goto IL_0b61;
																				}
																				goto IL_0bb7;
																				IL_0b61:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_0b6f;
																				IL_0b6f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_0b88;
																				IL_0b88:
																				array[num6] = 3;
																				goto IL_0b96;
																				IL_0b96:
																				num6++;
																				goto IL_0ba4;
																				IL_0ba4:
																				ptr2 += 16;
																				goto end_IL_03f1;
																				IL_0bb7:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_0bc5;
																				IL_0bc5:
																				if (19 > b)
																				{
																					break;
																				}
																				num = 146;
																				goto IL_0bdc;
																				IL_0c6e:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_03f1;
																				IL_0bdc:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0c1c;
																				IL_0c1c:
																				array[num6 - 2] = 3;
																				goto IL_0c30;
																				IL_0c30:
																				num6--;
																				goto end_IL_03f1;
																				IL_0c40:
																				if (21 < b)
																				{
																					goto IL_0c4b;
																				}
																				goto IL_0c63;
																				IL_0c4b:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0c56;
																				IL_0c56:
																				if (22 > b)
																				{
																				}
																				break;
																			}
																			break;
																		}
																		goto IL_0405;
																		IL_0807:
																		num6--;
																		goto end_IL_03f1;
																		IL_0405:
																		if (11 <= b)
																		{
																			goto end_IL_03f1;
																		}
																		goto IL_0413;
																		IL_0413:
																		if (5 < b)
																		{
																			goto IL_0421;
																		}
																		goto IL_067a;
																		IL_0421:
																		if (8 < b)
																		{
																			goto IL_042f;
																		}
																		goto IL_051c;
																		IL_042f:
																		if (9 >= b)
																		{
																			goto IL_043d;
																		}
																		goto IL_08bd;
																		IL_043d:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_04b5;
																		IL_04b5:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_04f5;
																		IL_04f5:
																		array[num6 - 2] = 0;
																		goto IL_0509;
																		IL_0509:
																		num6--;
																		goto end_IL_03f1;
																		IL_08bd:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_08cb;
																		IL_08cb:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_08d9;
																		IL_08d9:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_093b;
																		IL_093b:
																		num6 -= 2;
																		goto end_IL_03f1;
																		IL_051c:
																		if (8 > b)
																		{
																			goto IL_052a;
																		}
																		goto IL_081a;
																		IL_052a:
																		if (6 < b)
																		{
																			goto IL_0538;
																		}
																		goto IL_05bb;
																		IL_0538:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_0546;
																		IL_0546:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0554;
																		IL_0554:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0594;
																		IL_0594:
																		array[num6 - 2] = 0;
																		goto IL_05a8;
																		IL_05a8:
																		num6--;
																		goto end_IL_03f1;
																		IL_05bb:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_05c9;
																		IL_05c9:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0609;
																		IL_0609:
																		array[num6 - 2] = 0;
																		goto IL_061d;
																		IL_061d:
																		num6--;
																		goto end_IL_03f1;
																		IL_081a:
																		num6--;
																		goto end_IL_03f1;
																		IL_067a:
																		if (5 > b)
																		{
																			goto IL_0688;
																		}
																		goto IL_07b3;
																		IL_0688:
																		if (2 >= b)
																		{
																			goto IL_0693;
																		}
																		goto IL_0701;
																		IL_0693:
																		if (2 <= b)
																		{
																			goto IL_069e;
																		}
																		goto IL_06e3;
																		IL_069e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0996;
																		IL_0996:
																		array[num6 - 2] = 0;
																		goto IL_09aa;
																		IL_09aa:
																		num6--;
																		goto end_IL_03f1;
																		IL_06e3:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_06f1;
																		IL_06f1:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_073d;
																		IL_073d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0756;
																		IL_0756:
																		array[num6] = 0;
																		goto IL_089c;
																		IL_089c:
																		num6++;
																		goto IL_08aa;
																		IL_08aa:
																		ptr2 += 8;
																		goto end_IL_03f1;
																		IL_0701:
																		if (3 >= b)
																		{
																			goto IL_070c;
																		}
																		goto IL_071c;
																		IL_070c:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0769;
																		IL_0769:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0792;
																		IL_0792:
																		ptr2 += 8;
																		goto IL_07a0;
																		IL_07a0:
																		num6--;
																		goto end_IL_03f1;
																		IL_071c:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_072a;
																		IL_072a:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_0840;
																		IL_0840:
																		array[num6] = 0;
																		goto IL_084e;
																		IL_084e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0871;
																		IL_0871:
																		array2[num6] = null;
																		goto IL_087b;
																		IL_087b:
																		num6++;
																		goto IL_0889;
																		IL_0889:
																		ptr2 += 8;
																		goto end_IL_03f1;
																		IL_07b3:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_07f3;
																		IL_07f3:
																		array[num6 - 2] = 0;
																		goto IL_0807;
																	}
																	break;
																	IL_03b8:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_03f1;
															continue;
															end_IL_03c8:
															break;
														}
														continue;
														end_IL_03d8:
														break;
													}
													continue;
													end_IL_03f1:
													break;
												}
												continue;
												end_IL_0c9a:
												break;
											}
											continue;
											end_IL_0cad:
											break;
										}
										continue;
										end_IL_0cc0:
										break;
									}
									continue;
									end_IL_0ccb:
									break;
								}
								continue;
								end_IL_0cdb:
								break;
							}
							continue;
							end_IL_0ceb:
							break;
						}
						continue;
						end_IL_0cfb:
						break;
					}
					continue;
					end_IL_0d0b:
					break;
				}
				continue;
				end_IL_0d1b:
				break;
			}
		}
	}

	private void OnDisable()
	{
		ExpandPrimeGenericArraySortHelper(this);
	}

	private unsafe void method_1()
	{
		int num = 158;
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 139;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												array5[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsNestedPublicEventWaitHandleRights.IsObjectOutOfContextMAJORVERSION);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																num = 204;
																while (true)
																{
																	if (num != 204)
																	{
																		if (num != 1185)
																		{
																			goto IL_0754;
																		}
																		switch (num)
																		{
																		case 179:
																			goto end_IL_033f;
																		case 195:
																			goto IL_0363;
																		case 113:
																			goto IL_0371;
																		case 155:
																			goto IL_037f;
																		case 48:
																			goto IL_038d;
																		case 3:
																			goto IL_039b;
																		case 5:
																			goto IL_03a9;
																		case 72:
																			goto IL_03b7;
																		case 16:
																			goto IL_03c5;
																		case 89:
																		case 151:
																			goto IL_03d0;
																		case 7:
																			goto IL_0410;
																		case 10:
																			goto IL_0424;
																		case 161:
																			goto IL_0437;
																		case 180:
																			goto IL_0442;
																		case 0:
																		case 42:
																			goto IL_0450;
																		case 22:
																			goto IL_0490;
																		case 140:
																			goto IL_04a4;
																		case 150:
																			goto IL_04b7;
																		case 91:
																			goto IL_04c5;
																		case 45:
																		case 70:
																			goto IL_04dc;
																		case 123:
																			goto IL_04ef;
																		case 109:
																			goto IL_04fa;
																		case 35:
																			goto IL_0508;
																		case 101:
																			goto IL_0524;
																		case 138:
																		case 173:
																			goto IL_0532;
																		case 73:
																			goto IL_0594;
																		case 114:
																			goto IL_05a7;
																		case 65:
																		case 96:
																			goto IL_05b2;
																		case 80:
																			goto IL_05f2;
																		case 159:
																			goto IL_0606;
																		case 129:
																			goto IL_0619;
																		case 136:
																			goto IL_0627;
																		case 17:
																		case 24:
																			goto IL_0632;
																		case 84:
																			goto IL_065b;
																		case 185:
																			goto IL_0669;
																		case 37:
																			goto IL_067c;
																		case 102:
																			goto IL_068a;
																		case 130:
																			goto IL_0698;
																		case 103:
																		case 194:
																			goto IL_06a6;
																		case 166:
																			goto IL_06e6;
																		case 154:
																			goto IL_06fa;
																		case 76:
																			goto IL_071f;
																		case 77:
																		case 94:
																			goto IL_072d;
																		case 111:
																			goto IL_0746;
																		case 85:
																			goto IL_0754;
																		case 78:
																			goto IL_0762;
																		case 69:
																			goto IL_0775;
																		case 104:
																			goto IL_0783;
																		case 144:
																			goto IL_0791;
																		case 4:
																		case 107:
																			goto IL_079f;
																		case 187:
																			goto IL_07df;
																		case 120:
																			goto IL_07f3;
																		case 152:
																			goto IL_080f;
																		case 31:
																		case 131:
																			goto IL_081d;
																		case 171:
																			goto IL_082b;
																		case 14:
																			goto IL_084e;
																		case 41:
																			goto IL_0858;
																		case 18:
																			goto IL_0866;
																		case 57:
																		case 143:
																			goto IL_0879;
																		case 156:
																			goto IL_0892;
																		case 87:
																			goto IL_08a0;
																		case 38:
																			goto IL_08ae;
																		case 125:
																			goto IL_08c1;
																		case 122:
																			goto IL_08cf;
																		case 112:
																			goto IL_08dd;
																		case 100:
																			goto IL_08eb;
																		case 66:
																			goto IL_08f6;
																		case 33:
																		case 164:
																			goto IL_0904;
																		case 108:
																			goto IL_0918;
																		case 119:
																			goto IL_0957;
																		case 170:
																			goto IL_096a;
																		case 52:
																			goto IL_0978;
																		case 6:
																		case 181:
																			goto IL_0986;
																		case 191:
																			goto IL_09c6;
																		case 184:
																			goto IL_09da;
																		case 43:
																		case 116:
																			goto IL_09f6;
																		case 44:
																			goto IL_0a0a;
																		case 67:
																			goto IL_0a49;
																		case 61:
																			goto IL_0a5c;
																		case 63:
																			goto IL_0a67;
																		case 110:
																		case 128:
																			goto IL_0a75;
																		case 46:
																			goto IL_0a91;
																		case 95:
																			goto IL_0a9f;
																		case 81:
																			goto IL_0ab2;
																		case 29:
																			goto IL_0ac0;
																		case 115:
																			goto IL_0ace;
																		case 21:
																		case 97:
																			goto IL_0ad9;
																		case 49:
																			goto IL_0b2b;
																		case 183:
																			goto IL_0b47;
																		case 148:
																			goto IL_0b55;
																		case 90:
																			goto IL_0b63;
																		case 169:
																		case 176:
																			goto IL_0b71;
																		case 1:
																			goto IL_0bb2;
																		case 167:
																			goto IL_0bc6;
																		case 86:
																			goto IL_0beb;
																		case 39:
																		case 64:
																			goto IL_0bf9;
																		case 145:
																			goto IL_0c11;
																		case 54:
																			goto IL_0c1c;
																		case 2:
																		case 11:
																			goto IL_0c2a;
																		case 15:
																			goto IL_0c42;
																		case 27:
																			goto IL_0c50;
																		case 141:
																			goto IL_0c5e;
																		case 192:
																			goto IL_0c71;
																		case 146:
																			goto IL_0c7f;
																		case 117:
																		case 124:
																			goto IL_0c8d;
																		case 190:
																			goto IL_0cb6;
																		case 40:
																			goto IL_0cc4;
																		case 47:
																		case 132:
																			goto IL_0cd4;
																		case 50:
																			goto IL_0ced;
																		case 36:
																			goto IL_0cfb;
																		case 153:
																			goto IL_0d09;
																		case 25:
																		case 32:
																		case 34:
																		case 51:
																		case 58:
																		case 59:
																		case 60:
																		case 74:
																		case 79:
																		case 83:
																		case 93:
																		case 98:
																		case 99:
																		case 105:
																		case 118:
																		case 121:
																		case 127:
																		case 135:
																		case 147:
																		case 162:
																		case 168:
																		case 174:
																		case 175:
																		case 177:
																		case 182:
																		case 193:
																			goto IL_0d19;
																		case 9:
																		case 12:
																		case 13:
																		case 19:
																		case 20:
																		case 23:
																		case 26:
																		case 28:
																		case 53:
																		case 55:
																		case 56:
																		case 62:
																		case 71:
																		case 75:
																		case 92:
																		case 126:
																		case 134:
																		case 137:
																		case 142:
																		case 160:
																		case 165:
																		case 172:
																		case 178:
																		case 186:
																		case 189:
																		case 197:
																			goto end_IL_034f;
																		case 68:
																			goto end_IL_0d2c;
																		case 196:
																			goto end_IL_0d3f;
																		case 8:
																			goto end_IL_0d49;
																		case 163:
																			goto end_IL_0d54;
																		case 133:
																			goto end_IL_0d64;
																		case 139:
																			goto end_IL_0d74;
																		case 188:
																			goto end_IL_0d84;
																		case 106:
																			goto end_IL_0d94;
																		case 88:
																			goto end_IL_0d9f;
																		case 30:
																			goto end_IL_0daf;
																		case 157:
																			goto end_IL_0dbf;
																		case 158:
																			goto end_IL_0dcf;
																		case 82:
																		case 149:
																			return;
																		}
																		continue;
																	}
																	b = *ptr2;
																	goto IL_0363;
																	IL_0c7f:
																	if (17 <= b)
																	{
																		goto IL_0c8d;
																	}
																	goto IL_0d19;
																	IL_0cb6:
																	num6--;
																	goto IL_0cc4;
																	IL_0c8d:
																	((delegate*<Class157, void>)FlagsGetOrderablePartitions[*(int*)(ptr2 + num3)])((Class157)array2[num6 - 1]);
																	goto IL_0cb6;
																	IL_0363:
																	ptr2++;
																	goto IL_0371;
																	IL_0371:
																	if (b >= 1)
																	{
																		goto IL_037f;
																	}
																	goto IL_0d19;
																	IL_037f:
																	if (b <= 23)
																	{
																		goto IL_038d;
																	}
																	goto IL_0d19;
																	IL_038d:
																	if (12 >= b)
																	{
																		goto IL_039b;
																	}
																	goto IL_08c1;
																	IL_039b:
																	if (12 > b)
																	{
																		goto IL_03a9;
																	}
																	goto IL_0879;
																	IL_03a9:
																	if (6 < b)
																	{
																		goto IL_03b7;
																	}
																	goto IL_05a7;
																	IL_03b7:
																	if (9 >= b)
																	{
																		goto IL_03c5;
																	}
																	goto IL_04ef;
																	IL_03c5:
																	if (9 <= b)
																	{
																		goto IL_03d0;
																	}
																	goto IL_0437;
																	IL_03d0:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0410;
																	IL_0410:
																	array[num6 - 2] = 0;
																	goto IL_0424;
																	IL_0424:
																	num6--;
																	goto end_IL_034f;
																	IL_0437:
																	if (7 >= b)
																	{
																		goto IL_0442;
																	}
																	goto IL_04b7;
																	IL_0442:
																	if (7 <= b)
																	{
																		goto IL_0450;
																	}
																	goto IL_0d19;
																	IL_0450:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0490;
																	IL_0490:
																	array[num6 - 2] = 0;
																	goto IL_04a4;
																	IL_04a4:
																	num6--;
																	goto end_IL_034f;
																	IL_04b7:
																	if (8 >= b)
																	{
																		goto IL_04c5;
																	}
																	goto IL_0d19;
																	IL_04c5:
																	if (8 <= b)
																	{
																		num = 45;
																		goto IL_04dc;
																	}
																	goto IL_0d19;
																	IL_0cc4:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_04dc:
																	num6--;
																	goto end_IL_034f;
																	IL_04ef:
																	if (10 < b)
																	{
																		goto IL_04fa;
																	}
																	goto IL_0524;
																	IL_04fa:
																	if (11 >= b)
																	{
																		goto IL_0508;
																	}
																	goto IL_0d19;
																	IL_0508:
																	if (11 <= b)
																	{
																		num = 126;
																		goto end_IL_034f;
																	}
																	goto IL_0d19;
																	IL_0cd4:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																	goto IL_0ced;
																	IL_0524:
																	if (10 <= b)
																	{
																		goto IL_0532;
																	}
																	goto IL_0d19;
																	IL_0532:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0594;
																	IL_0594:
																	num6 -= 2;
																	goto end_IL_034f;
																	IL_05a7:
																	if (6 <= b)
																	{
																		goto IL_05b2;
																	}
																	goto IL_0619;
																	IL_05b2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_05f2;
																	IL_05f2:
																	array[num6 - 2] = 0;
																	goto IL_0606;
																	IL_0606:
																	num6--;
																	goto end_IL_034f;
																	IL_0619:
																	if (3 >= b)
																	{
																		goto IL_0627;
																	}
																	goto IL_0775;
																	IL_0627:
																	if (3 <= b)
																	{
																		goto IL_0632;
																	}
																	goto IL_067c;
																	IL_0632:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_065b;
																	IL_065b:
																	ptr2 += 8;
																	goto IL_0669;
																	IL_0669:
																	num6--;
																	goto end_IL_034f;
																	IL_067c:
																	if (1 < b)
																	{
																		goto IL_068a;
																	}
																	num = 76;
																	goto IL_071f;
																	IL_068a:
																	if (2 >= b)
																	{
																		goto IL_0698;
																	}
																	goto IL_0d19;
																	IL_0698:
																	if (2 <= b)
																	{
																		goto IL_06a6;
																	}
																	goto IL_0d19;
																	IL_06a6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_06e6;
																	IL_06e6:
																	array[num6 - 2] = 0;
																	goto IL_06fa;
																	IL_06fa:
																	num6--;
																	num = 165;
																	goto end_IL_034f;
																	IL_0ced:
																	array[num6] = 3;
																	goto IL_0cfb;
																	IL_071f:
																	if (1 <= b)
																	{
																		goto IL_072d;
																	}
																	goto IL_0d19;
																	IL_072d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0746;
																	IL_0746:
																	array[num6] = 0;
																	goto IL_0754;
																	IL_0754:
																	num6++;
																	goto IL_0762;
																	IL_0762:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_0775:
																	if (4 < b)
																	{
																		goto IL_0783;
																	}
																	num = 152;
																	goto IL_080f;
																	IL_0783:
																	if (5 >= b)
																	{
																		goto IL_0791;
																	}
																	goto IL_0d19;
																	IL_0791:
																	if (5 <= b)
																	{
																		goto IL_079f;
																	}
																	goto IL_0d19;
																	IL_079f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_07df;
																	IL_07df:
																	array[num6 - 2] = 0;
																	goto IL_07f3;
																	IL_07f3:
																	num6--;
																	goto end_IL_034f;
																	IL_0cfb:
																	num6++;
																	goto IL_0d09;
																	IL_080f:
																	if (4 <= b)
																	{
																		goto IL_081d;
																	}
																	goto IL_0d19;
																	IL_081d:
																	array[num6] = 0;
																	goto IL_082b;
																	IL_082b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_084e;
																	IL_084e:
																	array2[num6] = null;
																	goto IL_0858;
																	IL_0858:
																	num6++;
																	goto IL_0866;
																	IL_0866:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_0879:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0892;
																	IL_0892:
																	array[num6] = 1;
																	goto IL_08a0;
																	IL_08a0:
																	num6++;
																	goto IL_08ae;
																	IL_08ae:
																	ptr2 += 16;
																	goto end_IL_034f;
																	IL_08c1:
																	if (18 < b)
																	{
																		goto IL_08cf;
																	}
																	goto IL_0ab2;
																	IL_08cf:
																	if (21 >= b)
																	{
																		goto IL_08dd;
																	}
																	goto IL_0a5c;
																	IL_08dd:
																	if (21 > b)
																	{
																		goto IL_08eb;
																	}
																	num = 43;
																	goto IL_09f6;
																	IL_08eb:
																	if (19 >= b)
																	{
																		goto IL_08f6;
																	}
																	goto IL_096a;
																	IL_08f6:
																	if (19 <= b)
																	{
																		goto IL_0904;
																	}
																	goto IL_0d19;
																	IL_0904:
																	array[num6 - 1] = 3;
																	goto IL_0918;
																	IL_0918:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)FlagsGetOrderablePartitions[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_0957;
																	IL_0957:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_096a:
																	if (20 >= b)
																	{
																		goto IL_0978;
																	}
																	goto IL_0d19;
																	IL_0978:
																	if (20 <= b)
																	{
																		goto IL_0986;
																	}
																	goto IL_0d19;
																	IL_0986:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_09c6;
																	IL_09c6:
																	array[num6 - 2] = 3;
																	goto IL_09da;
																	IL_09da:
																	num6--;
																	goto end_IL_034f;
																	IL_0d09:
																	ptr2 += 16;
																	goto end_IL_034f;
																	IL_09f6:
																	array[num6 - 1] = 0;
																	goto IL_0a0a;
																	IL_0a0a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)FlagsGetOrderablePartitions[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_0a49;
																	IL_0a49:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_0a5c:
																	if (22 >= b)
																	{
																		goto IL_0a67;
																	}
																	goto IL_0a91;
																	IL_0a67:
																	if (22 <= b)
																	{
																		goto IL_0a75;
																	}
																	goto IL_0d19;
																	IL_0a75:
																	byte* num7 = ptr2;
																	num5 = 1;
																	ptr2 = num7 + -200;
																	goto end_IL_034f;
																	IL_0a91:
																	if (23 >= b)
																	{
																		goto IL_0a9f;
																	}
																	goto IL_0d19;
																	IL_0a9f:
																	if (23 <= b)
																	{
																	}
																	goto IL_0d19;
																	IL_0ab2:
																	if (18 > b)
																	{
																		goto IL_0ac0;
																	}
																	goto IL_0cd4;
																	IL_0ac0:
																	if (15 >= b)
																	{
																		goto IL_0ace;
																	}
																	goto IL_0c11;
																	IL_0ace:
																	if (15 <= b)
																	{
																		goto IL_0ad9;
																	}
																	goto IL_0b47;
																	IL_0ad9:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0b2b;
																	IL_0b2b:
																	num6--;
																	num = 20;
																	goto end_IL_034f;
																	IL_0b47:
																	if (13 < b)
																	{
																		goto IL_0b55;
																	}
																	num = 86;
																	goto IL_0beb;
																	IL_0b55:
																	if (14 >= b)
																	{
																		goto IL_0b63;
																	}
																	goto IL_0d19;
																	IL_0b63:
																	if (14 <= b)
																	{
																		goto IL_0b71;
																	}
																	goto IL_0d19;
																	IL_0b71:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																	goto IL_0bb2;
																	IL_0bb2:
																	array[num6 - 2] = 0;
																	goto IL_0bc6;
																	IL_0bc6:
																	num6--;
																	num = 172;
																	goto end_IL_034f;
																	IL_0d19:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_034f;
																	IL_0beb:
																	if (13 <= b)
																	{
																		goto IL_0bf9;
																	}
																	goto IL_0d19;
																	IL_0bf9:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_034f;
																	IL_0c11:
																	if (16 >= b)
																	{
																		goto IL_0c1c;
																	}
																	goto IL_0c71;
																	IL_0c1c:
																	if (16 <= b)
																	{
																		goto IL_0c2a;
																	}
																	goto IL_0d19;
																	IL_0c2a:
																	array2[num6] = array5[*(int*)(ptr2 + num3)];
																	goto IL_0c42;
																	IL_0c42:
																	array[num6] = 5;
																	goto IL_0c50;
																	IL_0c50:
																	num6++;
																	goto IL_0c5e;
																	IL_0c5e:
																	ptr2 += 8;
																	goto end_IL_034f;
																	IL_0c71:
																	if (17 >= b)
																	{
																		goto IL_0c7f;
																	}
																	goto IL_0d19;
																	continue;
																	end_IL_033f:
																	break;
																}
																continue;
																end_IL_034f:
																break;
															}
															continue;
															end_IL_0d2c:
															break;
														}
														continue;
														end_IL_0d3f:
														break;
													}
													continue;
													end_IL_0d49:
													break;
												}
												continue;
												end_IL_0d54:
												break;
											}
											continue;
											end_IL_0d64:
											break;
										}
										continue;
										end_IL_0d74:
										break;
									}
									continue;
									end_IL_0d84:
									break;
								}
								continue;
								end_IL_0d94:
								break;
							}
							continue;
							end_IL_0d9f:
							break;
						}
						continue;
						end_IL_0daf:
						break;
					}
					continue;
					end_IL_0dbf:
					break;
				}
				continue;
				end_IL_0dcf:
				break;
			}
		}
	}

	public Class157()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class157()
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					while (true)
					{
						IL_047c:
						int num3 = num2 * 4;
						while (true)
						{
							IL_046c:
							byte[] array = new byte[1];
							while (true)
							{
								IL_045c:
								object[] array2 = new object[1];
								while (true)
								{
									IL_0451:
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref cImplTypesAM.encodingCompressedStack);
									while (true)
									{
										IL_0447:
										byte* ptr2 = ptr;
										while (true)
										{
											IL_0437:
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												IL_01e8:
												byte b = *ptr2;
												while (true)
												{
													IL_01d8:
													ptr2++;
													while (true)
													{
														IL_01c8:
														if (b >= 1)
														{
															while (b <= 8)
															{
																while (true)
																{
																	IL_01a8:
																	if (4 >= b)
																	{
																		num = 94;
																		while (true)
																		{
																			if (num != 94)
																			{
																				if (num != 1075)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 70:
																					goto IL_01a8;
																				case 41:
																					goto IL_01b8;
																				case 18:
																					goto IL_01c8;
																				case 2:
																					goto IL_01d8;
																				case 5:
																				case 66:
																					goto IL_01e8;
																				case 64:
																					goto IL_01f3;
																				case 0:
																					goto IL_0201;
																				case 6:
																				case 23:
																					goto IL_020c;
																				case 10:
																					goto IL_021a;
																				case 43:
																					goto IL_0238;
																				case 28:
																					goto IL_0246;
																				case 26:
																					goto IL_0259;
																				case 51:
																					goto IL_0267;
																				case 37:
																				case 67:
																					goto IL_0283;
																				case 46:
																					goto IL_028e;
																				case 63:
																					goto IL_029e;
																				case 49:
																					goto IL_02ac;
																				case 13:
																				case 79:
																					goto IL_02c3;
																				case 59:
																				case 80:
																					goto IL_02e8;
																				case 48:
																					goto IL_0301;
																				case 54:
																				case 86:
																					goto IL_0314;
																				case 73:
																					goto IL_0329;
																				case 78:
																					goto IL_034a;
																				case 81:
																					goto IL_0355;
																				case 45:
																				case 53:
																					goto IL_0360;
																				case 55:
																					goto IL_0375;
																				case 33:
																				case 76:
																					goto IL_0388;
																				case 29:
																					goto IL_0393;
																				case 20:
																					goto IL_03ab;
																				case 9:
																					goto IL_03b6;
																				case 16:
																				case 44:
																					goto IL_03c1;
																				case 39:
																					goto IL_03d6;
																				case 3:
																				case 68:
																					goto IL_03e6;
																				case 24:
																					goto IL_0404;
																				case 4:
																				case 11:
																				case 14:
																				case 17:
																				case 19:
																				case 22:
																				case 25:
																				case 30:
																				case 34:
																				case 36:
																				case 42:
																				case 58:
																				case 61:
																				case 71:
																				case 84:
																				case 85:
																					goto end_IL_01b8;
																				case 15:
																					goto IL_0429;
																				case 12:
																				case 21:
																				case 27:
																				case 31:
																				case 32:
																				case 38:
																				case 57:
																				case 72:
																				case 77:
																				case 87:
																					goto IL_0437;
																				case 65:
																					goto IL_0447;
																				case 60:
																				case 62:
																				case 83:
																					goto IL_0451;
																				case 47:
																					goto IL_045c;
																				case 52:
																				case 69:
																					goto IL_046c;
																				case 82:
																					goto IL_047c;
																				case 1:
																				case 7:
																				case 8:
																				case 35:
																				case 56:
																					goto end_IL_0195;
																				case 74:
																					goto end_IL_048c;
																				case 75:
																					goto end_IL_04a3;
																				case 40:
																				case 50:
																					return;
																				}
																				continue;
																			}
																			if (4 > b)
																			{
																				goto IL_034a;
																			}
																			goto IL_03e6;
																			IL_03c1:
																			((delegate*<void>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
																			goto IL_03d6;
																			IL_03e6:
																			((delegate*<void>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
																			num = 24;
																			goto IL_0404;
																			IL_03d6:
																			ptr2 += 8;
																			goto IL_0437;
																			IL_034a:
																			if (2 >= b)
																			{
																				goto IL_0355;
																			}
																			goto IL_03ab;
																			IL_0355:
																			if (2 <= b)
																			{
																				goto IL_0360;
																			}
																			goto IL_0388;
																			IL_0360:
																			((delegate*<void>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
																			goto IL_0375;
																			IL_0375:
																			ptr2 += 8;
																			goto IL_0437;
																			IL_0388:
																			if (1 < b)
																			{
																				num = 14;
																				goto end_IL_01b8;
																			}
																			goto IL_0393;
																			IL_0393:
																			if (1 > b)
																			{
																			}
																			goto end_IL_01b8;
																			IL_0404:
																			ptr2 += 8;
																			goto IL_0437;
																			IL_03ab:
																			if (3 < b)
																			{
																				goto end_IL_01b8;
																			}
																			goto IL_03b6;
																			IL_03b6:
																			if (3 > b)
																			{
																				goto end_IL_01b8;
																			}
																			goto IL_03c1;
																			continue;
																			end_IL_0195:
																			break;
																		}
																		break;
																	}
																	goto IL_01f3;
																	IL_029e:
																	if (8 < b)
																	{
																		goto end_IL_01b8;
																	}
																	goto IL_02ac;
																	IL_02ac:
																	if (8 > b)
																	{
																		goto end_IL_01b8;
																	}
																	num = 79;
																	goto IL_02c3;
																	IL_01f3:
																	if (6 >= b)
																	{
																		goto IL_0201;
																	}
																	goto IL_0283;
																	IL_0201:
																	if (6 <= b)
																	{
																		goto IL_020c;
																	}
																	goto IL_0259;
																	IL_020c:
																	array[num5] = 5;
																	goto IL_021a;
																	IL_021a:
																	array2[num5] = ((delegate*<List<SpoofData>>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
																	goto IL_0238;
																	IL_0238:
																	num5++;
																	goto IL_0246;
																	IL_0246:
																	ptr2 += 8;
																	goto IL_0437;
																	IL_0259:
																	if (5 < b)
																	{
																		goto end_IL_01b8;
																	}
																	goto IL_0267;
																	IL_0267:
																	if (5 > b)
																	{
																		num = 22;
																		goto end_IL_01b8;
																	}
																	goto IL_0314;
																	IL_02c3:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	num = 32;
																	goto IL_0437;
																	IL_0314:
																	((delegate*<void>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
																	goto IL_0329;
																	IL_0329:
																	ptr2 += 8;
																	goto IL_0437;
																	IL_0283:
																	if (7 >= b)
																	{
																		goto IL_028e;
																	}
																	goto IL_029e;
																	IL_028e:
																	if (7 > b)
																	{
																		goto end_IL_01b8;
																	}
																	goto IL_02e8;
																	IL_02e8:
																	list_0 = (List<SpoofData>)array2[num5 - 1];
																	goto IL_0301;
																	IL_0301:
																	num5--;
																	goto IL_0437;
																}
																goto end_IL_01c8;
																continue;
																end_IL_01b8:
																break;
																IL_01b8:;
															}
														}
														((delegate*<void>)ppStringStringComparison[*(int*)(ptr2 + num3)])();
														goto IL_0429;
														IL_0429:
														ptr2 += 8;
														goto IL_0437;
														continue;
														end_IL_01c8:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_048c:
					break;
				}
				continue;
				end_IL_04a3:
				break;
			}
		}
	}

	private static int smethod_0(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num6;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 188;
		num6 = 4;
		num4 = 47;
		num6 = 110;
		num6 = 22;
		int num7 = smethod_1(47, 22);
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContinuationTaskDynamicPartitionerForIEnumerable.SizegetChars);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 39;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0236:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_0216:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_0209:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_01f9:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											num = 8;
																											while (true)
																											{
																												IL_01d6:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_01b1:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_019c:
																														array2[num5] = null;
																														num = 91;
																														while (true)
																														{
																															if (num != 91)
																															{
																																if (num != 1072)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 72:
																																	goto IL_019c;
																																case 62:
																																	goto IL_01b1;
																																case 8:
																																case 61:
																																	goto IL_01d6;
																																case 25:
																																	goto IL_01e6;
																																case 10:
																																	goto IL_01f9;
																																case 33:
																																	goto IL_0209;
																																case 54:
																																	goto IL_0216;
																																case 67:
																																	goto IL_0226;
																																case 40:
																																	goto IL_0236;
																																case 79:
																																	goto end_IL_0236;
																																case 39:
																																	goto end_IL_0246;
																																case 82:
																																	goto end_IL_0256;
																																case 23:
																																	goto IL_026c;
																																case 19:
																																	goto IL_027a;
																																case 28:
																																	goto IL_0288;
																																case 11:
																																case 24:
																																	goto IL_0296;
																																case 41:
																																	goto IL_02ae;
																																case 26:
																																case 44:
																																	goto IL_02bb;
																																case 6:
																																	goto IL_02c9;
																																case 7:
																																case 20:
																																	goto IL_02d7;
																																case 56:
																																case 59:
																																	goto IL_02f3;
																																case 65:
																																	goto IL_0321;
																																case 17:
																																	goto IL_032f;
																																case 1:
																																case 4:
																																	goto IL_033d;
																																case 35:
																																	goto IL_03b4;
																																case 22:
																																	goto IL_03c7;
																																case 69:
																																	goto IL_03d5;
																																case 16:
																																case 66:
																																	goto IL_03e3;
																																case 9:
																																	goto IL_0423;
																																case 57:
																																	goto IL_0437;
																																case 78:
																																	goto IL_044a;
																																case 2:
																																	goto IL_0455;
																																case 80:
																																	goto IL_0462;
																																case 32:
																																	goto IL_0470;
																																case 73:
																																	goto IL_0497;
																																case 0:
																																case 27:
																																case 29:
																																case 30:
																																case 34:
																																case 37:
																																case 43:
																																case 47:
																																case 48:
																																case 50:
																																case 63:
																																case 76:
																																case 77:
																																case 81:
																																case 83:
																																	goto end_IL_0189;
																																case 51:
																																	goto IL_04ca;
																																case 31:
																																	goto IL_04d8;
																																case 42:
																																	goto IL_04e6;
																																case 13:
																																case 14:
																																case 36:
																																case 38:
																																case 49:
																																case 55:
																																case 60:
																																case 64:
																																case 68:
																																case 70:
																																case 71:
																																	goto end_IL_0261;
																																case 84:
																																	goto end_IL_04f4;
																																case 58:
																																	goto end_IL_0507;
																																case 21:
																																	goto end_IL_0511;
																																case 12:
																																	goto end_IL_051c;
																																case 18:
																																	goto end_IL_0531;
																																case 3:
																																case 45:
																																	goto end_IL_0546;
																																case 5:
																																	goto end_IL_0556;
																																case 15:
																																case 52:
																																	goto end_IL_0566;
																																case 74:
																																	goto end_IL_0576;
																																case 75:
																																	goto end_IL_0586;
																																case 46:
																																case 53:
																																	goto IL_05a1;
																																}
																																continue;
																															}
																															num5++;
																															goto IL_0497;
																															IL_0497:
																															ptr2 += 8;
																															goto end_IL_0261;
																															continue;
																															end_IL_0189:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_01e6:;
																										}
																										break;
																									}
																									goto IL_02bb;
																									IL_02d7:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0261;
																									IL_02bb:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_02c9;
																									IL_02c9:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_02d7;
																								}
																								break;
																							}
																							goto IL_026c;
																							IL_0296:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0261;
																							IL_026c:
																							if (6 <= b)
																							{
																								goto end_IL_0261;
																							}
																							goto IL_027a;
																							IL_027a:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0288;
																							IL_0288:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0296;
																						}
																						break;
																					}
																					goto IL_02ae;
																					IL_0437:
																					num5--;
																					goto end_IL_0261;
																					IL_02ae:
																					if (4 <= b)
																					{
																						goto IL_02f3;
																					}
																					goto IL_0321;
																					IL_02f3:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0462;
																					IL_0462:
																					ptr2 += 8;
																					goto IL_0470;
																					IL_0470:
																					num5--;
																					num = 38;
																					goto end_IL_0261;
																					IL_0321:
																					if (2 >= b)
																					{
																						goto IL_032f;
																					}
																					goto IL_03c7;
																					IL_032f:
																					if (2 <= b)
																					{
																						goto IL_033d;
																					}
																					goto IL_044a;
																					IL_033d:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 35;
																					goto IL_03b4;
																					IL_03b4:
																					num5 -= 2;
																					goto end_IL_0261;
																					IL_044a:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0455;
																					IL_0455:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_03c7:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_03d5;
																					IL_03d5:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_03e3;
																					IL_03e3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0423;
																					IL_0423:
																					array[num5 - 2] = 0;
																					goto IL_0437;
																				}
																				break;
																				IL_0226:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04ca;
																		IL_04e6:
																		ptr2 += 8;
																		goto end_IL_0261;
																		IL_04d8:
																		num5++;
																		goto IL_04e6;
																		IL_04ca:
																		array[num5] = 0;
																		goto IL_04d8;
																		continue;
																		end_IL_0236:
																		break;
																	}
																	continue;
																	end_IL_0246:
																	break;
																}
																continue;
																end_IL_0256:
																break;
															}
															continue;
															end_IL_0261:
															break;
														}
														continue;
													}
													goto IL_05a1;
													IL_05a1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f4:
													break;
												}
												continue;
												end_IL_0507:
												break;
											}
											continue;
											end_IL_0511:
											break;
										}
										continue;
										end_IL_051c:
										break;
									}
									continue;
									end_IL_0531:
									break;
								}
								continue;
								end_IL_0546:
								break;
							}
							continue;
							end_IL_0556:
							break;
						}
						continue;
						end_IL_0566:
						break;
					}
					continue;
					end_IL_0576:
					break;
				}
				continue;
				end_IL_0586:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 16;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 109;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									num = 74;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreatorsSecurityInfoIEnumString.getCurrencyPositivePatternRegisterActivatedClientType);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0310:
														num = 91;
														while (true)
														{
															IL_0305:
															byte b = *ptr2;
															while (true)
															{
																IL_02ec:
																ptr2++;
																num = 65;
																while (true)
																{
																	IL_02dc:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02bc:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02af:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_029f:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_028f:
																										if (5 >= b)
																										{
																											while (true)
																											{
																												IL_027f:
																												if (5 <= b)
																												{
																													while (true)
																													{
																														IL_0266:
																														array[num5] = 0;
																														num = 145;
																														while (true)
																														{
																															if (num != 145)
																															{
																																if (num != 1126)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 34:
																																case 85:
																																	goto IL_0266;
																																case 49:
																																	goto IL_027f;
																																case 119:
																																case 137:
																																	goto IL_028f;
																																case 6:
																																	goto IL_029f;
																																case 78:
																																	goto IL_02af;
																																case 0:
																																	goto IL_02bc;
																																case 136:
																																	goto IL_02cc;
																																case 65:
																																	goto IL_02dc;
																																case 11:
																																	goto IL_02ec;
																																case 91:
																																	goto IL_0305;
																																case 73:
																																	goto IL_0310;
																																case 17:
																																case 30:
																																	goto IL_031b;
																																case 44:
																																case 60:
																																	goto IL_0360;
																																case 46:
																																	goto IL_036e;
																																case 75:
																																case 82:
																																	goto IL_037c;
																																case 100:
																																	goto IL_03c1;
																																case 23:
																																case 66:
																																	goto IL_03d5;
																																case 104:
																																	goto IL_03ed;
																																case 106:
																																	goto IL_0406;
																																case 1:
																																	goto IL_0411;
																																case 31:
																																case 43:
																																	goto IL_041f;
																																case 19:
																																	goto IL_0438;
																																case 8:
																																	goto IL_0446;
																																case 58:
																																	goto IL_0454;
																																case 79:
																																case 110:
																																	goto IL_0467;
																																case 64:
																																	goto IL_0475;
																																case 22:
																																case 114:
																																	goto IL_0488;
																																case 81:
																																	goto IL_0496;
																																case 52:
																																case 86:
																																	goto IL_04a1;
																																case 96:
																																	goto IL_04b5;
																																case 68:
																																	goto IL_0517;
																																case 62:
																																	goto IL_0525;
																																case 7:
																																	goto IL_0533;
																																case 80:
																																	goto IL_0541;
																																case 32:
																																case 71:
																																	goto IL_054f;
																																case 10:
																																	goto IL_0572;
																																case 77:
																																	goto IL_0580;
																																case 48:
																																	goto IL_0597;
																																case 26:
																																	goto IL_05aa;
																																case 93:
																																	goto IL_05b5;
																																case 40:
																																case 111:
																																	goto IL_05c0;
																																case 70:
																																	goto IL_05dc;
																																case 5:
																																case 76:
																																	goto IL_05ec;
																																case 63:
																																	goto IL_05fa;
																																case 116:
																																	goto IL_0616;
																																case 12:
																																case 120:
																																	goto IL_0629;
																																case 108:
																																	goto IL_0637;
																																case 9:
																																case 122:
																																	goto IL_064a;
																																case 113:
																																	goto IL_06ac;
																																case 123:
																																	goto IL_06bf;
																																case 42:
																																	goto IL_06cd;
																																case 125:
																																	goto IL_06e0;
																																case 127:
																																	goto IL_06f3;
																																case 124:
																																	goto IL_0707;
																																case 18:
																																case 128:
																																	goto IL_071a;
																																case 55:
																																	goto IL_0728;
																																case 14:
																																case 117:
																																	goto IL_0736;
																																case 50:
																																	goto IL_0776;
																																case 92:
																																	goto IL_078a;
																																case 56:
																																case 131:
																																	goto IL_079d;
																																case 45:
																																case 133:
																																	goto IL_07b0;
																																case 53:
																																	goto IL_07d9;
																																case 37:
																																	goto IL_07e7;
																																case 61:
																																	goto IL_081a;
																																case 20:
																																	goto IL_0824;
																																case 121:
																																	goto IL_0832;
																																case 4:
																																case 21:
																																case 25:
																																case 28:
																																case 33:
																																case 51:
																																case 54:
																																case 57:
																																case 67:
																																case 69:
																																case 83:
																																case 88:
																																case 94:
																																case 97:
																																case 98:
																																case 99:
																																case 101:
																																case 103:
																																case 115:
																																case 118:
																																case 126:
																																case 129:
																																case 130:
																																case 135:
																																	goto end_IL_02cc;
																																case 2:
																																case 3:
																																case 13:
																																case 24:
																																case 27:
																																case 38:
																																case 39:
																																case 41:
																																case 47:
																																case 59:
																																case 72:
																																case 89:
																																case 90:
																																case 95:
																																case 102:
																																case 105:
																																case 132:
																																	goto end_IL_0253;
																																case 36:
																																	goto end_IL_0855;
																																case 74:
																																	goto end_IL_0868;
																																case 29:
																																	goto end_IL_0872;
																																case 134:
																																	goto end_IL_087d;
																																case 35:
																																case 84:
																																	goto end_IL_089b;
																																case 107:
																																	goto end_IL_08ab;
																																case 109:
																																case 112:
																																	goto end_IL_08bb;
																																case 15:
																																	goto end_IL_08cb;
																																case 16:
																																	goto end_IL_08db;
																																case 87:
																																case 138:
																																	goto IL_08ff;
																																}
																																continue;
																															}
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_081a;
																															IL_081a:
																															array2[num5] = null;
																															goto IL_0824;
																															IL_0832:
																															ptr2 += 8;
																															break;
																															IL_0824:
																															num5++;
																															goto IL_0832;
																															continue;
																															end_IL_0253:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0629;
																												IL_0637:
																												if (4 > b)
																												{
																													goto end_IL_02cc;
																												}
																												break;
																												IL_0629:
																												if (4 < b)
																												{
																													goto end_IL_02cc;
																												}
																												goto IL_0637;
																											}
																											break;
																										}
																										goto IL_0360;
																										IL_0707:
																										num5--;
																										break;
																										IL_0360:
																										if (6 < b)
																										{
																											goto end_IL_02cc;
																										}
																										goto IL_036e;
																										IL_036e:
																										if (6 > b)
																										{
																											goto end_IL_02cc;
																										}
																										goto IL_037c;
																										IL_037c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_06f3;
																										IL_06f3:
																										array[num5 - 2] = 0;
																										goto IL_0707;
																									}
																									break;
																								}
																								goto IL_03c1;
																								IL_07d9:
																								ptr2 += 8;
																								goto IL_07e7;
																								IL_03c1:
																								if (3 <= b)
																								{
																									num = 66;
																									goto IL_03d5;
																								}
																								goto IL_0406;
																								IL_07e7:
																								num5--;
																								break;
																								IL_03d5:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0406:
																								if (1 >= b)
																								{
																									goto IL_0411;
																								}
																								goto IL_0467;
																								IL_0411:
																								if (1 > b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_041f;
																								IL_041f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0438;
																								IL_0438:
																								array[num5] = 0;
																								goto IL_0446;
																								IL_0446:
																								num5++;
																								goto IL_0454;
																								IL_0454:
																								ptr2 += 8;
																								break;
																								IL_0467:
																								if (2 < b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_0475;
																								IL_0475:
																								if (2 > b)
																								{
																									goto end_IL_02cc;
																								}
																								goto IL_07b0;
																								IL_07b0:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07d9;
																							}
																							break;
																						}
																						goto IL_031b;
																						IL_06e0:
																						num5--;
																						break;
																						IL_031b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03ed;
																						IL_03ed:
																						array[num5 - 2] = 0;
																						goto IL_06e0;
																					}
																					break;
																				}
																				goto IL_0488;
																				IL_05fa:
																				if (14 > b)
																				{
																					num = 99;
																				}
																				goto end_IL_02cc;
																				IL_0488:
																				if (11 >= b)
																				{
																					goto IL_0496;
																				}
																				goto IL_05aa;
																				IL_0496:
																				if (11 <= b)
																				{
																					goto IL_04a1;
																				}
																				goto IL_0517;
																				IL_04a1:
																				array[num5 - 2] = 0;
																				goto IL_04b5;
																				IL_04b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)NestedFamilyMuiResourceIdLookupMapEntryFieldId[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				num = 123;
																				goto IL_06bf;
																				IL_06bf:
																				num5--;
																				goto IL_06cd;
																				IL_06cd:
																				ptr2 += 8;
																				break;
																				IL_0517:
																				if (9 >= b)
																				{
																					goto IL_0525;
																				}
																				goto IL_071a;
																				IL_0525:
																				if (9 > b)
																				{
																					goto IL_0533;
																				}
																				goto IL_064a;
																				IL_0533:
																				if (8 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_0541;
																				IL_0541:
																				if (8 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_054f;
																				IL_054f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0572;
																				IL_0572:
																				array[num5] = 0;
																				goto IL_0580;
																				IL_0580:
																				num5++;
																				num = 48;
																				goto IL_0597;
																				IL_0597:
																				ptr2 += 8;
																				break;
																				IL_064a:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06ac;
																				IL_06ac:
																				num5 -= 2;
																				break;
																				IL_071a:
																				if (10 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_0728;
																				IL_0728:
																				if (10 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_0736;
																				IL_0736:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0776;
																				IL_0776:
																				array[num5 - 2] = 0;
																				goto IL_078a;
																				IL_078a:
																				num5--;
																				break;
																				IL_05aa:
																				if (13 >= b)
																				{
																					goto IL_05b5;
																				}
																				goto IL_05ec;
																				IL_05b5:
																				if (13 <= b)
																				{
																					goto IL_05c0;
																				}
																				goto IL_05dc;
																				IL_05c0:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_05dc:
																				if (12 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_0616;
																				IL_0616:
																				if (12 > b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_079d;
																				IL_079d:
																				num5--;
																				break;
																				IL_05ec:
																				if (14 < b)
																				{
																					goto end_IL_02cc;
																				}
																				goto IL_05fa;
																			}
																			goto end_IL_02dc;
																			continue;
																			end_IL_02cc:
																			break;
																			IL_02cc:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02dc:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_08ff;
												IL_08ff:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0855:
												break;
											}
											continue;
											end_IL_0868:
											break;
										}
										continue;
										end_IL_0872:
										break;
									}
									continue;
									end_IL_087d:
									break;
								}
								continue;
								end_IL_089b:
								break;
							}
							continue;
							end_IL_08ab:
							break;
						}
						continue;
						end_IL_08bb:
						break;
					}
					continue;
					end_IL_08cb:
					break;
				}
				continue;
				end_IL_08db:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 135;
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 83;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 155;
									while (true)
									{
										if (num != 155)
										{
											if (num != 1136)
											{
												goto IL_081a;
											}
											switch (num)
											{
											case 52:
												goto end_IL_027b;
											case 118:
												goto end_IL_028e;
											case 10:
											case 139:
												goto end_IL_02a7;
											case 59:
												goto end_IL_02b7;
											case 83:
											case 140:
												goto end_IL_02c7;
											case 134:
												goto end_IL_02d7;
											case 135:
												goto end_IL_02e7;
											case 129:
												goto IL_031d;
											case 0:
											case 16:
											case 23:
											case 28:
											case 33:
											case 46:
											case 61:
											case 63:
											case 69:
											case 76:
											case 79:
											case 81:
											case 91:
											case 99:
											case 107:
											case 114:
											case 116:
											case 138:
												goto IL_0325;
											case 1:
											case 111:
												goto IL_0335;
											case 38:
												goto IL_033e;
											case 4:
												goto IL_034c;
											case 117:
												goto IL_035a;
											case 35:
												goto IL_0368;
											case 72:
											case 80:
												goto IL_0376;
											case 64:
											case 66:
												goto IL_0384;
											case 108:
											case 148:
												goto IL_038f;
											case 105:
												goto IL_039d;
											case 122:
												goto IL_03b0;
											case 36:
											case 37:
												goto IL_03bb;
											case 144:
												goto IL_03d7;
											case 126:
												goto IL_03e5;
											case 94:
											case 127:
												goto IL_03f3;
											case 6:
												goto IL_0455;
											case 12:
												goto IL_0471;
											case 113:
												goto IL_047f;
											case 92:
												goto IL_048d;
											case 15:
											case 121:
												goto IL_0498;
											case 45:
												goto IL_04a6;
											case 88:
											case 133:
												goto IL_04c2;
											case 8:
												goto IL_04d0;
											case 57:
												goto IL_04f3;
											case 136:
												goto IL_04fd;
											case 87:
												goto IL_0514;
											case 20:
												goto IL_0527;
											case 103:
												goto IL_0535;
											case 18:
											case 123:
												goto IL_0543;
											case 89:
												goto IL_0587;
											case 25:
												goto IL_059b;
											case 3:
											case 67:
												goto IL_05ae;
											case 42:
												goto IL_05ee;
											case 24:
												goto IL_0602;
											case 32:
												goto IL_0615;
											case 77:
												goto IL_0623;
											case 47:
											case 84:
												goto IL_0631;
											case 101:
											case 110:
												goto IL_063c;
											case 43:
												goto IL_064a;
											case 82:
											case 112:
												goto IL_0658;
											case 74:
												goto IL_068a;
											case 73:
												goto IL_0698;
											case 130:
												goto IL_06ab;
											case 98:
											case 145:
												goto IL_06b6;
											case 54:
												goto IL_06c4;
											case 31:
											case 85:
												goto IL_06d2;
											case 137:
												goto IL_06e9;
											case 131:
												goto IL_0701;
											case 39:
												goto IL_0718;
											case 27:
											case 142:
												goto IL_072b;
											case 115:
												goto IL_076a;
											case 71:
												goto IL_077d;
											case 96:
												goto IL_078b;
											case 55:
												goto IL_0799;
											case 51:
											case 58:
												goto IL_07a4;
											case 125:
												goto IL_07b2;
											case 2:
											case 128:
												goto IL_07c0;
											case 30:
												goto IL_07e2;
											case 44:
												goto IL_07f9;
											case 65:
												goto IL_0807;
											case 49:
											case 104:
												goto IL_081a;
											case 40:
												goto IL_085a;
											case 56:
												goto IL_086e;
											case 53:
											case 90:
												goto IL_088a;
											case 132:
												goto IL_0898;
											case 14:
											case 141:
												goto IL_08a6;
											case 97:
												goto IL_08cf;
											case 9:
											case 100:
												goto IL_08e8;
											case 26:
												goto IL_0906;
											case 50:
												goto IL_0914;
											case 70:
											case 109:
												goto IL_0939;
											case 5:
											case 7:
											case 11:
											case 13:
											case 19:
											case 21:
											case 22:
											case 29:
											case 34:
											case 41:
											case 60:
											case 62:
											case 68:
											case 75:
											case 78:
											case 86:
											case 93:
											case 95:
											case 102:
											case 106:
											case 119:
											case 120:
											case 124:
											case 143:
											case 146:
											case 147:
												goto IL_0951;
											case 17:
											case 48:
												goto IL_0969;
											}
											continue;
										}
										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OtherOrganizationSidCallContextRemotingData.InsufficientExecutionStackExceptionTracingStatusChangedEventArgs);
										num = 129;
										goto IL_031d;
										IL_08e8:
										array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
										goto IL_0906;
										IL_0914:
										num4--;
										num = 116;
										goto IL_0325;
										IL_0906:
										ptr2 += 8;
										goto IL_0914;
										IL_031d:
										ptr2 = ptr;
										goto IL_0325;
										IL_0325:
										if (num5 != 1)
										{
											goto IL_0335;
										}
										goto IL_0969;
										IL_0969:
										return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										IL_0335:
										b = *ptr2;
										goto IL_033e;
										IL_033e:
										ptr2++;
										goto IL_034c;
										IL_034c:
										if (b >= 1)
										{
											goto IL_035a;
										}
										goto IL_0951;
										IL_035a:
										if (b <= 15)
										{
											goto IL_0368;
										}
										goto IL_0951;
										IL_0368:
										if (8 < b)
										{
											goto IL_0376;
										}
										goto IL_0615;
										IL_0376:
										if (12 < b)
										{
											goto IL_0384;
										}
										goto IL_0471;
										IL_0384:
										if (14 < b)
										{
											goto IL_038f;
										}
										goto IL_03b0;
										IL_038f:
										if (15 >= b)
										{
											goto IL_039d;
										}
										goto IL_0951;
										IL_039d:
										if (15 > b)
										{
										}
										goto IL_0951;
										IL_03b0:
										if (14 <= b)
										{
											goto IL_03bb;
										}
										goto IL_03d7;
										IL_03bb:
										byte* num6 = ptr2;
										num5 = 1;
										ptr2 = num6 + -200;
										goto IL_0325;
										IL_03d7:
										if (13 >= b)
										{
											goto IL_03e5;
										}
										goto IL_0951;
										IL_03e5:
										if (13 <= b)
										{
											goto IL_03f3;
										}
										goto IL_0951;
										IL_03f3:
										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
										goto IL_0455;
										IL_0455:
										num4 -= 2;
										num = 61;
										goto IL_0325;
										IL_0471:
										if (12 > b)
										{
											goto IL_047f;
										}
										goto IL_05ae;
										IL_047f:
										if (10 >= b)
										{
											goto IL_048d;
										}
										goto IL_0527;
										IL_048d:
										if (10 > b)
										{
											goto IL_0498;
										}
										goto IL_04c2;
										IL_0498:
										if (9 >= b)
										{
											goto IL_04a6;
										}
										goto IL_0951;
										IL_04a6:
										if (9 <= b)
										{
											num = 16;
											goto IL_0325;
										}
										goto IL_0951;
										IL_0939:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_0325;
										IL_04c2:
										array[num4] = 0;
										goto IL_04d0;
										IL_04d0:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
										goto IL_04f3;
										IL_04f3:
										array2[num4] = null;
										goto IL_04fd;
										IL_04fd:
										num4++;
										num = 87;
										goto IL_0514;
										IL_0514:
										ptr2 += 8;
										goto IL_0325;
										IL_0527:
										if (11 >= b)
										{
											goto IL_0535;
										}
										goto IL_0951;
										IL_0535:
										if (11 <= b)
										{
											goto IL_0543;
										}
										goto IL_0951;
										IL_0543:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
										goto IL_0587;
										IL_0587:
										array[num4 - 2] = 0;
										goto IL_059b;
										IL_059b:
										num4--;
										goto IL_0325;
										IL_05ae:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_05ee;
										IL_05ee:
										array[num4 - 2] = 0;
										goto IL_0602;
										IL_0602:
										num4--;
										goto IL_0325;
										IL_0615:
										if (8 > b)
										{
											goto IL_0623;
										}
										num = 109;
										goto IL_0939;
										IL_0623:
										if (4 < b)
										{
											goto IL_0631;
										}
										goto IL_077d;
										IL_0631:
										if (6 < b)
										{
											goto IL_063c;
										}
										goto IL_06ab;
										IL_063c:
										if (7 >= b)
										{
											goto IL_064a;
										}
										goto IL_0951;
										IL_064a:
										if (7 <= b)
										{
											goto IL_0658;
										}
										goto IL_0951;
										IL_0658:
										ref int reference = ref array3[*(int*)(ptr2 + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										num = 74;
										goto IL_068a;
										IL_068a:
										ptr2 += 8;
										goto IL_0698;
										IL_0698:
										num4--;
										goto IL_0325;
										IL_06ab:
										if (6 > b)
										{
											goto IL_06b6;
										}
										goto IL_072b;
										IL_06b6:
										if (5 >= b)
										{
											goto IL_06c4;
										}
										goto IL_0951;
										IL_06c4:
										if (5 <= b)
										{
											goto IL_06d2;
										}
										goto IL_0951;
										IL_06d2:
										array[num4] = 5;
										num = 137;
										goto IL_06e9;
										IL_06e9:
										array2[num4] = array5[*(int*)(ptr2 + num3)];
										goto IL_0701;
										IL_0701:
										num4++;
										num = 39;
										goto IL_0718;
										IL_0718:
										ptr2 += 8;
										goto IL_0325;
										IL_072b:
										((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_076a;
										IL_076a:
										num4 -= 3;
										goto IL_0325;
										IL_077d:
										if (4 > b)
										{
											goto IL_078b;
										}
										goto IL_08e8;
										IL_078b:
										if (2 >= b)
										{
											goto IL_0799;
										}
										num = 53;
										goto IL_088a;
										IL_0799:
										if (2 > b)
										{
											goto IL_07a4;
										}
										goto IL_081a;
										IL_07a4:
										if (1 >= b)
										{
											goto IL_07b2;
										}
										goto IL_0951;
										IL_07b2:
										if (1 <= b)
										{
											goto IL_07c0;
										}
										goto IL_0951;
										IL_07c0:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
										num = 30;
										goto IL_07e2;
										IL_07e2:
										array[num4] = 0;
										num = 44;
										goto IL_07f9;
										IL_07f9:
										num4++;
										goto IL_0807;
										IL_0807:
										ptr2 += 8;
										goto IL_0325;
										IL_081a:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_085a;
										IL_085a:
										array[num4 - 2] = 0;
										goto IL_086e;
										IL_086e:
										num4--;
										goto IL_0325;
										IL_0951:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_0325;
										IL_088a:
										if (3 >= b)
										{
											goto IL_0898;
										}
										goto IL_0951;
										IL_0898:
										if (3 <= b)
										{
											goto IL_08a6;
										}
										goto IL_0951;
										IL_08a6:
										array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
										goto IL_08cf;
										IL_08cf:
										array[num4 - 1] = 5;
										goto IL_0325;
										continue;
										end_IL_027b:
										break;
									}
									continue;
									end_IL_028e:
									break;
								}
								continue;
								end_IL_02a7:
								break;
							}
							continue;
							end_IL_02b7:
							break;
						}
						continue;
						end_IL_02c7:
						break;
					}
					continue;
					end_IL_02d7:
					break;
				}
				continue;
				end_IL_02e7:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 133;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 7;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 65;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InvalidHandleSalt.UtcSortPatternOemClear);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0348:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0328:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_031b:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_030e:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02fe:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02ee:
																											if (2 >= b)
																											{
																												while (true)
																												{
																													IL_02de:
																													if (2 > b)
																													{
																														while (1 >= b)
																														{
																															while (1 <= b)
																															{
																																while (true)
																																{
																																	IL_02a3:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																	while (true)
																																	{
																																		IL_0293:
																																		array[num5] = 0;
																																		while (true)
																																		{
																																			IL_027a:
																																			num5++;
																																			num = 150;
																																			while (true)
																																			{
																																				if (num != 150)
																																				{
																																					if (num != 1131)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 69:
																																						goto IL_027a;
																																					case 55:
																																						goto IL_0293;
																																					case 6:
																																					case 122:
																																						goto IL_02a3;
																																					case 126:
																																						goto IL_02be;
																																					case 10:
																																					case 15:
																																						goto IL_02ce;
																																					case 141:
																																						goto IL_02de;
																																					case 3:
																																					case 102:
																																						goto IL_02ee;
																																					case 20:
																																						goto IL_02fe;
																																					case 1:
																																						goto IL_030e;
																																					case 74:
																																						goto IL_031b;
																																					case 5:
																																						goto IL_0328;
																																					case 29:
																																						goto IL_0338;
																																					case 21:
																																						goto IL_0348;
																																					case 108:
																																						goto end_IL_0348;
																																					case 18:
																																					case 26:
																																						goto end_IL_0358;
																																					case 2:
																																					case 125:
																																						goto IL_0373;
																																					case 47:
																																					case 129:
																																						goto IL_038b;
																																					case 53:
																																						goto IL_0399;
																																					case 107:
																																					case 116:
																																						goto IL_03a4;
																																					case 30:
																																						goto IL_03e3;
																																					case 36:
																																						goto IL_03f6;
																																					case 124:
																																						goto IL_040d;
																																					case 66:
																																					case 104:
																																						goto IL_041b;
																																					case 31:
																																						goto IL_0429;
																																					case 51:
																																						goto IL_0441;
																																					case 61:
																																						goto IL_044f;
																																					case 136:
																																						goto IL_0462;
																																					case 71:
																																						goto IL_0470;
																																					case 89:
																																					case 111:
																																						goto IL_047e;
																																					case 114:
																																						goto IL_04a7;
																																					case 42:
																																						goto IL_04b5;
																																					case 109:
																																					case 118:
																																						goto IL_04db;
																																					case 32:
																																						goto IL_051b;
																																					case 64:
																																						goto IL_052f;
																																					case 33:
																																						goto IL_0542;
																																					case 93:
																																						goto IL_0550;
																																					case 43:
																																					case 75:
																																						goto IL_055e;
																																					case 73:
																																						goto IL_0587;
																																					case 60:
																																					case 82:
																																						goto IL_05a0;
																																					case 38:
																																						goto IL_05be;
																																					case 79:
																																						goto IL_05cc;
																																					case 22:
																																						goto IL_05df;
																																					case 121:
																																						goto IL_05ed;
																																					case 128:
																																					case 137:
																																						goto IL_05f8;
																																					case 97:
																																						goto IL_0638;
																																					case 17:
																																						goto IL_064c;
																																					case 85:
																																					case 96:
																																						goto IL_0668;
																																					case 95:
																																						goto IL_0676;
																																					case 25:
																																						goto IL_0684;
																																					case 27:
																																					case 56:
																																						goto IL_0692;
																																					case 106:
																																						goto IL_06d6;
																																					case 101:
																																						goto IL_06f3;
																																					case 139:
																																						goto IL_0706;
																																					case 127:
																																					case 130:
																																						goto IL_0711;
																																					case 113:
																																						goto IL_071f;
																																					case 23:
																																					case 48:
																																						goto IL_0732;
																																					case 35:
																																						goto IL_0740;
																																					case 135:
																																						goto IL_0763;
																																					case 13:
																																						goto IL_076d;
																																					case 0:
																																						goto IL_077b;
																																					case 78:
																																						goto IL_078e;
																																					case 90:
																																						goto IL_079c;
																																					case 57:
																																					case 58:
																																						goto IL_07a7;
																																					case 4:
																																						goto IL_07c3;
																																					case 46:
																																						goto IL_07d1;
																																					case 28:
																																					case 68:
																																						goto IL_07df;
																																					case 120:
																																						goto IL_0841;
																																					case 70:
																																					case 138:
																																						goto IL_0851;
																																					case 94:
																																						goto IL_085c;
																																					case 9:
																																					case 12:
																																					case 14:
																																					case 24:
																																					case 34:
																																					case 37:
																																					case 39:
																																					case 41:
																																					case 52:
																																					case 62:
																																					case 63:
																																					case 72:
																																					case 81:
																																					case 84:
																																					case 87:
																																					case 88:
																																					case 98:
																																					case 100:
																																					case 110:
																																					case 117:
																																					case 119:
																																					case 123:
																																					case 134:
																																					case 143:
																																						goto end_IL_0267;
																																					case 11:
																																					case 16:
																																					case 40:
																																					case 45:
																																					case 50:
																																					case 59:
																																					case 76:
																																					case 80:
																																					case 83:
																																					case 86:
																																					case 91:
																																					case 99:
																																					case 103:
																																					case 105:
																																					case 112:
																																					case 115:
																																					case 140:
																																					case 142:
																																						goto end_IL_0368;
																																					case 54:
																																						goto end_IL_0883;
																																					case 65:
																																						goto end_IL_0896;
																																					case 92:
																																						goto end_IL_08a0;
																																					case 7:
																																						goto end_IL_08ab;
																																					case 67:
																																					case 131:
																																						goto end_IL_08c4;
																																					case 19:
																																						goto end_IL_08d4;
																																					case 44:
																																					case 49:
																																						goto end_IL_08ed;
																																					case 132:
																																						goto end_IL_08fd;
																																					case 133:
																																						goto end_IL_090d;
																																					case 8:
																																					case 77:
																																						goto IL_0928;
																																					}
																																					continue;
																																				}
																																				ptr2 += 8;
																																				goto end_IL_0368;
																																				continue;
																																				end_IL_0267:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																																IL_02be:;
																															}
																															break;
																															IL_02ce:;
																														}
																														break;
																													}
																													goto IL_04db;
																													IL_052f:
																													num5--;
																													goto end_IL_0368;
																													IL_04db:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_051b;
																													IL_051b:
																													array[num5 - 2] = 0;
																													goto IL_052f;
																												}
																												break;
																											}
																											goto IL_0542;
																											IL_0587:
																											array[num5 - 1] = 5;
																											goto end_IL_0368;
																											IL_0542:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0550;
																											IL_0550:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_055e;
																											IL_055e:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0587;
																										}
																										break;
																									}
																									goto IL_05a0;
																									IL_05cc:
																									num5--;
																									goto end_IL_0368;
																									IL_05a0:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_05be;
																									IL_05be:
																									ptr2 += 8;
																									goto IL_05cc;
																								}
																								break;
																							}
																							goto IL_038b;
																							IL_04a7:
																							ptr2 += 8;
																							goto IL_04b5;
																							IL_038b:
																							if (6 >= b)
																							{
																								goto IL_0399;
																							}
																							goto IL_0462;
																							IL_0399:
																							if (6 <= b)
																							{
																								goto IL_03a4;
																							}
																							goto IL_03f6;
																							IL_03a4:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03e3;
																							IL_03e3:
																							num5 -= 3;
																							goto end_IL_0368;
																							IL_03f6:
																							if (5 < b)
																							{
																								break;
																							}
																							num = 124;
																							goto IL_040d;
																							IL_04b5:
																							num5--;
																							goto end_IL_0368;
																							IL_040d:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_041b;
																							IL_041b:
																							array[num5] = 5;
																							goto IL_0429;
																							IL_0429:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0441;
																							IL_0441:
																							num5++;
																							goto IL_044f;
																							IL_044f:
																							ptr2 += 8;
																							goto end_IL_0368;
																							IL_0462:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0470;
																							IL_0470:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_047e;
																							IL_047e:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04a7;
																						}
																						break;
																					}
																					goto IL_0373;
																					IL_0373:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0368;
																				}
																				break;
																			}
																			goto IL_05df;
																			IL_0851:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_085c;
																			IL_05df:
																			if (12 >= b)
																			{
																				goto IL_05ed;
																			}
																			goto IL_078e;
																			IL_05ed:
																			if (12 <= b)
																			{
																				goto IL_05f8;
																			}
																			num = 96;
																			goto IL_0668;
																			IL_05f8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0638;
																			IL_0638:
																			array[num5 - 2] = 0;
																			goto IL_064c;
																			IL_064c:
																			num5--;
																			goto end_IL_0368;
																			IL_085c:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_0668:
																			if (10 < b)
																			{
																				goto IL_0676;
																			}
																			goto IL_0706;
																			IL_0676:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0684;
																			IL_0684:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0692;
																			IL_0692:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06d6;
																			IL_06d6:
																			array[num5 - 2] = 0;
																			num = 101;
																			goto IL_06f3;
																			IL_06f3:
																			num5--;
																			goto end_IL_0368;
																			IL_0706:
																			if (10 > b)
																			{
																				goto IL_0711;
																			}
																			goto IL_0732;
																			IL_0711:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_071f;
																			IL_071f:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0368;
																			IL_0732:
																			array[num5] = 0;
																			goto IL_0740;
																			IL_0740:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0763;
																			IL_0763:
																			array2[num5] = null;
																			goto IL_076d;
																			IL_076d:
																			num5++;
																			goto IL_077b;
																			IL_077b:
																			ptr2 += 8;
																			goto end_IL_0368;
																			IL_078e:
																			if (14 >= b)
																			{
																				goto IL_079c;
																			}
																			goto IL_0851;
																			IL_079c:
																			if (14 <= b)
																			{
																				goto IL_07a7;
																			}
																			goto IL_07c3;
																			IL_07a7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0368;
																			IL_07c3:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_07d1;
																			IL_07d1:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_07df;
																			IL_07df:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0841;
																			IL_0841:
																			num5 -= 2;
																			goto end_IL_0368;
																		}
																		break;
																		IL_0338:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 45;
																goto end_IL_0368;
																continue;
																end_IL_0348:
																break;
															}
															continue;
															end_IL_0358:
															break;
														}
														continue;
														end_IL_0368:
														break;
													}
													continue;
												}
												goto IL_0928;
												IL_0928:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0883:
												break;
											}
											continue;
											end_IL_0896:
											break;
										}
										continue;
										end_IL_08a0:
										break;
									}
									continue;
									end_IL_08ab:
									break;
								}
								continue;
								end_IL_08c4:
								break;
							}
							continue;
							end_IL_08d4:
							break;
						}
						continue;
						end_IL_08ed:
						break;
					}
					continue;
					end_IL_08fd:
					break;
				}
				continue;
				end_IL_090d:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 121;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 42;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								num = 54;
								while (true)
								{
									int[] array3 = new int[2];
									while (true)
									{
										long[] array4 = new long[4];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setApartmentStategetInheritedObjectType.GetCultureInfoApplication);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 40;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_0321:
																			if (b >= 1)
																			{
																				while (b <= 15)
																				{
																					while (true)
																					{
																						IL_0301:
																						if (8 >= b)
																						{
																							num = 64;
																							while (true)
																							{
																								IL_02f1:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_02e1:
																										if (4 >= b)
																										{
																											while (true)
																											{
																												IL_02d1:
																												if (4 > b)
																												{
																													while (true)
																													{
																														IL_02c1:
																														if (2 >= b)
																														{
																															while (true)
																															{
																																IL_02b1:
																																if (2 > b)
																																{
																																	while (1 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_028e:
																																			if (1 > b)
																																			{
																																				num = 148;
																																				while (num != 148)
																																				{
																																					if (num != 1129)
																																					{
																																						goto IL_02c1;
																																					}
																																					switch (num)
																																					{
																																					case 56:
																																						goto IL_028e;
																																					case 94:
																																						goto IL_02a1;
																																					case 33:
																																						goto IL_02b1;
																																					case 76:
																																						goto IL_02c1;
																																					case 18:
																																						goto IL_02d1;
																																					case 15:
																																					case 81:
																																						goto IL_02e1;
																																					case 64:
																																						goto IL_02f1;
																																					case 46:
																																						goto IL_0301;
																																					case 36:
																																						goto IL_0311;
																																					case 11:
																																						goto IL_0321;
																																					case 80:
																																						goto end_IL_0321;
																																					case 74:
																																					case 100:
																																						goto end_IL_0331;
																																					case 134:
																																						goto IL_034c;
																																					case 86:
																																						goto IL_035a;
																																					case 133:
																																						goto IL_0368;
																																					case 78:
																																					case 91:
																																						goto IL_0373;
																																					case 102:
																																						goto IL_038f;
																																					case 28:
																																						goto IL_039d;
																																					case 57:
																																					case 77:
																																						goto IL_03ab;
																																					case 131:
																																						goto IL_040d;
																																					case 85:
																																					case 110:
																																						goto IL_0420;
																																					case 96:
																																						goto IL_042e;
																																					case 67:
																																						goto IL_0441;
																																					case 101:
																																						goto IL_044f;
																																					case 23:
																																						goto IL_045d;
																																					case 49:
																																					case 65:
																																						goto IL_0468;
																																					case 69:
																																						goto IL_0476;
																																					case 4:
																																					case 123:
																																						goto IL_0489;
																																					case 62:
																																						goto IL_0497;
																																					case 108:
																																						goto IL_04c3;
																																					case 52:
																																						goto IL_04cd;
																																					case 47:
																																						goto IL_04db;
																																					case 95:
																																						goto IL_04ee;
																																					case 0:
																																					case 38:
																																						goto IL_04fe;
																																					case 16:
																																						goto IL_053e;
																																					case 32:
																																						goto IL_055b;
																																					case 140:
																																						goto IL_056e;
																																					case 35:
																																					case 71:
																																						goto IL_057c;
																																					case 51:
																																						goto IL_05c0;
																																					case 124:
																																						goto IL_05dd;
																																					case 5:
																																					case 82:
																																						goto IL_05f0;
																																					case 58:
																																						goto IL_0609;
																																					case 3:
																																						goto IL_0617;
																																					case 115:
																																						goto IL_0625;
																																					case 41:
																																					case 135:
																																						goto IL_0638;
																																					case 44:
																																						goto IL_0678;
																																					case 90:
																																						goto IL_068c;
																																					case 20:
																																					case 117:
																																						goto IL_06b1;
																																					case 70:
																																						goto IL_06bf;
																																					case 59:
																																					case 113:
																																						goto IL_06d6;
																																					case 10:
																																						goto IL_06ff;
																																					case 48:
																																					case 137:
																																						goto IL_0718;
																																					case 92:
																																						goto IL_0736;
																																					case 79:
																																						goto IL_0744;
																																					case 138:
																																						goto IL_0757;
																																					case 60:
																																					case 98:
																																						goto IL_0762;
																																					case 139:
																																						goto IL_0770;
																																					case 26:
																																					case 118:
																																						goto IL_077e;
																																					case 73:
																																						goto IL_07a7;
																																					case 27:
																																						goto IL_07b5;
																																					case 39:
																																						goto IL_07c8;
																																					case 2:
																																					case 87:
																																						goto IL_07d3;
																																					case 84:
																																						goto IL_0812;
																																					case 25:
																																						goto IL_0825;
																																					case 8:
																																						goto IL_0839;
																																					case 66:
																																					case 125:
																																						goto IL_0844;
																																					case 93:
																																						goto IL_0852;
																																					case 132:
																																						goto IL_086a;
																																					case 24:
																																						goto IL_0878;
																																					case 6:
																																					case 99:
																																						goto IL_0888;
																																					case 13:
																																					case 17:
																																					case 19:
																																					case 29:
																																					case 31:
																																					case 34:
																																					case 43:
																																					case 45:
																																					case 68:
																																					case 97:
																																					case 103:
																																					case 104:
																																					case 106:
																																					case 107:
																																					case 109:
																																					case 112:
																																					case 116:
																																					case 119:
																																					case 122:
																																					case 127:
																																					case 128:
																																					case 136:
																																						goto end_IL_027b;
																																					case 1:
																																					case 7:
																																					case 12:
																																					case 14:
																																					case 21:
																																					case 37:
																																					case 40:
																																					case 50:
																																					case 55:
																																					case 61:
																																					case 72:
																																					case 75:
																																					case 83:
																																					case 88:
																																					case 89:
																																					case 111:
																																					case 114:
																																						goto end_IL_0341;
																																					case 30:
																																						goto end_IL_08b0;
																																					case 126:
																																						goto end_IL_08c3;
																																					case 53:
																																						goto end_IL_08ce;
																																					case 63:
																																						goto end_IL_08d8;
																																					case 129:
																																						goto end_IL_08e3;
																																					case 54:
																																						goto end_IL_08f3;
																																					case 130:
																																						goto end_IL_0903;
																																					case 22:
																																						goto end_IL_0913;
																																					case 42:
																																						goto end_IL_091e;
																																					case 141:
																																						goto end_IL_092e;
																																					case 120:
																																						goto end_IL_093e;
																																					case 121:
																																						goto end_IL_0949;
																																					case 9:
																																					case 105:
																																						goto IL_0964;
																																					}
																																					continue;
																																					end_IL_027b:
																																					break;
																																				}
																																				break;
																																			}
																																			goto IL_05f0;
																																			IL_0617:
																																			num5++;
																																			goto IL_0625;
																																			IL_0625:
																																			ptr2 += 8;
																																			goto end_IL_0341;
																																			IL_05f0:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																			goto IL_0609;
																																			IL_0609:
																																			array[num5] = 0;
																																			goto IL_0617;
																																		}
																																		break;
																																		IL_02a1:;
																																	}
																																	break;
																																}
																																goto IL_0638;
																																IL_068c:
																																num5--;
																																num = 12;
																																goto end_IL_0341;
																																IL_0638:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																goto IL_0678;
																																IL_0678:
																																array[num5 - 2] = 0;
																																goto IL_068c;
																															}
																															break;
																														}
																														num = 20;
																														goto IL_06b1;
																														IL_06ff:
																														array[num5 - 1] = 5;
																														goto end_IL_0341;
																														IL_06d6:
																														array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																														goto IL_06ff;
																														IL_06b1:
																														if (3 < b)
																														{
																															break;
																														}
																														goto IL_06bf;
																														IL_06bf:
																														if (3 > b)
																														{
																															break;
																														}
																														num = 113;
																														goto IL_06d6;
																													}
																													break;
																												}
																												goto IL_0718;
																												IL_0744:
																												num5--;
																												goto end_IL_0341;
																												IL_0718:
																												array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																												goto IL_0736;
																												IL_0736:
																												ptr2 += 8;
																												goto IL_0744;
																											}
																											break;
																										}
																										goto IL_0757;
																										IL_086a:
																										num5++;
																										goto IL_0878;
																										IL_0757:
																										if (6 < b)
																										{
																											goto IL_0762;
																										}
																										goto IL_07c8;
																										IL_0762:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0770;
																										IL_0770:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_077e;
																										IL_077e:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_07a7;
																										IL_07a7:
																										ptr2 += 8;
																										goto IL_07b5;
																										IL_07b5:
																										num5--;
																										goto end_IL_0341;
																										IL_07c8:
																										if (6 <= b)
																										{
																											goto IL_07d3;
																										}
																										goto IL_0825;
																										IL_07d3:
																										((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0812;
																										IL_0812:
																										num5 -= 3;
																										goto end_IL_0341;
																										IL_0825:
																										if (5 < b)
																										{
																											break;
																										}
																										num = 8;
																										goto IL_0839;
																										IL_0878:
																										ptr2 += 8;
																										goto end_IL_0341;
																										IL_0839:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_0844;
																										IL_0844:
																										array[num5] = 5;
																										goto IL_0852;
																										IL_0852:
																										array2[num5] = array5[*(int*)(ptr2 + num3)];
																										goto IL_086a;
																									}
																									break;
																								}
																								goto IL_0888;
																								IL_0888:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0341;
																							}
																							break;
																						}
																						goto IL_034c;
																						IL_053e:
																						array[num5 - 2] = 0;
																						num = 32;
																						goto IL_055b;
																						IL_055b:
																						num5--;
																						goto end_IL_0341;
																						IL_034c:
																						if (12 < b)
																						{
																							goto IL_035a;
																						}
																						goto IL_0441;
																						IL_035a:
																						if (14 >= b)
																						{
																							goto IL_0368;
																						}
																						goto IL_0420;
																						IL_0368:
																						if (14 <= b)
																						{
																							goto IL_0373;
																						}
																						goto IL_038f;
																						IL_0373:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0341;
																						IL_038f:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_039d;
																						IL_039d:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_03ab;
																						IL_03ab:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_040d;
																						IL_040d:
																						num5 -= 2;
																						goto end_IL_0341;
																						IL_0420:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_042e;
																						IL_042e:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_0441:
																						if (12 > b)
																						{
																							goto IL_044f;
																						}
																						goto IL_04fe;
																						IL_044f:
																						if (10 >= b)
																						{
																							goto IL_045d;
																						}
																						goto IL_04ee;
																						IL_045d:
																						if (10 > b)
																						{
																							goto IL_0468;
																						}
																						goto IL_0489;
																						IL_0468:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0476;
																						IL_0476:
																						if (9 > b)
																						{
																							break;
																						}
																						goto end_IL_0341;
																						IL_0489:
																						array[num5] = 0;
																						goto IL_0497;
																						IL_0497:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						num = 108;
																						goto IL_04c3;
																						IL_04c3:
																						array2[num5] = null;
																						goto IL_04cd;
																						IL_04cd:
																						num5++;
																						goto IL_04db;
																						IL_04db:
																						ptr2 += 8;
																						goto end_IL_0341;
																						IL_04ee:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_056e;
																						IL_056e:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_057c;
																						IL_057c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_05c0;
																						IL_05c0:
																						array[num5 - 2] = 0;
																						num = 124;
																						goto IL_05dd;
																						IL_05dd:
																						num5--;
																						goto end_IL_0341;
																						IL_04fe:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_053e;
																					}
																					break;
																					IL_0311:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0341;
																			continue;
																			end_IL_0321:
																			break;
																		}
																		continue;
																		end_IL_0331:
																		break;
																	}
																	continue;
																	end_IL_0341:
																	break;
																}
																continue;
															}
															goto IL_0964;
															IL_0964:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_08b0:
															break;
														}
														continue;
														end_IL_08c3:
														break;
													}
													continue;
													end_IL_08ce:
													break;
												}
												continue;
												end_IL_08d8:
												break;
											}
											continue;
											end_IL_08e3:
											break;
										}
										continue;
										end_IL_08f3:
										break;
									}
									continue;
									end_IL_0903:
									break;
								}
								continue;
								end_IL_0913:
								break;
							}
							continue;
							end_IL_091e:
							break;
						}
						continue;
						end_IL_092e:
						break;
					}
					continue;
					end_IL_093e:
					break;
				}
				continue;
				end_IL_0949:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LazyHelpersMemoryBarrier.SafeArrayRankMismatchExceptionsetAsDate);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0280:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0260:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0253:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0243:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0233:
																										if (4 < b)
																										{
																											while (true)
																											{
																												IL_0220:
																												if (5 < b)
																												{
																													num = 124;
																													while (num != 124)
																													{
																														if (num != 1105)
																														{
																															goto IL_03d3;
																														}
																														switch (num)
																														{
																														case 5:
																															goto IL_0220;
																														case 31:
																															goto IL_0233;
																														case 35:
																															goto IL_0243;
																														case 40:
																															goto IL_0253;
																														case 45:
																															goto IL_0260;
																														case 24:
																															goto IL_0270;
																														case 81:
																															goto IL_0280;
																														case 109:
																															goto end_IL_0280;
																														case 18:
																														case 64:
																															goto end_IL_0290;
																														case 55:
																														case 103:
																															goto IL_02ab;
																														case 61:
																															goto IL_02eb;
																														case 87:
																															goto IL_02ff;
																														case 82:
																															goto IL_0312;
																														case 6:
																														case 34:
																															goto IL_0320;
																														case 76:
																															goto IL_032e;
																														case 48:
																															goto IL_0351;
																														case 86:
																															goto IL_035b;
																														case 102:
																															goto IL_0369;
																														case 91:
																															goto IL_037c;
																														case 42:
																														case 74:
																															goto IL_0393;
																														case 113:
																															goto IL_03d3;
																														case 54:
																															goto IL_03e7;
																														case 95:
																															goto IL_0403;
																														case 70:
																															goto IL_0411;
																														case 0:
																														case 36:
																															goto IL_041f;
																														case 77:
																															goto IL_042d;
																														case 32:
																														case 114:
																															goto IL_043b;
																														case 110:
																															goto IL_047b;
																														case 106:
																															goto IL_048f;
																														case 84:
																															goto IL_04a2;
																														case 72:
																														case 90:
																															goto IL_04b5;
																														case 27:
																															goto IL_04de;
																														case 41:
																															goto IL_04ec;
																														case 89:
																															goto IL_04ff;
																														case 4:
																															goto IL_050d;
																														case 105:
																															goto IL_051b;
																														case 11:
																														case 49:
																															goto IL_0529;
																														case 47:
																															goto IL_0537;
																														case 26:
																														case 38:
																															goto IL_0545;
																														case 53:
																															goto IL_0585;
																														case 67:
																															goto IL_0599;
																														case 101:
																															goto IL_05ac;
																														case 79:
																														case 88:
																															goto IL_05ba;
																														case 39:
																															goto IL_05d3;
																														case 99:
																															goto IL_05e1;
																														case 10:
																															goto IL_05ef;
																														case 15:
																														case 75:
																															goto IL_0614;
																														case 63:
																															goto IL_0622;
																														case 104:
																															goto IL_0646;
																														case 69:
																															goto IL_0654;
																														case 7:
																															goto IL_0667;
																														case 1:
																															goto IL_0672;
																														case 2:
																														case 25:
																															goto IL_067d;
																														case 50:
																															goto IL_068d;
																														case 83:
																															goto IL_0698;
																														case 9:
																														case 111:
																															goto IL_06a3;
																														case 8:
																														case 14:
																														case 16:
																														case 17:
																														case 33:
																														case 37:
																														case 52:
																														case 56:
																														case 57:
																														case 58:
																														case 65:
																														case 66:
																														case 68:
																														case 78:
																														case 80:
																														case 85:
																														case 94:
																														case 98:
																														case 115:
																															goto end_IL_020d;
																														case 3:
																															goto IL_06df;
																														case 71:
																															goto IL_06ed;
																														case 96:
																															goto IL_06fb;
																														case 12:
																														case 20:
																														case 21:
																														case 22:
																														case 59:
																														case 62:
																														case 73:
																														case 92:
																														case 93:
																														case 97:
																														case 100:
																														case 107:
																														case 117:
																															goto end_IL_02a0;
																														case 116:
																															goto end_IL_0709;
																														case 44:
																															goto end_IL_071c;
																														case 28:
																															goto end_IL_0726;
																														case 46:
																															goto end_IL_0731;
																														case 51:
																															goto end_IL_0746;
																														case 23:
																														case 43:
																															goto end_IL_075b;
																														case 60:
																															goto end_IL_076b;
																														case 19:
																														case 108:
																															goto end_IL_077b;
																														case 29:
																															goto end_IL_078b;
																														case 30:
																															goto end_IL_079b;
																														case 13:
																														case 112:
																															goto IL_07b6;
																														}
																														continue;
																														end_IL_020d:
																														break;
																													}
																													break;
																												}
																												goto IL_0312;
																												IL_035b:
																												num5++;
																												goto IL_0369;
																												IL_0369:
																												ptr2 += 8;
																												goto end_IL_02a0;
																												IL_0312:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_0320;
																												IL_0320:
																												array[num5] = 0;
																												goto IL_032e;
																												IL_032e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0351;
																												IL_0351:
																												array2[num5] = null;
																												goto IL_035b;
																											}
																											break;
																										}
																										goto IL_037c;
																										IL_03d3:
																										array[num5 - 2] = 0;
																										goto IL_03e7;
																										IL_037c:
																										if (4 > b)
																										{
																											break;
																										}
																										num = 74;
																										goto IL_0393;
																										IL_03e7:
																										num5--;
																										num = 12;
																										goto end_IL_02a0;
																										IL_0393:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03d3;
																									}
																									break;
																								}
																								goto IL_0403;
																								IL_04ec:
																								num5--;
																								goto end_IL_02a0;
																								IL_0403:
																								if (3 > b)
																								{
																									goto IL_0411;
																								}
																								goto IL_04b5;
																								IL_0411:
																								if (1 < b)
																								{
																									goto IL_041f;
																								}
																								goto IL_04a2;
																								IL_041f:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_042d;
																								IL_042d:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_043b;
																								IL_043b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_047b;
																								IL_047b:
																								array[num5 - 2] = 0;
																								goto IL_048f;
																								IL_048f:
																								num5--;
																								goto end_IL_02a0;
																								IL_04a2:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_04b5:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04de;
																								IL_04de:
																								ptr2 += 8;
																								goto IL_04ec;
																							}
																							break;
																						}
																						goto IL_02ab;
																						IL_02ff:
																						num5--;
																						goto end_IL_02a0;
																						IL_02ab:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02eb;
																						IL_02eb:
																						array[num5 - 2] = 0;
																						goto IL_02ff;
																					}
																					break;
																				}
																				goto IL_04ff;
																				IL_0698:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_06a3;
																				IL_04ff:
																				if (9 >= b)
																				{
																					goto IL_050d;
																				}
																				goto IL_0667;
																				IL_050d:
																				if (9 > b)
																				{
																					goto IL_051b;
																				}
																				num = 15;
																				goto IL_0614;
																				IL_051b:
																				if (7 < b)
																				{
																					goto IL_0529;
																				}
																				goto IL_05ac;
																				IL_0529:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0537;
																				IL_0537:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0545;
																				IL_0545:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0585;
																				IL_0585:
																				array[num5 - 2] = 0;
																				goto IL_0599;
																				IL_0599:
																				num5--;
																				goto end_IL_02a0;
																				IL_05ac:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05ba;
																				IL_05ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05d3;
																				IL_05d3:
																				array[num5] = 0;
																				goto IL_05e1;
																				IL_05e1:
																				num5++;
																				goto IL_05ef;
																				IL_05ef:
																				ptr2 += 8;
																				num = 22;
																				goto end_IL_02a0;
																				IL_06a3:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a0;
																				IL_0614:
																				array[num5] = 0;
																				goto IL_0622;
																				IL_0622:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)MetadataSectionDependentOSDataPartitioner[*(int*)(ptr2 + num3)])();
																				goto IL_0646;
																				IL_0646:
																				num5++;
																				goto IL_0654;
																				IL_0654:
																				ptr2 += 8;
																				goto end_IL_02a0;
																				IL_0667:
																				if (10 >= b)
																				{
																					goto IL_0672;
																				}
																				goto IL_068d;
																				IL_0672:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_067d;
																				IL_067d:
																				num5--;
																				goto end_IL_02a0;
																				IL_068d:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0698;
																			}
																			break;
																			IL_0270:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06df;
																	IL_06fb:
																	ptr2 += 8;
																	goto end_IL_02a0;
																	IL_06ed:
																	num5++;
																	goto IL_06fb;
																	IL_06df:
																	array[num5] = 0;
																	goto IL_06ed;
																	continue;
																	end_IL_0280:
																	break;
																}
																continue;
																end_IL_0290:
																break;
															}
															continue;
															end_IL_02a0:
															break;
														}
														continue;
													}
													goto IL_07b6;
													IL_07b6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0709:
													break;
												}
												continue;
												end_IL_071c:
												break;
											}
											continue;
											end_IL_0726:
											break;
										}
										continue;
										end_IL_0731:
										break;
									}
									continue;
									end_IL_0746:
									break;
								}
								continue;
								end_IL_075b:
								break;
							}
							continue;
							end_IL_076b:
							break;
						}
						continue;
						end_IL_077b:
						break;
					}
					continue;
					end_IL_078b:
					break;
				}
				continue;
				end_IL_079b:
				break;
			}
		}
	}

	private static int smethod_7(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private static void ExpandPrimeGenericArraySortHelper(Class157 class157_1)
	{
		class157_1.method_0();
	}
}
