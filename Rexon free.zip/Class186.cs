using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Loud Hand Taps", "Rig", "Hand taps play at max volume.", false, 40, ModType.const_0, false)]
internal class Class186 : MonoBehaviour
{
	private float float_0;

	private static int int_0;

	private static float float_1;

	private static bool bool_0;

	private static int int_1;

	private static double double_0;

	private static float float_2;

	private static double double_1;

	private static IntPtr[] GetTypeInfoCountIReflectableType;

	private static IntPtr[] SafeProcessHandleConcurrentExclusiveSchedulerPair;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_093f, IL_0952, IL_0965, IL_0975, IL_0985, IL_0995, IL_09a5, IL_09b5, IL_09c9, IL_09d4, IL_09e7, IL_09f7, IL_0a05, IL_0a13, IL_0a23, IL_0a63, IL_0a7c, IL_0a87, IL_0a9a, IL_0aa5, IL_0ab5, IL_0ac3, IL_0ad6, IL_0ae4, IL_0aef, IL_0afd, IL_0b06, IL_0b14, IL_0b28, IL_0b6c, IL_0b7a, IL_0b8d, IL_0b9b, IL_0baf, IL_0c2f, IL_0c42, IL_0c50, IL_0c5e, IL_0c6c, IL_0c7f, IL_0cdf, IL_0ced, IL_0d00, IL_0d0e, IL_0d21, IL_0d2f, IL_0d3a, IL_0d63, IL_0d7c, IL_0d8f, IL_0d9a, IL_0dcd, IL_0de0, IL_0dee, IL_0e0c, IL_0e1a, IL_0e2d, IL_0e41, IL_0e80, IL_0e93, IL_0ed9, IL_0eec, IL_0eff, IL_0f12, IL_0f20, IL_0f2e, IL_0f3c, IL_0f4f, IL_0f5d, IL_0f79, IL_0f87, IL_0f95, IL_0fa3, IL_0fae, IL_0fc2, IL_0ffa, IL_100d, IL_101b, IL_1029, IL_1037, IL_104b, IL_108a, IL_109d, IL_10a8, IL_10bb, IL_10c9, IL_10d7, IL_10e0, IL_10fd, IL_113c, IL_114f, IL_115d, IL_1170, IL_117e, IL_1189, IL_11a3, IL_11b6, IL_11c4, IL_11d2, IL_11e0, IL_1221, IL_1235, IL_1248, IL_1253, IL_1261, IL_127f, IL_128d, IL_12a0, IL_12b3, IL_12c1, IL_12cc, IL_12eb, IL_12f9, IL_130c, IL_131f, IL_132d, IL_133b, IL_1349, IL_1387, IL_139b, IL_13ae, IL_1419, IL_142c, IL_1445, IL_145d, IL_147a, IL_14b2, IL_14c5, IL_14d3, IL_14e1, IL_14eb, IL_1502, IL_1515, IL_1523, IL_1536, IL_1544, IL_1587, IL_1592, IL_15a0, IL_15c4, IL_15d2, IL_15e9, IL_15fc, IL_160a, IL_1618, IL_163c, IL_164a, IL_1658, IL_166b, IL_1679, IL_1687, IL_16b0, IL_16d2, IL_16fb, IL_1714, IL_1728, IL_177e, IL_178c, IL_179f, IL_17b2, IL_17c0, IL_17ce, IL_17dc, IL_1800, IL_180e, IL_1821, IL_185f, IL_1873, IL_1886, IL_1899, IL_18a4, IL_18b2, IL_18bb, IL_18ed, IL_1906, IL_1914, IL_191d, IL_1930, IL_1943, IL_1957, IL_196a, IL_1978, IL_1981, IL_198f, IL_19a8, IL_19bf, IL_19cd, IL_19e0, IL_1a2d, IL_1a3b, IL_1a57, IL_1a65, IL_1a79, IL_1ab1, IL_1ac4, IL_1ad8, IL_1b1c, IL_1b39, IL_1b47, IL_1b5b, IL_1b9a, IL_1bad, IL_1bbb, IL_1bc9, IL_1c37, IL_1c4a, IL_1c58, IL_1c63, IL_1c7d, IL_1c8b, IL_1ca2, IL_1cbe, IL_1ccc, IL_1cda, IL_1d18, IL_1d2c, IL_1d3f, IL_1d4d, IL_1d60, IL_1d6e, IL_1d79, IL_1d87, IL_1dc7, IL_1ddb, IL_1dee, IL_1dfc, IL_1e0a, IL_1e1e, IL_1e5d, IL_1e70, IL_1e79, IL_1e84, IL_1e98, IL_1ee0, IL_1ef3, IL_1f01, IL_1f0f, IL_1f28, IL_1f36, IL_1f44, IL_1f57, IL_1f6b, IL_1faa, IL_1fbd, IL_1fd0, IL_1fde, IL_1ff2, IL_203a, IL_204d, IL_205b, IL_2069, IL_208d, IL_20a6, IL_20b4, IL_20c2, IL_20d5, IL_20e8, IL_2128, IL_213c, IL_214f, IL_215a, IL_216e, IL_21ad, IL_21c0, IL_21ce, IL_21d7, IL_21e5, IL_21f9, IL_2238, IL_224b, IL_22a9, IL_22bc, IL_22f5, IL_2308, IL_2313, IL_2321, IL_2339, IL_2347, IL_235a, IL_2368, IL_2373, IL_2386, IL_2394, IL_239f, IL_23ad, IL_23d0, IL_23da, IL_23e8, IL_23fb, IL_2409, IL_2414, IL_2454, IL_2468, IL_247b, IL_2489, IL_2497, IL_24b0, IL_24be, IL_24cc, IL_24df, IL_24ed, IL_24fb, IL_2504, IL_252d, IL_253b, IL_254e, IL_255c, IL_2567, IL_25a7, IL_25bb, IL_25ce, IL_25dc, IL_25ea, IL_262a, IL_263e, IL_2651, IL_265f, IL_266d, IL_26ad, IL_26c1, IL_26d4, IL_26e2, IL_26f0, IL_26fe, IL_2709, IL_276b, IL_277e, IL_278c, IL_279a, IL_27da, IL_27ee, IL_2801, IL_280f, IL_281d, IL_2831, IL_2870, IL_2883, IL_2891, IL_289c, IL_28ba, IL_28c8, IL_28db, IL_28e9, IL_28f7, IL_2914, IL_2963, IL_296d, IL_299a, IL_29ae, IL_29bc, IL_29cf, IL_29da, IL_29e8, IL_2a11, IL_2a2a, IL_2a38, IL_2a46, IL_2a5e, IL_2a7c, IL_2aa0, IL_2ab8, IL_2ac8, IL_2adb, IL_2aee, IL_2af8, IL_2b03, IL_2b13, IL_2b2c, IL_2b3c, IL_2b55, IL_2b65, IL_2b75, IL_2b85, IL_2b95, IL_2ba5 are reachable both inside and outside the pinned region starting at IL_2bba. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 502;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef87 = default(int);
			ref int reference = ref __rxRef87;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2ba5:
					num2 = 1;
					while (true)
					{
						IL_2b95:
						num3 = num2 * 4;
						while (true)
						{
							IL_2b85:
							num4 = num2 * 8;
							while (true)
							{
								IL_2b75:
								array2 = new byte[7];
								while (true)
								{
									IL_2b65:
									array3 = new object[7];
									while (true)
									{
										IL_2b55:
										array4 = new int[7];
										while (true)
										{
											IL_2b3c:
											array5 = new int[7];
											num = 39;
											while (true)
											{
												IL_2b2c:
												array6 = new long[7];
												while (true)
												{
													IL_2b13:
													array7 = new object[14];
													num = 479;
													while (true)
													{
														IL_2b03:
														array7[0] = this;
														while (true)
														{
															IL_2af8:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaxTraceSetInfoClassAsBstr.getCategorygetIdentity);
															while (true)
															{
																IL_2aee:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_09b5:
																		byte b = *ptr2;
																		num = 386;
																		while (true)
																		{
																			IL_09a5:
																			ptr2++;
																			while (true)
																			{
																				IL_0995:
																				if (b >= 1)
																				{
																					while (b <= 70)
																					{
																						while (true)
																						{
																							IL_0975:
																							if (35 >= b)
																							{
																								num = 131;
																								while (true)
																								{
																									IL_0965:
																									if (35 > b)
																									{
																										while (true)
																										{
																											IL_0952:
																											if (17 >= b)
																											{
																												num = 581;
																												while (true)
																												{
																													if (num != 581)
																													{
																														if (num != 1562)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 502:
																															break;
																														default:
																															continue;
																														case 309:
																															goto IL_0952;
																														case 131:
																															goto IL_0965;
																														case 226:
																															goto IL_0975;
																														case 252:
																															goto IL_0985;
																														case 518:
																															goto IL_0995;
																														case 386:
																															goto IL_09a5;
																														case 284:
																														case 291:
																															goto IL_09b5;
																														case 7:
																															goto IL_09c9;
																														case 18:
																															goto IL_09d4;
																														case 80:
																															goto IL_09e7;
																														case 134:
																															goto IL_09f7;
																														case 4:
																															goto IL_0a05;
																														case 116:
																															goto IL_0a13;
																														case 44:
																														case 165:
																															goto IL_0a23;
																														case 104:
																															goto IL_0a63;
																														case 192:
																															goto IL_0a7c;
																														case 9:
																															goto IL_0a87;
																														case 150:
																															goto IL_0a9a;
																														case 73:
																															goto IL_0aa5;
																														case 242:
																															goto IL_0ac3;
																														case 246:
																															goto IL_0ad6;
																														case 238:
																															goto IL_0ae4;
																														case 1:
																															goto IL_0aef;
																														case 153:
																															goto IL_0b06;
																														case 79:
																														case 209:
																															goto IL_0b14;
																														case 62:
																															goto IL_0b28;
																														case 301:
																															goto IL_0b7a;
																														case 334:
																															goto IL_0b8d;
																														case 70:
																														case 317:
																															goto IL_0b9b;
																														case 22:
																															goto IL_0baf;
																														case 17:
																															goto IL_0c2f;
																														case 362:
																															goto IL_0c42;
																														case 253:
																															goto IL_0c50;
																														case 293:
																															goto IL_0c5e;
																														case 347:
																															goto IL_0c6c;
																														case 160:
																														case 381:
																															goto IL_0c7f;
																														case 390:
																															goto IL_0cdf;
																														case 389:
																															goto IL_0ced;
																														case 393:
																															goto IL_0d00;
																														case 222:
																															goto IL_0d0e;
																														case 396:
																															goto IL_0d21;
																														case 91:
																															goto IL_0d2f;
																														case 56:
																														case 138:
																															goto IL_0d3a;
																														case 280:
																															goto IL_0d63;
																														case 224:
																															goto IL_0d7c;
																														case 399:
																															goto IL_0d8f;
																														case 86:
																														case 358:
																															goto IL_0d9a;
																														case 30:
																															goto IL_0dcd;
																														case 305:
																														case 416:
																															goto IL_0de0;
																														case 194:
																															goto IL_0dee;
																														case 270:
																															goto IL_0e0c;
																														case 52:
																															goto IL_0e1a;
																														case 298:
																														case 421:
																															goto IL_0e2d;
																														case 243:
																															goto IL_0e41;
																														case 355:
																															goto IL_0e80;
																														case 118:
																														case 423:
																															goto IL_0e93;
																														case 431:
																															goto IL_0ed9;
																														case 441:
																															goto IL_0eec;
																														case 454:
																															goto IL_0eff;
																														case 459:
																															goto IL_0f12;
																														case 19:
																															goto IL_0f20;
																														case 235:
																															goto IL_0f2e;
																														case 451:
																															goto IL_0f3c;
																														case 467:
																															goto IL_0f4f;
																														case 191:
																														case 286:
																															goto IL_0f5d;
																														case 471:
																															goto IL_0f79;
																														case 277:
																															goto IL_0f87;
																														case 241:
																															goto IL_0f95;
																														case 66:
																															goto IL_0fa3;
																														case 413:
																														case 464:
																															goto IL_0fae;
																														case 323:
																															goto IL_0fc2;
																														case 162:
																															goto IL_0ffa;
																														case 460:
																															goto IL_100d;
																														case 429:
																															goto IL_101b;
																														case 327:
																															goto IL_1029;
																														case 245:
																														case 352:
																															goto IL_1037;
																														case 117:
																															goto IL_104b;
																														case 428:
																															goto IL_108a;
																														case 420:
																															goto IL_109d;
																														case 76:
																															goto IL_10a8;
																														case 249:
																															goto IL_10bb;
																														case 239:
																															goto IL_10c9;
																														case 156:
																														case 425:
																															goto IL_10e0;
																														case 55:
																															goto IL_10fd;
																														case 21:
																															goto IL_113c;
																														case 190:
																															goto IL_114f;
																														case 324:
																															goto IL_115d;
																														case 339:
																															goto IL_1170;
																														case 307:
																															goto IL_117e;
																														case 96:
																														case 186:
																															goto IL_1189;
																														case 24:
																															goto IL_11a3;
																														case 102:
																															goto IL_11b6;
																														case 213:
																															goto IL_11c4;
																														case 365:
																															goto IL_11d2;
																														case 232:
																														case 449:
																															goto IL_11e0;
																														case 169:
																															goto IL_1221;
																														case 332:
																															goto IL_1235;
																														case 90:
																															goto IL_1248;
																														case 112:
																														case 410:
																															goto IL_1253;
																														case 279:
																															goto IL_1261;
																														case 108:
																															goto IL_127f;
																														case 446:
																															goto IL_128d;
																														case 319:
																															goto IL_12a0;
																														case 36:
																															goto IL_12b3;
																														case 264:
																															goto IL_12c1;
																														case 137:
																														case 140:
																															goto IL_12cc;
																														case 48:
																															goto IL_12eb;
																														case 379:
																															goto IL_12f9;
																														case 472:
																															goto IL_130c;
																														case 481:
																															goto IL_131f;
																														case 133:
																															goto IL_132d;
																														case 82:
																															goto IL_133b;
																														case 123:
																														case 363:
																															goto IL_1349;
																														case 340:
																															goto IL_1387;
																														case 63:
																															goto IL_139b;
																														case 124:
																														case 130:
																															goto IL_13ae;
																														case 146:
																															goto IL_1419;
																														case 328:
																														case 483:
																															goto IL_142c;
																														case 480:
																														case 492:
																															goto IL_1445;
																														case 351:
																														case 498:
																															goto IL_145d;
																														case 267:
																															goto IL_147a;
																														case 380:
																															goto IL_14b2;
																														case 503:
																															goto IL_14c5;
																														case 158:
																															goto IL_14d3;
																														case 167:
																														case 268:
																															goto IL_14e1;
																														case 149:
																															goto IL_14eb;
																														case 127:
																															goto IL_1502;
																														case 511:
																															goto IL_1515;
																														case 69:
																															goto IL_1523;
																														case 513:
																															goto IL_1536;
																														case 312:
																														case 361:
																															goto IL_1544;
																														case 515:
																															goto IL_1587;
																														case 85:
																															goto IL_1592;
																														case 212:
																														case 231:
																															goto IL_15a0;
																														case 387:
																															goto IL_15c4;
																														case 256:
																															goto IL_15d2;
																														case 349:
																															goto IL_15e9;
																														case 13:
																															goto IL_15fc;
																														case 182:
																															goto IL_160a;
																														case 221:
																														case 468:
																															goto IL_1618;
																														case 164:
																															goto IL_163c;
																														case 178:
																															goto IL_164a;
																														case 470:
																															goto IL_1658;
																														case 519:
																															goto IL_166b;
																														case 161:
																															goto IL_1679;
																														case 120:
																														case 469:
																															goto IL_1687;
																														case 233:
																															goto IL_16b0;
																														case 504:
																														case 520:
																															goto IL_16d2;
																														case 490:
																															goto IL_16fb;
																														case 234:
																														case 526:
																															goto IL_1714;
																														case 522:
																															goto IL_1728;
																														case 200:
																															goto IL_177e;
																														case 141:
																															goto IL_178c;
																														case 527:
																															goto IL_179f;
																														case 530:
																															goto IL_17b2;
																														case 32:
																															goto IL_17c0;
																														case 23:
																														case 223:
																															goto IL_17ce;
																														case 47:
																															goto IL_17dc;
																														case 434:
																															goto IL_1800;
																														case 125:
																															goto IL_180e;
																														case 20:
																														case 531:
																															goto IL_1821;
																														case 337:
																															goto IL_185f;
																														case 248:
																															goto IL_1873;
																														case 532:
																															goto IL_1886;
																														case 533:
																															goto IL_1899;
																														case 482:
																															goto IL_18a4;
																														case 189:
																														case 272:
																															goto IL_18bb;
																														case 170:
																															goto IL_18ed;
																														case 262:
																															goto IL_1906;
																														case 335:
																															goto IL_191d;
																														case 536:
																															goto IL_1930;
																														case 538:
																															goto IL_1943;
																														case 329:
																															goto IL_1957;
																														case 540:
																															goto IL_196a;
																														case 385:
																															goto IL_1981;
																														case 25:
																														case 278:
																															goto IL_198f;
																														case 8:
																															goto IL_19a8;
																														case 215:
																															goto IL_19bf;
																														case 350:
																															goto IL_19cd;
																														case 541:
																															goto IL_19e0;
																														case 326:
																															goto IL_1a2d;
																														case 174:
																															goto IL_1a3b;
																														case 544:
																															goto IL_1a57;
																														case 171:
																														case 487:
																															goto IL_1a65;
																														case 58:
																															goto IL_1a79;
																														case 26:
																															goto IL_1ab1;
																														case 219:
																														case 550:
																															goto IL_1ac4;
																														case 330:
																															goto IL_1ad8;
																														case 75:
																														case 553:
																															goto IL_1b1c;
																														case 554:
																															goto IL_1b39;
																														case 88:
																														case 510:
																															goto IL_1b47;
																														case 537:
																															goto IL_1b5b;
																														case 376:
																															goto IL_1b9a;
																														case 556:
																															goto IL_1bad;
																														case 398:
																															goto IL_1bbb;
																														case 129:
																														case 551:
																															goto IL_1bc9;
																														case 315:
																															goto IL_1c37;
																														case 163:
																															goto IL_1c4a;
																														case 51:
																															goto IL_1c58;
																														case 5:
																														case 299:
																															goto IL_1c63;
																														case 236:
																															goto IL_1c7d;
																														case 318:
																															goto IL_1c8b;
																														case 255:
																															goto IL_1ca2;
																														case 31:
																															goto IL_1cbe;
																														case 285:
																															goto IL_1ccc;
																														case 202:
																														case 313:
																															goto IL_1cda;
																														case 183:
																															goto IL_1d18;
																														case 107:
																															goto IL_1d2c;
																														case 345:
																															goto IL_1d3f;
																														case 84:
																															goto IL_1d4d;
																														case 207:
																															goto IL_1d60;
																														case 388:
																															goto IL_1d6e;
																														case 128:
																															goto IL_1d79;
																														case 154:
																														case 374:
																															goto IL_1d87;
																														case 204:
																															goto IL_1dc7;
																														case 217:
																															goto IL_1ddb;
																														case 83:
																															goto IL_1dee;
																														case 507:
																															goto IL_1dfc;
																														case 333:
																														case 491:
																															goto IL_1e0a;
																														case 529:
																															goto IL_1e1e;
																														case 477:
																															goto IL_1e5d;
																														case 383:
																															goto IL_1e79;
																														case 450:
																														case 512:
																															goto IL_1e84;
																														case 433:
																															goto IL_1e98;
																														case 466:
																															goto IL_1ee0;
																														case 435:
																															goto IL_1ef3;
																														case 59:
																															goto IL_1f01;
																														case 115:
																														case 444:
																															goto IL_1f0f;
																														case 42:
																															goto IL_1f28;
																														case 373:
																															goto IL_1f36;
																														case 254:
																															goto IL_1f44;
																														case 210:
																														case 557:
																															goto IL_1f57;
																														case 136:
																															goto IL_1f6b;
																														case 461:
																															goto IL_1faa;
																														case 559:
																															goto IL_1fbd;
																														case 560:
																															goto IL_1fd0;
																														case 273:
																														case 346:
																															goto IL_1fde;
																														case 71:
																															goto IL_1ff2;
																														case 525:
																															goto IL_203a;
																														case 563:
																															goto IL_204d;
																														case 2:
																														case 38:
																															goto IL_205b;
																														case 139:
																															goto IL_2069;
																														case 95:
																															goto IL_208d;
																														case 564:
																															goto IL_20a6;
																														case 405:
																															goto IL_20b4;
																														case 336:
																															goto IL_20c2;
																														case 565:
																															goto IL_20d5;
																														case 548:
																														case 566:
																															goto IL_20e8;
																														case 53:
																															goto IL_2128;
																														case 424:
																															goto IL_213c;
																														case 568:
																															goto IL_214f;
																														case 214:
																														case 302:
																															goto IL_215a;
																														case 29:
																															goto IL_216e;
																														case 282:
																															goto IL_21ad;
																														case 11:
																															goto IL_21c0;
																														case 476:
																															goto IL_21d7;
																														case 65:
																														case 89:
																															goto IL_21e5;
																														case 343:
																															goto IL_21f9;
																														case 375:
																															goto IL_2238;
																														case 14:
																														case 571:
																															goto IL_224b;
																														case 296:
																															goto IL_22a9;
																														case 311:
																														case 573:
																															goto IL_22bc;
																														case 237:
																															goto IL_22f5;
																														case 258:
																														case 438:
																															goto IL_2313;
																														case 353:
																															goto IL_2321;
																														case 257:
																															goto IL_2339;
																														case 473:
																															goto IL_2347;
																														case 370:
																															goto IL_235a;
																														case 218:
																															goto IL_2368;
																														case 41:
																														case 220:
																															goto IL_2373;
																														case 539:
																															goto IL_2386;
																														case 300:
																															goto IL_2394;
																														case 436:
																														case 558:
																															goto IL_239f;
																														case 33:
																															goto IL_23ad;
																														case 101:
																															goto IL_23d0;
																														case 122:
																															goto IL_23da;
																														case 509:
																															goto IL_23e8;
																														case 574:
																															goto IL_23fb;
																														case 43:
																															goto IL_2409;
																														case 109:
																														case 497:
																															goto IL_2414;
																														case 15:
																															goto IL_2454;
																														case 287:
																															goto IL_2468;
																														case 197:
																															goto IL_247b;
																														case 422:
																															goto IL_2489;
																														case 179:
																														case 261:
																															goto IL_2497;
																														case 442:
																															goto IL_24b0;
																														case 404:
																															goto IL_24be;
																														case 569:
																															goto IL_24cc;
																														case 126:
																															goto IL_24df;
																														case 542:
																															goto IL_24ed;
																														case 34:
																														case 528:
																															goto IL_2504;
																														case 61:
																															goto IL_252d;
																														case 486:
																															goto IL_253b;
																														case 111:
																															goto IL_254e;
																														case 395:
																															goto IL_255c;
																														case 344:
																														case 357:
																															goto IL_2567;
																														case 16:
																															goto IL_25a7;
																														case 341:
																															goto IL_25bb;
																														case 78:
																															goto IL_25ce;
																														case 359:
																															goto IL_25dc;
																														case 54:
																														case 99:
																															goto IL_25ea;
																														case 432:
																															goto IL_262a;
																														case 493:
																															goto IL_263e;
																														case 314:
																															goto IL_2651;
																														case 462:
																															goto IL_265f;
																														case 144:
																														case 495:
																															goto IL_266d;
																														case 105:
																															goto IL_26ad;
																														case 250:
																															goto IL_26c1;
																														case 93:
																															goto IL_26d4;
																														case 524:
																															goto IL_26e2;
																														case 360:
																															goto IL_26f0;
																														case 417:
																															goto IL_26fe;
																														case 331:
																														case 494:
																															goto IL_2709;
																														case 516:
																															goto IL_276b;
																														case 259:
																															goto IL_277e;
																														case 514:
																															goto IL_278c;
																														case 157:
																														case 391:
																															goto IL_279a;
																														case 552:
																															goto IL_27da;
																														case 369:
																															goto IL_27ee;
																														case 545:
																															goto IL_2801;
																														case 203:
																															goto IL_280f;
																														case 106:
																														case 266:
																															goto IL_281d;
																														case 403:
																															goto IL_2831;
																														case 508:
																															goto IL_2870;
																														case 57:
																															goto IL_2883;
																														case 6:
																															goto IL_2891;
																														case 92:
																														case 269:
																															goto IL_289c;
																														case 295:
																															goto IL_28ba;
																														case 400:
																															goto IL_28c8;
																														case 68:
																															goto IL_28db;
																														case 406:
																															goto IL_28e9;
																														case 181:
																														case 430:
																															goto IL_28f7;
																														case 478:
																															goto IL_29ae;
																														case 401:
																															goto IL_29bc;
																														case 152:
																															goto IL_29cf;
																														case 176:
																															goto IL_29da;
																														case 274:
																														case 372:
																															goto IL_29e8;
																														case 97:
																															goto IL_2a11;
																														case 77:
																															goto IL_2a2a;
																														case 415:
																															goto IL_2a38;
																														case 275:
																														case 292:
																															goto IL_2a46;
																														case 453:
																															goto IL_2a5e;
																														case 310:
																															goto IL_2a7c;
																														case 81:
																															goto IL_2aa0;
																														case 35:
																															goto IL_2ab8;
																														case 3:
																														case 45:
																														case 49:
																														case 50:
																														case 60:
																														case 64:
																														case 67:
																														case 72:
																														case 74:
																														case 100:
																														case 110:
																														case 114:
																														case 132:
																														case 143:
																														case 145:
																														case 147:
																														case 151:
																														case 155:
																														case 159:
																														case 166:
																														case 168:
																														case 172:
																														case 175:
																														case 184:
																														case 185:
																														case 187:
																														case 193:
																														case 196:
																														case 198:
																														case 206:
																														case 216:
																														case 227:
																														case 240:
																														case 244:
																														case 247:
																														case 260:
																														case 263:
																														case 271:
																														case 276:
																														case 281:
																														case 289:
																														case 290:
																														case 294:
																														case 297:
																														case 320:
																														case 321:
																														case 322:
																														case 348:
																														case 364:
																														case 367:
																														case 371:
																														case 377:
																														case 384:
																														case 402:
																														case 407:
																														case 408:
																														case 409:
																														case 418:
																														case 427:
																														case 439:
																														case 445:
																														case 448:
																														case 455:
																														case 456:
																														case 474:
																														case 475:
																														case 485:
																														case 489:
																														case 517:
																														case 521:
																														case 534:
																														case 543:
																														case 555:
																															goto end_IL_0985;
																														case 0:
																														case 10:
																														case 12:
																														case 27:
																														case 28:
																														case 37:
																														case 40:
																														case 87:
																														case 94:
																														case 98:
																														case 103:
																														case 113:
																														case 119:
																														case 121:
																														case 135:
																														case 142:
																														case 148:
																														case 173:
																														case 177:
																														case 188:
																														case 195:
																														case 199:
																														case 201:
																														case 205:
																														case 208:
																														case 211:
																														case 225:
																														case 228:
																														case 229:
																														case 251:
																														case 265:
																														case 283:
																														case 288:
																														case 303:
																														case 304:
																														case 306:
																														case 308:
																														case 316:
																														case 325:
																														case 338:
																														case 342:
																														case 354:
																														case 356:
																														case 368:
																														case 378:
																														case 382:
																														case 392:
																														case 397:
																														case 412:
																														case 414:
																														case 419:
																														case 437:
																														case 443:
																														case 452:
																														case 457:
																														case 458:
																														case 463:
																														case 465:
																														case 484:
																														case 488:
																														case 496:
																														case 499:
																														case 500:
																														case 505:
																														case 523:
																														case 535:
																														case 547:
																														case 549:
																														case 561:
																														case 562:
																														case 567:
																														case 570:
																														case 572:
																															goto end_IL_093f;
																														case 411:
																															goto IL_2aee;
																														case 440:
																															goto IL_2af8;
																														case 479:
																															goto IL_2b03;
																														case 394:
																															goto IL_2b13;
																														case 39:
																															goto IL_2b2c;
																														case 180:
																															goto IL_2b3c;
																														case 366:
																															goto IL_2b55;
																														case 506:
																															goto IL_2b65;
																														case 426:
																															goto IL_2b75;
																														case 447:
																															goto IL_2b85;
																														case 546:
																															goto IL_2b95;
																														case 501:
																															goto IL_2ba5;
																														case 46:
																														case 230:
																															return;
																														}
																														goto end_IL_2adb;
																													}
																													if (17 <= b)
																													{
																														goto IL_2313;
																													}
																													goto IL_235a;
																													IL_2a2a:
																													if (16 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_2a38;
																													IL_2a46:
																													array2[num6] = array2[num6 - 1];
																													goto IL_2a5e;
																													IL_2a38:
																													if (16 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_2a46;
																													IL_2313:
																													array2[num6] = 5;
																													goto IL_2321;
																													IL_2321:
																													array3[num6] = array7[*(int*)(ptr2 + num3)];
																													goto IL_2339;
																													IL_2339:
																													num6++;
																													goto IL_2347;
																													IL_2347:
																													ptr2 += 8;
																													break;
																													IL_235a:
																													if (8 >= b)
																													{
																														goto IL_2368;
																													}
																													goto IL_26d4;
																													IL_2368:
																													if (8 <= b)
																													{
																														goto IL_2373;
																													}
																													goto IL_2386;
																													IL_2373:
																													num6--;
																													break;
																													IL_2386:
																													if (4 >= b)
																													{
																														goto IL_2394;
																													}
																													goto IL_254e;
																													IL_2394:
																													if (4 <= b)
																													{
																														goto IL_239f;
																													}
																													goto IL_23fb;
																													IL_239f:
																													array2[num6] = 0;
																													goto IL_23ad;
																													IL_23ad:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																													goto IL_23d0;
																													IL_23d0:
																													array3[num6] = null;
																													goto IL_23da;
																													IL_23da:
																													num6++;
																													goto IL_23e8;
																													IL_23e8:
																													ptr2 += 8;
																													break;
																													IL_23fb:
																													if (2 >= b)
																													{
																														goto IL_2409;
																													}
																													goto IL_24df;
																													IL_2409:
																													if (2 <= b)
																													{
																														goto IL_2414;
																													}
																													goto IL_247b;
																													IL_2414:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_2454;
																													IL_2454:
																													array2[num6 - 2] = 0;
																													goto IL_2468;
																													IL_2468:
																													num6--;
																													break;
																													IL_247b:
																													if (1 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_2489;
																													IL_2489:
																													if (1 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_2497;
																													IL_2497:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																													goto IL_24b0;
																													IL_24b0:
																													array2[num6] = 0;
																													goto IL_24be;
																													IL_24be:
																													num6++;
																													goto IL_24cc;
																													IL_24cc:
																													ptr2 += 8;
																													break;
																													IL_24df:
																													if (3 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_24ed;
																													IL_24ed:
																													if (3 > b)
																													{
																														goto end_IL_0985;
																													}
																													num = 34;
																													goto IL_2504;
																													IL_2a5e:
																													array4[num6 - 0] = array4[num6 - 1];
																													goto IL_2a7c;
																													IL_2504:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_252d;
																													IL_252d:
																													ptr2 += 8;
																													goto IL_253b;
																													IL_253b:
																													num6--;
																													break;
																													IL_254e:
																													if (6 >= b)
																													{
																														goto IL_255c;
																													}
																													goto IL_2651;
																													IL_255c:
																													if (6 <= b)
																													{
																														goto IL_2567;
																													}
																													goto IL_25ce;
																													IL_2567:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_25a7;
																													IL_25a7:
																													array2[num6 - 2] = 0;
																													goto IL_25bb;
																													IL_25bb:
																													num6--;
																													break;
																													IL_25ce:
																													if (5 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_25dc;
																													IL_25dc:
																													if (5 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_25ea;
																													IL_25ea:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_262a;
																													IL_262a:
																													array2[num6 - 2] = 0;
																													goto IL_263e;
																													IL_263e:
																													num6--;
																													break;
																													IL_2651:
																													if (7 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_265f;
																													IL_265f:
																													if (7 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_266d;
																													IL_266d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_26ad;
																													IL_26ad:
																													array2[num6 - 2] = 0;
																													goto IL_26c1;
																													IL_26c1:
																													num6--;
																													break;
																													IL_26d4:
																													if (12 >= b)
																													{
																														goto IL_26e2;
																													}
																													goto IL_2883;
																													IL_26e2:
																													if (12 <= b)
																													{
																														break;
																													}
																													goto IL_26f0;
																													IL_26f0:
																													if (10 >= b)
																													{
																														goto IL_26fe;
																													}
																													goto IL_2801;
																													IL_26fe:
																													if (10 <= b)
																													{
																														goto IL_2709;
																													}
																													goto IL_277e;
																													IL_2709:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_276b;
																													IL_276b:
																													num6 -= 2;
																													break;
																													IL_277e:
																													if (9 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_278c;
																													IL_278c:
																													if (9 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_279a;
																													IL_279a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_27da;
																													IL_27da:
																													array2[num6 - 2] = 0;
																													goto IL_27ee;
																													IL_27ee:
																													num6--;
																													break;
																													IL_2801:
																													if (11 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_280f;
																													IL_280f:
																													if (11 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_281d;
																													IL_281d:
																													array2[num6 - 1] = 0;
																													goto IL_2831;
																													IL_2831:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_2870;
																													IL_2870:
																													ptr2 += 8;
																													break;
																													IL_2883:
																													if (14 >= b)
																													{
																														goto IL_2891;
																													}
																													goto IL_29cf;
																													IL_2891:
																													if (14 <= b)
																													{
																														goto IL_289c;
																													}
																													goto IL_28db;
																													IL_289c:
																													array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																													goto IL_28ba;
																													IL_28ba:
																													ptr2 += 8;
																													goto IL_28c8;
																													IL_28c8:
																													num6--;
																													break;
																													IL_28db:
																													if (13 < b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_28e9;
																													IL_28e9:
																													if (13 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_28f7;
																													IL_28f7:
																													array8 = array3;
																													num7 = num6;
																													if (array == null)
																													{
																														goto IL_2906;
																													}
																													num8 = ptr2;
																													byte b2 = *num8;
																													ptr2 = num8 + 4;
																													int num9 = *(int*)(ptr2 + num3);
																													ptr2 += 8;
																													byte* ptr3 = ptr2 + num9;
																													byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																													while (ptr2 != ptr3)
																													{
																														*ptr4 = (byte)(*ptr2 ^ b2);
																														ptr2++;
																														ptr4++;
																													}
																													array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																													goto IL_29ae;
																													IL_2a7c:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_2aa0;
																													IL_2aa0:
																													array3[num6] = array3[num6 - 1];
																													goto IL_2ab8;
																													IL_2ab8:
																													num6++;
																													break;
																													IL_29ae:
																													array2[num6] = 5;
																													goto IL_29bc;
																													IL_29bc:
																													num6++;
																													break;
																													IL_29cf:
																													if (15 >= b)
																													{
																														goto IL_29da;
																													}
																													goto IL_2a2a;
																													IL_29da:
																													if (15 > b)
																													{
																														goto end_IL_0985;
																													}
																													goto IL_29e8;
																													IL_29e8:
																													array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													goto IL_2a11;
																													IL_2a11:
																													array2[num6 - 1] = 5;
																													break;
																													continue;
																													end_IL_093f:
																													break;
																												}
																												break;
																											}
																											goto IL_09f7;
																											IL_1f01:
																											if (31 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1f0f;
																											IL_1f0f:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																											goto IL_1f28;
																											IL_09f7:
																											if (26 >= b)
																											{
																												goto IL_0a05;
																											}
																											goto IL_1bad;
																											IL_0a05:
																											if (26 > b)
																											{
																												goto IL_0a13;
																											}
																											goto IL_1b1c;
																											IL_0a13:
																											if (21 < b)
																											{
																												goto IL_0a7c;
																											}
																											goto IL_0f12;
																											IL_0a7c:
																											if (23 < b)
																											{
																												goto IL_0a87;
																											}
																											goto IL_0a9a;
																											IL_0a87:
																											if (24 >= b)
																											{
																												goto IL_0f4f;
																											}
																											goto IL_17b2;
																											IL_0f4f:
																											if (24 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_0f5d;
																											IL_0f5d:
																											num10 = ptr2;
																											num11 = -200;
																											num5 = 1;
																											ptr2 = num10 + num11;
																											break;
																											IL_17b2:
																											if (25 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_17c0;
																											IL_17c0:
																											if (25 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_17ce;
																											IL_17ce:
																											array2[num6] = 3;
																											goto IL_17dc;
																											IL_17dc:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																											goto IL_1800;
																											IL_1800:
																											num6++;
																											goto IL_180e;
																											IL_180e:
																											ptr2 += 8;
																											break;
																											IL_0a9a:
																											if (23 > b)
																											{
																												goto IL_0aa5;
																											}
																											num = 160;
																											goto IL_0c7f;
																											IL_0aa5:
																											if (22 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_0ac3;
																											IL_0ac3:
																											if (22 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_0e93;
																											IL_0e93:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																											goto IL_1943;
																											IL_1943:
																											array2[num6 - 2] = 0;
																											goto IL_1957;
																											IL_1957:
																											num6--;
																											break;
																											IL_1f28:
																											array2[num6] = 3;
																											goto IL_1f36;
																											IL_0c7f:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 536;
																											goto IL_1930;
																											IL_1930:
																											num6--;
																											break;
																											IL_0f12:
																											if (21 > b)
																											{
																												goto IL_0f20;
																											}
																											goto IL_1445;
																											IL_0f20:
																											if (19 >= b)
																											{
																												goto IL_0f2e;
																											}
																											goto IL_196a;
																											IL_0f2e:
																											if (19 > b)
																											{
																												goto IL_0f3c;
																											}
																											goto IL_145d;
																											IL_0f3c:
																											if (18 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1536;
																											IL_1536:
																											if (18 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1544;
																											IL_1544:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											goto IL_1886;
																											IL_1886:
																											num6 -= 3;
																											break;
																											IL_145d:
																											array2[num6 - 1] = 5;
																											num = 267;
																											goto IL_147a;
																											IL_147a:
																											array3[num6 - 1] = ((delegate*<string[], string>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																											goto IL_14b2;
																											IL_14b2:
																											ptr2 += 8;
																											break;
																											IL_196a:
																											if (20 < b)
																											{
																												goto end_IL_0985;
																											}
																											num = 385;
																											goto IL_1981;
																											IL_1f36:
																											num6++;
																											goto IL_1f44;
																											IL_1981:
																											if (20 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_198f;
																											IL_198f:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											goto IL_19a8;
																											IL_19a8:
																											array2[num6] = 1;
																											num = 215;
																											goto IL_19bf;
																											IL_19bf:
																											num6++;
																											goto IL_19cd;
																											IL_19cd:
																											ptr2 += 16;
																											break;
																											IL_1445:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											break;
																											IL_1b1c:
																											array3[num6] = array7[*(int*)(ptr2 + num3)];
																											goto IL_20a6;
																											IL_20a6:
																											array2[num6] = 5;
																											goto IL_20b4;
																											IL_20b4:
																											num6++;
																											goto IL_20c2;
																											IL_20c2:
																											ptr2 += 8;
																											break;
																											IL_1bad:
																											if (30 >= b)
																											{
																												goto IL_1bbb;
																											}
																											goto IL_1d60;
																											IL_1bbb:
																											if (30 <= b)
																											{
																												goto IL_1bc9;
																											}
																											goto IL_1c4a;
																											IL_1bc9:
																											ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_1c37;
																											IL_1c37:
																											num6 -= 2;
																											break;
																											IL_1c4a:
																											if (28 >= b)
																											{
																												goto IL_1c58;
																											}
																											goto IL_1d3f;
																											IL_1c58:
																											if (28 <= b)
																											{
																												goto IL_1c63;
																											}
																											goto IL_1cbe;
																											IL_1c63:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																											goto IL_1c7d;
																											IL_1c7d:
																											array2[num6] = 3;
																											goto IL_1c8b;
																											IL_1c8b:
																											num6++;
																											num = 255;
																											goto IL_1ca2;
																											IL_1ca2:
																											ptr2 += 8;
																											num = 412;
																											break;
																											IL_1cbe:
																											if (27 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1ccc;
																											IL_1ccc:
																											if (27 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1cda;
																											IL_1cda:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class186, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((Class186)array3[num6 - 1]);
																											goto IL_1d18;
																											IL_1d18:
																											array2[num6 - 1] = 3;
																											goto IL_1d2c;
																											IL_1d2c:
																											ptr2 += 8;
																											break;
																											IL_1d3f:
																											if (29 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1d4d;
																											IL_1d4d:
																											if (29 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_20e8;
																											IL_20e8:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_2128;
																											IL_2128:
																											array2[num6 - 2] = 3;
																											goto IL_213c;
																											IL_213c:
																											num6--;
																											break;
																											IL_1d60:
																											if (32 < b)
																											{
																												goto IL_1d6e;
																											}
																											num = 383;
																											goto IL_1e79;
																											IL_1d6e:
																											if (33 >= b)
																											{
																												goto IL_1d79;
																											}
																											goto IL_1dee;
																											IL_1d79:
																											if (33 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1d87;
																											IL_1d87:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1dc7;
																											IL_1dc7:
																											array2[num6 - 2] = 3;
																											goto IL_1ddb;
																											IL_1ddb:
																											num6--;
																											break;
																											IL_1dee:
																											if (34 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1dfc;
																											IL_1dfc:
																											if (34 > b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1e0a;
																											IL_1e0a:
																											array2[num6 - 1] = 0;
																											goto IL_1e1e;
																											IL_1e1e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1e5d;
																											IL_1e5d:
																											ptr2 += 8;
																											break;
																											IL_1f44:
																											ptr2 += 16;
																											break;
																											IL_1e79:
																											if (32 <= b)
																											{
																												goto IL_1e84;
																											}
																											goto IL_1ef3;
																											IL_1e84:
																											array2[num6 - 1] = 3;
																											goto IL_1e98;
																											IL_1e98:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											num = 466;
																											goto IL_1ee0;
																											IL_1ee0:
																											ptr2 += 8;
																											break;
																											IL_1ef3:
																											if (31 < b)
																											{
																												goto end_IL_0985;
																											}
																											goto IL_1f01;
																										}
																										break;
																									}
																									goto IL_0de0;
																									IL_0e1a:
																									ptr2 += 8;
																									break;
																									IL_0de0:
																									array2[num6] = 5;
																									goto IL_0dee;
																									IL_0dee:
																									array3[num6] = ((delegate*<GorillaTagger>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																									goto IL_0e0c;
																									IL_0e0c:
																									num6++;
																									goto IL_0e1a;
																								}
																								break;
																							}
																							goto IL_09c9;
																							IL_15d2:
																							num6++;
																							num = 349;
																							goto IL_15e9;
																							IL_15e9:
																							ptr2 += 8;
																							break;
																							IL_09c9:
																							if (53 < b)
																							{
																								goto IL_09d4;
																							}
																							goto IL_09e7;
																							IL_09d4:
																							if (62 < b)
																							{
																								goto IL_0ad6;
																							}
																							goto IL_0b7a;
																							IL_0b7a:
																							if (62 > b)
																							{
																								goto IL_0c42;
																							}
																							goto IL_16d2;
																							IL_16d2:
																							array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																							goto IL_16fb;
																							IL_16fb:
																							array2[num6 - 1] = 5;
																							break;
																							IL_0c42:
																							if (57 >= b)
																							{
																								goto IL_0c50;
																							}
																							goto IL_0d21;
																							IL_0c50:
																							if (57 > b)
																							{
																								goto IL_0c5e;
																							}
																							goto IL_1ac4;
																							IL_0c5e:
																							if (55 < b)
																							{
																								goto IL_0c6c;
																							}
																							goto IL_0d8f;
																							IL_0c6c:
																							if (56 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1a57;
																							IL_1a57:
																							if (56 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1a65;
																							IL_1a65:
																							array2[num6 - 1] = 5;
																							goto IL_1a79;
																							IL_1a79:
																							array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
																							goto IL_1ab1;
																							IL_1ab1:
																							ptr2 += 8;
																							break;
																							IL_0d8f:
																							if (55 <= b)
																							{
																								goto IL_0d9a;
																							}
																							goto IL_0dcd;
																							IL_0d9a:
																							((Class186)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_130c;
																							IL_130c:
																							num6 -= 2;
																							break;
																							IL_0dcd:
																							if (54 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_204d;
																							IL_204d:
																							if (54 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_205b;
																							IL_205b:
																							array2[num6] = 3;
																							goto IL_2069;
																							IL_2069:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																							goto IL_208d;
																							IL_208d:
																							num6++;
																							num = 565;
																							goto IL_20d5;
																							IL_20d5:
																							ptr2 += 8;
																							break;
																							IL_1ac4:
																							array2[num6 - 1] = 3;
																							goto IL_1ad8;
																							IL_1ad8:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1fbd;
																							IL_1fbd:
																							ptr2 += 8;
																							break;
																							IL_0d21:
																							if (59 >= b)
																							{
																								goto IL_0d2f;
																							}
																							goto IL_1899;
																							IL_0d2f:
																							if (59 <= b)
																							{
																								goto IL_0d3a;
																							}
																							goto IL_0d7c;
																							IL_0d3a:
																							array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0d63;
																							IL_0d63:
																							array2[num6 - 1] = 5;
																							break;
																							IL_0d7c:
																							if (58 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1fd0;
																							IL_1fd0:
																							if (58 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1fde;
																							IL_1fde:
																							array2[num6 - 1] = 0;
																							goto IL_1ff2;
																							IL_1ff2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							num = 525;
																							goto IL_203a;
																							IL_203a:
																							ptr2 += 8;
																							break;
																							IL_1899:
																							if (60 >= b)
																							{
																								goto IL_18a4;
																							}
																							goto IL_1906;
																							IL_18a4:
																							if (60 > b)
																							{
																								goto end_IL_0985;
																							}
																							num = 272;
																							goto IL_18bb;
																							IL_15fc:
																							if (52 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_160a;
																							IL_18bb:
																							array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 170;
																							goto IL_18ed;
																							IL_18ed:
																							array2[num6 - 1] = 5;
																							break;
																							IL_1906:
																							if (61 < b)
																							{
																								goto end_IL_0985;
																							}
																							num = 335;
																							goto IL_191d;
																							IL_160a:
																							if (52 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1618;
																							IL_191d:
																							if (61 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_22bc;
																							IL_22bc:
																							((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
																							goto IL_22f5;
																							IL_22f5:
																							num6 -= 3;
																							break;
																							IL_0ad6:
																							if (66 < b)
																							{
																								goto IL_0ae4;
																							}
																							goto IL_0b8d;
																							IL_0ae4:
																							if (68 < b)
																							{
																								goto IL_0aef;
																							}
																							num = 568;
																							goto IL_214f;
																							IL_0aef:
																							if (69 >= b)
																							{
																								num = 153;
																								goto IL_0b06;
																							}
																							goto IL_1515;
																							IL_163c:
																							array2[num6] = 0;
																							goto IL_164a;
																							IL_0b06:
																							if (69 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_0b14;
																							IL_0b14:
																							array2[num6 - 1] = 3;
																							goto IL_0b28;
																							IL_0b28:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0eec;
																							IL_0eec:
																							ptr2 += 8;
																							break;
																							IL_1515:
																							if (70 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1523;
																							IL_1523:
																							if (70 > b)
																							{
																							}
																							goto end_IL_0985;
																							IL_1618:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_163c;
																							IL_214f:
																							if (68 <= b)
																							{
																								goto IL_215a;
																							}
																							goto IL_21c0;
																							IL_215a:
																							array2[num6 - 1] = 3;
																							goto IL_216e;
																							IL_216e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_21ad;
																							IL_21ad:
																							ptr2 += 8;
																							break;
																							IL_21c0:
																							if (67 < b)
																							{
																								goto end_IL_0985;
																							}
																							num = 476;
																							goto IL_21d7;
																							IL_164a:
																							num6++;
																							goto IL_1658;
																							IL_21d7:
																							if (67 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_21e5;
																							IL_21e5:
																							array2[num6 - 1] = 3;
																							goto IL_21f9;
																							IL_21f9:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_2238;
																							IL_2238:
																							ptr2 += 8;
																							break;
																							IL_0b8d:
																							if (66 <= b)
																							{
																								goto IL_0b9b;
																							}
																							goto IL_0c2f;
																							IL_0b9b:
																							array2[num6 - 4] = 0;
																							goto IL_0baf;
																							IL_0baf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																							goto IL_0cdf;
																							IL_0cdf:
																							num6 -= 3;
																							goto IL_0ced;
																							IL_0ced:
																							ptr2 += 8;
																							break;
																							IL_0c2f:
																							if (64 >= b)
																							{
																								goto IL_0d00;
																							}
																							goto IL_166b;
																							IL_0d00:
																							if (64 > b)
																							{
																								goto IL_0d0e;
																							}
																							goto IL_0e2d;
																							IL_0d0e:
																							if (63 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_0ed9;
																							IL_0ed9:
																							if (63 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1f57;
																							IL_1f57:
																							array2[num6 - 1] = 3;
																							goto IL_1f6b;
																							IL_1f6b:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1faa;
																							IL_1faa:
																							ptr2 += 8;
																							break;
																							IL_0e2d:
																							array2[num6 - 1] = 0;
																							goto IL_0e41;
																							IL_0e41:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0e80;
																							IL_0e80:
																							ptr2 += 8;
																							break;
																							IL_166b:
																							if (65 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1679;
																							IL_1679:
																							if (65 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1687;
																							IL_1687:
																							array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_16b0;
																							IL_16b0:
																							array2[num6 - 1] = 5;
																							num = 443;
																							break;
																							IL_09e7:
																							if (53 <= b)
																							{
																								goto IL_0a23;
																							}
																							goto IL_0f79;
																							IL_0a23:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) | *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0a63;
																							IL_0a63:
																							array2[num6 - 2] = 0;
																							goto IL_0eff;
																							IL_0eff:
																							num6--;
																							break;
																							IL_0f79:
																							if (44 >= b)
																							{
																								goto IL_0f87;
																							}
																							goto IL_1170;
																							IL_0f87:
																							if (44 > b)
																							{
																								goto IL_0f95;
																							}
																							goto IL_224b;
																							IL_0f95:
																							if (39 >= b)
																							{
																								goto IL_0fa3;
																							}
																							goto IL_109d;
																							IL_0fa3:
																							if (39 <= b)
																							{
																								goto IL_0fae;
																							}
																							goto IL_100d;
																							IL_0fae:
																							array2[num6 - 1] = 5;
																							goto IL_0fc2;
																							IL_0fc2:
																							array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																							goto IL_0ffa;
																							IL_0ffa:
																							ptr2 += 8;
																							break;
																							IL_100d:
																							if (37 < b)
																							{
																								goto IL_101b;
																							}
																							goto IL_131f;
																							IL_101b:
																							if (38 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1029;
																							IL_1029:
																							if (38 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1037;
																							IL_1037:
																							array2[num6 - 1] = 3;
																							goto IL_104b;
																							IL_104b:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_108a;
																							IL_108a:
																							ptr2 += 8;
																							break;
																							IL_131f:
																							if (37 > b)
																							{
																								goto IL_132d;
																							}
																							goto IL_13ae;
																							IL_132d:
																							if (36 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_133b;
																							IL_133b:
																							if (36 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1349;
																							IL_1349:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<GorillaTagger, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																							goto IL_1387;
																							IL_1387:
																							array2[num6 - 1] = 3;
																							goto IL_139b;
																							IL_139b:
																							ptr2 += 8;
																							break;
																							IL_13ae:
																							ptr2 = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 146;
																							goto IL_1419;
																							IL_1419:
																							num6 -= 2;
																							break;
																							IL_109d:
																							if (41 >= b)
																							{
																								goto IL_10a8;
																							}
																							goto IL_10bb;
																							IL_10a8:
																							if (41 > b)
																							{
																								goto IL_14c5;
																							}
																							goto IL_1714;
																							IL_14c5:
																							if (40 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_14d3;
																							IL_14d3:
																							if (40 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_14e1;
																							IL_14e1:
																							array3[num6] = null;
																							goto IL_14eb;
																							IL_14eb:
																							array2[num6] = 5;
																							num = 127;
																							goto IL_1502;
																							IL_1502:
																							num6++;
																							break;
																							IL_1714:
																							array2[num6 - 2] = 0;
																							goto IL_1728;
																							IL_1728:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(NetworkView)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																							num = 200;
																							goto IL_177e;
																							IL_177e:
																							num6--;
																							goto IL_178c;
																							IL_178c:
																							ptr2 += 8;
																							break;
																							IL_10bb:
																							if (42 >= b)
																							{
																								goto IL_10c9;
																							}
																							goto IL_114f;
																							IL_10c9:
																							if (42 > b)
																							{
																								goto end_IL_0985;
																							}
																							num = 425;
																							goto IL_10e0;
																							IL_1658:
																							ptr2 += 8;
																							break;
																							IL_10e0:
																							array2[num6 - 1] = 3;
																							num = 55;
																							goto IL_10fd;
																							IL_10fd:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_113c;
																							IL_113c:
																							ptr2 += 8;
																							break;
																							IL_114f:
																							if (43 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_115d;
																							IL_115d:
																							if (43 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_142c;
																							IL_142c:
																							array2[num6 - 2] = 0;
																							goto IL_19e0;
																							IL_19e0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																							goto IL_1a2d;
																							IL_1a2d:
																							num6--;
																							goto IL_1a3b;
																							IL_1a3b:
																							ptr2 += 8;
																							num = 414;
																							break;
																							IL_224b:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_22a9;
																							IL_22a9:
																							num6--;
																							break;
																							IL_1170:
																							if (48 >= b)
																							{
																								goto IL_117e;
																							}
																							goto IL_12b3;
																							IL_117e:
																							if (48 <= b)
																							{
																								goto IL_1189;
																							}
																							goto IL_11b6;
																							IL_1189:
																							global::_003CModule_003E.bool_40 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																							goto IL_11a3;
																							IL_11a3:
																							num6--;
																							break;
																							IL_11b6:
																							if (46 < b)
																							{
																								goto IL_11c4;
																							}
																							goto IL_1248;
																							IL_11c4:
																							if (47 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_11d2;
																							IL_11d2:
																							if (47 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_11e0;
																							IL_11e0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_1221;
																							IL_1221:
																							array2[num6 - 2] = 0;
																							goto IL_1235;
																							IL_1235:
																							num6--;
																							break;
																							IL_1248:
																							if (46 <= b)
																							{
																								goto IL_1253;
																							}
																							goto IL_12a0;
																							IL_1253:
																							array2[num6] = 5;
																							goto IL_1261;
																							IL_1261:
																							array3[num6] = ((delegate*<GorillaTagger>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																							goto IL_127f;
																							IL_127f:
																							num6++;
																							goto IL_128d;
																							IL_128d:
																							ptr2 += 8;
																							break;
																							IL_12a0:
																							if (45 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1b39;
																							IL_1b39:
																							if (45 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1b47;
																							IL_1b47:
																							array2[num6 - 1] = 3;
																							goto IL_1b5b;
																							IL_1b5b:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1b9a;
																							IL_1b9a:
																							ptr2 += 8;
																							break;
																							IL_12b3:
																							if (50 >= b)
																							{
																								goto IL_12c1;
																							}
																							goto IL_1587;
																							IL_12c1:
																							if (50 <= b)
																							{
																								goto IL_12cc;
																							}
																							goto IL_12eb;
																							IL_12cc:
																							global::_003CModule_003E.bool_41 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
																							goto IL_179f;
																							IL_179f:
																							num6--;
																							break;
																							IL_12eb:
																							if (49 < b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_12f9;
																							IL_12f9:
																							if (49 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_1821;
																							IL_1821:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<GorillaTagger, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																							goto IL_185f;
																							IL_185f:
																							array2[num6 - 1] = 3;
																							goto IL_1873;
																							IL_1873:
																							ptr2 += 8;
																							break;
																							IL_1587:
																							if (51 >= b)
																							{
																								goto IL_1592;
																							}
																							goto IL_15fc;
																							IL_1592:
																							if (51 > b)
																							{
																								goto end_IL_0985;
																							}
																							goto IL_15a0;
																							IL_15a0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_15c4;
																							IL_15c4:
																							array2[num6] = 0;
																							goto IL_15d2;
																						}
																						goto end_IL_0995;
																						continue;
																						end_IL_0985:
																						break;
																						IL_0985:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				continue;
																				end_IL_0995:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_2adb:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_2906:
			while (true)
			{
				IL_2906_2:
				array = new byte[4];
				while (true)
				{
					IL_2914:
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_29bc_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_09b5_2:
									byte b = *ptr2;
									num = 386;
									while (true)
									{
										IL_09a5_2:
										ptr2++;
										while (true)
										{
											IL_0995_2:
											if (b >= 1)
											{
												while (b <= 70)
												{
													while (true)
													{
														IL_0975_2:
														if (35 >= b)
														{
															num = 131;
															while (true)
															{
																IL_0965_2:
																if (35 > b)
																{
																	while (true)
																	{
																		IL_0952_2:
																		if (17 >= b)
																		{
																			num = 581;
																			while (true)
																			{
																				if (num != 581)
																				{
																					if (num != 1562)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 309:
																						goto IL_0952_2;
																					case 131:
																						goto IL_0965_2;
																					case 226:
																						goto IL_0975_2;
																					case 252:
																						goto IL_0985_2;
																					case 518:
																						goto IL_0995_2;
																					case 386:
																						goto IL_09a5_2;
																					case 284:
																					case 291:
																						goto IL_09b5_2;
																					case 7:
																						goto IL_09c9_2;
																					case 18:
																						goto IL_09d4_2;
																					case 80:
																						goto IL_09e7_2;
																					case 134:
																						goto IL_09f7_2;
																					case 4:
																						goto IL_0a05_2;
																					case 116:
																						goto IL_0a13_2;
																					case 44:
																					case 165:
																						goto IL_0a23_2;
																					case 104:
																						goto IL_0a63_2;
																					case 192:
																						goto IL_0a7c_2;
																					case 9:
																						goto IL_0a87_2;
																					case 150:
																						goto IL_0a9a_2;
																					case 73:
																						goto IL_0aa5_2;
																					case 242:
																						goto IL_0ac3_2;
																					case 246:
																						goto IL_0ad6_2;
																					case 238:
																						goto IL_0ae4_2;
																					case 1:
																						goto IL_0aef_2;
																					case 153:
																						goto IL_0b06_2;
																					case 79:
																					case 209:
																						goto IL_0b14_2;
																					case 62:
																						goto IL_0b28_2;
																					case 301:
																						goto IL_0b7a_2;
																					case 334:
																						goto IL_0b8d_2;
																					case 70:
																					case 317:
																						goto IL_0b9b_2;
																					case 22:
																						goto IL_0baf_2;
																					case 17:
																						goto IL_0c2f_2;
																					case 362:
																						goto IL_0c42_2;
																					case 253:
																						goto IL_0c50_2;
																					case 293:
																						goto IL_0c5e_2;
																					case 347:
																						goto IL_0c6c_2;
																					case 160:
																					case 381:
																						goto IL_0c7f_2;
																					case 390:
																						goto IL_0cdf_2;
																					case 389:
																						goto IL_0ced_2;
																					case 393:
																						goto IL_0d00_2;
																					case 222:
																						goto IL_0d0e_2;
																					case 396:
																						goto IL_0d21_2;
																					case 91:
																						goto IL_0d2f_2;
																					case 56:
																					case 138:
																						goto IL_0d3a_2;
																					case 280:
																						goto IL_0d63_2;
																					case 224:
																						goto IL_0d7c_2;
																					case 399:
																						goto IL_0d8f_2;
																					case 86:
																					case 358:
																						goto IL_0d9a_2;
																					case 30:
																						goto IL_0dcd_2;
																					case 305:
																					case 416:
																						goto IL_0de0_2;
																					case 194:
																						goto IL_0dee_2;
																					case 270:
																						goto IL_0e0c_2;
																					case 52:
																						goto IL_0e1a_2;
																					case 298:
																					case 421:
																						goto IL_0e2d_2;
																					case 243:
																						goto IL_0e41_2;
																					case 355:
																						goto IL_0e80_2;
																					case 118:
																					case 423:
																						goto IL_0e93_2;
																					case 431:
																						goto IL_0ed9_2;
																					case 441:
																						goto IL_0eec_2;
																					case 454:
																						goto IL_0eff_2;
																					case 459:
																						goto IL_0f12_2;
																					case 19:
																						goto IL_0f20_2;
																					case 235:
																						goto IL_0f2e_2;
																					case 451:
																						goto IL_0f3c_2;
																					case 467:
																						goto IL_0f4f_2;
																					case 191:
																					case 286:
																						goto IL_0f5d_2;
																					case 471:
																						goto IL_0f79_2;
																					case 277:
																						goto IL_0f87_2;
																					case 241:
																						goto IL_0f95_2;
																					case 66:
																						goto IL_0fa3_2;
																					case 413:
																					case 464:
																						goto IL_0fae_2;
																					case 323:
																						goto IL_0fc2_2;
																					case 162:
																						goto IL_0ffa_2;
																					case 460:
																						goto IL_100d_2;
																					case 429:
																						goto IL_101b_2;
																					case 327:
																						goto IL_1029_2;
																					case 245:
																					case 352:
																						goto IL_1037_2;
																					case 117:
																						goto IL_104b_2;
																					case 428:
																						goto IL_108a_2;
																					case 420:
																						goto IL_109d_2;
																					case 76:
																						goto IL_10a8_2;
																					case 249:
																						goto IL_10bb_2;
																					case 239:
																						goto IL_10c9_2;
																					case 156:
																					case 425:
																						goto IL_10e0_2;
																					case 55:
																						goto IL_10fd_2;
																					case 21:
																						goto IL_113c_2;
																					case 190:
																						goto IL_114f_2;
																					case 324:
																						goto IL_115d_2;
																					case 339:
																						goto IL_1170_2;
																					case 307:
																						goto IL_117e_2;
																					case 96:
																					case 186:
																						goto IL_1189_2;
																					case 24:
																						goto IL_11a3_2;
																					case 102:
																						goto IL_11b6_2;
																					case 213:
																						goto IL_11c4_2;
																					case 365:
																						goto IL_11d2_2;
																					case 232:
																					case 449:
																						goto IL_11e0_2;
																					case 169:
																						goto IL_1221_2;
																					case 332:
																						goto IL_1235_2;
																					case 90:
																						goto IL_1248_2;
																					case 112:
																					case 410:
																						goto IL_1253_2;
																					case 279:
																						goto IL_1261_2;
																					case 108:
																						goto IL_127f_2;
																					case 446:
																						goto IL_128d_2;
																					case 319:
																						goto IL_12a0_2;
																					case 36:
																						goto IL_12b3_2;
																					case 264:
																						goto IL_12c1_2;
																					case 137:
																					case 140:
																						goto IL_12cc_2;
																					case 48:
																						goto IL_12eb_2;
																					case 379:
																						goto IL_12f9_2;
																					case 472:
																						goto IL_130c_2;
																					case 481:
																						goto IL_131f_2;
																					case 133:
																						goto IL_132d_2;
																					case 82:
																						goto IL_133b_2;
																					case 123:
																					case 363:
																						goto IL_1349_2;
																					case 340:
																						goto IL_1387_2;
																					case 63:
																						goto IL_139b_2;
																					case 124:
																					case 130:
																						goto IL_13ae_2;
																					case 146:
																						goto IL_1419_2;
																					case 328:
																					case 483:
																						goto IL_142c_2;
																					case 480:
																					case 492:
																						goto IL_1445_2;
																					case 351:
																					case 498:
																						goto IL_145d_2;
																					case 267:
																						goto IL_147a_2;
																					case 380:
																						goto IL_14b2_2;
																					case 503:
																						goto IL_14c5_2;
																					case 158:
																						goto IL_14d3_2;
																					case 167:
																					case 268:
																						goto IL_14e1_2;
																					case 149:
																						goto IL_14eb_2;
																					case 127:
																						goto IL_1502_2;
																					case 511:
																						goto IL_1515_2;
																					case 69:
																						goto IL_1523_2;
																					case 513:
																						goto IL_1536_2;
																					case 312:
																					case 361:
																						goto IL_1544_2;
																					case 515:
																						goto IL_1587_2;
																					case 85:
																						goto IL_1592_2;
																					case 212:
																					case 231:
																						goto IL_15a0_2;
																					case 387:
																						goto IL_15c4_2;
																					case 256:
																						goto IL_15d2_2;
																					case 349:
																						goto IL_15e9_2;
																					case 13:
																						goto IL_15fc_2;
																					case 182:
																						goto IL_160a_2;
																					case 221:
																					case 468:
																						goto IL_1618_2;
																					case 164:
																						goto IL_163c_2;
																					case 178:
																						goto IL_164a_2;
																					case 470:
																						goto IL_1658_2;
																					case 519:
																						goto IL_166b_2;
																					case 161:
																						goto IL_1679_2;
																					case 120:
																					case 469:
																						goto IL_1687_2;
																					case 233:
																						goto IL_16b0_2;
																					case 504:
																					case 520:
																						goto IL_16d2_2;
																					case 490:
																						goto IL_16fb_2;
																					case 234:
																					case 526:
																						goto IL_1714_2;
																					case 522:
																						goto IL_1728_2;
																					case 200:
																						goto IL_177e_2;
																					case 141:
																						goto IL_178c_2;
																					case 527:
																						goto IL_179f_2;
																					case 530:
																						goto IL_17b2_2;
																					case 32:
																						goto IL_17c0_2;
																					case 23:
																					case 223:
																						goto IL_17ce_2;
																					case 47:
																						goto IL_17dc_2;
																					case 434:
																						goto IL_1800_2;
																					case 125:
																						goto IL_180e_2;
																					case 20:
																					case 531:
																						goto IL_1821_2;
																					case 337:
																						goto IL_185f_2;
																					case 248:
																						goto IL_1873_2;
																					case 532:
																						goto IL_1886_2;
																					case 533:
																						goto IL_1899_2;
																					case 482:
																						goto IL_18a4_2;
																					case 189:
																					case 272:
																						goto IL_18bb_2;
																					case 170:
																						goto IL_18ed_2;
																					case 262:
																						goto IL_1906_2;
																					case 335:
																						goto IL_191d_2;
																					case 536:
																						goto IL_1930_2;
																					case 538:
																						goto IL_1943_2;
																					case 329:
																						goto IL_1957_2;
																					case 540:
																						goto IL_196a_2;
																					case 385:
																						goto IL_1981_2;
																					case 25:
																					case 278:
																						goto IL_198f_2;
																					case 8:
																						goto IL_19a8_2;
																					case 215:
																						goto IL_19bf_2;
																					case 350:
																						goto IL_19cd_2;
																					case 541:
																						goto IL_19e0_2;
																					case 326:
																						goto IL_1a2d_2;
																					case 174:
																						goto IL_1a3b_2;
																					case 544:
																						goto IL_1a57_2;
																					case 171:
																					case 487:
																						goto IL_1a65_2;
																					case 58:
																						goto IL_1a79_2;
																					case 26:
																						goto IL_1ab1_2;
																					case 219:
																					case 550:
																						goto IL_1ac4_2;
																					case 330:
																						goto IL_1ad8_2;
																					case 75:
																					case 553:
																						goto IL_1b1c_2;
																					case 554:
																						goto IL_1b39_2;
																					case 88:
																					case 510:
																						goto IL_1b47_2;
																					case 537:
																						goto IL_1b5b_2;
																					case 376:
																						goto IL_1b9a_2;
																					case 556:
																						goto IL_1bad_2;
																					case 398:
																						goto IL_1bbb_2;
																					case 129:
																					case 551:
																						goto IL_1bc9_2;
																					case 315:
																						goto IL_1c37_2;
																					case 163:
																						goto IL_1c4a_2;
																					case 51:
																						goto IL_1c58_2;
																					case 5:
																					case 299:
																						goto IL_1c63_2;
																					case 236:
																						goto IL_1c7d_2;
																					case 318:
																						goto IL_1c8b_2;
																					case 255:
																						goto IL_1ca2_2;
																					case 31:
																						goto IL_1cbe_2;
																					case 285:
																						goto IL_1ccc_2;
																					case 202:
																					case 313:
																						goto IL_1cda_2;
																					case 183:
																						goto IL_1d18_2;
																					case 107:
																						goto IL_1d2c_2;
																					case 345:
																						goto IL_1d3f_2;
																					case 84:
																						goto IL_1d4d_2;
																					case 207:
																						goto IL_1d60_2;
																					case 388:
																						goto IL_1d6e_2;
																					case 128:
																						goto IL_1d79_2;
																					case 154:
																					case 374:
																						goto IL_1d87_2;
																					case 204:
																						goto IL_1dc7_2;
																					case 217:
																						goto IL_1ddb_2;
																					case 83:
																						goto IL_1dee_2;
																					case 507:
																						goto IL_1dfc_2;
																					case 333:
																					case 491:
																						goto IL_1e0a_2;
																					case 529:
																						goto IL_1e1e_2;
																					case 477:
																						goto IL_1e5d_2;
																					case 383:
																						goto IL_1e79_2;
																					case 450:
																					case 512:
																						goto IL_1e84_2;
																					case 433:
																						goto IL_1e98_2;
																					case 466:
																						goto IL_1ee0_2;
																					case 435:
																						goto IL_1ef3_2;
																					case 59:
																						goto IL_1f01_2;
																					case 115:
																					case 444:
																						goto IL_1f0f_2;
																					case 42:
																						goto IL_1f28_2;
																					case 373:
																						goto IL_1f36_2;
																					case 254:
																						goto IL_1f44_2;
																					case 210:
																					case 557:
																						goto IL_1f57_2;
																					case 136:
																						goto IL_1f6b_2;
																					case 461:
																						goto IL_1faa_2;
																					case 559:
																						goto IL_1fbd_2;
																					case 560:
																						goto IL_1fd0_2;
																					case 273:
																					case 346:
																						goto IL_1fde_2;
																					case 71:
																						goto IL_1ff2_2;
																					case 525:
																						goto IL_203a_2;
																					case 563:
																						goto IL_204d_2;
																					case 2:
																					case 38:
																						goto IL_205b_2;
																					case 139:
																						goto IL_2069_2;
																					case 95:
																						goto IL_208d_2;
																					case 564:
																						goto IL_20a6_2;
																					case 405:
																						goto IL_20b4_2;
																					case 336:
																						goto IL_20c2_2;
																					case 565:
																						goto IL_20d5_2;
																					case 548:
																					case 566:
																						goto IL_20e8_2;
																					case 53:
																						goto IL_2128_2;
																					case 424:
																						goto IL_213c_2;
																					case 568:
																						goto IL_214f_2;
																					case 214:
																					case 302:
																						goto IL_215a_2;
																					case 29:
																						goto IL_216e_2;
																					case 282:
																						goto IL_21ad_2;
																					case 11:
																						goto IL_21c0_2;
																					case 476:
																						goto IL_21d7_2;
																					case 65:
																					case 89:
																						goto IL_21e5_2;
																					case 343:
																						goto IL_21f9_2;
																					case 375:
																						goto IL_2238_2;
																					case 14:
																					case 571:
																						goto IL_224b_2;
																					case 296:
																						goto IL_22a9_2;
																					case 311:
																					case 573:
																						goto IL_22bc_2;
																					case 237:
																						goto IL_22f5_2;
																					case 258:
																					case 438:
																						goto IL_2313_2;
																					case 353:
																						goto IL_2321_2;
																					case 257:
																						goto IL_2339_2;
																					case 473:
																						goto IL_2347_2;
																					case 370:
																						goto IL_235a_2;
																					case 218:
																						goto IL_2368_2;
																					case 41:
																					case 220:
																						goto IL_2373_2;
																					case 539:
																						goto IL_2386_2;
																					case 300:
																						goto IL_2394_2;
																					case 436:
																					case 558:
																						goto IL_239f_2;
																					case 33:
																						goto IL_23ad_2;
																					case 101:
																						goto IL_23d0_2;
																					case 122:
																						goto IL_23da_2;
																					case 509:
																						goto IL_23e8_2;
																					case 574:
																						goto IL_23fb_2;
																					case 43:
																						goto IL_2409_2;
																					case 109:
																					case 497:
																						goto IL_2414_2;
																					case 15:
																						goto IL_2454_2;
																					case 287:
																						goto IL_2468_2;
																					case 197:
																						goto IL_247b_2;
																					case 422:
																						goto IL_2489_2;
																					case 179:
																					case 261:
																						goto IL_2497_2;
																					case 442:
																						goto IL_24b0_2;
																					case 404:
																						goto IL_24be_2;
																					case 569:
																						goto IL_24cc_2;
																					case 126:
																						goto IL_24df_2;
																					case 542:
																						goto IL_24ed_2;
																					case 34:
																					case 528:
																						goto IL_2504_2;
																					case 61:
																						goto IL_252d_2;
																					case 486:
																						goto IL_253b_2;
																					case 111:
																						goto IL_254e_2;
																					case 395:
																						goto IL_255c_2;
																					case 344:
																					case 357:
																						goto IL_2567_2;
																					case 16:
																						goto IL_25a7_2;
																					case 341:
																						goto IL_25bb_2;
																					case 78:
																						goto IL_25ce_2;
																					case 359:
																						goto IL_25dc_2;
																					case 54:
																					case 99:
																						goto IL_25ea_2;
																					case 432:
																						goto IL_262a_2;
																					case 493:
																						goto IL_263e_2;
																					case 314:
																						goto IL_2651_2;
																					case 462:
																						goto IL_265f_2;
																					case 144:
																					case 495:
																						goto IL_266d_2;
																					case 105:
																						goto IL_26ad_2;
																					case 250:
																						goto IL_26c1_2;
																					case 93:
																						goto IL_26d4_2;
																					case 524:
																						goto IL_26e2_2;
																					case 360:
																						goto IL_26f0_2;
																					case 417:
																						goto IL_26fe_2;
																					case 331:
																					case 494:
																						goto IL_2709_2;
																					case 516:
																						goto IL_276b_2;
																					case 259:
																						goto IL_277e_2;
																					case 514:
																						goto IL_278c_2;
																					case 157:
																					case 391:
																						goto IL_279a_2;
																					case 552:
																						goto IL_27da_2;
																					case 369:
																						goto IL_27ee_2;
																					case 545:
																						goto IL_2801_2;
																					case 203:
																						goto IL_280f_2;
																					case 106:
																					case 266:
																						goto IL_281d_2;
																					case 403:
																						goto IL_2831_2;
																					case 508:
																						goto IL_2870_2;
																					case 57:
																						goto IL_2883_2;
																					case 6:
																						goto IL_2891_2;
																					case 92:
																					case 269:
																						goto IL_289c_2;
																					case 295:
																						goto IL_28ba_2;
																					case 400:
																						goto IL_28c8_2;
																					case 68:
																						goto IL_28db_2;
																					case 406:
																						goto IL_28e9_2;
																					case 181:
																					case 430:
																						goto IL_28f7_2;
																					case 478:
																						goto end_IL_2adb_2;
																					case 401:
																						goto IL_29bc_2;
																					case 152:
																						goto IL_29cf_2;
																					case 176:
																						goto IL_29da_2;
																					case 274:
																					case 372:
																						goto IL_29e8_2;
																					case 97:
																						goto IL_2a11_2;
																					case 77:
																						goto IL_2a2a_2;
																					case 415:
																						goto IL_2a38_2;
																					case 275:
																					case 292:
																						goto IL_2a46_2;
																					case 453:
																						goto IL_2a5e_2;
																					case 310:
																						goto IL_2a7c_2;
																					case 81:
																						goto IL_2aa0_2;
																					case 35:
																						goto IL_2ab8_2;
																					case 3:
																					case 45:
																					case 49:
																					case 50:
																					case 60:
																					case 64:
																					case 67:
																					case 72:
																					case 74:
																					case 100:
																					case 110:
																					case 114:
																					case 132:
																					case 143:
																					case 145:
																					case 147:
																					case 151:
																					case 155:
																					case 159:
																					case 166:
																					case 168:
																					case 172:
																					case 175:
																					case 184:
																					case 185:
																					case 187:
																					case 193:
																					case 196:
																					case 198:
																					case 206:
																					case 216:
																					case 227:
																					case 240:
																					case 244:
																					case 247:
																					case 260:
																					case 263:
																					case 271:
																					case 276:
																					case 281:
																					case 289:
																					case 290:
																					case 294:
																					case 297:
																					case 320:
																					case 321:
																					case 322:
																					case 348:
																					case 364:
																					case 367:
																					case 371:
																					case 377:
																					case 384:
																					case 402:
																					case 407:
																					case 408:
																					case 409:
																					case 418:
																					case 427:
																					case 439:
																					case 445:
																					case 448:
																					case 455:
																					case 456:
																					case 474:
																					case 475:
																					case 485:
																					case 489:
																					case 517:
																					case 521:
																					case 534:
																					case 543:
																					case 555:
																						goto end_IL_0985_2;
																					case 0:
																					case 10:
																					case 12:
																					case 27:
																					case 28:
																					case 37:
																					case 40:
																					case 87:
																					case 94:
																					case 98:
																					case 103:
																					case 113:
																					case 119:
																					case 121:
																					case 135:
																					case 142:
																					case 148:
																					case 173:
																					case 177:
																					case 188:
																					case 195:
																					case 199:
																					case 201:
																					case 205:
																					case 208:
																					case 211:
																					case 225:
																					case 228:
																					case 229:
																					case 251:
																					case 265:
																					case 283:
																					case 288:
																					case 303:
																					case 304:
																					case 306:
																					case 308:
																					case 316:
																					case 325:
																					case 338:
																					case 342:
																					case 354:
																					case 356:
																					case 368:
																					case 378:
																					case 382:
																					case 392:
																					case 397:
																					case 412:
																					case 414:
																					case 419:
																					case 437:
																					case 443:
																					case 452:
																					case 457:
																					case 458:
																					case 463:
																					case 465:
																					case 484:
																					case 488:
																					case 496:
																					case 499:
																					case 500:
																					case 505:
																					case 523:
																					case 535:
																					case 547:
																					case 549:
																					case 561:
																					case 562:
																					case 567:
																					case 570:
																					case 572:
																						goto end_IL_093f_2;
																					case 411:
																						ptr2 = ptr;
																						goto end_IL_093f_2;
																					case 440:
																						ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaxTraceSetInfoClassAsBstr.getCategorygetIdentity);
																						goto case 411;
																					case 479:
																						array7[0] = this;
																						goto case 440;
																					case 394:
																						array7 = new object[14];
																						num = 479;
																						goto case 479;
																					case 39:
																						array6 = new long[7];
																						goto case 394;
																					case 180:
																						array5 = new int[7];
																						num = 39;
																						goto case 39;
																					case 366:
																						array4 = new int[7];
																						goto case 180;
																					case 506:
																						array3 = new object[7];
																						goto case 366;
																					case 426:
																						array2 = new byte[7];
																						goto case 506;
																					case 447:
																						num4 = num2 * 8;
																						goto case 426;
																					case 546:
																						num3 = num2 * 4;
																						goto case 447;
																					case 501:
																						num2 = 1;
																						goto case 546;
																					case 502:
																						goto end_IL_29ae;
																					case 46:
																					case 230:
																						return;
																					}
																					continue;
																				}
																				if (17 <= b)
																				{
																					goto IL_2313_2;
																				}
																				goto IL_235a_2;
																				IL_2a5e_2:
																				array4[num6 - 0] = array4[num6 - 1];
																				goto IL_2a7c_2;
																				IL_2aa0_2:
																				array3[num6] = array3[num6 - 1];
																				goto IL_2ab8_2;
																				IL_2a7c_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_2aa0_2;
																				IL_2313_2:
																				array2[num6] = 5;
																				goto IL_2321_2;
																				IL_2321_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_2339_2;
																				IL_2339_2:
																				num6++;
																				goto IL_2347_2;
																				IL_2347_2:
																				ptr2 += 8;
																				break;
																				IL_235a_2:
																				if (8 >= b)
																				{
																					goto IL_2368_2;
																				}
																				goto IL_26d4_2;
																				IL_2368_2:
																				if (8 <= b)
																				{
																					goto IL_2373_2;
																				}
																				goto IL_2386_2;
																				IL_2373_2:
																				num6--;
																				break;
																				IL_2386_2:
																				if (4 >= b)
																				{
																					goto IL_2394_2;
																				}
																				goto IL_254e_2;
																				IL_2394_2:
																				if (4 <= b)
																				{
																					goto IL_239f_2;
																				}
																				goto IL_23fb_2;
																				IL_239f_2:
																				array2[num6] = 0;
																				goto IL_23ad_2;
																				IL_23ad_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				goto IL_23d0_2;
																				IL_23d0_2:
																				array3[num6] = null;
																				goto IL_23da_2;
																				IL_23da_2:
																				num6++;
																				goto IL_23e8_2;
																				IL_23e8_2:
																				ptr2 += 8;
																				break;
																				IL_23fb_2:
																				if (2 >= b)
																				{
																					goto IL_2409_2;
																				}
																				goto IL_24df_2;
																				IL_2409_2:
																				if (2 <= b)
																				{
																					goto IL_2414_2;
																				}
																				goto IL_247b_2;
																				IL_2414_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_2454_2;
																				IL_2454_2:
																				array2[num6 - 2] = 0;
																				goto IL_2468_2;
																				IL_2468_2:
																				num6--;
																				break;
																				IL_247b_2:
																				if (1 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_2489_2;
																				IL_2489_2:
																				if (1 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_2497_2;
																				IL_2497_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																				goto IL_24b0_2;
																				IL_24b0_2:
																				array2[num6] = 0;
																				goto IL_24be_2;
																				IL_24be_2:
																				num6++;
																				goto IL_24cc_2;
																				IL_24cc_2:
																				ptr2 += 8;
																				break;
																				IL_24df_2:
																				if (3 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_24ed_2;
																				IL_24ed_2:
																				if (3 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				num = 34;
																				goto IL_2504_2;
																				IL_2ab8_2:
																				num6++;
																				break;
																				IL_2504_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_252d_2;
																				IL_252d_2:
																				ptr2 += 8;
																				goto IL_253b_2;
																				IL_253b_2:
																				num6--;
																				break;
																				IL_254e_2:
																				if (6 >= b)
																				{
																					goto IL_255c_2;
																				}
																				goto IL_2651_2;
																				IL_255c_2:
																				if (6 <= b)
																				{
																					goto IL_2567_2;
																				}
																				goto IL_25ce_2;
																				IL_2567_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_25a7_2;
																				IL_25a7_2:
																				array2[num6 - 2] = 0;
																				goto IL_25bb_2;
																				IL_25bb_2:
																				num6--;
																				break;
																				IL_25ce_2:
																				if (5 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_25dc_2;
																				IL_25dc_2:
																				if (5 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_25ea_2;
																				IL_25ea_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_262a_2;
																				IL_262a_2:
																				array2[num6 - 2] = 0;
																				goto IL_263e_2;
																				IL_263e_2:
																				num6--;
																				break;
																				IL_2651_2:
																				if (7 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_265f_2;
																				IL_265f_2:
																				if (7 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_266d_2;
																				IL_266d_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_26ad_2;
																				IL_26ad_2:
																				array2[num6 - 2] = 0;
																				goto IL_26c1_2;
																				IL_26c1_2:
																				num6--;
																				break;
																				IL_26d4_2:
																				if (12 >= b)
																				{
																					goto IL_26e2_2;
																				}
																				goto IL_2883_2;
																				IL_26e2_2:
																				if (12 <= b)
																				{
																					break;
																				}
																				goto IL_26f0_2;
																				IL_26f0_2:
																				if (10 >= b)
																				{
																					goto IL_26fe_2;
																				}
																				goto IL_2801_2;
																				IL_26fe_2:
																				if (10 <= b)
																				{
																					goto IL_2709_2;
																				}
																				goto IL_277e_2;
																				IL_2709_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_276b_2;
																				IL_276b_2:
																				num6 -= 2;
																				break;
																				IL_277e_2:
																				if (9 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_278c_2;
																				IL_278c_2:
																				if (9 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_279a_2;
																				IL_279a_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_27da_2;
																				IL_27da_2:
																				array2[num6 - 2] = 0;
																				goto IL_27ee_2;
																				IL_27ee_2:
																				num6--;
																				break;
																				IL_2801_2:
																				if (11 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_280f_2;
																				IL_280f_2:
																				if (11 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_281d_2;
																				IL_281d_2:
																				array2[num6 - 1] = 0;
																				goto IL_2831_2;
																				IL_2831_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_2870_2;
																				IL_2870_2:
																				ptr2 += 8;
																				break;
																				IL_2883_2:
																				if (14 >= b)
																				{
																					goto IL_2891_2;
																				}
																				goto IL_29cf_2;
																				IL_2891_2:
																				if (14 <= b)
																				{
																					goto IL_289c_2;
																				}
																				goto IL_28db_2;
																				IL_289c_2:
																				array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																				goto IL_28ba_2;
																				IL_28ba_2:
																				ptr2 += 8;
																				goto IL_28c8_2;
																				IL_28c8_2:
																				num6--;
																				break;
																				IL_28db_2:
																				if (13 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_28e9_2;
																				IL_28e9_2:
																				if (13 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_28f7_2;
																				IL_28f7_2:
																				array8 = array3;
																				num7 = num6;
																				if (array == null)
																				{
																					goto IL_2906_2;
																				}
																				goto IL_2914;
																				IL_29cf_2:
																				if (15 >= b)
																				{
																					goto IL_29da_2;
																				}
																				goto IL_2a2a_2;
																				IL_29da_2:
																				if (15 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_29e8_2;
																				IL_29e8_2:
																				array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																				goto IL_2a11_2;
																				IL_2a11_2:
																				array2[num6 - 1] = 5;
																				break;
																				IL_2a2a_2:
																				if (16 < b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_2a38_2;
																				IL_2a38_2:
																				if (16 > b)
																				{
																					goto end_IL_0985_2;
																				}
																				goto IL_2a46_2;
																				IL_2a46_2:
																				array2[num6] = array2[num6 - 1];
																				goto IL_2a5e_2;
																				continue;
																				end_IL_093f_2:
																				break;
																			}
																			break;
																		}
																		goto IL_09f7_2;
																		IL_1f01_2:
																		if (31 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1f0f_2;
																		IL_1f0f_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																		goto IL_1f28_2;
																		IL_09f7_2:
																		if (26 >= b)
																		{
																			goto IL_0a05_2;
																		}
																		goto IL_1bad_2;
																		IL_0a05_2:
																		if (26 > b)
																		{
																			goto IL_0a13_2;
																		}
																		goto IL_1b1c_2;
																		IL_0a13_2:
																		if (21 < b)
																		{
																			goto IL_0a7c_2;
																		}
																		goto IL_0f12_2;
																		IL_0a7c_2:
																		if (23 < b)
																		{
																			goto IL_0a87_2;
																		}
																		goto IL_0a9a_2;
																		IL_0a87_2:
																		if (24 >= b)
																		{
																			goto IL_0f4f_2;
																		}
																		goto IL_17b2_2;
																		IL_0f4f_2:
																		if (24 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_0f5d_2;
																		IL_0f5d_2:
																		num10 = ptr2;
																		num11 = -200;
																		num5 = 1;
																		ptr2 = num10 + num11;
																		break;
																		IL_17b2_2:
																		if (25 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_17c0_2;
																		IL_17c0_2:
																		if (25 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_17ce_2;
																		IL_17ce_2:
																		array2[num6] = 3;
																		goto IL_17dc_2;
																		IL_17dc_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																		goto IL_1800_2;
																		IL_1800_2:
																		num6++;
																		goto IL_180e_2;
																		IL_180e_2:
																		ptr2 += 8;
																		break;
																		IL_0a9a_2:
																		if (23 > b)
																		{
																			goto IL_0aa5_2;
																		}
																		num = 160;
																		goto IL_0c7f_2;
																		IL_0aa5_2:
																		if (22 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_0ac3_2;
																		IL_0ac3_2:
																		if (22 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_0e93_2;
																		IL_0e93_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																		goto IL_1943_2;
																		IL_1943_2:
																		array2[num6 - 2] = 0;
																		goto IL_1957_2;
																		IL_1957_2:
																		num6--;
																		break;
																		IL_1f28_2:
																		array2[num6] = 3;
																		goto IL_1f36_2;
																		IL_0c7f_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		num = 536;
																		goto IL_1930_2;
																		IL_1930_2:
																		num6--;
																		break;
																		IL_0f12_2:
																		if (21 > b)
																		{
																			goto IL_0f20_2;
																		}
																		goto IL_1445_2;
																		IL_0f20_2:
																		if (19 >= b)
																		{
																			goto IL_0f2e_2;
																		}
																		goto IL_196a_2;
																		IL_0f2e_2:
																		if (19 > b)
																		{
																			goto IL_0f3c_2;
																		}
																		goto IL_145d_2;
																		IL_0f3c_2:
																		if (18 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1536_2;
																		IL_1536_2:
																		if (18 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1544_2;
																		IL_1544_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_1886_2;
																		IL_1886_2:
																		num6 -= 3;
																		break;
																		IL_145d_2:
																		array2[num6 - 1] = 5;
																		num = 267;
																		goto IL_147a_2;
																		IL_147a_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_14b2_2;
																		IL_14b2_2:
																		ptr2 += 8;
																		break;
																		IL_196a_2:
																		if (20 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		num = 385;
																		goto IL_1981_2;
																		IL_1f36_2:
																		num6++;
																		goto IL_1f44_2;
																		IL_1981_2:
																		if (20 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_198f_2;
																		IL_198f_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_19a8_2;
																		IL_19a8_2:
																		array2[num6] = 1;
																		num = 215;
																		goto IL_19bf_2;
																		IL_19bf_2:
																		num6++;
																		goto IL_19cd_2;
																		IL_19cd_2:
																		ptr2 += 16;
																		break;
																		IL_1445_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		IL_1b1c_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_20a6_2;
																		IL_20a6_2:
																		array2[num6] = 5;
																		goto IL_20b4_2;
																		IL_20b4_2:
																		num6++;
																		goto IL_20c2_2;
																		IL_20c2_2:
																		ptr2 += 8;
																		break;
																		IL_1bad_2:
																		if (30 >= b)
																		{
																			goto IL_1bbb_2;
																		}
																		goto IL_1d60_2;
																		IL_1bbb_2:
																		if (30 <= b)
																		{
																			goto IL_1bc9_2;
																		}
																		goto IL_1c4a_2;
																		IL_1bc9_2:
																		ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_1c37_2;
																		IL_1c37_2:
																		num6 -= 2;
																		break;
																		IL_1c4a_2:
																		if (28 >= b)
																		{
																			goto IL_1c58_2;
																		}
																		goto IL_1d3f_2;
																		IL_1c58_2:
																		if (28 <= b)
																		{
																			goto IL_1c63_2;
																		}
																		goto IL_1cbe_2;
																		IL_1c63_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																		goto IL_1c7d_2;
																		IL_1c7d_2:
																		array2[num6] = 3;
																		goto IL_1c8b_2;
																		IL_1c8b_2:
																		num6++;
																		num = 255;
																		goto IL_1ca2_2;
																		IL_1ca2_2:
																		ptr2 += 8;
																		num = 412;
																		break;
																		IL_1cbe_2:
																		if (27 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1ccc_2;
																		IL_1ccc_2:
																		if (27 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1cda_2;
																		IL_1cda_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class186, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((Class186)array3[num6 - 1]);
																		goto IL_1d18_2;
																		IL_1d18_2:
																		array2[num6 - 1] = 3;
																		goto IL_1d2c_2;
																		IL_1d2c_2:
																		ptr2 += 8;
																		break;
																		IL_1d3f_2:
																		if (29 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1d4d_2;
																		IL_1d4d_2:
																		if (29 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_20e8_2;
																		IL_20e8_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_2128_2;
																		IL_2128_2:
																		array2[num6 - 2] = 3;
																		goto IL_213c_2;
																		IL_213c_2:
																		num6--;
																		break;
																		IL_1d60_2:
																		if (32 < b)
																		{
																			goto IL_1d6e_2;
																		}
																		num = 383;
																		goto IL_1e79_2;
																		IL_1d6e_2:
																		if (33 >= b)
																		{
																			goto IL_1d79_2;
																		}
																		goto IL_1dee_2;
																		IL_1d79_2:
																		if (33 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1d87_2;
																		IL_1d87_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1dc7_2;
																		IL_1dc7_2:
																		array2[num6 - 2] = 3;
																		goto IL_1ddb_2;
																		IL_1ddb_2:
																		num6--;
																		break;
																		IL_1dee_2:
																		if (34 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1dfc_2;
																		IL_1dfc_2:
																		if (34 > b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1e0a_2;
																		IL_1e0a_2:
																		array2[num6 - 1] = 0;
																		goto IL_1e1e_2;
																		IL_1e1e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1e5d_2;
																		IL_1e5d_2:
																		ptr2 += 8;
																		break;
																		IL_1f44_2:
																		ptr2 += 16;
																		break;
																		IL_1e79_2:
																		if (32 <= b)
																		{
																			goto IL_1e84_2;
																		}
																		goto IL_1ef3_2;
																		IL_1e84_2:
																		array2[num6 - 1] = 3;
																		goto IL_1e98_2;
																		IL_1e98_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		num = 466;
																		goto IL_1ee0_2;
																		IL_1ee0_2:
																		ptr2 += 8;
																		break;
																		IL_1ef3_2:
																		if (31 < b)
																		{
																			goto end_IL_0985_2;
																		}
																		goto IL_1f01_2;
																	}
																	break;
																}
																goto IL_0de0_2;
																IL_0e1a_2:
																ptr2 += 8;
																break;
																IL_0de0_2:
																array2[num6] = 5;
																goto IL_0dee_2;
																IL_0dee_2:
																array3[num6] = ((delegate*<GorillaTagger>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
																goto IL_0e0c_2;
																IL_0e0c_2:
																num6++;
																goto IL_0e1a_2;
															}
															break;
														}
														goto IL_09c9_2;
														IL_15d2_2:
														num6++;
														num = 349;
														goto IL_15e9_2;
														IL_15e9_2:
														ptr2 += 8;
														break;
														IL_09c9_2:
														if (53 < b)
														{
															goto IL_09d4_2;
														}
														goto IL_09e7_2;
														IL_09d4_2:
														if (62 < b)
														{
															goto IL_0ad6_2;
														}
														goto IL_0b7a_2;
														IL_0b7a_2:
														if (62 > b)
														{
															goto IL_0c42_2;
														}
														goto IL_16d2_2;
														IL_16d2_2:
														array3[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
														goto IL_16fb_2;
														IL_16fb_2:
														array2[num6 - 1] = 5;
														break;
														IL_0c42_2:
														if (57 >= b)
														{
															goto IL_0c50_2;
														}
														goto IL_0d21_2;
														IL_0c50_2:
														if (57 > b)
														{
															goto IL_0c5e_2;
														}
														goto IL_1ac4_2;
														IL_0c5e_2:
														if (55 < b)
														{
															goto IL_0c6c_2;
														}
														goto IL_0d8f_2;
														IL_0c6c_2:
														if (56 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1a57_2;
														IL_1a57_2:
														if (56 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1a65_2;
														IL_1a65_2:
														array2[num6 - 1] = 5;
														goto IL_1a79_2;
														IL_1a79_2:
														array3[num6 - 1] = ((delegate*<NetworkView, PhotonView>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((NetworkView)array3[num6 - 1]);
														goto IL_1ab1_2;
														IL_1ab1_2:
														ptr2 += 8;
														break;
														IL_0d8f_2:
														if (55 <= b)
														{
															goto IL_0d9a_2;
														}
														goto IL_0dcd_2;
														IL_0d9a_2:
														((Class186)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_130c_2;
														IL_130c_2:
														num6 -= 2;
														break;
														IL_0dcd_2:
														if (54 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_204d_2;
														IL_204d_2:
														if (54 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_205b_2;
														IL_205b_2:
														array2[num6] = 3;
														goto IL_2069_2;
														IL_2069_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
														goto IL_208d_2;
														IL_208d_2:
														num6++;
														num = 565;
														goto IL_20d5_2;
														IL_20d5_2:
														ptr2 += 8;
														break;
														IL_1ac4_2:
														array2[num6 - 1] = 3;
														goto IL_1ad8_2;
														IL_1ad8_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1fbd_2;
														IL_1fbd_2:
														ptr2 += 8;
														break;
														IL_0d21_2:
														if (59 >= b)
														{
															goto IL_0d2f_2;
														}
														goto IL_1899_2;
														IL_0d2f_2:
														if (59 <= b)
														{
															goto IL_0d3a_2;
														}
														goto IL_0d7c_2;
														IL_0d3a_2:
														array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_0d63_2;
														IL_0d63_2:
														array2[num6 - 1] = 5;
														break;
														IL_0d7c_2:
														if (58 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1fd0_2;
														IL_1fd0_2:
														if (58 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1fde_2;
														IL_1fde_2:
														array2[num6 - 1] = 0;
														goto IL_1ff2_2;
														IL_1ff2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 525;
														goto IL_203a_2;
														IL_203a_2:
														ptr2 += 8;
														break;
														IL_1899_2:
														if (60 >= b)
														{
															goto IL_18a4_2;
														}
														goto IL_1906_2;
														IL_18a4_2:
														if (60 > b)
														{
															goto end_IL_0985_2;
														}
														num = 272;
														goto IL_18bb_2;
														IL_15fc_2:
														if (52 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_160a_2;
														IL_18bb_2:
														array3[num6 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 170;
														goto IL_18ed_2;
														IL_18ed_2:
														array2[num6 - 1] = 5;
														break;
														IL_1906_2:
														if (61 < b)
														{
															goto end_IL_0985_2;
														}
														num = 335;
														goto IL_191d_2;
														IL_160a_2:
														if (52 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1618_2;
														IL_191d_2:
														if (61 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_22bc_2;
														IL_22bc_2:
														((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = array3[num6 - 1];
														goto IL_22f5_2;
														IL_22f5_2:
														num6 -= 3;
														break;
														IL_0ad6_2:
														if (66 < b)
														{
															goto IL_0ae4_2;
														}
														goto IL_0b8d_2;
														IL_0ae4_2:
														if (68 < b)
														{
															goto IL_0aef_2;
														}
														num = 568;
														goto IL_214f_2;
														IL_0aef_2:
														if (69 >= b)
														{
															num = 153;
															goto IL_0b06_2;
														}
														goto IL_1515_2;
														IL_163c_2:
														array2[num6] = 0;
														goto IL_164a_2;
														IL_0b06_2:
														if (69 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_0b14_2;
														IL_0b14_2:
														array2[num6 - 1] = 3;
														goto IL_0b28_2;
														IL_0b28_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0eec_2;
														IL_0eec_2:
														ptr2 += 8;
														break;
														IL_1515_2:
														if (70 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1523_2;
														IL_1523_2:
														if (70 > b)
														{
														}
														goto end_IL_0985_2;
														IL_1618_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_163c_2;
														IL_214f_2:
														if (68 <= b)
														{
															goto IL_215a_2;
														}
														goto IL_21c0_2;
														IL_215a_2:
														array2[num6 - 1] = 3;
														goto IL_216e_2;
														IL_216e_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_21ad_2;
														IL_21ad_2:
														ptr2 += 8;
														break;
														IL_21c0_2:
														if (67 < b)
														{
															goto end_IL_0985_2;
														}
														num = 476;
														goto IL_21d7_2;
														IL_164a_2:
														num6++;
														goto IL_1658_2;
														IL_21d7_2:
														if (67 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_21e5_2;
														IL_21e5_2:
														array2[num6 - 1] = 3;
														goto IL_21f9_2;
														IL_21f9_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2238_2;
														IL_2238_2:
														ptr2 += 8;
														break;
														IL_0b8d_2:
														if (66 <= b)
														{
															goto IL_0b9b_2;
														}
														goto IL_0c2f_2;
														IL_0b9b_2:
														array2[num6 - 4] = 0;
														goto IL_0baf_2;
														IL_0baf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
														goto IL_0cdf_2;
														IL_0cdf_2:
														num6 -= 3;
														goto IL_0ced_2;
														IL_0ced_2:
														ptr2 += 8;
														break;
														IL_0c2f_2:
														if (64 >= b)
														{
															goto IL_0d00_2;
														}
														goto IL_166b_2;
														IL_0d00_2:
														if (64 > b)
														{
															goto IL_0d0e_2;
														}
														goto IL_0e2d_2;
														IL_0d0e_2:
														if (63 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_0ed9_2;
														IL_0ed9_2:
														if (63 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1f57_2;
														IL_1f57_2:
														array2[num6 - 1] = 3;
														goto IL_1f6b_2;
														IL_1f6b_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1faa_2;
														IL_1faa_2:
														ptr2 += 8;
														break;
														IL_0e2d_2:
														array2[num6 - 1] = 0;
														goto IL_0e41_2;
														IL_0e41_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0e80_2;
														IL_0e80_2:
														ptr2 += 8;
														break;
														IL_166b_2:
														if (65 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1679_2;
														IL_1679_2:
														if (65 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1687_2;
														IL_1687_2:
														array3[num6 - 1] = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_16b0_2;
														IL_16b0_2:
														array2[num6 - 1] = 5;
														num = 443;
														break;
														IL_09e7_2:
														if (53 <= b)
														{
															goto IL_0a23_2;
														}
														goto IL_0f79_2;
														IL_0a23_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) | *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0a63_2;
														IL_0a63_2:
														array2[num6 - 2] = 0;
														goto IL_0eff_2;
														IL_0eff_2:
														num6--;
														break;
														IL_0f79_2:
														if (44 >= b)
														{
															goto IL_0f87_2;
														}
														goto IL_1170_2;
														IL_0f87_2:
														if (44 > b)
														{
															goto IL_0f95_2;
														}
														goto IL_224b_2;
														IL_0f95_2:
														if (39 >= b)
														{
															goto IL_0fa3_2;
														}
														goto IL_109d_2;
														IL_0fa3_2:
														if (39 <= b)
														{
															goto IL_0fae_2;
														}
														goto IL_100d_2;
														IL_0fae_2:
														array2[num6 - 1] = 5;
														goto IL_0fc2_2;
														IL_0fc2_2:
														array3[num6 - 1] = ((delegate*<GorillaTagger, NetworkView>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_0ffa_2;
														IL_0ffa_2:
														ptr2 += 8;
														break;
														IL_100d_2:
														if (37 < b)
														{
															goto IL_101b_2;
														}
														goto IL_131f_2;
														IL_101b_2:
														if (38 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1029_2;
														IL_1029_2:
														if (38 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1037_2;
														IL_1037_2:
														array2[num6 - 1] = 3;
														goto IL_104b_2;
														IL_104b_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_108a_2;
														IL_108a_2:
														ptr2 += 8;
														break;
														IL_131f_2:
														if (37 > b)
														{
															goto IL_132d_2;
														}
														goto IL_13ae_2;
														IL_132d_2:
														if (36 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_133b_2;
														IL_133b_2:
														if (36 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1349_2;
														IL_1349_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<GorillaTagger, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_1387_2;
														IL_1387_2:
														array2[num6 - 1] = 3;
														goto IL_139b_2;
														IL_139b_2:
														ptr2 += 8;
														break;
														IL_13ae_2:
														ptr2 = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														num = 146;
														goto IL_1419_2;
														IL_1419_2:
														num6 -= 2;
														break;
														IL_109d_2:
														if (41 >= b)
														{
															goto IL_10a8_2;
														}
														goto IL_10bb_2;
														IL_10a8_2:
														if (41 > b)
														{
															goto IL_14c5_2;
														}
														goto IL_1714_2;
														IL_14c5_2:
														if (40 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_14d3_2;
														IL_14d3_2:
														if (40 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_14e1_2;
														IL_14e1_2:
														array3[num6] = null;
														goto IL_14eb_2;
														IL_14eb_2:
														array2[num6] = 5;
														num = 127;
														goto IL_1502_2;
														IL_1502_2:
														num6++;
														break;
														IL_1714_2:
														array2[num6 - 2] = 0;
														goto IL_1728_2;
														IL_1728_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(NetworkView)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														num = 200;
														goto IL_177e_2;
														IL_177e_2:
														num6--;
														goto IL_178c_2;
														IL_178c_2:
														ptr2 += 8;
														break;
														IL_10bb_2:
														if (42 >= b)
														{
															goto IL_10c9_2;
														}
														goto IL_114f_2;
														IL_10c9_2:
														if (42 > b)
														{
															goto end_IL_0985_2;
														}
														num = 425;
														goto IL_10e0_2;
														IL_1658_2:
														ptr2 += 8;
														break;
														IL_10e0_2:
														array2[num6 - 1] = 3;
														num = 55;
														goto IL_10fd_2;
														IL_10fd_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_113c_2;
														IL_113c_2:
														ptr2 += 8;
														break;
														IL_114f_2:
														if (43 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_115d_2;
														IL_115d_2:
														if (43 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_142c_2;
														IL_142c_2:
														array2[num6 - 2] = 0;
														goto IL_19e0_2;
														IL_19e0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														goto IL_1a2d_2;
														IL_1a2d_2:
														num6--;
														goto IL_1a3b_2;
														IL_1a3b_2:
														ptr2 += 8;
														num = 414;
														break;
														IL_224b_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_22a9_2;
														IL_22a9_2:
														num6--;
														break;
														IL_1170_2:
														if (48 >= b)
														{
															goto IL_117e_2;
														}
														goto IL_12b3_2;
														IL_117e_2:
														if (48 <= b)
														{
															goto IL_1189_2;
														}
														goto IL_11b6_2;
														IL_1189_2:
														global::_003CModule_003E.bool_40 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
														goto IL_11a3_2;
														IL_11a3_2:
														num6--;
														break;
														IL_11b6_2:
														if (46 < b)
														{
															goto IL_11c4_2;
														}
														goto IL_1248_2;
														IL_11c4_2:
														if (47 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_11d2_2;
														IL_11d2_2:
														if (47 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_11e0_2;
														IL_11e0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1221_2;
														IL_1221_2:
														array2[num6 - 2] = 0;
														goto IL_1235_2;
														IL_1235_2:
														num6--;
														break;
														IL_1248_2:
														if (46 <= b)
														{
															goto IL_1253_2;
														}
														goto IL_12a0_2;
														IL_1253_2:
														array2[num6] = 5;
														goto IL_1261_2;
														IL_1261_2:
														array3[num6] = ((delegate*<GorillaTagger>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])();
														goto IL_127f_2;
														IL_127f_2:
														num6++;
														goto IL_128d_2;
														IL_128d_2:
														ptr2 += 8;
														break;
														IL_12a0_2:
														if (45 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1b39_2;
														IL_1b39_2:
														if (45 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1b47_2;
														IL_1b47_2:
														array2[num6 - 1] = 3;
														goto IL_1b5b_2;
														IL_1b5b_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1b9a_2;
														IL_1b9a_2:
														ptr2 += 8;
														break;
														IL_12b3_2:
														if (50 >= b)
														{
															goto IL_12c1_2;
														}
														goto IL_1587_2;
														IL_12c1_2:
														if (50 <= b)
														{
															goto IL_12cc_2;
														}
														goto IL_12eb_2;
														IL_12cc_2:
														global::_003CModule_003E.bool_41 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0;
														goto IL_179f_2;
														IL_179f_2:
														num6--;
														break;
														IL_12eb_2:
														if (49 < b)
														{
															goto end_IL_0985_2;
														}
														goto IL_12f9_2;
														IL_12f9_2:
														if (49 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_1821_2;
														IL_1821_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<GorillaTagger, float>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_185f_2;
														IL_185f_2:
														array2[num6 - 1] = 3;
														goto IL_1873_2;
														IL_1873_2:
														ptr2 += 8;
														break;
														IL_1587_2:
														if (51 >= b)
														{
															goto IL_1592_2;
														}
														goto IL_15fc_2;
														IL_1592_2:
														if (51 > b)
														{
															goto end_IL_0985_2;
														}
														goto IL_15a0_2;
														IL_15a0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)GetTypeInfoCountIReflectableType[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_15c4_2;
														IL_15c4_2:
														array2[num6] = 0;
														goto IL_15d2_2;
													}
													goto end_IL_0995_2;
													continue;
													end_IL_0985_2:
													break;
													IL_0985_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											break;
											continue;
											end_IL_0995_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_2adb_2:
								break;
							}
							break;
						}
						continue;
						end_IL_29ae:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class186()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EscapeGetElement.GetConnectionPointContainerObjectDisposedRegKeyClosed);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 32;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_024c:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_022f:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_021f:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_020f:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01ff:
																										if (3 >= b)
																										{
																											while (3 <= b)
																											{
																												num = 111;
																												while (true)
																												{
																													if (num != 111)
																													{
																														if (num != 1092)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 89:
																															goto IL_01ec;
																														case 53:
																														case 93:
																															goto IL_01ff;
																														case 68:
																															goto IL_020f;
																														case 51:
																															goto IL_021f;
																														case 101:
																															goto IL_022f;
																														case 75:
																															goto IL_023c;
																														case 12:
																															goto IL_024c;
																														case 66:
																															goto end_IL_024c;
																														case 72:
																														case 104:
																															goto end_IL_025c;
																														case 54:
																														case 67:
																															goto IL_0277;
																														case 24:
																														case 36:
																															goto IL_0282;
																														case 22:
																														case 27:
																															goto IL_0290;
																														case 50:
																															goto IL_029e;
																														case 60:
																															goto IL_02b1;
																														case 57:
																															goto IL_02bf;
																														case 0:
																														case 59:
																															goto IL_02ca;
																														case 44:
																															goto IL_02d8;
																														case 29:
																															goto IL_02f4;
																														case 35:
																														case 56:
																															goto IL_0302;
																														case 47:
																														case 73:
																															goto IL_0347;
																														case 48:
																															goto IL_03a9;
																														case 8:
																														case 74:
																															goto IL_03bc;
																														case 79:
																															goto IL_03e1;
																														case 39:
																														case 45:
																															goto IL_03ef;
																														case 87:
																															goto IL_040b;
																														case 25:
																															goto IL_041f;
																														case 91:
																															goto IL_0432;
																														case 61:
																															goto IL_0440;
																														case 23:
																															goto IL_044e;
																														case 100:
																															goto IL_0461;
																														case 70:
																															goto IL_0479;
																														case 94:
																															goto IL_0487;
																														case 92:
																															goto IL_049a;
																														case 41:
																														case 84:
																															goto IL_04a5;
																														case 37:
																															goto IL_04ce;
																														case 31:
																															goto IL_04dc;
																														case 33:
																															goto IL_04ef;
																														case 58:
																															goto IL_04fd;
																														case 52:
																														case 71:
																															goto IL_050b;
																														case 26:
																															goto IL_0524;
																														case 82:
																															goto IL_0532;
																														case 64:
																															goto IL_0540;
																														case 80:
																														case 102:
																															goto IL_0550;
																														case 95:
																															goto IL_055e;
																														case 63:
																															goto IL_0581;
																														case 55:
																															goto IL_0594;
																														case 6:
																															goto IL_05a2;
																														case 1:
																														case 3:
																														case 5:
																														case 11:
																														case 21:
																														case 30:
																														case 34:
																														case 40:
																														case 43:
																														case 49:
																														case 62:
																														case 65:
																														case 69:
																														case 76:
																														case 78:
																														case 81:
																														case 90:
																														case 98:
																														case 99:
																															goto end_IL_01d9;
																														case 10:
																														case 13:
																														case 18:
																														case 20:
																														case 32:
																														case 38:
																														case 46:
																														case 83:
																														case 85:
																														case 88:
																														case 96:
																														case 103:
																															goto end_IL_026c;
																														case 42:
																															goto end_IL_05c5;
																														case 9:
																															goto end_IL_05d8;
																														case 7:
																															goto end_IL_05e3;
																														case 77:
																															goto end_IL_05ed;
																														case 4:
																															goto end_IL_05f8;
																														case 14:
																														case 15:
																															goto end_IL_060d;
																														case 28:
																															goto end_IL_061d;
																														case 19:
																														case 86:
																															goto end_IL_062d;
																														case 16:
																															goto end_IL_063d;
																														case 17:
																															goto end_IL_064d;
																														case 2:
																														case 97:
																															goto IL_0668;
																														}
																														continue;
																													}
																													goto IL_0461;
																													IL_0461:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto end_IL_026c;
																													continue;
																													end_IL_01d9:
																													break;
																												}
																												break;
																												IL_01ec:;
																											}
																											break;
																										}
																										goto IL_0479;
																										IL_0487:
																										if (4 <= b)
																										{
																											goto end_IL_026c;
																										}
																										break;
																										IL_0479:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_0487;
																									}
																									break;
																								}
																								goto IL_049a;
																								IL_0540:
																								ptr2 += 8;
																								goto end_IL_026c;
																								IL_049a:
																								if (2 <= b)
																								{
																									goto IL_04a5;
																								}
																								goto IL_04ef;
																								IL_04a5:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04ce;
																								IL_04ce:
																								ptr2 += 8;
																								goto IL_04dc;
																								IL_04dc:
																								num5--;
																								goto end_IL_026c;
																								IL_04ef:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_04fd;
																								IL_04fd:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_050b;
																								IL_050b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0524;
																								IL_0524:
																								array[num5] = 0;
																								goto IL_0532;
																								IL_0532:
																								num5++;
																								goto IL_0540;
																							}
																							break;
																						}
																						goto IL_0550;
																						IL_05a2:
																						ptr2 += 8;
																						goto end_IL_026c;
																						IL_0550:
																						array[num5] = 0;
																						goto IL_055e;
																						IL_055e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0581;
																						IL_0581:
																						array2[num5] = null;
																						num = 55;
																						goto IL_0594;
																						IL_0594:
																						num5++;
																						goto IL_05a2;
																					}
																					break;
																				}
																				goto IL_0277;
																				IL_0347:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03a9;
																				IL_0277:
																				if (8 < b)
																				{
																					goto IL_0282;
																				}
																				goto IL_02b1;
																				IL_0282:
																				if (9 < b)
																				{
																					goto IL_0290;
																				}
																				goto IL_03e1;
																				IL_0290:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_029e;
																				IL_029e:
																				if (10 <= b)
																				{
																				}
																				break;
																				IL_03e1:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_03ef;
																				IL_03ef:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_026c;
																				IL_02b1:
																				if (8 > b)
																				{
																					goto IL_02bf;
																				}
																				goto IL_0347;
																				IL_02bf:
																				if (6 < b)
																				{
																					goto IL_02ca;
																				}
																				goto IL_02f4;
																				IL_02ca:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_02d8;
																				IL_02d8:
																				if (7 > b)
																				{
																					num = 98;
																					break;
																				}
																				goto IL_03bc;
																				IL_03a9:
																				num5 -= 2;
																				goto end_IL_026c;
																				IL_03bc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0432;
																				IL_0432:
																				array[num5] = 0;
																				goto IL_0440;
																				IL_0440:
																				num5++;
																				goto IL_044e;
																				IL_044e:
																				ptr2 += 8;
																				goto end_IL_026c;
																				IL_02f4:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0302;
																				IL_0302:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_040b;
																				IL_040b:
																				array[num5 - 2] = 0;
																				goto IL_041f;
																				IL_041f:
																				num5--;
																				goto end_IL_026c;
																			}
																			break;
																			IL_023c:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_026c;
																	continue;
																	end_IL_024c:
																	break;
																}
																continue;
																end_IL_025c:
																break;
															}
															continue;
															end_IL_026c:
															break;
														}
														continue;
													}
													goto IL_0668;
													IL_0668:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05c5:
													break;
												}
												continue;
												end_IL_05d8:
												break;
											}
											continue;
											end_IL_05e3:
											break;
										}
										continue;
										end_IL_05ed:
										break;
									}
									continue;
									end_IL_05f8:
									break;
								}
								continue;
								end_IL_060d:
								break;
							}
							continue;
							end_IL_061d:
							break;
						}
						continue;
						end_IL_062d:
						break;
					}
					continue;
					end_IL_063d:
					break;
				}
				continue;
				end_IL_064d:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 20;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 30;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									num = 65;
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemotingConfigurationgetGroups.CounterDESCKIND);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 7;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0240:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_0216:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_0206:
																									if (7 <= b)
																									{
																										while (true)
																										{
																											IL_01e2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 112;
																											while (true)
																											{
																												if (num != 112)
																												{
																													if (num != 1093)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 4:
																													case 37:
																														goto IL_01e2;
																													case 34:
																														goto IL_0206;
																													case 54:
																														goto IL_0216;
																													case 82:
																														goto end_IL_0216;
																													case 24:
																														goto end_IL_0223;
																													case 49:
																														goto IL_0240;
																													case 31:
																														goto end_IL_0240;
																													case 87:
																													case 90:
																														goto end_IL_0250;
																													case 61:
																														goto IL_026b;
																													case 38:
																													case 63:
																														goto IL_027b;
																													case 6:
																													case 32:
																														goto IL_0286;
																													case 69:
																														goto end_IL_01cf;
																													case 22:
																													case 58:
																														goto IL_02a2;
																													case 78:
																														goto IL_02be;
																													case 76:
																													case 79:
																														goto IL_02d1;
																													case 19:
																														goto IL_02df;
																													case 85:
																														goto IL_0307;
																													case 2:
																													case 77:
																														goto IL_0312;
																													case 23:
																													case 55:
																														goto IL_031d;
																													case 14:
																														goto IL_032b;
																													case 36:
																														goto IL_033e;
																													case 39:
																														goto IL_034e;
																													case 27:
																													case 33:
																														goto IL_035c;
																													case 74:
																														goto IL_039c;
																													case 25:
																														goto IL_03b0;
																													case 51:
																													case 88:
																														goto IL_03c3;
																													case 12:
																														goto IL_03ec;
																													case 44:
																														goto IL_03fa;
																													case 56:
																													case 93:
																														goto IL_040d;
																													case 1:
																														goto IL_044d;
																													case 46:
																														goto IL_0461;
																													case 95:
																														goto IL_0474;
																													case 75:
																														goto IL_047e;
																													case 92:
																														goto IL_048c;
																													case 100:
																														goto IL_049f;
																													case 67:
																														goto IL_04ad;
																													case 101:
																													case 105:
																														goto IL_04c0;
																													case 47:
																														goto IL_0500;
																													case 15:
																														goto IL_051d;
																													case 29:
																														goto IL_0547;
																													case 18:
																														goto IL_0555;
																													case 103:
																														goto IL_0568;
																													case 98:
																														goto IL_0573;
																													case 5:
																													case 72:
																														goto IL_057e;
																													case 0:
																														goto IL_05be;
																													case 57:
																														goto IL_05d2;
																													case 3:
																													case 40:
																													case 42:
																													case 48:
																													case 53:
																													case 60:
																													case 62:
																													case 64:
																													case 68:
																													case 70:
																													case 71:
																													case 80:
																													case 83:
																													case 86:
																													case 89:
																													case 91:
																													case 94:
																													case 96:
																													case 99:
																														goto end_IL_0230;
																													case 84:
																														goto IL_0605;
																													case 10:
																														goto IL_0613;
																													case 43:
																														goto IL_0621;
																													case 7:
																													case 8:
																													case 13:
																													case 17:
																													case 45:
																													case 50:
																													case 59:
																													case 73:
																													case 81:
																													case 102:
																													case 104:
																														goto end_IL_0260;
																													case 9:
																														goto end_IL_062f;
																													case 66:
																														goto end_IL_0642;
																													case 16:
																														goto end_IL_0655;
																													case 65:
																														goto end_IL_0660;
																													case 28:
																														goto end_IL_0675;
																													case 26:
																													case 52:
																														goto end_IL_068a;
																													case 11:
																														goto end_IL_06a3;
																													case 30:
																														goto end_IL_06b3;
																													case 35:
																														goto end_IL_06c3;
																													case 20:
																														goto end_IL_06d3;
																													case 21:
																														goto end_IL_06de;
																													case 41:
																													case 97:
																														goto IL_0702;
																													}
																													continue;
																												}
																												array[num5] = 0;
																												num = 29;
																												goto IL_0547;
																												IL_0547:
																												num5++;
																												goto IL_0555;
																												IL_0555:
																												ptr2 += 8;
																												goto end_IL_0260;
																												continue;
																												end_IL_01cf:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0568;
																									IL_05d2:
																									num5--;
																									goto end_IL_0260;
																									IL_0568:
																									if (6 < b)
																									{
																										goto end_IL_0230;
																									}
																									goto IL_0573;
																									IL_0573:
																									if (6 > b)
																									{
																										goto end_IL_0230;
																									}
																									goto IL_057e;
																									IL_057e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05be;
																									IL_05be:
																									array[num5 - 2] = 0;
																									goto IL_05d2;
																								}
																								goto IL_0294;
																							}
																							goto IL_027b;
																							IL_051d:
																							num5--;
																							goto end_IL_0260;
																							IL_027b:
																							if (8 < b)
																							{
																								goto IL_0286;
																							}
																							goto IL_02be;
																							IL_0286:
																							if (9 < b)
																							{
																								goto end_IL_0230;
																							}
																							goto IL_0294;
																							IL_0294:
																							if (9 > b)
																							{
																								goto end_IL_0230;
																							}
																							goto IL_02a2;
																							IL_02a2:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0260;
																							IL_02be:
																							if (8 > b)
																							{
																								goto end_IL_0230;
																							}
																							goto IL_04c0;
																							IL_04c0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0500;
																							IL_0500:
																							array[num5 - 2] = 0;
																							num = 15;
																							goto IL_051d;
																							continue;
																							end_IL_0216:
																							break;
																						}
																						continue;
																					}
																					goto IL_026b;
																					IL_04ad:
																					if (1 > b)
																					{
																					}
																					goto end_IL_0230;
																					IL_026b:
																					if (5 <= b)
																					{
																						goto IL_02d1;
																					}
																					goto IL_0307;
																					IL_02d1:
																					array[num5] = 0;
																					goto IL_02df;
																					IL_02df:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0474;
																					IL_0474:
																					array2[num5] = null;
																					goto IL_047e;
																					IL_047e:
																					num5++;
																					goto IL_048c;
																					IL_048c:
																					ptr2 += 8;
																					goto end_IL_0260;
																					IL_0307:
																					if (2 < b)
																					{
																						goto IL_0312;
																					}
																					goto IL_034e;
																					IL_0312:
																					if (3 < b)
																					{
																						goto IL_031d;
																					}
																					goto IL_033e;
																					IL_031d:
																					if (4 < b)
																					{
																						goto end_IL_0230;
																					}
																					goto IL_032b;
																					IL_032b:
																					if (4 > b)
																					{
																						goto end_IL_0230;
																					}
																					goto IL_040d;
																					IL_040d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_044d;
																					IL_044d:
																					array[num5 - 2] = 0;
																					goto IL_0461;
																					IL_0461:
																					num5--;
																					goto end_IL_0260;
																					IL_033e:
																					if (3 > b)
																					{
																						goto end_IL_0230;
																					}
																					goto IL_03c3;
																					IL_03c3:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03ec;
																					IL_03ec:
																					ptr2 += 8;
																					goto IL_03fa;
																					IL_03fa:
																					num5--;
																					goto end_IL_0260;
																					IL_034e:
																					if (2 <= b)
																					{
																						goto IL_035c;
																					}
																					goto IL_049f;
																					IL_035c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_039c;
																					IL_039c:
																					array[num5 - 2] = 0;
																					goto IL_03b0;
																					IL_03b0:
																					num5--;
																					goto end_IL_0260;
																					IL_049f:
																					if (1 < b)
																					{
																						goto end_IL_0230;
																					}
																					goto IL_04ad;
																					continue;
																					end_IL_0223:
																					break;
																				}
																				continue;
																				end_IL_0230:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0605;
																		IL_0621:
																		ptr2 += 8;
																		goto end_IL_0260;
																		IL_0613:
																		num5++;
																		goto IL_0621;
																		IL_0605:
																		array[num5] = 0;
																		goto IL_0613;
																		continue;
																		end_IL_0240:
																		break;
																	}
																	continue;
																	end_IL_0250:
																	break;
																}
																continue;
																end_IL_0260:
																break;
															}
															continue;
														}
														goto IL_0702;
														IL_0702:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_062f:
														break;
													}
													continue;
													end_IL_0642:
													break;
												}
												continue;
												end_IL_0655:
												break;
											}
											continue;
											end_IL_0660:
											break;
										}
										continue;
										end_IL_0675:
										break;
									}
									continue;
									end_IL_068a:
									break;
								}
								continue;
								end_IL_06a3:
								break;
							}
							continue;
							end_IL_06b3:
							break;
						}
						continue;
						end_IL_06c3:
						break;
					}
					continue;
					end_IL_06d3:
					break;
				}
				continue;
				end_IL_06de:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 87;
		object[] array2 = default(object[]);
		int num4 = default(int);
		byte* ptr = default(byte*);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 122;
					while (true)
					{
						if (num != 122)
						{
							if (num != 1103)
							{
								goto IL_0594;
							}
							switch (num)
							{
							case 78:
							case 97:
								goto end_IL_01f7;
							case 86:
								goto end_IL_0207;
							case 87:
								goto end_IL_0220;
							case 2:
							case 36:
								goto IL_0249;
							case 84:
								goto IL_0257;
							case 26:
								goto IL_0265;
							case 3:
								goto IL_0278;
							case 57:
								goto IL_0281;
							case 5:
							case 8:
							case 14:
							case 15:
							case 31:
							case 37:
							case 40:
							case 44:
							case 49:
							case 50:
							case 55:
							case 58:
							case 69:
							case 96:
								goto IL_0289;
							case 94:
								goto IL_0299;
							case 17:
								goto IL_02a2;
							case 111:
								goto IL_02ab;
							case 12:
								goto IL_02b9;
							case 91:
								goto IL_02c7;
							case 16:
								goto IL_02d5;
							case 61:
							case 81:
								goto IL_02e3;
							case 34:
								goto IL_02f1;
							case 45:
							case 64:
								goto IL_02ff;
							case 4:
							case 59:
								goto IL_030a;
							case 1:
								goto IL_0318;
							case 32:
							case 51:
								goto IL_0326;
							case 79:
								goto IL_0349;
							case 104:
								goto IL_0357;
							case 27:
								goto IL_0365;
							case 90:
								goto IL_0378;
							case 73:
							case 76:
								goto IL_0386;
							case 85:
								goto IL_03c6;
							case 108:
								goto IL_03da;
							case 113:
							case 115:
								goto IL_03ed;
							case 109:
								goto IL_044f;
							case 6:
							case 82:
								goto IL_0462;
							case 62:
								goto IL_046d;
							case 19:
							case 63:
								goto IL_047b;
							case 102:
								goto IL_0497;
							case 107:
								goto IL_04a5;
							case 68:
								goto IL_04b8;
							case 25:
							case 42:
								goto IL_04c3;
							case 80:
								goto IL_0503;
							case 22:
								goto IL_0517;
							case 39:
								goto IL_052a;
							case 56:
								goto IL_0538;
							case 112:
							case 114:
								goto IL_0546;
							case 100:
								goto IL_0551;
							case 72:
							case 75:
								goto IL_055f;
							case 106:
								goto IL_0578;
							case 95:
								goto IL_0586;
							case 9:
								goto IL_0594;
							case 41:
							case 88:
								goto IL_05b0;
							case 74:
								goto IL_05be;
							case 20:
							case 110:
								goto IL_05cc;
							case 105:
								goto IL_05f5;
							case 10:
								goto IL_0603;
							case 0:
							case 70:
								goto IL_0616;
							case 46:
								goto IL_062e;
							case 28:
							case 101:
								goto IL_0639;
							case 99:
								goto IL_0644;
							case 23:
							case 52:
								goto IL_064f;
							case 89:
								goto IL_065d;
							case 13:
								goto IL_0680;
							case 54:
								goto IL_068a;
							case 11:
								goto IL_0698;
							case 77:
								goto IL_06ab;
							case 7:
							case 18:
							case 21:
							case 24:
							case 30:
							case 33:
							case 35:
							case 38:
							case 43:
							case 47:
							case 48:
							case 53:
							case 60:
							case 65:
							case 66:
							case 67:
							case 83:
							case 92:
							case 93:
							case 98:
							case 103:
								goto IL_06b9;
							case 29:
							case 71:
								goto IL_06da;
							}
							continue;
						}
						array2 = new object[3];
						goto IL_0249;
						IL_0680:
						array2[num4] = null;
						goto IL_068a;
						IL_0698:
						ptr += 8;
						goto IL_0289;
						IL_068a:
						num4++;
						goto IL_0698;
						IL_0249:
						array3 = new int[4];
						goto IL_0257;
						IL_0257:
						array4 = new long[3];
						goto IL_0265;
						IL_0265:
						array3[0] = int_2;
						goto IL_0278;
						IL_0278:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExponentHasLocalValues.opGreaterThanOrEqualInvariantCultureIgnoreCase);
						goto IL_0281;
						IL_0281:
						ptr = ptr2;
						goto IL_0289;
						IL_0289:
						if (num5 != 1)
						{
							goto IL_0299;
						}
						num = 29;
						goto IL_06da;
						IL_06ab:
						if (4 <= b)
						{
							goto IL_0289;
						}
						goto IL_06b9;
						IL_06da:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						IL_0299:
						num = 17;
						goto IL_02a2;
						IL_02a2:
						b = *ptr;
						goto IL_02ab;
						IL_02ab:
						ptr++;
						goto IL_02b9;
						IL_02b9:
						if (b >= 1)
						{
							goto IL_02c7;
						}
						goto IL_06b9;
						IL_02c7:
						if (b <= 11)
						{
							goto IL_02d5;
						}
						goto IL_06b9;
						IL_02d5:
						if (6 < b)
						{
							goto IL_02e3;
						}
						goto IL_04b8;
						IL_02e3:
						if (9 >= b)
						{
							goto IL_02f1;
						}
						goto IL_0462;
						IL_02f1:
						if (9 > b)
						{
							goto IL_02ff;
						}
						goto IL_03ed;
						IL_02ff:
						if (7 < b)
						{
							goto IL_030a;
						}
						goto IL_0378;
						IL_030a:
						if (8 >= b)
						{
							goto IL_0318;
						}
						goto IL_06b9;
						IL_0318:
						if (8 <= b)
						{
							goto IL_0326;
						}
						goto IL_06b9;
						IL_0326:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
						goto IL_0349;
						IL_0349:
						array[num4] = 0;
						goto IL_0357;
						IL_0357:
						num4++;
						goto IL_0365;
						IL_0365:
						ptr += 8;
						goto IL_0289;
						IL_0378:
						if (7 <= b)
						{
							goto IL_0386;
						}
						goto IL_06b9;
						IL_0386:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						goto IL_03c6;
						IL_03c6:
						array[num4 - 2] = 0;
						goto IL_03da;
						IL_03da:
						num4--;
						goto IL_0289;
						IL_03ed:
						ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						goto IL_044f;
						IL_044f:
						num4 -= 2;
						goto IL_0289;
						IL_0462:
						if (10 >= b)
						{
							goto IL_046d;
						}
						goto IL_0497;
						IL_046d:
						if (10 <= b)
						{
							goto IL_047b;
						}
						goto IL_06b9;
						IL_047b:
						byte* num6 = ptr;
						num5 = 1;
						ptr = num6 + -200;
						goto IL_0289;
						IL_0497:
						if (11 >= b)
						{
							goto IL_04a5;
						}
						goto IL_06b9;
						IL_04a5:
						if (11 > b)
						{
						}
						goto IL_06b9;
						IL_04b8:
						if (6 <= b)
						{
							goto IL_04c3;
						}
						goto IL_052a;
						IL_04c3:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						goto IL_0503;
						IL_0503:
						array[num4 - 2] = 0;
						goto IL_0517;
						IL_0517:
						num4--;
						goto IL_0289;
						IL_052a:
						if (3 >= b)
						{
							goto IL_0538;
						}
						goto IL_062e;
						IL_0538:
						if (3 > b)
						{
							goto IL_0546;
						}
						goto IL_0616;
						IL_0546:
						if (1 >= b)
						{
							goto IL_0551;
						}
						num = 88;
						goto IL_05b0;
						IL_0551:
						if (1 <= b)
						{
							goto IL_055f;
						}
						goto IL_06b9;
						IL_055f:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
						goto IL_0578;
						IL_0578:
						array[num4] = 0;
						goto IL_0586;
						IL_0586:
						num4++;
						goto IL_0594;
						IL_0594:
						ptr += 8;
						goto IL_0289;
						IL_06b9:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_0289;
						IL_05b0:
						if (2 >= b)
						{
							goto IL_05be;
						}
						goto IL_06b9;
						IL_05be:
						if (2 <= b)
						{
							goto IL_05cc;
						}
						goto IL_06b9;
						IL_05cc:
						ref int reference = ref array3[*(int*)(ptr + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
						goto IL_05f5;
						IL_05f5:
						ptr += 8;
						goto IL_0603;
						IL_0603:
						num4--;
						goto IL_0289;
						IL_0616:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_0289;
						IL_062e:
						if (4 < b)
						{
							goto IL_0639;
						}
						goto IL_06ab;
						IL_0639:
						if (5 >= b)
						{
							goto IL_0644;
						}
						goto IL_06b9;
						IL_0644:
						if (5 <= b)
						{
							goto IL_064f;
						}
						goto IL_06b9;
						IL_064f:
						array[num4] = 0;
						goto IL_065d;
						IL_065d:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
						goto IL_0680;
						continue;
						end_IL_01f7:
						break;
					}
					continue;
					end_IL_0207:
					break;
				}
				continue;
				end_IL_0220:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getInheritedObjectAceTypeClientReceive.PackingSizeReadLinesIterator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0321:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0304:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02f4:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02e4:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02d4:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02c4:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02b4:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0286:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 153;
																														while (true)
																														{
																															if (num != 153)
																															{
																																if (num != 1134)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 95:
																																	goto IL_0286;
																																case 8:
																																case 98:
																																	goto IL_02b4;
																																case 131:
																																	goto IL_02c4;
																																case 23:
																																case 128:
																																	goto IL_02d4;
																																case 26:
																																	goto IL_02e4;
																																case 93:
																																	goto IL_02f4;
																																case 100:
																																	goto IL_0304;
																																case 80:
																																	goto IL_0311;
																																case 6:
																																	goto IL_0321;
																																case 45:
																																	goto end_IL_0321;
																																case 72:
																																case 101:
																																	goto end_IL_0331;
																																case 31:
																																	goto IL_034c;
																																case 82:
																																case 89:
																																	goto IL_035a;
																																case 5:
																																	goto IL_0368;
																																case 37:
																																case 53:
																																	goto IL_0373;
																																case 77:
																																	goto IL_0391;
																																case 73:
																																	goto IL_039f;
																																case 48:
																																	goto IL_03b2;
																																case 65:
																																	goto IL_03bd;
																																case 91:
																																case 92:
																																	goto IL_03d0;
																																case 44:
																																	goto IL_03de;
																																case 81:
																																case 84:
																																	goto IL_03ec;
																																case 108:
																																	goto IL_0423;
																																case 39:
																																	goto IL_042e;
																																case 54:
																																	goto IL_043c;
																																case 63:
																																case 105:
																																	goto IL_044a;
																																case 12:
																																	goto IL_0473;
																																case 97:
																																	goto IL_0481;
																																case 99:
																																	goto IL_0494;
																																case 29:
																																case 106:
																																	goto IL_049f;
																																case 103:
																																	goto IL_04ad;
																																case 33:
																																case 119:
																																	goto IL_04bb;
																																case 43:
																																	goto IL_04c9;
																																case 112:
																																	goto IL_04e1;
																																case 36:
																																	goto IL_04ef;
																																case 88:
																																case 121:
																																	goto IL_0502;
																																case 4:
																																	goto IL_0541;
																																case 2:
																																case 123:
																																	goto IL_0554;
																																case 126:
																																	goto IL_0594;
																																case 34:
																																	goto IL_05a8;
																																case 107:
																																case 130:
																																	goto IL_05bb;
																																case 49:
																																case 138:
																																	goto IL_05d3;
																																case 10:
																																	goto IL_05e1;
																																case 66:
																																case 139:
																																	goto IL_05ef;
																																case 114:
																																	goto IL_0608;
																																case 58:
																																	goto IL_0616;
																																case 104:
																																	goto IL_0624;
																																case 140:
																																	goto IL_0640;
																																case 60:
																																	goto IL_0663;
																																case 21:
																																	goto IL_0671;
																																case 28:
																																	goto IL_0684;
																																case 38:
																																	goto IL_0692;
																																case 7:
																																	goto IL_06a5;
																																case 16:
																																	goto IL_06b3;
																																case 50:
																																case 83:
																																	goto IL_06c1;
																																case 74:
																																	goto IL_0705;
																																case 96:
																																	goto IL_0719;
																																case 0:
																																case 25:
																																	goto IL_072c;
																																case 51:
																																	goto IL_076c;
																																case 118:
																																	goto IL_0780;
																																case 64:
																																	goto IL_0793;
																																case 78:
																																	goto IL_07a1;
																																case 32:
																																case 87:
																																	goto IL_07ac;
																																case 70:
																																	goto IL_07c8;
																																case 46:
																																	goto IL_07d6;
																																case 69:
																																case 76:
																																	goto IL_07e4;
																																case 47:
																																	goto IL_0846;
																																case 109:
																																	goto IL_085f;
																																case 55:
																																	goto IL_086a;
																																case 1:
																																case 3:
																																case 9:
																																case 13:
																																case 14:
																																case 17:
																																case 20:
																																case 22:
																																case 27:
																																case 52:
																																case 56:
																																case 61:
																																case 62:
																																case 85:
																																case 86:
																																case 110:
																																case 111:
																																case 113:
																																case 117:
																																case 124:
																																case 127:
																																case 129:
																																case 132:
																																case 134:
																																case 136:
																																case 137:
																																case 141:
																																case 144:
																																	goto end_IL_0273;
																																case 11:
																																case 15:
																																case 18:
																																case 35:
																																case 41:
																																case 59:
																																case 71:
																																case 75:
																																case 79:
																																case 90:
																																case 102:
																																case 116:
																																case 120:
																																case 133:
																																case 135:
																																case 143:
																																case 145:
																																case 146:
																																	goto end_IL_0341;
																																case 40:
																																	goto end_IL_0888;
																																case 94:
																																	goto end_IL_089b;
																																case 115:
																																	goto end_IL_08a5;
																																case 24:
																																	goto end_IL_08b0;
																																case 30:
																																case 42:
																																	goto end_IL_08c0;
																																case 19:
																																	goto end_IL_08d0;
																																case 57:
																																case 142:
																																	goto end_IL_08e0;
																																case 67:
																																	goto end_IL_08f0;
																																case 68:
																																	goto end_IL_0900;
																																case 122:
																																case 125:
																																	goto IL_091b;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_0663;
																															IL_0663:
																															num5++;
																															goto IL_0671;
																															IL_0671:
																															ptr2 += 8;
																															goto end_IL_0341;
																															continue;
																															end_IL_0273:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0684;
																											IL_0692:
																											if (9 > b)
																											{
																												break;
																											}
																											goto end_IL_0341;
																											IL_0684:
																											if (9 < b)
																											{
																												break;
																											}
																											goto IL_0692;
																										}
																										break;
																									}
																									goto IL_06a5;
																									IL_0719:
																									num5--;
																									goto end_IL_0341;
																									IL_06a5:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_06b3;
																									IL_06b3:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_06c1;
																									IL_06c1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0705;
																									IL_0705:
																									array[num5 - 2] = 0;
																									goto IL_0719;
																								}
																								break;
																							}
																							goto IL_072c;
																							IL_0780:
																							num5--;
																							goto end_IL_0341;
																							IL_072c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_076c;
																							IL_076c:
																							array[num5 - 2] = 0;
																							goto IL_0780;
																						}
																						break;
																					}
																					goto IL_0793;
																					IL_086a:
																					if (15 > b)
																					{
																					}
																					break;
																					IL_0793:
																					if (14 >= b)
																					{
																						goto IL_07a1;
																					}
																					goto IL_085f;
																					IL_07a1:
																					if (14 <= b)
																					{
																						goto IL_07ac;
																					}
																					goto IL_07c8;
																					IL_07ac:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0341;
																					IL_07c8:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_07d6;
																					IL_07d6:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_07e4;
																					IL_07e4:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0846;
																					IL_0846:
																					num5 -= 2;
																					num = 145;
																					goto end_IL_0341;
																					IL_085f:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_086a;
																				}
																				break;
																			}
																			goto IL_034c;
																			IL_05bb:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0341;
																			IL_034c:
																			if (8 > b)
																			{
																				goto IL_035a;
																			}
																			goto IL_05bb;
																			IL_035a:
																			if (4 >= b)
																			{
																				goto IL_0368;
																			}
																			goto IL_0423;
																			IL_0368:
																			if (4 <= b)
																			{
																				goto IL_0373;
																			}
																			goto IL_03b2;
																			IL_0373:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0391;
																			IL_0391:
																			ptr2 += 8;
																			goto IL_039f;
																			IL_039f:
																			num5--;
																			goto end_IL_0341;
																			IL_03b2:
																			if (2 >= b)
																			{
																				goto IL_03bd;
																			}
																			goto IL_03d0;
																			IL_03bd:
																			if (2 <= b)
																			{
																				goto IL_0554;
																			}
																			goto IL_05d3;
																			IL_05d3:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_05e1;
																			IL_05e1:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05ef;
																			IL_05ef:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0608;
																			IL_0608:
																			array[num5] = 0;
																			goto IL_0616;
																			IL_0616:
																			num5++;
																			goto IL_0624;
																			IL_0624:
																			ptr2 += 8;
																			num = 116;
																			goto end_IL_0341;
																			IL_0554:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0594;
																			IL_0594:
																			array[num5 - 2] = 0;
																			goto IL_05a8;
																			IL_05a8:
																			num5--;
																			goto end_IL_0341;
																			IL_03d0:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_03de;
																			IL_03de:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_03ec;
																			IL_03ec:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 140;
																			goto IL_0640;
																			IL_0640:
																			array[num5 - 1] = 5;
																			goto end_IL_0341;
																			IL_0423:
																			if (6 < b)
																			{
																				goto IL_042e;
																			}
																			goto IL_0494;
																			IL_042e:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_043c;
																			IL_043c:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_044a;
																			IL_044a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0473;
																			IL_0473:
																			ptr2 += 8;
																			goto IL_0481;
																			IL_0481:
																			num5--;
																			goto end_IL_0341;
																			IL_0494:
																			if (6 > b)
																			{
																				goto IL_049f;
																			}
																			goto IL_0502;
																			IL_049f:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_04ad;
																			IL_04ad:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_04bb;
																			IL_04bb:
																			array[num5] = 5;
																			goto IL_04c9;
																			IL_04c9:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_04e1;
																			IL_04e1:
																			num5++;
																			goto IL_04ef;
																			IL_04ef:
																			ptr2 += 8;
																			goto end_IL_0341;
																			IL_0502:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0541;
																			IL_0541:
																			num5 -= 3;
																			goto end_IL_0341;
																		}
																		break;
																		IL_0311:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0341;
																continue;
																end_IL_0321:
																break;
															}
															continue;
															end_IL_0331:
															break;
														}
														continue;
														end_IL_0341:
														break;
													}
													continue;
												}
												goto IL_091b;
												IL_091b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0888:
												break;
											}
											continue;
											end_IL_089b:
											break;
										}
										continue;
										end_IL_08a5:
										break;
									}
									continue;
									end_IL_08b0:
									break;
								}
								continue;
								end_IL_08c0:
								break;
							}
							continue;
							end_IL_08d0:
							break;
						}
						continue;
						end_IL_08e0:
						break;
					}
					continue;
					end_IL_08f0:
					break;
				}
				continue;
				end_IL_0900:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 12;
		long[] array = default(long[]);
		int num4 = default(int);
		byte[] array2 = default(byte[]);
		object[] array3 = default(object[]);
		int[] array4 = default(int[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 142;
				while (true)
				{
					if (num == 142)
					{
						goto IL_027b;
					}
					if (num != 1123)
					{
						goto IL_0668;
					}
					switch (num)
					{
					case 11:
						goto end_IL_0247;
					case 12:
						goto end_IL_0257;
					case 111:
						goto IL_027b;
					case 30:
						goto IL_0289;
					case 40:
					case 55:
						goto IL_0297;
					case 109:
						goto IL_02ae;
					case 103:
						goto IL_02c5;
					case 48:
						goto IL_02d8;
					case 77:
						goto IL_02ea;
					case 21:
					case 25:
					case 43:
					case 61:
					case 70:
					case 76:
					case 79:
					case 80:
					case 90:
					case 94:
					case 106:
					case 115:
					case 123:
					case 124:
					case 125:
					case 130:
					case 133:
						goto IL_02f2;
					case 16:
					case 49:
						goto IL_0302;
					case 83:
						goto IL_030b;
					case 92:
						goto IL_0319;
					case 122:
						goto IL_0327;
					case 72:
						goto IL_0335;
					case 13:
					case 59:
						goto IL_0343;
					case 10:
					case 17:
						goto IL_0351;
					case 32:
						goto IL_035c;
					case 64:
					case 84:
						goto IL_0367;
					case 69:
						goto IL_0383;
					case 14:
						goto IL_0391;
					case 2:
					case 19:
						goto IL_039f;
					case 20:
						goto IL_03b2;
					case 93:
						goto IL_03c0;
					case 75:
						goto IL_03d3;
					case 0:
					case 127:
						goto IL_03e1;
					case 3:
					case 66:
						goto IL_03ef;
					case 87:
						goto IL_03fd;
					case 7:
					case 9:
						goto IL_040b;
					case 38:
						goto IL_044b;
					case 4:
						goto IL_045f;
					case 135:
						goto IL_0472;
					case 134:
						goto IL_047d;
					case 107:
						goto IL_048b;
					case 39:
					case 81:
						goto IL_0499;
					case 56:
						goto IL_04bc;
					case 35:
						goto IL_04ca;
					case 120:
						goto IL_04d8;
					case 18:
					case 71:
						goto IL_04fd;
					case 73:
						goto IL_055f;
					case 37:
					case 50:
						goto IL_0572;
					case 57:
						goto IL_0586;
					case 108:
						goto IL_05c5;
					case 116:
						goto IL_05d8;
					case 33:
					case 112:
						goto IL_05e6;
					case 46:
						goto IL_05f4;
					case 45:
						goto IL_0602;
					case 62:
						goto IL_060d;
					case 58:
						goto IL_061b;
					case 113:
					case 129:
						goto IL_062e;
					case 28:
						goto IL_063c;
					case 95:
						goto IL_0668;
					case 121:
						goto IL_0672;
					case 42:
						goto IL_0680;
					case 15:
					case 23:
						goto IL_0693;
					case 36:
						goto IL_06a1;
					case 85:
					case 126:
						goto IL_06af;
					case 44:
						goto IL_06ef;
					case 54:
						goto IL_0703;
					case 34:
						goto IL_0716;
					case 1:
					case 104:
						goto IL_0724;
					case 119:
						goto IL_072f;
					case 31:
					case 41:
						goto IL_073d;
					case 105:
						goto IL_0756;
					case 99:
						goto IL_0764;
					case 117:
						goto IL_0772;
					case 60:
						goto IL_0785;
					case 96:
						goto IL_0793;
					case 53:
					case 67:
						goto IL_07aa;
					case 52:
						goto IL_07d3;
					case 65:
						goto IL_07e1;
					case 26:
					case 27:
						goto IL_07f4;
					case 89:
					case 128:
						goto IL_0815;
					case 100:
						goto IL_0855;
					case 6:
						goto IL_0869;
					case 5:
					case 22:
					case 24:
					case 29:
					case 47:
					case 51:
					case 63:
					case 68:
					case 74:
					case 78:
					case 82:
					case 86:
					case 88:
					case 91:
					case 97:
					case 98:
					case 101:
					case 102:
					case 110:
					case 114:
					case 118:
					case 131:
						goto IL_087c;
					case 8:
					case 132:
						goto IL_0894;
					}
					continue;
					IL_0815:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]);
					goto IL_0855;
					IL_0855:
					array2[num4 - 2] = 0;
					goto IL_0869;
					IL_027b:
					array2 = new byte[3];
					goto IL_0289;
					IL_0289:
					array3 = new object[3];
					goto IL_0297;
					IL_0297:
					array4 = new int[4];
					num = 109;
					goto IL_02ae;
					IL_02ae:
					array = new long[3];
					num = 103;
					goto IL_02c5;
					IL_02c5:
					array4[0] = int_2;
					goto IL_02d8;
					IL_02d8:
					ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileDialogPermissiongetAccountDomainSid.TypeInitializergetParamNames);
					num = 77;
					goto IL_02ea;
					IL_02ea:
					ptr2 = ptr;
					goto IL_02f2;
					IL_02f2:
					if (num5 != 1)
					{
						goto IL_0302;
					}
					goto IL_0894;
					IL_0894:
					return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]);
					IL_0302:
					b = *ptr2;
					goto IL_030b;
					IL_030b:
					ptr2++;
					goto IL_0319;
					IL_0319:
					if (b >= 1)
					{
						goto IL_0327;
					}
					goto IL_087c;
					IL_0327:
					if (b <= 14)
					{
						goto IL_0335;
					}
					goto IL_087c;
					IL_0335:
					if (7 < b)
					{
						goto IL_0343;
					}
					goto IL_05d8;
					IL_0343:
					if (11 < b)
					{
						goto IL_0351;
					}
					goto IL_03d3;
					IL_0351:
					if (13 >= b)
					{
						goto IL_035c;
					}
					goto IL_03b2;
					IL_035c:
					if (13 <= b)
					{
						goto IL_0367;
					}
					goto IL_0383;
					IL_0367:
					byte* num6 = ptr2;
					num5 = 1;
					ptr2 = num6 + -200;
					goto IL_02f2;
					IL_0383:
					if (12 >= b)
					{
						goto IL_0391;
					}
					goto IL_087c;
					IL_0391:
					if (12 <= b)
					{
						goto IL_039f;
					}
					goto IL_087c;
					IL_039f:
					num4--;
					goto IL_02f2;
					IL_03b2:
					if (14 >= b)
					{
						goto IL_03c0;
					}
					goto IL_087c;
					IL_03c0:
					if (14 <= b)
					{
					}
					goto IL_087c;
					IL_03d3:
					if (11 > b)
					{
						goto IL_03e1;
					}
					goto IL_0572;
					IL_03e1:
					if (9 < b)
					{
						goto IL_03ef;
					}
					goto IL_0472;
					IL_03ef:
					if (10 >= b)
					{
						goto IL_03fd;
					}
					goto IL_087c;
					IL_03fd:
					if (10 <= b)
					{
						goto IL_040b;
					}
					goto IL_087c;
					IL_040b:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]);
					goto IL_044b;
					IL_044b:
					array2[num4 - 2] = 0;
					goto IL_045f;
					IL_045f:
					num4--;
					goto IL_02f2;
					IL_0472:
					if (9 > b)
					{
						goto IL_047d;
					}
					num = 71;
					goto IL_04fd;
					IL_047d:
					if (8 >= b)
					{
						goto IL_048b;
					}
					goto IL_087c;
					IL_048b:
					if (8 <= b)
					{
						goto IL_0499;
					}
					goto IL_087c;
					IL_0499:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4]) = array4[*(int*)(ptr2 + num3)];
					goto IL_04bc;
					IL_04bc:
					array2[num4] = 0;
					goto IL_04ca;
					IL_04ca:
					num4++;
					goto IL_04d8;
					IL_04d8:
					ptr2 += 8;
					num = 21;
					goto IL_02f2;
					IL_0869:
					num4--;
					goto IL_02f2;
					IL_04fd:
					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
					goto IL_055f;
					IL_055f:
					num4 -= 2;
					goto IL_02f2;
					IL_0572:
					array2[num4 - 1] = 0;
					goto IL_0586;
					IL_0586:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]) = ((delegate*<int, int>)SafeProcessHandleConcurrentExclusiveSchedulerPair[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]));
					goto IL_05c5;
					IL_05c5:
					ptr2 += 8;
					goto IL_02f2;
					IL_05d8:
					if (7 > b)
					{
						goto IL_05e6;
					}
					goto IL_0815;
					IL_05e6:
					if (3 < b)
					{
						goto IL_05f4;
					}
					goto IL_0716;
					IL_05f4:
					if (5 >= b)
					{
						goto IL_0602;
					}
					goto IL_0693;
					IL_0602:
					if (5 > b)
					{
						goto IL_060d;
					}
					goto IL_062e;
					IL_060d:
					if (4 >= b)
					{
						goto IL_061b;
					}
					goto IL_087c;
					IL_061b:
					if (4 <= b)
					{
						goto IL_02f2;
					}
					goto IL_087c;
					IL_062e:
					array2[num4] = 0;
					goto IL_063c;
					IL_063c:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4]) = array4[*(int*)(ptr2 + num3)];
					num = 95;
					goto IL_0668;
					IL_0668:
					array3[num4] = null;
					goto IL_0672;
					IL_0672:
					num4++;
					goto IL_0680;
					IL_0680:
					ptr2 += 8;
					goto IL_02f2;
					IL_0693:
					if (6 >= b)
					{
						goto IL_06a1;
					}
					goto IL_087c;
					IL_06a1:
					if (6 <= b)
					{
						goto IL_06af;
					}
					goto IL_087c;
					IL_06af:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]);
					goto IL_06ef;
					IL_06ef:
					array2[num4 - 2] = 0;
					goto IL_0703;
					IL_0703:
					num4--;
					goto IL_02f2;
					IL_0716:
					if (3 > b)
					{
						goto IL_0724;
					}
					goto IL_07f4;
					IL_0724:
					if (1 >= b)
					{
						goto IL_072f;
					}
					goto IL_0785;
					IL_072f:
					if (1 <= b)
					{
						goto IL_073d;
					}
					goto IL_087c;
					IL_073d:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4]) = *(int*)(ptr2 + num3);
					goto IL_0756;
					IL_0756:
					array2[num4] = 0;
					goto IL_0764;
					IL_0764:
					num4++;
					goto IL_0772;
					IL_0772:
					ptr2 += 8;
					goto IL_02f2;
					IL_0785:
					if (2 >= b)
					{
						goto IL_0793;
					}
					goto IL_087c;
					IL_0793:
					if (2 <= b)
					{
						num = 67;
						goto IL_07aa;
					}
					goto IL_087c;
					IL_087c:
					ptr2 = ptr + *(int*)(ptr2 + num3);
					goto IL_02f2;
					IL_07aa:
					ref int reference = ref array4[*(int*)(ptr2 + num3)];
					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[num4 - 1]);
					goto IL_07d3;
					IL_07d3:
					ptr2 += 8;
					goto IL_07e1;
					IL_07e1:
					num4--;
					goto IL_02f2;
					IL_07f4:
					ptr2 = ptr + *(int*)(ptr2 + num3);
					num = 94;
					goto IL_02f2;
					continue;
					end_IL_0247:
					break;
				}
				continue;
				end_IL_0257:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 20;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 40;
								while (true)
								{
									array3[0] = int_2;
									num = 100;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref filterListgetEscapedCodeBase.AMDCreatePartialActivationContext);
										num = 87;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0284:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0267:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0257:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0247:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0237:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0227:
																											if (1 < b)
																											{
																												while (true)
																												{
																													IL_0214:
																													if (2 < b)
																													{
																														num = 121;
																														while (num != 121)
																														{
																															if (num != 1102)
																															{
																																goto IL_0274;
																															}
																															switch (num)
																															{
																															case 39:
																															case 62:
																																goto IL_0214;
																															case 11:
																																goto IL_0227;
																															case 75:
																																goto IL_0237;
																															case 0:
																															case 38:
																																goto IL_0247;
																															case 50:
																																goto IL_0257;
																															case 86:
																																goto IL_0267;
																															case 77:
																																goto IL_0274;
																															case 49:
																																goto IL_0284;
																															case 53:
																																goto end_IL_0284;
																															case 1:
																															case 80:
																																goto end_IL_0294;
																															case 5:
																															case 17:
																																goto IL_02af;
																															case 41:
																																goto IL_02ba;
																															case 67:
																																goto IL_02c5;
																															case 55:
																															case 76:
																																goto IL_02d5;
																															case 29:
																															case 97:
																																goto IL_02e5;
																															case 81:
																															case 109:
																																goto IL_0301;
																															case 113:
																																goto IL_0319;
																															case 114:
																																goto IL_032c;
																															case 85:
																															case 107:
																																goto IL_0337;
																															case 68:
																																goto IL_0399;
																															case 94:
																																goto IL_03ac;
																															case 8:
																															case 90:
																																goto IL_03b7;
																															case 71:
																																goto IL_03c5;
																															case 47:
																															case 106:
																																goto IL_03d3;
																															case 31:
																																goto IL_03f6;
																															case 63:
																																goto IL_0404;
																															case 105:
																																goto IL_0412;
																															case 92:
																																goto IL_0425;
																															case 25:
																															case 64:
																																goto IL_0433;
																															case 51:
																																goto IL_0473;
																															case 42:
																																goto IL_0487;
																															case 3:
																																goto IL_049a;
																															case 27:
																															case 56:
																																goto IL_04b1;
																															case 108:
																																goto IL_04da;
																															case 65:
																																goto IL_04e8;
																															case 46:
																																goto IL_04fb;
																															case 59:
																															case 70:
																																goto IL_0509;
																															case 79:
																																goto IL_0522;
																															case 89:
																																goto IL_0530;
																															case 45:
																																goto IL_053e;
																															case 61:
																																goto IL_0551;
																															case 60:
																																goto IL_055c;
																															case 78:
																																goto IL_0578;
																															case 69:
																																goto IL_0586;
																															case 19:
																															case 30:
																																goto IL_0594;
																															case 52:
																																goto IL_05a2;
																															case 103:
																																goto IL_05c5;
																															case 93:
																																goto IL_05cf;
																															case 43:
																																goto IL_05e6;
																															case 54:
																															case 88:
																																goto IL_05f9;
																															case 44:
																																goto IL_0639;
																															case 12:
																																goto IL_064d;
																															case 2:
																															case 10:
																															case 14:
																															case 16:
																															case 22:
																															case 24:
																															case 26:
																															case 28:
																															case 33:
																															case 35:
																															case 37:
																															case 72:
																															case 82:
																															case 83:
																															case 91:
																															case 95:
																															case 96:
																															case 98:
																															case 99:
																															case 102:
																															case 111:
																																goto end_IL_0201;
																															case 6:
																															case 9:
																															case 15:
																															case 21:
																															case 23:
																															case 34:
																															case 36:
																															case 57:
																															case 58:
																															case 66:
																															case 84:
																															case 104:
																															case 110:
																															case 112:
																																goto end_IL_02a4;
																															case 87:
																																goto end_IL_0679;
																															case 100:
																																goto end_IL_068c;
																															case 40:
																																goto end_IL_0696;
																															case 13:
																																goto end_IL_06aa;
																															case 18:
																															case 20:
																																goto end_IL_06c8;
																															case 7:
																																goto end_IL_06e1;
																															case 4:
																															case 101:
																																goto end_IL_06f1;
																															case 73:
																																goto end_IL_070a;
																															case 74:
																																goto end_IL_071a;
																															case 32:
																															case 48:
																																goto IL_0735;
																															}
																															continue;
																															end_IL_0201:
																															break;
																														}
																														break;
																													}
																													goto IL_049a;
																													IL_04b1:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_04da;
																													IL_04da:
																													ptr2 += 8;
																													goto IL_04e8;
																													IL_049a:
																													if (2 > b)
																													{
																														break;
																													}
																													num = 27;
																													goto IL_04b1;
																													IL_04e8:
																													num5--;
																													goto end_IL_02a4;
																												}
																												break;
																											}
																											goto IL_04fb;
																											IL_053e:
																											ptr2 += 8;
																											goto end_IL_02a4;
																											IL_04fb:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0509;
																											IL_0509:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0522;
																											IL_0522:
																											array[num5] = 0;
																											goto IL_0530;
																											IL_0530:
																											num5++;
																											goto IL_053e;
																										}
																										break;
																									}
																									goto IL_0301;
																									IL_0301:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02a4;
																								}
																								break;
																							}
																							goto IL_0551;
																							IL_05cf:
																							num5++;
																							num = 43;
																							goto IL_05e6;
																							IL_0551:
																							if (4 >= b)
																							{
																								goto IL_055c;
																							}
																							goto IL_0578;
																							IL_055c:
																							if (4 <= b)
																							{
																								goto end_IL_02a4;
																							}
																							num = 22;
																							break;
																							IL_05e6:
																							ptr2 += 8;
																							goto end_IL_02a4;
																							IL_0578:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0586;
																							IL_0586:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0594;
																							IL_0594:
																							array[num5] = 0;
																							goto IL_05a2;
																							IL_05a2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05c5;
																							IL_05c5:
																							array2[num5] = null;
																							goto IL_05cf;
																						}
																						break;
																					}
																					goto IL_05f9;
																					IL_064d:
																					num5--;
																					goto end_IL_02a4;
																					IL_05f9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0639;
																					IL_0639:
																					array[num5 - 2] = 0;
																					goto IL_064d;
																				}
																				break;
																			}
																			goto IL_02af;
																			IL_0487:
																			num5--;
																			goto end_IL_02a4;
																			IL_02af:
																			if (9 < b)
																			{
																				goto IL_02ba;
																			}
																			goto IL_032c;
																			IL_02ba:
																			if (10 >= b)
																			{
																				goto IL_02c5;
																			}
																			goto IL_02d5;
																			IL_02c5:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_02e5;
																			IL_02e5:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a4;
																			IL_02d5:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0319;
																			IL_0319:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_032c:
																			if (9 <= b)
																			{
																				goto IL_0337;
																			}
																			goto IL_03ac;
																			IL_0337:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0399;
																			IL_0399:
																			num5 -= 2;
																			goto end_IL_02a4;
																			IL_03ac:
																			if (7 < b)
																			{
																				goto IL_03b7;
																			}
																			goto IL_0425;
																			IL_03b7:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03c5;
																			IL_03c5:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03d3;
																			IL_03d3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03f6;
																			IL_03f6:
																			array[num5] = 0;
																			goto IL_0404;
																			IL_0404:
																			num5++;
																			goto IL_0412;
																			IL_0412:
																			ptr2 += 8;
																			goto end_IL_02a4;
																			IL_0425:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0433;
																			IL_0433:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0473;
																			IL_0473:
																			array[num5 - 2] = 0;
																			goto IL_0487;
																		}
																		break;
																		IL_0274:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 84;
																goto end_IL_02a4;
																continue;
																end_IL_0284:
																break;
															}
															continue;
															end_IL_0294:
															break;
														}
														continue;
														end_IL_02a4:
														break;
													}
													continue;
												}
												goto IL_0735;
												IL_0735:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0679:
												break;
											}
											continue;
											end_IL_068c:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06aa:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06e1:
							break;
						}
						continue;
						end_IL_06f1:
						break;
					}
					continue;
					end_IL_070a:
					break;
				}
				continue;
				end_IL_071a:
				break;
			}
		}
	}

	private static int smethod_6(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 31;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InfoLegacyBehavior.SymCustomAttrPredicate);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 56;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0235:
																byte b = *ptr2;
																while (true)
																{
																	IL_0225:
																	ptr2++;
																	while (true)
																	{
																		IL_0215:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_0205:
																				if (b <= 8)
																				{
																					while (true)
																					{
																						IL_01f8:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_01e8:
																								if (6 >= b)
																								{
																									while (6 > b)
																									{
																										num = 67;
																										while (true)
																										{
																											IL_01c2:
																											if (5 < b)
																											{
																												num = 97;
																												while (num != 97 && num == 1078)
																												{
																													switch (num)
																													{
																													case 59:
																													case 67:
																														goto IL_01c2;
																													case 34:
																														goto IL_01d5;
																													case 6:
																														goto IL_01e8;
																													case 77:
																														goto IL_01f8;
																													case 5:
																														goto IL_0205;
																													case 21:
																														goto IL_0215;
																													case 87:
																														goto IL_0225;
																													case 46:
																													case 88:
																														goto IL_0235;
																													case 22:
																														goto IL_0240;
																													case 15:
																													case 18:
																														goto IL_024b;
																													case 13:
																														goto IL_0256;
																													case 20:
																														goto IL_026d;
																													case 40:
																													case 74:
																														goto IL_0280;
																													case 73:
																														goto IL_02a9;
																													case 42:
																														goto IL_02b7;
																													case 79:
																														goto IL_02d3;
																													case 4:
																													case 12:
																														goto IL_02de;
																													case 10:
																														goto IL_02e9;
																													case 49:
																													case 75:
																														goto IL_030a;
																													case 0:
																													case 81:
																														goto IL_037a;
																													case 83:
																														goto IL_03bc;
																													case 84:
																														goto IL_03cf;
																													case 86:
																														goto IL_03e3;
																													case 68:
																														goto IL_03f6;
																													case 19:
																													case 26:
																														goto IL_040f;
																													case 23:
																														goto IL_0427;
																													case 54:
																														goto IL_0432;
																													case 1:
																														goto IL_0440;
																													case 9:
																													case 85:
																														goto IL_044e;
																													case 58:
																														goto IL_046a;
																													case 47:
																													case 70:
																														goto IL_0475;
																													case 63:
																														goto IL_0483;
																													case 25:
																														goto IL_04a6;
																													case 50:
																														goto IL_04b0;
																													case 17:
																														goto IL_04be;
																													case 2:
																													case 7:
																													case 14:
																													case 24:
																													case 28:
																													case 32:
																													case 33:
																													case 36:
																													case 37:
																													case 44:
																													case 53:
																													case 55:
																													case 64:
																													case 66:
																													case 76:
																													case 78:
																													case 80:
																													case 82:
																														goto end_IL_01af;
																													case 8:
																														goto IL_04fa;
																													case 60:
																														goto IL_0508;
																													case 39:
																														goto IL_0516;
																													case 3:
																													case 11:
																													case 27:
																													case 29:
																													case 41:
																													case 56:
																													case 57:
																													case 61:
																													case 72:
																													case 89:
																														goto end_IL_01d5;
																													case 38:
																														goto end_IL_0524;
																													case 90:
																														goto end_IL_0537;
																													case 16:
																														goto end_IL_0542;
																													case 69:
																														goto end_IL_054c;
																													case 65:
																														goto end_IL_0557;
																													case 51:
																														goto end_IL_056c;
																													case 35:
																													case 48:
																														goto end_IL_0581;
																													case 45:
																														goto end_IL_0591;
																													case 43:
																													case 62:
																														goto end_IL_05a1;
																													case 30:
																														goto end_IL_05b1;
																													case 31:
																														goto end_IL_05c1;
																													case 52:
																													case 71:
																														goto IL_05dc;
																													}
																													continue;
																													end_IL_01af:
																													break;
																												}
																												break;
																											}
																											goto IL_03f6;
																											IL_03f6:
																											if (5 > b)
																											{
																												num = 80;
																												break;
																											}
																											goto IL_040f;
																											IL_040f:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_01d5;
																										}
																										goto IL_04d7;
																										continue;
																										end_IL_01d5:
																										break;
																										IL_01d5:;
																									}
																									break;
																								}
																								goto IL_0427;
																								IL_04be:
																								ptr2 += 8;
																								break;
																								IL_0427:
																								if (7 < b)
																								{
																									goto IL_0432;
																								}
																								goto IL_046a;
																								IL_0432:
																								if (8 >= b)
																								{
																									goto IL_0440;
																								}
																								goto IL_04d7;
																								IL_0440:
																								if (8 <= b)
																								{
																									goto IL_044e;
																								}
																								goto IL_04d7;
																								IL_044e:
																								byte* num5 = ptr2;
																								num4 = 1;
																								ptr2 = num5 + -200;
																								break;
																								IL_046a:
																								if (7 <= b)
																								{
																									goto IL_0475;
																								}
																								goto IL_04d7;
																								IL_0475:
																								array[num6] = 0;
																								goto IL_0483;
																								IL_0483:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_04a6;
																								IL_04a6:
																								array2[num6] = null;
																								goto IL_04b0;
																								IL_04b0:
																								num6++;
																								goto IL_04be;
																							}
																							break;
																						}
																						goto IL_0240;
																						IL_0280:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_02a9;
																						IL_0240:
																						if (4 > b)
																						{
																							goto IL_024b;
																						}
																						goto IL_0280;
																						IL_024b:
																						if (2 < b)
																						{
																							goto IL_0256;
																						}
																						goto IL_02d3;
																						IL_0256:
																						if (3 >= b)
																						{
																							num = 20;
																							goto IL_026d;
																						}
																						goto IL_04d7;
																						IL_02a9:
																						ptr2 += 8;
																						goto IL_02b7;
																						IL_026d:
																						if (3 <= b)
																						{
																							goto IL_037a;
																						}
																						goto IL_04d7;
																						IL_037a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_03cf;
																						IL_03cf:
																						array[num6 - 2] = 0;
																						goto IL_03e3;
																						IL_03e3:
																						num6--;
																						break;
																						IL_02d3:
																						if (2 > b)
																						{
																							goto IL_02de;
																						}
																						goto IL_030a;
																						IL_02de:
																						if (1 >= b)
																						{
																							goto IL_02e9;
																						}
																						num = 82;
																						goto IL_04d7;
																						IL_02e9:
																						if (1 > b)
																						{
																						}
																						goto IL_04d7;
																						IL_02b7:
																						num6--;
																						num = 11;
																						break;
																						IL_030a:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_03bc;
																						IL_03bc:
																						num6 -= 2;
																						break;
																					}
																					break;
																				}
																				num = 53;
																				goto IL_04d7;
																			}
																			break;
																		}
																		goto IL_04d7;
																		IL_0516:
																		ptr2 += 8;
																		break;
																		IL_04d7:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04fa;
																		IL_04fa:
																		array[num6] = 0;
																		goto IL_0508;
																		IL_0508:
																		num6++;
																		goto IL_0516;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05dc;
														IL_05dc:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_0524:
														break;
													}
													continue;
													end_IL_0537:
													break;
												}
												continue;
												end_IL_0542:
												break;
											}
											continue;
											end_IL_054c:
											break;
										}
										continue;
										end_IL_0557:
										break;
									}
									continue;
									end_IL_056c:
									break;
								}
								continue;
								end_IL_0581:
								break;
							}
							continue;
							end_IL_0591:
							break;
						}
						continue;
						end_IL_05a1:
						break;
					}
					continue;
					end_IL_05b1:
					break;
				}
				continue;
				end_IL_05c1:
				break;
			}
		}
	}

	static Class186()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_0042:
					num = 11;
					while (true)
					{
						if (num != 11)
						{
							if (num != 992)
							{
								break;
							}
							switch (num)
							{
							case 2:
							case 3:
								goto IL_0042;
							case 0:
								goto end_IL_0035;
							case 1:
								goto end_IL_0051;
							case 4:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0035:
						break;
					}
					break;
				}
				continue;
				end_IL_0051:
				break;
			}
		}
	}
}
