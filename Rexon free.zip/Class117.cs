using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Rain", "Super Infection/Casual [MASTERCLIENT]", "Rains gadgets from above.", false, 34, ModType.const_0, false)]
internal class Class117 : MonoBehaviour
{
	private float float_0;

	private float float_1;

	private static bool bool_0;

	private static int int_0;

	private static double double_0;

	private static float float_2;

	private static bool bool_1;

	private static IntPtr[] getGeoIdAddRange;

	private static IntPtr[] TraceGuidQueryInfoSetCurrentThreadActivityId;

	private static IntPtr[] ReadAllLinesLdelemR;

	private static IntPtr[] IsNestedFamilyEventTooBig;

	private unsafe void Update()
	{
		int num = 91;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[6];
						while (true)
						{
							object[] array2 = new object[6];
							while (true)
							{
								int[] array3 = new int[6];
								while (true)
								{
									int[] array4 = new int[7];
									num = 766;
									while (true)
									{
										long[] array5 = new long[6];
										while (true)
										{
											object[] array6 = new object[1];
											num = 723;
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PanicLevelWhenAllPromise.IsGlobalTypeDefTokenNotApplicable);
													num = 387;
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 != 1)
															{
																while (true)
																{
																	IL_0dca:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0db1:
																		ptr2++;
																		num = 106;
																		while (true)
																		{
																			IL_0da1:
																			if (b >= 1)
																			{
																				while (b <= 95)
																				{
																					while (true)
																					{
																						IL_0d81:
																						if (48 >= b)
																						{
																							while (true)
																							{
																								IL_0d71:
																								if (48 > b)
																								{
																									while (true)
																									{
																										IL_0d61:
																										if (24 >= b)
																										{
																											while (true)
																											{
																												IL_0d51:
																												if (24 > b)
																												{
																													while (true)
																													{
																														IL_0d41:
																														if (12 < b)
																														{
																															while (true)
																															{
																																IL_0d31:
																																if (18 < b)
																																{
																																	while (true)
																																	{
																																		IL_0d21:
																																		if (21 < b)
																																		{
																																			while (true)
																																			{
																																				IL_0d11:
																																				if (22 < b)
																																				{
																																					while (23 >= b)
																																					{
																																						while (23 <= b)
																																						{
																																							num = 97;
																																							while (true)
																																							{
																																								IL_0ca3:
																																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																								num = 375;
																																								while (true)
																																								{
																																									IL_0c8d:
																																									array[num6 - 2] = 3;
																																									while (true)
																																									{
																																										IL_0c74:
																																										num6--;
																																										num = 785;
																																										while (num != 785)
																																										{
																																											if (num != 1766)
																																											{
																																												goto end_IL_0cee;
																																											}
																																											switch (num)
																																											{
																																											case 175:
																																												goto IL_0c74;
																																											case 375:
																																												goto IL_0c8d;
																																											case 97:
																																											case 397:
																																												goto IL_0ca3;
																																											case 182:
																																												goto IL_0cee;
																																											case 140:
																																												goto IL_0d01;
																																											case 689:
																																												goto IL_0d11;
																																											case 336:
																																												goto IL_0d21;
																																											case 541:
																																												goto IL_0d31;
																																											case 674:
																																												goto IL_0d41;
																																											case 461:
																																												goto IL_0d51;
																																											case 546:
																																												goto IL_0d61;
																																											case 340:
																																												goto IL_0d71;
																																											case 303:
																																												goto IL_0d81;
																																											case 166:
																																												goto IL_0d91;
																																											case 106:
																																												goto IL_0da1;
																																											case 114:
																																												goto IL_0db1;
																																											case 18:
																																											case 477:
																																												goto IL_0dca;
																																											case 239:
																																												goto IL_0dd5;
																																											case 22:
																																												goto IL_0de0;
																																											case 117:
																																											case 197:
																																												goto IL_0df9;
																																											case 30:
																																												goto IL_0e12;
																																											case 55:
																																												goto IL_0e20;
																																											case 324:
																																												goto IL_0e30;
																																											case 1:
																																											case 334:
																																												goto IL_0e40;
																																											case 335:
																																												goto IL_0e59;
																																											case 374:
																																												goto IL_0e6c;
																																											case 391:
																																												goto IL_0e7f;
																																											case 284:
																																											case 331:
																																												goto IL_0e8d;
																																											case 412:
																																												goto IL_0ea3;
																																											case 69:
																																											case 195:
																																												goto IL_0eb1;
																																											case 232:
																																												goto IL_0eea;
																																											case 11:
																																												goto IL_0efe;
																																											case 462:
																																												goto IL_0f11;
																																											case 241:
																																												goto IL_0f50;
																																											case 479:
																																												goto IL_0f63;
																																											case 384:
																																												goto IL_0fa2;
																																											case 576:
																																												goto IL_0fb5;
																																											case 357:
																																												goto IL_0fc3;
																																											case 233:
																																												goto IL_0fda;
																																											case 289:
																																											case 395:
																																												goto IL_0fe5;
																																											case 548:
																																												goto IL_1025;
																																											case 535:
																																												goto IL_103e;
																																											case 72:
																																												goto IL_104c;
																																											case 496:
																																												goto IL_105a;
																																											case 570:
																																												goto IL_1065;
																																											case 56:
																																												goto IL_1073;
																																											case 169:
																																												goto IL_108f;
																																											case 35:
																																											case 115:
																																												goto IL_109d;
																																											case 528:
																																												goto IL_10b6;
																																											case 88:
																																												goto IL_10c9;
																																											case 338:
																																												goto IL_10e2;
																																											case 14:
																																												goto IL_10f9;
																																											case 33:
																																											case 145:
																																												goto IL_1107;
																																											case 87:
																																												goto IL_1169;
																																											case 310:
																																											case 598:
																																												goto IL_117c;
																																											case 54:
																																												goto IL_11bc;
																																											case 279:
																																											case 629:
																																												goto IL_11d5;
																																											case 148:
																																												goto IL_11e3;
																																											case 633:
																																												goto IL_1204;
																																											case 423:
																																											case 575:
																																												goto IL_120f;
																																											case 98:
																																												goto IL_1233;
																																											case 348:
																																												goto IL_124f;
																																											case 293:
																																												goto IL_125d;
																																											case 450:
																																												goto IL_1268;
																																											case 46:
																																											case 638:
																																												goto IL_127b;
																																											case 430:
																																												goto IL_1294;
																																											case 647:
																																												goto IL_12a7;
																																											case 5:
																																												goto IL_12b5;
																																											case 10:
																																											case 85:
																																												goto IL_12c3;
																																											case 572:
																																												goto IL_12ea;
																																											case 345:
																																												goto IL_12f8;
																																											case 470:
																																												goto IL_1306;
																																											case 307:
																																											case 681:
																																												goto IL_1322;
																																											case 76:
																																												goto IL_133b;
																																											case 439:
																																												goto IL_1349;
																																											case 240:
																																												goto IL_1357;
																																											case 687:
																																												goto IL_136a;
																																											case 152:
																																												goto IL_1378;
																																											case 697:
																																												goto IL_138b;
																																											case 702:
																																												goto IL_139e;
																																											case 566:
																																												goto IL_13a9;
																																											case 156:
																																											case 277:
																																												goto IL_13b7;
																																											case 583:
																																												goto IL_13c5;
																																											case 178:
																																												goto IL_13e8;
																																											case 502:
																																												goto IL_13f2;
																																											case 322:
																																												goto IL_1409;
																																											case 396:
																																												goto IL_141c;
																																											case 93:
																																												goto IL_142a;
																																											case 705:
																																												goto IL_143d;
																																											case 451:
																																												goto IL_1454;
																																											case 390:
																																											case 706:
																																												goto IL_1467;
																																											case 457:
																																												goto IL_1490;
																																											case 669:
																																												goto IL_149e;
																																											case 712:
																																												goto IL_14ba;
																																											case 139:
																																											case 585:
																																												goto IL_14c5;
																																											case 109:
																																												goto IL_1505;
																																											case 382:
																																												goto IL_1519;
																																											case 242:
																																												goto IL_152c;
																																											case 365:
																																												goto IL_1537;
																																											case 6:
																																											case 701:
																																												goto IL_1545;
																																											case 125:
																																												goto IL_1585;
																																											case 53:
																																												goto IL_1599;
																																											case 351:
																																												goto IL_15ac;
																																											case 50:
																																												goto IL_15c3;
																																											case 80:
																																											case 486:
																																												goto IL_15d1;
																																											case 718:
																																												goto IL_15e4;
																																											case 101:
																																											case 716:
																																												goto IL_15ef;
																																											case 355:
																																												goto IL_1641;
																																											case 630:
																																												goto IL_165d;
																																											case 445:
																																												goto IL_166b;
																																											case 78:
																																												goto IL_1679;
																																											case 556:
																																											case 557:
																																												goto IL_1687;
																																											case 627:
																																												goto IL_16c8;
																																											case 111:
																																												goto IL_16dc;
																																											case 161:
																																												goto IL_16ef;
																																											case 230:
																																											case 549:
																																												goto IL_1706;
																																											case 727:
																																												goto IL_1727;
																																											case 619:
																																												goto IL_1735;
																																											case 733:
																																												goto IL_1748;
																																											case 124:
																																												goto IL_1756;
																																											case 606:
																																											case 746:
																																												goto IL_1769;
																																											case 618:
																																											case 771:
																																												goto IL_1785;
																																											case 316:
																																												goto IL_17c5;
																																											case 483:
																																												goto IL_17d9;
																																											case 777:
																																												goto IL_17ec;
																																											case 134:
																																												goto IL_17ff;
																																											case 694:
																																												goto IL_180d;
																																											case 37:
																																											case 137:
																																												goto IL_1818;
																																											case 207:
																																												goto IL_1832;
																																											case 504:
																																												goto IL_1845;
																																											case 686:
																																												goto IL_1853;
																																											case 522:
																																											case 673:
																																												goto IL_185e;
																																											case 688:
																																												goto IL_189e;
																																											case 492:
																																												goto IL_18b2;
																																											case 227:
																																												goto IL_18c5;
																																											case 500:
																																												goto IL_18d3;
																																											case 291:
																																											case 530:
																																												goto IL_18de;
																																											case 506:
																																												goto IL_190c;
																																											case 349:
																																												goto IL_1928;
																																											case 501:
																																												goto IL_1933;
																																											case 287:
																																											case 341:
																																												goto IL_1941;
																																											case 708:
																																												goto IL_1959;
																																											case 219:
																																												goto IL_1967;
																																											case 440:
																																												goto IL_1975;
																																											case 121:
																																												goto IL_1988;
																																											case 489:
																																												goto IL_1996;
																																											case 179:
																																											case 617:
																																												goto IL_19a4;
																																											case 422:
																																												goto IL_19b2;
																																											case 297:
																																												goto IL_19d6;
																																											case 480:
																																												goto IL_19e4;
																																											case 594:
																																												goto IL_19f7;
																																											case 464:
																																												goto IL_1a02;
																																											case 354:
																																												goto IL_1a10;
																																											case 79:
																																											case 768:
																																												goto IL_1a1e;
																																											case 769:
																																												goto IL_1a38;
																																											case 724:
																																												goto IL_1a4b;
																																											case 86:
																																											case 659:
																																												goto IL_1a59;
																																											case 403:
																																												goto IL_1a6d;
																																											case 381:
																																												goto IL_1aac;
																																											case 218:
																																												goto IL_1abf;
																																											case 623:
																																												goto IL_1acd;
																																											case 198:
																																											case 761:
																																												goto IL_1ad8;
																																											case 16:
																																												goto IL_1af6;
																																											case 41:
																																												goto IL_1b04;
																																											case 711:
																																												goto IL_1b12;
																																											case 59:
																																												goto IL_1b25;
																																											case 131:
																																												goto IL_1b30;
																																											case 472:
																																											case 529:
																																												goto IL_1b3e;
																																											case 173:
																																												goto IL_1b62;
																																											case 730:
																																												goto IL_1b70;
																																											case 380:
																																												goto IL_1b7e;
																																											case 625:
																																												goto IL_1b91;
																																											case 379:
																																												goto IL_1b9f;
																																											case 559:
																																											case 650:
																																												goto IL_1bad;
																																											case 555:
																																												goto IL_1bed;
																																											case 0:
																																												goto IL_1c01;
																																											case 642:
																																												goto IL_1c14;
																																											case 221:
																																												goto IL_1c1f;
																																											case 399:
																																											case 667:
																																												goto IL_1c36;
																																											case 155:
																																												goto IL_1c54;
																																											case 275:
																																												goto IL_1c62;
																																											case 360:
																																												goto IL_1c70;
																																											case 330:
																																												goto IL_1c83;
																																											case 643:
																																												goto IL_1c9a;
																																											case 256:
																																											case 446:
																																												goto IL_1ca8;
																																											case 509:
																																												goto IL_1cbc;
																																											case 678:
																																												goto IL_1d0e;
																																											case 645:
																																												goto IL_1d1c;
																																											case 376:
																																												goto IL_1d2f;
																																											case 684:
																																												goto IL_1d3d;
																																											case 693:
																																												goto IL_1d4b;
																																											case 286:
																																												goto IL_1d59;
																																											case 626:
																																												goto IL_1d67;
																																											case 260:
																																												goto IL_1d72;
																																											case 490:
																																											case 533:
																																												goto IL_1d80;
																																											case 107:
																																												goto IL_1d94;
																																											case 612:
																																												goto IL_1dd3;
																																											case 163:
																																												goto IL_1de6;
																																											case 9:
																																												goto IL_1df4;
																																											case 254:
																																											case 265:
																																												goto IL_1e02;
																																											case 553:
																																												goto IL_1e20;
																																											case 133:
																																											case 628:
																																												goto IL_1e3c;
																																											case 92:
																																												goto IL_1e6a;
																																											case 765:
																																												goto IL_1e7d;
																																											case 325:
																																												goto IL_1e88;
																																											case 320:
																																												goto IL_1e96;
																																											case 154:
																																											case 364:
																																												goto IL_1ea4;
																																											case 120:
																																												goto IL_1eb9;
																																											case 754:
																																												goto IL_1ecc;
																																											case 17:
																																											case 356:
																																												goto IL_1eda;
																																											case 393:
																																												goto IL_1eee;
																																											case 474:
																																												goto IL_1f2d;
																																											case 258:
																																											case 604:
																																												goto IL_1f40;
																																											case 435:
																																												goto IL_1f54;
																																											case 418:
																																												goto IL_1f93;
																																											case 122:
																																												goto IL_1fa6;
																																											case 204:
																																												goto IL_1fb4;
																																											case 296:
																																											case 615:
																																												goto IL_1fbf;
																																											case 333:
																																												goto IL_1fd9;
																																											case 128:
																																												goto IL_1fe7;
																																											case 515:
																																												goto IL_1ff5;
																																											case 671:
																																												goto IL_2008;
																																											case 454:
																																												goto IL_2013;
																																											case 71:
																																											case 434:
																																												goto IL_2021;
																																											case 429:
																																												goto IL_202f;
																																											case 587:
																																												goto IL_2053;
																																											case 180:
																																												goto IL_2061;
																																											case 141:
																																												goto IL_2074;
																																											case 42:
																																												goto IL_208b;
																																											case 416:
																																											case 672:
																																												goto IL_2099;
																																											case 567:
																																												goto IL_20d7;
																																											case 143:
																																												goto IL_20eb;
																																											case 300:
																																												goto IL_20fe;
																																											case 544:
																																												goto IL_210c;
																																											case 737:
																																											case 774:
																																												goto IL_211a;
																																											case 735:
																																												goto IL_2188;
																																											case 519:
																																												goto IL_219b;
																																											case 164:
																																												goto IL_21a9;
																																											case 437:
																																											case 740:
																																												goto IL_21b7;
																																											case 649:
																																												goto IL_21d5;
																																											case 193:
																																												goto IL_21e3;
																																											case 292:
																																												goto IL_21f1;
																																											case 473:
																																												goto IL_2204;
																																											case 584:
																																												goto IL_2212;
																																											case 344:
																																											case 677:
																																												goto IL_2220;
																																											case 592:
																																												goto IL_2234;
																																											case 378:
																																												goto IL_2288;
																																											case 319:
																																												goto IL_2296;
																																											case 269:
																																												goto IL_22a9;
																																											case 306:
																																												goto IL_22b7;
																																											case 288:
																																												goto IL_22c5;
																																											case 278:
																																												goto IL_22d3;
																																											case 554:
																																												goto IL_22e1;
																																											case 246:
																																											case 704:
																																												goto IL_22ec;
																																											case 205:
																																												goto IL_22fa;
																																											case 493:
																																												goto IL_231e;
																																											case 84:
																																												goto IL_232c;
																																											case 116:
																																												goto IL_233f;
																																											case 715:
																																												goto IL_234a;
																																											case 144:
																																											case 482:
																																												goto IL_2358;
																																											case 21:
																																												goto IL_2371;
																																											case 89:
																																												goto IL_2384;
																																											case 521:
																																												goto IL_2392;
																																											case 290:
																																											case 369:
																																												goto IL_23a0;
																																											case 455:
																																												goto IL_23b4;
																																											case 590:
																																												goto IL_23f3;
																																											case 758:
																																												goto IL_2406;
																																											case 419:
																																												goto IL_2411;
																																											case 252:
																																											case 577:
																																												goto IL_241f;
																																											case 255:
																																												goto IL_2433;
																																											case 481:
																																												goto IL_2472;
																																											case 685:
																																												goto IL_2485;
																																											case 245:
																																												goto IL_2493;
																																											case 222:
																																											case 523:
																																												goto IL_24a1;
																																											case 428:
																																												goto IL_24ab;
																																											case 778:
																																												goto IL_24b9;
																																											case 602:
																																											case 743:
																																												goto IL_24cc;
																																											case 621:
																																												goto IL_2519;
																																											case 58:
																																												goto IL_2527;
																																											case 682:
																																												goto IL_253a;
																																											case 191:
																																												goto IL_2548;
																																											case 372:
																																												goto IL_2556;
																																											case 389:
																																												goto IL_2561;
																																											case 61:
																																											case 442:
																																												goto IL_256f;
																																											case 729:
																																												goto IL_2583;
																																											case 43:
																																												goto IL_25c2;
																																											case 564:
																																												goto IL_25d5;
																																											case 608:
																																												goto IL_25e3;
																																											case 516:
																																											case 709:
																																												goto IL_25f1;
																																											case 103:
																																												goto IL_260b;
																																											case 177:
																																											case 558:
																																												goto IL_2630;
																																											case 368:
																																												goto IL_263e;
																																											case 40:
																																												goto IL_2651;
																																											case 142:
																																												goto IL_2668;
																																											case 57:
																																												goto IL_2684;
																																											case 644:
																																												goto IL_268f;
																																											case 208:
																																											case 410:
																																												goto IL_269d;
																																											case 736:
																																												goto IL_26c0;
																																											case 301:
																																												goto IL_26ce;
																																											case 700:
																																												goto IL_26dc;
																																											case 24:
																																												goto IL_26ef;
																																											case 722:
																																												goto IL_26fd;
																																											case 196:
																																											case 273:
																																												goto IL_270b;
																																											case 580:
																																												goto IL_2749;
																																											case 468:
																																												goto IL_275d;
																																											case 217:
																																												goto IL_2779;
																																											case 263:
																																											case 427:
																																												goto IL_2784;
																																											case 414:
																																												goto IL_27ab;
																																											case 73:
																																												goto IL_27b9;
																																											case 38:
																																												goto IL_27c7;
																																											case 538:
																																												goto IL_27e3;
																																											case 236:
																																												goto IL_27f1;
																																											case 463:
																																											case 484:
																																												goto IL_27fc;
																																											case 605:
																																												goto IL_280a;
																																											case 648:
																																												goto IL_282d;
																																											case 593:
																																												goto IL_283b;
																																											case 39:
																																												goto IL_284e;
																																											case 215:
																																												goto IL_285c;
																																											case 231:
																																											case 305:
																																												goto IL_2867;
																																											case 601:
																																												goto IL_28c7;
																																											case 571:
																																												goto IL_28da;
																																											case 66:
																																												goto IL_28e5;
																																											case 110:
																																												goto IL_28f3;
																																											case 64:
																																											case 574:
																																												goto IL_2901;
																																											case 670:
																																												goto IL_2925;
																																											case 51:
																																												goto IL_2933;
																																											case 441:
																																												goto IL_2941;
																																											case 271:
																																												goto IL_2954;
																																											case 7:
																																											case 651:
																																												goto IL_2962;
																																											case 170:
																																												goto IL_29b7;
																																											case 721:
																																												goto IL_29ca;
																																											case 168:
																																												goto IL_29d5;
																																											case 551:
																																											case 665:
																																												goto IL_29e3;
																																											case 347:
																																												goto IL_2a0f;
																																											case 172:
																																												goto IL_2a1d;
																																											case 165:
																																												goto IL_2a2b;
																																											case 561:
																																												goto IL_2a3e;
																																											case 343:
																																												goto IL_2a4c;
																																											case 96:
																																											case 495:
																																												goto IL_2a5a;
																																											case 751:
																																												goto IL_2ab9;
																																											case 404:
																																												goto IL_2acc;
																																											case 70:
																																												goto IL_2ada;
																																											case 44:
																																												goto IL_2ae8;
																																											case 298:
																																												goto IL_2af3;
																																											case 194:
																																												goto IL_2b01;
																																											case 675:
																																											case 683:
																																												goto IL_2b0f;
																																											case 210:
																																												goto IL_2b3a;
																																											case 620:
																																												goto IL_2b53;
																																											case 83:
																																											case 668:
																																												goto IL_2b61;
																																											case 65:
																																												goto IL_2bc0;
																																											case 438:
																																											case 661:
																																												goto IL_2bd3;
																																											case 409:
																																												goto IL_2c33;
																																											case 759:
																																												goto IL_2c46;
																																											case 136:
																																												goto IL_2c51;
																																											case 456:
																																											case 639:
																																												goto IL_2c5f;
																																											case 731:
																																												goto IL_2c82;
																																											case 488:
																																												goto IL_2c90;
																																											case 337:
																																												goto IL_2c9e;
																																											case 174:
																																												goto IL_2cb1;
																																											case 520:
																																												goto IL_2cbf;
																																											case 609:
																																											case 657:
																																												goto IL_2ccd;
																																											case 386:
																																												goto IL_2d0a;
																																											case 187:
																																												goto IL_2d21;
																																											case 27:
																																												goto IL_2d34;
																																											case 526:
																																												goto IL_2d42;
																																											case 447:
																																												goto IL_2d50;
																																											case 47:
																																												goto IL_2d67;
																																											case 113:
																																											case 739:
																																												goto IL_2d72;
																																											case 206:
																																												goto IL_2d86;
																																											case 274:
																																												goto IL_2dc5;
																																											case 610:
																																												goto IL_2dd8;
																																											case 127:
																																												goto IL_2de6;
																																											case 226:
																																											case 352:
																																												goto IL_2df1;
																																											case 531:
																																												goto IL_2e38;
																																											case 104:
																																												goto IL_2e4c;
																																											case 162:
																																												goto IL_2e5f;
																																											case 662:
																																												goto IL_2e6a;
																																											case 81:
																																											case 237:
																																												goto IL_2e78;
																																											case 534:
																																												goto IL_2eb6;
																																											case 764:
																																												goto IL_2eca;
																																											case 449:
																																												goto IL_2edd;
																																											case 703:
																																												goto IL_2eeb;
																																											case 15:
																																											case 366:
																																												goto IL_2ef9;
																																											case 60:
																																												goto IL_2f0d;
																																											case 332:
																																												goto IL_2f61;
																																											case 158:
																																												goto IL_2f6f;
																																											case 537:
																																												goto IL_2f82;
																																											case 118:
																																												goto IL_2f90;
																																											case 184:
																																											case 507:
																																												goto IL_2f9e;
																																											case 295:
																																												goto IL_2fb2;
																																											case 407:
																																												goto IL_3006;
																																											case 752:
																																												goto IL_3014;
																																											case 655:
																																												goto IL_3027;
																																											case 77:
																																												goto IL_3035;
																																											case 443:
																																											case 635:
																																												goto IL_3043;
																																											case 552:
																																												goto IL_30dd;
																																											case 728:
																																												goto IL_30eb;
																																											case 545:
																																												goto IL_30fe;
																																											case 266:
																																												goto IL_310c;
																																											case 20:
																																											case 511:
																																												goto IL_3117;
																																											case 350:
																																												goto IL_3125;
																																											case 748:
																																												goto IL_3149;
																																											case 747:
																																												goto IL_3157;
																																											case 452:
																																												goto IL_316a;
																																											case 652:
																																												goto IL_3178;
																																											case 2:
																																												goto IL_3186;
																																											case 34:
																																											case 328:
																																												goto IL_319d;
																																											case 560:
																																												goto IL_31ab;
																																											case 536:
																																												goto IL_31cf;
																																											case 726:
																																												goto IL_31e6;
																																											case 762:
																																												goto IL_31f9;
																																											case 146:
																																											case 342:
																																												goto IL_3207;
																																											case 238:
																																												goto IL_3245;
																																											case 588:
																																												goto IL_3259;
																																											case 467:
																																												goto IL_326c;
																																											case 185:
																																												goto IL_327a;
																																											case 775:
																																												goto IL_3288;
																																											case 52:
																																											case 573:
																																												goto IL_3296;
																																											case 401:
																																												goto IL_32aa;
																																											case 568:
																																												goto IL_32e9;
																																											case 514:
																																												goto IL_32fc;
																																											case 13:
																																											case 756:
																																												goto IL_330a;
																																											case 48:
																																												goto IL_3368;
																																											case 31:
																																											case 742:
																																												goto IL_337b;
																																											case 151:
																																												goto IL_3389;
																																											case 478:
																																												goto IL_33a7;
																																											case 453:
																																												goto IL_33b5;
																																											case 616:
																																												goto IL_33c8;
																																											case 581:
																																												goto IL_33d6;
																																											case 527:
																																												goto IL_33e4;
																																											case 405:
																																												goto IL_33f2;
																																											case 181:
																																											case 578:
																																												goto IL_33fd;
																																											case 666:
																																												goto IL_3411;
																																											case 150:
																																												goto IL_344e;
																																											case 312:
																																												goto IL_3461;
																																											case 465:
																																												goto IL_346c;
																																											case 741:
																																												goto IL_347a;
																																											case 130:
																																											case 749:
																																												goto IL_3488;
																																											case 67:
																																												goto IL_349c;
																																											case 201:
																																												goto IL_34d4;
																																											case 596:
																																												goto IL_34f0;
																																											case 123:
																																											case 503:
																																												goto IL_34fe;
																																											case 211:
																																												goto IL_3536;
																																											case 159:
																																												goto IL_354a;
																																											case 102:
																																												goto IL_355d;
																																											case 4:
																																												goto IL_3568;
																																											case 32:
																																											case 664:
																																												goto IL_3576;
																																											case 244:
																																												goto IL_358f;
																																											case 361:
																																												goto IL_35a2;
																																											case 532:
																																												goto IL_35b0;
																																											case 68:
																																											case 402:
																																												goto IL_35be;
																																											case 216:
																																												goto IL_35e8;
																																											case 280:
																																											case 563:
																																												goto IL_3601;
																																											case 370:
																																												goto IL_362c;
																																											case 469:
																																												goto IL_3645;
																																											case 75:
																																												goto IL_3653;
																																											case 371:
																																											case 424:
																																												goto IL_365e;
																																											case 589:
																																												goto IL_3677;
																																											case 129:
																																												goto IL_368a;
																																											case 200:
																																												goto IL_3695;
																																											case 82:
																																											case 400:
																																												goto IL_36a3;
																																											case 641:
																																												goto IL_36ce;
																																											case 691:
																																												goto IL_36f0;
																																											case 74:
																																												goto IL_36fe;
																																											case 326:
																																											case 738:
																																												goto IL_3715;
																																											case 658:
																																												goto IL_3723;
																																											case 524:
																																												goto IL_3741;
																																											case 713:
																																												goto IL_374f;
																																											case 229:
																																												goto IL_3762;
																																											case 171:
																																												goto IL_3770;
																																											case 99:
																																											case 485:
																																												goto IL_377e;
																																											case 388:
																																												goto IL_3792;
																																											case 415:
																																												goto IL_37e4;
																																											case 25:
																																												goto IL_37f2;
																																											case 147:
																																												goto IL_3802;
																																											case 663:
																																												goto IL_380d;
																																											case 3:
																																											case 23:
																																											case 26:
																																											case 28:
																																											case 36:
																																											case 45:
																																											case 49:
																																											case 94:
																																											case 100:
																																											case 108:
																																											case 112:
																																											case 126:
																																											case 138:
																																											case 149:
																																											case 167:
																																											case 176:
																																											case 183:
																																											case 186:
																																											case 188:
																																											case 190:
																																											case 192:
																																											case 199:
																																											case 214:
																																											case 223:
																																											case 224:
																																											case 234:
																																											case 243:
																																											case 247:
																																											case 248:
																																											case 249:
																																											case 257:
																																											case 261:
																																											case 262:
																																											case 264:
																																											case 270:
																																											case 272:
																																											case 282:
																																											case 283:
																																											case 299:
																																											case 304:
																																											case 308:
																																											case 311:
																																											case 313:
																																											case 314:
																																											case 315:
																																											case 317:
																																											case 329:
																																											case 339:
																																											case 367:
																																											case 377:
																																											case 383:
																																											case 385:
																																											case 392:
																																											case 394:
																																											case 398:
																																											case 408:
																																											case 411:
																																											case 413:
																																											case 417:
																																											case 421:
																																											case 426:
																																											case 432:
																																											case 459:
																																											case 471:
																																											case 475:
																																											case 476:
																																											case 498:
																																											case 499:
																																											case 512:
																																											case 513:
																																											case 518:
																																											case 539:
																																											case 542:
																																											case 547:
																																											case 550:
																																											case 565:
																																											case 569:
																																											case 582:
																																											case 586:
																																											case 591:
																																											case 600:
																																											case 614:
																																											case 622:
																																											case 624:
																																											case 631:
																																											case 632:
																																											case 637:
																																											case 653:
																																											case 660:
																																											case 676:
																																											case 692:
																																											case 695:
																																											case 707:
																																											case 717:
																																											case 720:
																																											case 725:
																																											case 745:
																																											case 776:
																																												goto end_IL_0cee;
																																											case 8:
																																											case 12:
																																											case 19:
																																											case 29:
																																											case 62:
																																											case 63:
																																											case 95:
																																											case 105:
																																											case 132:
																																											case 135:
																																											case 153:
																																											case 157:
																																											case 160:
																																											case 189:
																																											case 202:
																																											case 209:
																																											case 212:
																																											case 213:
																																											case 220:
																																											case 225:
																																											case 228:
																																											case 235:
																																											case 250:
																																											case 251:
																																											case 253:
																																											case 259:
																																											case 268:
																																											case 276:
																																											case 281:
																																											case 285:
																																											case 294:
																																											case 302:
																																											case 309:
																																											case 318:
																																											case 321:
																																											case 323:
																																											case 327:
																																											case 346:
																																											case 353:
																																											case 358:
																																											case 359:
																																											case 362:
																																											case 363:
																																											case 373:
																																											case 406:
																																											case 425:
																																											case 431:
																																											case 433:
																																											case 436:
																																											case 444:
																																											case 448:
																																											case 458:
																																											case 460:
																																											case 466:
																																											case 487:
																																											case 491:
																																											case 494:
																																											case 497:
																																											case 505:
																																											case 508:
																																											case 510:
																																											case 517:
																																											case 525:
																																											case 540:
																																											case 543:
																																											case 562:
																																											case 579:
																																											case 595:
																																											case 599:
																																											case 603:
																																											case 607:
																																											case 634:
																																											case 636:
																																											case 640:
																																											case 646:
																																											case 654:
																																											case 656:
																																											case 679:
																																											case 680:
																																											case 690:
																																											case 696:
																																											case 698:
																																											case 699:
																																											case 710:
																																											case 714:
																																											case 719:
																																											case 732:
																																											case 734:
																																											case 744:
																																											case 750:
																																											case 753:
																																											case 755:
																																											case 757:
																																											case 760:
																																											case 763:
																																											case 767:
																																											case 773:
																																												goto end_IL_0c61;
																																											case 387:
																																												goto end_IL_3834;
																																											case 267:
																																												goto end_IL_3847;
																																											case 723:
																																												goto end_IL_3851;
																																											case 613:
																																												goto end_IL_3865;
																																											case 766:
																																												goto end_IL_3875;
																																											case 770:
																																												goto end_IL_388e;
																																											case 611:
																																												goto end_IL_389e;
																																											case 597:
																																												goto end_IL_38b7;
																																											case 420:
																																												goto end_IL_38c7;
																																											case 203:
																																												goto end_IL_38d7;
																																											case 90:
																																												goto end_IL_38e7;
																																											case 91:
																																												goto end_IL_38f7;
																																											case 119:
																																											case 772:
																																												return;
																																											}
																																											continue;
																																											end_IL_0c61:
																																											break;
																																										}
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							goto end_IL_0da1;
																																							continue;
																																							end_IL_0cee:
																																							break;
																																							IL_0cee:;
																																						}
																																						break;
																																						IL_0d01:;
																																					}
																																					break;
																																				}
																																				goto IL_0e7f;
																																				IL_0f50:
																																				ptr2 += 8;
																																				goto end_IL_0da1;
																																				IL_0e7f:
																																				if (22 > b)
																																				{
																																					break;
																																				}
																																				goto IL_0e8d;
																																				IL_0e8d:
																																				array[num6 - 1] = 3;
																																				goto IL_0f11;
																																				IL_0f11:
																																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																																				goto IL_0f50;
																																			}
																																			break;
																																		}
																																		goto IL_0dd5;
																																		IL_0e20:
																																		num6++;
																																		goto IL_0e6c;
																																		IL_0dd5:
																																		if (21 > b)
																																		{
																																			goto IL_0de0;
																																		}
																																		num = 197;
																																		goto IL_0df9;
																																		IL_0de0:
																																		if (19 < b)
																																		{
																																			goto IL_0e30;
																																		}
																																		goto IL_0ea3;
																																		IL_0ea3:
																																		if (19 > b)
																																		{
																																			break;
																																		}
																																		goto IL_0eb1;
																																		IL_0eb1:
																																		array2[num6 - 2] = ((string[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																																		goto IL_0eea;
																																		IL_0eea:
																																		array[num6 - 2] = 5;
																																		goto IL_0efe;
																																		IL_0efe:
																																		num6--;
																																		goto end_IL_0da1;
																																		IL_0e30:
																																		if (20 < b)
																																		{
																																			break;
																																		}
																																		goto IL_0e59;
																																		IL_0e59:
																																		if (20 > b)
																																		{
																																			break;
																																		}
																																		goto IL_127b;
																																		IL_127b:
																																		global::_003CModule_003E.string_42 = (string)array2[num6 - 1];
																																		goto IL_1294;
																																		IL_1294:
																																		num6--;
																																		goto end_IL_0da1;
																																		IL_0e6c:
																																		ptr2 += 16;
																																		goto end_IL_0da1;
																																		IL_0df9:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																																		goto IL_0e12;
																																		IL_0e12:
																																		array[num6] = 3;
																																		goto IL_0e20;
																																	}
																																	break;
																																}
																																goto IL_1204;
																																IL_1706:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																num = 250;
																																goto end_IL_0da1;
																																IL_1204:
																																if (18 <= b)
																																{
																																	goto IL_120f;
																																}
																																goto IL_124f;
																																IL_120f:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																																goto IL_1233;
																																IL_1233:
																																array[num6] = 0;
																																num = 705;
																																goto IL_143d;
																																IL_143d:
																																num6++;
																																num = 451;
																																goto IL_1454;
																																IL_1454:
																																ptr2 += 8;
																																goto end_IL_0da1;
																																IL_124f:
																																if (15 < b)
																																{
																																	goto IL_125d;
																																}
																																goto IL_15e4;
																																IL_125d:
																																if (16 >= b)
																																{
																																	goto IL_1268;
																																}
																																goto IL_12a7;
																																IL_1268:
																																if (16 > b)
																																{
																																	break;
																																}
																																goto IL_1769;
																																IL_1769:
																																byte* num7 = ptr2;
																																num5 = 1;
																																ptr2 = num7 + -200;
																																goto end_IL_0da1;
																																IL_12a7:
																																if (17 < b)
																																{
																																	break;
																																}
																																goto IL_12b5;
																																IL_12b5:
																																if (17 > b)
																																{
																																	break;
																																}
																																goto IL_12c3;
																																IL_12c3:
																																array2[num6] = ((delegate*<string[]>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																																num = 572;
																																goto IL_12ea;
																																IL_12ea:
																																array[num6] = 5;
																																goto IL_12f8;
																																IL_12f8:
																																num6++;
																																goto IL_1306;
																																IL_1306:
																																ptr2 += 8;
																																num = 358;
																																goto end_IL_0da1;
																																IL_15e4:
																																if (15 <= b)
																																{
																																	goto IL_15ef;
																																}
																																goto IL_165d;
																																IL_15ef:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																goto IL_1641;
																																IL_1641:
																																num6--;
																																num = 508;
																																goto end_IL_0da1;
																																IL_165d:
																																if (13 < b)
																																{
																																	goto IL_166b;
																																}
																																goto IL_16ef;
																																IL_166b:
																																if (14 < b)
																																{
																																	break;
																																}
																																goto IL_1679;
																																IL_1679:
																																if (14 > b)
																																{
																																	break;
																																}
																																goto IL_1687;
																																IL_1687:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																																goto IL_16c8;
																																IL_16c8:
																																array[num6 - 2] = 0;
																																goto IL_16dc;
																																IL_16dc:
																																num6--;
																																goto end_IL_0da1;
																																IL_16ef:
																																if (13 > b)
																																{
																																	break;
																																}
																																num = 230;
																																goto IL_1706;
																															}
																															break;
																														}
																														goto IL_0fb5;
																														IL_1727:
																														if (11 < b)
																														{
																															break;
																														}
																														goto IL_1735;
																														IL_0fb5:
																														if (12 > b)
																														{
																															goto IL_0fc3;
																														}
																														goto IL_1322;
																														IL_0fc3:
																														if (6 >= b)
																														{
																															num = 233;
																															goto IL_0fda;
																														}
																														goto IL_10c9;
																														IL_1735:
																														if (11 > b)
																														{
																															break;
																														}
																														goto end_IL_0da1;
																														IL_0fda:
																														if (6 <= b)
																														{
																															goto IL_0fe5;
																														}
																														goto IL_103e;
																														IL_0fe5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1025;
																														IL_1025:
																														array[num6 - 2] = 0;
																														goto IL_138b;
																														IL_138b:
																														num6--;
																														goto end_IL_0da1;
																														IL_103e:
																														if (3 >= b)
																														{
																															goto IL_104c;
																														}
																														goto IL_139e;
																														IL_104c:
																														if (3 > b)
																														{
																															goto IL_105a;
																														}
																														goto IL_1467;
																														IL_105a:
																														if (1 < b)
																														{
																															goto IL_1065;
																														}
																														num = 169;
																														goto IL_108f;
																														IL_1065:
																														if (2 < b)
																														{
																															break;
																														}
																														goto IL_1073;
																														IL_1073:
																														if (2 > b)
																														{
																															break;
																														}
																														goto IL_117c;
																														IL_117c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_11bc;
																														IL_11bc:
																														array[num6 - 2] = 0;
																														goto IL_17ec;
																														IL_17ec:
																														num6--;
																														goto end_IL_0da1;
																														IL_1322:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																														goto IL_133b;
																														IL_108f:
																														if (1 > b)
																														{
																															break;
																														}
																														goto IL_109d;
																														IL_109d:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																														goto IL_10b6;
																														IL_10b6:
																														array[num6] = 0;
																														goto IL_1748;
																														IL_1748:
																														num6++;
																														goto IL_1756;
																														IL_1756:
																														ptr2 += 8;
																														goto end_IL_0da1;
																														IL_1467:
																														ref int reference = ref array4[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1490;
																														IL_1490:
																														ptr2 += 8;
																														goto IL_149e;
																														IL_149e:
																														num6--;
																														num = 680;
																														goto end_IL_0da1;
																														IL_139e:
																														if (4 >= b)
																														{
																															goto IL_13a9;
																														}
																														goto IL_141c;
																														IL_13a9:
																														if (4 > b)
																														{
																															break;
																														}
																														goto IL_13b7;
																														IL_13b7:
																														array[num6] = 0;
																														goto IL_13c5;
																														IL_13c5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																														goto IL_13e8;
																														IL_13e8:
																														array2[num6] = null;
																														goto IL_13f2;
																														IL_13f2:
																														num6++;
																														num = 322;
																														goto IL_1409;
																														IL_1409:
																														ptr2 += 8;
																														goto end_IL_0da1;
																														IL_141c:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_142a;
																														IL_142a:
																														if (5 > b)
																														{
																															break;
																														}
																														goto IL_1785;
																														IL_1785:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_17c5;
																														IL_17c5:
																														array[num6 - 2] = 0;
																														goto IL_17d9;
																														IL_17d9:
																														num6--;
																														goto end_IL_0da1;
																														IL_10c9:
																														if (9 < b)
																														{
																															goto IL_10e2;
																														}
																														num = 712;
																														goto IL_14ba;
																														IL_133b:
																														array[num6] = 1;
																														goto IL_1349;
																														IL_14ba:
																														if (9 <= b)
																														{
																															goto IL_14c5;
																														}
																														goto IL_152c;
																														IL_14c5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1505;
																														IL_1505:
																														array[num6 - 2] = 0;
																														goto IL_1519;
																														IL_1519:
																														num6--;
																														goto end_IL_0da1;
																														IL_152c:
																														if (7 >= b)
																														{
																															goto IL_1537;
																														}
																														goto IL_15ac;
																														IL_1537:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_1545;
																														IL_1545:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_1585;
																														IL_1585:
																														array[num6 - 2] = 0;
																														goto IL_1599;
																														IL_1599:
																														num6--;
																														goto end_IL_0da1;
																														IL_15ac:
																														if (8 < b)
																														{
																															break;
																														}
																														num = 50;
																														goto IL_15c3;
																														IL_1349:
																														num6++;
																														goto IL_1357;
																														IL_15c3:
																														if (8 > b)
																														{
																															break;
																														}
																														goto IL_15d1;
																														IL_15d1:
																														num6--;
																														goto end_IL_0da1;
																														IL_10e2:
																														if (10 >= b)
																														{
																															num = 14;
																															goto IL_10f9;
																														}
																														goto IL_1727;
																														IL_1357:
																														ptr2 += 16;
																														goto end_IL_0da1;
																														IL_10f9:
																														if (10 > b)
																														{
																															break;
																														}
																														goto IL_1107;
																														IL_1107:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_1169;
																														IL_1169:
																														num6 -= 2;
																														goto end_IL_0da1;
																													}
																													break;
																												}
																												goto IL_0e40;
																												IL_0fa2:
																												ptr2 += 8;
																												goto end_IL_0da1;
																												IL_0e40:
																												array[num6 - 1] = 0;
																												goto IL_0f63;
																												IL_0f63:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																												goto IL_0fa2;
																											}
																											break;
																										}
																										goto IL_17ff;
																										IL_21a9:
																										if (47 > b)
																										{
																											break;
																										}
																										goto IL_21b7;
																										IL_17ff:
																										if (36 >= b)
																										{
																											goto IL_180d;
																										}
																										goto IL_1d2f;
																										IL_180d:
																										if (36 <= b)
																										{
																											goto IL_1818;
																										}
																										goto IL_1845;
																										IL_1818:
																										global::_003CModule_003E.int_196 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_1832;
																										IL_1832:
																										num6--;
																										goto end_IL_0da1;
																										IL_1845:
																										if (30 >= b)
																										{
																											goto IL_1853;
																										}
																										goto IL_1abf;
																										IL_1853:
																										if (30 <= b)
																										{
																											goto IL_185e;
																										}
																										goto IL_18c5;
																										IL_185e:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_189e;
																										IL_189e:
																										array[num6 - 2] = 3;
																										goto IL_18b2;
																										IL_18b2:
																										num6--;
																										goto end_IL_0da1;
																										IL_18c5:
																										if (27 >= b)
																										{
																											goto IL_18d3;
																										}
																										goto IL_19f7;
																										IL_18d3:
																										if (27 <= b)
																										{
																											goto IL_18de;
																										}
																										goto IL_1928;
																										IL_18de:
																										((Class117)array2[num6 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_190c;
																										IL_190c:
																										num6 -= 2;
																										num = 460;
																										goto end_IL_0da1;
																										IL_1928:
																										if (25 >= b)
																										{
																											goto IL_1933;
																										}
																										goto IL_1988;
																										IL_1933:
																										if (25 > b)
																										{
																											break;
																										}
																										goto IL_1941;
																										IL_1941:
																										array2[num6] = array6[*(int*)(ptr2 + num3)];
																										goto IL_1959;
																										IL_1959:
																										array[num6] = 5;
																										goto IL_1967;
																										IL_1967:
																										num6++;
																										goto IL_1975;
																										IL_1975:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1988:
																										if (26 < b)
																										{
																											break;
																										}
																										goto IL_1996;
																										IL_1996:
																										if (26 > b)
																										{
																											break;
																										}
																										goto IL_19a4;
																										IL_19a4:
																										array[num6] = 3;
																										goto IL_19b2;
																										IL_19b2:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_19d6;
																										IL_19d6:
																										num6++;
																										goto IL_19e4;
																										IL_19e4:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_19f7:
																										if (28 < b)
																										{
																											goto IL_1a02;
																										}
																										goto IL_1a4b;
																										IL_1a02:
																										if (29 < b)
																										{
																											break;
																										}
																										goto IL_1a10;
																										IL_1a10:
																										if (29 > b)
																										{
																											break;
																										}
																										goto IL_1a1e;
																										IL_1a1e:
																										global::_003CModule_003E.int_195 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_1a38;
																										IL_1a38:
																										num6--;
																										goto end_IL_0da1;
																										IL_1a4b:
																										if (28 > b)
																										{
																											break;
																										}
																										goto IL_1a59;
																										IL_1a59:
																										array[num6 - 1] = 3;
																										goto IL_1a6d;
																										IL_1a6d:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_1aac;
																										IL_1aac:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1abf:
																										if (33 >= b)
																										{
																											goto IL_1acd;
																										}
																										goto IL_1c14;
																										IL_1acd:
																										if (33 <= b)
																										{
																											goto IL_1ad8;
																										}
																										goto IL_1b25;
																										IL_1ad8:
																										array2[num6] = ((delegate*<Dictionary<string, int>>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_1af6;
																										IL_1af6:
																										array[num6] = 5;
																										goto IL_1b04;
																										IL_1b04:
																										num6++;
																										goto IL_1b12;
																										IL_1b12:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1b25:
																										if (31 >= b)
																										{
																											goto IL_1b30;
																										}
																										goto IL_1b91;
																										IL_1b30:
																										if (31 > b)
																										{
																											break;
																										}
																										goto IL_1b3e;
																										IL_1b3e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_1b62;
																										IL_1b62:
																										array[num6] = 0;
																										goto IL_1b70;
																										IL_1b70:
																										num6++;
																										goto IL_1b7e;
																										IL_1b7e:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1b91:
																										if (32 < b)
																										{
																											break;
																										}
																										goto IL_1b9f;
																										IL_1b9f:
																										if (32 > b)
																										{
																											break;
																										}
																										goto IL_1bad;
																										IL_1bad:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_1bed;
																										IL_1bed:
																										array[num6 - 2] = 3;
																										goto IL_1c01;
																										IL_1c01:
																										num6--;
																										goto end_IL_0da1;
																										IL_1c14:
																										if (34 >= b)
																										{
																											goto IL_1c1f;
																										}
																										goto IL_1c83;
																										IL_1c1f:
																										if (34 > b)
																										{
																											break;
																										}
																										num = 399;
																										goto IL_1c36;
																										IL_21b7:
																										array2[num6] = ((delegate*<List<GameEntityCreateData>>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_21d5;
																										IL_1c36:
																										array2[num6] = ((delegate*<string>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_1c54;
																										IL_1c54:
																										array[num6] = 5;
																										goto IL_1c62;
																										IL_1c62:
																										num6++;
																										goto IL_1c70;
																										IL_1c70:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1c83:
																										if (35 < b)
																										{
																											break;
																										}
																										num = 643;
																										goto IL_1c9a;
																										IL_21d5:
																										array[num6] = 5;
																										goto IL_21e3;
																										IL_1c9a:
																										if (35 > b)
																										{
																											break;
																										}
																										goto IL_1ca8;
																										IL_1ca8:
																										array[num6 - 2] = 0;
																										goto IL_1cbc;
																										IL_1cbc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num6 - 2], (string)array2[num6 - 1]);
																										goto IL_1d0e;
																										IL_1d0e:
																										num6--;
																										goto IL_1d1c;
																										IL_1d1c:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1d2f:
																										if (42 >= b)
																										{
																											goto IL_1d3d;
																										}
																										goto IL_1fa6;
																										IL_1d3d:
																										if (42 > b)
																										{
																											goto IL_1d4b;
																										}
																										goto IL_1f40;
																										IL_1d4b:
																										if (39 >= b)
																										{
																											goto IL_1d59;
																										}
																										goto IL_1e7d;
																										IL_1d59:
																										if (39 > b)
																										{
																											goto IL_1d67;
																										}
																										num = 628;
																										goto IL_1e3c;
																										IL_1d67:
																										if (37 >= b)
																										{
																											goto IL_1d72;
																										}
																										goto IL_1de6;
																										IL_1d72:
																										if (37 > b)
																										{
																											break;
																										}
																										goto IL_1d80;
																										IL_1d80:
																										array[num6 - 1] = 3;
																										goto IL_1d94;
																										IL_1d94:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_1dd3;
																										IL_1dd3:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1de6:
																										if (38 < b)
																										{
																											break;
																										}
																										goto IL_1df4;
																										IL_1df4:
																										if (38 > b)
																										{
																											break;
																										}
																										goto IL_1e02;
																										IL_1e02:
																										((delegate*<void>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										num = 553;
																										goto IL_1e20;
																										IL_1e20:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_21e3:
																										num6++;
																										goto IL_21f1;
																										IL_1e3c:
																										((Class117)array2[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_1e6a;
																										IL_1e6a:
																										num6 -= 2;
																										goto end_IL_0da1;
																										IL_1e7d:
																										if (40 < b)
																										{
																											goto IL_1e88;
																										}
																										goto IL_1ecc;
																										IL_1e88:
																										if (41 < b)
																										{
																											break;
																										}
																										goto IL_1e96;
																										IL_1e96:
																										if (41 > b)
																										{
																											break;
																										}
																										goto IL_1ea4;
																										IL_1ea4:
																										((delegate*<void>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_1eb9;
																										IL_1eb9:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1ecc:
																										if (40 > b)
																										{
																											break;
																										}
																										goto IL_1eda;
																										IL_1eda:
																										array[num6 - 1] = 3;
																										goto IL_1eee;
																										IL_1eee:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_1f2d;
																										IL_1f2d:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1f40:
																										array[num6 - 1] = 3;
																										goto IL_1f54;
																										IL_1f54:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_1f93;
																										IL_1f93:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_1fa6:
																										if (45 >= b)
																										{
																											goto IL_1fb4;
																										}
																										goto IL_20fe;
																										IL_1fb4:
																										if (45 <= b)
																										{
																											goto IL_1fbf;
																										}
																										goto IL_2008;
																										IL_1fbf:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																										goto IL_1fd9;
																										IL_1fd9:
																										array[num6] = 3;
																										goto IL_1fe7;
																										IL_1fe7:
																										num6++;
																										goto IL_1ff5;
																										IL_1ff5:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_2008:
																										if (43 >= b)
																										{
																											goto IL_2013;
																										}
																										goto IL_2074;
																										IL_2013:
																										if (43 > b)
																										{
																											break;
																										}
																										goto IL_2021;
																										IL_2021:
																										array[num6] = 3;
																										goto IL_202f;
																										IL_202f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																										goto IL_2053;
																										IL_2053:
																										num6++;
																										goto IL_2061;
																										IL_2061:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_2074:
																										if (44 < b)
																										{
																											break;
																										}
																										num = 42;
																										goto IL_208b;
																										IL_21f1:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_208b:
																										if (44 > b)
																										{
																											break;
																										}
																										goto IL_2099;
																										IL_2099:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Class117, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Class117)array2[num6 - 1]);
																										goto IL_20d7;
																										IL_20d7:
																										array[num6 - 1] = 3;
																										goto IL_20eb;
																										IL_20eb:
																										ptr2 += 8;
																										goto end_IL_0da1;
																										IL_20fe:
																										if (46 >= b)
																										{
																											goto IL_210c;
																										}
																										goto IL_219b;
																										IL_210c:
																										if (46 > b)
																										{
																											break;
																										}
																										goto IL_211a;
																										IL_211a:
																										ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_2188;
																										IL_2188:
																										num6 -= 2;
																										goto end_IL_0da1;
																										IL_219b:
																										if (47 < b)
																										{
																											break;
																										}
																										goto IL_21a9;
																									}
																									break;
																								}
																								goto IL_11d5;
																								IL_1378:
																								num6++;
																								goto end_IL_0da1;
																								IL_11d5:
																								array[num6] = 15;
																								goto IL_11e3;
																								IL_11e3:
																								array3[num6] = *(int*)(ptr2 + num3);
																								num = 687;
																								goto IL_136a;
																								IL_136a:
																								ptr2 += 8;
																								goto IL_1378;
																							}
																							break;
																						}
																						goto IL_2204;
																						IL_3770:
																						if (94 > b)
																						{
																							break;
																						}
																						goto IL_377e;
																						IL_2204:
																						if (72 >= b)
																						{
																							goto IL_2212;
																						}
																						goto IL_2d34;
																						IL_2212:
																						if (72 <= b)
																						{
																							goto IL_2220;
																						}
																						goto IL_22a9;
																						IL_2220:
																						array[num6 - 2] = 3;
																						goto IL_2234;
																						IL_2234:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<float, float, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																						goto IL_2288;
																						IL_2288:
																						num6--;
																						goto IL_2296;
																						IL_2296:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_22a9:
																						if (60 < b)
																						{
																							goto IL_22b7;
																						}
																						num = 217;
																						goto IL_2779;
																						IL_22b7:
																						if (66 >= b)
																						{
																							goto IL_22c5;
																						}
																						goto IL_253a;
																						IL_22c5:
																						if (66 > b)
																						{
																							goto IL_22d3;
																						}
																						goto IL_24cc;
																						IL_22d3:
																						if (63 >= b)
																						{
																							goto IL_22e1;
																						}
																						goto IL_2406;
																						IL_22e1:
																						if (63 <= b)
																						{
																							goto IL_22ec;
																						}
																						goto IL_233f;
																						IL_22ec:
																						array[num6] = 0;
																						goto IL_22fa;
																						IL_22fa:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)getGeoIdAddRange[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_231e;
																						IL_231e:
																						num6++;
																						goto IL_232c;
																						IL_232c:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_233f:
																						if (61 >= b)
																						{
																							goto IL_234a;
																						}
																						goto IL_2384;
																						IL_234a:
																						if (61 > b)
																						{
																							break;
																						}
																						goto IL_2358;
																						IL_2358:
																						global::_003CModule_003E.string_41 = (string[])array2[num6 - 1];
																						goto IL_2371;
																						IL_2371:
																						num6--;
																						goto end_IL_0da1;
																						IL_2384:
																						if (62 < b)
																						{
																							break;
																						}
																						goto IL_2392;
																						IL_2392:
																						if (62 > b)
																						{
																							break;
																						}
																						goto IL_23a0;
																						IL_23a0:
																						array[num6 - 1] = 3;
																						goto IL_23b4;
																						IL_23b4:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_23f3;
																						IL_23f3:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2406:
																						if (64 >= b)
																						{
																							goto IL_2411;
																						}
																						goto IL_2485;
																						IL_2411:
																						if (64 > b)
																						{
																							break;
																						}
																						goto IL_241f;
																						IL_241f:
																						array[num6 - 1] = 3;
																						goto IL_2433;
																						IL_2433:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2472;
																						IL_2472:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2485:
																						if (65 < b)
																						{
																							break;
																						}
																						goto IL_2493;
																						IL_2493:
																						if (65 > b)
																						{
																							break;
																						}
																						goto IL_24a1;
																						IL_24a1:
																						array2[num6] = null;
																						goto IL_24ab;
																						IL_24ab:
																						array[num6] = 5;
																						goto IL_24b9;
																						IL_24b9:
																						num6++;
																						goto end_IL_0da1;
																						IL_24cc:
																						((delegate*<List<GameEntityCreateData>, Player, bool, void>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num6 - 3], (Player)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0);
																						goto IL_2519;
																						IL_2519:
																						num6 -= 3;
																						goto IL_2527;
																						IL_2527:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_253a:
																						if (69 >= b)
																						{
																							goto IL_2548;
																						}
																						goto IL_2684;
																						IL_2548:
																						if (69 > b)
																						{
																							goto IL_2556;
																						}
																						num = 558;
																						goto IL_2630;
																						IL_2556:
																						if (67 >= b)
																						{
																							goto IL_2561;
																						}
																						goto IL_25d5;
																						IL_2561:
																						if (67 > b)
																						{
																							break;
																						}
																						goto IL_256f;
																						IL_256f:
																						array[num6 - 1] = 3;
																						goto IL_2583;
																						IL_2583:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_25c2;
																						IL_25c2:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_25d5:
																						if (68 < b)
																						{
																							break;
																						}
																						goto IL_25e3;
																						IL_25e3:
																						if (68 > b)
																						{
																							break;
																						}
																						goto IL_25f1;
																						IL_25f1:
																						global::_003CModule_003E.int_194 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_260b;
																						IL_260b:
																						num6--;
																						num = 494;
																						goto end_IL_0da1;
																						IL_3792:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num6 - 2], (string)array2[num6 - 1]) ? 1 : 0);
																						goto IL_37e4;
																						IL_2630:
																						array[num6] = 15;
																						goto IL_263e;
																						IL_263e:
																						array3[num6] = *(int*)(ptr2 + num3);
																						goto IL_2651;
																						IL_2651:
																						ptr2 += 8;
																						num = 142;
																						goto IL_2668;
																						IL_2668:
																						num6++;
																						num = 309;
																						goto end_IL_0da1;
																						IL_2684:
																						if (70 >= b)
																						{
																							goto IL_268f;
																						}
																						goto IL_26ef;
																						IL_268f:
																						if (70 > b)
																						{
																							break;
																						}
																						goto IL_269d;
																						IL_269d:
																						array2[num6] = ((delegate*<Vector3>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_26c0;
																						IL_26c0:
																						array[num6] = 4;
																						goto IL_26ce;
																						IL_26ce:
																						num6++;
																						goto IL_26dc;
																						IL_26dc:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_26ef:
																						if (71 < b)
																						{
																							break;
																						}
																						goto IL_26fd;
																						IL_26fd:
																						if (71 > b)
																						{
																							break;
																						}
																						goto IL_270b;
																						IL_270b:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Vector3, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																						goto IL_2749;
																						IL_2749:
																						array[num6 - 1] = 3;
																						goto IL_275d;
																						IL_275d:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_377e:
																						array[num6 - 2] = 0;
																						goto IL_3792;
																						IL_2779:
																						if (60 <= b)
																						{
																							goto IL_2784;
																						}
																						goto IL_27e3;
																						IL_2784:
																						array2[num6] = ((delegate*<string[]>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						num = 414;
																						goto IL_27ab;
																						IL_27ab:
																						array[num6] = 5;
																						goto IL_27b9;
																						IL_27b9:
																						num6++;
																						goto IL_27c7;
																						IL_27c7:
																						ptr2 += 8;
																						num = 607;
																						goto end_IL_0da1;
																						IL_27e3:
																						if (54 >= b)
																						{
																							goto IL_27f1;
																						}
																						goto IL_2acc;
																						IL_27f1:
																						if (54 <= b)
																						{
																							goto IL_27fc;
																						}
																						goto IL_284e;
																						IL_27fc:
																						array[num6] = 4;
																						goto IL_280a;
																						IL_280a:
																						array2[num6] = ((delegate*<Quaternion>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_282d;
																						IL_282d:
																						num6++;
																						goto IL_283b;
																						IL_283b:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_284e:
																						if (51 >= b)
																						{
																							goto IL_285c;
																						}
																						goto IL_29ca;
																						IL_285c:
																						if (51 <= b)
																						{
																							goto IL_2867;
																						}
																						goto IL_28da;
																						IL_2867:
																						((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)getGeoIdAddRange[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_28c7;
																						IL_28c7:
																						num6 -= 2;
																						goto end_IL_0da1;
																						IL_28da:
																						if (49 < b)
																						{
																							goto IL_28e5;
																						}
																						goto IL_2954;
																						IL_28e5:
																						if (50 < b)
																						{
																							break;
																						}
																						goto IL_28f3;
																						IL_28f3:
																						if (50 > b)
																						{
																							break;
																						}
																						goto IL_2901;
																						IL_2901:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_2925;
																						IL_2925:
																						array[num6] = 0;
																						goto IL_2933;
																						IL_2933:
																						num6++;
																						goto IL_2941;
																						IL_2941:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2954:
																						if (49 > b)
																						{
																							break;
																						}
																						goto IL_2962;
																						IL_2962:
																						((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)getGeoIdAddRange[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4) = default(GameEntityCreateData);
																						num = 170;
																						goto IL_29b7;
																						IL_29b7:
																						num6--;
																						goto end_IL_0da1;
																						IL_29ca:
																						if (52 >= b)
																						{
																							goto IL_29d5;
																						}
																						goto IL_2a3e;
																						IL_29d5:
																						if (52 > b)
																						{
																							break;
																						}
																						goto IL_29e3;
																						IL_29e3:
																						array2[num6] = ((delegate*<Vector3>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						num = 347;
																						goto IL_2a0f;
																						IL_2a0f:
																						array[num6] = 4;
																						goto IL_2a1d;
																						IL_2a1d:
																						num6++;
																						goto IL_2a2b;
																						IL_2a2b:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2a3e:
																						if (53 < b)
																						{
																							break;
																						}
																						goto IL_2a4c;
																						IL_2a4c:
																						if (53 > b)
																						{
																							break;
																						}
																						goto IL_2a5a;
																						IL_2a5a:
																						((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)getGeoIdAddRange[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).position = (Vector3)array2[num6 - 1];
																						goto IL_2ab9;
																						IL_2ab9:
																						num6 -= 2;
																						goto end_IL_0da1;
																						IL_2acc:
																						if (57 >= b)
																						{
																							goto IL_2ada;
																						}
																						goto IL_2c46;
																						IL_2ada:
																						if (57 > b)
																						{
																							goto IL_2ae8;
																						}
																						goto IL_2bd3;
																						IL_2ae8:
																						if (55 < b)
																						{
																							goto IL_2af3;
																						}
																						goto IL_2b53;
																						IL_2af3:
																						if (56 < b)
																						{
																							break;
																						}
																						goto IL_2b01;
																						IL_2b01:
																						if (56 > b)
																						{
																							break;
																						}
																						goto IL_2b0f;
																						IL_2b0f:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_2b3a;
																						IL_2b3a:
																						array[num6 - 1] = 1;
																						goto end_IL_0da1;
																						IL_2b53:
																						if (55 > b)
																						{
																							break;
																						}
																						goto IL_2b61;
																						IL_2b61:
																						((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)getGeoIdAddRange[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).rotation = (Quaternion)array2[num6 - 1];
																						goto IL_2bc0;
																						IL_2bc0:
																						num6 -= 2;
																						goto end_IL_0da1;
																						IL_2bd3:
																						((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)getGeoIdAddRange[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_2c33;
																						IL_2c33:
																						num6 -= 2;
																						goto end_IL_0da1;
																						IL_2c46:
																						if (58 >= b)
																						{
																							goto IL_2c51;
																						}
																						goto IL_2cb1;
																						IL_2c51:
																						if (58 > b)
																						{
																							break;
																						}
																						goto IL_2c5f;
																						IL_2c5f:
																						array2[num6] = ((delegate*<GameEntityCreateData>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_2c82;
																						IL_2c82:
																						array[num6] = 4;
																						goto IL_2c90;
																						IL_2c90:
																						num6++;
																						goto IL_2c9e;
																						IL_2c9e:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2cb1:
																						if (59 < b)
																						{
																							break;
																						}
																						goto IL_2cbf;
																						IL_2cbf:
																						if (59 > b)
																						{
																							break;
																						}
																						goto IL_2ccd;
																						IL_2ccd:
																						((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num6 - 2], (GameEntityCreateData)array2[num6 - 1]);
																						goto IL_2d0a;
																						IL_2d0a:
																						num6 -= 2;
																						num = 187;
																						goto IL_2d21;
																						IL_2d21:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2d34:
																						if (84 >= b)
																						{
																							goto IL_2d42;
																						}
																						goto IL_33c8;
																						IL_2d42:
																						if (84 > b)
																						{
																							goto IL_2d50;
																						}
																						goto IL_337b;
																						IL_2d50:
																						if (78 >= b)
																						{
																							num = 47;
																							goto IL_2d67;
																						}
																						goto IL_30fe;
																						IL_37e4:
																						num6--;
																						goto IL_37f2;
																						IL_2d67:
																						if (78 <= b)
																						{
																							goto IL_2d72;
																						}
																						goto IL_2dd8;
																						IL_2d72:
																						array[num6 - 1] = 3;
																						goto IL_2d86;
																						IL_2d86:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_2dc5;
																						IL_2dc5:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2dd8:
																						if (75 >= b)
																						{
																							goto IL_2de6;
																						}
																						goto IL_2f82;
																						IL_2de6:
																						if (75 <= b)
																						{
																							goto IL_2df1;
																						}
																						goto IL_2e5f;
																						IL_2df1:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Vector3, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																						num = 531;
																						goto IL_2e38;
																						IL_2e38:
																						array[num6 - 1] = 3;
																						goto IL_2e4c;
																						IL_2e4c:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2e5f:
																						if (73 >= b)
																						{
																							goto IL_2e6a;
																						}
																						goto IL_2edd;
																						IL_2e6a:
																						if (73 > b)
																						{
																							break;
																						}
																						goto IL_2e78;
																						IL_2e78:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Vector3, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																						goto IL_2eb6;
																						IL_2eb6:
																						array[num6 - 1] = 3;
																						goto IL_2eca;
																						IL_2eca:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2edd:
																						if (74 < b)
																						{
																							break;
																						}
																						goto IL_2eeb;
																						IL_2eeb:
																						if (74 > b)
																						{
																							break;
																						}
																						goto IL_2ef9;
																						IL_2ef9:
																						array[num6 - 2] = 3;
																						goto IL_2f0d;
																						IL_2f0d:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<float, float, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																						goto IL_2f61;
																						IL_2f61:
																						num6--;
																						goto IL_2f6f;
																						IL_2f6f:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_2f82:
																						if (76 >= b)
																						{
																							goto IL_2f90;
																						}
																						goto IL_3027;
																						IL_2f90:
																						if (76 > b)
																						{
																							break;
																						}
																						goto IL_2f9e;
																						IL_2f9e:
																						array[num6 - 2] = 3;
																						goto IL_2fb2;
																						IL_2fb2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<float, float, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																						goto IL_3006;
																						IL_3006:
																						num6--;
																						goto IL_3014;
																						IL_3014:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_3027:
																						if (77 < b)
																						{
																							break;
																						}
																						goto IL_3035;
																						IL_3035:
																						if (77 > b)
																						{
																							break;
																						}
																						goto IL_3043;
																						IL_3043:
																						((delegate*<ref Vector3, float, float, float, void>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)getGeoIdAddRange[array3[num6 - 4]])(array2[num6 - 4], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 4])), array6, array4), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																						goto IL_30dd;
																						IL_30dd:
																						num6 -= 4;
																						goto IL_30eb;
																						IL_30eb:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_30fe:
																						if (81 >= b)
																						{
																							goto IL_310c;
																						}
																						goto IL_326c;
																						IL_310c:
																						if (81 <= b)
																						{
																							goto IL_3117;
																						}
																						goto IL_316a;
																						IL_3117:
																						array[num6] = 0;
																						goto IL_3125;
																						IL_3125:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)getGeoIdAddRange[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_3149;
																						IL_3149:
																						num6++;
																						goto IL_3157;
																						IL_3157:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_316a:
																						if (79 < b)
																						{
																							goto IL_3178;
																						}
																						goto IL_31f9;
																						IL_3178:
																						if (80 < b)
																						{
																							break;
																						}
																						goto IL_3186;
																						IL_3186:
																						if (80 > b)
																						{
																							break;
																						}
																						num = 328;
																						goto IL_319d;
																						IL_37f2:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_319d:
																						array[num6] = 0;
																						goto IL_31ab;
																						IL_31ab:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = (((delegate*<bool>)getGeoIdAddRange[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_31cf;
																						IL_31cf:
																						num6++;
																						num = 726;
																						goto IL_31e6;
																						IL_31e6:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_31f9:
																						if (79 > b)
																						{
																							break;
																						}
																						goto IL_3207;
																						IL_3207:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Class117, float>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Class117)array2[num6 - 1]);
																						goto IL_3245;
																						IL_3245:
																						array[num6 - 1] = 3;
																						goto IL_3259;
																						IL_3259:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_326c:
																						if (82 < b)
																						{
																							goto IL_327a;
																						}
																						goto IL_32fc;
																						IL_327a:
																						if (83 < b)
																						{
																							break;
																						}
																						goto IL_3288;
																						IL_3288:
																						if (83 > b)
																						{
																							break;
																						}
																						goto IL_3296;
																						IL_3296:
																						array[num6 - 1] = 3;
																						goto IL_32aa;
																						IL_32aa:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getGeoIdAddRange[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_32e9;
																						IL_32e9:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_32fc:
																						if (82 > b)
																						{
																							break;
																						}
																						goto IL_330a;
																						IL_330a:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_3368;
																						IL_3368:
																						num6--;
																						goto end_IL_0da1;
																						IL_337b:
																						array[num6] = 5;
																						goto IL_3389;
																						IL_3389:
																						array2[num6] = ((delegate*<GorillaTagger>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_33a7;
																						IL_33a7:
																						num6++;
																						goto IL_33b5;
																						IL_33b5:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_33c8:
																						if (90 >= b)
																						{
																							goto IL_33d6;
																						}
																						goto IL_3645;
																						IL_33d6:
																						if (90 > b)
																						{
																							goto IL_33e4;
																						}
																						goto IL_3601;
																						IL_33e4:
																						if (87 >= b)
																						{
																							goto IL_33f2;
																						}
																						goto IL_355d;
																						IL_33f2:
																						if (87 <= b)
																						{
																							goto IL_33fd;
																						}
																						goto IL_3461;
																						IL_33fd:
																						array[num6 - 1] = 4;
																						goto IL_3411;
																						IL_3411:
																						array2[num6 - 1] = ((delegate*<Transform, Vector3>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																						goto IL_344e;
																						IL_344e:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_3461:
																						if (85 < b)
																						{
																							goto IL_346c;
																						}
																						num = 596;
																						goto IL_34f0;
																						IL_346c:
																						if (86 < b)
																						{
																							break;
																						}
																						goto IL_347a;
																						IL_347a:
																						if (86 > b)
																						{
																							break;
																						}
																						goto IL_3488;
																						IL_3488:
																						array[num6 - 1] = 5;
																						goto IL_349c;
																						IL_349c:
																						array2[num6 - 1] = ((delegate*<Component, Transform>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																						goto IL_34d4;
																						IL_34d4:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_3802:
																						if (95 < b)
																						{
																							break;
																						}
																						goto IL_380d;
																						IL_34f0:
																						if (85 > b)
																						{
																							break;
																						}
																						goto IL_34fe;
																						IL_34fe:
																						array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)getGeoIdAddRange[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																						goto IL_3536;
																						IL_3536:
																						array[num6 - 1] = 5;
																						goto IL_354a;
																						IL_354a:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_355d:
																						if (88 >= b)
																						{
																							goto IL_3568;
																						}
																						goto IL_35a2;
																						IL_3568:
																						if (88 > b)
																						{
																							break;
																						}
																						goto IL_3576;
																						IL_3576:
																						global::_003CModule_003E.vector3_101 = (Vector3)array2[num6 - 1];
																						goto IL_358f;
																						IL_358f:
																						num6--;
																						goto end_IL_0da1;
																						IL_35a2:
																						if (89 < b)
																						{
																							break;
																						}
																						goto IL_35b0;
																						IL_35b0:
																						if (89 > b)
																						{
																							break;
																						}
																						goto IL_35be;
																						IL_35be:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (nint)((string[])array2[num6 - 1]).LongLength;
																						goto IL_35e8;
																						IL_35e8:
																						array[num6 - 1] = 2;
																						goto end_IL_0da1;
																						IL_3601:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_362c;
																						IL_362c:
																						array[num6 - 1] = 0;
																						goto end_IL_0da1;
																						IL_3645:
																						if (93 >= b)
																						{
																							goto IL_3653;
																						}
																						goto IL_3762;
																						IL_3653:
																						if (93 <= b)
																						{
																							goto IL_365e;
																						}
																						goto IL_368a;
																						IL_365e:
																						global::_003CModule_003E.list_9 = (List<GameEntityCreateData>)array2[num6 - 1];
																						goto IL_3677;
																						IL_3677:
																						num6--;
																						goto end_IL_0da1;
																						IL_368a:
																						if (91 >= b)
																						{
																							goto IL_3695;
																						}
																						goto IL_36f0;
																						IL_3695:
																						if (91 > b)
																						{
																							break;
																						}
																						goto IL_36a3;
																						IL_36a3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_36ce;
																						IL_36ce:
																						array[num6 - 1] = 0;
																						num = 353;
																						goto end_IL_0da1;
																						IL_36f0:
																						if (92 < b)
																						{
																							break;
																						}
																						goto IL_36fe;
																						IL_36fe:
																						if (92 > b)
																						{
																							break;
																						}
																						num = 326;
																						goto IL_3715;
																						IL_380d:
																						if (95 <= b)
																						{
																							num = 272;
																						}
																						break;
																						IL_3715:
																						array[num6] = 5;
																						goto IL_3723;
																						IL_3723:
																						array2[num6] = ((delegate*<List<GameEntityCreateData>>)getGeoIdAddRange[*(int*)(ptr2 + num3)])();
																						goto IL_3741;
																						IL_3741:
																						num6++;
																						goto IL_374f;
																						IL_374f:
																						ptr2 += 8;
																						goto end_IL_0da1;
																						IL_3762:
																						if (94 >= b)
																						{
																							goto IL_3770;
																						}
																						goto IL_3802;
																					}
																					break;
																					IL_0d91:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_0da1:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
															}
															num = 119;
															return;
															continue;
															end_IL_3834:
															break;
														}
														continue;
														end_IL_3847:
														break;
													}
													continue;
													end_IL_3851:
													break;
												}
												continue;
												end_IL_3865:
												break;
											}
											continue;
											end_IL_3875:
											break;
										}
										continue;
										end_IL_388e:
										break;
									}
									continue;
									end_IL_389e:
									break;
								}
								continue;
								end_IL_38b7:
								break;
							}
							continue;
							end_IL_38c7:
							break;
						}
						continue;
						end_IL_38d7:
						break;
					}
					continue;
					end_IL_38e7:
					break;
				}
				continue;
				end_IL_38f7:
				break;
			}
		}
	}

	private void OnDisable()
	{
		Class9.smethod_49();
	}

	private unsafe void method_0()
	{
		int num = 170;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 22;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefaultDependencyAttributeFileExists.CopyTorandom);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_03ac:
															if (b >= 1)
															{
																while (b <= 21)
																{
																	while (true)
																	{
																		IL_038f:
																		if (11 < b)
																		{
																			while (true)
																			{
																				IL_037f:
																				if (16 < b)
																				{
																					while (true)
																					{
																						IL_0372:
																						if (19 >= b)
																						{
																							while (true)
																							{
																								IL_0362:
																								if (19 <= b)
																								{
																									while (true)
																									{
																										IL_034c:
																										array[num6 - 1] = 0;
																										while (true)
																										{
																											IL_0302:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)TraceGuidQueryInfoSetCurrentThreadActivityId[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											num = 184;
																											while (true)
																											{
																												if (num != 184)
																												{
																													if (num != 1165)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 144:
																														goto IL_0302;
																													case 62:
																													case 107:
																														goto IL_034c;
																													case 159:
																														goto IL_0362;
																													case 146:
																														goto IL_0372;
																													case 17:
																														goto IL_037f;
																													case 89:
																														goto IL_038f;
																													case 37:
																														goto end_IL_038f;
																													case 95:
																														goto IL_03ac;
																													case 28:
																														goto end_IL_03ac;
																													case 69:
																													case 143:
																														goto end_IL_03bc;
																													case 6:
																														goto IL_03d7;
																													case 43:
																														goto IL_03e5;
																													case 73:
																														goto IL_03f5;
																													case 53:
																													case 118:
																														goto IL_0408;
																													case 131:
																														goto IL_0424;
																													case 32:
																													case 55:
																														goto IL_042f;
																													case 125:
																														goto IL_0449;
																													case 50:
																														goto IL_0454;
																													case 23:
																													case 101:
																														goto IL_0462;
																													case 129:
																														goto IL_047a;
																													case 110:
																														goto IL_0491;
																													case 18:
																													case 20:
																														goto IL_049f;
																													case 51:
																														goto IL_04e0;
																													case 33:
																														goto IL_04f4;
																													case 141:
																														goto IL_0507;
																													case 49:
																														goto IL_0515;
																													case 142:
																														goto IL_0528;
																													case 85:
																														goto IL_0536;
																													case 151:
																														goto IL_0546;
																													case 134:
																													case 154:
																														goto IL_0556;
																													case 98:
																														goto IL_05a8;
																													case 155:
																														goto IL_05bb;
																													case 99:
																													case 116:
																														goto IL_05c9;
																													case 165:
																														goto IL_05f0;
																													case 27:
																														goto IL_05fe;
																													case 47:
																													case 91:
																														goto IL_0609;
																													case 1:
																														goto IL_0649;
																													case 80:
																														goto IL_065d;
																													case 19:
																														goto IL_0670;
																													case 0:
																														goto IL_067e;
																													case 9:
																														goto IL_0689;
																													case 119:
																													case 164:
																														goto IL_0697;
																													case 160:
																														goto IL_06c0;
																													case 16:
																														goto IL_06ce;
																													case 109:
																														goto IL_06e1;
																													case 8:
																														goto IL_06ef;
																													case 102:
																													case 150:
																														goto IL_06fd;
																													case 75:
																														goto IL_070b;
																													case 83:
																														goto IL_072e;
																													case 133:
																														goto IL_0741;
																													case 60:
																														goto IL_074f;
																													case 163:
																														goto IL_0762;
																													case 152:
																														goto IL_0770;
																													case 140:
																													case 156:
																														goto IL_077b;
																													case 10:
																														goto IL_078e;
																													case 24:
																														goto IL_0799;
																													case 70:
																													case 115:
																														goto IL_07a7;
																													case 104:
																														goto IL_07e7;
																													case 57:
																														goto IL_0800;
																													case 38:
																														goto IL_080e;
																													case 59:
																													case 79:
																														goto IL_081c;
																													case 121:
																														goto IL_085c;
																													case 36:
																														goto IL_0870;
																													case 167:
																														goto IL_0883;
																													case 82:
																														goto IL_0891;
																													case 162:
																														goto IL_089f;
																													case 172:
																														goto IL_08b2;
																													case 58:
																														goto IL_08bd;
																													case 76:
																														goto IL_08d0;
																													case 39:
																														goto IL_08de;
																													case 2:
																													case 123:
																														goto IL_08ec;
																													case 56:
																														goto IL_094e;
																													case 174:
																														goto IL_0961;
																													case 175:
																														goto IL_0974;
																													case 136:
																													case 148:
																														goto IL_097f;
																													case 88:
																														goto IL_09bf;
																													case 100:
																														goto IL_09d3;
																													case 158:
																														goto IL_09e6;
																													case 44:
																														goto IL_09f4;
																													case 74:
																													case 90:
																														goto end_IL_02ef;
																													case 106:
																														goto IL_0a1b;
																													case 124:
																														goto IL_0a29;
																													case 122:
																														goto IL_0a37;
																													case 176:
																														goto IL_0a4a;
																													case 111:
																													case 177:
																														goto IL_0a5d;
																													case 147:
																														goto IL_0a9d;
																													case 112:
																														goto IL_0aba;
																													case 126:
																														goto IL_0ae0;
																													case 105:
																														goto IL_0aeb;
																													case 61:
																													case 128:
																														goto IL_0af9;
																													case 42:
																														goto IL_0b12;
																													case 12:
																														goto IL_0b20;
																													case 21:
																														goto IL_0b2e;
																													case 54:
																														goto IL_0b4a;
																													case 35:
																														goto IL_0b55;
																													case 78:
																													case 81:
																														goto IL_0b60;
																													case 130:
																														goto IL_0ba0;
																													case 145:
																														goto IL_0bb4;
																													case 5:
																													case 7:
																													case 15:
																													case 25:
																													case 29:
																													case 41:
																													case 52:
																													case 64:
																													case 66:
																													case 72:
																													case 77:
																													case 84:
																													case 86:
																													case 87:
																													case 94:
																													case 96:
																													case 108:
																													case 120:
																													case 127:
																													case 132:
																													case 135:
																													case 137:
																													case 139:
																													case 153:
																														goto end_IL_039c;
																													case 3:
																													case 4:
																													case 11:
																													case 13:
																													case 14:
																													case 30:
																													case 34:
																													case 45:
																													case 46:
																													case 48:
																													case 63:
																													case 68:
																													case 71:
																													case 92:
																													case 93:
																													case 103:
																													case 113:
																													case 114:
																													case 117:
																													case 138:
																													case 157:
																													case 166:
																													case 171:
																													case 173:
																														goto end_IL_03cc;
																													case 67:
																														goto end_IL_0bd7;
																													case 161:
																														goto end_IL_0bea;
																													case 31:
																														goto end_IL_0bf4;
																													case 26:
																													case 97:
																														goto end_IL_0bff;
																													case 65:
																														goto end_IL_0c0f;
																													case 22:
																														goto end_IL_0c1f;
																													case 168:
																														goto end_IL_0c2f;
																													case 169:
																														goto end_IL_0c3f;
																													case 170:
																														goto end_IL_0c58;
																													case 40:
																													case 149:
																														return;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto end_IL_03cc;
																												continue;
																												end_IL_02ef:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0ae0;
																								IL_0bb4:
																								num6--;
																								goto end_IL_03cc;
																								IL_0ae0:
																								if (17 >= b)
																								{
																									goto IL_0aeb;
																								}
																								goto IL_0b4a;
																								IL_0aeb:
																								if (17 > b)
																								{
																									goto end_IL_039c;
																								}
																								goto IL_0af9;
																								IL_0af9:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																								goto IL_0b12;
																								IL_0b12:
																								array[num6] = 3;
																								goto IL_0b20;
																								IL_0b20:
																								num6++;
																								goto IL_0b2e;
																								IL_0b2e:
																								ptr2 += 16;
																								num = 93;
																								goto end_IL_03cc;
																								IL_0b4a:
																								if (18 < b)
																								{
																									goto end_IL_039c;
																								}
																								goto IL_0b55;
																								IL_0b55:
																								if (18 > b)
																								{
																									goto end_IL_039c;
																								}
																								goto IL_0b60;
																								IL_0b60:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0ba0;
																								IL_0ba0:
																								array[num6 - 2] = 3;
																								goto IL_0bb4;
																							}
																							break;
																						}
																						goto IL_03d7;
																						IL_0515:
																						if (21 > b)
																						{
																						}
																						goto end_IL_039c;
																						IL_03d7:
																						if (20 >= b)
																						{
																							goto IL_03e5;
																						}
																						goto IL_0507;
																						IL_03e5:
																						if (20 > b)
																						{
																							goto end_IL_039c;
																						}
																						goto IL_0408;
																						IL_0408:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_03cc;
																						IL_0507:
																						if (21 < b)
																						{
																							goto end_IL_039c;
																						}
																						goto IL_0515;
																					}
																					break;
																				}
																				goto IL_0424;
																				IL_0556:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05a8;
																				IL_0424:
																				if (16 <= b)
																				{
																					goto IL_042f;
																				}
																				goto IL_0449;
																				IL_042f:
																				((delegate*<void>)TraceGuidQueryInfoSetCurrentThreadActivityId[*(int*)(ptr2 + num3)])();
																				goto IL_0a4a;
																				IL_0a4a:
																				ptr2 += 8;
																				goto end_IL_03cc;
																				IL_0449:
																				if (13 >= b)
																				{
																					goto IL_0454;
																				}
																				goto IL_047a;
																				IL_0454:
																				if (13 <= b)
																				{
																					goto IL_0462;
																				}
																				goto IL_0546;
																				IL_0462:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_03cc;
																				IL_0546:
																				if (12 < b)
																				{
																					goto end_IL_039c;
																				}
																				goto IL_05bb;
																				IL_05bb:
																				if (12 > b)
																				{
																					goto end_IL_039c;
																				}
																				goto IL_05c9;
																				IL_05c9:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				num = 167;
																				goto IL_0883;
																				IL_0883:
																				array[num6] = 1;
																				goto IL_0891;
																				IL_0891:
																				num6++;
																				goto IL_089f;
																				IL_089f:
																				ptr2 += 16;
																				goto end_IL_03cc;
																				IL_047a:
																				if (14 >= b)
																				{
																					num = 110;
																					goto IL_0491;
																				}
																				goto IL_0528;
																				IL_05a8:
																				num6--;
																				goto end_IL_03cc;
																				IL_0491:
																				if (14 > b)
																				{
																					goto end_IL_039c;
																				}
																				goto IL_049f;
																				IL_049f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_04e0;
																				IL_04e0:
																				array[num6 - 2] = 0;
																				goto IL_04f4;
																				IL_04f4:
																				num6--;
																				goto end_IL_03cc;
																				IL_0528:
																				if (15 < b)
																				{
																					goto end_IL_039c;
																				}
																				goto IL_0536;
																				IL_0536:
																				if (15 > b)
																				{
																					goto end_IL_039c;
																				}
																				goto IL_0556;
																			}
																			goto IL_0a02;
																		}
																		goto IL_03f5;
																		IL_094e:
																		num6 -= 2;
																		goto end_IL_03cc;
																		IL_03f5:
																		if (11 <= b)
																		{
																			goto end_IL_03cc;
																		}
																		goto IL_05f0;
																		IL_05f0:
																		if (5 >= b)
																		{
																			goto IL_05fe;
																		}
																		goto IL_0762;
																		IL_05fe:
																		if (5 <= b)
																		{
																			goto IL_0609;
																		}
																		goto IL_0670;
																		IL_0609:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0649;
																		IL_0649:
																		array[num6 - 2] = 0;
																		goto IL_065d;
																		IL_065d:
																		num6--;
																		goto end_IL_03cc;
																		IL_0670:
																		if (2 < b)
																		{
																			goto IL_067e;
																		}
																		goto IL_0974;
																		IL_067e:
																		if (3 >= b)
																		{
																			goto IL_0689;
																		}
																		goto IL_06e1;
																		IL_0689:
																		if (3 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_0697;
																		IL_0697:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_06c0;
																		IL_06c0:
																		ptr2 += 8;
																		goto IL_06ce;
																		IL_06ce:
																		num6--;
																		goto end_IL_03cc;
																		IL_06e1:
																		if (4 < b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_06ef;
																		IL_06ef:
																		if (4 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_06fd;
																		IL_06fd:
																		array[num6] = 0;
																		goto IL_070b;
																		IL_070b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_072e;
																		IL_072e:
																		array2[num6] = null;
																		num = 133;
																		goto IL_0741;
																		IL_0741:
																		num6++;
																		goto IL_074f;
																		IL_074f:
																		ptr2 += 8;
																		goto end_IL_03cc;
																		IL_0974:
																		if (2 <= b)
																		{
																			goto IL_097f;
																		}
																		goto IL_09e6;
																		IL_097f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_09bf;
																		IL_09bf:
																		array[num6 - 2] = 0;
																		goto IL_09d3;
																		IL_09d3:
																		num6--;
																		goto end_IL_03cc;
																		IL_09e6:
																		if (1 < b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_09f4;
																		IL_09f4:
																		if (1 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_0a02;
																		IL_0a02:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a1b;
																		IL_0a1b:
																		array[num6] = 0;
																		goto IL_0a29;
																		IL_0a29:
																		num6++;
																		goto IL_0a37;
																		IL_0a37:
																		ptr2 += 8;
																		goto end_IL_03cc;
																		IL_0762:
																		if (8 >= b)
																		{
																			goto IL_0770;
																		}
																		goto IL_08b2;
																		IL_0770:
																		if (8 <= b)
																		{
																			goto IL_077b;
																		}
																		goto IL_078e;
																		IL_077b:
																		num6--;
																		goto end_IL_03cc;
																		IL_078e:
																		if (6 >= b)
																		{
																			goto IL_0799;
																		}
																		goto IL_0800;
																		IL_0799:
																		if (6 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_07a7;
																		IL_07a7:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_07e7;
																		IL_07e7:
																		array[num6 - 2] = 0;
																		goto IL_0961;
																		IL_0961:
																		num6--;
																		goto end_IL_03cc;
																		IL_0800:
																		if (7 < b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_080e;
																		IL_080e:
																		if (7 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_081c;
																		IL_081c:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_085c;
																		IL_085c:
																		array[num6 - 2] = 0;
																		goto IL_0870;
																		IL_0870:
																		num6--;
																		goto end_IL_03cc;
																		IL_08b2:
																		if (9 >= b)
																		{
																			goto IL_08bd;
																		}
																		goto IL_08d0;
																		IL_08bd:
																		if (9 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_0a5d;
																		IL_0a5d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0a9d;
																		IL_0a9d:
																		array[num6 - 2] = 0;
																		num = 112;
																		goto IL_0aba;
																		IL_0aba:
																		num6--;
																		goto end_IL_03cc;
																		IL_08d0:
																		if (10 < b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_08de;
																		IL_08de:
																		if (10 > b)
																		{
																			goto end_IL_039c;
																		}
																		goto IL_08ec;
																		IL_08ec:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_094e;
																		continue;
																		end_IL_038f:
																		break;
																	}
																	continue;
																	end_IL_039c:
																	break;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_03cc;
															continue;
															end_IL_03ac:
															break;
														}
														continue;
														end_IL_03bc:
														break;
													}
													continue;
													end_IL_03cc:
													break;
												}
												continue;
												end_IL_0bd7:
												break;
											}
											continue;
											end_IL_0bea:
											break;
										}
										continue;
										end_IL_0bf4:
										break;
									}
									continue;
									end_IL_0bff:
									break;
								}
								continue;
								end_IL_0c0f:
								break;
							}
							continue;
							end_IL_0c1f:
							break;
						}
						continue;
						end_IL_0c2f:
						break;
					}
					continue;
					end_IL_0c3f:
					break;
				}
				continue;
				end_IL_0c58:
				break;
			}
		}
	}

	public Class117()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 38;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setParamTypesgetMutex.SparseArrayTables);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_038d:
														byte b = *ptr2;
														while (true)
														{
															IL_037d:
															ptr2++;
															while (true)
															{
																IL_036d:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_034d:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_032d:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_0320:
																								if (4 <= b)
																								{
																									while (true)
																									{
																										IL_02f7:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										num = 12;
																										while (true)
																										{
																											IL_02e7:
																											ptr2 += 8;
																											while (true)
																											{
																												IL_02ce:
																												num5--;
																												num = 171;
																												while (num != 171)
																												{
																													if (num != 1152)
																													{
																														goto IL_0530;
																													}
																													switch (num)
																													{
																													case 60:
																														goto IL_02ce;
																													case 12:
																														goto IL_02e7;
																													case 27:
																													case 63:
																														goto IL_02f7;
																													case 140:
																														goto IL_0320;
																													case 105:
																													case 149:
																														goto IL_032d;
																													case 104:
																														goto IL_033d;
																													case 150:
																														goto IL_034d;
																													case 137:
																														goto IL_035d;
																													case 18:
																														goto IL_036d;
																													case 92:
																														goto IL_037d;
																													case 6:
																													case 139:
																														goto IL_038d;
																													case 95:
																														goto IL_0398;
																													case 58:
																													case 144:
																														goto IL_03a3;
																													case 85:
																														goto IL_03b1;
																													case 16:
																													case 107:
																														goto IL_03bf;
																													case 153:
																														goto IL_03e8;
																													case 164:
																														goto IL_0401;
																													case 21:
																													case 74:
																														goto IL_040c;
																													case 145:
																														goto IL_041a;
																													case 17:
																													case 98:
																														goto IL_0428;
																													case 9:
																														goto IL_0441;
																													case 68:
																														goto IL_044f;
																													case 62:
																														goto IL_045d;
																													case 41:
																													case 69:
																														goto IL_0470;
																													case 97:
																														goto IL_04b0;
																													case 154:
																														goto IL_04c4;
																													case 75:
																														goto IL_04d7;
																													case 2:
																													case 45:
																														goto IL_04e5;
																													case 20:
																														goto IL_04f0;
																													case 29:
																													case 57:
																														goto IL_04fe;
																													case 91:
																														goto IL_0530;
																													case 136:
																														goto IL_053e;
																													case 155:
																														goto IL_0551;
																													case 8:
																														goto IL_055f;
																													case 130:
																													case 138:
																														goto IL_056d;
																													case 151:
																														goto IL_0585;
																													case 67:
																														goto IL_0590;
																													case 102:
																														goto IL_059e;
																													case 71:
																													case 129:
																														goto IL_05b5;
																													case 120:
																														goto IL_05c3;
																													case 3:
																														goto IL_05db;
																													case 162:
																														goto IL_05e9;
																													case 52:
																													case 159:
																														goto IL_05fc;
																													case 81:
																														goto IL_063b;
																													case 24:
																													case 163:
																														goto IL_064e;
																													case 5:
																														goto IL_065c;
																													case 66:
																													case 147:
																														goto IL_0667;
																													case 100:
																														goto IL_0672;
																													case 54:
																													case 148:
																														goto IL_0680;
																													case 72:
																														goto IL_069c;
																													case 134:
																														goto IL_06aa;
																													case 146:
																														goto IL_06c6;
																													case 78:
																													case 118:
																														goto IL_06d1;
																													case 56:
																													case 152:
																														goto IL_06e4;
																													case 101:
																														goto IL_06f2;
																													case 108:
																													case 115:
																														goto IL_0700;
																													case 59:
																														goto IL_070e;
																													case 88:
																														goto IL_0732;
																													case 25:
																														goto IL_0740;
																													case 89:
																														goto IL_075c;
																													case 14:
																													case 80:
																														goto IL_0767;
																													case 132:
																														goto IL_07c9;
																													case 82:
																														goto IL_07dc;
																													case 65:
																													case 156:
																														goto IL_07ea;
																													case 123:
																														goto IL_07f8;
																													case 23:
																													case 50:
																														goto IL_0806;
																													case 96:
																														goto IL_0846;
																													case 131:
																														goto IL_085a;
																													case 141:
																														goto IL_086d;
																													case 47:
																													case 117:
																														goto IL_0878;
																													case 133:
																														goto IL_0886;
																													case 4:
																													case 103:
																														goto IL_0894;
																													case 70:
																														goto IL_08a2;
																													case 44:
																														goto IL_08c5;
																													case 31:
																														goto IL_08cf;
																													case 111:
																														goto IL_08dd;
																													case 79:
																													case 116:
																														goto IL_08ed;
																													case 11:
																														goto IL_0931;
																													case 143:
																														goto IL_0945;
																													case 0:
																													case 1:
																													case 13:
																													case 19:
																													case 22:
																													case 26:
																													case 33:
																													case 37:
																													case 49:
																													case 51:
																													case 61:
																													case 64:
																													case 76:
																													case 87:
																													case 93:
																													case 94:
																													case 99:
																													case 106:
																													case 110:
																													case 112:
																													case 113:
																													case 114:
																													case 125:
																													case 126:
																													case 128:
																													case 157:
																													case 158:
																													case 160:
																													case 161:
																														goto end_IL_035d;
																													case 7:
																													case 15:
																													case 28:
																													case 35:
																													case 42:
																													case 43:
																													case 46:
																													case 53:
																													case 55:
																													case 73:
																													case 86:
																													case 90:
																													case 109:
																													case 119:
																													case 121:
																													case 122:
																													case 124:
																													case 127:
																													case 142:
																														goto end_IL_02bb;
																													case 135:
																														goto end_IL_0968;
																													case 77:
																														goto end_IL_097b;
																													case 34:
																														goto end_IL_0985;
																													case 10:
																														goto end_IL_0990;
																													case 38:
																													case 39:
																														goto end_IL_09a0;
																													case 36:
																														goto end_IL_09b0;
																													case 30:
																													case 40:
																														goto end_IL_09c0;
																													case 83:
																														goto end_IL_09d9;
																													case 84:
																														goto end_IL_09e9;
																													case 32:
																													case 48:
																														goto IL_0a04;
																													}
																													continue;
																													end_IL_02bb:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0398;
																								IL_04c4:
																								num5--;
																								break;
																								IL_0398:
																								if (2 < b)
																								{
																									goto IL_03a3;
																								}
																								goto IL_0401;
																								IL_03a3:
																								if (3 < b)
																								{
																									goto end_IL_035d;
																								}
																								goto IL_03b1;
																								IL_03b1:
																								if (3 > b)
																								{
																									goto end_IL_035d;
																								}
																								goto IL_03bf;
																								IL_03bf:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_03e8;
																								IL_03e8:
																								array[num5 - 1] = 5;
																								break;
																								IL_0401:
																								if (2 > b)
																								{
																									goto IL_040c;
																								}
																								goto IL_0470;
																								IL_040c:
																								if (1 < b)
																								{
																									goto end_IL_035d;
																								}
																								goto IL_041a;
																								IL_041a:
																								if (1 > b)
																								{
																									goto end_IL_035d;
																								}
																								goto IL_0428;
																								IL_0428:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0441;
																								IL_0441:
																								array[num5] = 0;
																								goto IL_044f;
																								IL_044f:
																								num5++;
																								goto IL_045d;
																								IL_045d:
																								ptr2 += 8;
																								break;
																								IL_0470:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04b0;
																								IL_04b0:
																								array[num5 - 2] = 0;
																								goto IL_04c4;
																							}
																							break;
																						}
																						goto IL_04d7;
																						IL_05fc:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_063b;
																						IL_04d7:
																						if (6 < b)
																						{
																							goto IL_04e5;
																						}
																						goto IL_0585;
																						IL_04e5:
																						if (7 >= b)
																						{
																							goto IL_04f0;
																						}
																						goto IL_0551;
																						IL_04f0:
																						if (7 > b)
																						{
																							goto end_IL_035d;
																						}
																						goto IL_04fe;
																						IL_04fe:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 91;
																						goto IL_0530;
																						IL_0530:
																						ptr2 += 8;
																						goto IL_053e;
																						IL_053e:
																						num5--;
																						break;
																						IL_0551:
																						if (8 < b)
																						{
																							goto end_IL_035d;
																						}
																						goto IL_055f;
																						IL_055f:
																						if (8 > b)
																						{
																							goto end_IL_035d;
																						}
																						goto IL_056d;
																						IL_056d:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_0585:
																						if (6 > b)
																						{
																							goto IL_0590;
																						}
																						goto IL_05fc;
																						IL_0590:
																						if (5 < b)
																						{
																							goto end_IL_035d;
																						}
																						goto IL_059e;
																						IL_059e:
																						if (5 > b)
																						{
																							goto end_IL_035d;
																						}
																						num = 129;
																						goto IL_05b5;
																						IL_063b:
																						num5 -= 3;
																						break;
																						IL_05b5:
																						array[num5] = 5;
																						goto IL_05c3;
																						IL_05c3:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_05db;
																						IL_05db:
																						num5++;
																						goto IL_05e9;
																						IL_05e9:
																						ptr2 += 8;
																						break;
																					}
																					break;
																					IL_033d:;
																				}
																				break;
																			}
																			goto IL_064e;
																			IL_0931:
																			array[num5 - 2] = 0;
																			goto IL_0945;
																			IL_064e:
																			if (13 < b)
																			{
																				goto IL_065c;
																			}
																			goto IL_075c;
																			IL_065c:
																			if (15 < b)
																			{
																				goto IL_0667;
																			}
																			goto IL_06c6;
																			IL_0667:
																			if (16 >= b)
																			{
																				goto IL_0672;
																			}
																			goto IL_069c;
																			IL_0672:
																			if (16 > b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_0680;
																			IL_0680:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_069c:
																			if (17 < b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_06aa;
																			IL_06aa:
																			if (17 > b)
																			{
																				num = 26;
																			}
																			goto end_IL_035d;
																			IL_0945:
																			num5--;
																			break;
																			IL_06c6:
																			if (15 <= b)
																			{
																				goto IL_06d1;
																			}
																			goto IL_06e4;
																			IL_06d1:
																			num5--;
																			break;
																			IL_06e4:
																			if (14 < b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_06f2;
																			IL_06f2:
																			if (14 > b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_0700;
																			IL_0700:
																			array[num5] = 0;
																			goto IL_070e;
																			IL_070e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)ReadAllLinesLdelemR[*(int*)(ptr2 + num3)])();
																			goto IL_0732;
																			IL_0732:
																			num5++;
																			goto IL_0740;
																			IL_0740:
																			ptr2 += 8;
																			num = 122;
																			break;
																			IL_075c:
																			if (13 <= b)
																			{
																				goto IL_0767;
																			}
																			goto IL_07dc;
																			IL_0767:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_07c9;
																			IL_07c9:
																			num5 -= 2;
																			break;
																			IL_07dc:
																			if (11 < b)
																			{
																				goto IL_07ea;
																			}
																			goto IL_086d;
																			IL_07ea:
																			if (12 < b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_07f8;
																			IL_07f8:
																			if (12 > b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_0806;
																			IL_0806:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0846;
																			IL_0846:
																			array[num5 - 2] = 0;
																			goto IL_085a;
																			IL_085a:
																			num5--;
																			break;
																			IL_086d:
																			if (11 > b)
																			{
																				goto IL_0878;
																			}
																			goto IL_08ed;
																			IL_0878:
																			if (10 < b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_0886;
																			IL_0886:
																			if (10 > b)
																			{
																				goto end_IL_035d;
																			}
																			goto IL_0894;
																			IL_0894:
																			array[num5] = 0;
																			goto IL_08a2;
																			IL_08a2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_08c5;
																			IL_08c5:
																			array2[num5] = null;
																			goto IL_08cf;
																			IL_08cf:
																			num5++;
																			goto IL_08dd;
																			IL_08dd:
																			ptr2 += 8;
																			break;
																			IL_08ed:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0931;
																		}
																		goto end_IL_036d;
																		continue;
																		end_IL_035d:
																		break;
																		IL_035d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_036d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a04;
												IL_0a04:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0968:
												break;
											}
											continue;
											end_IL_097b:
											break;
										}
										continue;
										end_IL_0985:
										break;
									}
									continue;
									end_IL_0990:
									break;
								}
								continue;
								end_IL_09a0:
								break;
							}
							continue;
							end_IL_09b0:
							break;
						}
						continue;
						end_IL_09c0:
						break;
					}
					continue;
					end_IL_09d9:
					break;
				}
				continue;
				end_IL_09e9:
				break;
			}
		}
	}

	private static int smethod_1(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 114;
		num2 = 38;
		return num + 38;
	}

	private unsafe static int smethod_2()
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 18;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IntrospectiveSortUtilitiesSerObjectInfoInit.IIdentityPermissionFactoryAlreadyInstalled);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 140;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0369:
															byte b = *ptr2;
															while (true)
															{
																IL_0359:
																ptr2++;
																while (true)
																{
																	IL_0349:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0329:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_0319:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_0309:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02f9:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_02ec:
																												if (10 <= b)
																												{
																													while (true)
																													{
																														IL_02dc:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_02b7:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_02ab:
																																array2[num5] = null;
																																while (true)
																																{
																																	IL_029b:
																																	num5++;
																																	while (true)
																																	{
																																		IL_0282:
																																		ptr2 += 8;
																																		num = 152;
																																		while (num != 152 && num == 1133)
																																		{
																																			switch (num)
																																			{
																																			case 70:
																																				goto IL_0282;
																																			case 128:
																																				goto IL_029b;
																																			case 102:
																																				goto IL_02ab;
																																			case 108:
																																				goto IL_02b7;
																																			case 81:
																																			case 114:
																																				goto IL_02dc;
																																			case 32:
																																				goto IL_02ec;
																																			case 61:
																																			case 77:
																																				goto IL_02f9;
																																			case 65:
																																				goto IL_0309;
																																			case 115:
																																				goto IL_0319;
																																			case 113:
																																				goto IL_0329;
																																			case 3:
																																				goto IL_0339;
																																			case 29:
																																				goto IL_0349;
																																			case 144:
																																				goto IL_0359;
																																			case 118:
																																			case 141:
																																				goto IL_0369;
																																			case 60:
																																			case 109:
																																				goto IL_0374;
																																			case 74:
																																				goto IL_0382;
																																			case 50:
																																			case 145:
																																				goto IL_039e;
																																			case 123:
																																				goto IL_03ac;
																																			case 12:
																																			case 27:
																																				goto IL_03ba;
																																			case 11:
																																				goto IL_03fe;
																																			case 58:
																																				goto IL_0412;
																																			case 16:
																																			case 72:
																																				goto IL_0425;
																																			case 14:
																																				goto IL_0465;
																																			case 116:
																																				goto IL_0479;
																																			case 38:
																																			case 57:
																																				goto IL_048c;
																																			case 93:
																																				goto IL_04a3;
																																			case 42:
																																			case 55:
																																				goto IL_04ae;
																																			case 135:
																																				goto IL_04ca;
																																			case 54:
																																				goto IL_04d8;
																																			case 117:
																																			case 121:
																																				goto IL_04e3;
																																			case 8:
																																				goto IL_0545;
																																			case 26:
																																				goto IL_0566;
																																			case 82:
																																				goto IL_0574;
																																			case 47:
																																				goto IL_0587;
																																			case 33:
																																			case 67:
																																				goto IL_0595;
																																			case 25:
																																				goto IL_05a3;
																																			case 5:
																																				goto IL_05b1;
																																			case 73:
																																				goto IL_05bf;
																																			case 9:
																																			case 95:
																																				goto IL_05ca;
																																			case 39:
																																				goto IL_05d8;
																																			case 35:
																																			case 62:
																																				goto IL_05e6;
																																			case 51:
																																				goto IL_05ff;
																																			case 59:
																																				goto IL_060d;
																																			case 130:
																																				goto IL_0624;
																																			case 46:
																																			case 66:
																																				goto IL_0637;
																																			case 44:
																																				goto IL_0677;
																																			case 110:
																																				goto IL_068b;
																																			case 79:
																																				goto IL_069e;
																																			case 112:
																																				goto IL_06ac;
																																			case 10:
																																			case 142:
																																				goto IL_06ba;
																																			case 80:
																																				goto IL_06e3;
																																			case 40:
																																			case 71:
																																				goto IL_06fc;
																																			case 37:
																																				goto IL_071a;
																																			case 86:
																																				goto IL_0728;
																																			case 69:
																																				goto IL_073b;
																																			case 89:
																																				goto IL_0752;
																																			case 7:
																																			case 124:
																																				goto IL_075d;
																																			case 30:
																																				goto IL_076b;
																																			case 34:
																																			case 53:
																																				goto IL_0779;
																																			case 0:
																																				goto IL_0787;
																																			case 45:
																																				goto IL_079f;
																																			case 56:
																																				goto IL_07ad;
																																			case 41:
																																			case 99:
																																				goto IL_07c0;
																																			case 127:
																																				goto IL_07ff;
																																			case 91:
																																				goto IL_0812;
																																			case 48:
																																				goto IL_081d;
																																			case 92:
																																			case 129:
																																				goto IL_0828;
																																			case 85:
																																				goto IL_0851;
																																			case 107:
																																				goto IL_085f;
																																			case 111:
																																			case 139:
																																				goto IL_086f;
																																			case 4:
																																			case 6:
																																			case 13:
																																			case 22:
																																			case 24:
																																			case 36:
																																			case 49:
																																			case 68:
																																			case 78:
																																			case 83:
																																			case 87:
																																			case 88:
																																			case 90:
																																			case 94:
																																			case 97:
																																			case 100:
																																			case 101:
																																			case 105:
																																			case 106:
																																			case 120:
																																			case 126:
																																			case 132:
																																			case 134:
																																			case 137:
																																			case 143:
																																				goto end_IL_0339;
																																			case 1:
																																			case 23:
																																			case 28:
																																			case 31:
																																			case 43:
																																			case 52:
																																			case 64:
																																			case 84:
																																			case 96:
																																			case 103:
																																			case 119:
																																			case 125:
																																			case 133:
																																			case 136:
																																			case 138:
																																			case 140:
																																				goto end_IL_026f;
																																			case 63:
																																				goto end_IL_08a0;
																																			case 122:
																																				goto end_IL_08b3;
																																			case 21:
																																				goto end_IL_08be;
																																			case 104:
																																				goto end_IL_08c8;
																																			case 98:
																																				goto end_IL_08d3;
																																			case 2:
																																			case 18:
																																				goto end_IL_08e3;
																																			case 76:
																																				goto end_IL_08f3;
																																			case 17:
																																			case 75:
																																				goto end_IL_0903;
																																			case 19:
																																				goto end_IL_091c;
																																			case 20:
																																				goto end_IL_092c;
																																			case 15:
																																			case 131:
																																				goto IL_0947;
																																			}
																																			continue;
																																			end_IL_026f:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0374;
																												IL_0382:
																												if (9 > b)
																												{
																													goto end_IL_0339;
																												}
																												num = 103;
																												break;
																												IL_0374:
																												if (9 < b)
																												{
																													goto end_IL_0339;
																												}
																												goto IL_0382;
																											}
																											break;
																										}
																										goto IL_039e;
																										IL_0412:
																										num5--;
																										break;
																										IL_039e:
																										if (11 < b)
																										{
																											goto end_IL_0339;
																										}
																										goto IL_03ac;
																										IL_03ac:
																										if (11 > b)
																										{
																											goto end_IL_0339;
																										}
																										goto IL_03ba;
																										IL_03ba:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_03fe;
																										IL_03fe:
																										array[num5 - 2] = 0;
																										goto IL_0412;
																									}
																									break;
																								}
																								goto IL_0425;
																								IL_0479:
																								num5--;
																								break;
																								IL_0425:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0465;
																								IL_0465:
																								array[num5 - 2] = 0;
																								goto IL_0479;
																							}
																							break;
																						}
																						goto IL_048c;
																						IL_0574:
																						if (15 > b)
																						{
																						}
																						goto end_IL_0339;
																						IL_048c:
																						if (14 >= b)
																						{
																							num = 93;
																							goto IL_04a3;
																						}
																						goto IL_0566;
																						IL_0566:
																						if (15 < b)
																						{
																							goto end_IL_0339;
																						}
																						goto IL_0574;
																						IL_04a3:
																						if (14 <= b)
																						{
																							goto IL_04ae;
																						}
																						goto IL_04ca;
																						IL_04ae:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_04ca:
																						if (13 < b)
																						{
																							goto end_IL_0339;
																						}
																						goto IL_04d8;
																						IL_04d8:
																						if (13 > b)
																						{
																							num = 137;
																							goto end_IL_0339;
																						}
																						goto IL_04e3;
																						IL_04e3:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0545;
																						IL_0545:
																						num5 -= 2;
																						break;
																					}
																					break;
																				}
																				goto IL_0587;
																				IL_085f:
																				num5--;
																				break;
																				IL_0587:
																				if (8 > b)
																				{
																					goto IL_0595;
																				}
																				goto IL_086f;
																				IL_0595:
																				if (4 >= b)
																				{
																					goto IL_05a3;
																				}
																				goto IL_073b;
																				IL_05a3:
																				if (4 > b)
																				{
																					goto IL_05b1;
																				}
																				goto IL_06fc;
																				IL_05b1:
																				if (2 >= b)
																				{
																					goto IL_05bf;
																				}
																				goto IL_069e;
																				IL_05bf:
																				if (2 > b)
																				{
																					goto IL_05ca;
																				}
																				goto IL_0637;
																				IL_05ca:
																				if (1 < b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_05d8;
																				IL_05d8:
																				if (1 > b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_05e6;
																				IL_05e6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05ff;
																				IL_05ff:
																				array[num5] = 0;
																				goto IL_060d;
																				IL_060d:
																				num5++;
																				num = 130;
																				goto IL_0624;
																				IL_0624:
																				ptr2 += 8;
																				break;
																				IL_0637:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0677;
																				IL_0677:
																				array[num5 - 2] = 0;
																				goto IL_068b;
																				IL_068b:
																				num5--;
																				break;
																				IL_069e:
																				if (3 < b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_06ac;
																				IL_06ac:
																				if (3 > b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_06ba;
																				IL_06ba:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_06e3;
																				IL_06e3:
																				array[num5 - 1] = 5;
																				break;
																				IL_06fc:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_071a;
																				IL_071a:
																				ptr2 += 8;
																				goto IL_0728;
																				IL_0728:
																				num5--;
																				break;
																				IL_073b:
																				if (6 >= b)
																				{
																					num = 89;
																					goto IL_0752;
																				}
																				goto IL_0812;
																				IL_086f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0752:
																				if (6 > b)
																				{
																					goto IL_075d;
																				}
																				goto IL_07c0;
																				IL_075d:
																				if (5 < b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_076b;
																				IL_076b:
																				if (5 > b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_0779;
																				IL_0779:
																				array[num5] = 5;
																				goto IL_0787;
																				IL_0787:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_079f;
																				IL_079f:
																				num5++;
																				goto IL_07ad;
																				IL_07ad:
																				ptr2 += 8;
																				break;
																				IL_07c0:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07ff;
																				IL_07ff:
																				num5 -= 3;
																				break;
																				IL_0812:
																				if (7 < b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_081d;
																				IL_081d:
																				if (7 > b)
																				{
																					goto end_IL_0339;
																				}
																				goto IL_0828;
																				IL_0828:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0851;
																				IL_0851:
																				ptr2 += 8;
																				goto IL_085f;
																			}
																			goto end_IL_0349;
																			continue;
																			end_IL_0339:
																			break;
																			IL_0339:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 133;
																	break;
																	continue;
																	end_IL_0349:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0947;
													IL_0947:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a0:
													break;
												}
												continue;
												end_IL_08b3:
												break;
											}
											continue;
											end_IL_08be:
											break;
										}
										continue;
										end_IL_08c8:
										break;
									}
									continue;
									end_IL_08d3:
									break;
								}
								continue;
								end_IL_08e3:
								break;
							}
							continue;
							end_IL_08f3:
							break;
						}
						continue;
						end_IL_0903:
						break;
					}
					continue;
					end_IL_091c:
					break;
				}
				continue;
				end_IL_092c:
				break;
			}
		}
	}

	private static int smethod_3(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OnDeserializedAttributeMscorlibDictionaryKeyCollectionDebugView.getInvalidHandleIResourceReader);
										num = 81;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_023c:
														byte b = *ptr2;
														while (true)
														{
															IL_022c:
															ptr2++;
															while (true)
															{
																IL_021c:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_01fc:
																			if (6 >= b)
																			{
																				num = 115;
																				while (true)
																				{
																					if (num != 115)
																					{
																						if (num != 1096)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 18:
																							goto IL_01fc;
																						case 1:
																							goto IL_020c;
																						case 78:
																							goto IL_021c;
																						case 31:
																							goto IL_022c;
																						case 42:
																						case 89:
																							goto IL_023c;
																						case 2:
																							goto IL_0247;
																						case 3:
																							goto IL_0252;
																						case 25:
																						case 51:
																							goto IL_0262;
																						case 22:
																							goto IL_026d;
																						case 28:
																							goto IL_027d;
																						case 21:
																							goto IL_028b;
																						case 27:
																						case 52:
																							goto IL_02a7;
																						case 54:
																						case 65:
																							goto IL_02c3;
																						case 60:
																							goto IL_0325;
																						case 73:
																							goto IL_0338;
																						case 50:
																							goto IL_0343;
																						case 82:
																						case 83:
																							goto IL_0351;
																						case 32:
																							goto IL_0391;
																						case 92:
																							goto IL_03a5;
																						case 95:
																							goto IL_03b8;
																						case 12:
																							goto IL_03c6;
																						case 97:
																						case 100:
																							goto IL_03d4;
																						case 29:
																							goto IL_03f7;
																						case 14:
																							goto IL_0405;
																						case 96:
																							goto IL_0413;
																						case 13:
																						case 15:
																							goto IL_0431;
																						case 47:
																							goto IL_0471;
																						case 6:
																							goto IL_0485;
																						case 49:
																							goto IL_0498;
																						case 11:
																							goto IL_04a6;
																						case 7:
																						case 103:
																							goto IL_04b1;
																						case 58:
																							goto IL_04c9;
																						case 16:
																							goto IL_04d4;
																						case 55:
																						case 104:
																							goto IL_04e2;
																						case 70:
																							goto IL_04fb;
																						case 41:
																							goto IL_0509;
																						case 23:
																							goto IL_0520;
																						case 5:
																						case 86:
																							goto IL_053c;
																						case 37:
																							goto IL_054a;
																						case 48:
																						case 72:
																							goto IL_0558;
																						case 57:
																							goto IL_0581;
																						case 30:
																							goto IL_058f;
																						case 17:
																							goto IL_05a2;
																						case 91:
																							goto IL_05ad;
																						case 77:
																							goto IL_05bd;
																						case 45:
																							goto IL_05c8;
																						case 19:
																						case 108:
																							goto IL_05d3;
																						case 64:
																							goto IL_05e1;
																						case 105:
																							goto IL_0604;
																						case 80:
																							goto IL_0617;
																						case 67:
																							goto IL_0625;
																						case 4:
																						case 8:
																						case 10:
																						case 35:
																						case 43:
																						case 44:
																						case 53:
																						case 59:
																						case 61:
																						case 62:
																						case 69:
																						case 76:
																						case 84:
																						case 85:
																						case 93:
																						case 101:
																						case 102:
																						case 106:
																						case 107:
																							goto end_IL_020c;
																						case 0:
																						case 9:
																						case 26:
																						case 33:
																						case 34:
																						case 36:
																						case 40:
																						case 46:
																						case 63:
																						case 71:
																						case 79:
																						case 87:
																						case 88:
																						case 94:
																							goto end_IL_01e9;
																						case 81:
																							goto end_IL_0648;
																						case 20:
																							goto end_IL_065b;
																						case 99:
																							goto end_IL_0665;
																						case 98:
																							goto end_IL_0679;
																						case 56:
																						case 66:
																							goto end_IL_068e;
																						case 90:
																							goto end_IL_069e;
																						case 39:
																						case 68:
																							goto end_IL_06ae;
																						case 74:
																							goto end_IL_06be;
																						case 75:
																							goto end_IL_06ce;
																						case 24:
																						case 38:
																							goto IL_06e9;
																						}
																						continue;
																					}
																					if (6 <= b)
																					{
																						goto IL_0431;
																					}
																					goto IL_0498;
																					IL_05e1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0604;
																					IL_0617:
																					num5++;
																					goto IL_0625;
																					IL_0604:
																					array2[num5] = null;
																					num = 80;
																					goto IL_0617;
																					IL_0431:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0471;
																					IL_0471:
																					array[num5 - 2] = 0;
																					goto IL_0485;
																					IL_0485:
																					num5--;
																					break;
																					IL_0498:
																					if (3 >= b)
																					{
																						goto IL_04a6;
																					}
																					goto IL_05a2;
																					IL_04a6:
																					if (3 <= b)
																					{
																						goto IL_04b1;
																					}
																					goto IL_04c9;
																					IL_04b1:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_04c9:
																					if (1 >= b)
																					{
																						goto IL_04d4;
																					}
																					num = 86;
																					goto IL_053c;
																					IL_04d4:
																					if (1 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_04e2;
																					IL_04e2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_04fb;
																					IL_04fb:
																					array[num5] = 0;
																					goto IL_0509;
																					IL_0509:
																					num5++;
																					num = 23;
																					goto IL_0520;
																					IL_0520:
																					ptr2 += 8;
																					break;
																					IL_0625:
																					ptr2 += 8;
																					break;
																					IL_053c:
																					if (2 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_054a;
																					IL_054a:
																					if (2 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_0558;
																					IL_0558:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0581;
																					IL_0581:
																					ptr2 += 8;
																					goto IL_058f;
																					IL_058f:
																					num5--;
																					break;
																					IL_05a2:
																					if (4 >= b)
																					{
																						goto IL_05ad;
																					}
																					goto IL_05bd;
																					IL_05ad:
																					if (4 <= b)
																					{
																						break;
																					}
																					goto end_IL_020c;
																					IL_05bd:
																					if (5 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_05c8;
																					IL_05c8:
																					if (5 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_05d3;
																					IL_05d3:
																					array[num5] = 0;
																					goto IL_05e1;
																					continue;
																					end_IL_01e9:
																					break;
																				}
																				break;
																			}
																			goto IL_0247;
																			IL_027d:
																			if (11 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_028b;
																			IL_028b:
																			if (11 <= b)
																			{
																				num = 8;
																			}
																			goto end_IL_020c;
																			IL_0247:
																			if (9 >= b)
																			{
																				goto IL_0252;
																			}
																			goto IL_0262;
																			IL_0252:
																			if (9 <= b)
																			{
																				goto IL_02c3;
																			}
																			goto IL_0338;
																			IL_02c3:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0325;
																			IL_0325:
																			num5 -= 2;
																			break;
																			IL_0338:
																			if (7 >= b)
																			{
																				goto IL_0343;
																			}
																			goto IL_03b8;
																			IL_0343:
																			if (7 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_0351;
																			IL_0351:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0391;
																			IL_0391:
																			array[num5 - 2] = 0;
																			goto IL_03a5;
																			IL_03a5:
																			num5--;
																			break;
																			IL_03b8:
																			if (8 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_03c6;
																			IL_03c6:
																			if (8 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_03d4;
																			IL_03d4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03f7;
																			IL_03f7:
																			array[num5] = 0;
																			goto IL_0405;
																			IL_0405:
																			num5++;
																			goto IL_0413;
																			IL_0413:
																			ptr2 += 8;
																			break;
																			IL_0262:
																			if (10 >= b)
																			{
																				goto IL_026d;
																			}
																			goto IL_027d;
																			IL_026d:
																			if (10 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_02a7;
																			IL_02a7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																		}
																		goto end_IL_021c;
																		continue;
																		end_IL_020c:
																		break;
																		IL_020c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_021c:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06e9;
												IL_06e9:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0648:
												break;
											}
											continue;
											end_IL_065b:
											break;
										}
										continue;
										end_IL_0665:
										break;
									}
									continue;
									end_IL_0679:
									break;
								}
								continue;
								end_IL_068e:
								break;
							}
							continue;
							end_IL_069e:
							break;
						}
						continue;
						end_IL_06ae:
						break;
					}
					continue;
					end_IL_06be:
					break;
				}
				continue;
				end_IL_06ce:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 48;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 47;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileInfoResultHandlerCompatibleComparer.ITypeLibExporterNotifySinkISTOREENUMASSEMBLIESFLAGS);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0312:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			if (8 < b)
																			{
																				while (true)
																				{
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02d5:
																							if (12 <= b)
																							{
																								while (true)
																								{
																									IL_028a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 154;
																									while (true)
																									{
																										if (num != 154)
																										{
																											if (num != 1135)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 11:
																											case 95:
																												goto IL_028a;
																											case 23:
																												goto IL_02d5;
																											case 68:
																											case 98:
																												goto end_IL_02d5;
																											case 80:
																												goto end_IL_02e2;
																											case 133:
																												goto end_IL_02f2;
																											case 29:
																												goto IL_0312;
																											case 97:
																												goto end_IL_0312;
																											case 110:
																											case 146:
																												goto end_IL_0322;
																											case 25:
																											case 81:
																												goto IL_033d;
																											case 52:
																												goto IL_0348;
																											case 40:
																												goto IL_0353;
																											case 108:
																												goto IL_0363;
																											case 112:
																											case 132:
																												goto IL_0373;
																											case 65:
																												goto IL_0381;
																											case 79:
																												goto IL_03a4;
																											case 119:
																												goto IL_03ae;
																											case 4:
																												goto IL_03bc;
																											case 134:
																												goto end_IL_0277;
																											case 137:
																												goto IL_03e2;
																											case 43:
																											case 86:
																												goto IL_03f0;
																											case 91:
																												goto IL_0434;
																											case 107:
																												goto IL_0448;
																											case 37:
																												goto IL_046f;
																											case 117:
																											case 124:
																												goto IL_0482;
																											case 57:
																												goto IL_048d;
																											case 90:
																												goto IL_049b;
																											case 61:
																												goto IL_04ae;
																											case 12:
																											case 34:
																												goto IL_04b9;
																											case 56:
																											case 69:
																												goto IL_04de;
																											case 122:
																												goto IL_04ec;
																											case 13:
																											case 115:
																												goto IL_04fa;
																											case 84:
																												goto IL_055c;
																											case 144:
																												goto IL_056f;
																											case 60:
																											case 143:
																												goto IL_057a;
																											case 38:
																											case 103:
																												goto IL_0592;
																											case 51:
																											case 120:
																												goto IL_05a0;
																											case 58:
																												goto IL_05ae;
																											case 46:
																											case 111:
																												goto IL_05b9;
																											case 9:
																												goto IL_05c7;
																											case 1:
																											case 78:
																												goto IL_05d2;
																											case 10:
																												goto IL_05e0;
																											case 62:
																												goto IL_0601;
																											case 53:
																												goto IL_060f;
																											case 71:
																											case 118:
																												goto IL_0630;
																											case 128:
																												goto IL_066f;
																											case 21:
																											case 22:
																												goto IL_0682;
																											case 87:
																												goto IL_0690;
																											case 72:
																											case 123:
																												goto IL_069e;
																											case 6:
																												goto IL_06d0;
																											case 93:
																												goto IL_06de;
																											case 116:
																												goto IL_06f1;
																											case 142:
																												goto IL_06ff;
																											case 140:
																												goto IL_070d;
																											case 24:
																											case 100:
																												goto IL_0718;
																											case 121:
																												goto IL_0726;
																											case 14:
																											case 31:
																												goto IL_0734;
																											case 64:
																												goto IL_0756;
																											case 33:
																												goto IL_0764;
																											case 59:
																												goto IL_0772;
																											case 0:
																											case 45:
																												goto IL_0785;
																											case 147:
																												goto IL_07c5;
																											case 139:
																												goto IL_07d9;
																											case 3:
																												goto IL_07ec;
																											case 135:
																												goto IL_07fa;
																											case 19:
																											case 44:
																												goto IL_0808;
																											case 138:
																												goto IL_0831;
																											case 2:
																											case 75:
																												goto IL_0859;
																											case 66:
																												goto IL_0877;
																											case 104:
																												goto IL_0885;
																											case 5:
																											case 7:
																											case 15:
																											case 16:
																											case 18:
																											case 20:
																											case 32:
																											case 36:
																											case 49:
																											case 54:
																											case 55:
																											case 67:
																											case 70:
																											case 76:
																											case 83:
																											case 89:
																											case 94:
																											case 99:
																											case 101:
																											case 105:
																											case 109:
																											case 126:
																											case 129:
																											case 131:
																											case 141:
																												goto end_IL_0302;
																											case 17:
																											case 26:
																											case 27:
																											case 30:
																											case 35:
																											case 41:
																											case 63:
																											case 73:
																											case 85:
																											case 88:
																											case 92:
																											case 96:
																											case 102:
																											case 106:
																											case 125:
																											case 130:
																											case 136:
																											case 145:
																												goto end_IL_0332;
																											case 50:
																												goto end_IL_08a8;
																											case 82:
																												goto end_IL_08bb;
																											case 42:
																												goto end_IL_08c5;
																											case 28:
																												goto end_IL_08d0;
																											case 74:
																											case 127:
																												goto end_IL_08e0;
																											case 114:
																												goto end_IL_08f0;
																											case 39:
																											case 113:
																												goto end_IL_0900;
																											case 47:
																												goto end_IL_0910;
																											case 48:
																												goto end_IL_0920;
																											case 8:
																											case 77:
																												goto IL_0944;
																											}
																											continue;
																										}
																										array[num5 - 2] = 0;
																										goto IL_046f;
																										IL_046f:
																										num5--;
																										goto end_IL_0332;
																										continue;
																										end_IL_0277:
																										break;
																									}
																									break;
																								}
																								goto IL_03cf;
																							}
																							goto IL_033d;
																							IL_0448:
																							num5--;
																							goto end_IL_0332;
																							IL_033d:
																							if (10 >= b)
																							{
																								goto IL_0348;
																							}
																							goto IL_0363;
																							IL_0348:
																							if (10 > b)
																							{
																								goto IL_0353;
																							}
																							goto IL_0373;
																							IL_0353:
																							if (9 < b)
																							{
																								goto end_IL_0302;
																							}
																							goto IL_03cf;
																							IL_03cf:
																							if (9 <= b)
																							{
																								goto end_IL_0332;
																							}
																							goto end_IL_0302;
																							IL_0373:
																							array[num5] = 0;
																							goto IL_0381;
																							IL_0381:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03a4;
																							IL_03a4:
																							array2[num5] = null;
																							goto IL_03ae;
																							IL_03ae:
																							num5++;
																							goto IL_03bc;
																							IL_03bc:
																							ptr2 += 8;
																							goto end_IL_0332;
																							IL_0363:
																							if (11 < b)
																							{
																								goto end_IL_0302;
																							}
																							goto IL_03e2;
																							IL_03e2:
																							if (11 > b)
																							{
																								goto end_IL_0302;
																							}
																							goto IL_03f0;
																							IL_03f0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0434;
																							IL_0434:
																							array[num5 - 2] = 0;
																							goto IL_0448;
																							continue;
																							end_IL_02d5:
																							break;
																						}
																						continue;
																					}
																					goto IL_0482;
																					IL_04fa:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_055c;
																					IL_0482:
																					if (14 < b)
																					{
																						goto IL_048d;
																					}
																					goto IL_04ae;
																					IL_048d:
																					if (15 < b)
																					{
																						goto end_IL_0302;
																					}
																					goto IL_049b;
																					IL_049b:
																					if (15 <= b)
																					{
																					}
																					goto end_IL_0302;
																					IL_04ae:
																					if (14 <= b)
																					{
																						goto IL_04b9;
																					}
																					num = 69;
																					goto IL_04de;
																					IL_04b9:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0332;
																					IL_055c:
																					num5 -= 2;
																					goto end_IL_0332;
																					IL_04de:
																					if (13 < b)
																					{
																						goto end_IL_0302;
																					}
																					goto IL_04ec;
																					IL_04ec:
																					if (13 > b)
																					{
																						goto end_IL_0302;
																					}
																					goto IL_04fa;
																					continue;
																					end_IL_02e2:
																					break;
																				}
																				continue;
																			}
																			goto IL_056f;
																			IL_0859:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0877;
																			IL_056f:
																			if (8 <= b)
																			{
																				goto IL_057a;
																			}
																			goto IL_0592;
																			IL_057a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0332;
																			IL_0592:
																			if (4 < b)
																			{
																				goto IL_05a0;
																			}
																			goto IL_06f1;
																			IL_05a0:
																			if (6 >= b)
																			{
																				goto IL_05ae;
																			}
																			goto IL_0682;
																			IL_05ae:
																			if (6 > b)
																			{
																				goto IL_05b9;
																			}
																			goto IL_0630;
																			IL_05b9:
																			if (5 < b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_05c7;
																			IL_05c7:
																			if (5 > b)
																			{
																				num = 83;
																				goto end_IL_0302;
																			}
																			goto IL_05d2;
																			IL_05d2:
																			array[num5] = 5;
																			goto IL_05e0;
																			IL_05e0:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 62;
																			goto IL_0601;
																			IL_0601:
																			num5++;
																			goto IL_060f;
																			IL_060f:
																			ptr2 += 8;
																			goto end_IL_0332;
																			IL_0877:
																			ptr2 += 8;
																			goto IL_0885;
																			IL_0630:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_066f;
																			IL_066f:
																			num5 -= 3;
																			goto end_IL_0332;
																			IL_0682:
																			if (7 < b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_0690;
																			IL_0690:
																			if (7 > b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_069e;
																			IL_069e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 6;
																			goto IL_06d0;
																			IL_06d0:
																			ptr2 += 8;
																			goto IL_06de;
																			IL_06de:
																			num5--;
																			goto end_IL_0332;
																			IL_06f1:
																			if (4 > b)
																			{
																				goto IL_06ff;
																			}
																			num = 2;
																			goto IL_0859;
																			IL_06ff:
																			if (2 >= b)
																			{
																				goto IL_070d;
																			}
																			goto IL_07ec;
																			IL_070d:
																			if (2 > b)
																			{
																				goto IL_0718;
																			}
																			goto IL_0785;
																			IL_0718:
																			if (1 < b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_0726;
																			IL_0726:
																			if (1 > b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_0734;
																			IL_0734:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 64;
																			goto IL_0756;
																			IL_0756:
																			array[num5] = 0;
																			goto IL_0764;
																			IL_0764:
																			num5++;
																			goto IL_0772;
																			IL_0772:
																			ptr2 += 8;
																			goto end_IL_0332;
																			IL_0785:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07c5;
																			IL_07c5:
																			array[num5 - 2] = 0;
																			goto IL_07d9;
																			IL_07d9:
																			num5--;
																			goto end_IL_0332;
																			IL_07ec:
																			if (3 < b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_07fa;
																			IL_07fa:
																			if (3 > b)
																			{
																				goto end_IL_0302;
																			}
																			goto IL_0808;
																			IL_0808:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0831;
																			IL_0831:
																			array[num5 - 1] = 5;
																			num = 136;
																			goto end_IL_0332;
																			IL_0885:
																			num5--;
																			goto end_IL_0332;
																			continue;
																			end_IL_02f2:
																			break;
																		}
																		continue;
																		end_IL_0302:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0332;
																continue;
																end_IL_0312:
																break;
															}
															continue;
															end_IL_0322:
															break;
														}
														continue;
														end_IL_0332:
														break;
													}
													continue;
												}
												goto IL_0944;
												IL_0944:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a8:
												break;
											}
											continue;
											end_IL_08bb:
											break;
										}
										continue;
										end_IL_08c5:
										break;
									}
									continue;
									end_IL_08d0:
									break;
								}
								continue;
								end_IL_08e0:
								break;
							}
							continue;
							end_IL_08f0:
							break;
						}
						continue;
						end_IL_0900:
						break;
					}
					continue;
					end_IL_0910:
					break;
				}
				continue;
				end_IL_0920:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 100;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 116;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDefaultValueICLRSurrogateEntry.DequeuePRIExceptionInfo);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 3;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02cc:
																	if (b >= 1)
																	{
																		while (b <= 13)
																		{
																			while (true)
																			{
																				IL_02af:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_029f:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_028f:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_027f:
																										if (5 < b)
																										{
																											while (6 >= b)
																											{
																												while (true)
																												{
																													IL_025c:
																													if (6 > b)
																													{
																														num = 139;
																														while (num != 139 && num == 1120)
																														{
																															switch (num)
																															{
																															case 19:
																																goto IL_025c;
																															case 40:
																															case 85:
																																goto IL_026f;
																															case 35:
																															case 56:
																																goto IL_027f;
																															case 17:
																															case 71:
																																goto IL_028f;
																															case 132:
																																goto IL_029f;
																															case 36:
																																goto IL_02af;
																															case 98:
																																goto IL_02bc;
																															case 77:
																																goto IL_02cc;
																															case 92:
																																goto end_IL_02cc;
																															case 3:
																																goto end_IL_02dc;
																															case 72:
																																goto end_IL_02ec;
																															case 25:
																															case 79:
																																goto IL_030b;
																															case 7:
																																goto IL_0319;
																															case 39:
																																goto IL_0327;
																															case 62:
																																goto IL_0332;
																															case 76:
																															case 90:
																																goto IL_0340;
																															case 61:
																																goto IL_0363;
																															case 63:
																																goto IL_0371;
																															case 0:
																																goto IL_037f;
																															case 21:
																															case 96:
																																goto IL_0392;
																															case 37:
																																goto IL_03a0;
																															case 48:
																															case 64:
																																goto IL_03ae;
																															case 110:
																																goto IL_0410;
																															case 113:
																															case 115:
																																goto IL_0423;
																															case 26:
																																goto IL_042e;
																															case 66:
																																goto IL_0439;
																															case 4:
																															case 6:
																																goto IL_0449;
																															case 68:
																																goto IL_0465;
																															case 42:
																															case 118:
																																goto IL_047e;
																															case 27:
																																goto IL_048c;
																															case 54:
																																goto IL_04b0;
																															case 124:
																																goto IL_04c0;
																															case 125:
																																goto IL_04d0;
																															case 129:
																																goto IL_04e3;
																															case 78:
																															case 130:
																																goto IL_04ff;
																															case 53:
																															case 127:
																																goto IL_0512;
																															case 24:
																																goto IL_0552;
																															case 14:
																																goto IL_0566;
																															case 109:
																																goto IL_0579;
																															case 82:
																															case 97:
																																goto IL_0584;
																															case 131:
																																goto IL_0592;
																															case 34:
																																goto IL_05b5;
																															case 106:
																																goto IL_05bf;
																															case 128:
																																goto IL_05cd;
																															case 59:
																															case 73:
																																goto IL_05e9;
																															case 11:
																																goto IL_0600;
																															case 18:
																																goto IL_0613;
																															case 69:
																																goto IL_0621;
																															case 87:
																																goto IL_062c;
																															case 80:
																																goto IL_063a;
																															case 55:
																															case 94:
																																goto IL_0648;
																															case 83:
																																goto IL_0671;
																															case 28:
																																goto IL_067f;
																															case 123:
																																goto IL_06a4;
																															case 91:
																															case 95:
																																goto IL_06b2;
																															case 88:
																																goto IL_06cb;
																															case 30:
																																goto IL_06d9;
																															case 23:
																																goto IL_06e7;
																															case 75:
																															case 93:
																																goto IL_06fa;
																															case 117:
																															case 122:
																																goto IL_0718;
																															case 51:
																																goto IL_0758;
																															case 112:
																																goto IL_076c;
																															case 2:
																															case 5:
																															case 9:
																															case 10:
																															case 20:
																															case 22:
																															case 31:
																															case 33:
																															case 38:
																															case 43:
																															case 46:
																															case 49:
																															case 50:
																															case 58:
																															case 60:
																															case 67:
																															case 70:
																															case 81:
																															case 86:
																															case 102:
																															case 107:
																															case 108:
																															case 111:
																															case 114:
																																goto end_IL_0249;
																															case 8:
																															case 13:
																															case 16:
																															case 32:
																															case 41:
																															case 44:
																															case 47:
																															case 52:
																															case 57:
																															case 65:
																															case 74:
																															case 89:
																															case 103:
																															case 104:
																															case 119:
																															case 121:
																																goto end_IL_02f7;
																															case 12:
																																goto end_IL_078f;
																															case 29:
																																goto end_IL_07a2;
																															case 120:
																																goto end_IL_07ac;
																															case 15:
																																goto end_IL_07b7;
																															case 1:
																															case 105:
																																goto end_IL_07cc;
																															case 126:
																																goto end_IL_07dc;
																															case 101:
																															case 116:
																																goto end_IL_07ec;
																															case 99:
																																goto end_IL_07fc;
																															case 100:
																																goto end_IL_080c;
																															case 45:
																															case 84:
																																goto IL_0830;
																															}
																															continue;
																															end_IL_0249:
																															break;
																														}
																														break;
																													}
																													goto IL_0512;
																													IL_0552:
																													array[num5 - 2] = 0;
																													goto IL_0566;
																													IL_0566:
																													num5--;
																													goto end_IL_02f7;
																													IL_0512:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0552;
																												}
																												break;
																												IL_026f:;
																											}
																											break;
																										}
																										goto IL_0579;
																										IL_05e9:
																										if (4 < b)
																										{
																											break;
																										}
																										num = 11;
																										goto IL_0600;
																										IL_0579:
																										if (5 <= b)
																										{
																											goto IL_0584;
																										}
																										num = 73;
																										goto IL_05e9;
																										IL_0584:
																										array[num5] = 0;
																										goto IL_0592;
																										IL_0592:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_05b5;
																										IL_05b5:
																										array2[num5] = null;
																										goto IL_05bf;
																										IL_05bf:
																										num5++;
																										goto IL_05cd;
																										IL_05cd:
																										ptr2 += 8;
																										goto end_IL_02f7;
																										IL_0600:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_02f7;
																									}
																									break;
																								}
																								goto IL_0613;
																								IL_06e7:
																								ptr2 += 8;
																								goto end_IL_02f7;
																								IL_0613:
																								if (3 > b)
																								{
																									goto IL_0621;
																								}
																								goto IL_06fa;
																								IL_0621:
																								if (1 < b)
																								{
																									goto IL_062c;
																								}
																								num = 123;
																								goto IL_06a4;
																								IL_062c:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_063a;
																								IL_063a:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0648;
																								IL_0648:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0671;
																								IL_0671:
																								ptr2 += 8;
																								goto IL_067f;
																								IL_067f:
																								num5--;
																								num = 104;
																								goto end_IL_02f7;
																								IL_06fa:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								num = 52;
																								goto end_IL_02f7;
																								IL_06a4:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_06b2;
																								IL_06b2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_06cb;
																								IL_06cb:
																								array[num5] = 0;
																								goto IL_06d9;
																								IL_06d9:
																								num5++;
																								goto IL_06e7;
																							}
																							break;
																						}
																						goto IL_0718;
																						IL_076c:
																						num5--;
																						goto end_IL_02f7;
																						IL_0718:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0758;
																						IL_0758:
																						array[num5 - 2] = 0;
																						goto IL_076c;
																					}
																					break;
																				}
																				num = 79;
																				goto IL_030b;
																				IL_0465:
																				if (13 < b)
																				{
																					num = 46;
																					break;
																				}
																				goto IL_04d0;
																				IL_04d0:
																				if (13 <= b)
																				{
																				}
																				break;
																				IL_030b:
																				if (10 >= b)
																				{
																					goto IL_0319;
																				}
																				goto IL_0423;
																				IL_0319:
																				if (10 > b)
																				{
																					goto IL_0327;
																				}
																				goto IL_047e;
																				IL_0327:
																				if (8 >= b)
																				{
																					goto IL_0332;
																				}
																				goto IL_0392;
																				IL_0332:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0340;
																				IL_0340:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0363;
																				IL_0363:
																				array[num5] = 0;
																				goto IL_0371;
																				IL_0371:
																				num5++;
																				goto IL_037f;
																				IL_037f:
																				ptr2 += 8;
																				goto end_IL_02f7;
																				IL_0392:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_03a0;
																				IL_03a0:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_03ae;
																				IL_03ae:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0410;
																				IL_0410:
																				num5 -= 2;
																				goto end_IL_02f7;
																				IL_047e:
																				array[num5] = 0;
																				goto IL_048c;
																				IL_048c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)IsNestedFamilyEventTooBig[*(int*)(ptr2 + num3)])();
																				goto IL_04b0;
																				IL_04b0:
																				num5++;
																				goto IL_04e3;
																				IL_04e3:
																				ptr2 += 8;
																				num = 74;
																				goto end_IL_02f7;
																				IL_0423:
																				if (12 >= b)
																				{
																					goto IL_042e;
																				}
																				goto IL_0465;
																				IL_042e:
																				if (12 > b)
																				{
																					goto IL_0439;
																				}
																				goto IL_0449;
																				IL_0439:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_04c0;
																				IL_04c0:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_04ff;
																				IL_04ff:
																				num5--;
																				goto end_IL_02f7;
																				IL_0449:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02f7;
																			}
																			break;
																			IL_02bc:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f7;
																	continue;
																	end_IL_02cc:
																	break;
																}
																continue;
																end_IL_02dc:
																break;
															}
															continue;
															end_IL_02ec:
															break;
														}
														continue;
														end_IL_02f7:
														break;
													}
													continue;
												}
												goto IL_0830;
												IL_0830:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_078f:
												break;
											}
											continue;
											end_IL_07a2:
											break;
										}
										continue;
										end_IL_07ac:
										break;
									}
									continue;
									end_IL_07b7:
									break;
								}
								continue;
								end_IL_07cc:
								break;
							}
							continue;
							end_IL_07dc:
							break;
						}
						continue;
						end_IL_07ec:
						break;
					}
					continue;
					end_IL_07fc:
					break;
				}
				continue;
				end_IL_080c:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 67;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								IL_0609:
								long[] array4 = new long[2];
								while (true)
								{
									IL_05eb:
									array3[0] = int_1;
									num = 83;
									while (true)
									{
										IL_05e0:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RawAclgetAppDomainManagerType.GetTypeLibLcidgetResult);
										while (true)
										{
											IL_05d6:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_05c3:
												if (num4 != 1)
												{
													while (true)
													{
														IL_026e:
														byte b = *ptr2;
														while (true)
														{
															IL_0255:
															ptr2++;
															num = 16;
															while (true)
															{
																IL_0245:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0225:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0218:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0208:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01fb:
																									if (3 < b)
																									{
																										while (4 >= b)
																										{
																											num = 110;
																											while (true)
																											{
																												if (num != 110)
																												{
																													if (num != 1091)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 71:
																													case 89:
																														goto IL_01e8;
																													case 32:
																														goto IL_01fb;
																													case 77:
																														goto IL_0208;
																													case 70:
																														goto IL_0218;
																													case 93:
																														goto IL_0225;
																													case 79:
																														goto IL_0235;
																													case 16:
																														goto IL_0245;
																													case 75:
																														goto IL_0255;
																													case 2:
																													case 55:
																														goto IL_026e;
																													case 9:
																														goto IL_0279;
																													case 14:
																													case 54:
																														goto IL_0289;
																													case 58:
																													case 65:
																														goto IL_0299;
																													case 69:
																														goto IL_02b1;
																													case 82:
																														goto IL_02d4;
																													case 51:
																														goto IL_02de;
																													case 25:
																														goto IL_02ec;
																													case 18:
																														goto IL_031b;
																													case 10:
																													case 72:
																														goto IL_0326;
																													case 76:
																														goto IL_0334;
																													case 3:
																													case 31:
																														goto IL_0342;
																													case 84:
																														goto IL_035b;
																													case 86:
																														goto IL_0369;
																													case 7:
																														goto IL_0380;
																													case 4:
																													case 43:
																														goto IL_0393;
																													case 91:
																														goto IL_03bc;
																													case 48:
																														goto IL_03ca;
																													case 36:
																														goto IL_03dd;
																													case 20:
																														goto IL_03eb;
																													case 12:
																													case 90:
																														goto IL_03f9;
																													case 47:
																														goto IL_0404;
																													case 39:
																													case 49:
																														goto IL_0412;
																													case 44:
																														goto IL_0452;
																													case 102:
																														goto IL_0466;
																													case 80:
																														goto IL_0479;
																													case 11:
																														goto IL_0487;
																													case 64:
																													case 99:
																														goto IL_0495;
																													case 87:
																														goto IL_04c1;
																													case 6:
																														goto IL_04cf;
																													case 74:
																														goto IL_04dd;
																													case 29:
																													case 42:
																														goto IL_04f0;
																													case 40:
																														goto IL_0552;
																													case 1:
																													case 27:
																														goto IL_0562;
																													case 92:
																														goto IL_056d;
																													case 38:
																													case 101:
																														goto IL_0578;
																													case 81:
																														goto IL_0591;
																													case 95:
																														goto IL_059c;
																													case 0:
																													case 8:
																													case 22:
																													case 23:
																													case 26:
																													case 35:
																													case 37:
																													case 41:
																													case 45:
																													case 50:
																													case 56:
																													case 68:
																													case 73:
																													case 78:
																													case 85:
																													case 88:
																													case 94:
																													case 98:
																													case 103:
																														goto end_IL_01e8;
																													case 15:
																													case 17:
																													case 21:
																													case 28:
																													case 30:
																													case 52:
																													case 53:
																													case 59:
																													case 60:
																													case 62:
																													case 63:
																													case 96:
																													case 97:
																														goto IL_05c3;
																													case 34:
																														goto IL_05d6;
																													case 83:
																														goto IL_05e0;
																													case 24:
																														goto IL_05eb;
																													case 33:
																														goto IL_0609;
																													case 13:
																													case 61:
																														goto end_IL_01d5;
																													case 46:
																														goto end_IL_0619;
																													case 5:
																													case 19:
																														goto end_IL_0629;
																													case 66:
																														goto end_IL_0639;
																													case 67:
																														goto end_IL_0649;
																													case 57:
																													case 100:
																														goto IL_0664;
																													}
																													continue;
																												}
																												if (4 > b)
																												{
																													goto end_IL_01e8;
																												}
																												goto IL_05c3;
																												continue;
																												end_IL_01d5:
																												break;
																											}
																											goto end_IL_0245;
																											continue;
																											end_IL_01e8:
																											break;
																											IL_01e8:;
																										}
																										break;
																									}
																									goto IL_0279;
																									IL_0299:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_05c3;
																									IL_0279:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0299;
																								}
																								break;
																							}
																							num = 18;
																							goto IL_031b;
																							IL_03bc:
																							ptr2 += 8;
																							goto IL_03ca;
																							IL_03ca:
																							num5--;
																							goto IL_05c3;
																							IL_031b:
																							if (2 > b)
																							{
																								goto IL_0326;
																							}
																							goto IL_0393;
																							IL_0326:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0334;
																							IL_0334:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0342;
																							IL_0342:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_035b;
																							IL_035b:
																							array[num5] = 0;
																							goto IL_0369;
																							IL_0369:
																							num5++;
																							num = 7;
																							goto IL_0380;
																							IL_0380:
																							ptr2 += 8;
																							goto IL_05c3;
																							IL_0393:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03bc;
																						}
																						break;
																					}
																					goto IL_0289;
																					IL_02ec:
																					ptr2 += 8;
																					goto IL_05c3;
																					IL_0289:
																					array[num5] = 0;
																					goto IL_02b1;
																					IL_02b1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02d4;
																					IL_02d4:
																					array2[num5] = null;
																					goto IL_02de;
																					IL_02de:
																					num5++;
																					goto IL_02ec;
																				}
																				break;
																			}
																			goto IL_03dd;
																			IL_059c:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_03dd:
																			if (8 >= b)
																			{
																				goto IL_03eb;
																			}
																			goto IL_0562;
																			IL_03eb:
																			if (8 > b)
																			{
																				goto IL_03f9;
																			}
																			goto IL_04f0;
																			IL_03f9:
																			if (6 >= b)
																			{
																				goto IL_0404;
																			}
																			goto IL_0479;
																			IL_0404:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0412;
																			IL_0412:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0452;
																			IL_0452:
																			array[num5 - 2] = 0;
																			goto IL_0466;
																			IL_0466:
																			num5--;
																			goto IL_05c3;
																			IL_0479:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0487;
																			IL_0487:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0495;
																			IL_0495:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 87;
																			goto IL_04c1;
																			IL_04c1:
																			array[num5] = 0;
																			goto IL_04cf;
																			IL_04cf:
																			num5++;
																			goto IL_04dd;
																			IL_04dd:
																			ptr2 += 8;
																			goto IL_05c3;
																			IL_04f0:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0552;
																			IL_0552:
																			num5 -= 2;
																			goto IL_05c3;
																			IL_0562:
																			if (9 >= b)
																			{
																				goto IL_056d;
																			}
																			goto IL_0591;
																			IL_056d:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0578;
																			IL_0578:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_05c3;
																			IL_0591:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_059c;
																		}
																		break;
																		IL_0235:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 97;
																goto IL_05c3;
																continue;
																end_IL_0245:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0664;
												IL_0664:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_0619:
							break;
						}
						continue;
						end_IL_0629:
						break;
					}
					continue;
					end_IL_0639:
					break;
				}
				continue;
				end_IL_0649:
				break;
			}
		}
	}

	static Class117()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 14;
			while (true)
			{
				if (num != 14)
				{
					if (num != 995)
					{
						return;
					}
					switch (num)
					{
					case 5:
						goto end_IL_0041;
					case 1:
					case 3:
						goto IL_0064;
					case 0:
						return;
					case 2:
						return;
					case 4:
						return;
					case 6:
						return;
					case 7:
						return;
					}
					continue;
				}
				Class300.smethod_0();
				goto IL_0064;
				IL_0064:
				num = 7;
				return;
				continue;
				end_IL_0041:
				break;
			}
		}
	}
}
